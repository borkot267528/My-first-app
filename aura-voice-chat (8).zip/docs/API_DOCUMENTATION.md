# Aura Voice Chat Platform — Production API Documentation

Version: 1.0.0  
Base URL: `/api`  
Authentication: Bearer Token (JWT) or `X-Demo-User-Id` Header (for sandbox/preview environments)  
OpenAPI 3.0 Spec Endpoint: `/api/docs/json`  
Interactive Swagger UI: `/api/docs`

---

## Overview
The Aura Voice Chat API is a high-performance REST and Real-time messaging service built for modern Android and Web voice social platforms. It powers live audio rooms, gift sending with screen-wide animations, multi-currency wallets (Coins and Diamonds), lucky bag drops, daily spins, PK battles, family clans, 1-on-1 private messaging, and hierarchical staff administration.

---

## 1. Authentication & Users Module
All authenticated endpoints require a valid JWT token in the `Authorization: Bearer <token>` header.

### POST `/api/auth/firebase`
Simulates or verifies a Firebase Authentication ID token and issues a session JWT.
- **Request Body:**
  ```json
  {
    "firebaseUid": "firebase-test-101",
    "email": "user@auravoice.io",
    "displayName": "Elena Vance",
    "avatar": "https://images.unsplash.com/..."
  }
  ```
- **Response (200 OK):**
  ```json
  {
    "success": true,
    "data": {
      "user": { "id": "usr-001", "name": "Elena Vance", "role": "ceo", ... },
      "tokens": { "accessToken": "eyJhbGciOi...", "expiresIn": 86400 }
    }
  }
  ```

### GET `/api/auth/me`
Returns the currently authenticated user profile and wallet balances.
- **Response (200 OK):**
  ```json
  {
    "success": true,
    "data": {
      "id": "usr-001", "name": "Elena Vance", "role": "ceo", "coins": 50000, "diamonds": 1200, "vipLevel": "svip"
    }
  }
  ```

---

## 2. Voice Rooms & Seats Module

### GET `/api/rooms?category={category}&search={search}`
Retrieves a filtered list of active voice rooms.
- **Query Parameters:** `category` (all, popular, country, family, game, music), `search` (keyword string).

### GET `/api/rooms/:id`
Retrieves detailed metadata for a specific voice room along with its real-time message history.

### POST `/api/rooms`
Creates a new live voice room.
- **Request Body:** `{ "title": "Night Beats", "topic": "Chill music & chat", "category": "music" }`

### POST `/api/rooms/:id/seats`
Joins or moves to a specific microphone seat in the voice room.
- **Request Body:** `{ "seatIndex": 1 }`

---

## 3. Gifts & Animations Module

### GET `/api/gifts`
Returns the complete catalog of virtual gifts with coin prices and animation trigger metadata.

### POST `/api/gifts/send`
Sends a virtual gift from the authenticated user to a target host/user in a voice room, deducting Coins from sender and adding Diamonds to recipient.
- **Request Body:**
  ```json
  {
    "recipientId": "usr-003",
    "giftId": "gft-1",
    "count": 1,
    "roomId": "room-101"
  }
  ```
- **Response (200 OK):**
  ```json
  {
    "success": true,
    "data": {
      "senderBalance": { "coins": 49900 },
      "recipientBalance": { "diamonds": 1250 },
      "animation": { "type": "screen_effect", "url": "https://...", "duration": 4000 }
    }
  }
  ```

---

## 4. Wallet & Financial Ledger Module

### POST `/api/wallet/recharge`
Recharges Coins into the user's wallet via mock or real payment gateway callbacks.
- **Request Body:** `{ "amountCoins": 5000, "costUsd": 49.99, "packageId": "pkg_5000" }`

### POST `/api/wallet/withdraw`
Submits a withdrawal request to convert earned Diamonds into real currency.
- **Request Body:** `{ "amountDiamonds": 1000, "payoutMethod": "Bank Transfer #991" }`

### GET `/api/wallet/transactions`
Retrieves paginated financial transaction history (recharges, gifts, withdrawals, lucky bags).

---

## 5. Lucky Bag & Daily Spin Module

### GET `/api/luckybags?roomId={roomId}`
Retrieves active lucky bag countdown timers in a room.

### POST `/api/luckybags`
Creates and drops a randomized coin lucky bag into a voice room.
- **Request Body:** `{ "roomId": "room-101", "totalCoins": 500, "totalWinners": 5 }`

### POST `/api/luckybags/:id/claim`
Claims a randomized coin share from an active lucky bag when the countdown expires.

---

## 6. PK Battles Module

### GET `/api/pk/live`
Returns currently active 1v1 Room PK battles with real-time score indicators.

### POST `/api/pk/start`
Initiates a timed PK battle between two active voice rooms.

---

## 7. Family Clans Module

### GET `/api/families`
Returns ranked family clans with contribution scores and member counts.

### GET `/api/families/:id`
Returns detailed clan information, member roster, and announcement bulletins.

---

## 8. Messaging & Real-time Notifications Module

### GET `/api/messages/conversations`
Retrieves recent 1-on-1 private conversation previews.

### GET `/api/messages/private/:peerId`
Retrieves private chat message history between the current user and a target peer.

### POST `/api/messages/private`
Sends a 1-on-1 direct message (text, image, or audio voice note).

### GET `/api/notifications`
Retrieves user notifications (system alerts, gift notifications, PK outcomes).

---

## 9. RBAC Admin & Analytics Module
Requires staff role permissions (`ceo`, `gm`, `manager`, `super_admin`, `admin`, `bd`, `agency`, `host`).

### GET `/api/admin/overview`
Returns executive KPI metrics (DAU, active rooms, revenue, commission calculations).

### GET `/api/admin/security`
Returns system security audit report, rate limit metrics, and database connection state.

### POST `/api/admin/moderate-report`
Resolves or escalates user moderation reports.

### GET `/api/test/suite`
Executes the automated 10-suite integration test runner verifying 100% backend health.
