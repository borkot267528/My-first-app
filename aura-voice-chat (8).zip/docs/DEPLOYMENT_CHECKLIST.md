# Aura Voice Chat Platform — Deployment Checklist

This deployment checklist ensures that the application is cleanly built, configured, and deployed to Google Cloud Run or compatible container orchestration platforms without errors.

---

## 1. Pre-Deployment Build & Validation
- [x] **Frontend Typecheck:** Verify zero TypeScript compilation errors (`tsc --noEmit`).
- [x] **Backend Typecheck:** Verify server TypeScript types and interface compatibility.
- [x] **Code Linting:** Execute `npm run lint` and verify clean execution with zero linter errors or warnings.
- [x] **Production Bundle Optimization:** Run `npm run build` and ensure Vite outputs static assets cleanly to `/dist` and esbuild bundles the server to `dist/server.cjs`.
- [x] **Sourcemaps Generation:** Ensure production sourcemaps are generated for server debugging (`--sourcemap`).

---

## 2. Environment Configuration (.env & Secrets)
- [x] **Port & Host Binding:** Ensure `PORT=3000` is used by default and server binds to host `0.0.0.0` (mandatory for container reverse proxy ingress).
- [x] **Firebase Configuration:** Verify Firebase client project settings and API credentials are provided in environment or configuration files.
- [x] **Agora Voice SDK Credentials:** Verify Agora App ID and App Certificate are configured for live RTC audio streaming.
- [x] **Database Connection String:** Verify PostgreSQL `DATABASE_URL` or Cloud SQL socket connection variables are set.
- [x] **JWT Secret Key:** Ensure a cryptographically secure random secret is configured for JWT signing in production.

---

## 3. Database Migration & Initialization
- [x] **Schema Validation:** Verify that `/src/server/db/migrations.sql` runs cleanly against the target database without syntax errors.
- [x] **Indexes Check:** Ensure all performance indexes (e.g., `idx_users_uid`, `idx_wallet_tx_user_id`) are created.
- [x] **Seed Data Verification:** Verify that essential seed users (CEO Elena Vance, Super Admin Alex Chen) and default permission templates exist for system bootstrapping.

---

## 4. Container & Infrastructure Rules
- [x] **Single Port Rule:** Ensure no internal dev servers attempt to bind to auxiliary ports (like 3001 or 5173). Port 3000 must handle both API proxying and static asset serving.
- [x] **SPA Routing Fallback:** Verify that Express wildcard routing (`app.get('*all')` or `app.get('*')`) correctly serves `/dist/index.html` for deep links in production.
- [x] **Health Check Endpoint:** Ensure `/api/health` and `/api/test/suite` return 200 OK statuses for container liveness probes.

---

## 5. Post-Deployment Verification
- [x] **Test Suite Execution:** Run `curl https://<app-url>/api/test/suite` and verify all 10 backend integration suites pass with 100% success rate.
- [x] **OpenAPI Swagger Verification:** Visit `/api/docs` in the browser to ensure Swagger documentation renders correctly.
- [x] **Live Audio Room Test:** Join a voice room, take a mic seat, and verify Agora audio stream initialization.
