# Aura Voice Chat Platform — Database Architecture & Schema Documentation

Version: 1.0.0  
Engine: PostgreSQL 16+ (Cloud SQL / Neon / Supabase compatible)  
ORM / Query Layer: Native SQL with connection pooling & strictly indexed metadata  
Migrations File: `/src/server/db/migrations.sql`

---

## 1. Schema Overview & Entity Relationship Diagram (ERD)

The Aura Voice Chat database schema is optimized for high-concurrency audio social platforms. It separates read-heavy user profiles from transactional wallet ledgers and real-time room states.

```
[users] 1<---1 [user_profiles]
   | 
   +---1<---* [staff] 
   +---1<---* [audit_logs]
   +---1<---* [voice_rooms] 1<---* [room_members]
   +---1<---* [wallet_transactions]
   +---1<---* [lucky_bags] 1<---* [lucky_bag_claims]
   +---1<---* [private_messages]
   +---1<---* [notifications]
```

---

## 2. Table Definitions & Indexing Strategy

### Table: `users`
Stores core identity, authentication mappings, and real-time wallet balances.
- **Primary Key:** `id` (UUID, auto-generated)
- **Attributes:** `uid` (Unique alphanumeric ID), `email`, `name`, `avatar`, `role`, `coins` (BIGINT, >= 0), `diamonds` (BIGINT, >= 0), `is_online` (BOOLEAN).
- **Indexes:**
  - `idx_users_uid` on `(uid)` — Fast profile lookups by user handle.
  - `idx_users_email` on `(email)` — Firebase authentication mapping.
  - `idx_users_role` on `(role)` — Quick RBAC filtering for staff queries.

### Table: `user_profiles`
Stores extended social attributes and VIP subscription states.
- **Foreign Key:** `user_id` (UUID, references `users(id)` ON DELETE CASCADE)
- **Attributes:** `bio`, `frame_id`, `background_id`, `vip_level` ('none', 'vip', 'svip'), `vip_expiry`, `level`.
- **Indexes:**
  - `idx_user_profiles_vip_level` on `(vip_level)` — Leaderboard ranking optimizations.

### Table: `staff` & `permission_templates`
Manages hierarchical role-based access control (RBAC) and staff assignment logs.
- **Roles:** `ceo`, `gm`, `manager`, `super_admin`, `admin`, `bd`, `agency`, `host`.
- **Attributes:** `user_id`, `role`, `assigned_by`, `status` ('active', 'suspended').
- **Indexes:** `idx_staff_user_id`, `idx_staff_role`, `idx_staff_status`.

### Table: `audit_logs`
Immutable compliance log recording all administrative overrides, bans, and system changes.
- **Attributes:** `id`, `action`, `module`, `performed_by_user_id`, `performed_by_role`, `target_id`, `details` (JSONB), `ip_address`, `timestamp`.
- **Indexes:** `idx_audit_logs_module`, `idx_audit_logs_performed_by`, `idx_audit_logs_timestamp`.

### Table: `voice_rooms` & `room_members`
Stores active audio room metadata, categories, seat configurations, and participant rosters.
- **Attributes:** `title`, `topic`, `category`, `host_id`, `country`, `max_seats` (1 to 20), `is_locked`.
- **Indexes:** `idx_voice_rooms_category`, `idx_voice_rooms_host_id`, `idx_voice_rooms_country`.

### Table: `wallet_transactions`
ACID-compliant ledger recording every coin movement, gift sending, recharge, and cash withdrawal.
- **Attributes:** `id`, `user_id`, `type` ('recharge', 'gift_sent', 'gift_received', 'lucky_bag', 'withdrawal'), `amount`, `currency` ('coins', 'diamonds'), `reference_id`, `status` ('pending', 'completed', 'failed'), `created_at`.
- **Indexes:** `idx_wallet_tx_user_id`, `idx_wallet_tx_type`, `idx_wallet_tx_status`, `idx_wallet_tx_created_at`.

### Table: `lucky_bags` & `lucky_bag_claims`
Manages room coin pools and randomized distribution tracking.
- **Attributes:** `room_id`, `creator_id`, `total_coins`, `remaining_coins`, `total_winners`, `status` ('active', 'claimed', 'expired'), `expires_at`.
- **Indexes:** `idx_lucky_bags_room_id`, `idx_lucky_bags_status`.

### Table: `private_messages` & `notifications`
Stores 1-on-1 direct messages and system alert broadcasts.
- **Indexes:** `idx_private_msg_sender_receiver`, `idx_notifications_user_id`.

---

## 3. Query Optimization & Performance Rules
1. **Never use `SELECT *` in production queries** — Explicitly list required column projections to minimize network payloads.
2. **Atomic Balance Updates** — Use database-level check constraints (`CHECK (coins >= 0)`) and transactional locks when processing virtual gifts or withdrawals to prevent double-spending or negative balances.
3. **JSONB Indexing** — Use GIN indexes on `audit_logs(details)` when querying deep administrative metadata.
4. **Connection Pooling** — Keep max pool size configured to 20 connections per container replica to prevent Postgres exhaustion under high load.
