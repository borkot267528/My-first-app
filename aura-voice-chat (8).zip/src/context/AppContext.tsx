/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, VoiceRoom, Gift, Family, RoomMessage } from '../types';
import { ApiClient, getApiBaseUrl } from '../lib/api';
import { 
  auth, 
  db,
  googleProvider,
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  sendPasswordResetEmail,
  fbSignOut, 
  onAuthStateChanged,
  fbUpdateProfile,
  signInWithPopup,
  FirebaseUser 
} from '../lib/firebase';
import { doc, getDoc, onSnapshot } from 'firebase/firestore';
import { 
  createRealFirestoreUserProfile, 
  fetchUserFromFirestore, 
  normalizeFirestoreUser 
} from '../lib/firestoreUsers';

export type NavTab = 'home' | 'rooms' | 'messages' | 'family' | 'profile';
export type ModalType = 'none' | 'vip_shop' | 'wallet' | 'lucky_bag' | 'spin' | 'pk' | 'admin' | 'api_docs' | 'create_room' | 'cp' | 'friends' | 'search';

export interface ExtraSignUpData {
  phone?: string;
  country?: string;
  countryFlag?: string;
  gender?: 'male' | 'female' | 'other';
}

interface AppContextType {
  currentUser: User | null;
  setCurrentUser: React.Dispatch<React.SetStateAction<User | null>>;
  firebaseUser: FirebaseUser | null;
  isAuthLoading: boolean;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  isSearchOpen: boolean;
  setIsSearchOpen: (open: boolean) => void;
  searchInitialQuery: string;
  openUserSearch: (initialQuery?: string) => void;
  signInWithEmail: (email: string, password: string) => Promise<User>;
  signUpWithEmail: (email: string, password: string, displayName: string, extra?: ExtraSignUpData) => Promise<User>;
  sendResetPassword: (email: string) => Promise<void>;
  signInWithGoogle: () => Promise<User>;
  signOut: () => Promise<void>;
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  activeModal: ModalType;
  setActiveModal: (modal: ModalType) => void;
  activeRoom: VoiceRoom | null;
  setActiveRoom: (room: VoiceRoom | null) => void;
  roomMessages: RoomMessage[];
  setRoomMessages: React.Dispatch<React.SetStateAction<RoomMessage[]>>;
  isMobileFrame: boolean;
  setIsMobileFrame: (val: boolean) => void;
  gifts: Gift[];
  families: Family[];
  notification: string | null;
  showNotification: (msg: string) => void;
  switchDemoUser: (userId: string) => Promise<void>;
  refreshUser: () => Promise<void>;
  isSpeakingSimulator: boolean;
  setIsSpeakingSimulator: (val: boolean) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    try {
      const cached = localStorage.getItem('aura_cached_user');
      return cached ? JSON.parse(cached) : null;
    } catch (e) {
      return null;
    }
  });
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [isAuthLoading, setIsAuthLoading] = useState<boolean>(true);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [isSearchOpen, setIsSearchOpen] = useState<boolean>(false);
  const [searchInitialQuery, setSearchInitialQuery] = useState<string>('');

  const openUserSearch = (initialQuery?: string) => {
    if (initialQuery !== undefined) {
      setSearchInitialQuery(initialQuery);
    }
    setIsSearchOpen(true);
  };

  const [activeTab, setActiveTab] = useState<NavTab>('home');
  const [activeModal, setActiveModal] = useState<ModalType>('none');
  const [activeRoom, setActiveRoom] = useState<VoiceRoom | null>(null);
  const [roomMessages, setRoomMessages] = useState<RoomMessage[]>([]);
  const [isMobileFrame, setIsMobileFrame] = useState<boolean>(true); // Mobile First Android Style default
  const [gifts, setGifts] = useState<Gift[]>([]);
  const [families, setFamilies] = useState<Family[]>([]);
  const [notification, setNotification] = useState<string | null>(null);
  const [isSpeakingSimulator, setIsSpeakingSimulator] = useState<boolean>(true);

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => {
      setNotification(prev => (prev === msg ? null : prev));
    }, 4000);
  };

  const refreshUser = async () => {
    try {
      const activeId = currentUser?.id || localStorage.getItem('aura_demo_user_id') || '2383452';
      try {
        const snap = await getDoc(doc(db, 'users', activeId));
        if (snap.exists()) {
          const u = { ...(snap.data() as User), id: snap.id };
          setCurrentUser(prev => ({ ...(prev || {}), ...u }));
          localStorage.setItem('aura_cached_user', JSON.stringify(u));
        }
      } catch (fsErr) {}

      const u = await ApiClient.getMe();
      if (u) {
        setCurrentUser(prev => ({ ...(prev || {}), ...u }));
      }
      const fList = await ApiClient.getFamilies();
      if (fList) setFamilies(fList);
    } catch (err) {
      console.warn('Could not refresh user, retaining cached user state');
    }
  };

  const switchDemoUser = async (userId: string) => {
    localStorage.setItem('aura_demo_user_id', userId);
    try {
      const snap = await getDoc(doc(db, 'users', userId));
      if (snap.exists()) {
        const u = { ...(snap.data() as User), id: snap.id };
        setCurrentUser(u);
        localStorage.setItem('aura_cached_user', JSON.stringify(u));
      }
    } catch (fsErr) {}

    try {
      const res = await fetch(`${getApiBaseUrl()}/auth/me`, {
        headers: {
          'Content-Type': 'application/json',
          'X-Demo-User-Id': userId
        }
      });
      const json = await res.json();
      if (json.success && json.data) {
        setCurrentUser(prev => ({ ...(prev || {}), ...json.data }));
        showNotification(`Switched identity to: ${json.data.name} (${json.data.role.toUpperCase()})`);
      }
    } catch (e) {
      showNotification('Switched demo user profile');
    }
  };

  // Firebase Email/Password Sign-In
  const signInWithEmail = async (email: string, password: string): Promise<User> => {
    setIsAuthLoading(true);
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const fbUser = userCredential.user;
      setFirebaseUser(fbUser);

      // Load canonical profile directly from Firestore
      let userProfile = await fetchUserFromFirestore(fbUser.uid);
      if (!userProfile) {
        userProfile = await createRealFirestoreUserProfile(fbUser.uid, {
          name: fbUser.displayName || email.split('@')[0],
          email: fbUser.email || email,
          avatar: fbUser.photoURL || undefined
        });
      }

      // Sync with backend store and create session JWT
      const syncResult = await ApiClient.syncFirebaseAuth(
        fbUser.uid,
        fbUser.email || email,
        fbUser.displayName || userProfile.name,
        fbUser.photoURL || userProfile.avatar,
        userProfile
      );

      const finalUser: User = {
        ...userProfile,
        ...syncResult.user,
        id: fbUser.uid,
        uid: userProfile.uid || syncResult.user.uid,
        firebaseUid: fbUser.uid,
        nigoId: userProfile.uid || syncResult.user.uid,
        email: fbUser.email || email
      };

      setCurrentUser(finalUser);
      localStorage.setItem('aura_demo_user_id', fbUser.uid);
      localStorage.setItem('aura_cached_user', JSON.stringify(finalUser));

      showNotification(`Welcome back, ${finalUser.name}! ✨`);
      return finalUser;
    } catch (err: any) {
      // Fallback direct backend login check (for demo staff accounts like Elena Vance ceo@aura.com)
      try {
        const directLogin = await ApiClient.login(email, password);
        setCurrentUser(directLogin.user);
        showNotification(`Welcome, ${directLogin.user.name}!`);
        return directLogin.user;
      } catch (fallbackErr) {
        throw err;
      }
    } finally {
      setIsAuthLoading(false);
    }
  };

  // Firebase Email/Password Sign-Up (Real user registration)
  const signUpWithEmail = async (
    email: string, 
    password: string, 
    displayName: string,
    extra?: ExtraSignUpData
  ): Promise<User> => {
    setIsAuthLoading(true);
    try {
      // 1. Create real account in Firebase Authentication
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const fbUser = userCredential.user;

      if (displayName) {
        await fbUpdateProfile(fbUser, { displayName }).catch(err => console.warn('fbUpdateProfile notice:', err));
      }

      setFirebaseUser(fbUser);

      // 2. Create canonical Firestore User Profile with unique Nigo ID and default role "user"
      const firestoreProfile = await createRealFirestoreUserProfile(fbUser.uid, {
        name: displayName || email.split('@')[0],
        email: fbUser.email || email,
        phone: extra?.phone,
        country: extra?.country,
        countryFlag: extra?.countryFlag,
        gender: extra?.gender
      });

      // 3. Sync with backend database store and retrieve session tokens
      const syncResult = await ApiClient.syncFirebaseAuth(
        fbUser.uid,
        fbUser.email || email,
        displayName,
        fbUser.photoURL || undefined,
        firestoreProfile
      );

      const finalUser: User = {
        ...firestoreProfile,
        ...syncResult.user,
        id: fbUser.uid,
        uid: firestoreProfile.uid,
        firebaseUid: fbUser.uid,
        nigoId: firestoreProfile.uid,
        role: 'user'
      };

      setCurrentUser(finalUser);
      localStorage.setItem('aura_demo_user_id', fbUser.uid);
      localStorage.setItem('aura_cached_user', JSON.stringify(finalUser));

      showNotification(`Account created! Welcome to Aura Voice, ${finalUser.name}! (Nigo ID: ${finalUser.uid}) 🎉`);
      return finalUser;
    } finally {
      setIsAuthLoading(false);
    }
  };

  // Firebase Password Reset Email
  const sendResetPassword = async (email: string): Promise<void> => {
    setIsAuthLoading(true);
    try {
      await sendPasswordResetEmail(auth, email.trim());
      showNotification(`Password reset instructions sent to ${email}. Check your inbox! 📧`);
    } finally {
      setIsAuthLoading(false);
    }
  };

  // Firebase Google Sign-In
  const signInWithGoogle = async (): Promise<User> => {
    setIsAuthLoading(true);
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const fbUser = result.user;
      setFirebaseUser(fbUser);

      let userProfile = await fetchUserFromFirestore(fbUser.uid);
      if (!userProfile) {
        const userEmail = fbUser.email || `${fbUser.uid}@aura.com`;
        userProfile = await createRealFirestoreUserProfile(fbUser.uid, {
          name: fbUser.displayName || userEmail.split('@')[0] || 'Member',
          email: userEmail,
          avatar: fbUser.photoURL || undefined
        });
      }

      const syncResult = await ApiClient.syncFirebaseAuth(
        fbUser.uid,
        fbUser.email || `${fbUser.uid}@aura.com`,
        fbUser.displayName || undefined,
        fbUser.photoURL || undefined,
        userProfile
      );

      const finalUser: User = {
        ...userProfile,
        ...syncResult.user,
        id: fbUser.uid,
        uid: userProfile.uid || syncResult.user.uid,
        firebaseUid: fbUser.uid,
        nigoId: userProfile.uid || syncResult.user.uid
      };

      setCurrentUser(finalUser);
      localStorage.setItem('aura_demo_user_id', fbUser.uid);
      localStorage.setItem('aura_cached_user', JSON.stringify(finalUser));

      showNotification(`Signed in as ${finalUser.name}!`);
      return finalUser;
    } finally {
      setIsAuthLoading(false);
    }
  };

  // Firebase Sign-Out
  const signOut = async (): Promise<void> => {
    setIsAuthLoading(true);
    try {
      await fbSignOut(auth);
      setFirebaseUser(null);
      localStorage.removeItem('aura_access_token');
      // Set to demo guest user
      const guest = await ApiClient.getMe().catch(() => null);
      if (guest) setCurrentUser(guest);
      showNotification('Signed out successfully.');
    } catch (err: any) {
      showNotification('Signed out.');
    } finally {
      setIsAuthLoading(false);
    }
  };

  // Firebase Auth State Listener & Initialization
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      setIsAuthLoading(true);
      if (fbUser) {
        setFirebaseUser(fbUser);
        try {
          // Firestore is canonical source
          let fsUser = await fetchUserFromFirestore(fbUser.uid);
          if (!fsUser) {
            const userEmail = fbUser.email || `${fbUser.uid}@aura.com`;
            fsUser = await createRealFirestoreUserProfile(fbUser.uid, {
              name: fbUser.displayName || userEmail.split('@')[0] || 'Aura Member',
              email: userEmail,
              avatar: fbUser.photoURL || undefined
            });
          }

          const syncResult = await ApiClient.syncFirebaseAuth(
            fbUser.uid,
            fbUser.email || `${fbUser.uid}@aura.com`,
            fbUser.displayName || fsUser.name,
            fbUser.photoURL || fsUser.avatar,
            fsUser
          );

          const finalUser: User = {
            ...fsUser,
            ...syncResult.user,
            id: fbUser.uid,
            uid: fsUser.uid || syncResult.user.uid,
            firebaseUid: fbUser.uid,
            nigoId: fsUser.uid || syncResult.user.uid
          };

          setCurrentUser(finalUser);
          localStorage.setItem('aura_demo_user_id', fbUser.uid);
          localStorage.setItem('aura_cached_user', JSON.stringify(finalUser));
        } catch (err) {
          console.warn('Failed to sync Firebase Auth user to backend store:', err);
          const u = await ApiClient.getMe().catch(() => null);
          if (u) setCurrentUser(u);
        }
      } else {
        setFirebaseUser(null);
        // If no firebase session, retrieve from Firestore first, then fallback to API
        try {
          const activeId = localStorage.getItem('aura_demo_user_id') || '2383452';
          const snap = await getDoc(doc(db, 'users', activeId)).catch(() => null);
          if (snap && snap.exists()) {
            const fsUser = normalizeFirestoreUser(snap.id, snap.data());
            setCurrentUser(prev => ({ ...(prev || {}), ...fsUser }));
            localStorage.setItem('aura_cached_user', JSON.stringify(fsUser));
          } else {
            const u = await ApiClient.getMe();
            if (u) {
              setCurrentUser(prev => ({ ...(prev || {}), ...u }));
              localStorage.setItem('aura_cached_user', JSON.stringify(u));
            }
          }
        } catch (err) {
          console.error('Initialization error fetching user:', err);
        }
      }
      setIsAuthLoading(false);
    });

    // Load initial gifts & families
    const loadAppData = async () => {
      try {
        const [gList, fList] = await Promise.all([
          ApiClient.getGifts().catch(() => []),
          ApiClient.getFamilies().catch(() => [])
        ]);
        if (gList && gList.length > 0) setGifts(gList);
        if (fList && fList.length > 0) setFamilies(fList);
      } catch (err) {
        console.warn('Failed to preload gifts/families:', err);
      }
    };
    loadAppData();

    const handleFamiliesUpdated = () => {
      ApiClient.getFamilies().then(list => {
        if (list) setFamilies(list);
      }).catch(e => console.warn('Could not refresh families:', e));
    };
    window.addEventListener('families_updated', handleFamiliesUpdated);

    return () => {
      unsubscribe();
      window.removeEventListener('families_updated', handleFamiliesUpdated);
    };
  }, []);

  // Real-time Firestore sync for active user profile changes
  useEffect(() => {
    const activeDocId = currentUser?.id || localStorage.getItem('aura_demo_user_id') || '2383452';
    if (!activeDocId) return;

    try {
      const userDocRef = doc(db, 'users', activeDocId);
      const unsub = onSnapshot(userDocRef, (snap) => {
        if (snap.exists()) {
          const fsUser = normalizeFirestoreUser(snap.id, snap.data());
          // PROFILE SYNCHRONIZATION: Firestore is canonical source
          setCurrentUser(prev => {
            if (!prev) return fsUser;
            return {
              ...prev,
              ...fsUser
            };
          });
          try {
            localStorage.setItem('aura_cached_user', JSON.stringify(fsUser));
          } catch (e) {}
        }
      }, (err) => {
        if (err && err.code !== 'cancelled') {
          console.warn('Firestore active user doc listener notice:', err.message);
        }
      });

      return () => unsub();
    } catch (e) {
      return () => {};
    }
  }, [currentUser?.id, firebaseUser?.uid]);

  // Window event listener for profile updates dispatched from anywhere in the app
  useEffect(() => {
    const handleProfileUpdated = (e: any) => {
      if (e.detail) {
        setCurrentUser(prev => {
          const updated = prev ? { ...prev, ...e.detail } : e.detail;
          try {
            localStorage.setItem('aura_cached_user', JSON.stringify(updated));
          } catch (err) {}
          return updated;
        });
      }
    };
    window.addEventListener('user_profile_updated', handleProfileUpdated);
    return () => window.removeEventListener('user_profile_updated', handleProfileUpdated);
  }, []);

  // WebSocket / Live Room simulation loop
  useEffect(() => {
    if (!activeRoom) return;

    // Load initial room messages
    ApiClient.getRoomById(activeRoom.id).then(({ room, messages }) => {
      setActiveRoom(room);
      setRoomMessages(messages);
    }).catch(() => {});

    // Simulate live speaking and random chat
    const interval = setInterval(() => {
      if (!isSpeakingSimulator) return;

      setActiveRoom(prev => {
        if (!prev) return null;
        const newSeats = prev.seats.map(s => {
          if (s.userId && !s.isMuted) {
            return { ...s, isSpeaking: Math.random() > 0.4 };
          }
          return s;
        });
        return { ...prev, seats: newSeats };
      });

      // Occasionally add a demo chat message or gift notification
      if (Math.random() > 0.75 && activeRoom) {
        const sampleSenders = ['Marcus Aurelius', 'Kenji Sato', 'Sophia Taylor', 'Liam Vance', 'Chloe Wu'];
        const sampleTexts = [
          'This acoustic guitar sounds amazing! 🎶',
          'Welcome to the room everyone! Let us hit 10k likes 🔥',
          'Who wants to join seat #3 for PK battle?',
          'Good vibes only ✨ Sending hearts ❤️',
          'Just dropped a Lucky Bag! Quick grab it 🎁'
        ];
        const randomSender = sampleSenders[Math.floor(Math.random() * sampleSenders.length)];
        const randomText = sampleTexts[Math.floor(Math.random() * sampleTexts.length)];
        
        setRoomMessages(prevMsg => [
          ...prevMsg.slice(-40),
          {
            id: `sim-${Date.now()}`,
            roomId: activeRoom.id,
            userId: `sim-u-${Date.now()}`,
            userName: randomSender,
            userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
            type: randomText.includes('Lucky Bag') ? 'lucky_bag' : 'text',
            content: randomText,
            timestamp: new Date().toISOString()
          }
        ]);
      }
    }, 2500);

    return () => clearInterval(interval);
  }, [activeRoom?.id, isSpeakingSimulator]);

  return (
    <AppContext.Provider value={{
      currentUser,
      setCurrentUser,
      firebaseUser,
      isAuthLoading,
      isAuthModalOpen,
      setIsAuthModalOpen,
      isSearchOpen,
      setIsSearchOpen,
      searchInitialQuery,
      openUserSearch,
      signInWithEmail,
      signUpWithEmail,
      sendResetPassword,
      signInWithGoogle,
      signOut,
      activeTab,
      setActiveTab,
      activeModal,
      setActiveModal,
      activeRoom,
      setActiveRoom,
      roomMessages,
      setRoomMessages,
      isMobileFrame,
      setIsMobileFrame,
      gifts,
      families,
      notification,
      showNotification,
      switchDemoUser,
      refreshUser,
      isSpeakingSimulator,
      setIsSpeakingSimulator
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within an AppProvider');
  return context;
};

export const useAppOptional = () => {
  return useContext(AppContext);
};
