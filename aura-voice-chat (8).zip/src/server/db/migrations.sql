-- ============================================================================
-- Aura Voice Chat Platform - Production PostgreSQL Schema & Migrations
-- Version: 1.0.0
-- Description: Complete schema with constraints, indexes, foreign keys, and audit
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 1. USERS TABLE
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    uid VARCHAR(20) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    avatar TEXT NOT NULL,
    gender VARCHAR(10) DEFAULT 'other' CHECK (gender IN ('male', 'female', 'other')),
    country VARCHAR(100) DEFAULT 'Global',
    role VARCHAR(50) DEFAULT 'user' NOT NULL,
    coins BIGINT DEFAULT 10000 CHECK (coins >= 0),
    diamonds BIGINT DEFAULT 500 CHECK (diamonds >= 0),
    is_online BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_users_uid ON users(uid);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
CREATE INDEX IF NOT EXISTS idx_users_is_online ON users(is_online);

-- 2. USER PROFILES TABLE
CREATE TABLE IF NOT EXISTS user_profiles (
    user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    bio TEXT DEFAULT 'Welcome to my Aura voice room!',
    frame_id VARCHAR(100) NULL,
    background_id VARCHAR(100) NULL,
    vip_level VARCHAR(20) DEFAULT 'none' CHECK (vip_level IN ('none', 'vip', 'svip')),
    vip_expiry TIMESTAMPTZ NULL,
    level INTEGER DEFAULT 1 CHECK (level >= 1)
);
CREATE INDEX IF NOT EXISTS idx_user_profiles_vip_level ON user_profiles(vip_level);
CREATE INDEX IF NOT EXISTS idx_user_profiles_level ON user_profiles(level);

-- 3. STAFF & PERMISSIONS TABLE
CREATE TABLE IF NOT EXISTS staff (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role VARCHAR(50) NOT NULL CHECK (role IN ('ceo', 'gm', 'manager', 'super_admin', 'admin', 'bd', 'agency', 'host')),
    assigned_by UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'suspended')),
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_staff_user_id ON staff(user_id);
CREATE INDEX IF NOT EXISTS idx_staff_role ON staff(role);
CREATE INDEX IF NOT EXISTS idx_staff_status ON staff(status);

-- 4. PERMISSION TEMPLATES TABLE
CREATE TABLE IF NOT EXISTS permission_templates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    role VARCHAR(50) UNIQUE NOT NULL,
    permissions JSONB NOT NULL DEFAULT '[]'::jsonb,
    description TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 5. AUDIT LOGS TABLE
CREATE TABLE IF NOT EXISTS audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    action VARCHAR(255) NOT NULL,
    module VARCHAR(50) NOT NULL,
    performed_by_user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    performed_by_role VARCHAR(50) NOT NULL,
    target_id VARCHAR(255) NULL,
    details JSONB DEFAULT '{}'::jsonb,
    ip_address VARCHAR(45) NULL,
    timestamp TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_audit_logs_module ON audit_logs(module);
CREATE INDEX IF NOT EXISTS idx_audit_logs_performed_by ON audit_logs(performed_by_user_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_timestamp ON audit_logs(timestamp);

-- 6. VOICE ROOMS TABLE
CREATE TABLE IF NOT EXISTS voice_rooms (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title VARCHAR(150) NOT NULL,
    topic VARCHAR(255) NOT NULL,
    category VARCHAR(50) DEFAULT 'popular' CHECK (category IN ('popular', 'new', 'country', 'family', 'game', 'music')),
    host_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    country VARCHAR(100) DEFAULT 'Global',
    max_seats INTEGER DEFAULT 9 CHECK (max_seats BETWEEN 1 AND 20),
    is_locked BOOLEAN DEFAULT false,
    password_hash VARCHAR(255) NULL,
    announcement TEXT NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_voice_rooms_category ON voice_rooms(category);
CREATE INDEX IF NOT EXISTS idx_voice_rooms_host_id ON voice_rooms(host_id);
CREATE INDEX IF NOT EXISTS idx_voice_rooms_country ON voice_rooms(country);

-- 7. ROOM MEMBERS TABLE
CREATE TABLE IF NOT EXISTS room_members (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    room_id UUID NOT NULL REFERENCES voice_rooms(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    seat_index INTEGER NULL CHECK (seat_index BETWEEN 0 AND 19),
    is_muted BOOLEAN DEFAULT false,
    is_speaking BOOLEAN DEFAULT false,
    joined_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(room_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_room_members_room_id ON room_members(room_id);

-- 8. ROOM MESSAGES TABLE
CREATE TABLE IF NOT EXISTS room_messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    room_id UUID NOT NULL REFERENCES voice_rooms(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type VARCHAR(50) NOT NULL CHECK (type IN ('text', 'gift', 'system', 'join', 'emoji', 'lucky_bag')),
    content TEXT NOT NULL,
    metadata JSONB DEFAULT '{}'::jsonb,
    timestamp TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_room_messages_room_id_time ON room_messages(room_id, timestamp DESC);

-- 9. PRIVATE MESSAGES TABLE
CREATE TABLE IF NOT EXISTS private_messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sender_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    receiver_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type VARCHAR(50) DEFAULT 'text' CHECK (type IN ('text', 'image', 'voice', 'gift')),
    content TEXT NOT NULL,
    read BOOLEAN DEFAULT false,
    timestamp TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_private_messages_sender_receiver ON private_messages(sender_id, receiver_id);

-- 10. FAMILIES TABLE
CREATE TABLE IF NOT EXISTS families (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) NOT NULL UNIQUE,
    slogan VARCHAR(255) NOT NULL,
    leader_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    level INTEGER DEFAULT 1 CHECK (level >= 1),
    total_contribution BIGINT DEFAULT 0 CHECK (total_contribution >= 0),
    ranking INTEGER DEFAULT 999,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_families_ranking ON families(ranking);
CREATE INDEX IF NOT EXISTS idx_families_leader_id ON families(leader_id);

-- 11. GIFTS TABLE
CREATE TABLE IF NOT EXISTS gifts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) NOT NULL UNIQUE,
    icon TEXT NOT NULL,
    price_coins INTEGER NOT NULL CHECK (price_coins > 0),
    category VARCHAR(50) DEFAULT 'popular',
    animation_type VARCHAR(50) DEFAULT 'pop',
    svg_color VARCHAR(20) DEFAULT '#a855f7'
);
CREATE INDEX IF NOT EXISTS idx_gifts_category ON gifts(category);
CREATE INDEX IF NOT EXISTS idx_gifts_price ON gifts(price_coins);

-- 12. WALLET TRANSACTIONS TABLE
CREATE TABLE IF NOT EXISTS wallet_transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type VARCHAR(50) NOT NULL,
    currency VARCHAR(20) NOT NULL CHECK (currency IN ('coin', 'diamond')),
    amount BIGINT NOT NULL,
    balance_after BIGINT NOT NULL,
    description TEXT NOT NULL,
    status VARCHAR(20) DEFAULT 'completed' CHECK (status IN ('completed', 'pending', 'rejected')),
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_wallet_tx_user_id ON wallet_transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_wallet_tx_type ON wallet_transactions(type);

-- 13. LUCKY BAGS TABLE
CREATE TABLE IF NOT EXISTS lucky_bags (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    room_id UUID NOT NULL REFERENCES voice_rooms(id) ON DELETE CASCADE,
    sender_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    total_coins INTEGER NOT NULL CHECK (total_coins > 0),
    remaining_coins INTEGER NOT NULL CHECK (remaining_coins >= 0),
    total_winners INTEGER NOT NULL CHECK (total_winners > 0),
    claimed_count INTEGER DEFAULT 0 CHECK (claimed_count <= total_winners),
    status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'expired', 'depleted')),
    expires_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_lucky_bags_room_id ON lucky_bags(room_id);

-- 14. PK BATTLES TABLE
CREATE TABLE IF NOT EXISTS pk_battles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    room_a_id UUID NOT NULL REFERENCES voice_rooms(id) ON DELETE CASCADE,
    room_b_id UUID NOT NULL REFERENCES voice_rooms(id) ON DELETE CASCADE,
    room_a_score INTEGER DEFAULT 0 CHECK (room_a_score >= 0),
    room_b_score INTEGER DEFAULT 0 CHECK (room_b_score >= 0),
    duration_seconds INTEGER DEFAULT 300,
    status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('matching', 'active', 'finished')),
    winner_room_id UUID NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_pk_battles_status ON pk_battles(status);

-- 15. DAILY SPINS TABLE
CREATE TABLE IF NOT EXISTS daily_spins (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    reward_type VARCHAR(50) NOT NULL,
    reward_value INTEGER NOT NULL,
    spun_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_daily_spins_user_id ON daily_spins(user_id);

-- 16. REFERRAL SYSTEM TABLE
CREATE TABLE IF NOT EXISTS referral_system (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    referrer_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    referred_user_id UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    bonus_coins INTEGER DEFAULT 500,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 17. BADGES & MEDALS TABLES
CREATE TABLE IF NOT EXISTS badges (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) UNIQUE NOT NULL,
    icon TEXT NOT NULL,
    description TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS medals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) UNIQUE NOT NULL,
    icon TEXT NOT NULL,
    level INTEGER DEFAULT 1,
    color VARCHAR(20) DEFAULT '#f59e0b'
);

-- END OF MIGRATION SCRIPT
