/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Production PostgreSQL Schema Definitions & Table Names
export const TABLE_NAMES = {
  USERS: 'users',
  USER_PROFILES: 'user_profiles',
  STAFF: 'staff',
  STAFF_PERMISSIONS: 'staff_permissions',
  PERMISSION_TEMPLATES: 'permission_templates',
  AUDIT_LOGS: 'audit_logs',
  LOGIN_HISTORY: 'login_history',
  DEVICES: 'devices',
  VOICE_ROOMS: 'voice_rooms',
  ROOM_MEMBERS: 'room_members',
  ROOM_MESSAGES: 'room_messages',
  PRIVATE_MESSAGES: 'private_messages',
  FAMILIES: 'families',
  FAMILY_MEMBERS: 'family_members',
  FAMILY_CHAT: 'family_chat',
  FAMILY_CONTRIBUTIONS: 'family_contributions',
  AGENCIES: 'agencies',
  HOSTS: 'hosts',
  BD: 'bd',
  RECHARGE_REQUESTS: 'recharge_requests',
  WITHDRAWAL_REQUESTS: 'withdrawal_requests',
  WALLET_TRANSACTIONS: 'wallet_transactions',
  COIN_TRANSACTIONS: 'coin_transactions',
  DIAMOND_TRANSACTIONS: 'diamond_transactions',
  GIFTS: 'gifts',
  GIFT_HISTORY: 'gift_history',
  LUCKY_BAGS: 'lucky_bags',
  LUCKY_BAG_CLAIMS: 'lucky_bag_claims',
  DAILY_SPINS: 'daily_spins',
  REFERRAL_SYSTEM: 'referral_system',
  PK_BATTLES: 'pk_battles',
  VIP: 'vip',
  SVIP: 'svip',
  BADGES: 'badges',
  MEDALS: 'medals',
  NOTIFICATIONS: 'notifications',
  VISITOR_HISTORY: 'visitor_history',
  GIFT_WALL: 'gift_wall',
  ALBUMS: 'albums',
  REPORTS: 'reports',
  EVENTS: 'events',
  SETTINGS: 'settings',
  ADMIN_LOGS: 'admin_logs',
  STAFF_ACTIVITY_LOGS: 'staff_activity_logs',
  COUNTRIES: 'countries'
} as const;

export interface PgTableMetadata {
  tableName: string;
  columns: { name: string; type: string; constraints?: string }[];
  indexes: string[];
  foreignKeys: { column: string; targetTable: string; targetColumn: string; onDelete: string }[];
}

export const POSTGRES_TABLES_METADATA: PgTableMetadata[] = [
  {
    tableName: TABLE_NAMES.USERS,
    columns: [
      { name: 'id', type: 'UUID', constraints: 'PRIMARY KEY DEFAULT gen_random_uuid()' },
      { name: 'uid', type: 'VARCHAR(20)', constraints: 'UNIQUE NOT NULL' },
      { name: 'email', type: 'VARCHAR(255)', constraints: 'UNIQUE NOT NULL' },
      { name: 'name', type: 'VARCHAR(100)', constraints: 'NOT NULL' },
      { name: 'avatar', type: 'TEXT', constraints: 'NOT NULL' },
      { name: 'gender', type: 'VARCHAR(10)', constraints: "DEFAULT 'other' CHECK (gender IN ('male', 'female', 'other'))" },
      { name: 'country', type: 'VARCHAR(100)', constraints: "DEFAULT 'Global'" },
      { name: 'role', type: 'VARCHAR(50)', constraints: "DEFAULT 'user' NOT NULL" },
      { name: 'coins', type: 'BIGINT', constraints: 'DEFAULT 0 CHECK (coins >= 0)' },
      { name: 'diamonds', type: 'BIGINT', constraints: 'DEFAULT 0 CHECK (diamonds >= 0)' },
      { name: 'is_online', type: 'BOOLEAN', constraints: 'DEFAULT false' },
      { name: 'created_at', type: 'TIMESTAMPTZ', constraints: 'DEFAULT CURRENT_TIMESTAMP' },
      { name: 'updated_at', type: 'TIMESTAMPTZ', constraints: 'DEFAULT CURRENT_TIMESTAMP' }
    ],
    indexes: ['idx_users_uid', 'idx_users_email', 'idx_users_role', 'idx_users_is_online'],
    foreignKeys: []
  },
  {
    tableName: TABLE_NAMES.USER_PROFILES,
    columns: [
      { name: 'user_id', type: 'UUID', constraints: 'PRIMARY KEY' },
      { name: 'bio', type: 'TEXT', constraints: 'DEFAULT \'Welcome to my Aura voice room!\'' },
      { name: 'frame_id', type: 'VARCHAR(100)', constraints: 'NULL' },
      { name: 'background_id', type: 'VARCHAR(100)', constraints: 'NULL' },
      { name: 'vip_level', type: 'VARCHAR(20)', constraints: "DEFAULT 'none' CHECK (vip_level IN ('none', 'vip', 'svip'))" },
      { name: 'vip_expiry', type: 'TIMESTAMPTZ', constraints: 'NULL' },
      { name: 'level', type: 'INTEGER', constraints: 'DEFAULT 1 CHECK (level >= 1)' }
    ],
    indexes: ['idx_user_profiles_vip_level', 'idx_user_profiles_level'],
    foreignKeys: [{ column: 'user_id', targetTable: TABLE_NAMES.USERS, targetColumn: 'id', onDelete: 'CASCADE' }]
  },
  {
    tableName: TABLE_NAMES.STAFF,
    columns: [
      { name: 'id', type: 'UUID', constraints: 'PRIMARY KEY DEFAULT gen_random_uuid()' },
      { name: 'user_id', type: 'UUID', constraints: 'UNIQUE NOT NULL' },
      { name: 'role', type: 'VARCHAR(50)', constraints: "NOT NULL CHECK (role IN ('ceo', 'gm', 'manager', 'super_admin', 'admin', 'bd', 'agency', 'host'))" },
      { name: 'assigned_by', type: 'UUID', constraints: 'NOT NULL' },
      { name: 'status', type: 'VARCHAR(20)', constraints: "DEFAULT 'active' CHECK (status IN ('active', 'suspended'))" },
      { name: 'created_at', type: 'TIMESTAMPTZ', constraints: 'DEFAULT CURRENT_TIMESTAMP' }
    ],
    indexes: ['idx_staff_user_id', 'idx_staff_role', 'idx_staff_status'],
    foreignKeys: [
      { column: 'user_id', targetTable: TABLE_NAMES.USERS, targetColumn: 'id', onDelete: 'CASCADE' },
      { column: 'assigned_by', targetTable: TABLE_NAMES.USERS, targetColumn: 'id', onDelete: 'RESTRICT' }
    ]
  },
  {
    tableName: TABLE_NAMES.AUDIT_LOGS,
    columns: [
      { name: 'id', type: 'UUID', constraints: 'PRIMARY KEY DEFAULT gen_random_uuid()' },
      { name: 'action', type: 'VARCHAR(255)', constraints: 'NOT NULL' },
      { name: 'module', type: 'VARCHAR(50)', constraints: 'NOT NULL' },
      { name: 'performed_by_user_id', type: 'UUID', constraints: 'NOT NULL' },
      { name: 'performed_by_role', type: 'VARCHAR(50)', constraints: 'NOT NULL' },
      { name: 'target_id', type: 'VARCHAR(255)', constraints: 'NULL' },
      { name: 'details', type: 'JSONB', constraints: 'DEFAULT \'{}\'::jsonb' },
      { name: 'ip_address', type: 'VARCHAR(45)', constraints: 'NULL' },
      { name: 'timestamp', type: 'TIMESTAMPTZ', constraints: 'DEFAULT CURRENT_TIMESTAMP' }
    ],
    indexes: ['idx_audit_logs_module', 'idx_audit_logs_performed_by', 'idx_audit_logs_timestamp'],
    foreignKeys: [{ column: 'performed_by_user_id', targetTable: TABLE_NAMES.USERS, targetColumn: 'id', onDelete: 'CASCADE' }]
  },
  {
    tableName: TABLE_NAMES.VOICE_ROOMS,
    columns: [
      { name: 'id', type: 'UUID', constraints: 'PRIMARY KEY DEFAULT gen_random_uuid()' },
      { name: 'title', type: 'VARCHAR(150)', constraints: 'NOT NULL' },
      { name: 'topic', type: 'VARCHAR(255)', constraints: 'NOT NULL' },
      { name: 'category', type: 'VARCHAR(50)', constraints: "DEFAULT 'popular' CHECK (category IN ('popular', 'new', 'country', 'family', 'game', 'music'))" },
      { name: 'host_id', type: 'UUID', constraints: 'NOT NULL' },
      { name: 'country', type: 'VARCHAR(100)', constraints: "DEFAULT 'Global'" },
      { name: 'max_seats', type: 'INTEGER', constraints: 'DEFAULT 9 CHECK (max_seats BETWEEN 1 AND 20)' },
      { name: 'is_locked', type: 'BOOLEAN', constraints: 'DEFAULT false' },
      { name: 'password_hash', type: 'VARCHAR(255)', constraints: 'NULL' },
      { name: 'announcement', type: 'TEXT', constraints: 'NULL' },
      { name: 'created_at', type: 'TIMESTAMPTZ', constraints: 'DEFAULT CURRENT_TIMESTAMP' }
    ],
    indexes: ['idx_voice_rooms_category', 'idx_voice_rooms_host_id', 'idx_voice_rooms_country'],
    foreignKeys: [{ column: 'host_id', targetTable: TABLE_NAMES.USERS, targetColumn: 'id', onDelete: 'CASCADE' }]
  },
  {
    tableName: TABLE_NAMES.WALLET_TRANSACTIONS,
    columns: [
      { name: 'id', type: 'UUID', constraints: 'PRIMARY KEY DEFAULT gen_random_uuid()' },
      { name: 'user_id', type: 'UUID', constraints: 'NOT NULL' },
      { name: 'type', type: 'VARCHAR(50)', constraints: 'NOT NULL' },
      { name: 'currency', type: 'VARCHAR(20)', constraints: "NOT NULL CHECK (currency IN ('coin', 'diamond'))" },
      { name: 'amount', type: 'BIGINT', constraints: 'NOT NULL' },
      { name: 'balance_after', type: 'BIGINT', constraints: 'NOT NULL' },
      { name: 'description', type: 'TEXT', constraints: 'NOT NULL' },
      { name: 'status', type: 'VARCHAR(20)', constraints: "DEFAULT 'completed' CHECK (status IN ('completed', 'pending', 'rejected'))" },
      { name: 'created_at', type: 'TIMESTAMPTZ', constraints: 'DEFAULT CURRENT_TIMESTAMP' }
    ],
    indexes: ['idx_wallet_tx_user_id', 'idx_wallet_tx_type', 'idx_wallet_tx_created_at'],
    foreignKeys: [{ column: 'user_id', targetTable: TABLE_NAMES.USERS, targetColumn: 'id', onDelete: 'CASCADE' }]
  },
  {
    tableName: TABLE_NAMES.GIFTS,
    columns: [
      { name: 'id', type: 'UUID', constraints: 'PRIMARY KEY DEFAULT gen_random_uuid()' },
      { name: 'name', type: 'VARCHAR(100)', constraints: 'NOT NULL UNIQUE' },
      { name: 'icon', type: 'TEXT', constraints: 'NOT NULL' },
      { name: 'price_coins', type: 'INTEGER', constraints: 'NOT NULL CHECK (price_coins > 0)' },
      { name: 'category', type: 'VARCHAR(50)', constraints: "DEFAULT 'popular'" },
      { name: 'animation_type', type: 'VARCHAR(50)', constraints: "DEFAULT 'pop'" },
      { name: 'svg_color', type: 'VARCHAR(20)', constraints: "DEFAULT '#a855f7'" }
    ],
    indexes: ['idx_gifts_category', 'idx_gifts_price'],
    foreignKeys: []
  },
  {
    tableName: TABLE_NAMES.LUCKY_BAGS,
    columns: [
      { name: 'id', type: 'UUID', constraints: 'PRIMARY KEY DEFAULT gen_random_uuid()' },
      { name: 'room_id', type: 'UUID', constraints: 'NOT NULL' },
      { name: 'sender_id', type: 'UUID', constraints: 'NOT NULL' },
      { name: 'total_coins', type: 'INTEGER', constraints: 'NOT NULL CHECK (total_coins > 0)' },
      { name: 'remaining_coins', type: 'INTEGER', constraints: 'NOT NULL CHECK (remaining_coins >= 0)' },
      { name: 'total_winners', type: 'INTEGER', constraints: 'NOT NULL CHECK (total_winners > 0)' },
      { name: 'claimed_count', type: 'INTEGER', constraints: 'DEFAULT 0 CHECK (claimed_count <= total_winners)' },
      { name: 'status', type: 'VARCHAR(20)', constraints: "DEFAULT 'active' CHECK (status IN ('active', 'expired', 'depleted'))" },
      { name: 'expires_at', type: 'TIMESTAMPTZ', constraints: 'NOT NULL' },
      { name: 'created_at', type: 'TIMESTAMPTZ', constraints: 'DEFAULT CURRENT_TIMESTAMP' }
    ],
    indexes: ['idx_lucky_bags_room_id', 'idx_lucky_bags_status'],
    foreignKeys: [
      { column: 'room_id', targetTable: TABLE_NAMES.VOICE_ROOMS, targetColumn: 'id', onDelete: 'CASCADE' },
      { column: 'sender_id', targetTable: TABLE_NAMES.USERS, targetColumn: 'id', onDelete: 'CASCADE' }
    ]
  },
  {
    tableName: TABLE_NAMES.PK_BATTLES,
    columns: [
      { name: 'id', type: 'UUID', constraints: 'PRIMARY KEY DEFAULT gen_random_uuid()' },
      { name: 'room_a_id', type: 'UUID', constraints: 'NOT NULL' },
      { name: 'room_b_id', type: 'UUID', constraints: 'NOT NULL' },
      { name: 'room_a_score', type: 'INTEGER', constraints: 'DEFAULT 0 CHECK (room_a_score >= 0)' },
      { name: 'room_b_score', type: 'INTEGER', constraints: 'DEFAULT 0 CHECK (room_b_score >= 0)' },
      { name: 'duration_seconds', type: 'INTEGER', constraints: 'DEFAULT 300' },
      { name: 'status', type: 'VARCHAR(20)', constraints: "DEFAULT 'active' CHECK (status IN ('matching', 'active', 'finished'))" },
      { name: 'winner_room_id', type: 'UUID', constraints: 'NULL' },
      { name: 'created_at', type: 'TIMESTAMPTZ', constraints: 'DEFAULT CURRENT_TIMESTAMP' }
    ],
    indexes: ['idx_pk_battles_status', 'idx_pk_battles_room_a', 'idx_pk_battles_room_b'],
    foreignKeys: [
      { column: 'room_a_id', targetTable: TABLE_NAMES.VOICE_ROOMS, targetColumn: 'id', onDelete: 'CASCADE' },
      { column: 'room_b_id', targetTable: TABLE_NAMES.VOICE_ROOMS, targetColumn: 'id', onDelete: 'CASCADE' }
    ]
  },
  {
    tableName: TABLE_NAMES.FAMILIES,
    columns: [
      { name: 'id', type: 'UUID', constraints: 'PRIMARY KEY DEFAULT gen_random_uuid()' },
      { name: 'name', type: 'VARCHAR(100)', constraints: 'NOT NULL UNIQUE' },
      { name: 'slogan', type: 'VARCHAR(255)', constraints: 'NOT NULL' },
      { name: 'leader_id', type: 'UUID', constraints: 'NOT NULL' },
      { name: 'level', type: 'INTEGER', constraints: 'DEFAULT 1 CHECK (level >= 1)' },
      { name: 'total_contribution', type: 'BIGINT', constraints: 'DEFAULT 0 CHECK (total_contribution >= 0)' },
      { name: 'ranking', type: 'INTEGER', constraints: 'DEFAULT 999' },
      { name: 'created_at', type: 'TIMESTAMPTZ', constraints: 'DEFAULT CURRENT_TIMESTAMP' }
    ],
    indexes: ['idx_families_ranking', 'idx_families_leader_id', 'idx_families_level'],
    foreignKeys: [{ column: 'leader_id', targetTable: TABLE_NAMES.USERS, targetColumn: 'id', onDelete: 'RESTRICT' }]
  }
];
