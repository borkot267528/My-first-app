/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { 
  User, VoiceRoom, Gift, Family, FamilyMember, FamilyApplication, WalletTransaction, 
  AuditLog, StaffMember, LuckyBag, PkBattle, DailySpinReward,
  RoomMessage, PrivateMessage, UserRole, StaffActivityLog,
  NotificationItem, ReportItem, RechargePackage, Banner, BenefitAssignmentRecord,
  Agency, RechargeAgent, Merchant, WithdrawPaymentMethod, BanRecord, Country,
  AdminAppearanceSettings,
  PermissionModule, SystemPermission, RolePermissionConfig, StaffPermissionOverride,
  Connection, ConnectionRequest, BlockedUserRecord, ConnectionSystemConfig,
  UserGiftInventoryItem
} from '../../types';
import { 
  DEFAULT_RBAC_MODULES, 
  DEFAULT_RBAC_PERMISSIONS, 
  DEFAULT_ROLE_CONFIGS 
} from '../../lib/rbacDefaults';
import process from 'node:process';

class CountryStoreMap extends Map<string, Country> {
  override get(key: string): Country | undefined {
    if (!key) return undefined;
    if (super.has(key)) return super.get(key);
    const upper = key.trim().toUpperCase();
    const lower = key.trim().toLowerCase();
    for (const c of super.values()) {
      if (
        c.id === key ||
        c.id.toLowerCase() === lower ||
        (c.iso2 && c.iso2.toUpperCase() === upper) ||
        (c.iso3 && c.iso3.toUpperCase() === upper) ||
        (c.countryCode && c.countryCode.toUpperCase() === upper) ||
        (c.name && c.name.toLowerCase() === lower)
      ) {
        return c;
      }
    }
    return undefined;
  }
}

class UserStoreMap extends Map<string, User> {
  override set(key: string, value: User): this {
    const canonicalId = value?.id || key;
    // Remove any previous keys pointing to this same user ID or UID to prevent duplicates in the map
    for (const [k, u] of super.entries()) {
      if (k !== canonicalId && (u.id === canonicalId || (value.uid && u.uid === value.uid))) {
        super.delete(k);
      }
    }
    return super.set(canonicalId, value);
  }

  override get(key: string): User | undefined {
    if (!key) return undefined;
    if (super.has(key)) return super.get(key);
    if (key === 'usr-001' || key === 'usr-ceo' || key === 'usr-2383452' || key === '8829104') {
      return super.get('2383452');
    }
    if (key === 'usr-002') return super.get('8829105');
    if (key === 'usr-003') return super.get('8829106');
    if (key === 'usr-004') return super.get('8829107');
    if (key === 'usr-005') return super.get('8829108');
    // Lookup by uid, id, email, or firebaseUid
    const trimmed = key.trim().toLowerCase();
    for (const u of super.values()) {
      if (
        u.id === key.trim() || 
        u.uid === key.trim() || 
        (u.email && u.email.toLowerCase() === trimmed) || 
        ((u as any).firebaseUid && (u as any).firebaseUid === key.trim())
      ) {
        return u;
      }
    }
    return undefined;
  }

  override values(): IterableIterator<User> {
    const seen = new Set<string>();
    const unique: User[] = [];
    for (const u of super.values()) {
      if (u && u.id && !seen.has(u.id)) {
        seen.add(u.id);
        unique.push(u);
      }
    }
    return unique.values();
  }
}

class StaffStoreMap extends Map<string, StaffMember> {
  override get(key: string): StaffMember | undefined {
    if (!key) return undefined;
    if (super.has(key)) return super.get(key);
    if (key === 'stf-ceo' || key === 'stf-2383452' || key === '2383452' || key === 'usr-001') {
      return super.get('stf-1');
    }
    const trimmed = key.trim().toLowerCase();
    for (const s of super.values()) {
      if (s.userId === key.trim() || (s.email && s.email.toLowerCase() === trimmed)) {
        return s;
      }
    }
    return undefined;
  }
}

class RoomStoreMap extends Map<string, VoiceRoom> {
  override get(key: string): VoiceRoom | undefined {
    if (!key) return undefined;
    if (super.has(key)) return super.get(key);
    const clean = String(key).replace(/^room-/, '');
    if (super.has(clean)) return super.get(clean);
    if (super.has(`room-${clean}`)) return super.get(`room-${clean}`);
    for (const r of super.values()) {
      if (
        r.id === key || 
        r.id === clean || 
        r.id === `room-${clean}` || 
        (r as any).hostUid === key || 
        (r as any).hostUid === clean || 
        r.hostId === key || 
        r.hostId === clean
      ) {
        return r;
      }
    }
    return undefined;
  }
}

class MemoryStore {
  public users: UserStoreMap = new UserStoreMap();
  public rooms: RoomStoreMap = new RoomStoreMap();
  public gifts: Map<string, Gift> = new Map();
  public userGiftInventories: Map<string, Map<string, UserGiftInventoryItem>> = new Map();
  public families: Map<string, Family> = new Map();
  public familyMembers: Map<string, FamilyMember> = new Map();
  public familyApplications: Map<string, FamilyApplication> = new Map();
  public transactions: Map<string, WalletTransaction> = new Map();
  public auditLogs: Map<string, AuditLog> = new Map();
  public staff: StaffStoreMap = new StaffStoreMap();
  public luckyBags: Map<string, LuckyBag> = new Map();
  public pkBattles: Map<string, PkBattle> = new Map();
  public roomMessages: Map<string, RoomMessage[]> = new Map();
  public privateMessages: Map<string, PrivateMessage[]> = new Map();
  public spinRewards: DailySpinReward[] = [];
  public staffActivityLogs: Map<string, StaffActivityLog> = new Map();
  public notifications: Map<string, NotificationItem[]> = new Map();
  public reports: Map<string, ReportItem> = new Map();
  public rechargePackages: RechargePackage[] = [];
  public banners: Map<string, Banner> = new Map();
  public benefitAssignments: Map<string, BenefitAssignmentRecord> = new Map();
  public agencies: Map<string, Agency> = new Map();
  public rechargeAgents: Map<string, RechargeAgent> = new Map();
  public merchants: Map<string, Merchant> = new Map();
  public withdrawPaymentMethods: Map<string, WithdrawPaymentMethod> = new Map();
  public banHistory: Map<string, BanRecord> = new Map();
  public uploadedFiles: Map<string, { id: string; name: string; contentType: string; data: string; size: number; createdAt: string; module?: string; uploadedBy?: string }> = new Map();
  public countries: CountryStoreMap = new CountryStoreMap();
  public rbacModules: Map<string, PermissionModule> = new Map();
  public rbacPermissions: Map<string, SystemPermission> = new Map();
  public rbacRoles: Map<string, RolePermissionConfig> = new Map();
  public rbacStaffOverrides: Map<string, StaffPermissionOverride> = new Map();
  public connections: Map<string, Connection> = new Map();
  public connectionRequests: Map<string, ConnectionRequest> = new Map();
  public blockedUsers: Map<string, BlockedUserRecord> = new Map();
  public adminAppearance: AdminAppearanceSettings = {
    backgroundColor: '#0c0618',
    updatedAt: '2025-01-01T00:00:00.000Z',
    updatedBy: '2383452',
    updatedByName: 'Elena Vance (CEO)',
    updatedByRole: 'ceo'
  };
  public connectionConfig: ConnectionSystemConfig = {
    minUserLevelForCp: 1,
    initialIntimacyPoints: 100,
    giftIntimacyPercent: 10,
    giftIntimacyBasePerGift: 10,
    maxFriendsLimit: 500,
    autoApproveVipCp: false,
    allowSameGenderCp: true,
    updatedAt: new Date().toISOString(),
    updatedBy: 'System'
  };

  constructor() {
    this.seedData();
    this.ensureDefaultCeoExists();
    this.syncWithFirestore().catch(() => {});
  }

  private firestoreInstance: any = null;

  public async getFirestoreDb() {
    if (this.firestoreInstance) return this.firestoreInstance;
    try {
      const fs = await import('node:fs');
      const path = await import('node:path');
      const nodeProcess = await import('node:process');

      const cwd = (typeof nodeProcess.default?.cwd === 'function' ? nodeProcess.default.cwd() : null)
        || (typeof nodeProcess.cwd === 'function' ? nodeProcess.cwd() : null)
        || (typeof process !== 'undefined' && typeof process.cwd === 'function' ? process.cwd() : null)
        || '.';

      const possiblePaths = [
        path.resolve(cwd, 'firebase-applet-config.json'),
        path.resolve('.', 'firebase-applet-config.json'),
        path.join(cwd, 'firebase-applet-config.json'),
        '/app/applet/firebase-applet-config.json'
      ];

      const configPath = possiblePaths.find(p => fs.existsSync(p));
      if (!configPath) return null;
      const cfg = JSON.parse(fs.readFileSync(configPath, 'utf8'));
      if (!cfg || !cfg.projectId) return null;

      const { initializeApp, getApps } = await import('firebase/app');
      const { getFirestore, setLogLevel } = await import('firebase/firestore/lite');
      try {
        setLogLevel('silent');
      } catch (e) {}
      const existing = getApps().find(a => a.name === 'aura-server-backend');
      const app = existing || initializeApp(cfg, 'aura-server-backend');
      this.firestoreInstance = getFirestore(app, cfg.firestoreDatabaseId);
      return this.firestoreInstance;
    } catch (e: any) {
      console.warn('[Backend Store] Firestore init notice:', e?.message || e);
      return null;
    }
  }

  public async syncWithFirestore() {
    try {
      const db = await this.getFirestoreDb();
      if (!db) return;

      const { collection, getDocs, doc, getDoc } = await import('firebase/firestore/lite');

      // 1. Sync users collection from Firestore
      try {
        const snap = await getDocs(collection(db, 'users'));
        snap.forEach(d => {
          const data = d.data() as User;
          const isCeo = data.id === '2383452' || data.uid === '2383452' || (data.email && data.email.toLowerCase() === 'imoborkot@gmail.com');
          const userId = isCeo ? '2383452' : (data.id || d.id);
          const existing = this.users.get(userId);
          if (existing) {
            Object.assign(existing, data, { id: userId });
          } else {
            this.users.set(userId, { ...data, id: userId });
          }
          if (isCeo) {
            const ceoStaff = this.staff.get('stf-1');
            if (ceoStaff) {
              ceoStaff.name = data.name;
              if (data.email) ceoStaff.email = data.email;
            }
          }
        });
        if (snap.size > 0) {
          console.log(`[Backend Store] Synced ${snap.size} users from Firestore.`);
        }
      } catch (userErr: any) {
        console.warn('[Backend Store] Firestore user sync notice:', userErr?.message || userErr);
      }

      // 2. Sync countries collection from Firestore (if customized in DB)
      try {
        const countrySnap = await getDocs(collection(db, 'countries'));
        if (countrySnap.size > 0) {
          countrySnap.forEach(d => {
            const cData = d.data() as Country;
            const cid = cData.id || d.id;
            this.countries.set(cid, { ...cData, id: cid });
          });
          console.log(`[Backend Store] Synced ${countrySnap.size} countries from Firestore.`);
        }
      } catch (countryErr: any) {
        console.warn('[Backend Store] Firestore countries sync notice:', countryErr?.message || countryErr);
      }

      // 3. Sync adminSettings (appearance) from Firestore
      try {
        const appearanceSnap = await getDoc(doc(db, 'adminSettings', 'appearance')).catch(() => null);
        if (appearanceSnap && appearanceSnap.exists()) {
          const appData = appearanceSnap.data() as AdminAppearanceSettings;
          if (appData && appData.backgroundColor) {
            this.adminAppearance = appData;
            console.log(`[Backend Store] Synced admin appearance settings from Firestore: ${appData.backgroundColor}`);
          }
        }
      } catch (appErr: any) {
        console.warn('[Backend Store] Firestore appearance check notice:', appErr?.message || appErr);
      }

      // 4. Sync adminSettings (connectionConfig) from Firestore
      try {
        const connCfgSnap = await getDoc(doc(db, 'adminSettings', 'connectionConfig')).catch(() => null);
        if (connCfgSnap && connCfgSnap.exists()) {
          const cfgData = connCfgSnap.data() as ConnectionSystemConfig;
          if (cfgData) {
            this.connectionConfig = { ...this.connectionConfig, ...cfgData };
            console.log(`[Backend Store] Synced connection config from Firestore.`);
          }
        }
      } catch (connCfgErr: any) {
        console.warn('[Backend Store] Firestore connection config check notice:', connCfgErr?.message || connCfgErr);
      }

      // 5. Sync RBAC modules from Firestore
      try {
        const modSnap = await getDocs(collection(db, 'permissionModules')).catch(() => null);
        if (modSnap && modSnap.size > 0) {
          modSnap.forEach(d => {
            const data = d.data() as PermissionModule;
            const mid = data.key || data.id || d.id;
            this.rbacModules.set(mid, { ...data, id: mid, key: data.key || mid });
          });
          console.log(`[Backend Store] Synced ${modSnap.size} RBAC modules from Firestore.`);
        }
      } catch (modErr: any) {
        console.warn('[Backend Store] Firestore RBAC modules notice:', modErr?.message || modErr);
      }

      // 6. Sync RBAC permissions from Firestore
      try {
        const permSnap = await getDocs(collection(db, 'permissions')).catch(() => null);
        if (permSnap && permSnap.size > 0) {
          permSnap.forEach(d => {
            const data = d.data() as SystemPermission;
            const pid = data.key || data.id || d.id;
            this.rbacPermissions.set(pid, { ...data, id: pid, key: data.key || pid });
          });
          console.log(`[Backend Store] Synced ${permSnap.size} RBAC permissions from Firestore.`);
        }
      } catch (permErr: any) {
        console.warn('[Backend Store] Firestore RBAC permissions notice:', permErr?.message || permErr);
      }

      // 7. Sync RBAC roles from Firestore
      try {
        const roleSnap = await getDocs(collection(db, 'roles')).catch(() => null);
        if (roleSnap && roleSnap.size > 0) {
          roleSnap.forEach(d => {
            const data = d.data() as RolePermissionConfig;
            const rid = (data.roleId || d.id) as UserRole;
            // CEO Safeguard: CEO always has * and FULL access and unrestricted grant authority
            if (rid === 'ceo') {
              data.permissions = { ...data.permissions, '*': 'FULL', 'users:edit_uid': 'FULL' };
              data.canGrantRoles = ['*'];
            }
            this.rbacRoles.set(rid, { ...data, id: rid, roleId: rid });
          });
          console.log(`[Backend Store] Synced ${roleSnap.size} RBAC roles from Firestore.`);
        }
      } catch (roleErr: any) {
        console.warn('[Backend Store] Firestore RBAC roles notice:', roleErr?.message || roleErr);
      }

      // 8. Sync RBAC staff overrides from Firestore
      try {
        const overrideSnap = await getDocs(collection(db, 'staffOverrides')).catch(() => null);
        if (overrideSnap && overrideSnap.size > 0) {
          overrideSnap.forEach(d => {
            const data = d.data() as StaffPermissionOverride;
            const uid = data.userId || d.id;
            this.rbacStaffOverrides.set(uid, { ...data, userId: uid });
          });
          console.log(`[Backend Store] Synced ${overrideSnap.size} RBAC staff overrides from Firestore.`);
        }
      } catch (overErr: any) {
        console.warn('[Backend Store] Firestore RBAC staff overrides notice:', overErr?.message || overErr);
      }

      // Sync Connections from Firestore
      try {
        const connSnap = await getDocs(collection(db, 'connections')).catch(() => null);
        if (connSnap && connSnap.size > 0) {
          connSnap.forEach(d => {
            const data = d.data() as Connection;
            const cid = data.id || d.id;
            this.connections.set(cid, { ...data, id: cid });
          });
          console.log(`[Backend Store] Synced ${connSnap.size} connections from Firestore.`);
        }
      } catch (cErr: any) {
        console.warn('[Backend Store] Firestore connections sync notice:', cErr?.message || cErr);
      }

      // Sync Connection Requests from Firestore
      try {
        const reqSnap = await getDocs(collection(db, 'connectionRequests')).catch(() => null);
        if (reqSnap && reqSnap.size > 0) {
          reqSnap.forEach(d => {
            const data = d.data() as ConnectionRequest;
            const rid = data.id || d.id;
            this.connectionRequests.set(rid, { ...data, id: rid });
          });
          console.log(`[Backend Store] Synced ${reqSnap.size} connection requests from Firestore.`);
        }
      } catch (rErr: any) {
        console.warn('[Backend Store] Firestore connection requests sync notice:', rErr?.message || rErr);
      }

      // Sync Blocked Users from Firestore
      try {
        const blockSnap = await getDocs(collection(db, 'blockedUsers')).catch(() => null);
        if (blockSnap && blockSnap.size > 0) {
          blockSnap.forEach(d => {
            const data = d.data() as BlockedUserRecord;
            const bid = data.id || d.id;
            this.blockedUsers.set(bid, { ...data, id: bid });
          });
          console.log(`[Backend Store] Synced ${blockSnap.size} blocked user records from Firestore.`);
        }
      } catch (bErr: any) {
        console.warn('[Backend Store] Firestore blocked users sync notice:', bErr?.message || bErr);
      }
    } catch (err: any) {
      console.warn('[Backend Store] Firestore sync notice:', err?.message || err);
    }
  }

  // ==========================================
  // CONNECTIONS FIRESTORE PERSISTENCE METHODS
  // ==========================================

  public async persistConnection(conn: Connection) {
    this.connections.set(conn.id, conn);
    try {
      const db = await this.getFirestoreDb();
      if (!db) return;
      const { doc, setDoc } = await import('firebase/firestore/lite');

      // Clean undefined and non-serializable user sub-objects before writing to document
      const docData = {
        id: conn.id,
        type: conn.type,
        user1Id: conn.user1Id,
        user2Id: conn.user2Id,
        level: Number(conn.level || 1),
        intimacyPoints: Number(conn.intimacyPoints || 0),
        sharedGiftsCount: Number(conn.sharedGiftsCount || 0),
        sharedGiftsCoins: Number(conn.sharedGiftsCoins || 0),
        status: conn.status,
        establishedAt: conn.establishedAt,
        updatedAt: conn.updatedAt || new Date().toISOString()
      };
      await setDoc(doc(db, 'connections', conn.id), docData, { merge: true });
      console.log(`[Backend Store] Persisted connection to Firestore: ${conn.id}`);
    } catch (err: any) {
      console.warn('[Backend Store] Firestore connection save notice:', err?.message || err);
    }
  }

  public async persistConnectionRequest(req: ConnectionRequest) {
    this.connectionRequests.set(req.id, req);
    try {
      const db = await this.getFirestoreDb();
      if (!db) return;
      const { doc, setDoc } = await import('firebase/firestore/lite');

      const docData = {
        id: req.id,
        type: req.type,
        senderId: req.senderId,
        receiverId: req.receiverId,
        status: req.status,
        message: req.message || '',
        createdAt: req.createdAt,
        updatedAt: req.updatedAt || new Date().toISOString()
      };
      await setDoc(doc(db, 'connectionRequests', req.id), docData, { merge: true });
      console.log(`[Backend Store] Persisted connection request to Firestore: ${req.id}`);
    } catch (err: any) {
      console.warn('[Backend Store] Firestore connection request save notice:', err?.message || err);
    }
  }

  public async persistUser(user: User) {
    this.users.set(user.id, user);
    try {
      const db = await this.getFirestoreDb();
      if (!db) return;
      const { doc, setDoc } = await import('firebase/firestore/lite');

      const docData: any = {};
      Object.entries(user).forEach(([k, v]) => {
        if (v !== undefined) docData[k] = v;
      });
      docData.updatedAt = new Date().toISOString();

      await setDoc(doc(db, 'users', user.id), docData, { merge: true }).catch(() => {});
      console.log(`[Backend Store] Persisted user to Firestore: ${user.id}`);
    } catch (err: any) {
      console.warn('[Backend Store] Firestore user save notice:', err?.message || err);
    }
  }

  public async persistBlockedUser(record: BlockedUserRecord) {
    this.blockedUsers.set(record.id, record);
    try {
      const db = await this.getFirestoreDb();
      if (!db) return;
      const { doc, setDoc } = await import('firebase/firestore/lite');

      await setDoc(doc(db, 'blockedUsers', record.id), record, { merge: true });
      console.log(`[Backend Store] Persisted blocked user to Firestore: ${record.id}`);
    } catch (err: any) {
      console.warn('[Backend Store] Firestore blocked user save notice:', err?.message || err);
    }
  }

  public async removeBlockedUserFromFirestore(id: string) {
    this.blockedUsers.delete(id);
    try {
      const db = await this.getFirestoreDb();
      if (!db) return;
      const { doc, deleteDoc } = await import('firebase/firestore/lite');

      await deleteDoc(doc(db, 'blockedUsers', id));
    } catch (err: any) {
      console.warn('[Backend Store] Firestore delete blocked user notice:', err?.message || err);
    }
  }

  // ==========================================
  // RBAC FIRESTORE PERSISTENCE METHODS
  // ==========================================

  public async persistRoleConfig(roleConfig: RolePermissionConfig) {
    // CEO Safeguard: Ensure CEO retains ultimate access
    if (roleConfig.roleId === 'ceo') {
      roleConfig.permissions['*'] = 'FULL';
      roleConfig.permissions['users:edit_uid'] = 'FULL';
      roleConfig.canGrantRoles = ['*'];
    }
    this.rbacRoles.set(roleConfig.roleId, roleConfig);
    try {
      const db = await this.getFirestoreDb();
      if (!db) return;
      const { doc, setDoc } = await import('firebase/firestore/lite');

      await setDoc(doc(db, 'roles', roleConfig.roleId), roleConfig, { merge: true });
      console.log(`[Backend Store] Persisted RBAC role config to Firestore: ${roleConfig.roleId}`);
    } catch (err: any) {
      console.warn('[Backend Store] Firestore role save notice:', err?.message || err);
    }
  }

  public async persistPermission(permission: SystemPermission) {
    this.rbacPermissions.set(permission.key, permission);
    try {
      const db = await this.getFirestoreDb();
      if (!db) return;
      const { doc, setDoc } = await import('firebase/firestore/lite');

      await setDoc(doc(db, 'permissions', permission.key), permission, { merge: true });
      console.log(`[Backend Store] Persisted RBAC permission to Firestore: ${permission.key}`);
    } catch (err: any) {
      console.warn('[Backend Store] Firestore permission save notice:', err?.message || err);
    }
  }

  public async persistModule(module: PermissionModule) {
    this.rbacModules.set(module.key, module);
    try {
      const db = await this.getFirestoreDb();
      if (!db) return;
      const { doc, setDoc } = await import('firebase/firestore/lite');

      await setDoc(doc(db, 'permissionModules', module.key), module, { merge: true });
      console.log(`[Backend Store] Persisted RBAC module to Firestore: ${module.key}`);
    } catch (err: any) {
      console.warn('[Backend Store] Firestore module save notice:', err?.message || err);
    }
  }

  public async persistStaffOverride(override: StaffPermissionOverride) {
    this.rbacStaffOverrides.set(override.userId, override);
    try {
      const db = await this.getFirestoreDb();
      if (!db) return;
      const { doc, setDoc } = await import('firebase/firestore/lite');

      await setDoc(doc(db, 'staffOverrides', override.userId), override, { merge: true });
      console.log(`[Backend Store] Persisted RBAC staff override to Firestore for user: ${override.userId}`);
    } catch (err: any) {
      console.warn('[Backend Store] Firestore staff override save notice:', err?.message || err);
    }
  }

  public async deleteStaffOverride(userId: string) {
    this.rbacStaffOverrides.delete(userId);
    try {
      const db = await this.getFirestoreDb();
      if (!db) return;
      const { doc, deleteDoc } = await import('firebase/firestore/lite');

      await deleteDoc(doc(db, 'staffOverrides', userId));
      console.log(`[Backend Store] Deleted RBAC staff override from Firestore for user: ${userId}`);
    } catch (err: any) {
      console.warn('[Backend Store] Firestore delete staff override notice:', err?.message || err);
    }
  }

  public async resetRoleConfig(roleId: UserRole, resetBy: string = 'System') {
    const defaultConfig = DEFAULT_ROLE_CONFIGS[roleId];
    if (!defaultConfig) {
      throw new Error(`Unknown role ${roleId}`);
    }
    const freshConfig: RolePermissionConfig = {
      ...defaultConfig,
      permissions: { ...defaultConfig.permissions },
      canGrantRoles: [...defaultConfig.canGrantRoles] as any,
      updatedAt: new Date().toISOString(),
      updatedBy: resetBy
    };
    await this.persistRoleConfig(freshConfig);
    return freshConfig;
  }

  public async persistAdminAppearanceToFirestore(appearance: AdminAppearanceSettings) {
    try {
      const db = await this.getFirestoreDb();
      if (!db) return;
      const { doc, setDoc } = await import('firebase/firestore/lite');

      await setDoc(doc(db, 'adminSettings', 'appearance'), appearance, { merge: true });
      console.log(`[Backend Store] Persisted admin appearance to Firestore: ${appearance.backgroundColor}`);
    } catch (err: any) {
      console.warn('[Backend Store] Firestore appearance save notice:', err?.message || err);
    }
  }

  public async persistConnectionConfigToFirestore(config: ConnectionSystemConfig) {
    try {
      this.connectionConfig = config;
      const db = await this.getFirestoreDb();
      if (!db) return;
      const { doc, setDoc } = await import('firebase/firestore/lite');
      await setDoc(doc(db, 'adminSettings', 'connectionConfig'), config, { merge: true });
      console.log(`[Backend Store] Persisted connection config to Firestore`);
    } catch (err: any) {
      console.warn('[Backend Store] Firestore connection config save notice:', err?.message || err);
    }
  }

  public async persistCountryToFirestore(country: Country) {
    try {
      const db = await this.getFirestoreDb();
      if (!db) return;
      const { doc, setDoc } = await import('firebase/firestore/lite');

      await setDoc(doc(db, 'countries', country.id), country, { merge: true });
    } catch (err: any) {
      console.warn('[Backend Store] Firestore country save notice:', err?.message || err);
    }
  }

  public async deleteCountryFromFirestore(countryId: string) {
    try {
      const db = await this.getFirestoreDb();
      if (!db) return;
      const { doc, deleteDoc } = await import('firebase/firestore/lite');

      await deleteDoc(doc(db, 'countries', countryId));
    } catch (err: any) {
      console.warn('[Backend Store] Firestore country delete notice:', err?.message || err);
    }
  }

  public ensureDefaultCeoExists() {
    // Check if CEO user with UID 2383452 or CEO role exists in users table
    let ceoUser = this.users.get('2383452') || Array.from(this.users.values()).find(u => u.uid === '2383452' || u.id === '2383452' || u.email === 'ceo@aura.com' || u.role === 'ceo');
    if (!ceoUser) {
      ceoUser = {
        id: '2383452',
        uid: '2383452',
        name: 'Elena Vance (CEO)',
        email: 'ceo@aura.com',
        password: 'Admin@123',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
        frame: '👑 Golden Monarch',
        background: '🌌 Nebula Deep',
        gender: 'female',
        country: 'United States',
        countryFlag: '🇺🇸',
        bio: '👑 CEO & Founder of Aura Voice Platform. Account ID: 2383452. Full administrative control & staff management.',
        role: 'ceo',
        vipLevel: 'svip',
        vipExpiry: '2030-12-31T23:59:59Z',
        coins: 10000000,
        diamonds: 5000000,
        level: 100,
        sendingLevel: 100,
        receivingLevel: 100,
        isOnline: true,
        createdAt: '2025-01-01T00:00:00Z',
        badges: [
          { id: 'bdg-ceo', name: 'Executive Leader', icon: '👑', description: 'Platform CEO & Owner', acquiredAt: '2025-01-01' },
          { id: 'bdg-1', name: 'Founding Icon', icon: '🌟', description: 'Early adopter of Aura Voice', acquiredAt: '2025-01-10' },
          { id: 'bdg-3', name: 'Wealthy Patron', icon: '💎', description: 'VIP Platinum Patron', acquiredAt: '2025-05-01' }
        ],
        medals: [
          { id: 'mdl-ceo', name: 'Owner', icon: '⚡', level: 10, color: '#f59e0b' },
          { id: 'mdl-1', name: 'Charisma King', icon: '🔥', level: 10, color: '#f59e0b' }
        ]
      };
    } else {
      // Ensure UID 2383452, email, password, and CEO role are explicitly set
      ceoUser.uid = '2383452';
      ceoUser.id = '2383452';
      ceoUser.email = ceoUser.email || 'ceo@aura.com';
      ceoUser.password = ceoUser.password || 'Admin@123';
      ceoUser.role = 'ceo';
      ceoUser.vipLevel = 'svip';
    }

    // Set under ONLY primary ID 2383452 to avoid duplicating items when calling this.users.values()
    this.users.set('2383452', ceoUser);

    // Check if staff entry exists
    let ceoStaff = this.staff.get('stf-1') || Array.from(this.staff.values()).find(s => s.userId === '2383452' || s.email === 'ceo@aura.com' || s.role === 'ceo');
    if (!ceoStaff) {
      ceoStaff = {
        id: 'stf-1',
        userId: '2383452',
        name: ceoUser.name,
        email: 'ceo@aura.com',
        role: 'ceo',
        permissions: ['all', 'admin:super', 'finance:withdraw', 'rooms:manage', 'users:ban', 'staff:manage', 'permission:grant', 'audit:view', 'system:config', 'wallet:manage', 'reports:manage'],
        assignedBy: 'system',
        assignedAt: '2025-01-01T00:00:00Z',
        status: 'active'
      };
    } else {
      ceoStaff.id = 'stf-1';
      ceoStaff.userId = '2383452';
      ceoStaff.email = 'ceo@aura.com';
      ceoStaff.permissions = ['all', 'admin:super', 'finance:withdraw', 'rooms:manage', 'users:ban', 'staff:manage', 'permission:grant', 'audit:view', 'system:config', 'wallet:manage', 'reports:manage'];
    }
    this.staff.set('stf-1', ceoStaff);

    // Synchronize CEO / User's voice room to ensure room ID matches profile ID (UID)
    let ceoRoom = this.rooms.get('2383452') || this.rooms.get('room-101');
    if (ceoRoom) {
      ceoRoom.id = ceoUser.uid || '2383452';
      ceoRoom.hostUid = ceoUser.uid || '2383452';
      ceoRoom.hostId = ceoUser.id;
      ceoRoom.hostName = ceoUser.name;
      ceoRoom.hostAvatar = ceoUser.avatar;
      ceoRoom.hostFrame = ceoUser.frame;
      if (ceoRoom.seats && ceoRoom.seats[0]) {
        ceoRoom.seats[0].userId = ceoUser.id;
        ceoRoom.seats[0].userName = ceoUser.name;
        ceoRoom.seats[0].userAvatar = ceoUser.avatar;
        ceoRoom.seats[0].userFrame = ceoUser.frame;
      }
      this.rooms.set(ceoRoom.id, ceoRoom);
    }
  }

  private seedData() {
    // 1. Seed Users
    const usersList: User[] = [
      {
        id: '2383452',
        uid: '2383452',
        name: 'Elena Vance (CEO)',
        email: 'ceo@aura.com',
        password: 'Admin@123',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
        frame: '👑 Golden Monarch',
        background: '🌌 Nebula Deep',
        gender: 'female',
        country: 'United States',
        countryFlag: '🇺🇸',
        bio: '👑 CEO & Founder of Aura Voice Platform. Account ID: 2383452. Full administrative control & staff management.',
        role: 'ceo',
        vipLevel: 'svip',
        vipExpiry: '2030-12-31T23:59:59Z',
        coins: 10000000,
        diamonds: 5000000,
        level: 100,
        sendingLevel: 100,
        receivingLevel: 100,
        familyId: 'fam-001',
        familyName: 'Royal Dynasty 👑',
        isOnline: true,
        createdAt: '2025-01-10T10:00:00Z',
        badges: [
          { id: 'bdg-1', name: 'Founding Icon', icon: '🌟', description: 'Early adopter of Aura Voice', acquiredAt: '2025-01-10' },
          { id: 'bdg-2', name: 'PK Conqueror', icon: '⚔️', description: 'Won 100+ Live PK Battles', acquiredAt: '2025-03-15' },
          { id: 'bdg-3', name: 'Wealthy Patron', icon: '💎', description: 'Sent over 1M coins in gifts', acquiredAt: '2025-05-01' },
          { id: 'bdg-ceo', name: 'Platform CEO', icon: '👑', description: 'Supreme Executive Authority', acquiredAt: '2025-01-01' }
        ],
        medals: [
          { id: 'mdl-1', name: 'Charisma King', icon: '🔥', level: 10, color: '#f59e0b' },
          { id: 'mdl-2', name: 'Vocal Master', icon: '🎤', level: 10, color: '#ec4899' },
          { id: 'mdl-ceo', name: 'Owner', icon: '⚡', level: 10, color: '#f59e0b' }
        ]
      },
      {
        id: '8829105',
        uid: '8829105',
        name: 'Alex Chen',
        email: 'alex.chen@auravoice.io',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
        frame: '⚡ Cyber Pulse',
        gender: 'male',
        country: 'Singapore',
        countryFlag: '🇸🇬',
        bio: '🎮 Gaming debates, EDM music, and weekend tournaments!',
        role: 'super_admin',
        vipLevel: 'vip',
        coins: 48500,
        diamonds: 2100,
        level: 42,
        sendingLevel: 42,
        receivingLevel: 56,
        familyId: 'fam-002',
        familyName: 'Cyber Wolves 🐺',
        isOnline: true,
        createdAt: '2025-02-01T12:00:00Z',
        badges: [
          { id: 'bdg-4', name: 'Gamer MVP', icon: '🕹️', description: 'Hosted 50 game nights', acquiredAt: '2025-04-10' }
        ],
        medals: [
          { id: 'mdl-3', name: 'Top Host', icon: '🎙️', level: 6, color: '#3b82f6' }
        ]
      },
      {
        id: '8829106',
        uid: '8829106',
        name: 'Marcus Aurelius',
        email: 'marcus@auravoice.io',
        avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
        gender: 'male',
        country: 'United Kingdom',
        countryFlag: '🇬🇧',
        bio: 'Philosophy, quiet tea sessions, and late evening jazz 🎷',
        role: 'gm',
        vipLevel: 'svip',
        coins: 89000,
        diamonds: 5400,
        level: 55,
        sendingLevel: 55,
        receivingLevel: 48,
        familyId: 'fam-001',
        familyName: 'Royal Dynasty 👑',
        isOnline: true,
        createdAt: '2025-01-15T10:00:00Z',
        badges: [],
        medals: []
      },
      {
        id: '8829107',
        uid: '8829107',
        name: 'Sophia Taylor',
        email: 'sophia@auravoice.io',
        avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80',
        gender: 'female',
        country: 'Australia',
        countryFlag: '🇦🇺',
        bio: '🌊 Acoustic guitar live covers every Tuesday & Thursday!',
        role: 'agency',
        vipLevel: 'vip',
        coins: 34000,
        diamonds: 1800,
        level: 38,
        sendingLevel: 32,
        receivingLevel: 72,
        familyId: 'fam-003',
        familyName: 'Aura Stars ✨',
        isOnline: false,
        createdAt: '2025-02-15T10:00:00Z',
        badges: [],
        medals: []
      },
      {
        id: '8829108',
        uid: '8829108',
        name: 'Kenji Sato',
        email: 'kenji@auravoice.io',
        avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=300&q=80',
        gender: 'male',
        country: 'Japan',
        countryFlag: '🇯🇵',
        bio: 'Anisong karaoke party! Join seat #3 to sing along 🎶',
        role: 'host',
        vipLevel: 'none',
        coins: 12500,
        diamonds: 450,
        level: 25,
        sendingLevel: 25,
        receivingLevel: 30,
        familyId: 'fam-002',
        familyName: 'Cyber Wolves 🐺',
        isOnline: true,
        createdAt: '2025-03-01T10:00:00Z',
        badges: [],
        medals: []
      }
    ];

    usersList.forEach(u => this.users.set(u.id, u));

    // 2. Seed Voice Rooms
    const roomsList: VoiceRoom[] = [
      {
        id: '2383452',
        hostUid: '2383452',
        title: '🌙 Night Vibes & Lofi Chill Lounge',
        topic: 'Relaxing tunes, open mic talk, make new friends globally',
        category: 'popular',
        coverImage: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=600&q=80',
        hostId: '2383452',
        hostName: 'Elena Vance',
        hostAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
        hostFrame: '👑 Golden Monarch',
        country: 'United States',
        countryFlag: '🇺🇸',
        language: 'English',
        onlineCount: 48,
        maxSeats: 9,
        isLocked: false,
        announcement: '🎉 Welcome to Elena\'s VIP room! Please keep conversations respectful. Next PK battle at 10 PM UTC!',
        tags: ['Chill', 'Lofi', 'Friendship', '24/7'],
        musicPlaying: {
          title: 'Midnight Breeze (Lofi Mix)',
          artist: 'Aura Beats Studio',
          isPlaying: true
        },
        pkState: {
          active: true,
          opponentRoomId: '8829105',
          opponentName: 'Alex Chen',
          opponentAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
          myScore: 18450,
          opponentScore: 14200,
          timeLeft: 185
        },
        seats: [
          { index: 0, userId: '2383452', userName: 'Elena Vance', userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80', userFrame: '👑 Golden Monarch', isMuted: false, isLocked: false, isSpeaking: true, contributionCoin: 45000 },
          { index: 1, userId: '8829106', userName: 'Marcus Aurelius', userAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80', isMuted: false, isLocked: false, isSpeaking: false, contributionCoin: 28000 },
          { index: 2, userId: '8829108', userName: 'Kenji Sato', userAvatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=300&q=80', isMuted: true, isLocked: false, isSpeaking: false, contributionCoin: 12500 },
          { index: 3, isMuted: false, isLocked: false, isSpeaking: false, contributionCoin: 0 },
          { index: 4, isMuted: false, isLocked: false, isSpeaking: false, contributionCoin: 0 },
          { index: 5, isMuted: false, isLocked: true, isSpeaking: false, contributionCoin: 0 },
          { index: 6, isMuted: false, isLocked: false, isSpeaking: false, contributionCoin: 0 },
          { index: 7, isMuted: false, isLocked: false, isSpeaking: false, contributionCoin: 0 },
          { index: 8, isMuted: false, isLocked: false, isSpeaking: false, contributionCoin: 0 }
        ],
        createdAt: '2025-07-27T18:00:00Z'
      },
      {
        id: '8829105',
        hostUid: '8829105',
        title: '🎤 Global EDM & Gaming Tournament Chat',
        topic: 'Discussing the upcoming summer esports championship',
        category: 'game',
        coverImage: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80',
        hostId: '8829105',
        hostName: 'Alex Chen',
        hostAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
        hostFrame: '⚡ Cyber Pulse',
        country: 'Singapore',
        countryFlag: '🇸🇬',
        language: 'English',
        onlineCount: 32,
        maxSeats: 9,
        isLocked: false,
        announcement: '🎮 Join mic seat #2 to register your squad for tonight\'s Valorant custom match!',
        tags: ['Esports', 'Gaming', 'EDM', 'Tourney'],
        seats: [
          { index: 0, userId: '8829105', userName: 'Alex Chen', userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80', userFrame: '⚡ Cyber Pulse', isMuted: false, isLocked: false, isSpeaking: true, contributionCoin: 32000 },
          { index: 1, isMuted: false, isLocked: false, isSpeaking: false, contributionCoin: 0 },
          { index: 2, isMuted: false, isLocked: false, isSpeaking: false, contributionCoin: 0 },
          { index: 3, isMuted: false, isLocked: false, isSpeaking: false, contributionCoin: 0 },
          { index: 4, isMuted: false, isLocked: false, isSpeaking: false, contributionCoin: 0 },
          { index: 5, isMuted: false, isLocked: false, isSpeaking: false, contributionCoin: 0 },
          { index: 6, isMuted: false, isLocked: false, isSpeaking: false, contributionCoin: 0 },
          { index: 7, isMuted: false, isLocked: false, isSpeaking: false, contributionCoin: 0 },
          { index: 8, isMuted: false, isLocked: false, isSpeaking: false, contributionCoin: 0 }
        ],
        createdAt: '2025-07-27T19:00:00Z'
      },
      {
        id: '8829107',
        hostUid: '8829107',
        title: '🌟 Acoustic Sunset & Live Singing Arena',
        topic: 'Live acoustic guitar covers. Request your favorite pop songs!',
        category: 'music',
        coverImage: 'https://images.unsplash.com/photo-1510915361894-db8b60106cb1?auto=format&fit=crop&w=600&q=80',
        hostId: '8829107',
        hostName: 'Sophia Taylor',
        hostAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80',
        country: 'Australia',
        countryFlag: '🇦🇺',
        language: 'English',
        onlineCount: 26,
        maxSeats: 6,
        isLocked: false,
        announcement: '🎸 Song requests are 100 coins via Gift panel! Thank you for supporting acoustic artists ❤️',
        tags: ['Music', 'Live Guitar', 'Singing', 'Acoustic'],
        seats: [
          { index: 0, userId: '8829107', userName: 'Sophia Taylor', userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80', isMuted: false, isLocked: false, isSpeaking: true, contributionCoin: 18000 },
          { index: 1, isMuted: false, isLocked: false, isSpeaking: false, contributionCoin: 0 },
          { index: 2, isMuted: false, isLocked: false, isSpeaking: false, contributionCoin: 0 },
          { index: 3, isMuted: false, isLocked: false, isSpeaking: false, contributionCoin: 0 },
          { index: 4, isMuted: false, isLocked: false, isSpeaking: false, contributionCoin: 0 },
          { index: 5, isMuted: false, isLocked: false, isSpeaking: false, contributionCoin: 0 }
        ],
        createdAt: '2025-07-27T20:00:00Z'
      }
    ];

    roomsList.forEach(r => {
      this.rooms.set(r.id, r);
    });

    // 3. Seed Gifts
    const giftsList: Gift[] = [
      { 
        id: 'gft-1', 
        name: 'Love Rose 🌹', 
        icon: '🌹', 
        priceCoins: 10, 
        category: 'popular', 
        animationType: 'pop', 
        svgColor: '#f43f5e',
        description: 'A classic scarlet rose symbolizing affection and warm welcome.',
        stockQuantity: -1,
        isAvailable: true,
        diamondYieldRate: 0.5,
        rarity: 'common',
        tags: ['welcome', 'popular', 'flower']
      },
      { 
        id: 'gft-2', 
        name: 'Neon Heart 💖', 
        icon: '💖', 
        priceCoins: 50, 
        category: 'popular', 
        animationType: 'pop', 
        svgColor: '#ec4899',
        description: 'Vibrant pulsating neon heart that glows across the voice stage.',
        stockQuantity: -1,
        isAvailable: true,
        diamondYieldRate: 0.5,
        rarity: 'common',
        tags: ['heart', 'love', 'neon']
      },
      { 
        id: 'gft-3', 
        name: 'Golden Mic 🎙️', 
        icon: '🎙️', 
        priceCoins: 100, 
        category: 'popular', 
        animationType: 'pop', 
        svgColor: '#eab308',
        description: 'Prestigious golden microphone for the room host or favorite singer.',
        stockQuantity: -1,
        isAvailable: true,
        diamondYieldRate: 0.5,
        rarity: 'rare',
        tags: ['mic', 'music', 'host']
      },
      { 
        id: 'gft-4', 
        name: 'Diamond Ring 💍', 
        icon: '💍', 
        priceCoins: 500, 
        category: 'luxury', 
        animationType: 'banner', 
        svgColor: '#38bdf8',
        description: 'Dazzling gemstone solitaire ring with a sparkling screen banner.',
        stockQuantity: 1000,
        isAvailable: true,
        diamondYieldRate: 0.55,
        rarity: 'rare',
        tags: ['luxury', 'ring', 'cp']
      },
      { 
        id: 'gft-5', 
        name: 'Royal Crown 👑', 
        icon: '👑', 
        priceCoins: 1000, 
        category: 'luxury', 
        animationType: 'fullscreen', 
        svgColor: '#f59e0b',
        description: 'Coronate your top broadcaster with a golden imperial crown animation.',
        stockQuantity: 500,
        isAvailable: true,
        diamondYieldRate: 0.6,
        rarity: 'epic',
        tags: ['crown', 'royalty', 'luxury']
      },
      { 
        id: 'gft-6', 
        name: 'Sports Car 🏎️', 
        icon: '🏎️', 
        priceCoins: 3000, 
        category: 'luxury', 
        animationType: 'fullscreen', 
        svgColor: '#ef4444',
        description: 'Rev roaring turbocharged supercar racing through the voice room!',
        stockQuantity: 250,
        isAvailable: true,
        diamondYieldRate: 0.6,
        rarity: 'epic',
        tags: ['car', 'speed', 'luxury']
      },
      { 
        id: 'gft-7', 
        name: 'Golden Dragon 🐉', 
        icon: '🐉', 
        priceCoins: 5000, 
        category: 'luxury', 
        animationType: 'fullscreen', 
        svgColor: '#eab308',
        description: 'Mythical oriental golden dragon soaring with fireworks and blessings.',
        stockQuantity: 100,
        isAvailable: true,
        diamondYieldRate: 0.65,
        rarity: 'legendary',
        tags: ['dragon', 'mythic', 'luxury']
      },
      { 
        id: 'gft-8', 
        name: 'Rocket Ship 🚀', 
        icon: '🚀', 
        priceCoins: 10000, 
        category: 'luxury', 
        animationType: 'fullscreen', 
        svgColor: '#8b5cf6',
        description: 'Interstellar rocket blastoff launching the host straight to #1 rankings!',
        stockQuantity: 50,
        isAvailable: true,
        diamondYieldRate: 0.7,
        rarity: 'legendary',
        tags: ['space', 'rocket', 'top-tier']
      },
      { 
        id: 'gft-9', 
        name: 'PK Hammer 🔨', 
        icon: '🔨', 
        priceCoins: 200, 
        category: 'pk', 
        animationType: 'pop', 
        svgColor: '#ef4444',
        description: 'Strike the rival room in live 1v1 PK battles and crush their score!',
        stockQuantity: -1,
        isAvailable: true,
        diamondYieldRate: 0.5,
        rarity: 'common',
        tags: ['pk', 'battle', 'smash']
      },
      { 
        id: 'gft-10', 
        name: 'Victory Trophy 🏆', 
        icon: '🏆', 
        priceCoins: 800, 
        category: 'pk', 
        animationType: 'banner', 
        svgColor: '#f59e0b',
        description: 'Golden championship cup delivering massive momentum during PK final minutes.',
        stockQuantity: 500,
        isAvailable: true,
        diamondYieldRate: 0.55,
        rarity: 'rare',
        tags: ['trophy', 'pk', 'champion']
      },
      { 
        id: 'gft-11', 
        name: 'Family Shield 🛡️', 
        icon: '🛡️', 
        priceCoins: 300, 
        category: 'family', 
        animationType: 'pop', 
        svgColor: '#3b82f6',
        description: 'Defend your guild honor and earn family contribution EXP for all members.',
        stockQuantity: -1,
        isAvailable: true,
        diamondYieldRate: 0.5,
        rarity: 'rare',
        tags: ['guild', 'family', 'defense']
      },
      { 
        id: 'gft-12', 
        name: 'Aura Castle 🏰', 
        icon: '🏰', 
        priceCoins: 15000, 
        category: 'special', 
        animationType: 'fullscreen', 
        svgColor: '#a855f7',
        description: 'Ultimate monumental majestic citadel with global platform-wide broadcast alert.',
        stockQuantity: 20,
        isAvailable: true,
        diamondYieldRate: 0.75,
        rarity: 'mythic',
        tags: ['castle', 'mythic', 'global-banner']
      }
    ];

    giftsList.forEach(g => this.gifts.set(g.id, g));

    // Seed default user backpack inventories (e.g. for demo user Elena Vance 2383452)
    const seedInventory = new Map<string, UserGiftInventoryItem>();
    seedInventory.set('gft-1', {
      id: 'inv-item-1',
      userId: '2383452',
      giftId: 'gft-1',
      quantity: 5,
      gift: giftsList[0],
      acquiredAt: new Date().toISOString(),
      source: 'spin'
    });
    seedInventory.set('gft-2', {
      id: 'inv-item-2',
      userId: '2383452',
      giftId: 'gft-2',
      quantity: 3,
      gift: giftsList[1],
      acquiredAt: new Date().toISOString(),
      source: 'event'
    });
    seedInventory.set('gft-3', {
      id: 'inv-item-3',
      userId: '2383452',
      giftId: 'gft-3',
      quantity: 1,
      gift: giftsList[2],
      acquiredAt: new Date().toISOString(),
      source: 'reward'
    });
    seedInventory.set('gft-10', {
      id: 'inv-item-4',
      userId: '2383452',
      giftId: 'gft-10',
      quantity: 2,
      gift: giftsList[9],
      acquiredAt: new Date().toISOString(),
      source: 'lucky_bag'
    });
    this.userGiftInventories.set('2383452', seedInventory);

    // 4. Seed Families
    const familiesList: Family[] = [
      {
        id: 'fam-001',
        familyId: 'FAM-100001',
        name: 'Royal Dynasty 👑',
        slogan: 'Where kings and queens unite in harmony!',
        badge: '👑',
        logo: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=500&q=80',
        coverImage: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=500&q=80',
        description: 'The supreme royal guild of Aura Voice. Home to top creators, broadcasters and VIPs.',
        announcement: 'Weekly clan meeting this Sunday at 8 PM UTC! Complete your daily contributions.',
        country: 'Global 🌐',
        category: 'VIP & Elite',
        status: 'active',
        privacy: 'public',
        joinMethod: 'anyone',
        ownerId: '2383452',
        leaderId: '2383452',
        leaderName: 'Elena Vance',
        leaderAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
        coLeaderIds: ['8829106'],
        coLeaderNames: ['Marcus Aurelius'],
        level: 8,
        xp: 45000,
        totalContribution: 4500000,
        memberCount: 45,
        maxMembers: 50,
        ranking: 1,
        createdAt: '2025-01-01T00:00:00Z'
      },
      {
        id: 'fam-002',
        familyId: 'FAM-100002',
        name: 'Cyber Wolves 🐺',
        slogan: 'Howl together, win together. Never surrender.',
        badge: '🐺',
        logo: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=500&q=80',
        coverImage: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=500&q=80',
        description: 'Elite gaming and PK competitive guild dominating voice battles.',
        announcement: 'PK tournament signups open now! DM the clan leader to register.',
        country: 'Singapore 🇸🇬',
        category: 'Gaming & Social',
        status: 'active',
        privacy: 'public',
        joinMethod: 'approval',
        ownerId: '8829105',
        leaderId: '8829105',
        leaderName: 'Alex Chen',
        leaderAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
        coLeaderIds: ['8829108'],
        coLeaderNames: ['Kenji Sato'],
        level: 6,
        xp: 28000,
        totalContribution: 2800000,
        memberCount: 38,
        maxMembers: 50,
        ranking: 2,
        createdAt: '2025-02-01T00:00:00Z'
      },
      {
        id: 'fam-003',
        familyId: 'FAM-100003',
        name: 'Aura Stars ✨',
        slogan: 'Shining bright across every voice room globally.',
        badge: '✨',
        logo: 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?auto=format&fit=crop&w=500&q=80',
        coverImage: 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?auto=format&fit=crop&w=500&q=80',
        description: 'A friendly community of acoustic vocalists, singers, and podcast hosts.',
        announcement: 'Welcome all new acoustic & music singers! Open mic night every Friday.',
        country: 'Australia 🇦🇺',
        category: 'Music & Acoustic',
        status: 'active',
        privacy: 'public',
        joinMethod: 'anyone',
        ownerId: '8829107',
        leaderId: '8829107',
        leaderName: 'Sophia Taylor',
        leaderAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80',
        level: 5,
        xp: 19500,
        totalContribution: 1950000,
        memberCount: 29,
        maxMembers: 40,
        ranking: 3,
        createdAt: '2025-03-01T00:00:00Z'
      },
      {
        id: 'fam-004',
        familyId: 'FAM-100004',
        name: 'Phoenix Dynasty 🔥',
        slogan: 'From the ashes of battles, we rise victorious!',
        badge: '🔥',
        logo: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=500&q=80',
        coverImage: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=500&q=80',
        description: 'Elite competitive clan with high-stake voice battle tournaments.',
        announcement: 'Daily PK wars start at 7 PM UTC! All members please check in.',
        country: 'United Kingdom 🇬🇧',
        category: 'Gaming & Social',
        status: 'active',
        privacy: 'public',
        joinMethod: 'approval',
        ownerId: '8829106',
        leaderId: '8829106',
        leaderName: 'Marcus Aurelius',
        leaderAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
        level: 7,
        xp: 32000,
        totalContribution: 3200000,
        memberCount: 42,
        maxMembers: 50,
        ranking: 4,
        createdAt: '2025-02-15T00:00:00Z'
      },
      {
        id: 'fam-005',
        familyId: 'FAM-100005',
        name: 'Neon Chillers 🌌',
        slogan: 'Relax, vibe, make lifelong friends across the globe.',
        badge: '🌌',
        logo: 'https://images.unsplash.com/photo-1511447333015-45b65e60f6d5?auto=format&fit=crop&w=500&q=80',
        coverImage: 'https://images.unsplash.com/photo-1511447333015-45b65e60f6d5?auto=format&fit=crop&w=500&q=80',
        description: 'Open community lounge for relaxed conversations and lofi music.',
        announcement: 'Everyone is welcome! Instant membership without approvals.',
        country: 'Canada 🇨🇦',
        category: 'Social',
        status: 'active',
        privacy: 'public',
        joinMethod: 'anyone',
        ownerId: '8829108',
        leaderId: '8829108',
        leaderName: 'Kenji Sato',
        leaderAvatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=300&q=80',
        level: 4,
        xp: 14000,
        totalContribution: 1400000,
        memberCount: 22,
        maxMembers: 35,
        ranking: 5,
        createdAt: '2025-03-10T00:00:00Z'
      }
    ];

    familiesList.forEach(f => this.families.set(f.id, f));

    // Seed Family Members
    const initialFamilyMembers: FamilyMember[] = [
      { id: 'fmem-1', familyId: 'fam-001', userId: '2383452', userUid: '2383452', name: 'Elena Vance', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80', role: 'leader', userRole: 'ceo', contributionDaily: 5000, contributionTotal: 1200000, isOnline: true, joinedAt: '2025-01-01T00:00:00Z' },
      { id: 'fmem-2', familyId: 'fam-001', userId: '8829106', userUid: '8829106', name: 'Marcus Aurelius', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80', role: 'co_leader', userRole: 'gm', contributionDaily: 3200, contributionTotal: 850000, isOnline: true, joinedAt: '2025-01-15T00:00:00Z' },
      { id: 'fmem-3', familyId: 'fam-001', userId: '8829109', userUid: '8829109', name: 'Liam Vance', avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=300&q=80', role: 'elder', userRole: 'official_staff', contributionDaily: 1200, contributionTotal: 190000, isOnline: false, joinedAt: '2025-02-01T00:00:00Z' },
      { id: 'fmem-4', familyId: 'fam-002', userId: '8829105', userUid: '8829105', name: 'Alex Chen', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80', role: 'leader', userRole: 'super_admin', contributionDaily: 4200, contributionTotal: 620000, isOnline: true, joinedAt: '2025-02-01T00:00:00Z' },
      { id: 'fmem-5', familyId: 'fam-002', userId: '8829108', userUid: '8829108', name: 'Kenji Sato', avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=300&q=80', role: 'co_leader', userRole: 'host', contributionDaily: 2100, contributionTotal: 340000, isOnline: true, joinedAt: '2025-02-10T00:00:00Z' },
      { id: 'fmem-6', familyId: 'fam-003', userId: '8829107', userUid: '8829107', name: 'Sophia Taylor', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80', role: 'leader', userRole: 'host', contributionDaily: 3500, contributionTotal: 580000, isOnline: true, joinedAt: '2025-03-01T00:00:00Z' }
    ];

    initialFamilyMembers.forEach(m => this.familyMembers.set(m.id, m));

    // 5. Seed Staff
    const staffList: StaffMember[] = [
      { id: 'stf-1', userId: '2383452', name: 'Elena Vance (CEO)', email: 'ceo@aura.com', role: 'ceo', permissions: ['all', 'admin:super', 'finance:withdraw', 'rooms:manage', 'users:ban', 'staff:manage', 'permission:grant', 'audit:view', 'system:config', 'wallet:manage', 'reports:manage'], assignedBy: 'system', assignedAt: '2025-01-01T00:00:00Z', status: 'active' },
      { id: 'stf-2', userId: '8829106', name: 'Marcus Aurelius', email: 'marcus@auravoice.io', role: 'gm', permissions: ['admin:super', 'rooms:manage', 'users:ban', 'staff:view'], assignedBy: '2383452', assignedAt: '2025-01-10T00:00:00Z', status: 'active' },
      { id: 'stf-3', userId: '8829105', name: 'Alex Chen', email: 'alex.chen@auravoice.io', role: 'super_admin', permissions: ['rooms:manage', 'users:ban', 'audit:view'], assignedBy: '2383452', assignedAt: '2025-02-01T00:00:00Z', status: 'active' }
    ];

    staffList.forEach(s => this.staff.set(s.id, s));

    // 6. Seed Daily Spin Rewards
    this.spinRewards = [
      { id: 'spn-1', name: '100 Coins 🪙', type: 'coin', value: 100, icon: '🪙', probability: 35, color: '#f59e0b' },
      { id: 'spn-2', name: '500 Coins 🪙', type: 'coin', value: 500, icon: '💰', probability: 20, color: '#eab308' },
      { id: 'spn-3', name: '50 Diamonds 💎', type: 'diamond', value: 50, icon: '💎', probability: 15, color: '#38bdf8' },
      { id: 'spn-4', name: '1,000 Coins 🪙', type: 'coin', value: 1000, icon: '🏆', probability: 10, color: '#f97316' },
      { id: 'spn-5', name: '200 Diamonds 💎', type: 'diamond', value: 200, icon: '✨', probability: 8, color: '#a855f7' },
      { id: 'spn-6', name: '3-Day VIP Pass 🎟️', type: 'vip_day', value: 3, icon: '🎟️', probability: 7, color: '#ec4899' },
      { id: 'spn-7', name: '5,000 Coins Jackpot 🎉', type: 'coin', value: 5000, icon: '👑', probability: 3, color: '#ef4444' },
      { id: 'spn-8', name: 'Exclusive Neon Frame ⚡', type: 'frame', value: 1, icon: '⚡', probability: 2, color: '#10b981' }
    ];

    // 7. Seed Lucky Bag
    const demoBag: LuckyBag = {
      id: 'lck-001',
      roomId: '2383452',
      senderId: '2383452',
      senderName: 'Elena Vance',
      totalCoins: 1000,
      remainingCoins: 650,
      totalWinners: 5,
      claimedCount: 2,
      status: 'active',
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 10 * 60 * 1000).toISOString(),
      claims: [
        { userId: '8829106', userName: 'Marcus Aurelius', userAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80', amount: 200, claimedAt: new Date().toISOString() },
        { userId: '8829108', userName: 'Kenji Sato', userAvatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=300&q=80', amount: 150, claimedAt: new Date().toISOString() }
      ]
    };
    this.luckyBags.set(demoBag.id, demoBag);

    // 7.5 Seed Transactions
    const txList: WalletTransaction[] = [
      { id: 'tx-001', userId: '2383452', type: 'recharge', currency: 'coin', amount: 150000, balanceAfter: 1000000, description: 'Monarch Treasure Coin Package Recharge ($99.99)', status: 'completed', timestamp: new Date(Date.now() - 7200000).toISOString(), createdAt: new Date(Date.now() - 7200000).toISOString() },
      { id: 'tx-002', userId: '8829105', type: 'recharge', currency: 'coin', amount: 30000, balanceAfter: 48500, description: 'Diamond VIP Chest Recharge ($24.99)', status: 'completed', timestamp: new Date(Date.now() - 14400000).toISOString(), createdAt: new Date(Date.now() - 14400000).toISOString() },
      { id: 'tx-003', userId: '8829106', type: 'gift_sent', currency: 'coin', amount: 5000, balanceAfter: 85200, description: 'Sent Golden Dragon 🐉 to Sophia Taylor', status: 'completed', timestamp: new Date(Date.now() - 21600000).toISOString(), createdAt: new Date(Date.now() - 21600000).toISOString() },
      { id: 'tx-004', userId: '8829107', type: 'withdraw', currency: 'diamond', amount: 10000, balanceAfter: 15400, description: 'USDT TRC-20 Host Commission Cashout ($100.00)', status: 'completed', timestamp: new Date(Date.now() - 28800000).toISOString(), createdAt: new Date(Date.now() - 28800000).toISOString() },
      { id: 'tx-005', userId: '8829108', type: 'recharge', currency: 'coin', amount: 12000, balanceAfter: 32000, description: 'Pro Host Bundle ($9.99)', status: 'completed', timestamp: new Date(Date.now() - 36000000).toISOString(), createdAt: new Date(Date.now() - 36000000).toISOString() }
    ];
    txList.forEach(t => this.transactions.set(t.id, t));

    // 8. Seed Audit Logs
    const initialLog: AuditLog = {
      id: 'aud-001',
      action: 'SYSTEM_BOOT_SEEDING_COMPLETE',
      module: 'system',
      performedByUserId: '2383452',
      performedByUserName: 'Elena Vance',
      performedByRole: 'ceo',
      details: 'Initialized production PostgreSQL memory simulation with 5 users, 3 rooms, 12 gifts, and staff hierarchy.',
      ipAddress: '127.0.0.1',
      timestamp: new Date().toISOString()
    };
    this.auditLogs.set(initialLog.id, initialLog);

    // 9. Seed Recharge Packages
    this.rechargePackages = [
      // Coin Packages
      { id: 'pkg-coin-1', name: 'Starter Pack', currencyType: 'coin', coins: 1000, bonusCoins: 100, diamonds: 0, priceUsd: 9.99, badge: 'STARTER', popular: false, bestValue: false, isActive: true, sortOrder: 1 },
      { id: 'pkg-coin-2', name: 'Value Pack', currencyType: 'coin', coins: 3000, bonusCoins: 450, diamonds: 0, priceUsd: 29.99, badge: 'POPULAR', popular: true, bestValue: false, isActive: true, sortOrder: 2 },
      { id: 'pkg-coin-3', name: 'Pro Host Bundle', currencyType: 'coin', coins: 5000, bonusCoins: 1000, diamonds: 0, priceUsd: 49.99, badge: 'VALUE', popular: false, bestValue: false, isActive: true, sortOrder: 3 },
      { id: 'pkg-coin-4', name: 'Diamond VIP Chest', currencyType: 'coin', coins: 10000, bonusCoins: 2500, diamonds: 0, priceUsd: 99.99, badge: 'BEST VALUE', popular: false, bestValue: true, isActive: true, sortOrder: 4 },
      { id: 'pkg-coin-5', name: 'Royal Vault', currencyType: 'coin', coins: 25000, bonusCoins: 7000, diamonds: 0, priceUsd: 249.99, badge: 'HOT', popular: false, bestValue: false, isActive: true, sortOrder: 5 },
      { id: 'pkg-coin-6', name: 'Monarch Treasure', currencyType: 'coin', coins: 50000, bonusCoins: 15000, diamonds: 0, priceUsd: 499.99, badge: 'SVIP ONLY', popular: false, bestValue: false, isActive: true, sortOrder: 6 },
      // Diamond Packages
      { id: 'pkg-dia-1', name: '500 Diamonds Pack', currencyType: 'diamond', coins: 0, bonusCoins: 0, diamonds: 500, priceUsd: 9.99, badge: 'STARTER', popular: false, bestValue: false, isActive: true, sortOrder: 7 },
      { id: 'pkg-dia-2', name: '2,000 Diamonds Pack', currencyType: 'diamond', coins: 0, bonusCoins: 0, diamonds: 2000, priceUsd: 39.99, badge: 'POPULAR', popular: true, bestValue: false, isActive: true, sortOrder: 8 },
      { id: 'pkg-dia-3', name: '5,000 Diamonds Pack', currencyType: 'diamond', coins: 0, bonusCoins: 0, diamonds: 5000, priceUsd: 99.99, badge: 'BEST VALUE', popular: false, bestValue: true, isActive: true, sortOrder: 9 }
    ];

    // 10. Seed Staff Activity Logs
    const stfLog: StaffActivityLog = {
      id: 'stf-act-001',
      staffId: 'stf-1',
      staffName: 'Elena Vance',
      staffRole: 'ceo',
      actionType: 'LOGIN',
      targetResource: 'Admin Portal',
      details: 'CEO logged into system console and verified room moderation policies.',
      ipAddress: '127.0.0.1',
      timestamp: new Date().toISOString()
    };
    this.staffActivityLogs.set(stfLog.id, stfLog);

    // 11. Seed Sample Notifications
    const demoNotif: NotificationItem = {
      id: 'notif-001',
      userId: '2383452',
      title: '🎉 Welcome to Aura Voice 2026',
      message: 'Your SVIP Royal Monarch status has been renewed! Enjoy 2x XP and exclusive entrance banners.',
      type: 'system',
      read: false,
      createdAt: new Date().toISOString()
    };
    this.notifications.set('2383452', [demoNotif]);

    // 12. Seed Sample Reports
    const demoRep: ReportItem = {
      id: 'rep-001',
      reporterId: '8829106',
      reporterName: 'Marcus Aurelius',
      targetType: 'room',
      targetId: '8829105',
      reason: 'Spam background noise during gaming tournament match setup.',
      status: 'pending',
      createdAt: new Date().toISOString()
    };
    this.reports.set(demoRep.id, demoRep);

    // 13. Seed Home Page Promotional Banners
    const initialBanners: Banner[] = [
      {
        id: 'bnr-001',
        title: '🎉 Summer PK World Championship',
        subtitle: 'Win 1,000,000 Diamonds & Royal Dragon Frame!',
        description: 'Compete in live voice room battles to claim the legendary dragon frame and huge diamond prizes.',
        type: 'pk',
        targetAction: 'open_event',
        targetUrl: '/events/summer-pk-2026',
        startDate: '2025-01-01T00:00:00.000Z',
        endDate: '2030-12-31T23:59:59.000Z',
        isActive: true,
        sortOrder: 1,
        imageUrl: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=800&q=80',
        createdBy: 'Elena Vance (CEO)',
        createdAt: '2025-01-01T00:00:00.000Z'
      },
      {
        id: 'bnr-002',
        title: '👑 SVIP Exclusive Genesis Club',
        subtitle: 'Unlock customized entrance animations and 10x exp.',
        description: 'Upgrade your privilege level to unlock monarch badge, stealth mode, and custom entry effects.',
        type: 'vip',
        targetAction: 'open_vip',
        startDate: '2025-01-01T00:00:00.000Z',
        endDate: '2030-12-31T23:59:59.000Z',
        isActive: true,
        sortOrder: 2,
        imageUrl: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=800&q=80',
        createdBy: 'Elena Vance (CEO)',
        createdAt: '2025-01-01T00:00:00.000Z'
      },
      {
        id: 'bnr-003',
        title: '🎁 Daily Lucky Bag Rain',
        subtitle: 'Join Top Rooms now to grab free coin drops every hour!',
        description: 'Jump into featured voice party rooms and catch live lucky coin drops dropped by top hosts.',
        type: 'gift',
        targetAction: 'open_recharge',
        startDate: '2025-01-01T00:00:00.000Z',
        endDate: '2030-12-31T23:59:59.000Z',
        isActive: true,
        sortOrder: 3,
        imageUrl: 'https://images.unsplash.com/photo-1513151233558-d860c5398176?auto=format&fit=crop&w=800&q=80',
        createdBy: 'Elena Vance (CEO)',
        createdAt: '2025-01-01T00:00:00.000Z'
      }
    ];

    initialBanners.forEach(b => this.banners.set(b.id, b));

    // Seed Initial Agencies
    const initialAgencies: Agency[] = [
      {
        id: 'ag-01',
        name: 'Alpha Talent Agency',
        code: 'ALPHA77',
        ownerUid: '8829101',
        ownerName: 'Sarah Connor',
        logoUrl: 'https://images.unsplash.com/photo-1560179707-f14e90ef3623?auto=format&fit=crop&w=300&q=80',
        description: 'Premier global talent guild for acoustic music & voice performance hosts.',
        country: 'United States',
        contactInfo: 'alpha@auratalent.com',
        membersCount: 18,
        totalRevenueUsd: 42500,
        commissionRate: 15,
        pendingPayoutUsd: 6375,
        status: 'active',
        createdAt: '2025-01-10T10:00:00.000Z'
      },
      {
        id: 'ag-02',
        name: 'Star Media Global',
        code: 'STAR99',
        ownerUid: '8829102',
        ownerName: 'Marcus Vance',
        logoUrl: 'https://images.unsplash.com/photo-1572021335469-31706a17aaef?auto=format&fit=crop&w=300&q=80',
        description: 'International entertainment guild managing top tier voice artists.',
        country: 'United Kingdom',
        contactInfo: 'management@starmedia.com',
        membersCount: 24,
        totalRevenueUsd: 68900,
        commissionRate: 18,
        pendingPayoutUsd: 12402,
        status: 'active',
        createdAt: '2025-01-15T12:00:00.000Z'
      }
    ];
    initialAgencies.forEach(a => this.agencies.set(a.id, a));

    // Seed Initial Recharge Agents
    const initialAgents: RechargeAgent[] = [
      {
        id: 'ra-01',
        userId: '8829105',
        uid: '8829105',
        name: 'Alex Chen (Regional Super Agent)',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
        creditBalance: 1250000,
        rechargeVolume: 5800000,
        commissionRate: 6,
        totalCommissionEarned: 348000,
        status: 'active',
        notes: 'North America / East Coast territory authorized agent',
        createdAt: '2025-02-01T08:00:00.000Z'
      },
      {
        id: 'ra-02',
        userId: '8829106',
        uid: '8829106',
        name: 'Marcus Aurelius (Asia-Pacific Agent)',
        avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
        creditBalance: 850000,
        rechargeVolume: 3200000,
        commissionRate: 5,
        totalCommissionEarned: 160000,
        status: 'active',
        notes: 'APAC regional distributor',
        createdAt: '2025-02-10T09:30:00.000Z'
      }
    ];
    initialAgents.forEach(ra => this.rechargeAgents.set(ra.id, ra));

    // Seed Initial Merchants
    const initialMerchants: Merchant[] = [
      {
        id: 'mch-01',
        name: 'Stripe Gateway Pro',
        code: 'MCH_STRIPE_01',
        ownerUid: '2383452',
        ownerName: 'Elena Vance (CEO)',
        apiKey: 'pk_live_aura_stripe_9921820491',
        secretKey: 'sk_live_aura_sec_••••••••••••8819',
        feePercentage: 2.9,
        totalProcessedUsd: 145000,
        availableBalanceUsd: 28400,
        pendingSettlementUsd: 4200,
        currency: 'USD',
        webhookUrl: 'https://api.aura.com/webhooks/stripe',
        status: 'active',
        notes: 'Primary credit card gateway',
        createdAt: '2025-01-01T00:00:00.000Z'
      },
      {
        id: 'mch-02',
        name: 'PayPal Global Merchant',
        code: 'MCH_PAYPAL_02',
        ownerUid: '8829100',
        ownerName: 'Elena Vance (CEO)',
        apiKey: 'client_id_paypal_aura_8819284',
        secretKey: 'secret_paypal_••••••••••••3312',
        feePercentage: 3.4,
        totalProcessedUsd: 89000,
        availableBalanceUsd: 15200,
        pendingSettlementUsd: 1800,
        currency: 'USD',
        webhookUrl: 'https://api.aura.com/webhooks/paypal',
        status: 'active',
        notes: 'PayPal wallet integration',
        createdAt: '2025-01-05T00:00:00.000Z'
      }
    ];
    initialMerchants.forEach(m => this.merchants.set(m.id, m));

    // 16. Seed Dynamic Withdrawal Payment Methods
    const initialWithdrawMethods: WithdrawPaymentMethod[] = [
      {
        id: 'wpm-01',
        name: 'bKash',
        type: 'mobile_wallet',
        currency: 'BDT',
        accountFieldLabel: 'bKash Number',
        placeholder: 'Enter your bKash personal/agent number (e.g. 017XXXXXXXX)',
        minWithdraw: 100,
        maxWithdraw: 50000,
        processingFee: 0,
        isActive: true,
        sortOrder: 1,
        createdAt: '2025-01-01T00:00:00.000Z',
        updatedAt: '2025-01-01T00:00:00.000Z',
        createdBy: 'Elena Vance (CEO)'
      },
      {
        id: 'wpm-02',
        name: 'Nagad',
        type: 'mobile_wallet',
        currency: 'BDT',
        accountFieldLabel: 'Nagad Number',
        placeholder: 'Enter your Nagad mobile number (e.g. 019XXXXXXXX)',
        minWithdraw: 100,
        maxWithdraw: 50000,
        processingFee: 0,
        isActive: true,
        sortOrder: 2,
        createdAt: '2025-01-01T00:00:00.000Z',
        updatedAt: '2025-01-01T00:00:00.000Z',
        createdBy: 'Elena Vance (CEO)'
      },
      {
        id: 'wpm-03',
        name: 'Rocket',
        type: 'mobile_wallet',
        currency: 'BDT',
        accountFieldLabel: 'Rocket Account Number',
        placeholder: 'Enter your 12-digit Rocket number with check digit',
        minWithdraw: 100,
        maxWithdraw: 50000,
        processingFee: 0,
        isActive: true,
        sortOrder: 3,
        createdAt: '2025-01-01T00:00:00.000Z',
        updatedAt: '2025-01-01T00:00:00.000Z',
        createdBy: 'Elena Vance (CEO)'
      },
      {
        id: 'wpm-04',
        name: 'Binance USDT',
        type: 'crypto',
        currency: 'USDT',
        accountFieldLabel: 'USDT Wallet Address (TRC20 / BEP20)',
        placeholder: 'Enter TRC20 (T...) or BEP20 (0x...) wallet address',
        minWithdraw: 500,
        maxWithdraw: 100000,
        processingFee: 1.0,
        isActive: true,
        sortOrder: 4,
        createdAt: '2025-01-02T00:00:00.000Z',
        updatedAt: '2025-01-02T00:00:00.000Z',
        createdBy: 'Elena Vance (CEO)'
      },
      {
        id: 'wpm-05',
        name: 'Bank Transfer',
        type: 'bank',
        currency: 'USD',
        accountFieldLabel: 'Bank Account Number & Routing',
        placeholder: 'Account: XXXXXXXXX, Routing: XXXXXXXXX, Bank Name',
        minWithdraw: 1000,
        maxWithdraw: 250000,
        processingFee: 0,
        isActive: true,
        sortOrder: 5,
        createdAt: '2025-01-02T00:00:00.000Z',
        updatedAt: '2025-01-02T00:00:00.000Z',
        createdBy: 'Elena Vance (CEO)'
      },
      {
        id: 'wpm-06',
        name: 'PayPal',
        type: 'paypal',
        currency: 'USD',
        accountFieldLabel: 'PayPal Email',
        placeholder: 'e.g. user@gmail.com / paypal.me username',
        minWithdraw: 200,
        maxWithdraw: 50000,
        processingFee: 2.0,
        isActive: true,
        sortOrder: 6,
        createdAt: '2025-01-03T00:00:00.000Z',
        updatedAt: '2025-01-03T00:00:00.000Z',
        createdBy: 'Elena Vance (CEO)'
      },
      {
        id: 'wpm-07',
        name: 'Chase Bank',
        type: 'bank',
        currency: 'USD',
        accountFieldLabel: 'Chase Account & Wire Routing Number',
        placeholder: 'Enter Chase checking/savings account number',
        minWithdraw: 500,
        maxWithdraw: 200000,
        processingFee: 0,
        isActive: true,
        sortOrder: 7,
        createdAt: '2025-01-04T00:00:00.000Z',
        updatedAt: '2025-01-04T00:00:00.000Z',
        createdBy: 'Elena Vance (CEO)'
      }
    ];
    initialWithdrawMethods.forEach(w => this.withdrawPaymentMethods.set(w.id, w));

    // 17. Seed Initial Ban History Records for demonstration and testing
    const initialBans: BanRecord[] = [
      {
        id: 'ban-001',
        userId: '8829108',
        userUid: '8829108',
        userName: 'Kenji Sato',
        userAvatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=300&q=80',
        banType: 'temporary',
        durationHours: 24,
        reason: 'Inappropriate room background image during live broadcast',
        adminNote: 'Warned via message. First violation temporary suspension.',
        bannedBy: '2383452',
        bannedByName: 'Elena Vance (CEO)',
        bannedByRole: 'ceo',
        bannedAt: new Date(Date.now() - 48 * 3600 * 1000).toISOString(),
        expiresAt: new Date(Date.now() - 24 * 3600 * 1000).toISOString(),
        status: 'expired'
      },
      {
        id: 'ban-002',
        userId: '8829107',
        userUid: '8829107',
        userName: 'Sophia Taylor',
        userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80',
        banType: 'temporary',
        durationHours: 6,
        reason: 'Temporary investigation for suspected unauthorized recharge dispute',
        adminNote: 'Resolved after payment receipt verified by billing dept.',
        bannedBy: '8829106',
        bannedByName: 'Marcus Aurelius',
        bannedByRole: 'gm',
        bannedAt: new Date(Date.now() - 12 * 3600 * 1000).toISOString(),
        expiresAt: new Date(Date.now() - 6 * 3600 * 1000).toISOString(),
        status: 'unbanned',
        unbannedBy: '2383452',
        unbannedByName: 'Elena Vance (CEO)',
        unbannedAt: new Date(Date.now() - 8 * 3600 * 1000).toISOString(),
        unbanReason: 'Payment verified and dispute cleared'
      }
    ];
    initialBans.forEach(b => this.banHistory.set(b.id, b));

    // 18. Seed Initial Benefit Assignments (VIP, SVIP, Profile Frames)
    const initialBenefits: BenefitAssignmentRecord[] = [
      {
        id: 'bnf-001',
        targetUserId: '8829106',
        targetUserUid: '8829106',
        targetUserName: 'Marcus Aurelius',
        targetUserAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
        benefitType: 'svip',
        levelOrFrameId: 'SVIP 3',
        durationDays: 30,
        assignedByUserId: '2383452',
        assignedByUserName: 'Elena Vance (CEO)',
        assignedByRole: 'ceo',
        assignmentMode: 'free_grant',
        status: 'active',
        createdAt: new Date(Date.now() - 5 * 24 * 3600 * 1000).toISOString(),
        expiresAt: new Date(Date.now() + 25 * 24 * 3600 * 1000).toISOString(),
        reason: 'Senior GM platform leadership privilege grant'
      },
      {
        id: 'bnf-002',
        targetUserId: '8829105',
        targetUserUid: '8829105',
        targetUserName: 'Alex Chen',
        targetUserAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
        benefitType: 'frame',
        levelOrFrameId: '⚡ Cyber Pulse',
        durationDays: 'permanent',
        assignedByUserId: '2383452',
        assignedByUserName: 'Elena Vance (CEO)',
        assignedByRole: 'ceo',
        assignmentMode: 'free_grant',
        status: 'active',
        createdAt: new Date(Date.now() - 15 * 24 * 3600 * 1000).toISOString(),
        expiresAt: 'permanent',
        reason: 'Super Admin official special profile frame badge'
      },
      {
        id: 'bnf-003',
        targetUserId: '8829107',
        targetUserUid: '8829107',
        targetUserName: 'Sophia Taylor',
        targetUserAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80',
        benefitType: 'vip',
        levelOrFrameId: 'VIP 2',
        durationDays: 30,
        assignedByUserId: '8829106',
        assignedByUserName: 'Marcus Aurelius',
        assignedByRole: 'gm',
        assignmentMode: 'coin_deduction',
        status: 'active',
        createdAt: new Date(Date.now() - 2 * 24 * 3600 * 1000).toISOString(),
        expiresAt: new Date(Date.now() + 28 * 24 * 3600 * 1000).toISOString(),
        reason: 'Monthly agency top performer recognition'
      }
    ];
    initialBenefits.forEach(bnf => this.benefitAssignments.set(bnf.id, bnf));

    // 19. Seed Production Dynamic Countries
    const initialCountries: Country[] = [
      {
        id: 'bd',
        name: 'Bangladesh',
        countryCode: 'BD',
        iso2: 'BD',
        iso3: 'BGD',
        dialCode: '+880',
        flag: '🇧🇩',
        currencyName: 'Bangladeshi Taka',
        currencyCode: 'BDT',
        currencySymbol: '৳',
        defaultLanguage: 'Bengali',
        timezone: 'Asia/Dhaka',
        status: 'enabled',
        registrationAllowed: true,
        loginAllowed: true,
        rechargeAllowed: true,
        withdrawalAllowed: true,
        voiceRoomAllowed: true,
        paymentMethods: ['bKash', 'Nagad', 'Rocket', 'Binance USDT', 'Upay'],
        withdrawalMethods: ['bKash', 'Nagad', 'Rocket', 'Binance USDT'],
        sortOrder: 1,
        createdAt: '2025-01-01T00:00:00.000Z',
        updatedAt: '2025-01-01T00:00:00.000Z',
        createdBy: 'Elena Vance (CEO)'
      },
      {
        id: 'in',
        name: 'India',
        countryCode: 'IN',
        iso2: 'IN',
        iso3: 'IND',
        dialCode: '+91',
        flag: '🇮🇳',
        currencyName: 'Indian Rupee',
        currencyCode: 'INR',
        currencySymbol: '₹',
        defaultLanguage: 'Hindi',
        timezone: 'Asia/Kolkata',
        status: 'enabled',
        registrationAllowed: true,
        loginAllowed: true,
        rechargeAllowed: true,
        withdrawalAllowed: true,
        voiceRoomAllowed: true,
        paymentMethods: ['UPI', 'Paytm', 'PhonePe', 'Google Pay', 'IMPS Bank Transfer'],
        withdrawalMethods: ['UPI', 'Paytm', 'Bank Transfer (IMPS)'],
        sortOrder: 2,
        createdAt: '2025-01-01T00:00:00.000Z',
        updatedAt: '2025-01-01T00:00:00.000Z',
        createdBy: 'Elena Vance (CEO)'
      },
      {
        id: 'us',
        name: 'United States',
        countryCode: 'US',
        iso2: 'US',
        iso3: 'USA',
        dialCode: '+1',
        flag: '🇺🇸',
        currencyName: 'US Dollar',
        currencyCode: 'USD',
        currencySymbol: '$',
        defaultLanguage: 'English',
        timezone: 'America/New_York',
        status: 'enabled',
        registrationAllowed: true,
        loginAllowed: true,
        rechargeAllowed: true,
        withdrawalAllowed: true,
        voiceRoomAllowed: true,
        paymentMethods: ['Credit/Debit Card', 'PayPal', 'Apple Pay', 'Google Pay', 'Stripe', 'ACH Transfer'],
        withdrawalMethods: ['PayPal', 'ACH Bank Transfer', 'Binance USDT (TRC-20)'],
        sortOrder: 3,
        createdAt: '2025-01-01T00:00:00.000Z',
        updatedAt: '2025-01-01T00:00:00.000Z',
        createdBy: 'Elena Vance (CEO)'
      },
      {
        id: 'sa',
        name: 'Saudi Arabia',
        countryCode: 'SA',
        iso2: 'SA',
        iso3: 'SAU',
        dialCode: '+966',
        flag: '🇸🇦',
        currencyName: 'Saudi Riyal',
        currencyCode: 'SAR',
        currencySymbol: '﷼',
        defaultLanguage: 'Arabic',
        timezone: 'Asia/Riyadh',
        status: 'enabled',
        registrationAllowed: true,
        loginAllowed: true,
        rechargeAllowed: true,
        withdrawalAllowed: true,
        voiceRoomAllowed: true,
        paymentMethods: ['Mada', 'STC Pay', 'Urpay', 'Visa/Mastercard'],
        withdrawalMethods: ['STC Pay', 'Urpay', 'Bank Wire'],
        sortOrder: 4,
        createdAt: '2025-01-01T00:00:00.000Z',
        updatedAt: '2025-01-01T00:00:00.000Z',
        createdBy: 'Elena Vance (CEO)'
      },
      {
        id: 'ae',
        name: 'United Arab Emirates',
        countryCode: 'AE',
        iso2: 'AE',
        iso3: 'ARE',
        dialCode: '+971',
        flag: '🇦🇪',
        currencyName: 'UAE Dirham',
        currencyCode: 'AED',
        currencySymbol: 'د.إ',
        defaultLanguage: 'Arabic',
        timezone: 'Asia/Dubai',
        status: 'enabled',
        registrationAllowed: true,
        loginAllowed: true,
        rechargeAllowed: true,
        withdrawalAllowed: true,
        voiceRoomAllowed: true,
        paymentMethods: ['e& money', 'Careem Pay', 'Apple Pay', 'Credit/Debit Card'],
        withdrawalMethods: ['e& money', 'Careem Pay', 'Bank Wire'],
        sortOrder: 5,
        createdAt: '2025-01-01T00:00:00.000Z',
        updatedAt: '2025-01-01T00:00:00.000Z',
        createdBy: 'Elena Vance (CEO)'
      },
      {
        id: 'gb',
        name: 'United Kingdom',
        countryCode: 'GB',
        iso2: 'GB',
        iso3: 'GBR',
        dialCode: '+44',
        flag: '🇬🇧',
        currencyName: 'British Pound',
        currencyCode: 'GBP',
        currencySymbol: '£',
        defaultLanguage: 'English',
        timezone: 'Europe/London',
        status: 'enabled',
        registrationAllowed: true,
        loginAllowed: true,
        rechargeAllowed: true,
        withdrawalAllowed: true,
        voiceRoomAllowed: true,
        paymentMethods: ['Faster Payments', 'PayPal', 'Revolut', 'Visa/Mastercard'],
        withdrawalMethods: ['Faster Payments (Bank)', 'Revolut', 'PayPal'],
        sortOrder: 6,
        createdAt: '2025-01-01T00:00:00.000Z',
        updatedAt: '2025-01-01T00:00:00.000Z',
        createdBy: 'Elena Vance (CEO)'
      },
      {
        id: 'pk',
        name: 'Pakistan',
        countryCode: 'PK',
        iso2: 'PK',
        iso3: 'PAK',
        dialCode: '+92',
        flag: '🇵🇰',
        currencyName: 'Pakistani Rupee',
        currencyCode: 'PKR',
        currencySymbol: '₨',
        defaultLanguage: 'Urdu',
        timezone: 'Asia/Karachi',
        status: 'enabled',
        registrationAllowed: true,
        loginAllowed: true,
        rechargeAllowed: true,
        withdrawalAllowed: true,
        voiceRoomAllowed: true,
        paymentMethods: ['JazzCash', 'Easypaisa', 'SadaPay', 'NayaPay', 'Bank Transfer'],
        withdrawalMethods: ['JazzCash', 'Easypaisa', 'SadaPay', 'Bank Transfer'],
        sortOrder: 7,
        createdAt: '2025-01-01T00:00:00.000Z',
        updatedAt: '2025-01-01T00:00:00.000Z',
        createdBy: 'Elena Vance (CEO)'
      },
      {
        id: 'ca',
        name: 'Canada',
        countryCode: 'CA',
        iso2: 'CA',
        iso3: 'CAN',
        dialCode: '+1',
        flag: '🇨🇦',
        currencyName: 'Canadian Dollar',
        currencyCode: 'CAD',
        currencySymbol: 'CA$',
        defaultLanguage: 'English',
        timezone: 'America/Toronto',
        status: 'enabled',
        registrationAllowed: true,
        loginAllowed: true,
        rechargeAllowed: true,
        withdrawalAllowed: true,
        voiceRoomAllowed: true,
        paymentMethods: ['Interac e-Transfer', 'Credit Card', 'PayPal'],
        withdrawalMethods: ['Interac e-Transfer', 'Direct Deposit', 'PayPal'],
        sortOrder: 8,
        createdAt: '2025-01-01T00:00:00.000Z',
        updatedAt: '2025-01-01T00:00:00.000Z',
        createdBy: 'Elena Vance (CEO)'
      },
      {
        id: 'de',
        name: 'Germany',
        countryCode: 'DE',
        iso2: 'DE',
        iso3: 'DEU',
        dialCode: '+49',
        flag: '🇩🇪',
        currencyName: 'Euro',
        currencyCode: 'EUR',
        currencySymbol: '€',
        defaultLanguage: 'German',
        timezone: 'Europe/Berlin',
        status: 'enabled',
        registrationAllowed: true,
        loginAllowed: true,
        rechargeAllowed: true,
        withdrawalAllowed: true,
        voiceRoomAllowed: true,
        paymentMethods: ['SEPA Bank Transfer', 'Sofort', 'PayPal', 'Giropay'],
        withdrawalMethods: ['SEPA Bank Transfer', 'PayPal'],
        sortOrder: 9,
        createdAt: '2025-01-01T00:00:00.000Z',
        updatedAt: '2025-01-01T00:00:00.000Z',
        createdBy: 'Elena Vance (CEO)'
      },
      {
        id: 'jp',
        name: 'Japan',
        countryCode: 'JP',
        iso2: 'JP',
        iso3: 'JPN',
        dialCode: '+81',
        flag: '🇯🇵',
        currencyName: 'Japanese Yen',
        currencyCode: 'JPY',
        currencySymbol: '¥',
        defaultLanguage: 'Japanese',
        timezone: 'Asia/Tokyo',
        status: 'enabled',
        registrationAllowed: true,
        loginAllowed: true,
        rechargeAllowed: true,
        withdrawalAllowed: true,
        voiceRoomAllowed: true,
        paymentMethods: ['PayPay', 'Line Pay', 'Convenience Store (Konbini)', 'Credit Card'],
        withdrawalMethods: ['PayPay', 'Bank Transfer (Zengin)'],
        sortOrder: 10,
        createdAt: '2025-01-01T00:00:00.000Z',
        updatedAt: '2025-01-01T00:00:00.000Z',
        createdBy: 'Elena Vance (CEO)'
      }
    ];
    initialCountries.forEach(c => this.countries.set(c.id, c));

    // Seed RBAC Modules
    DEFAULT_RBAC_MODULES.forEach(m => this.rbacModules.set(m.key, { ...m }));

    // Seed RBAC Permissions
    DEFAULT_RBAC_PERMISSIONS.forEach(p => this.rbacPermissions.set(p.key, { ...p }));

    // Seed RBAC Roles
    (Object.keys(DEFAULT_ROLE_CONFIGS) as UserRole[]).forEach(r => {
      const cfg = DEFAULT_ROLE_CONFIGS[r];
      this.rbacRoles.set(r, {
        ...cfg,
        permissions: { ...cfg.permissions },
        canGrantRoles: [...cfg.canGrantRoles] as any
      });
    });

    // 20. Seed Initial Social Connections & Requests
    const initialFriendConn: Connection = {
      id: 'friend-2383452_8829105',
      type: 'friend',
      user1Id: '2383452',
      user2Id: '8829105',
      level: 1,
      intimacyPoints: 120,
      sharedGiftsCount: 2,
      sharedGiftsCoins: 1200,
      status: 'active',
      establishedAt: new Date(Date.now() - 14 * 24 * 3600 * 1000).toISOString(),
      updatedAt: new Date().toISOString()
    };
    this.connections.set(initialFriendConn.id, initialFriendConn);

    const friendConn2: Connection = {
      id: 'friend-8829106_8829107',
      type: 'friend',
      user1Id: '8829106',
      user2Id: '8829107',
      level: 1,
      intimacyPoints: 340,
      sharedGiftsCount: 5,
      sharedGiftsCoins: 4800,
      status: 'active',
      establishedAt: new Date(Date.now() - 20 * 24 * 3600 * 1000).toISOString(),
      updatedAt: new Date().toISOString()
    };
    this.connections.set(friendConn2.id, friendConn2);

    const friendConn3: Connection = {
      id: 'friend-8829105_8829108',
      type: 'friend',
      user1Id: '8829105',
      user2Id: '8829108',
      level: 1,
      intimacyPoints: 80,
      sharedGiftsCount: 1,
      sharedGiftsCoins: 500,
      status: 'active',
      establishedAt: new Date(Date.now() - 5 * 24 * 3600 * 1000).toISOString(),
      updatedAt: new Date().toISOString()
    };
    this.connections.set(friendConn3.id, friendConn3);

    // CP Couple 1: Alex Chen & Sophia Taylor (Soulmates Lv 3)
    const cpConn1: Connection = {
      id: 'cp-8829105_8829107',
      type: 'cp',
      user1Id: '8829105',
      user2Id: '8829107',
      level: 3,
      intimacyPoints: 4250,
      sharedGiftsCount: 18,
      sharedGiftsCoins: 36000,
      status: 'active',
      establishedAt: new Date(Date.now() - 45 * 24 * 3600 * 1000).toISOString(),
      updatedAt: new Date().toISOString()
    };
    this.connections.set(cpConn1.id, cpConn1);

    // CP Couple 2: Marcus Aurelius & Kenji Sato (Sweet Romance Lv 2)
    const cpConn2: Connection = {
      id: 'cp-8829106_8829108',
      type: 'cp',
      user1Id: '8829106',
      user2Id: '8829108',
      level: 2,
      intimacyPoints: 1680,
      sharedGiftsCount: 9,
      sharedGiftsCoins: 12500,
      status: 'active',
      establishedAt: new Date(Date.now() - 18 * 24 * 3600 * 1000).toISOString(),
      updatedAt: new Date().toISOString()
    };
    this.connections.set(cpConn2.id, cpConn2);

    // CP Couple 3: Past / Terminated CP for testing filter & history
    const cpConn3: Connection = {
      id: 'cp-8829108_8829109',
      type: 'cp',
      user1Id: '8829108',
      user2Id: '8829109',
      level: 1,
      intimacyPoints: 410,
      sharedGiftsCount: 3,
      sharedGiftsCoins: 2100,
      status: 'terminated',
      establishedAt: new Date(Date.now() - 80 * 24 * 3600 * 1000).toISOString(),
      updatedAt: new Date(Date.now() - 10 * 24 * 3600 * 1000).toISOString()
    };
    this.connections.set(cpConn3.id, cpConn3);

    const initialFriendReq: ConnectionRequest = {
      id: 'req-friend-sample-01',
      type: 'friend',
      senderId: '8829106',
      receiverId: '2383452',
      status: 'pending',
      message: 'Hey Elena! Loved your recent voice room party. Let\'s connect! 👥',
      createdAt: new Date(Date.now() - 2 * 3600 * 1000).toISOString(),
      updatedAt: new Date().toISOString()
    };
    this.connectionRequests.set(initialFriendReq.id, initialFriendReq);

    const initialCpReq: ConnectionRequest = {
      id: 'req-cp-sample-01',
      type: 'cp',
      senderId: '8829109',
      receiverId: '2383452',
      status: 'pending',
      message: 'Would you like to be my CP partner on Nigo? ❤️',
      createdAt: new Date(Date.now() - 5 * 3600 * 1000).toISOString(),
      updatedAt: new Date().toISOString()
    };
    this.connectionRequests.set(initialCpReq.id, initialCpReq);

    const cpReqDeclined: ConnectionRequest = {
      id: 'req-cp-sample-02',
      type: 'cp',
      senderId: '8829106',
      receiverId: '8829105',
      status: 'declined',
      message: 'Let\'s become CP partners! 💖',
      createdAt: new Date(Date.now() - 25 * 24 * 3600 * 1000).toISOString(),
      updatedAt: new Date(Date.now() - 24 * 24 * 3600 * 1000).toISOString()
    };
    this.connectionRequests.set(cpReqDeclined.id, cpReqDeclined);

    // Blocked user sample
    const sampleBlock: BlockedUserRecord = {
      id: 'blk-8829109_8829108',
      userId: '8829109',
      blockedUserId: '8829108',
      createdAt: new Date(Date.now() - 9 * 24 * 3600 * 1000).toISOString()
    };
    this.blockedUsers.set(sampleBlock.id, sampleBlock);
  }

  /**
   * Automatically expires temporary bans where banExpiresAt <= Date.now()
   */
  public checkAndExpireBans(): void {
    const now = Date.now();
    for (const user of this.users.values()) {
      if (user.status === 'banned' && user.banType === 'temporary' && user.banExpiresAt) {
        const expTime = new Date(user.banExpiresAt).getTime();
        if (expTime <= now) {
          user.status = 'active';
          delete user.banType;
          delete user.banReason;
          delete user.banNote;
          delete user.banStartedAt;
          delete user.banExpiresAt;
          this.users.set(user.id, user);

          // Update active ban record in banHistory
          for (const record of this.banHistory.values()) {
            if (record.userId === user.id && record.status === 'active') {
              record.status = 'expired';
              this.banHistory.set(record.id, record);
            }
          }

          this.recordAudit({
            action: 'USER_BAN_EXPIRED',
            module: 'security',
            performedByUserId: 'system',
            performedByUserName: 'System Auto-Scheduler',
            performedByRole: 'ceo',
            targetId: user.id,
            targetName: user.name,
            details: `Temporary ban for user [${user.name}] (${user.uid}) has automatically expired. Account restored to ACTIVE status.`,
            ipAddress: '127.0.0.1'
          });
        }
      }
    }
  }

  /**
   * Check if a given user is currently actively banned
   */
  public isUserBanned(userId: string): { isBanned: boolean; reason?: string; expiresAt?: string; banType?: 'temporary' | 'permanent'; bannedBy?: string } {
    this.checkAndExpireBans();
    const user = this.users.get(userId);
    if (!user) return { isBanned: false };

    if (user.status === 'banned') {
      return {
        isBanned: true,
        reason: user.banReason || 'Account suspended by platform security administration.',
        expiresAt: user.banExpiresAt,
        banType: user.banType || 'permanent',
        bannedBy: user.bannedByName || user.bannedBy || 'Platform Security'
      };
    }
    return { isBanned: false };
  }

  /**
   * Ban a user (temporary or permanent)
   */
  public banUser(params: {
    adminId: string;
    adminName: string;
    adminRole: UserRole;
    adminUid?: string;
    targetUserId: string;
    banType: 'temporary' | 'permanent';
    durationHours?: number;
    reason: string;
    adminNote?: string;
    ipAddress?: string;
  }): { success: boolean; user: User; banRecord: BanRecord } {
    this.checkAndExpireBans();
    const targetUser = this.users.get(params.targetUserId);
    if (!targetUser) {
      throw new Error('Target user not found');
    }

    const now = new Date();
    const bannedAt = now.toISOString();
    let expiresAt: string | undefined = undefined;

    if (params.banType === 'temporary') {
      const hours = Math.max(1, Number(params.durationHours) || 24);
      const expDate = new Date(now.getTime() + hours * 3600 * 1000);
      expiresAt = expDate.toISOString();
    }

    // Update target user fields without altering wallet/VIP/family/badges data
    targetUser.status = 'banned';
    targetUser.banType = params.banType;
    targetUser.banReason = params.reason;
    targetUser.banNote = params.adminNote;
    targetUser.banStartedAt = bannedAt;
    targetUser.banExpiresAt = expiresAt;
    targetUser.bannedBy = params.adminId;
    targetUser.bannedByName = params.adminName;
    targetUser.bannedByRole = params.adminRole;
    targetUser.isOnline = false; // Disconnect session

    this.users.set(targetUser.id, targetUser);

    // Create Ban History record
    const banRecord: BanRecord = {
      id: `ban-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      userId: targetUser.id,
      userUid: targetUser.uid,
      userName: targetUser.name,
      userAvatar: targetUser.avatar,
      banType: params.banType,
      durationHours: params.durationHours,
      reason: params.reason,
      adminNote: params.adminNote,
      bannedBy: params.adminId,
      bannedByName: params.adminName,
      bannedByRole: params.adminRole,
      bannedAt,
      expiresAt,
      status: 'active'
    };

    this.banHistory.set(banRecord.id, banRecord);

    // System Audit Log
    this.recordAudit({
      action: 'USER_BANNED',
      module: 'security',
      performedByUserId: params.adminId,
      performedByUserName: params.adminName,
      performedByRole: params.adminRole,
      targetId: targetUser.id,
      targetName: targetUser.name,
      reason: params.reason,
      details: `Staff ${params.adminName} (${params.adminRole.toUpperCase()}) banned user [${targetUser.name}] (UID: ${targetUser.uid}, ID: ${targetUser.id}). Type: ${params.banType.toUpperCase()}${expiresAt ? `, Expires: ${expiresAt}` : ' (Permanent)'}. Reason: ${params.reason}${params.adminNote ? `. Note: ${params.adminNote}` : ''}`,
      ipAddress: params.ipAddress || '127.0.0.1'
    });

    // Staff Activity Log
    this.recordStaffActivity({
      staffId: params.adminId,
      staffName: params.adminName,
      staffRole: params.adminRole,
      actionType: 'USER_BAN',
      targetResource: `User: ${targetUser.name} (${targetUser.uid})`,
      details: `${params.banType.toUpperCase()} ban applied. Reason: ${params.reason}`,
      ipAddress: params.ipAddress || '127.0.0.1'
    });

    return { success: true, user: targetUser, banRecord };
  }

  /**
   * Unban a user
   */
  public unbanUser(params: {
    adminId: string;
    adminName: string;
    adminRole: UserRole;
    targetUserId: string;
    reason?: string;
    ipAddress?: string;
  }): { success: boolean; user: User } {
    this.checkAndExpireBans();
    const targetUser = this.users.get(params.targetUserId);
    if (!targetUser) {
      throw new Error('Target user not found');
    }

    const previousBanType = targetUser.banType || 'permanent';
    const unbannedAt = new Date().toISOString();

    targetUser.status = 'active';
    delete targetUser.banType;
    delete targetUser.banReason;
    delete targetUser.banNote;
    delete targetUser.banStartedAt;
    delete targetUser.banExpiresAt;
    targetUser.unbannedAt = unbannedAt;
    targetUser.unbannedBy = params.adminId;
    targetUser.unbannedByName = params.adminName;

    this.users.set(targetUser.id, targetUser);

    // Update Ban Records for this user in banHistory
    for (const record of this.banHistory.values()) {
      if (record.userId === targetUser.id && record.status === 'active') {
        record.status = 'unbanned';
        record.unbannedBy = params.adminId;
        record.unbannedByName = params.adminName;
        record.unbannedAt = unbannedAt;
        record.unbanReason = params.reason || 'Manual unban by authorized staff administrator';
        this.banHistory.set(record.id, record);
      }
    }

    // System Audit Log
    this.recordAudit({
      action: 'USER_UNBANNED',
      module: 'security',
      performedByUserId: params.adminId,
      performedByUserName: params.adminName,
      performedByRole: params.adminRole,
      targetId: targetUser.id,
      targetName: targetUser.name,
      reason: params.reason,
      details: `Staff ${params.adminName} (${params.adminRole.toUpperCase()}) unbanned user [${targetUser.name}] (UID: ${targetUser.uid}, ID: ${targetUser.id}). Previous ban type: ${previousBanType}. Reason: ${params.reason || 'Restored platform access'}`,
      ipAddress: params.ipAddress || '127.0.0.1'
    });

    // Staff Activity Log
    this.recordStaffActivity({
      staffId: params.adminId,
      staffName: params.adminName,
      staffRole: params.adminRole,
      actionType: 'ROLE_CHANGE',
      targetResource: `User: ${targetUser.name} (${targetUser.uid})`,
      details: `User unbanned and restored to ACTIVE status. Reason: ${params.reason || 'Access restored'}`,
      ipAddress: params.ipAddress || '127.0.0.1'
    });

    return { success: true, user: targetUser };
  }

  /**
   * Get all Ban History records with optional filtering
   */
  public getBanHistory(filter?: { status?: string; search?: string }): BanRecord[] {
    this.checkAndExpireBans();
    let records = Array.from(this.banHistory.values());

    if (filter?.status && filter.status !== 'all') {
      if (filter.status === 'permanent') {
        records = records.filter(r => r.banType === 'permanent' && r.status === 'active');
      } else {
        records = records.filter(r => r.status === filter.status);
      }
    }

    if (filter?.search && filter.search.trim()) {
      const q = filter.search.toLowerCase().trim();
      records = records.filter(r => 
        r.userName.toLowerCase().includes(q) ||
        r.userUid.toLowerCase().includes(q) ||
        r.userId.toLowerCase().includes(q) ||
        r.reason.toLowerCase().includes(q) ||
        (r.adminNote && r.adminNote.toLowerCase().includes(q)) ||
        r.bannedByName.toLowerCase().includes(q) ||
        (r.unbannedByName && r.unbannedByName.toLowerCase().includes(q))
      );
    }

    return records.sort((a, b) => new Date(b.bannedAt).getTime() - new Date(a.bannedAt).getTime());
  }

  public recordAudit(log: Omit<AuditLog, 'id' | 'timestamp'>): AuditLog {
    const newLog: AuditLog = {
      ...log,
      id: `aud-${Date.now()}-${Math.floor(Math.random()*1000)}`,
      timestamp: new Date().toISOString()
    };
    this.auditLogs.set(newLog.id, newLog);
    return newLog;
  }

  public recordStaffActivity(log: Omit<StaffActivityLog, 'id' | 'timestamp'>): StaffActivityLog {
    const newLog: StaffActivityLog = {
      ...log,
      id: `stf-act-${Date.now()}-${Math.floor(Math.random()*1000)}`,
      timestamp: new Date().toISOString()
    };
    this.staffActivityLogs.set(newLog.id, newLog);
    return newLog;
  }

  public addNotification(userId: string, item: Omit<NotificationItem, 'id' | 'createdAt' | 'read' | 'userId'>): NotificationItem {
    const list = this.notifications.get(userId) || [];
    const newNotif: NotificationItem = {
      ...item,
      id: `notif-${Date.now()}-${Math.floor(Math.random()*1000)}`,
      userId,
      read: false,
      createdAt: new Date().toISOString()
    };
    list.unshift(newNotif);
    this.notifications.set(userId, list);
    return newNotif;
  }

  public getAdminAppearance(): AdminAppearanceSettings {
    return this.adminAppearance;
  }

  public setAdminAppearance(appearance: AdminAppearanceSettings): AdminAppearanceSettings {
    this.adminAppearance = appearance;
    return this.adminAppearance;
  }
}

export const dbStore = new MemoryStore();
