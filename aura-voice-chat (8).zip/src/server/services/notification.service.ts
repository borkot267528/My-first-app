/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { dbStore } from '../db/store';
import { NotificationItem } from '../../types';

export class NotificationService {
  public static getUserNotifications(userId: string): NotificationItem[] {
    return dbStore.notifications.get(userId) || [];
  }

  public static markAsRead(userId: string, notificationId?: string): NotificationItem[] {
    const list = dbStore.notifications.get(userId) || [];
    list.forEach(item => {
      if (!notificationId || item.id === notificationId) {
        item.read = true;
      }
    });
    dbStore.notifications.set(userId, list);
    return list;
  }

  public static sendNotification(userId: string, title: string, message: string, type: NotificationItem['type'] = 'system', link?: string): NotificationItem {
    const user = dbStore.users.get(userId);
    if (!user) throw new Error('User not found');

    return dbStore.addNotification(userId, {
      title,
      message,
      type,
      link
    });
  }

  public static broadcastSystemNotification(title: string, message: string, link?: string): number {
    let count = 0;
    for (const userId of dbStore.users.keys()) {
      dbStore.addNotification(userId, {
        title: `📢 ${title}`,
        message,
        type: 'system',
        link
      });
      count++;
    }

    dbStore.recordAudit({
      action: 'SYSTEM_BROADCAST_NOTIFICATION',
      module: 'system',
      performedByUserId: 'system',
      performedByUserName: 'System Admin',
      performedByRole: 'ceo',
      details: `Broadcasted "${title}" to ${count} users.`,
      ipAddress: '127.0.0.1'
    });

    return count;
  }
}
