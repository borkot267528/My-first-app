/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { dbStore } from '../db/store';
import { AuthService } from './auth.service';
import { PermissionService } from './permission.service';
import { WalletService } from './wallet.service';
import { RoomService } from './room.service';
import { MessageService } from './message.service';
import { NotificationService } from './notification.service';
import { AdminService } from './admin.service';
import { VirtualGiftService } from './virtualGift.service';

export interface TestResult {
  suite: string;
  testName: string;
  passed: boolean;
  durationMs: number;
  message?: string;
}

export class TestSuiteService {
  public static async runAllTests(): Promise<{ totalTests: number; passed: number; failed: number; results: TestResult[]; timestamp: string }> {
    const results: TestResult[] = [];
    const startTime = Date.now();

    // Helper for running individual assertions
    const assertTest = (suite: string, name: string, fn: () => void) => {
      const t0 = Date.now();
      try {
        fn();
        results.push({ suite, testName: name, passed: true, durationMs: Date.now() - t0 });
      } catch (err: any) {
        results.push({ suite, testName: name, passed: false, durationMs: Date.now() - t0, message: err.message });
      }
    };

    // 1. Test Database Schema & Repository Persistence
    assertTest('1. Database & Repository', 'Verify PostgreSQL table metadata & seed users count', () => {
      if (dbStore.users.size < 5) throw new Error('Expected at least 5 seed users in repository');
      if (dbStore.rooms.size < 3) throw new Error('Expected at least 3 active voice rooms');
    });

    // 2. Test Firebase Auth & JWT
    assertTest('2. Firebase Auth & JWT', 'Simulate Firebase Auth token verification & JWT generation', () => {
      const authRes = AuthService.simulateFirebaseAuth('firebase-test-101', 'test.user@auravoice.io', 'Test User 101');
      if (!authRes.tokens.accessToken || !authRes.user.id) throw new Error('Failed to generate JWT token or create user');
      const verified = AuthService.verifyToken(authRes.tokens.accessToken);
      if (!verified || verified.email !== 'test.user@auravoice.io') throw new Error('JWT token verification failed');
    });

    // 3. Test RBAC Permission System
    assertTest('3. Role-Based Permissions (RBAC)', 'Verify role hierarchies and granular permissions', () => {
      const canCeoBan = PermissionService.hasPermission('ceo', 'users:ban');
      const canUserBan = PermissionService.hasPermission('user', 'users:ban');
      if (!canCeoBan) throw new Error('CEO should have permission to ban users');
      if (canUserBan) throw new Error('Standard user should not have permission to ban users');
      if (!PermissionService.hasRoleOrHigher('super_admin', 'host')) throw new Error('Super Admin hierarchy failure');
    });

    // 4. Test Audit Logs & Staff Activity Logs
    assertTest('4. Audit & Staff Activity Logs', 'Record audit event and staff moderation log', () => {
      const initAuditCount = dbStore.auditLogs.size;
      const initStaffCount = dbStore.staffActivityLogs.size;
      
      dbStore.recordAudit({
        action: 'TEST_AUDIT_ACTION',
        module: 'system',
        performedByUserId: '2383452',
        performedByUserName: 'Elena Vance',
        performedByRole: 'ceo',
        details: 'Automated test execution audit record',
        ipAddress: '127.0.0.1'
      });

      dbStore.recordStaffActivity({
        staffId: 'stf-1',
        staffName: 'Elena Vance',
        staffRole: 'ceo',
        actionType: 'SYSTEM_CONFIG',
        targetResource: 'Test Suite',
        details: 'Verified test automation execution',
        ipAddress: '127.0.0.1'
      });

      if (dbStore.auditLogs.size <= initAuditCount) throw new Error('Audit log was not persisted');
      if (dbStore.staffActivityLogs.size <= initStaffCount) throw new Error('Staff activity log was not persisted');
    });

    // 5. Test Wallet, Recharge, Withdrawal, and Transactions
    assertTest('5. Wallet Ledger & Recharge', 'Recharge coins and convert to diamonds via gift sending', () => {
      const initCoins = dbStore.users.get('2383452')?.coins || 0;
      WalletService.recharge('2383452', 5000, 0, 'Test recharge package');
      const newCoins = dbStore.users.get('2383452')?.coins || 0;
      if (newCoins !== initCoins + 5000) throw new Error('Wallet balance did not increase correctly');

      // Send gift from 2383452 to 8829106
      WalletService.sendGift('2383452', '8829106', 'gft-1', 2);
    });

    // 6. Test Withdrawal Moderation
    assertTest('6. Withdrawal System', 'Submit withdrawal request and moderate approval', () => {
      const tx = WalletService.withdraw('2383452', 100, 'Test Bank Account #991');
      if (tx.status !== 'pending') throw new Error('Withdrawal request should start as pending');
      const moderated = WalletService.moderateWithdrawal('2383452', tx.id, 'completed', 'Approved via test suite');
      if (moderated.status !== 'completed') throw new Error('Withdrawal moderation failed to complete');
    });

    // 7. Test Voice Room Backend & PK Battle
    assertTest('7. Voice Room & PK Battle', 'Create room, join mic seat, start PK battle and score', () => {
      const room = RoomService.createRoom('2383452', 'Test Automation Room', 'Automated integration testing', 'popular');
      const emptySeat = room.seats.find(s => !s.userId && !s.isLocked && s.index > 0);
      if (emptySeat) {
        RoomService.joinSeat(room.id, '8829106', emptySeat.index);
      }
      
      const rooms = Array.from(dbStore.rooms.values());
      const roomAId = rooms[0]?.id || '2383452';
      const roomBId = rooms[1]?.id || '8829105';
      const battle = RoomService.startPkBattle(roomAId, roomBId, 300);
      RoomService.updatePkScore(battle.id, 500, 300);
      if (battle.roomAScore !== 500 || battle.roomBScore !== 300) throw new Error('PK score matching error');
    });

    // 8. Test Messaging Backend & Notification System
    assertTest('8. Messaging & Notifications', 'Send private 1-on-1 DM and broadcast system notification', () => {
      const dm = MessageService.sendPrivateMessage('2383452', '8829106', 'Hello from test suite!', 'text');
      if (!dm.id || dm.content !== 'Hello from test suite!') throw new Error('Private message dispatch failed');

      const count = NotificationService.broadcastSystemNotification('Test Alert', 'All backend services operating at 100% capacity.');
      if (count < 5) throw new Error('Broadcast notification failed to reach all users');
    });

    // 9. Test Admin Dashboard APIs, Reports, and Analytics
    assertTest('9. Admin APIs & Analytics Overview', 'Retrieve executive analytics and moderate moderation report', () => {
      const overview = AdminService.getAnalyticsOverview();
      if (overview.totalUsers < 5 || overview.activeRooms < 3) throw new Error('Analytics calculations inaccurate');
      
      const report = AdminService.moderateReport('2383452', 'rep-001', 'resolved', 'Investigated and resolved during test');
      if (report.status !== 'resolved') throw new Error('Report moderation failed');
    });

    // 10. Test Security & Health Audit
    assertTest('10. Security & Health Audit', 'Verify rate limiter, JWT algorithms, and database connection state', () => {
      const secReport = AdminService.getSecurityAuditReport();
      if (secReport.status !== 'SECURE_PRODUCTION_READY') throw new Error('Security status check failed');
    });

    // 11. Test VirtualGiftService (Inventory, Balance Deduction & Notification Triggering)
    assertTest('11. VirtualGiftService', 'Handle gift inventory, balance deduction, backpack, and room notifications', () => {
      // 1. Inventory Catalog & Stats
      const catalog = VirtualGiftService.getAllGifts();
      if (!catalog || catalog.length < 5) throw new Error('Expected at least 5 gifts in catalog inventory');
      const stats = VirtualGiftService.getInventoryStats();
      if (stats.totalGifts !== catalog.length) throw new Error('Inventory stats count mismatch');

      // 2. Personal Backpack Inventory
      const seedItem = VirtualGiftService.addUserGiftInventory('2383452', 'gft-1', 3, 'spin');
      if (seedItem.quantity < 3) throw new Error('Failed to add item to user backpack');
      const userBackpack = VirtualGiftService.getUserGiftInventory('2383452');
      if (!userBackpack.some(b => b.giftId === 'gft-1')) throw new Error('Backpack did not contain added gift');

      // 3. Balance Deduction & Voice Room Notification Triggering
      const user = dbStore.users.get('2383452');
      if (!user) throw new Error('Test user not found');
      if (user.coins < 200) {
        user.coins += 1000;
        dbStore.users.set('2383452', user);
      }
      const initialCoins = user.coins;

      const receiver = dbStore.users.get('8829106');
      if (!receiver) throw new Error('Receiver user not found');
      const initialDiamonds = receiver.diamonds;

      const sendRes = VirtualGiftService.sendGiftInVoiceRoom({
        senderId: '2383452',
        receiverId: '8829106',
        giftId: 'gft-1',
        count: 2,
        roomId: 'room-101'
      });

      if (!sendRes.success) throw new Error('Gift sending failed');
      if (sendRes.totalCostCoins !== 20) throw new Error('Incorrect total coin cost deduction');
      if (sendRes.senderNewCoinBalance !== initialCoins - 20) throw new Error('Sender coins were not deducted properly');
      if (sendRes.receiverNewDiamondBalance < initialDiamonds + 10) throw new Error('Receiver did not receive diamonds');
      if (!sendRes.notificationsSent.receiverNotificationId) throw new Error('Receiver notification was not triggered');
      if (!sendRes.notificationsSent.roomBroadcast) throw new Error('Room broadcast notification was not triggered');
    });

    // 12. Test Firebase & Wallet Currency Management (Recharge, Balance, Ledger)
    assertTest('12. Firebase & Wallet Currency', 'Verify user coin balance, recharge packages, bonus tiers, and audit persistence', () => {
      const user = dbStore.users.get('2383452');
      if (!user) throw new Error('Target user for wallet test not found');
      
      const initialCoins = user.coins;
      const rechargeAmount = 10000;

      const tx = WalletService.recharge('2383452', rechargeAmount, 0, 'Firebase Wallet Test Pack');
      if (tx.balanceAfter !== initialCoins + rechargeAmount) {
        throw new Error('Recharge did not accurately update user coin balance');
      }

      // Verify transaction ledger entry
      const recordedTx = dbStore.transactions.get(tx.id);
      if (!recordedTx || recordedTx.type !== 'recharge' || recordedTx.amount !== rechargeAmount) {
        throw new Error('Wallet transaction audit ledger entry was not correctly recorded');
      }
    });

    // 13. Test User Search Functionality (Search by UID & Display Name)
    assertTest('13. User Search System', 'Search users by unique User ID (UID) and display name with security sanitization', () => {
      const allUsers = Array.from(dbStore.users.values());
      if (allUsers.length === 0) throw new Error('No users available to test search');

      // Test UID search
      const targetUser = allUsers[0];
      const targetUid = targetUser.uid;
      const matchedByUid = allUsers.filter(u => u.uid.toLowerCase().includes(targetUid.toLowerCase()));
      if (matchedByUid.length === 0) throw new Error(`User Search by UID "${targetUid}" failed`);

      // Test Display Name search
      const targetName = targetUser.name.split(' ')[0].toLowerCase();
      const matchedByName = allUsers.filter(u => u.name.toLowerCase().includes(targetName));
      if (matchedByName.length === 0) throw new Error(`User Search by Display Name "${targetName}" failed`);

      // Ensure no passwords are leaked
      const sanitized = allUsers.map(u => {
        const { password, ...safe } = u as any;
        return safe;
      });
      if (sanitized.some(u => u.password !== undefined)) {
        throw new Error('Search result sanitization failed: password field was exposed');
      }
    });

    const passed = results.filter(r => r.passed).length;
    const failed = results.filter(r => !r.passed).length;

    return {
      totalTests: results.length,
      passed,
      failed,
      results,
      timestamp: new Date().toISOString()
    };
  }
}
