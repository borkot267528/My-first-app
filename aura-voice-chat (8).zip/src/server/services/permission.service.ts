/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { 
  UserRole, 
  PermissionAccessLevel, 
  EffectivePermissionResult 
} from '../../types';
import { dbStore } from '../db/store';
import { isAccessLevelSufficient, DEFAULT_ROLE_CONFIGS, ROLE_HIERARCHY } from '../../lib/rbacDefaults';

export { ROLE_HIERARCHY };

export class PermissionService {
  public static hasRoleOrHigher(userRole: UserRole, requiredRole: UserRole): boolean {
    return (ROLE_HIERARCHY[userRole] || 0) >= (ROLE_HIERARCHY[requiredRole] || 0);
  }

  /**
   * Evaluates if a role or specific user holds sufficient dynamic permissions.
   * Checks Staff Override first -> Dynamic Role Configuration -> Semantic Fallbacks.
   * CEO always returns true (absolute safeguard).
   */
  public static hasPermission(
    userRole: UserRole, 
    permission: string, 
    customPermissions: string[] = [],
    requiredLevel: PermissionAccessLevel = 'VIEW',
    userId?: string
  ): boolean {
    // 1. Absolute CEO Safeguard
    if (userRole === 'ceo') return true;

    // 2. Direct wildcard in custom permissions
    if (customPermissions.includes('*') || customPermissions.includes('all')) return true;
    if (customPermissions.includes(permission)) return true;

    // 3. Check individual staff overrides if userId provided
    if (userId && dbStore.rbacStaffOverrides.has(userId)) {
      const override = dbStore.rbacStaffOverrides.get(userId);
      if (override && override.overrides && override.overrides[permission] !== undefined) {
        const level = override.overrides[permission];
        if (level === 'NONE') return false; // Explicitly revoked
        return isAccessLevelSufficient(level, requiredLevel);
      }
    }

    // 4. Check dynamic role configuration from dbStore
    const dynamicRole = dbStore.rbacRoles.get(userRole) || DEFAULT_ROLE_CONFIGS[userRole];
    if (dynamicRole && dynamicRole.permissions) {
      if (dynamicRole.permissions['*'] === 'FULL') return true;

      const directLevel = dynamicRole.permissions[permission];
      if (directLevel !== undefined) {
        if (directLevel === 'NONE') return false;
        return isAccessLevelSufficient(directLevel, requiredLevel);
      }
    }

    // 5. Semantic Aliases & Sub-permission Fallbacks
    const aliasCheck = this.checkSemanticAliases(userRole, permission, requiredLevel, userId);
    if (aliasCheck !== null) return aliasCheck;

    return false;
  }

  private static checkSemanticAliases(
    userRole: UserRole, 
    permission: string, 
    requiredLevel: PermissionAccessLevel,
    userId?: string
  ): boolean | null {
    switch (permission) {
      case 'admin:access':
        // Staff roles above standard user have admin access if they have at least one VIEW perm
        return userRole !== 'user';
      case 'users:manage':
        return this.hasPermission(userRole, 'users:edit_profile', [], requiredLevel, userId) ||
               this.hasPermission(userRole, 'users:ban', [], requiredLevel, userId);
      case 'rooms:manage':
        return this.hasPermission(userRole, 'rooms:moderate', [], requiredLevel, userId) ||
               this.hasPermission(userRole, 'rooms:lock', [], requiredLevel, userId);
      case 'wallet:view':
        return this.hasPermission(userRole, 'wallet:view_transactions', [], requiredLevel, userId);
      case 'wallet:manage':
        return this.hasPermission(userRole, 'wallet:manage_user', [], requiredLevel, userId) ||
               this.hasPermission(userRole, 'wallet:recharge', [], requiredLevel, userId);
      case 'staff:assign':
        return this.hasPermission(userRole, 'staff:assign_role', [], requiredLevel, userId);
      case 'families:manage':
        return this.hasPermission(userRole, 'family:create_edit', [], requiredLevel, userId) ||
               this.hasPermission(userRole, 'family:manage_members', [], requiredLevel, userId);
      case 'settings:manage':
        return this.hasPermission(userRole, 'settings:appearance', [], requiredLevel, userId) ||
               this.hasPermission(userRole, 'countries:manage', [], requiredLevel, userId);
      default:
        return null;
    }
  }

  /**
   * Validates whether an executor can grant/assign a target role.
   * Evaluates Dynamic Role Grant Authority and Role Hierarchy.
   */
  public static canGrantRole(
    executorRole: UserRole,
    targetRole: UserRole,
    executorUserId?: string
  ): { allowed: boolean; status: number; error?: string } {
    if (executorRole === 'ceo') {
      return { allowed: true, status: 200 };
    }

    if (targetRole === 'ceo') {
      return {
        allowed: false,
        status: 403,
        error: '⛔ PERMISSION DENIED: CEO role is immutable and cannot be assigned by other staff.'
      };
    }

    const execRank = ROLE_HIERARCHY[executorRole] || 0;
    const targetRank = ROLE_HIERARCHY[targetRole] || 0;

    // Strict hierarchy rule: cannot grant equal or higher role
    if (targetRank >= execRank) {
      return {
        allowed: false,
        status: 403,
        error: `⛔ PERMISSION DENIED: You cannot grant a role with equal or higher rank (${targetRole.toUpperCase()}).`
      };
    }

    // Check dynamic grant authority configuration
    const roleConfig = dbStore.rbacRoles.get(executorRole) || DEFAULT_ROLE_CONFIGS[executorRole];
    const allowedGrants = roleConfig ? roleConfig.canGrantRoles : [];

    const isWildcard = (allowedGrants as string[]).includes('*');
    const isExplicitlyAllowed = (allowedGrants as string[]).includes(targetRole);

    if (!isWildcard && !isExplicitlyAllowed) {
      return {
        allowed: false,
        status: 403,
        error: `⛔ PERMISSION DENIED: Role ${executorRole.toUpperCase()} does not possess grant authority for ${targetRole.toUpperCase()}.`
      };
    }

    return { allowed: true, status: 200 };
  }

  /**
   * Retrieves effective consolidated permissions for a role/user.
   */
  public static getEffectivePermissions(role: UserRole, userId?: string): EffectivePermissionResult {
    const isCeo = role === 'ceo';
    const roleConfig = dbStore.rbacRoles.get(role) || DEFAULT_ROLE_CONFIGS[role];
    const rolePermissions = roleConfig ? { ...roleConfig.permissions } : {};
    const canGrantRoles = roleConfig ? roleConfig.canGrantRoles : [];

    let overrides: Record<string, PermissionAccessLevel> = {};
    if (userId && dbStore.rbacStaffOverrides.has(userId)) {
      const overrideObj = dbStore.rbacStaffOverrides.get(userId);
      if (overrideObj && overrideObj.overrides) {
        overrides = { ...overrideObj.overrides };
      }
    }

    const effectivePermissions: Record<string, PermissionAccessLevel> = { ...rolePermissions };

    // Apply overrides
    Object.keys(overrides).forEach(key => {
      effectivePermissions[key] = overrides[key];
    });

    if (isCeo) {
      effectivePermissions['*'] = 'FULL';
      effectivePermissions['users:edit_uid'] = 'FULL';
    }

    return {
      userId,
      role,
      isCeo,
      rolePermissions,
      overrides,
      effectivePermissions,
      canGrantRoles
    };
  }

  public static canBanUser(
    executorRole: UserRole,
    executorPermissions: string[] = [],
    targetRole?: UserRole,
    executorUserId?: string
  ): { allowed: boolean; status: number; error?: string } {
    if (executorRole === 'ceo') {
      return { allowed: true, status: 200 };
    }

    const hasBanPerm = this.hasPermission(executorRole, 'users:ban', executorPermissions, 'MANAGE', executorUserId) ||
                       this.hasPermission(executorRole, 'users:manage', executorPermissions, 'MANAGE', executorUserId);

    if (!hasBanPerm) {
      return {
        allowed: false,
        status: 403,
        error: '⛔ PERMISSION DENIED: You do not possess the required "users:ban" moderation permission.'
      };
    }

    // Role hierarchy check
    if (targetRole) {
      if (targetRole === 'ceo') {
        return {
          allowed: false,
          status: 403,
          error: '⛔ PERMISSION DENIED: Non-CEO staff members cannot ban the Platform CEO.'
        };
      }

      const execRank = ROLE_HIERARCHY[executorRole] || 0;
      const targetRank = ROLE_HIERARCHY[targetRole] || 0;

      if (targetRank >= execRank) {
        return {
          allowed: false,
          status: 403,
          error: `⛔ PERMISSION DENIED: You cannot ban staff member with equal or higher role rank (${targetRole.toUpperCase()}).`
        };
      }
    }

    return { allowed: true, status: 200 };
  }

  public static canUnbanUser(
    executorRole: UserRole,
    executorPermissions: string[] = [],
    targetRole?: UserRole,
    executorUserId?: string
  ): { allowed: boolean; status: number; error?: string } {
    if (executorRole === 'ceo') {
      return { allowed: true, status: 200 };
    }

    const hasUnbanPerm = this.hasPermission(executorRole, 'users:ban', executorPermissions, 'MANAGE', executorUserId) ||
                         this.hasPermission(executorRole, 'users:manage', executorPermissions, 'MANAGE', executorUserId);

    if (!hasUnbanPerm) {
      return {
        allowed: false,
        status: 403,
        error: '⛔ PERMISSION DENIED: You do not possess the required "users:ban" moderation permission.'
      };
    }

    if (targetRole && targetRole === 'ceo') {
      return {
        allowed: false,
        status: 403,
        error: '⛔ PERMISSION DENIED: Action not authorized on CEO account.'
      };
    }

    return { allowed: true, status: 200 };
  }

  public static canEditUserUid(
    executorRole?: string, 
    targetRole?: string, 
    executorUserId?: string
  ): { allowed: boolean; status: number; error?: string } {
    const normRole = (executorRole || '').toLowerCase() as UserRole;
    if (normRole === 'ceo') {
      return { allowed: true, status: 200 };
    }

    // Dynamic permission check for users:edit_uid with CEO protection
    const hasUidPerm = this.hasPermission(normRole, 'users:edit_uid', [], 'MANAGE', executorUserId);
    if (!hasUidPerm) {
      return {
        allowed: false,
        status: 403,
        error: '⛔ PERMISSION DENIED: Editing User UID is a CEO-Protected permission that is not granted to your account.'
      };
    }

    const normTargetRole = (targetRole || '').toLowerCase();
    if (normTargetRole === 'ceo') {
      return {
        allowed: false,
        status: 403,
        error: '⛔ PERMISSION DENIED: Non-CEO staff members cannot edit the UID of the CEO.'
      };
    }

    return { allowed: true, status: 200 };
  }

  public static canManageFamily(
    executorRole: UserRole,
    executorPermissions: string[] = [],
    action: 'create' | 'edit' | 'suspend' | 'delete' | 'members' = 'edit',
    executorUserId?: string
  ): { allowed: boolean; status: number; error?: string } {
    if (executorRole === 'ceo') return { allowed: true, status: 200 };

    const actionPermMap: Record<string, string> = {
      create: 'family:create_edit',
      edit: 'family:create_edit',
      suspend: 'family:suspend_delete',
      delete: 'family:suspend_delete',
      members: 'family:manage_members'
    };

    const permKey = actionPermMap[action] || 'families:view';
    const hasPerm = this.hasPermission(executorRole, permKey, executorPermissions, 'MANAGE', executorUserId);

    if (!hasPerm) {
      return {
        allowed: false,
        status: 403,
        error: `⛔ PERMISSION DENIED: You do not possess the required "${permKey}" permission to perform "${action}" on Families.`
      };
    }

    return { allowed: true, status: 200 };
  }
}
