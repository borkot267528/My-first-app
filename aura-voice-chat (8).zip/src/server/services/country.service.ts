/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { dbStore } from '../db/store';
import { Country, CountryFormData, User } from '../../types';

export class CountryService {
  /**
   * Get all countries, optionally filtered by status or search keyword
   */
  public static getAllCountries(filters?: { status?: string; search?: string }): Country[] {
    let list = Array.from(dbStore.countries.values());

    if (filters?.status && filters.status !== 'all') {
      list = list.filter(c => c.status === filters.status);
    }

    if (filters?.search && filters.search.trim()) {
      const q = filters.search.trim().toLowerCase();
      list = list.filter(c => 
        c.name.toLowerCase().includes(q) ||
        c.iso2.toLowerCase().includes(q) ||
        c.iso3.toLowerCase().includes(q) ||
        c.dialCode.toLowerCase().includes(q) ||
        c.currencyCode.toLowerCase().includes(q) ||
        c.currencyName.toLowerCase().includes(q)
      );
    }

    // Sort by sortOrder ascending, then name
    return list.sort((a, b) => {
      const orderA = a.sortOrder !== undefined ? a.sortOrder : 999;
      const orderB = b.sortOrder !== undefined ? b.sortOrder : 999;
      if (orderA !== orderB) return orderA - orderB;
      return a.name.localeCompare(b.name);
    });
  }

  /**
   * Get active/enabled countries for client app dropdowns (registration, profile, recharge, withdrawal)
   */
  public static getEnabledCountries(): Country[] {
    return Array.from(dbStore.countries.values())
      .filter(c => c.status === 'enabled')
      .sort((a, b) => {
        const orderA = a.sortOrder !== undefined ? a.sortOrder : 999;
        const orderB = b.sortOrder !== undefined ? b.sortOrder : 999;
        if (orderA !== orderB) return orderA - orderB;
        return a.name.localeCompare(b.name);
      });
  }

  /**
   * Get single country by ID, ISO2, ISO3 or name
   */
  public static getCountryById(idOrCode: string): Country | null {
    if (!idOrCode) return null;
    const country = dbStore.countries.get(idOrCode);
    return country || null;
  }

  /**
   * Validate country input fields
   */
  private static validateCountryData(data: Partial<CountryFormData>, existingCountryId?: string): void {
    if (!data.name || !data.name.trim()) {
      throw new Error('Country name is required');
    }
    if (!data.iso2 || !data.iso2.trim()) {
      throw new Error('ISO 2-letter code is required');
    }
    const iso2 = data.iso2.trim().toUpperCase();
    if (iso2.length !== 2 || !/^[A-Z]{2}$/.test(iso2)) {
      throw new Error('ISO 2-letter code must be exactly 2 alphabetical characters (e.g. BD, US, IN)');
    }

    if (!data.iso3 || !data.iso3.trim()) {
      throw new Error('ISO 3-letter code is required');
    }
    const iso3 = data.iso3.trim().toUpperCase();
    if (iso3.length !== 3 || !/^[A-Z]{3}$/.test(iso3)) {
      throw new Error('ISO 3-letter code must be exactly 3 alphabetical characters (e.g. BGD, USA, IND)');
    }

    if (!data.dialCode || !data.dialCode.trim()) {
      throw new Error('Dial code is required');
    }
    const dialCode = data.dialCode.trim();
    if (!/^\+\d{1,6}$/.test(dialCode)) {
      throw new Error('Dial code must start with "+" followed by 1 to 6 digits (e.g. +880, +1, +91)');
    }

    if (!data.currencyCode || !data.currencyCode.trim()) {
      throw new Error('Currency code is required (e.g. BDT, USD, EUR)');
    }
    if (!data.currencySymbol || !data.currencySymbol.trim()) {
      throw new Error('Currency symbol is required (e.g. ৳, $, €)');
    }

    // Uniqueness validation
    for (const c of dbStore.countries.values()) {
      if (existingCountryId && c.id === existingCountryId) continue;
      
      if (c.iso2.toUpperCase() === iso2) {
        throw new Error(`ISO 2-letter code "${iso2}" is already in use by ${c.name}`);
      }
      if (c.iso3.toUpperCase() === iso3) {
        throw new Error(`ISO 3-letter code "${iso3}" is already in use by ${c.name}`);
      }
      if (c.dialCode.trim() === dialCode) {
        // Dial code warning or conflict check (note: some countries share dial codes like US/CA +1)
        if (c.name.toLowerCase() === data.name.trim().toLowerCase()) {
          throw new Error(`A country with name "${c.name}" already exists`);
        }
      }
    }
  }

  /**
   * Create a new country (Admin Only)
   */
  public static async createCountry(adminUser: User, input: CountryFormData): Promise<Country> {
    this.validateCountryData(input);

    const iso2 = input.iso2.trim().toUpperCase();
    const iso3 = input.iso3.trim().toUpperCase();
    const id = iso2.toLowerCase();

    // Check if ID already taken
    if (dbStore.countries.has(id)) {
      throw new Error(`Country with ID/code "${id}" already exists`);
    }

    const now = new Date().toISOString();
    const newCountry: Country = {
      id,
      name: input.name.trim(),
      countryCode: iso2,
      iso2,
      iso3,
      dialCode: input.dialCode.trim(),
      flag: input.flag?.trim() || '🌐',
      currencyName: input.currencyName?.trim() || `${iso3} Currency`,
      currencyCode: input.currencyCode.trim().toUpperCase(),
      currencySymbol: input.currencySymbol.trim(),
      defaultLanguage: input.defaultLanguage?.trim() || 'English',
      timezone: input.timezone?.trim() || 'UTC',
      status: input.status || 'enabled',
      registrationAllowed: input.registrationAllowed !== false,
      loginAllowed: input.loginAllowed !== false,
      rechargeAllowed: input.rechargeAllowed !== false,
      withdrawalAllowed: input.withdrawalAllowed !== false,
      voiceRoomAllowed: input.voiceRoomAllowed !== false,
      paymentMethods: Array.isArray(input.paymentMethods) 
        ? input.paymentMethods.map(m => m.trim()).filter(Boolean)
        : [],
      withdrawalMethods: Array.isArray(input.withdrawalMethods)
        ? input.withdrawalMethods.map(m => m.trim()).filter(Boolean)
        : (Array.isArray(input.paymentMethods) ? input.paymentMethods.map(m => m.trim()).filter(Boolean) : []),
      sortOrder: input.sortOrder !== undefined ? Number(input.sortOrder) : dbStore.countries.size + 1,
      createdAt: now,
      updatedAt: now,
      createdBy: `${adminUser.name} (${adminUser.role.toUpperCase()})`,
      updatedBy: `${adminUser.name} (${adminUser.role.toUpperCase()})`
    };

    // Store in memory
    dbStore.countries.set(newCountry.id, newCountry);

    // Persist to Firestore
    await dbStore.persistCountryToFirestore(newCountry);

    // Audit Log
    dbStore.recordAudit({
      action: 'ADMIN_COUNTRY_CREATED',
      module: 'system',
      performedByUserId: adminUser.id,
      performedByUserName: adminUser.name,
      performedByRole: adminUser.role,
      targetId: newCountry.id,
      details: `Created new country: ${newCountry.name} (${newCountry.iso2}, Dial: ${newCountry.dialCode}, Currency: ${newCountry.currencyCode}) with status: ${newCountry.status.toUpperCase()}`,
      ipAddress: '127.0.0.1'
    });

    return newCountry;
  }

  /**
   * Update an existing country (Admin Only)
   */
  public static async updateCountry(adminUser: User, countryId: string, input: Partial<CountryFormData>): Promise<Country> {
    const country = dbStore.countries.get(countryId);
    if (!country) {
      throw new Error(`Country with ID "${countryId}" not found`);
    }

    const mergedData: CountryFormData = {
      name: input.name !== undefined ? input.name : country.name,
      iso2: input.iso2 !== undefined ? input.iso2 : country.iso2,
      iso3: input.iso3 !== undefined ? input.iso3 : country.iso3,
      dialCode: input.dialCode !== undefined ? input.dialCode : country.dialCode,
      flag: input.flag !== undefined ? input.flag : country.flag,
      currencyName: input.currencyName !== undefined ? input.currencyName : country.currencyName,
      currencyCode: input.currencyCode !== undefined ? input.currencyCode : country.currencyCode,
      currencySymbol: input.currencySymbol !== undefined ? input.currencySymbol : country.currencySymbol,
      defaultLanguage: input.defaultLanguage !== undefined ? input.defaultLanguage : country.defaultLanguage,
      timezone: input.timezone !== undefined ? input.timezone : country.timezone,
      status: input.status !== undefined ? input.status : country.status,
      registrationAllowed: input.registrationAllowed !== undefined ? input.registrationAllowed : country.registrationAllowed,
      loginAllowed: input.loginAllowed !== undefined ? input.loginAllowed : country.loginAllowed,
      rechargeAllowed: input.rechargeAllowed !== undefined ? input.rechargeAllowed : country.rechargeAllowed,
      withdrawalAllowed: input.withdrawalAllowed !== undefined ? input.withdrawalAllowed : country.withdrawalAllowed,
      voiceRoomAllowed: input.voiceRoomAllowed !== undefined ? input.voiceRoomAllowed : country.voiceRoomAllowed,
      paymentMethods: input.paymentMethods !== undefined ? input.paymentMethods : country.paymentMethods,
      withdrawalMethods: input.withdrawalMethods !== undefined ? input.withdrawalMethods : (country.withdrawalMethods || country.paymentMethods),
      sortOrder: input.sortOrder !== undefined ? Number(input.sortOrder) : country.sortOrder
    };

    this.validateCountryData(mergedData, country.id);

    const previousSnapshot = { ...country };
    const now = new Date().toISOString();

    country.name = mergedData.name.trim();
    country.countryCode = mergedData.iso2.trim().toUpperCase();
    country.iso2 = mergedData.iso2.trim().toUpperCase();
    country.iso3 = mergedData.iso3.trim().toUpperCase();
    country.dialCode = mergedData.dialCode.trim();
    country.flag = mergedData.flag?.trim() || country.flag;
    country.currencyName = mergedData.currencyName?.trim() || country.currencyName;
    country.currencyCode = mergedData.currencyCode.trim().toUpperCase();
    country.currencySymbol = mergedData.currencySymbol.trim();
    country.defaultLanguage = mergedData.defaultLanguage?.trim() || country.defaultLanguage;
    country.timezone = mergedData.timezone?.trim() || country.timezone;
    country.status = mergedData.status;
    country.registrationAllowed = mergedData.registrationAllowed;
    country.loginAllowed = mergedData.loginAllowed;
    country.rechargeAllowed = mergedData.rechargeAllowed;
    country.withdrawalAllowed = mergedData.withdrawalAllowed;
    country.voiceRoomAllowed = mergedData.voiceRoomAllowed;
    country.paymentMethods = Array.isArray(mergedData.paymentMethods)
      ? mergedData.paymentMethods.map(m => m.trim()).filter(Boolean)
      : country.paymentMethods;
    country.withdrawalMethods = Array.isArray(mergedData.withdrawalMethods)
      ? mergedData.withdrawalMethods.map(m => m.trim()).filter(Boolean)
      : (country.withdrawalMethods || country.paymentMethods);
    country.sortOrder = mergedData.sortOrder !== undefined ? Number(mergedData.sortOrder) : country.sortOrder;
    country.updatedAt = now;
    country.updatedBy = `${adminUser.name} (${adminUser.role.toUpperCase()})`;

    // Save in memory
    dbStore.countries.set(country.id, country);

    // Persist to Firestore
    await dbStore.persistCountryToFirestore(country);

    // Audit Log
    dbStore.recordAudit({
      action: 'ADMIN_COUNTRY_UPDATED',
      module: 'system',
      performedByUserId: adminUser.id,
      performedByUserName: adminUser.name,
      performedByRole: adminUser.role,
      targetId: country.id,
      details: `Updated country ${country.name} (${country.iso2}). Previous status: ${previousSnapshot.status}, New status: ${country.status}. Currency: ${country.currencyCode} (${country.currencySymbol})`,
      ipAddress: '127.0.0.1'
    });

    return country;
  }

  /**
   * Toggle country status (enabled / disabled)
   */
  public static async toggleCountryStatus(adminUser: User, countryId: string, status: 'enabled' | 'disabled'): Promise<Country> {
    const country = dbStore.countries.get(countryId);
    if (!country) {
      throw new Error(`Country with ID "${countryId}" not found`);
    }

    const previousStatus = country.status;
    country.status = status;
    country.updatedAt = new Date().toISOString();
    country.updatedBy = `${adminUser.name} (${adminUser.role.toUpperCase()})`;

    dbStore.countries.set(country.id, country);
    await dbStore.persistCountryToFirestore(country);

    dbStore.recordAudit({
      action: 'ADMIN_COUNTRY_STATUS_TOGGLED',
      module: 'system',
      performedByUserId: adminUser.id,
      performedByUserName: adminUser.name,
      performedByRole: adminUser.role,
      targetId: country.id,
      details: `Country "${country.name}" status changed from "${previousStatus}" to "${status}"`,
      ipAddress: '127.0.0.1'
    });

    return country;
  }

  /**
   * Count how many registered users are currently associated with this country
   */
  public static getAssociatedUsersCount(countryId: string): number {
    const country = dbStore.countries.get(countryId);
    if (!country) return 0;

    const normalizedName = country.name.toLowerCase().trim();
    const iso2 = country.iso2.toLowerCase().trim();

    let count = 0;
    for (const u of dbStore.users.values()) {
      if (
        (u.countryId && u.countryId.toLowerCase() === country.id.toLowerCase()) ||
        (u.countryCode && u.countryCode.toLowerCase() === iso2) ||
        (u.country && u.country.toLowerCase().trim() === normalizedName)
      ) {
        count++;
      }
    }
    return count;
  }

  /**
   * Safely delete a country.
   * STRICT DELETION POLICY:
   * Do NOT permanently delete a country if users are already associated with that country.
   * Instead, reject deletion with clear instructions to Disable the country.
   */
  public static async deleteCountry(adminUser: User, countryId: string): Promise<{ deleted: boolean; countryId: string; message: string }> {
    const country = dbStore.countries.get(countryId);
    if (!country) {
      throw new Error(`Country with ID "${countryId}" not found`);
    }

    // Safety check: count associated users
    const associatedUsersCount = this.getAssociatedUsersCount(countryId);
    if (associatedUsersCount > 0) {
      throw new Error(
        `Cannot delete country "${country.name}" because ${associatedUsersCount} registered user(s) are currently associated with it. To prevent data corruption and preserve user profiles, please disable this country instead (Status: Disabled).`
      );
    }

    const previousData = { ...country };

    // Delete from memory
    dbStore.countries.delete(country.id);

    // Delete from Firestore
    await dbStore.deleteCountryFromFirestore(country.id);

    // Audit Log
    dbStore.recordAudit({
      action: 'ADMIN_COUNTRY_DELETED',
      module: 'system',
      performedByUserId: adminUser.id,
      performedByUserName: adminUser.name,
      performedByRole: adminUser.role,
      targetId: countryId,
      details: `Permanently deleted country: ${previousData.name} (${previousData.iso2}). Verified 0 associated active users.`,
      ipAddress: '127.0.0.1'
    });

    return {
      deleted: true,
      countryId,
      message: `Country "${previousData.name}" was safely deleted.`
    };
  }

  /**
   * Get configured payment methods for a given user or country
   */
  public static getCountryPaymentMethods(countryIdOrName?: string): { rechargeMethods: string[]; withdrawalMethods: string[]; currency: string; currencySymbol: string } {
    if (!countryIdOrName) {
      const defaultCountry = dbStore.countries.get('bd') || dbStore.countries.get('us');
      return {
        rechargeMethods: defaultCountry?.paymentMethods || ['Credit/Debit Card', 'PayPal'],
        withdrawalMethods: defaultCountry?.withdrawalMethods || ['Bank Transfer'],
        currency: defaultCountry?.currencyCode || 'USD',
        currencySymbol: defaultCountry?.currencySymbol || '$'
      };
    }

    const country = dbStore.countries.get(countryIdOrName);
    if (!country) {
      return {
        rechargeMethods: ['Credit/Debit Card', 'PayPal'],
        withdrawalMethods: ['Bank Transfer'],
        currency: 'USD',
        currencySymbol: '$'
      };
    }

    return {
      rechargeMethods: country.rechargeAllowed ? country.paymentMethods : [],
      withdrawalMethods: country.withdrawalAllowed ? (country.withdrawalMethods || country.paymentMethods) : [],
      currency: country.currencyCode,
      currencySymbol: country.currencySymbol
    };
  }
}
