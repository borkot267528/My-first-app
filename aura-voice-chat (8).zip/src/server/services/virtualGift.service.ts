/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { dbStore } from '../db/store';
import { 
  Gift, 
  UserGiftInventoryItem, 
  SendGiftParams, 
  SendGiftResult, 
  GiftInventoryStats,
  WalletTransaction,
  VoiceRoom,
  ContributorLeaderboardCategory,
  ContributorLeaderboardPeriod,
  ContributorLeaderboardItem,
  ContributorLeaderboardResponse
} from '../../types';
import { ConnectionService } from './connection.service';
import { NotificationService } from './notification.service';
import { RoomService } from './room.service';

export class VirtualGiftService {
  // =========================================================================
  // 1. SYSTEM GIFT CATALOG & INVENTORY MANAGEMENT
  // =========================================================================

  /**
   * Retrieves all gifts from the catalog inventory with optional filtering and sorting.
   */
  public static getAllGifts(filter?: {
    category?: string;
    search?: string;
    minPrice?: number;
    maxPrice?: number;
    inStockOnly?: boolean;
    sortBy?: 'price_asc' | 'price_desc' | 'popular' | 'name';
  }): Gift[] {
    let gifts = Array.from(dbStore.gifts.values());

    if (!filter) return gifts;

    // Filter by category
    if (filter.category && filter.category !== 'all') {
      gifts = gifts.filter(g => g.category === filter.category);
    }

    // Filter by search query
    if (filter.search && filter.search.trim()) {
      const q = filter.search.toLowerCase().trim();
      gifts = gifts.filter(g => 
        g.name.toLowerCase().includes(q) || 
        (g.description && g.description.toLowerCase().includes(q)) ||
        (g.tags && g.tags.some(t => t.toLowerCase().includes(q)))
      );
    }

    // Filter by price range
    if (filter.minPrice !== undefined) {
      gifts = gifts.filter(g => g.priceCoins >= filter.minPrice!);
    }
    if (filter.maxPrice !== undefined) {
      gifts = gifts.filter(g => g.priceCoins <= filter.maxPrice!);
    }

    // Filter by availability / stock
    if (filter.inStockOnly) {
      gifts = gifts.filter(g => 
        g.isAvailable !== false && 
        (g.stockQuantity === undefined || g.stockQuantity === -1 || g.stockQuantity > 0)
      );
    }

    // Sorting
    if (filter.sortBy === 'price_asc') {
      gifts.sort((a, b) => a.priceCoins - b.priceCoins);
    } else if (filter.sortBy === 'price_desc') {
      gifts.sort((a, b) => b.priceCoins - a.priceCoins);
    } else if (filter.sortBy === 'name') {
      gifts.sort((a, b) => a.name.localeCompare(b.name));
    }

    return gifts;
  }

  /**
   * Gets a single gift by its unique identifier.
   */
  public static getGiftById(giftId: string): Gift | undefined {
    return dbStore.gifts.get(giftId);
  }

  /**
   * Checks whether a requested gift has sufficient inventory stock.
   */
  public static checkGiftAvailability(giftId: string, count: number = 1): { 
    available: boolean; 
    error?: string; 
    remainingStock?: number;
    gift?: Gift;
  } {
    const gift = dbStore.gifts.get(giftId);
    if (!gift) {
      return { available: false, error: `Gift with ID ${giftId} not found in catalog.` };
    }

    if (gift.isAvailable === false) {
      return { available: false, error: `${gift.name} is currently unavailable for purchase.` };
    }

    if (gift.stockQuantity !== undefined && gift.stockQuantity !== -1) {
      if (gift.stockQuantity < count) {
        return { 
          available: false, 
          error: `Insufficient stock for ${gift.name}. Available: ${gift.stockQuantity}, Requested: ${count}`,
          remainingStock: gift.stockQuantity,
          gift
        };
      }
      return { available: true, remainingStock: gift.stockQuantity, gift };
    }

    return { available: true, remainingStock: -1, gift };
  }

  /**
   * Adds a new virtual gift into the platform catalog inventory (Staff/Admin).
   */
  public static addGiftToCatalog(adminId: string, giftData: Partial<Gift>): Gift {
    const admin = dbStore.users.get(adminId);
    const newId = giftData.id || `gft-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

    const newGift: Gift = {
      id: newId,
      name: giftData.name || 'New Virtual Gift',
      icon: giftData.icon || '🎁',
      priceCoins: Math.max(1, Number(giftData.priceCoins) || 10),
      category: giftData.category || 'popular',
      animationType: giftData.animationType || 'pop',
      svgColor: giftData.svgColor || '#ec4899',
      description: giftData.description || 'Virtual gift effect for live rooms.',
      stockQuantity: giftData.stockQuantity !== undefined ? Number(giftData.stockQuantity) : -1,
      isAvailable: giftData.isAvailable !== false,
      diamondYieldRate: giftData.diamondYieldRate !== undefined ? Number(giftData.diamondYieldRate) : 0.5,
      rarity: giftData.rarity || 'common',
      tags: giftData.tags || ['gift', 'custom'],
      createdAt: new Date().toISOString()
    };

    dbStore.gifts.set(newId, newGift);

    dbStore.recordAudit({
      action: 'VIRTUAL_GIFT_CREATED',
      module: 'gift',
      performedByUserId: adminId,
      performedByUserName: admin ? admin.name : 'Admin',
      performedByRole: admin ? admin.role : 'ceo',
      targetId: newId,
      targetName: newGift.name,
      details: `Added new gift ${newGift.name} (${newId}) for ${newGift.priceCoins} coins.`,
      ipAddress: '127.0.0.1'
    });

    return newGift;
  }

  /**
   * Updates an existing virtual gift in the catalog inventory (Staff/Admin).
   */
  public static updateGiftInCatalog(adminId: string, giftId: string, updates: Partial<Gift>): Gift {
    const existing = dbStore.gifts.get(giftId);
    if (!existing) {
      throw new Error(`Gift with ID ${giftId} not found`);
    }

    const admin = dbStore.users.get(adminId);
    const updated: Gift = {
      ...existing,
      ...updates,
      id: existing.id,
      priceCoins: updates.priceCoins !== undefined ? Math.max(1, Number(updates.priceCoins)) : existing.priceCoins,
      stockQuantity: updates.stockQuantity !== undefined ? Number(updates.stockQuantity) : existing.stockQuantity,
      diamondYieldRate: updates.diamondYieldRate !== undefined ? Number(updates.diamondYieldRate) : existing.diamondYieldRate
    };

    dbStore.gifts.set(giftId, updated);

    dbStore.recordAudit({
      action: 'VIRTUAL_GIFT_UPDATED',
      module: 'gift',
      performedByUserId: adminId,
      performedByUserName: admin ? admin.name : 'Admin',
      performedByRole: admin ? admin.role : 'ceo',
      targetId: giftId,
      targetName: updated.name,
      details: `Updated gift ${updated.name} (${giftId}): Price ${existing.priceCoins} -> ${updated.priceCoins}, Stock ${existing.stockQuantity ?? 'Inf'} -> ${updated.stockQuantity ?? 'Inf'}`,
      ipAddress: '127.0.0.1'
    });

    return updated;
  }

  /**
   * Deletes or archives a gift from the catalog inventory.
   */
  public static deleteGiftFromCatalog(adminId: string, giftId: string): boolean {
    const gift = dbStore.gifts.get(giftId);
    if (!gift) throw new Error(`Gift with ID ${giftId} not found`);

    const admin = dbStore.users.get(adminId);
    dbStore.gifts.delete(giftId);

    dbStore.recordAudit({
      action: 'VIRTUAL_GIFT_DELETED',
      module: 'gift',
      performedByUserId: adminId,
      performedByUserName: admin ? admin.name : 'Admin',
      performedByRole: admin ? admin.role : 'ceo',
      targetId: giftId,
      targetName: gift.name,
      details: `Deleted gift ${gift.name} (${giftId}) from platform inventory.`,
      ipAddress: '127.0.0.1'
    });

    return true;
  }

  /**
   * Generates comprehensive gift inventory analytics & counts.
   */
  public static getInventoryStats(): GiftInventoryStats {
    const all = Array.from(dbStore.gifts.values());
    const categoryCounts: Record<string, number> = {};
    const rarityCounts: Record<string, number> = {};
    let totalInStock = 0;

    all.forEach(g => {
      categoryCounts[g.category] = (categoryCounts[g.category] || 0) + 1;
      const rarity = g.rarity || 'common';
      rarityCounts[rarity] = (rarityCounts[rarity] || 0) + 1;
      if (g.stockQuantity && g.stockQuantity > 0) {
        totalInStock += g.stockQuantity;
      }
    });

    // Top gifts by popularity / luxury
    const mostPopularGifts = [...all].sort((a, b) => b.priceCoins - a.priceCoins).slice(0, 5);

    return {
      totalGifts: all.length,
      totalCategories: Object.keys(categoryCounts).length,
      categoryCounts,
      rarityCounts,
      totalInStock,
      mostPopularGifts
    };
  }

  // =========================================================================
  // 2. USER BACKPACK & PERSONAL GIFT INVENTORY
  // =========================================================================

  /**
   * Returns all items currently stored in a user's backpack inventory.
   */
  public static getUserGiftInventory(userId: string): UserGiftInventoryItem[] {
    const userMap = dbStore.userGiftInventories.get(userId);
    if (!userMap) return [];

    const items: UserGiftInventoryItem[] = [];
    userMap.forEach(item => {
      if (item.quantity > 0) {
        const giftDetails = dbStore.gifts.get(item.giftId);
        items.push({
          ...item,
          gift: giftDetails || item.gift
        });
      }
    });

    return items;
  }

  /**
   * Gets the owned count of a specific gift in the user's backpack inventory.
   */
  public static getUserGiftQuantity(userId: string, giftId: string): number {
    const userMap = dbStore.userGiftInventories.get(userId);
    if (!userMap) return 0;
    const item = userMap.get(giftId);
    return item ? Math.max(0, item.quantity) : 0;
  }

  /**
   * Adds a gift into a user's personal inventory (from spin, event drop, reward, or bundle).
   */
  public static addUserGiftInventory(
    userId: string, 
    giftId: string, 
    quantity: number, 
    source: UserGiftInventoryItem['source'] = 'reward'
  ): UserGiftInventoryItem {
    if (quantity <= 0) throw new Error('Quantity must be greater than zero');
    const gift = dbStore.gifts.get(giftId);
    if (!gift) throw new Error(`Gift ${giftId} not found`);

    let userMap = dbStore.userGiftInventories.get(userId);
    if (!userMap) {
      userMap = new Map();
      dbStore.userGiftInventories.set(userId, userMap);
    }

    const existing = userMap.get(giftId);
    if (existing) {
      existing.quantity += quantity;
      existing.acquiredAt = new Date().toISOString();
      existing.gift = gift;
      return existing;
    }

    const newItem: UserGiftInventoryItem = {
      id: `inv-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      userId,
      giftId,
      quantity,
      gift,
      acquiredAt: new Date().toISOString(),
      source
    };

    userMap.set(giftId, newItem);

    // Send in-app notification about receiving inventory gift
    NotificationService.sendNotification(
      userId,
      `🎒 New Gift Added to Backpack!`,
      `You acquired ${quantity}x ${gift.name}! You can send this gift for free from your inventory.`,
      'gift'
    );

    return newItem;
  }

  /**
   * Deducts quantity from a user's backpack inventory.
   */
  public static deductUserGiftInventory(
    userId: string, 
    giftId: string, 
    quantity: number
  ): { success: boolean; remainingCount: number } {
    const userMap = dbStore.userGiftInventories.get(userId);
    if (!userMap) throw new Error('User has no items in gift backpack');

    const item = userMap.get(giftId);
    if (!item || item.quantity < quantity) {
      throw new Error(`Insufficient inventory: owned ${item ? item.quantity : 0}, requested ${quantity}`);
    }

    item.quantity -= quantity;
    if (item.quantity <= 0) {
      userMap.delete(giftId);
    }

    return { success: true, remainingCount: Math.max(0, item.quantity) };
  }

  // =========================================================================
  // 3. USER BALANCE DEDUCTION & GIFT SENDING TRANSACTION
  // =========================================================================

  /**
   * Core orchestrator: executes user balance deduction or inventory consumption,
   * converts diamonds for receiver, updates leveling & PK scores, and triggers all notifications.
   */
  public static sendGiftInVoiceRoom(params: SendGiftParams): SendGiftResult {
    const { 
      senderId, 
      receiverId, 
      giftId, 
      count = 1, 
      roomId, 
      deductFromInventory = false,
      comboStreak = 1,
      customMessage
    } = params;

    const validatedCount = Math.max(1, Math.floor(Number(count) || 1));

    // 1. Validate Sender & Receiver
    const sender = dbStore.users.get(senderId);
    if (!sender) throw new Error('Sender user not found');

    const receiver = dbStore.users.get(receiverId);
    if (!receiver) throw new Error('Receiver user not found');

    // 2. Validate Gift in Catalog
    const gift = dbStore.gifts.get(giftId);
    if (!gift) throw new Error(`Gift with ID "${giftId}" not found in catalog.`);

    if (gift.isAvailable === false) {
      throw new Error(`Gift "${gift.name}" is currently disabled.`);
    }

    // 3. Balance Deduction or Inventory Consumption
    const totalCostCoins = deductFromInventory ? 0 : gift.priceCoins * validatedCount;
    let remainingInventory: number | undefined;

    if (deductFromInventory) {
      // Consume from personal backpack
      const deductRes = this.deductUserGiftInventory(senderId, giftId, validatedCount);
      remainingInventory = deductRes.remainingCount;
    } else {
      // Deduct from sender's coin balance
      if (sender.coins < totalCostCoins) {
        throw new Error(
          `Insufficient coins. Required: ${totalCostCoins.toLocaleString()} Coins (Current Balance: ${sender.coins.toLocaleString()})`
        );
      }

      // Check catalog stock for limited-edition gifts
      if (gift.stockQuantity !== undefined && gift.stockQuantity !== -1) {
        if (gift.stockQuantity < validatedCount) {
          throw new Error(`Only ${gift.stockQuantity} items left in stock for ${gift.name}`);
        }
        gift.stockQuantity -= validatedCount;
        dbStore.gifts.set(gift.id, gift);
      }

      sender.coins -= totalCostCoins;
    }

    // 4. Calculate Host Diamond Earnings (e.g. 50% default yield rate)
    const yieldRate = gift.diamondYieldRate !== undefined ? gift.diamondYieldRate : 0.5;
    const baseValue = gift.priceCoins * validatedCount;
    const diamondsAwarded = Math.floor(baseValue * yieldRate);
    receiver.diamonds += diamondsAwarded;

    // 5. Update Wealth / Sending Level Progression (Sender)
    // Sending level increases based on coins spent
    if (totalCostCoins > 0) {
      const currentSendingLvl = sender.sendingLevel || 1;
      const expPoints = totalCostCoins;
      // Progressive level milestone (e.g. each level requires level * 2500 coins)
      if (expPoints >= currentSendingLvl * 1000) {
        sender.sendingLevel = Math.min(100, currentSendingLvl + 1);
      }
    }

    // 6. Update Charm / Receiving Level Progression (Receiver)
    // Receiving level increases based on diamonds earned
    if (diamondsAwarded > 0) {
      const currentReceivingLvl = receiver.receivingLevel || 1;
      if (diamondsAwarded >= currentReceivingLvl * 800) {
        receiver.receivingLevel = Math.min(100, currentReceivingLvl + 1);
      }
    }

    // Persist updated users
    dbStore.users.set(senderId, sender);
    dbStore.users.set(receiverId, receiver);

    // 7. Record Ledger Transactions
    const txId = `tx-vgift-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

    const senderTx: WalletTransaction = {
      id: `${txId}-s`,
      userId: senderId,
      type: 'gift_sent',
      currency: 'coin',
      amount: -totalCostCoins,
      balanceAfter: sender.coins,
      description: deductFromInventory 
        ? `Sent ${validatedCount}x ${gift.name} to ${receiver.name} (from Backpack)`
        : `Sent ${validatedCount}x ${gift.name} to ${receiver.name}`,
      status: 'completed',
      timestamp: new Date().toISOString()
    };
    dbStore.transactions.set(senderTx.id, senderTx);

    const receiverTx: WalletTransaction = {
      id: `${txId}-r`,
      userId: receiverId,
      type: 'gift_received',
      currency: 'diamond',
      amount: diamondsAwarded,
      balanceAfter: receiver.diamonds,
      description: `Received ${validatedCount}x ${gift.name} from ${sender.name} (+${diamondsAwarded} Diamonds)`,
      status: 'completed',
      timestamp: new Date().toISOString()
    };
    dbStore.transactions.set(receiverTx.id, receiverTx);

    // 8. Room-Specific Logic: Seat Contribution & Active PK Battle Surge
    let activeRoom: VoiceRoom | undefined;
    let roomMessageId: string | undefined;
    let pkScoreBoosted = false;
    let pkNewScore: number | undefined;

    if (roomId) {
      activeRoom = RoomService.getRoomById(roomId);
      if (activeRoom) {
        // A. Update mic seat contribution if sender or receiver is seated
        if (activeRoom.seats && activeRoom.seats.length > 0) {
          activeRoom.seats.forEach(s => {
            if (s.userId === senderId) {
              s.contributionCoin = (s.contributionCoin || 0) + (totalCostCoins || baseValue);
            }
          });
          dbStore.rooms.set(activeRoom.id, activeRoom);
        }

        // B. PK Battle Dynamic Tug-of-War Score Boost
        if (activeRoom.pkState?.active) {
          const scoreBoost = totalCostCoins > 0 ? totalCostCoins : baseValue;
          activeRoom.pkState.myScore += scoreBoost;
          pkScoreBoosted = true;
          pkNewScore = activeRoom.pkState.myScore;

          // Sync with PK battle store if match exists
          for (const battle of dbStore.pkBattles.values()) {
            if (battle.status === 'active') {
              if (battle.roomAId === activeRoom.id || battle.roomAId === roomId) {
                battle.roomAScore += scoreBoost;
              } else if (battle.roomBId === activeRoom.id || battle.roomBId === roomId) {
                battle.roomBScore += scoreBoost;
              }
            }
          }
          dbStore.rooms.set(activeRoom.id, activeRoom);
        }

        // C. Publish Broadcast Message into Room Chat
        const addedMsg = RoomService.addRoomMessage(activeRoom.id, {
          roomId: activeRoom.id,
          userId: sender.id,
          userName: sender.name,
          userAvatar: sender.avatar,
          vipLevel: sender.vipLevel,
          type: 'gift',
          content: customMessage || `sent ${validatedCount}x ${gift.name} to ${receiver.name}!`,
          giftId: gift.id,
          giftName: gift.name,
          giftIcon: gift.icon,
          giftCount: validatedCount
        });
        roomMessageId = addedMsg.id;
      }
    }

    // 9. Update CP / Friend Connection Intimacy
    try {
      ConnectionService.onGiftSent(senderId, receiverId, totalCostCoins || baseValue, validatedCount);
    } catch (cErr) {
      console.warn('[VirtualGiftService] Connection update notice:', cErr);
    }

    // 10. Update Family Guild Contribution if sender belongs to a family
    let familyNoticeSent = false;
    if (sender.familyId) {
      const family = dbStore.families.get(sender.familyId);
      if (family) {
        const familyContributionGain = Math.floor((totalCostCoins || baseValue) * 0.1);
        family.totalContribution = (family.totalContribution || 0) + familyContributionGain;
        family.xp = (family.xp || 0) + familyContributionGain;
        dbStore.families.set(family.id, family);
        familyNoticeSent = true;
      }
    }

    // =========================================================================
    // 4. NOTIFICATION TRIGGERING
    // =========================================================================

    const roomTitle = activeRoom ? activeRoom.title : 'Live Voice Room';
    const roomPath = roomId ? `/room/${roomId}` : undefined;

    // A. Recipient In-App Notification
    const receiverNotif = NotificationService.sendNotification(
      receiverId,
      `🎁 Gift Received: ${validatedCount}x ${gift.name}!`,
      `${sender.name} sent you ${validatedCount}x ${gift.name} in "${roomTitle}". You earned +${diamondsAwarded.toLocaleString()} diamonds!`,
      'gift',
      roomPath
    );

    // B. Host Notification (if recipient is a guest/co-host on mic, notify the room host as well)
    let hostNotifId: string | undefined;
    if (activeRoom && activeRoom.hostId && activeRoom.hostId !== receiverId && activeRoom.hostId !== senderId) {
      const hostNotif = NotificationService.sendNotification(
        activeRoom.hostId,
        `✨ Room Gift Surge!`,
        `${sender.name} sent ${validatedCount}x ${gift.name} to ${receiver.name} in your room "${activeRoom.title}"!`,
        'gift',
        roomPath
      );
      hostNotifId = hostNotif.id;
    }

    // C. PK Battle Score Surge Notification (if in active PK)
    if (pkScoreBoosted && activeRoom) {
      NotificationService.sendNotification(
        activeRoom.hostId,
        `⚔️ PK Battle Score Surge!`,
        `${sender.name} boosted your PK Battle score by +${(totalCostCoins || baseValue).toLocaleString()} points with ${gift.name}!`,
        'pk',
        roomPath
      );
    }

    // D. Global / Room Luxury Banner Alert for high-tier gifts
    const isLuxuryOrSpecial = 
      gift.category === 'luxury' || 
      gift.category === 'special' || 
      gift.priceCoins >= 1000 || 
      validatedCount >= 52;

    if (isLuxuryOrSpecial) {
      // Trigger a platform/room-wide broadcast notice
      const luxuryAlertTitle = `🌟 Luxury Gift Alert: ${gift.icon} ${gift.name}!`;
      const luxuryAlertMsg = `${sender.name} gifted ${validatedCount}x ${gift.name} to ${receiver.name} in room "${roomTitle}"!`;
      
      // If room exists, add an animated system announcement to room stream
      if (activeRoom) {
        RoomService.addRoomMessage(activeRoom.id, {
          roomId: activeRoom.id,
          userId: 'system',
          userName: 'AURA SPOTLIGHT 🌟',
          userAvatar: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=150&q=80',
          type: 'system',
          content: `👑 LUXURY COMBO: ${sender.name} just gifted ${validatedCount}x ${gift.name} to ${receiver.name}!`
        });
      }
    }

    // 11. Audit Log Recording
    dbStore.recordAudit({
      action: 'VIRTUAL_GIFT_SENT',
      module: 'gift',
      performedByUserId: senderId,
      performedByUserName: sender.name,
      performedByRole: sender.role,
      targetId: receiverId,
      targetName: receiver.name,
      details: `Sent ${validatedCount}x ${gift.name} (${gift.id}) in room ${roomId || 'Direct'}. Cost: ${totalCostCoins} coins, Yield: ${diamondsAwarded} diamonds. (Backpack: ${deductFromInventory})`,
      ipAddress: '127.0.0.1'
    });

    return {
      success: true,
      transactionId: txId,
      senderId,
      receiverId,
      gift,
      count: validatedCount,
      totalCostCoins,
      diamondsAwarded,
      senderNewCoinBalance: sender.coins,
      receiverNewDiamondBalance: receiver.diamonds,
      deductedFromInventory: !!deductFromInventory,
      remainingInventoryCount: remainingInventory,
      senderSendingLevel: sender.sendingLevel,
      receiverReceivingLevel: receiver.receivingLevel,
      roomMessageId,
      pkScoreBoosted,
      pkNewScore,
      notificationsSent: {
        receiverNotificationId: receiverNotif.id,
        roomBroadcast: !!roomId,
        luxuryGlobalAlert: isLuxuryOrSpecial,
        hostNotificationId: hostNotifId,
        familyNoticeSent
      },
      comboStreak,
      timestamp: new Date().toISOString()
    };
  }

  // =========================================================================
  // 4. TOP CONTRIBUTORS LEADERBOARD ANALYTICS & REAL-TIME RANKING
  // =========================================================================

  /**
   * Generates real-time contributor rankings based on virtual gift earnings (diamonds),
   * gifts sent (coins), and multi-signal engagement scores across Daily, Weekly, and All-Time periods.
   */
  public static getTopContributors(
    category: ContributorLeaderboardCategory = 'earners',
    period: ContributorLeaderboardPeriod = 'daily',
    limit: number = 50,
    currentUserId?: string
  ): ContributorLeaderboardResponse {
    const now = Date.now();
    let cutoffTime = 0;
    if (period === 'daily') {
      cutoffTime = now - (24 * 60 * 60 * 1000);
    } else if (period === 'weekly') {
      cutoffTime = now - (7 * 24 * 60 * 60 * 1000);
    }

    // Aggregators for gifts from transaction ledger
    const userSpentMap = new Map<string, number>();
    const userEarnedMap = new Map<string, number>();
    const userSentCountMap = new Map<string, number>();
    const userReceivedCountMap = new Map<string, number>();

    // Process transactions
    for (const tx of dbStore.transactions.values()) {
      if (!tx.timestamp) continue;
      const txTime = new Date(tx.timestamp).getTime();
      if (txTime < cutoffTime) continue;

      if (tx.type === 'gift_sent' && tx.currency === 'coin') {
        const spent = Math.abs(tx.amount || 0);
        userSpentMap.set(tx.userId, (userSpentMap.get(tx.userId) || 0) + spent);
        userSentCountMap.set(tx.userId, (userSentCountMap.get(tx.userId) || 0) + 1);
      } else if (tx.type === 'gift_received' && tx.currency === 'diamond') {
        const earned = Math.abs(tx.amount || 0);
        userEarnedMap.set(tx.userId, (userEarnedMap.get(tx.userId) || 0) + earned);
        userReceivedCountMap.set(tx.userId, (userReceivedCountMap.get(tx.userId) || 0) + 1);
      }
    }

    // Also factor room seat contributions
    for (const room of dbStore.rooms.values()) {
      if (room.seats) {
        room.seats.forEach(s => {
          if (s.userId && s.contributionCoin && s.contributionCoin > 0) {
            const current = userSpentMap.get(s.userId) || 0;
            // Add if not already captured
            if (current < s.contributionCoin) {
              userSpentMap.set(s.userId, s.contributionCoin);
            }
          }
        });
      }
    }

    const items: ContributorLeaderboardItem[] = [];

    // Scale factors for period estimations if no transactions exist in the short window
    const periodScale = period === 'daily' ? 0.08 : period === 'weekly' ? 0.35 : 1.0;

    for (const user of dbStore.users.values()) {
      if (!user || !user.id) continue;

      const txSpent = userSpentMap.get(user.id) || 0;
      const txEarned = userEarnedMap.get(user.id) || 0;
      const giftsSent = userSentCountMap.get(user.id) || 0;
      const giftsReceived = userReceivedCountMap.get(user.id) || 0;

      // Base user values for realistic baseline
      const baseEarned = Math.round((user.diamonds || 0) * periodScale);
      const baseSpent = Math.round(((user.sendingLevel || 1) * 3500 + (user.diamonds || 0) * 0.8) * periodScale);

      const totalDiamondsEarned = Math.max(txEarned, baseEarned);
      const totalCoinsSpent = Math.max(txSpent, baseSpent);

      // Multi-factor engagement score
      const engagementScore = Math.round(
        (totalDiamondsEarned * 1.5) +
        (totalCoinsSpent * 1.0) +
        ((user.sendingLevel || 1) * 300) +
        ((user.receivingLevel || 1) * 450) +
        (user.isOnline ? 2000 : 0) +
        (user.vipLevel === 'svip' ? 6000 : user.vipLevel === 'vip' ? 2500 : 0) +
        (giftsSent * 50) +
        (giftsReceived * 100)
      );

      // Check if user is currently active in any room
      let activeRoomId: string | undefined;
      for (const room of dbStore.rooms.values()) {
        if (room.hostId === user.id || room.seats?.some(s => s.userId === user.id)) {
          activeRoomId = room.id;
          break;
        }
      }

      items.push({
        rank: 0, // Assigned after sorting
        userId: user.id,
        name: user.name,
        avatar: user.avatar,
        uid: user.uid || user.id,
        role: user.role,
        gender: user.gender,
        country: user.country,
        countryFlag: user.countryFlag,
        vipLevel: user.vipLevel,
        frame: user.frame,
        sendingLevel: user.sendingLevel || 1,
        receivingLevel: user.receivingLevel || 1,
        totalCoinsSpent,
        diamondsEarned: totalDiamondsEarned,
        engagementScore,
        giftsSentCount: Math.max(giftsSent, Math.floor(totalCoinsSpent / 150)),
        giftsReceivedCount: Math.max(giftsReceived, Math.floor(totalDiamondsEarned / 80)),
        isOnline: !!user.isOnline,
        activeRoomId,
        familyName: user.familyName,
        badge: user.badges && user.badges.length > 0 ? user.badges[0].name : undefined,
        trend: 'up',
        trendPositions: Math.floor(Math.random() * 3) + 1
      });
    }

    // Sort by selected category
    if (category === 'earners') {
      items.sort((a, b) => b.diamondsEarned - a.diamondsEarned || b.receivingLevel - a.receivingLevel);
    } else if (category === 'senders') {
      items.sort((a, b) => b.totalCoinsSpent - a.totalCoinsSpent || b.sendingLevel - a.sendingLevel);
    } else {
      // 'engagement'
      items.sort((a, b) => b.engagementScore - a.engagementScore);
    }

    // Assign final 1-based ranks
    items.forEach((item, index) => {
      item.rank = index + 1;
      // Assign realistic trend
      if (item.rank === 1) {
        item.trend = 'same';
        item.trendPositions = 0;
      } else if (index % 4 === 0) {
        item.trend = 'down';
        item.trendPositions = 1;
      } else if (index % 3 === 0) {
        item.trend = 'same';
        item.trendPositions = 0;
      } else {
        item.trend = 'up';
        item.trendPositions = Math.floor(Math.random() * 2) + 1;
      }
    });

    const topItems = items.slice(0, Math.max(1, limit));

    // Find current user's ranking if requested
    let currentUserRank: ContributorLeaderboardResponse['currentUserRank'];
    if (currentUserId) {
      const idx = items.findIndex(it => it.userId === currentUserId || it.uid === currentUserId);
      if (idx !== -1) {
        const myItem = items[idx];
        const nextAbove = idx > 0 ? items[idx - 1] : undefined;
        const myScore = category === 'earners' ? myItem.diamondsEarned : category === 'senders' ? myItem.totalCoinsSpent : myItem.engagementScore;
        const nextScore = nextAbove ? (category === 'earners' ? nextAbove.diamondsEarned : category === 'senders' ? nextAbove.totalCoinsSpent : nextAbove.engagementScore) : myScore;

        currentUserRank = {
          rank: myItem.rank,
          score: myScore,
          diamondsEarned: myItem.diamondsEarned,
          coinsSpent: myItem.totalCoinsSpent,
          diffToNextRank: Math.max(0, nextScore - myScore)
        };
      }
    }

    return {
      category,
      period,
      updatedAt: new Date().toISOString(),
      totalContributors: items.length,
      topItems,
      currentUserRank
    };
  }
}
