/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import jwt from 'jsonwebtoken';
import { dbStore } from '../db/store';
import { User, UserRole } from '../../types';

const JWT_SECRET = process.env.JWT_SECRET || 'aura-voice-super-secret-jwt-key-2026';
const REFRESH_SECRET = process.env.REFRESH_SECRET || 'aura-voice-refresh-secret-2026';

export interface TokenPayload {
  userId: string;
  role: UserRole;
  email: string;
}

export class AuthService {
  public static generateTokens(user: User) {
    const payload: TokenPayload = {
      userId: user.id,
      role: user.role,
      email: user.email
    };

    const accessToken = jwt.sign(payload, JWT_SECRET, { expiresIn: '24h' });
    const refreshToken = jwt.sign(payload, REFRESH_SECRET, { expiresIn: '7d' });

    return { accessToken, refreshToken, expiresIn: 86400 };
  }

  public static verifyToken(token: string): TokenPayload | null {
    try {
      return jwt.verify(token, JWT_SECRET) as TokenPayload;
    } catch (err) {
      return null;
    }
  }

  public static loginWithEmailPassword(emailOrId: string, password?: string): { user: User; tokens: { accessToken: string; refreshToken: string; expiresIn: number } } | null {
    // Ensure default CEO exists
    dbStore.ensureDefaultCeoExists();

    const normalizedIdentifier = (emailOrId || '').trim().toLowerCase();
    
    // Find user by email, uid, or user ID (e.g. 2383452, usr-2383452, usr-001, ceo@aura.com)
    let user = Array.from(dbStore.users.values()).find(u => 
      (u.email && u.email.toLowerCase() === normalizedIdentifier) ||
      u.uid === emailOrId.trim() ||
      u.id === emailOrId.trim() ||
      (u.uid === '2383452' && (normalizedIdentifier === '2383452' || normalizedIdentifier === 'ceo'))
    );
    
    // Direct CEO lookup fallback by ID or email
    if (!user && (normalizedIdentifier === 'ceo@aura.com' || normalizedIdentifier === '2383452' || normalizedIdentifier === 'ceo')) {
      user = dbStore.users.get('2383452') || dbStore.users.get('usr-2383452') || dbStore.users.get('usr-001') || dbStore.users.get('usr-ceo');
    }

    if (!user) return null;

    // Password verification: for CEO account 2383452, accepts Admin@123 or 2383452 or any admin pass
    if (user.role === 'ceo' && (user.uid === '2383452' || user.id === '2383452')) {
      if (password && password !== 'Admin@123' && password !== '2383452' && password !== user.password) {
        // Continue if password matches stored or standard CEO password
        if (user.password && user.password !== password) {
          return null;
        }
      }
    } else if (user.password && password && user.password !== password) {
      return null;
    }

    user.isOnline = true;
    dbStore.users.set(user.id, user);

    dbStore.recordAudit({
      action: 'USER_LOGIN_EMAIL_PASSWORD',
      module: 'auth',
      performedByUserId: user.id,
      performedByUserName: user.name,
      performedByRole: user.role,
      details: `User logged in via credentials: ${user.name} (UID: ${user.uid}, Role: ${user.role.toUpperCase()})`,
      ipAddress: '127.0.0.1'
    });

    const tokens = this.generateTokens(user);
    return { user, tokens };
  }

  public static simulateFirebaseAuth(
    firebaseUid: string, 
    email: string, 
    displayName?: string, 
    avatar?: string,
    profile?: Partial<User>
  ): { user: User; tokens: { accessToken: string; refreshToken: string; expiresIn: number } } {
    dbStore.ensureDefaultCeoExists();

    const normalizedEmail = (email || '').toLowerCase().trim();
    let user = Array.from(dbStore.users.values()).find(
      u => (u.email && u.email.toLowerCase() === normalizedEmail) || 
           u.uid === firebaseUid || 
           (u as any).firebaseUid === firebaseUid ||
           u.id === firebaseUid
    );
    
    // Check if logging in as platform owner / CEO email or UID 2383452
    if (!user && (normalizedEmail === 'ceo@aura.com' || firebaseUid === '2383452')) {
      user = dbStore.users.get('2383452') || dbStore.users.get('usr-2383452') || dbStore.users.get('usr-001');
    }

    if (!user) {
      const isOwnerEmail = normalizedEmail === 'imoborkot@gmail.com' || normalizedEmail === 'ceo@aura.com';
      const canonicalNigoId = isOwnerEmail 
        ? '2383452' 
        : (profile?.uid || profile?.nigoId || Math.floor(1000000 + Math.random() * 9000000).toString());
      
      user = {
        id: firebaseUid,
        uid: canonicalNigoId,
        firebaseUid,
        nigoId: canonicalNigoId,
        name: profile?.name?.trim() || displayName?.trim() || (normalizedEmail ? normalizedEmail.split('@')[0] : 'Aura Member'),
        email: email,
        avatar: profile?.avatar || avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
        gender: profile?.gender || 'other',
        phone: profile?.phone || '',
        country: profile?.country || 'United States',
        countryFlag: profile?.countryFlag || '🇺🇸',
        bio: isOwnerEmail ? '👑 Platform CEO & Founder of Aura Voice Platform. Full administrative control & staff management.' : (profile?.bio || 'Just joined Aura Voice Chat! Say hello 👋'),
        role: isOwnerEmail ? 'ceo' : 'user',
        vipLevel: isOwnerEmail ? 'svip' : 'none',
        coins: isOwnerEmail ? 10000000 : 10000, // Welcome bonus / CEO reserve
        diamonds: isOwnerEmail ? 5000000 : 500,
        level: isOwnerEmail ? 100 : 1,
        sendingLevel: isOwnerEmail ? 100 : 1,
        receivingLevel: isOwnerEmail ? 100 : 1,
        isOnline: true,
        createdAt: profile?.createdAt || new Date().toISOString(),
        badges: isOwnerEmail ? [
          { id: 'bdg-ceo', name: 'Executive Leader', icon: '👑', description: 'Platform CEO & Owner', acquiredAt: '2025-01-01' },
          { id: 'bdg-1', name: 'Founding Icon', icon: '🌟', description: 'Early adopter of Aura Voice', acquiredAt: '2025-01-10' }
        ] : [
          { id: 'bdg-new', name: 'Newcomer', icon: '🌱', description: 'Joined the Aura Voice platform', acquiredAt: new Date().toISOString().split('T')[0] }
        ],
        medals: isOwnerEmail ? [
          { id: 'mdl-ceo', name: 'Owner', icon: '⚡', level: 10, color: '#f59e0b' }
        ] : []
      };
      (user as any).firebaseUid = firebaseUid;
      dbStore.users.set(user.id, user);

      dbStore.recordAudit({
        action: 'USER_REGISTERED_FIREBASE_AUTH',
        module: 'auth',
        performedByUserId: user.id,
        performedByUserName: user.name,
        performedByRole: user.role,
        details: `New user registered via Firebase Auth: ${email} (UID: ${user.uid}, Firebase UID: ${firebaseUid}, Role: ${user.role})`,
        ipAddress: '127.0.0.1'
      });
    } else {
      user.isOnline = true;
      (user as any).firebaseUid = firebaseUid;
      if (displayName && (!user.name || user.name === 'Aura Newbie')) {
        user.name = displayName;
      }
      if (avatar && (!user.avatar || user.avatar.includes('placeholder'))) {
        user.avatar = avatar;
      }
      if (profile?.phone && !user.phone) {
        user.phone = profile.phone;
      }
      if (profile?.country && (!user.country || user.country === 'Global')) {
        user.country = profile.country;
        if (profile.countryFlag) user.countryFlag = profile.countryFlag;
      }
      if (profile?.gender && (!user.gender || user.gender === 'other')) {
        user.gender = profile.gender;
      }
      dbStore.users.set(user.id, user);
    }

    const tokens = this.generateTokens(user);
    return { user, tokens };
  }
}
