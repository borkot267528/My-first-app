/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { dbStore } from '../db/store';
import { WalletTransaction, RechargePackage, WithdrawPaymentMethod } from '../../types';
import { ConnectionService } from './connection.service';
import { VirtualGiftService } from './virtualGift.service';

export class WalletService {
  public static getBalance(userId: string) {
    const user = dbStore.users.get(userId);
    if (!user) throw new Error('User not found');
    return { coins: user.coins, diamonds: user.diamonds };
  }

  public static recharge(userId: string, coins: number, diamonds: number, description: string): WalletTransaction {
    const user = dbStore.users.get(userId);
    if (!user) throw new Error('User not found');

    if (coins > 0) user.coins += coins;
    if (diamonds > 0) user.diamonds += diamonds;
    dbStore.users.set(userId, user);

    const tx: WalletTransaction = {
      id: `tx-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      userId,
      type: 'recharge',
      currency: coins > 0 ? 'coin' : 'diamond',
      amount: coins > 0 ? coins : diamonds,
      balanceAfter: coins > 0 ? user.coins : user.diamonds,
      description,
      status: 'completed',
      timestamp: new Date().toISOString()
    };
    dbStore.transactions.set(tx.id, tx);

    dbStore.recordAudit({
      action: 'WALLET_RECHARGE',
      module: 'wallet',
      performedByUserId: userId,
      performedByUserName: user.name,
      performedByRole: user.role,
      details: `Recharged ${coins} coins and ${diamonds} diamonds. New Coins: ${user.coins}`,
      ipAddress: '127.0.0.1'
    });

    dbStore.addNotification(userId, {
      title: '🪙 Wallet Recharge Successful!',
      message: `Successfully recharged ${coins > 0 ? `${coins.toLocaleString()} Coins` : `${diamonds.toLocaleString()} Diamonds`} (${description}). Your new balance is ready!`,
      type: 'wallet'
    });

    return tx;
  }

  public static withdraw(userId: string, diamondsToConvert: number, accountDetails: string): WalletTransaction {
    const user = dbStore.users.get(userId);
    if (!user) throw new Error('User not found');

    if (user.diamonds < diamondsToConvert) {
      throw new Error('Insufficient diamonds balance for withdrawal');
    }

    user.diamonds -= diamondsToConvert;
    dbStore.users.set(userId, user);

    const tx: WalletTransaction = {
      id: `tx-wd-${Date.now()}`,
      userId,
      type: 'withdraw',
      currency: 'diamond',
      amount: -diamondsToConvert,
      balanceAfter: user.diamonds,
      description: `Withdrawal request for ${diamondsToConvert} diamonds to account: ${accountDetails}`,
      status: 'pending',
      timestamp: new Date().toISOString()
    };
    dbStore.transactions.set(tx.id, tx);

    dbStore.recordAudit({
      action: 'WALLET_WITHDRAW_REQUEST',
      module: 'wallet',
      performedByUserId: userId,
      performedByUserName: user.name,
      performedByRole: user.role,
      details: `Requested withdrawal of ${diamondsToConvert} diamonds. Remaining diamonds: ${user.diamonds}`,
      ipAddress: '127.0.0.1'
    });

    return tx;
  }

  public static sendGift(senderId: string, receiverId: string, giftId: string, count: number = 1, roomId?: string): { senderBalance: number; receiverDiamonds: number } {
    // Import VirtualGiftService for robust gift inventory, balance deduction, and notification handling
    const result = VirtualGiftService.sendGiftInVoiceRoom({
      senderId,
      receiverId,
      giftId,
      count,
      roomId
    });

    return { senderBalance: result.senderNewCoinBalance, receiverDiamonds: result.receiverNewDiamondBalance };
  }

  public static getRechargePackages(): RechargePackage[] {
    return dbStore.rechargePackages;
  }

  public static updateRechargePackage(
    staffId: string,
    pkgId: string,
    updates: Partial<RechargePackage>
  ): RechargePackage[] {
    const staff = dbStore.users.get(staffId);
    const index = dbStore.rechargePackages.findIndex(p => p.id === pkgId);
    if (index === -1) {
      throw new Error(`Package with ID ${pkgId} not found`);
    }

    const oldPkg = { ...dbStore.rechargePackages[index] };
    const updatedPkg: RechargePackage = {
      ...oldPkg,
      ...updates,
      id: oldPkg.id,
      coins: updates.coins !== undefined ? Number(updates.coins) : oldPkg.coins,
      bonusCoins: updates.bonusCoins !== undefined ? Number(updates.bonusCoins) : oldPkg.bonusCoins,
      diamonds: updates.diamonds !== undefined ? Number(updates.diamonds) : (oldPkg.diamonds || 0),
      priceUsd: updates.priceUsd !== undefined ? Number(updates.priceUsd) : oldPkg.priceUsd
    };

    dbStore.rechargePackages[index] = updatedPkg;

    const staffName = staff ? staff.name : 'Elena Vance (CEO)';
    const staffRole = staff ? staff.role : 'ceo';
    dbStore.recordAudit({
      action: 'WALLET_PACKAGE_UPDATED',
      module: 'wallet',
      performedByUserId: staffId || '2383452',
      performedByUserName: staffName,
      performedByRole: staffRole,
      targetId: updatedPkg.id,
      targetName: updatedPkg.name,
      details: `Updated Package ${updatedPkg.name} (${updatedPkg.id}): Coins ${oldPkg.coins} -> ${updatedPkg.coins}, Diamonds ${oldPkg.diamonds || 0} -> ${updatedPkg.diamonds || 0}, Price $${oldPkg.priceUsd} -> $${updatedPkg.priceUsd}`,
      ipAddress: '127.0.0.1'
    });

    dbStore.recordStaffActivity({
      staffId: staffId || '2383452',
      staffName,
      staffRole,
      actionType: 'SYSTEM_CONFIG',
      targetResource: `Wallet Package ${updatedPkg.name} (${updatedPkg.id})`,
      details: `Modified package configuration: ${updatedPkg.currencyType === 'diamond' ? `${updatedPkg.diamonds} Diamonds` : `${updatedPkg.coins} (+${updatedPkg.bonusCoins}) Coins`} for $${updatedPkg.priceUsd}`,
      ipAddress: '127.0.0.1'
    });

    return dbStore.rechargePackages;
  }

  public static saveAllRechargePackages(
    staffId: string,
    packages: RechargePackage[]
  ): RechargePackage[] {
    const staff = dbStore.users.get(staffId);
    if (!Array.isArray(packages) || packages.length === 0) {
      throw new Error('Package list cannot be empty');
    }

    dbStore.rechargePackages = packages.map((p, idx) => ({
      id: p.id || `pkg-${Date.now()}-${idx}`,
      name: p.name || `Package #${idx + 1}`,
      currencyType: p.currencyType || (p.diamonds && p.diamonds > 0 ? 'diamond' : 'coin'),
      coins: Number(p.coins) || 0,
      bonusCoins: Number(p.bonusCoins) || 0,
      diamonds: Number(p.diamonds) || 0,
      priceUsd: Number(p.priceUsd) || 0.99,
      badge: p.badge || '',
      popular: !!p.popular,
      bestValue: !!p.bestValue,
      isActive: p.isActive !== false,
      sortOrder: p.sortOrder ?? (idx + 1)
    }));

    const staffName = staff ? staff.name : 'Elena Vance (CEO)';
    const staffRole = staff ? staff.role : 'ceo';
    dbStore.recordAudit({
      action: 'WALLET_PACKAGES_SAVED',
      module: 'wallet',
      performedByUserId: staffId || '2383452',
      performedByUserName: staffName,
      performedByRole: staffRole,
      details: `Saved ${packages.length} wallet packages in database. Invalidation event dispatched.`,
      ipAddress: '127.0.0.1'
    });

    dbStore.recordStaffActivity({
      staffId: staffId || '2383452',
      staffName,
      staffRole,
      actionType: 'SYSTEM_CONFIG',
      targetResource: 'Wallet Packages Database',
      details: `Admin updated ${packages.length} Coin/Diamond packages for instant user availability`,
      ipAddress: '127.0.0.1'
    });

    return dbStore.rechargePackages;
  }

  public static createRechargePackage(
    staffId: string,
    newPkg: Partial<RechargePackage>
  ): RechargePackage[] {
    const staff = dbStore.users.get(staffId);
    const isDiamond = newPkg.currencyType === 'diamond' || (!newPkg.coins && (newPkg.diamonds || 0) > 0);
    const pkg: RechargePackage = {
      id: `pkg-${isDiamond ? 'dia' : 'coin'}-${Date.now()}`,
      name: newPkg.name || (isDiamond ? 'New Diamond Package' : 'New Coin Package'),
      currencyType: isDiamond ? 'diamond' : 'coin',
      coins: isDiamond ? 0 : (Number(newPkg.coins) || 1000),
      bonusCoins: isDiamond ? 0 : (Number(newPkg.bonusCoins) || 0),
      diamonds: isDiamond ? (Number(newPkg.diamonds) || 500) : 0,
      priceUsd: Number(newPkg.priceUsd) || 9.99,
      badge: newPkg.badge || '',
      popular: !!newPkg.popular,
      bestValue: !!newPkg.bestValue,
      isActive: newPkg.isActive !== false,
      sortOrder: dbStore.rechargePackages.length + 1
    };

    dbStore.rechargePackages.push(pkg);

    const staffName = staff ? staff.name : 'Elena Vance (CEO)';
    const staffRole = staff ? staff.role : 'ceo';
    dbStore.recordAudit({
      action: 'WALLET_PACKAGE_CREATED',
      module: 'wallet',
      performedByUserId: staffId || '2383452',
      performedByUserName: staffName,
      performedByRole: staffRole,
      targetId: pkg.id,
      targetName: pkg.name,
      details: `Created new package ${pkg.name} (${pkg.id}) for $${pkg.priceUsd}`,
      ipAddress: '127.0.0.1'
    });

    return dbStore.rechargePackages;
  }

  public static deleteRechargePackage(
    staffId: string,
    pkgId: string
  ): RechargePackage[] {
    const staff = dbStore.users.get(staffId);
    const existing = dbStore.rechargePackages.find(p => p.id === pkgId);
    if (!existing) throw new Error(`Package ${pkgId} not found`);

    dbStore.rechargePackages = dbStore.rechargePackages.filter(p => p.id !== pkgId);

    const staffName = staff ? staff.name : 'Elena Vance (CEO)';
    const staffRole = staff ? staff.role : 'ceo';
    dbStore.recordAudit({
      action: 'WALLET_PACKAGE_DELETED',
      module: 'wallet',
      performedByUserId: staffId || '2383452',
      performedByUserName: staffName,
      performedByRole: staffRole,
      targetId: existing.id,
      targetName: existing.name,
      details: `Deleted package ${existing.name} (${pkgId})`,
      ipAddress: '127.0.0.1'
    });

    return dbStore.rechargePackages;
  }

  public static moderateWithdrawal(staffId: string, txId: string, status: 'completed' | 'rejected', notes?: string): WalletTransaction {
    const tx = dbStore.transactions.get(txId);
    const staff = dbStore.users.get(staffId);
    if (!tx || !staff) throw new Error('Transaction or Staff member not found');
    if (tx.type !== 'withdraw' || tx.status !== 'pending') {
      throw new Error('Only pending withdrawal requests can be moderated');
    }

    tx.status = status;
    tx.description += ` [Moderated by ${staff.name}: ${status.toUpperCase()} - ${notes || 'No notes'}]`;
    dbStore.transactions.set(tx.id, tx);

    const user = dbStore.users.get(tx.userId);
    if (status === 'rejected' && user) {
      // Refund diamonds if rejected
      user.diamonds += Math.abs(tx.amount);
      dbStore.users.set(user.id, user);
    }

    if (user) {
      dbStore.addNotification(user.id, {
        title: `Withdrawal Request ${status === 'completed' ? 'Approved ✅' : 'Rejected ❌'}`,
        message: status === 'completed' 
          ? `Your withdrawal request for ${Math.abs(tx.amount)} diamonds has been processed and sent to your bank account.`
          : `Your withdrawal request was rejected. ${Math.abs(tx.amount)} diamonds have been refunded to your wallet.`,
        type: 'wallet'
      });
    }

    dbStore.recordStaffActivity({
      staffId: staff.id,
      staffName: staff.name,
      staffRole: staff.role,
      actionType: 'WITHDRAWAL_APPROVAL',
      targetResource: `txId: ${tx.id} (${user?.name || tx.userId})`,
      details: `Set status to ${status}. Amount: ${Math.abs(tx.amount)} diamonds. Notes: ${notes || 'none'}`,
      ipAddress: '127.0.0.1'
    });

    return tx;
  }

  public static getLedgerByCurrency(userId: string, currency?: 'coin' | 'diamond'): WalletTransaction[] {
    const all = Array.from(dbStore.transactions.values()).filter(t => t.userId === userId);
    if (!currency) return all.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    return all.filter(t => t.currency === currency).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  // ==========================================
  // WITHDRAW PAYMENT METHODS MANAGEMENT
  // ==========================================

  public static getWithdrawPaymentMethods(activeOnly: boolean = false): WithdrawPaymentMethod[] {
    const methods = Array.from(dbStore.withdrawPaymentMethods.values());
    const filtered = activeOnly ? methods.filter(m => m.isActive) : methods;
    return filtered.sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0));
  }

  public static getWithdrawPaymentMethodById(id: string): WithdrawPaymentMethod | undefined {
    return dbStore.withdrawPaymentMethods.get(id);
  }

  public static createWithdrawPaymentMethod(
    staffId: string,
    data: Partial<WithdrawPaymentMethod>
  ): WithdrawPaymentMethod[] {
    const staff = dbStore.users.get(staffId);
    const staffName = staff ? staff.name : 'Elena Vance (CEO)';
    const staffRole = staff ? staff.role : 'ceo';

    if (!data.name || !data.name.trim()) {
      throw new Error('Payment method name is required');
    }
    if (!data.accountFieldLabel || !data.accountFieldLabel.trim()) {
      throw new Error('Required account field label is required');
    }

    const id = data.id || `wpm-${Date.now().toString().slice(-4)}`;
    const currentMethods = Array.from(dbStore.withdrawPaymentMethods.values());

    const newMethod: WithdrawPaymentMethod = {
      id,
      name: data.name.trim(),
      type: data.type || 'mobile_wallet',
      currency: (data.currency || 'USD').toUpperCase().trim(),
      accountFieldLabel: data.accountFieldLabel.trim(),
      placeholder: data.placeholder ? data.placeholder.trim() : `Enter your ${data.accountFieldLabel.trim()}`,
      minWithdraw: Number(data.minWithdraw) || 100,
      maxWithdraw: Number(data.maxWithdraw) || 50000,
      processingFee: Number(data.processingFee) || 0,
      isActive: data.isActive !== false,
      sortOrder: data.sortOrder !== undefined ? Number(data.sortOrder) : currentMethods.length + 1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      createdBy: staffName,
      updatedBy: staffName
    };

    dbStore.withdrawPaymentMethods.set(newMethod.id, newMethod);

    dbStore.recordAudit({
      action: 'WITHDRAW_METHOD_CREATED',
      module: 'wallet',
      performedByUserId: staffId || '2383452',
      performedByUserName: staffName,
      performedByRole: staffRole,
      targetId: newMethod.id,
      targetName: newMethod.name,
      details: `Created withdrawal payment method [${newMethod.name}] (Type: ${newMethod.type}, Currency: ${newMethod.currency}, Field: ${newMethod.accountFieldLabel}, Active: ${newMethod.isActive})`,
      ipAddress: '127.0.0.1'
    });

    return this.getWithdrawPaymentMethods(false);
  }

  public static updateWithdrawPaymentMethod(
    staffId: string,
    id: string,
    updates: Partial<WithdrawPaymentMethod>
  ): WithdrawPaymentMethod[] {
    const staff = dbStore.users.get(staffId);
    const staffName = staff ? staff.name : 'Elena Vance (CEO)';
    const staffRole = staff ? staff.role : 'ceo';

    const existing = dbStore.withdrawPaymentMethods.get(id);
    if (!existing) {
      throw new Error(`Withdrawal payment method ${id} not found`);
    }

    const previousValue = { ...existing };

    if (updates.name !== undefined) existing.name = updates.name.trim();
    if (updates.type !== undefined) existing.type = updates.type;
    if (updates.currency !== undefined) existing.currency = updates.currency.toUpperCase().trim();
    if (updates.accountFieldLabel !== undefined) existing.accountFieldLabel = updates.accountFieldLabel.trim();
    if (updates.placeholder !== undefined) existing.placeholder = updates.placeholder.trim();
    if (updates.minWithdraw !== undefined) existing.minWithdraw = Number(updates.minWithdraw);
    if (updates.maxWithdraw !== undefined) existing.maxWithdraw = Number(updates.maxWithdraw);
    if (updates.processingFee !== undefined) existing.processingFee = Number(updates.processingFee);
    if (updates.isActive !== undefined) existing.isActive = Boolean(updates.isActive);
    if (updates.sortOrder !== undefined) existing.sortOrder = Number(updates.sortOrder);
    
    existing.updatedAt = new Date().toISOString();
    existing.updatedBy = staffName;

    dbStore.withdrawPaymentMethods.set(existing.id, existing);

    dbStore.recordAudit({
      action: 'WITHDRAW_METHOD_UPDATED',
      module: 'wallet',
      performedByUserId: staffId || '2383452',
      performedByUserName: staffName,
      performedByRole: staffRole,
      targetId: existing.id,
      targetName: existing.name,
      details: `Updated withdrawal payment method [${existing.name}]. Changes: Name(${previousValue.name}->${existing.name}), Active(${previousValue.isActive}->${existing.isActive}), Fee(${previousValue.processingFee}->${existing.processingFee})`,
      ipAddress: '127.0.0.1'
    });

    return this.getWithdrawPaymentMethods(false);
  }

  public static toggleWithdrawPaymentMethodStatus(
    staffId: string,
    id: string,
    isActive: boolean
  ): WithdrawPaymentMethod[] {
    const staff = dbStore.users.get(staffId);
    const staffName = staff ? staff.name : 'Elena Vance (CEO)';
    const staffRole = staff ? staff.role : 'ceo';

    const existing = dbStore.withdrawPaymentMethods.get(id);
    if (!existing) {
      throw new Error(`Withdrawal payment method ${id} not found`);
    }

    existing.isActive = isActive;
    existing.updatedAt = new Date().toISOString();
    existing.updatedBy = staffName;

    dbStore.withdrawPaymentMethods.set(existing.id, existing);

    const action = isActive ? 'WITHDRAW_METHOD_ACTIVATED' : 'WITHDRAW_METHOD_DEACTIVATED';
    dbStore.recordAudit({
      action,
      module: 'wallet',
      performedByUserId: staffId || '2383452',
      performedByUserName: staffName,
      performedByRole: staffRole,
      targetId: existing.id,
      targetName: existing.name,
      details: `${isActive ? 'Activated' : 'Deactivated'} withdrawal payment method [${existing.name}]`,
      ipAddress: '127.0.0.1'
    });

    return this.getWithdrawPaymentMethods(false);
  }

  public static deleteWithdrawPaymentMethod(
    staffId: string,
    id: string
  ): { success: boolean; list: WithdrawPaymentMethod[]; error?: string } {
    const staff = dbStore.users.get(staffId);
    const staffName = staff ? staff.name : 'Elena Vance (CEO)';
    const staffRole = staff ? staff.role : 'ceo';

    const existing = dbStore.withdrawPaymentMethods.get(id);
    if (!existing) {
      throw new Error(`Withdrawal payment method ${id} not found`);
    }

    // Safety Protection Check: Check if existing transactions reference this method
    const allTxs = Array.from(dbStore.transactions.values());
    const isReferencedInTransactions = allTxs.some(tx => 
      tx.type === 'withdraw' && 
      tx.description && 
      tx.description.toLowerCase().includes(existing.name.toLowerCase())
    );

    if (isReferencedInTransactions) {
      // Safety Rule: Do not allow deleting a payment method referenced in existing transactions
      return {
        success: false,
        list: this.getWithdrawPaymentMethods(false),
        error: `Cannot delete payment method "${existing.name}" because it is referenced by existing transaction/withdrawal history. You can safely Deactivate it instead.`
      };
    }

    dbStore.withdrawPaymentMethods.delete(id);

    dbStore.recordAudit({
      action: 'WITHDRAW_METHOD_DELETED',
      module: 'wallet',
      performedByUserId: staffId || '2383452',
      performedByUserName: staffName,
      performedByRole: staffRole,
      targetId: existing.id,
      targetName: existing.name,
      details: `Deleted withdrawal payment method [${existing.name}] (ID: ${id})`,
      ipAddress: '127.0.0.1'
    });

    return {
      success: true,
      list: this.getWithdrawPaymentMethods(false)
    };
  }
}
