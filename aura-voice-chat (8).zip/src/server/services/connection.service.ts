/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { dbStore } from '../db/store';
import { 
  Connection, 
  ConnectionRequest, 
  BlockedUserRecord, 
  ConnectionType, 
  User,
  AdminConnectionOverview,
  ConnectionSystemConfig
} from '../../types';
import { NotificationService } from './notification.service';

export class ConnectionService {
  /**
   * Helper to fetch normalized user details
   */
  private static getUser(userId: string): User | undefined {
    return dbStore.users.get(userId);
  }

  /**
   * Check if userA has blocked userB or vice versa
   */
  public static isBlocked(userAId: string, userBId: string): boolean {
    for (const record of dbStore.blockedUsers.values()) {
      if (
        (record.userId === userAId && record.blockedUserId === userBId) ||
        (record.userId === userBId && record.blockedUserId === userAId)
      ) {
        return true;
      }
    }
    return false;
  }

  /**
   * Get all active friends for a user
   */
  public static getFriends(userId: string): { connections: Connection[]; friends: User[] } {
    const activeFriendConns: Connection[] = [];
    const friendsList: User[] = [];

    for (const conn of dbStore.connections.values()) {
      if (conn.type === 'friend' && conn.status === 'active') {
        if (conn.user1Id === userId || conn.user2Id === userId) {
          const friendId = conn.user1Id === userId ? conn.user2Id : conn.user1Id;
          if (this.isBlocked(userId, friendId)) continue;

          const friendUser = this.getUser(friendId);
          if (friendUser) {
            const populatedConn: Connection = {
              ...conn,
              user1: this.getUser(conn.user1Id),
              user2: this.getUser(conn.user2Id)
            };
            activeFriendConns.push(populatedConn);
            friendsList.push(friendUser);
          }
        }
      }
    }

    return { connections: activeFriendConns, friends: friendsList };
  }

  /**
   * Get incoming and outgoing friend requests
   */
  public static getFriendRequests(userId: string): { 
    incoming: ConnectionRequest[]; 
    outgoing: ConnectionRequest[] 
  } {
    const incoming: ConnectionRequest[] = [];
    const outgoing: ConnectionRequest[] = [];

    for (const req of dbStore.connectionRequests.values()) {
      if (req.type === 'friend' && req.status === 'pending') {
        if (req.receiverId === userId) {
          if (!this.isBlocked(userId, req.senderId)) {
            incoming.push({
              ...req,
              sender: this.getUser(req.senderId),
              receiver: this.getUser(req.receiverId)
            });
          }
        } else if (req.senderId === userId) {
          if (!this.isBlocked(userId, req.receiverId)) {
            outgoing.push({
              ...req,
              sender: this.getUser(req.senderId),
              receiver: this.getUser(req.receiverId)
            });
          }
        }
      }
    }

    // Sort by newest first
    incoming.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    outgoing.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    return { incoming, outgoing };
  }

  /**
   * Get active CP (Couple / Connection Partner) for a user
   */
  public static getCP(userId: string): Connection | null {
    for (const conn of dbStore.connections.values()) {
      if (conn.type === 'cp' && conn.status === 'active') {
        if (conn.user1Id === userId || conn.user2Id === userId) {
          const partnerId = conn.user1Id === userId ? conn.user2Id : conn.user1Id;
          if (this.isBlocked(userId, partnerId)) return null;

          return {
            ...conn,
            user1: this.getUser(conn.user1Id),
            user2: this.getUser(conn.user2Id)
          };
        }
      }
    }
    return null;
  }

  /**
   * Get incoming and outgoing CP requests
   */
  public static getCPRequests(userId: string): { 
    incoming: ConnectionRequest[]; 
    outgoing: ConnectionRequest[] 
  } {
    const incoming: ConnectionRequest[] = [];
    const outgoing: ConnectionRequest[] = [];

    for (const req of dbStore.connectionRequests.values()) {
      if (req.type === 'cp' && req.status === 'pending') {
        if (req.receiverId === userId) {
          if (!this.isBlocked(userId, req.senderId)) {
            incoming.push({
              ...req,
              sender: this.getUser(req.senderId),
              receiver: this.getUser(req.receiverId)
            });
          }
        } else if (req.senderId === userId) {
          if (!this.isBlocked(userId, req.receiverId)) {
            outgoing.push({
              ...req,
              sender: this.getUser(req.senderId),
              receiver: this.getUser(req.receiverId)
            });
          }
        }
      }
    }

    incoming.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    outgoing.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    return { incoming, outgoing };
  }

  /**
   * Send a social connection request (Friend or CP)
   */
  public static sendRequest(
    senderId: string, 
    receiverId: string, 
    type: ConnectionType, 
    message?: string
  ): ConnectionRequest {
    const sender = this.getUser(senderId);
    const receiver = this.getUser(receiverId);

    if (!sender) throw new Error('Sender user profile not found');
    if (!receiver) throw new Error('Receiver user profile not found');

    // Rule: Prevent sending request to own account
    if (senderId === receiverId) {
      throw new Error('You cannot send a connection request to your own account');
    }

    // Rule: Check block status
    if (this.isBlocked(senderId, receiverId)) {
      throw new Error('Unable to send request to this user');
    }

    if (type === 'friend') {
      // Check if already friends
      const { friends } = this.getFriends(senderId);
      if (friends.some(f => f.id === receiverId || f.uid === receiverId)) {
        throw new Error('You are already friends with this user');
      }

      // Check for existing pending request in either direction
      for (const r of dbStore.connectionRequests.values()) {
        if (r.type === 'friend' && r.status === 'pending') {
          if (
            (r.senderId === senderId && r.receiverId === receiverId) ||
            (r.senderId === receiverId && r.receiverId === senderId)
          ) {
            throw new Error('A friend request between you and this user is already pending');
          }
        }
      }
    } else if (type === 'cp') {
      // Rule: Sender cannot have an existing active CP
      const senderCP = this.getCP(senderId);
      if (senderCP) {
        throw new Error('You already have an active CP connection. You must remove your existing CP before initiating a new one.');
      }

      // Rule: Receiver cannot have an existing active CP
      const receiverCP = this.getCP(receiverId);
      if (receiverCP) {
        throw new Error('This user is already in an active CP connection with someone else.');
      }

      // Check for existing pending CP request
      for (const r of dbStore.connectionRequests.values()) {
        if (r.type === 'cp' && r.status === 'pending') {
          if (
            (r.senderId === senderId && r.receiverId === receiverId) ||
            (r.senderId === receiverId && r.receiverId === senderId)
          ) {
            throw new Error('A CP connection request is already pending between you and this user');
          }
        }
      }
    }

    const newRequest: ConnectionRequest = {
      id: `req-${Date.now()}-${Math.floor(Math.random() * 10000)}`,
      type,
      senderId,
      receiverId,
      status: 'pending',
      message: message?.trim() || (type === 'cp' ? 'Would you like to be my CP partner? ❤️' : 'Let\'s be friends on Nigo! 👥'),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    dbStore.persistConnectionRequest(newRequest).catch(() => {});

    // Send real notification to receiver
    const title = type === 'cp' ? '❤️ New CP Invitation!' : '👥 New Friend Request!';
    const notifMsg = type === 'cp'
      ? `${sender.name} invited you to become CP partners!`
      : `${sender.name} sent you a friend request.`;
    
    NotificationService.sendNotification(receiverId, title, notifMsg, 'system');

    return {
      ...newRequest,
      sender,
      receiver
    };
  }

  /**
   * Accept an incoming connection request
   * Backend strictly validates that request.receiverId === userId
   */
  public static acceptRequest(userId: string, requestId: string): { 
    connection: Connection; 
    request: ConnectionRequest 
  } {
    const req = dbStore.connectionRequests.get(requestId);
    if (!req) throw new Error('Connection request not found');

    if (req.status !== 'pending') {
      throw new Error(`This request has already been ${req.status}`);
    }

    // Strict Security check: Only the designated recipient can accept
    if (req.receiverId !== userId) {
      throw new Error('You are not authorized to accept this request');
    }

    const sender = this.getUser(req.senderId);
    const receiver = this.getUser(req.receiverId);
    if (!sender || !receiver) throw new Error('One or both user profiles could not be loaded');

    if (req.type === 'cp') {
      // Re-verify neither has established a CP in the interim
      if (this.getCP(req.senderId) || this.getCP(req.receiverId)) {
        throw new Error('One of the users has already established an active CP connection');
      }
    }

    // Update request
    req.status = 'accepted';
    req.updatedAt = new Date().toISOString();
    dbStore.persistConnectionRequest(req).catch(() => {});

    // Canonical connection ID based on type and sorted user IDs
    const sortedIds = [req.senderId, req.receiverId].sort();
    const connId = `${req.type}-${sortedIds[0]}_${sortedIds[1]}`;

    const newConnection: Connection = {
      id: connId,
      type: req.type,
      user1Id: req.senderId,
      user2Id: req.receiverId,
      level: 1,
      intimacyPoints: 100,
      sharedGiftsCount: 0,
      sharedGiftsCoins: 0,
      status: 'active',
      establishedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    dbStore.persistConnection(newConnection).catch(() => {});

    // If CP, cancel any other pending CP requests involving either user
    if (req.type === 'cp') {
      for (const otherReq of dbStore.connectionRequests.values()) {
        if (otherReq.id !== req.id && otherReq.type === 'cp' && otherReq.status === 'pending') {
          if (
            otherReq.senderId === req.senderId ||
            otherReq.receiverId === req.senderId ||
            otherReq.senderId === req.receiverId ||
            otherReq.receiverId === req.receiverId
          ) {
            otherReq.status = 'cancelled';
            otherReq.updatedAt = new Date().toISOString();
            dbStore.persistConnectionRequest(otherReq).catch(() => {});
          }
        }
      }
    }

    // Send success notifications to both users
    const notifTitle = req.type === 'cp' ? '❤️ CP Connected!' : '👥 Friend Connected!';
    NotificationService.sendNotification(
      req.senderId,
      notifTitle,
      `You and ${receiver.name} are now ${req.type === 'cp' ? 'CP partners' : 'friends'}! 🎉`,
      'system'
    );
    NotificationService.sendNotification(
      req.receiverId,
      notifTitle,
      `You and ${sender.name} are now ${req.type === 'cp' ? 'CP partners' : 'friends'}! 🎉`,
      'system'
    );

    return {
      connection: {
        ...newConnection,
        user1: sender,
        user2: receiver
      },
      request: {
        ...req,
        sender,
        receiver
      }
    };
  }

  /**
   * Decline an incoming request
   * Backend strictly validates that request.receiverId === userId
   */
  public static declineRequest(userId: string, requestId: string): ConnectionRequest {
    const req = dbStore.connectionRequests.get(requestId);
    if (!req) throw new Error('Connection request not found');

    if (req.status !== 'pending') {
      throw new Error(`This request has already been ${req.status}`);
    }

    if (req.receiverId !== userId) {
      throw new Error('You are not authorized to decline this request');
    }

    req.status = 'declined';
    req.updatedAt = new Date().toISOString();
    dbStore.persistConnectionRequest(req).catch(() => {});

    return req;
  }

  /**
   * Cancel an outgoing request
   * Backend strictly validates that request.senderId === userId
   */
  public static cancelRequest(userId: string, requestId: string): ConnectionRequest {
    const req = dbStore.connectionRequests.get(requestId);
    if (!req) throw new Error('Connection request not found');

    if (req.status !== 'pending') {
      throw new Error(`This request has already been ${req.status}`);
    }

    if (req.senderId !== userId) {
      throw new Error('You are not authorized to cancel this request');
    }

    req.status = 'cancelled';
    req.updatedAt = new Date().toISOString();
    dbStore.persistConnectionRequest(req).catch(() => {});

    return req;
  }

  /**
   * Remove/terminate an active connection (Unfriend or CP Breakup)
   * Backend strictly validates that caller is user1Id or user2Id
   */
  public static removeConnection(userId: string, connectionId: string): { success: boolean; connection: Connection } {
    const conn = dbStore.connections.get(connectionId);
    if (!conn) throw new Error('Connection record not found');

    if (conn.status !== 'active') {
      throw new Error('Connection is already inactive');
    }

    if (conn.user1Id !== userId && conn.user2Id !== userId) {
      throw new Error('You are not a member of this connection');
    }

    const partnerId = conn.user1Id === userId ? conn.user2Id : conn.user1Id;
    const partner = this.getUser(partnerId);
    const currentUser = this.getUser(userId);

    conn.status = 'terminated';
    conn.updatedAt = new Date().toISOString();
    dbStore.persistConnection(conn).catch(() => {});

    // Notify the other user
    if (partner) {
      const typeLabel = conn.type === 'cp' ? 'CP Connection' : 'Friendship';
      NotificationService.sendNotification(
        partnerId,
        `🔔 ${typeLabel} Ended`,
        `${currentUser?.name || 'A user'} has removed the ${conn.type === 'cp' ? 'CP' : 'friend'} connection.`,
        'system'
      );
    }

    return {
      success: true,
      connection: {
        ...conn,
        user1: this.getUser(conn.user1Id),
        user2: this.getUser(conn.user2Id)
      }
    };
  }

  /**
   * Block a user
   */
  public static blockUser(userId: string, targetUserId: string): BlockedUserRecord {
    if (userId === targetUserId) {
      throw new Error('Cannot block yourself');
    }

    const targetUser = this.getUser(targetUserId);
    if (!targetUser) throw new Error('User not found');

    // Terminate any active connections between them
    for (const conn of dbStore.connections.values()) {
      if (conn.status === 'active') {
        if (
          (conn.user1Id === userId && conn.user2Id === targetUserId) ||
          (conn.user1Id === targetUserId && conn.user2Id === userId)
        ) {
          conn.status = 'terminated';
          conn.updatedAt = new Date().toISOString();
          dbStore.persistConnection(conn).catch(() => {});
        }
      }
    }

    // Cancel any pending requests
    for (const req of dbStore.connectionRequests.values()) {
      if (req.status === 'pending') {
        if (
          (req.senderId === userId && req.receiverId === targetUserId) ||
          (req.senderId === targetUserId && req.receiverId === userId)
        ) {
          req.status = 'cancelled';
          req.updatedAt = new Date().toISOString();
          dbStore.persistConnectionRequest(req).catch(() => {});
        }
      }
    }

    const blockId = `blk-${userId}_${targetUserId}`;
    const record: BlockedUserRecord = {
      id: blockId,
      userId,
      blockedUserId: targetUserId,
      createdAt: new Date().toISOString()
    };

    dbStore.persistBlockedUser(record).catch(() => {});

    return record;
  }

  /**
   * Unblock a user
   */
  public static unblockUser(userId: string, targetUserId: string): boolean {
    const blockId = `blk-${userId}_${targetUserId}`;
    dbStore.removeBlockedUserFromFirestore(blockId).catch(() => {});
    return true;
  }

  /**
   * Get all blocked users for a user
   */
  public static getBlockedUsers(userId: string): User[] {
    const list: User[] = [];
    for (const record of dbStore.blockedUsers.values()) {
      if (record.userId === userId) {
        const u = this.getUser(record.blockedUserId);
        if (u) list.push(u);
      }
    }
    return list;
  }

  /**
   * Discover and search users with annotated connection relationship
   */
  public static discoverUsers(userId: string, search?: string): (User & {
    connectionStatus: 'self' | 'friend' | 'cp' | 'pending_sent' | 'pending_received' | 'blocked' | 'none';
  })[] {
    const cleanSearch = (search || '').trim().toLowerCase();
    const result: (User & { connectionStatus: any })[] = [];

    // Precompute friend and CP partners
    const activeFriends = new Set<string>();
    let activeCpPartnerId: string | null = null;

    for (const conn of dbStore.connections.values()) {
      if (conn.status === 'active') {
        if (conn.type === 'friend') {
          if (conn.user1Id === userId) activeFriends.add(conn.user2Id);
          if (conn.user2Id === userId) activeFriends.add(conn.user1Id);
        } else if (conn.type === 'cp') {
          if (conn.user1Id === userId) activeCpPartnerId = conn.user2Id;
          if (conn.user2Id === userId) activeCpPartnerId = conn.user1Id;
        }
      }
    }

    // Precompute pending requests
    const pendingSent = new Set<string>();
    const pendingReceived = new Set<string>();

    for (const req of dbStore.connectionRequests.values()) {
      if (req.status === 'pending') {
        if (req.senderId === userId) pendingSent.add(req.receiverId);
        if (req.receiverId === userId) pendingReceived.add(req.senderId);
      }
    }

    const blockedIds = new Set<string>();
    for (const record of dbStore.blockedUsers.values()) {
      if (record.userId === userId) blockedIds.add(record.blockedUserId);
      if (record.blockedUserId === userId) blockedIds.add(record.userId);
    }

    for (const user of dbStore.users.values()) {
      if (user.id === userId || user.uid === userId) {
        if (!cleanSearch) continue; // don't show self in default discover, only if specifically queried
      }

      if (blockedIds.has(user.id) || (user.uid && blockedIds.has(user.uid))) {
        continue;
      }

      // Filter by search if provided (name, uid, nigoId, country)
      if (cleanSearch) {
        const matches = 
          user.name.toLowerCase().includes(cleanSearch) ||
          user.uid.toLowerCase().includes(cleanSearch) ||
          (user.nigoId && user.nigoId.toLowerCase().includes(cleanSearch)) ||
          user.country.toLowerCase().includes(cleanSearch);
        if (!matches) continue;
      }

      let connectionStatus: 'self' | 'friend' | 'cp' | 'pending_sent' | 'pending_received' | 'blocked' | 'none' = 'none';
      if (user.id === userId || user.uid === userId) {
        connectionStatus = 'self';
      } else if (activeCpPartnerId === user.id || (user.uid && activeCpPartnerId === user.uid)) {
        connectionStatus = 'cp';
      } else if (activeFriends.has(user.id) || (user.uid && activeFriends.has(user.uid))) {
        connectionStatus = 'friend';
      } else if (pendingSent.has(user.id) || (user.uid && pendingSent.has(user.uid))) {
        connectionStatus = 'pending_sent';
      } else if (pendingReceived.has(user.id) || (user.uid && pendingReceived.has(user.uid))) {
        connectionStatus = 'pending_received';
      }

      result.push({
        ...user,
        connectionStatus
      });
    }

    // Sort: online users first, then by level
    result.sort((a, b) => {
      if (a.isOnline && !b.isOnline) return -1;
      if (!a.isOnline && b.isOnline) return 1;
      return (b.level || 1) - (a.level || 1);
    });

    return result.slice(0, 100);
  }

  /**
   * Hook called when a gift is sent between two users
   * If they are CP partners, automatically update shared gifts & intimacy!
   */
  public static onGiftSent(senderId: string, receiverId: string, coinsSpent: number, giftCount: number = 1): void {
    for (const conn of dbStore.connections.values()) {
      if (conn.type === 'cp' && conn.status === 'active') {
        if (
          (conn.user1Id === senderId && conn.user2Id === receiverId) ||
          (conn.user1Id === receiverId && conn.user2Id === senderId)
        ) {
          conn.sharedGiftsCount = (conn.sharedGiftsCount || 0) + giftCount;
          conn.sharedGiftsCoins = (conn.sharedGiftsCoins || 0) + coinsSpent;
          
          // Intimacy points calculation: 10% of coins spent + 10 base per gift
          const pointsEarned = Math.floor(coinsSpent * 0.1) + (10 * giftCount);
          conn.intimacyPoints = (conn.intimacyPoints || 0) + pointsEarned;

          // Connection level calculation based on intimacy points
          // Lv 1: 0 - 500
          // Lv 2: 500 - 1500
          // Lv 3: 1500 - 3500
          // Lv 4: 3500 - 7000
          // Lv 5: 7000+
          const pts = conn.intimacyPoints;
          let calculatedLevel = 1;
          if (pts >= 7000) calculatedLevel = 5;
          else if (pts >= 3500) calculatedLevel = 4;
          else if (pts >= 1500) calculatedLevel = 3;
          else if (pts >= 500) calculatedLevel = 2;

          conn.level = calculatedLevel;
          conn.updatedAt = new Date().toISOString();

          dbStore.persistConnection(conn).catch(() => {});
          break;
        }
      }
    }
  }

  // ==========================================
  // ADMIN CP & FRIENDSHIP MANAGEMENT OPERATIONS
  // ==========================================

  public static calculateCpLevel(intimacy: number): number {
    if (intimacy >= 15000) return 5;
    if (intimacy >= 5000) return 4;
    if (intimacy >= 2000) return 3;
    if (intimacy >= 500) return 2;
    return 1;
  }

  /**
   * Get full executive statistics overview for CP and Friendship
   */
  public static getAdminOverview(): AdminConnectionOverview {
    let totalActiveCp = 0;
    let totalTerminatedCp = 0;
    let totalActiveFriends = 0;
    let totalTerminatedFriends = 0;
    let totalIntimacyPoints = 0;
    let totalSharedCoins = 0;

    const levelDistribution: Record<number, number> = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
    const allCps: Connection[] = [];

    for (const conn of dbStore.connections.values()) {
      if (conn.type === 'cp') {
        if (conn.status === 'active') {
          totalActiveCp++;
          totalIntimacyPoints += conn.intimacyPoints || 0;
          totalSharedCoins += conn.sharedGiftsCoins || 0;
          const lvl = conn.level || 1;
          levelDistribution[lvl] = (levelDistribution[lvl] || 0) + 1;
          allCps.push({
            ...conn,
            user1: this.getUser(conn.user1Id),
            user2: this.getUser(conn.user2Id)
          });
        } else {
          totalTerminatedCp++;
        }
      } else if (conn.type === 'friend') {
        if (conn.status === 'active') {
          totalActiveFriends++;
        } else {
          totalTerminatedFriends++;
        }
      }
    }

    let totalPendingRequests = 0;
    let totalAcceptedRequests = 0;
    let totalDeclinedRequests = 0;
    let totalCancelledRequests = 0;

    for (const req of dbStore.connectionRequests.values()) {
      if (req.status === 'pending') totalPendingRequests++;
      else if (req.status === 'accepted') totalAcceptedRequests++;
      else if (req.status === 'declined') totalDeclinedRequests++;
      else if (req.status === 'cancelled') totalCancelledRequests++;
    }

    // Top CP couples sorted by intimacy points
    allCps.sort((a, b) => (b.intimacyPoints || 0) - (a.intimacyPoints || 0));
    const topCpCouples = allCps.slice(0, 10);
    const averageIntimacy = totalActiveCp > 0 ? Math.round(totalIntimacyPoints / totalActiveCp) : 0;

    return {
      totalActiveCp,
      totalTerminatedCp,
      totalActiveFriends,
      totalTerminatedFriends,
      totalPendingRequests,
      totalAcceptedRequests,
      totalDeclinedRequests,
      totalCancelledRequests,
      totalIntimacyPoints,
      totalSharedCoins,
      averageIntimacy,
      levelDistribution,
      topCpCouples
    };
  }

  /**
   * Get all connections with filtering and user population
   */
  public static getAdminConnections(filters: {
    type?: string;
    status?: string;
    search?: string;
    minLevel?: number;
    sortBy?: string;
  }): Connection[] {
    const list: Connection[] = [];
    const searchClean = (filters.search || '').trim().toLowerCase();

    for (const conn of dbStore.connections.values()) {
      // Type filter
      if (filters.type && filters.type !== 'all' && conn.type !== filters.type) {
        continue;
      }
      // Status filter
      if (filters.status && filters.status !== 'all' && conn.status !== filters.status) {
        continue;
      }
      // Level filter
      if (filters.minLevel && (conn.level || 1) < filters.minLevel) {
        continue;
      }

      const u1 = this.getUser(conn.user1Id);
      const u2 = this.getUser(conn.user2Id);

      // Search query filter (matches name, UID, or connection ID)
      if (searchClean) {
        const matches =
          conn.id.toLowerCase().includes(searchClean) ||
          (u1 && (
            u1.name.toLowerCase().includes(searchClean) ||
            u1.uid.toLowerCase().includes(searchClean) ||
            u1.id.toLowerCase().includes(searchClean)
          )) ||
          (u2 && (
            u2.name.toLowerCase().includes(searchClean) ||
            u2.uid.toLowerCase().includes(searchClean) ||
            u2.id.toLowerCase().includes(searchClean)
          ));

        if (!matches) continue;
      }

      list.push({
        ...conn,
        user1: u1,
        user2: u2
      });
    }

    // Sort
    const sortBy = filters.sortBy || 'newest';
    if (sortBy === 'intimacy') {
      list.sort((a, b) => (b.intimacyPoints || 0) - (a.intimacyPoints || 0));
    } else if (sortBy === 'coins') {
      list.sort((a, b) => (b.sharedGiftsCoins || 0) - (a.sharedGiftsCoins || 0));
    } else if (sortBy === 'oldest') {
      list.sort((a, b) => new Date(a.establishedAt).getTime() - new Date(b.establishedAt).getTime());
    } else {
      // newest default
      list.sort((a, b) => new Date(b.establishedAt).getTime() - new Date(a.establishedAt).getTime());
    }

    return list;
  }

  /**
   * Admin forcefully creates or bonds a CP connection between two users
   */
  public static adminCreateCP(
    user1Id: string,
    user2Id: string,
    intimacyPoints: number = 100,
    level?: number,
    ceremonyNote?: string,
    adminUser?: User,
    forceOverride: boolean = false
  ): Connection {
    if (!user1Id || !user2Id) throw new Error('Both partner user IDs are required');
    if (user1Id === user2Id) throw new Error('Cannot create CP bond with oneself');

    const u1 = this.getUser(user1Id);
    const u2 = this.getUser(user2Id);
    if (!u1) throw new Error(`Partner 1 user (${user1Id}) not found`);
    if (!u2) throw new Error(`Partner 2 user (${user2Id}) not found`);

    // Check existing active CP
    const existingCp1 = this.getCP(user1Id);
    const existingCp2 = this.getCP(user2Id);

    if (existingCp1) {
      if (!forceOverride) {
        throw new Error(`${u1.name} already has an active CP bond. Use Force Override to dissolve previous bond.`);
      }
      // Terminate old CP
      const oldConn = dbStore.connections.get(existingCp1.id);
      if (oldConn) {
        oldConn.status = 'terminated';
        oldConn.updatedAt = new Date().toISOString();
        dbStore.persistConnection(oldConn).catch(() => {});
      }
    }

    if (existingCp2) {
      if (!forceOverride) {
        throw new Error(`${u2.name} already has an active CP bond. Use Force Override to dissolve previous bond.`);
      }
      // Terminate old CP
      const oldConn = dbStore.connections.get(existingCp2.id);
      if (oldConn) {
        oldConn.status = 'terminated';
        oldConn.updatedAt = new Date().toISOString();
        dbStore.persistConnection(oldConn).catch(() => {});
      }
    }

    const calculatedLevel = level && level >= 1 && level <= 5 ? level : this.calculateCpLevel(intimacyPoints);
    const sortedIds = [user1Id, user2Id].sort();
    const connId = `cp-${sortedIds[0]}_${sortedIds[1]}`;

    const newConnection: Connection = {
      id: connId,
      type: 'cp',
      user1Id,
      user2Id,
      level: calculatedLevel,
      intimacyPoints: Math.max(0, intimacyPoints),
      sharedGiftsCount: 0,
      sharedGiftsCoins: 0,
      status: 'active',
      establishedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    dbStore.persistConnection(newConnection).catch(() => {});

    // Cancel pending requests
    for (const req of dbStore.connectionRequests.values()) {
      if (req.type === 'cp' && req.status === 'pending') {
        if (
          req.senderId === user1Id || req.receiverId === user1Id ||
          req.senderId === user2Id || req.receiverId === user2Id
        ) {
          req.status = 'accepted';
          req.updatedAt = new Date().toISOString();
          dbStore.persistConnectionRequest(req).catch(() => {});
        }
      }
    }

    // Send notifications to both users
    const msg = ceremonyNote || 'Congratulations! You have been officially bound as CP partners by Platform Administration! 👑❤️';
    NotificationService.sendNotification(user1Id, '❤️ CP Partner Official Bond', msg, 'system');
    NotificationService.sendNotification(user2Id, '❤️ CP Partner Official Bond', msg, 'system');

    // Audit log
    dbStore.recordAudit({
      action: 'ADMIN_CP_FORCE_CREATED',
      module: 'connections',
      performedByUserId: adminUser?.id || 'admin',
      performedByUserName: adminUser?.name || 'Administrator',
      performedByRole: adminUser?.role || 'admin',
      targetId: connId,
      targetName: `${u1.name} & ${u2.name}`,
      details: `Established CP bond between ${u1.name} (UID: ${u1.uid}) and ${u2.name} (UID: ${u2.uid}) with Level ${calculatedLevel} (${intimacyPoints} intimacy pts). ${ceremonyNote ? `Note: ${ceremonyNote}` : ''}`,
      ipAddress: '127.0.0.1'
    });

    return {
      ...newConnection,
      user1: u1,
      user2: u2
    };
  }

  /**
   * Admin adjusts intimacy points and/or level
   */
  public static adminAdjustIntimacy(
    connectionId: string,
    intimacyPoints: number,
    level?: number,
    sharedGiftsCoins?: number,
    reason: string = 'Administrative Intimacy Adjustment',
    adminUser?: User
  ): Connection {
    const conn = dbStore.connections.get(connectionId);
    if (!conn) throw new Error('Connection record not found');
    if (conn.type !== 'cp') throw new Error('Only CP connections have intimacy points and levels');

    const prevPoints = conn.intimacyPoints || 0;
    const prevLevel = conn.level || 1;

    conn.intimacyPoints = Math.max(0, intimacyPoints);
    if (level && level >= 1 && level <= 5) {
      conn.level = level;
    } else {
      conn.level = this.calculateCpLevel(conn.intimacyPoints);
    }

    if (typeof sharedGiftsCoins === 'number') {
      conn.sharedGiftsCoins = Math.max(0, sharedGiftsCoins);
    }

    conn.updatedAt = new Date().toISOString();
    dbStore.persistConnection(conn).catch(() => {});

    const u1 = this.getUser(conn.user1Id);
    const u2 = this.getUser(conn.user2Id);

    // Notify users
    const notifText = `Your CP intimacy has been updated to ${conn.intimacyPoints} pts (Level ${conn.level}). Reason: ${reason}`;
    NotificationService.sendNotification(conn.user1Id, '✨ CP Intimacy Updated', notifText, 'system');
    NotificationService.sendNotification(conn.user2Id, '✨ CP Intimacy Updated', notifText, 'system');

    // Audit log
    dbStore.recordAudit({
      action: 'ADMIN_CP_INTIMACY_ADJUSTED',
      module: 'connections',
      performedByUserId: adminUser?.id || 'admin',
      performedByUserName: adminUser?.name || 'Administrator',
      performedByRole: adminUser?.role || 'admin',
      targetId: connectionId,
      targetName: `${u1?.name || conn.user1Id} & ${u2?.name || conn.user2Id}`,
      details: `Adjusted CP Intimacy: ${prevPoints} -> ${conn.intimacyPoints} pts, Level ${prevLevel} -> Level ${conn.level}. Reason: ${reason}`,
      ipAddress: '127.0.0.1'
    });

    return {
      ...conn,
      user1: u1,
      user2: u2
    };
  }

  /**
   * Admin terminates / dissolves a CP or friendship connection
   */
  public static adminTerminateConnection(
    connectionId: string,
    reason: string = 'Terminated by Platform Administrator',
    adminUser?: User
  ): Connection {
    const conn = dbStore.connections.get(connectionId);
    if (!conn) throw new Error('Connection record not found');

    const u1 = this.getUser(conn.user1Id);
    const u2 = this.getUser(conn.user2Id);

    conn.status = 'terminated';
    conn.updatedAt = new Date().toISOString();
    dbStore.persistConnection(conn).catch(() => {});

    const label = conn.type === 'cp' ? 'CP Partner Bond' : 'Friendship';
    NotificationService.sendNotification(
      conn.user1Id,
      `🔔 ${label} Dissolved`,
      `Your ${conn.type === 'cp' ? 'CP couple relationship' : 'friendship'} has been dissolved by administration. Reason: ${reason}`,
      'system'
    );
    NotificationService.sendNotification(
      conn.user2Id,
      `🔔 ${label} Dissolved`,
      `Your ${conn.type === 'cp' ? 'CP couple relationship' : 'friendship'} has been dissolved by administration. Reason: ${reason}`,
      'system'
    );

    // Audit log
    dbStore.recordAudit({
      action: 'ADMIN_CONNECTION_TERMINATED',
      module: 'connections',
      performedByUserId: adminUser?.id || 'admin',
      performedByUserName: adminUser?.name || 'Administrator',
      performedByRole: adminUser?.role || 'admin',
      targetId: connectionId,
      targetName: `${u1?.name || conn.user1Id} & ${u2?.name || conn.user2Id}`,
      details: `Dissolved ${conn.type.toUpperCase()} connection. Reason: ${reason}`,
      ipAddress: '127.0.0.1'
    });

    return {
      ...conn,
      user1: u1,
      user2: u2
    };
  }

  /**
   * Admin establishes a direct friendship between two users
   */
  public static adminCreateFriendship(
    user1Id: string,
    user2Id: string,
    note?: string,
    adminUser?: User
  ): Connection {
    if (!user1Id || !user2Id) throw new Error('Both user IDs are required');
    if (user1Id === user2Id) throw new Error('Cannot add friendship with oneself');

    const u1 = this.getUser(user1Id);
    const u2 = this.getUser(user2Id);
    if (!u1) throw new Error(`User 1 (${user1Id}) not found`);
    if (!u2) throw new Error(`User 2 (${user2Id}) not found`);

    const sortedIds = [user1Id, user2Id].sort();
    const connId = `friend-${sortedIds[0]}_${sortedIds[1]}`;

    let conn = dbStore.connections.get(connId);
    if (conn) {
      conn.status = 'active';
      conn.updatedAt = new Date().toISOString();
    } else {
      conn = {
        id: connId,
        type: 'friend',
        user1Id: sortedIds[0],
        user2Id: sortedIds[1],
        level: 1,
        intimacyPoints: 0,
        sharedGiftsCount: 0,
        sharedGiftsCoins: 0,
        status: 'active',
        establishedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
    }

    dbStore.persistConnection(conn).catch(() => {});

    // Audit log
    dbStore.recordAudit({
      action: 'ADMIN_FRIENDSHIP_FORCE_CREATED',
      module: 'connections',
      performedByUserId: adminUser?.id || 'admin',
      performedByUserName: adminUser?.name || 'Administrator',
      performedByRole: adminUser?.role || 'admin',
      targetId: connId,
      targetName: `${u1.name} & ${u2.name}`,
      details: `Force created friendship between ${u1.name} (UID: ${u1.uid}) and ${u2.name} (UID: ${u2.uid}). ${note ? `Note: ${note}` : ''}`,
      ipAddress: '127.0.0.1'
    });

    return {
      ...conn,
      user1: u1,
      user2: u2
    };
  }

  /**
   * Get all connection requests across platform for admin moderation
   */
  public static getAdminRequests(filters: {
    type?: string;
    status?: string;
    search?: string;
  }): ConnectionRequest[] {
    const list: ConnectionRequest[] = [];
    const searchClean = (filters.search || '').trim().toLowerCase();

    for (const req of dbStore.connectionRequests.values()) {
      if (filters.type && filters.type !== 'all' && req.type !== filters.type) {
        continue;
      }
      if (filters.status && filters.status !== 'all' && req.status !== filters.status) {
        continue;
      }

      const sender = this.getUser(req.senderId);
      const receiver = this.getUser(req.receiverId);

      if (searchClean) {
        const matches =
          req.id.toLowerCase().includes(searchClean) ||
          (req.message && req.message.toLowerCase().includes(searchClean)) ||
          (sender && (sender.name.toLowerCase().includes(searchClean) || sender.uid.toLowerCase().includes(searchClean))) ||
          (receiver && (receiver.name.toLowerCase().includes(searchClean) || receiver.uid.toLowerCase().includes(searchClean)));
        if (!matches) continue;
      }

      list.push({
        ...req,
        sender,
        receiver
      });
    }

    list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return list;
  }

  /**
   * Admin purges / cancels a connection request
   */
  public static adminPurgeRequest(requestId: string, adminUser?: User): boolean {
    const req = dbStore.connectionRequests.get(requestId);
    if (!req) throw new Error('Request not found');

    const sender = this.getUser(req.senderId);
    const receiver = this.getUser(req.receiverId);

    req.status = 'cancelled';
    req.updatedAt = new Date().toISOString();
    dbStore.persistConnectionRequest(req).catch(() => {});

    // Audit log
    dbStore.recordAudit({
      action: 'ADMIN_REQUEST_PURGED',
      module: 'connections',
      performedByUserId: adminUser?.id || 'admin',
      performedByUserName: adminUser?.name || 'Administrator',
      performedByRole: adminUser?.role || 'admin',
      targetId: requestId,
      targetName: `${req.type.toUpperCase()} Request (${sender?.name || req.senderId} -> ${receiver?.name || req.receiverId})`,
      details: `Purged request #${requestId}. Message: "${req.message || 'none'}"`,
      ipAddress: '127.0.0.1'
    });

    return true;
  }

  /**
   * Get all blocked relations across platform
   */
  public static getAdminBlockedUsers(search?: string): BlockedUserRecord[] {
    const list: BlockedUserRecord[] = [];
    const cleanSearch = (search || '').trim().toLowerCase();

    for (const record of dbStore.blockedUsers.values()) {
      const u = this.getUser(record.userId);
      const bu = this.getUser(record.blockedUserId);

      if (cleanSearch) {
        const matches =
          record.id.toLowerCase().includes(cleanSearch) ||
          (u && (u.name.toLowerCase().includes(cleanSearch) || u.uid.toLowerCase().includes(cleanSearch))) ||
          (bu && (bu.name.toLowerCase().includes(cleanSearch) || bu.uid.toLowerCase().includes(cleanSearch)));
        if (!matches) continue;
      }

      list.push({
        ...record,
        user: u,
        blockedUser: bu
      });
    }

    list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return list;
  }

  /**
   * Admin unblocks a user pair
   */
  public static adminUnblock(userId: string, targetUserId: string, reason?: string, adminUser?: User): boolean {
    const blockId = `blk-${userId}_${targetUserId}`;
    dbStore.removeBlockedUserFromFirestore(blockId).catch(() => {});

    const u1 = this.getUser(userId);
    const u2 = this.getUser(targetUserId);

    dbStore.recordAudit({
      action: 'ADMIN_USER_UNBLOCKED',
      module: 'connections',
      performedByUserId: adminUser?.id || 'admin',
      performedByUserName: adminUser?.name || 'Administrator',
      performedByRole: adminUser?.role || 'admin',
      targetId: blockId,
      targetName: `${u1?.name || userId} unblocked ${u2?.name || targetUserId}`,
      details: `Administrative unblock. Reason: ${reason || 'Manual Admin Intervention'}`,
      ipAddress: '127.0.0.1'
    });

    return true;
  }

  /**
   * Get system connection config
   */
  public static getConnectionConfig(): ConnectionSystemConfig {
    return dbStore.connectionConfig;
  }

  /**
   * Update system connection config
   */
  public static updateConnectionConfig(config: Partial<ConnectionSystemConfig>, adminUser?: User): ConnectionSystemConfig {
    const current = dbStore.connectionConfig;
    const updated: ConnectionSystemConfig = {
      ...current,
      ...config,
      updatedAt: new Date().toISOString(),
      updatedBy: adminUser ? `${adminUser.name} (${adminUser.role.toUpperCase()})` : 'Administrator'
    };

    dbStore.persistConnectionConfigToFirestore(updated).catch(() => {});

    dbStore.recordAudit({
      action: 'ADMIN_CONNECTION_CONFIG_UPDATED',
      module: 'connections',
      performedByUserId: adminUser?.id || 'admin',
      performedByUserName: adminUser?.name || 'Administrator',
      performedByRole: adminUser?.role || 'admin',
      targetId: 'adminSettings/connectionConfig',
      targetName: 'Connection System Config',
      details: `Updated CP & Friendship system rules: MinLevel: ${updated.minUserLevelForCp}, InitialPts: ${updated.initialIntimacyPoints}, MaxFriends: ${updated.maxFriendsLimit}`,
      ipAddress: '127.0.0.1'
    });

    return updated;
  }
}
