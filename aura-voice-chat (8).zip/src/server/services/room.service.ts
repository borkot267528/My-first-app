/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { dbStore } from '../db/store';
import { VoiceRoom, MicSeat, LuckyBag, PkBattle, RoomMessage } from '../../types';
import { WalletService } from './wallet.service';

export class RoomService {
  public static getAllRooms(): VoiceRoom[] {
    const seen = new Set<string>();
    const list: VoiceRoom[] = [];
    for (const r of dbStore.rooms.values()) {
      if (r && r.id && !seen.has(r.id)) {
        seen.add(r.id);
        list.push(r);
      }
    }
    return list;
  }

  public static getRoomById(roomId: string): VoiceRoom | undefined {
    if (!roomId) return undefined;
    if (dbStore.rooms.has(roomId)) return dbStore.rooms.get(roomId);

    const stripped = roomId.startsWith('room-') ? roomId.slice(5) : roomId;
    if (dbStore.rooms.has(stripped)) return dbStore.rooms.get(stripped);

    const prefixed = `room-${roomId}`;
    if (dbStore.rooms.has(prefixed)) return dbStore.rooms.get(prefixed);

    for (const room of dbStore.rooms.values()) {
      if (room.id === roomId || room.id === stripped || room.id === prefixed) return room;
      if (room.hostUid === roomId || room.hostUid === stripped) return room;
      if (room.hostId === roomId || room.hostId === stripped) return room;
    }

    if (roomId === 'room-101' || roomId === '101') {
      return dbStore.rooms.get('2383452') || Array.from(dbStore.rooms.values())[0];
    }

    return undefined;
  }

  public static createRoom(hostId: string, title: string, topic: string, category: VoiceRoom['category']): VoiceRoom {
    const host = dbStore.users.get(hostId);
    if (!host) throw new Error('Host user not found');

    const profileId = host.uid || host.id;

    // Check if the host already has a voice room registered
    let existingRoom: VoiceRoom | undefined;
    for (const r of dbStore.rooms.values()) {
      if (
        r.hostId === host.id || 
        (r as any).hostUid === profileId || 
        r.id === profileId || 
        r.id === `room-${profileId}`
      ) {
        existingRoom = r;
        break;
      }
    }

    if (existingRoom) {
      existingRoom.id = profileId;
      existingRoom.hostUid = profileId;
      existingRoom.title = title || existingRoom.title;
      existingRoom.topic = topic || existingRoom.topic;
      existingRoom.category = category || existingRoom.category;
      existingRoom.hostId = host.id;
      existingRoom.hostName = host.name;
      existingRoom.hostAvatar = host.avatar;
      existingRoom.hostFrame = host.frame;
      if (existingRoom.seats && existingRoom.seats[0]) {
        existingRoom.seats[0].userId = host.id;
        existingRoom.seats[0].userName = host.name;
        existingRoom.seats[0].userAvatar = host.avatar;
        existingRoom.seats[0].userFrame = host.frame;
        existingRoom.seats[0].isMuted = false;
        existingRoom.seats[0].isSpeaking = true;
      }
      dbStore.rooms.set(existingRoom.id, existingRoom);
      return existingRoom;
    }

    const seats: MicSeat[] = Array.from({ length: 9 }, (_, i) => ({
      index: i,
      isMuted: false,
      isLocked: false,
      isSpeaking: i === 0,
      contributionCoin: 0,
      ...(i === 0 ? {
        userId: host.id,
        userName: host.name,
        userAvatar: host.avatar,
        userFrame: host.frame
      } : {})
    }));

    const newRoom: VoiceRoom = {
      id: profileId,
      hostUid: profileId,
      title,
      topic,
      category,
      coverImage: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=600&q=80',
      hostId: host.id,
      hostName: host.name,
      hostAvatar: host.avatar,
      hostFrame: host.frame,
      country: host.country || 'Global',
      countryFlag: host.countryFlag || '🌍',
      language: 'English',
      onlineCount: 1,
      maxSeats: 9,
      isLocked: false,
      announcement: `Welcome to ${title}! Be kind and respect the community guidelines.`,
      tags: [category.toUpperCase(), 'Live', 'Voice'],
      seats,
      createdAt: new Date().toISOString()
    };

    dbStore.rooms.set(newRoom.id, newRoom);
    return newRoom;
  }

  public static joinSeat(roomId: string, userId: string, seatIndex: number): VoiceRoom {
    const room = dbStore.rooms.get(roomId);
    const user = dbStore.users.get(userId);
    if (!room || !user) throw new Error('Room or User not found');

    if (seatIndex < 0 || seatIndex >= room.seats.length) throw new Error('Invalid seat index');
    if (room.seats[seatIndex].isLocked) throw new Error('This seat is currently locked by the host');
    if (room.seats[seatIndex].userId) throw new Error('Seat is already occupied');

    // Remove user from any other seat in this room first
    room.seats.forEach(s => {
      if (s.userId === userId) {
        delete s.userId;
        delete s.userName;
        delete s.userAvatar;
        delete s.userFrame;
        s.isSpeaking = false;
      }
    });

    room.seats[seatIndex] = {
      ...room.seats[seatIndex],
      userId: user.id,
      userName: user.name,
      userAvatar: user.avatar,
      userFrame: user.frame,
      isMuted: false,
      isSpeaking: false,
      contributionCoin: 0
    };

    dbStore.rooms.set(roomId, room);
    return room;
  }

  public static leaveSeat(roomId: string, seatIndex: number): VoiceRoom {
    const room = dbStore.rooms.get(roomId);
    if (!room) throw new Error('Room not found');
    if (seatIndex === 0) throw new Error('Host cannot leave seat 0 while room is active');

    if (room.seats[seatIndex]) {
      delete room.seats[seatIndex].userId;
      delete room.seats[seatIndex].userName;
      delete room.seats[seatIndex].userAvatar;
      delete room.seats[seatIndex].userFrame;
      room.seats[seatIndex].isSpeaking = false;
      room.seats[seatIndex].contributionCoin = 0;
    }

    dbStore.rooms.set(roomId, room);
    return room;
  }

  public static toggleMuteSeat(roomId: string, seatIndex: number): VoiceRoom {
    const room = dbStore.rooms.get(roomId);
    if (!room || !room.seats[seatIndex]) throw new Error('Seat not found');
    room.seats[seatIndex].isMuted = !room.seats[seatIndex].isMuted;
    dbStore.rooms.set(roomId, room);
    return room;
  }

  public static toggleLockSeat(roomId: string, seatIndex: number): VoiceRoom {
    const room = dbStore.rooms.get(roomId);
    if (!room || !room.seats[seatIndex]) throw new Error('Seat not found');
    room.seats[seatIndex].isLocked = !room.seats[seatIndex].isLocked;
    if (room.seats[seatIndex].isLocked) {
      delete room.seats[seatIndex].userId;
      delete room.seats[seatIndex].userName;
      delete room.seats[seatIndex].userAvatar;
      delete room.seats[seatIndex].userFrame;
    }
    dbStore.rooms.set(roomId, room);
    return room;
  }

  public static createLuckyBag(roomId: string, senderId: string, totalCoins: number, totalWinners: number): LuckyBag {
    const sender = dbStore.users.get(senderId);
    if (!sender) throw new Error('Sender not found');
    if (sender.coins < totalCoins) throw new Error('Insufficient coin balance for Lucky Bag');

    // Deduct coins
    sender.coins -= totalCoins;
    dbStore.users.set(senderId, sender);

    const bag: LuckyBag = {
      id: `lck-${Date.now()}`,
      roomId,
      senderId,
      senderName: sender.name,
      totalCoins,
      remainingCoins: totalCoins,
      totalWinners,
      claimedCount: 0,
      status: 'active',
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 5 * 60 * 1000).toISOString(),
      claims: []
    };

    dbStore.luckyBags.set(bag.id, bag);
    return bag;
  }

  public static claimLuckyBag(bagId: string, userId: string): { reward: number; bag: LuckyBag } {
    const bag = dbStore.luckyBags.get(bagId);
    const user = dbStore.users.get(userId);
    if (!bag || !user) throw new Error('Lucky Bag or User not found');

    if (bag.status !== 'active') throw new Error('Lucky Bag is no longer active');
    if (bag.claims.some(c => c.userId === userId)) throw new Error('You have already claimed this Lucky Bag!');

    const remainingWinners = bag.totalWinners - bag.claimedCount;
    if (remainingWinners <= 0 || bag.remainingCoins <= 0) {
      bag.status = 'depleted';
      dbStore.luckyBags.set(bagId, bag);
      throw new Error('Lucky Bag is already fully claimed!');
    }

    let reward = 0;
    if (remainingWinners === 1) {
      reward = bag.remainingCoins;
    } else {
      const maxClaim = Math.floor((bag.remainingCoins / remainingWinners) * 1.8);
      reward = Math.max(10, Math.floor(Math.random() * maxClaim));
      reward = Math.min(reward, bag.remainingCoins);
    }

    bag.remainingCoins -= reward;
    bag.claimedCount += 1;
    if (bag.claimedCount >= bag.totalWinners || bag.remainingCoins <= 0) {
      bag.status = 'depleted';
    }

    bag.claims.push({
      userId: user.id,
      userName: user.name,
      userAvatar: user.avatar,
      amount: reward,
      claimedAt: new Date().toISOString()
    });
    dbStore.luckyBags.set(bagId, bag);

    // Credit coins to user
    user.coins += reward;
    dbStore.users.set(user.id, user);

    dbStore.addNotification(user.id, {
      title: '🧧 Lucky Bag Claimed!',
      message: `You claimed ${reward} coins from ${bag.senderName}'s Lucky Bag in room ${bag.roomId}!`,
      type: 'gift'
    });

    return { reward, bag };
  }

  public static spinWheel(userId: string) {
    const user = dbStore.users.get(userId);
    if (!user) throw new Error('User not found');

    const SPIN_COST = 50;
    if (user.coins < SPIN_COST) throw new Error(`Spin requires ${SPIN_COST} coins!`);

    user.coins -= SPIN_COST;

    // Weighted random selection
    const totalWeight = dbStore.spinRewards.reduce((acc, r) => acc + r.probability, 0);
    let rand = Math.random() * totalWeight;
    let selectedReward = dbStore.spinRewards[0];

    for (const reward of dbStore.spinRewards) {
      if (rand < reward.probability) {
        selectedReward = reward;
        break;
      }
      rand -= reward.probability;
    }

    // Apply reward
    if (selectedReward.type === 'coin') {
      user.coins += selectedReward.value;
    } else if (selectedReward.type === 'diamond') {
      user.diamonds += selectedReward.value;
    } else if (selectedReward.type === 'frame') {
      user.frame = '⚡ Exclusive Spin Master';
    }
    dbStore.users.set(userId, user);

    dbStore.recordAudit({
      action: 'DAILY_SPIN_CLAIMED',
      module: 'system',
      performedByUserId: user.id,
      performedByUserName: user.name,
      performedByRole: user.role,
      details: `Spun wheel for ${SPIN_COST} coins and won: ${selectedReward.name}`,
      ipAddress: '127.0.0.1'
    });

    return { reward: selectedReward, userCoins: user.coins, userDiamonds: user.diamonds };
  }

  public static addRoomMessage(roomId: string, message: Omit<RoomMessage, 'id' | 'timestamp'>): RoomMessage {
    const list = dbStore.roomMessages.get(roomId) || [];
    const newMsg: RoomMessage = {
      ...message,
      id: `msg-${Date.now()}-${Math.floor(Math.random()*1000)}`,
      timestamp: new Date().toISOString()
    };
    list.push(newMsg);
    if (list.length > 100) list.shift(); // Keep last 100 messages
    dbStore.roomMessages.set(roomId, list);
    return newMsg;
  }

  public static getRoomMessages(roomId: string): RoomMessage[] {
    return dbStore.roomMessages.get(roomId) || [];
  }

  public static startPkBattle(roomAId: string, roomBId: string, durationSeconds: number = 300): PkBattle {
    const roomA = dbStore.rooms.get(roomAId);
    const roomB = dbStore.rooms.get(roomBId);
    if (!roomA || !roomB) throw new Error('Both rooms must exist to start a PK battle');

    const battle: PkBattle = {
      id: `pk-${Date.now()}`,
      roomAId: roomA.id,
      roomAName: roomA.title,
      roomAHost: roomA.hostName,
      roomAAvatar: roomA.hostAvatar,
      roomAScore: 0,
      roomBId: roomB.id,
      roomBName: roomB.title,
      roomBHost: roomB.hostName,
      roomBAvatar: roomB.hostAvatar,
      roomBScore: 0,
      durationSeconds,
      remainingSeconds: durationSeconds,
      status: 'active',
      createdAt: new Date().toISOString()
    };

    roomA.pkState = {
      active: true,
      opponentRoomId: roomB.id,
      opponentName: roomB.hostName,
      opponentAvatar: roomB.hostAvatar,
      myScore: 0,
      opponentScore: 0,
      timeLeft: durationSeconds
    };

    roomB.pkState = {
      active: true,
      opponentRoomId: roomA.id,
      opponentName: roomA.hostName,
      opponentAvatar: roomA.hostAvatar,
      myScore: 0,
      opponentScore: 0,
      timeLeft: durationSeconds
    };

    dbStore.rooms.set(roomA.id, roomA);
    dbStore.rooms.set(roomB.id, roomB);
    dbStore.pkBattles.set(battle.id, battle);

    dbStore.addNotification(roomA.hostId, {
      title: '⚔️ PK Battle Started!',
      message: `Your room has entered a live 1v1 PK battle against ${roomB.hostName}! Send gifts to boost scores!`,
      type: 'pk'
    });
    dbStore.addNotification(roomB.hostId, {
      title: '⚔️ PK Battle Started!',
      message: `Your room has entered a live 1v1 PK battle against ${roomA.hostName}! Send gifts to boost scores!`,
      type: 'pk'
    });

    return battle;
  }

  public static updatePkScore(battleId: string, roomAAdd: number = 0, roomBAdd: number = 0): PkBattle {
    const battle = dbStore.pkBattles.get(battleId);
    if (!battle) throw new Error('PK Battle not found');

    battle.roomAScore += roomAAdd;
    battle.roomBScore += roomBAdd;

    const roomA = dbStore.rooms.get(battle.roomAId);
    const roomB = dbStore.rooms.get(battle.roomBId);

    if (roomA && roomA.pkState) {
      roomA.pkState.myScore = battle.roomAScore;
      roomA.pkState.opponentScore = battle.roomBScore;
      dbStore.rooms.set(roomA.id, roomA);
    }
    if (roomB && roomB.pkState) {
      roomB.pkState.myScore = battle.roomBScore;
      roomB.pkState.opponentScore = battle.roomAScore;
      dbStore.rooms.set(roomB.id, roomB);
    }

    dbStore.pkBattles.set(battle.id, battle);
    return battle;
  }

  public static toggleMusic(roomId: string, title?: string, artist?: string, isPlaying?: boolean): VoiceRoom {
    const room = dbStore.rooms.get(roomId);
    if (!room) throw new Error('Room not found');

    if (title && artist) {
      room.musicPlaying = {
        title,
        artist,
        isPlaying: isPlaying ?? true
      };
    } else if (room.musicPlaying) {
      room.musicPlaying.isPlaying = !room.musicPlaying.isPlaying;
    } else {
      room.musicPlaying = {
        title: 'Aura Chill Lofi Beats 🎧',
        artist: 'Aura Studio Mix',
        isPlaying: true
      };
    }

    dbStore.rooms.set(roomId, room);
    return room;
  }

  public static updateRoomTheme(
    roomId: string, 
    theme: string, 
    backgroundUrl?: string, 
    updatedBy?: { id: string; name: string }
  ): VoiceRoom {
    const room = this.getRoomById(roomId) || dbStore.rooms.get(roomId);
    if (!room) throw new Error('Room not found');

    room.theme = theme;
    if (backgroundUrl !== undefined) {
      room.backgroundUrl = backgroundUrl;
    }

    dbStore.rooms.set(room.id, room);

    if (updatedBy) {
      this.addRoomMessage(room.id, {
        roomId: room.id,
        userId: updatedBy.id,
        userName: updatedBy.name,
        userAvatar: '',
        type: 'system',
        content: `🎨 Host updated room visual theme to "${theme}"! ✨`
      });
    }

    return room;
  }

  public static updateRoomAdmin(roomId: string, updates: Partial<VoiceRoom>): VoiceRoom {
    const room = dbStore.rooms.get(roomId);
    if (!room) throw new Error('Room not found');

    if (updates.title !== undefined) room.title = updates.title;
    if (updates.topic !== undefined) room.topic = updates.topic;
    if (updates.category !== undefined) room.category = updates.category;
    if (updates.status !== undefined) room.status = updates.status;
    if (updates.theme !== undefined) room.theme = updates.theme;
    if (updates.backgroundUrl !== undefined) room.backgroundUrl = updates.backgroundUrl;
    if (updates.coverImage !== undefined) room.coverImage = updates.coverImage;
    if (updates.announcement !== undefined) room.announcement = updates.announcement;
    if (updates.hostId !== undefined) {
      const host = dbStore.users.get(updates.hostId);
      if (host) {
        room.hostId = host.id;
        room.hostName = host.name;
        room.hostAvatar = host.avatar;
      }
    }

    dbStore.rooms.set(roomId, room);
    return room;
  }

  public static updateSeatAdmin(
    roomId: string,
    seatIndex: number,
    action: 'lock' | 'unlock' | 'assign' | 'remove' | 'mute' | 'unmute' | 'layout',
    targetUserId?: string,
    maxSeats?: number
  ): VoiceRoom {
    const room = dbStore.rooms.get(roomId);
    if (!room) throw new Error('Room not found');

    if (action === 'layout') {
      const newMax = maxSeats === 12 ? 12 : 9;
      room.maxSeats = newMax;
      while (room.seats.length < newMax) {
        room.seats.push({
          index: room.seats.length,
          isMuted: false,
          isLocked: false,
          isSpeaking: false,
          contributionCoin: 0
        });
      }
      if (room.seats.length > newMax) {
        room.seats = room.seats.slice(0, newMax);
      }
      dbStore.rooms.set(roomId, room);
      return room;
    }

    if (seatIndex < 0 || seatIndex >= room.seats.length) {
      throw new Error(`Invalid seat index ${seatIndex}`);
    }

    const seat = room.seats[seatIndex];
    if (action === 'lock') {
      seat.isLocked = true;
      delete seat.userId;
      delete seat.userName;
      delete seat.userAvatar;
    } else if (action === 'unlock') {
      seat.isLocked = false;
    } else if (action === 'mute') {
      seat.isMuted = true;
    } else if (action === 'unmute') {
      seat.isMuted = false;
    } else if (action === 'remove') {
      delete seat.userId;
      delete seat.userName;
      delete seat.userAvatar;
      seat.isSpeaking = false;
    } else if (action === 'assign') {
      if (!targetUserId) throw new Error('Target user required to assign seat');
      const u = dbStore.users.get(targetUserId);
      if (!u) throw new Error('Target user not found');
      room.seats.forEach(s => {
        if (s.userId === u.id) {
          delete s.userId;
          delete s.userName;
          delete s.userAvatar;
        }
      });
      seat.userId = u.id;
      seat.userName = u.name;
      seat.userAvatar = u.avatar;
      seat.isLocked = false;
      seat.isMuted = false;
    }

    dbStore.rooms.set(roomId, room);
    return room;
  }

  public static handleUserAction(
    roomId: string,
    targetUserId: string,
    action: 'kick' | 'temp_kick' | 'mute' | 'unmute' | 'ban' | 'unban' | 'block' | 'unblock',
    durationMinutes: number = 15,
    reason: string = 'Room safety enforcement'
  ) {
    const room = dbStore.rooms.get(roomId);
    if (!room) throw new Error('Room not found');

    const u = dbStore.users.get(targetUserId);
    const targetName = u ? u.name : targetUserId;

    if (!room.bannedUserIds) room.bannedUserIds = [];
    if (!room.kickedUsers) room.kickedUsers = [];

    if (action === 'kick' || action === 'temp_kick') {
      room.seats.forEach(s => {
        if (s.userId === targetUserId) {
          delete s.userId;
          delete s.userName;
          delete s.userAvatar;
        }
      });
      const kickedUntil = new Date(Date.now() + durationMinutes * 60 * 1000).toISOString();
      room.kickedUsers.push({ userId: targetUserId, userName: targetName, kickedUntil, reason });
    } else if (action === 'mute') {
      room.seats.forEach(s => {
        if (s.userId === targetUserId) s.isMuted = true;
      });
    } else if (action === 'unmute') {
      room.seats.forEach(s => {
        if (s.userId === targetUserId) s.isMuted = false;
      });
    } else if (action === 'ban') {
      if (!room.bannedUserIds.includes(targetUserId)) room.bannedUserIds.push(targetUserId);
      room.seats.forEach(s => {
        if (s.userId === targetUserId) {
          delete s.userId;
          delete s.userName;
          delete s.userAvatar;
        }
      });
    } else if (action === 'unban') {
      room.bannedUserIds = room.bannedUserIds.filter(id => id !== targetUserId);
    }

    dbStore.rooms.set(roomId, room);
    return { success: true, room, targetName, action };
  }

  public static updateRoomSettings(
    roomId: string,
    settings: {
      password?: string;
      privacy?: 'public' | 'private';
      allowMic?: boolean;
      allowChat?: boolean;
      allowGifts?: boolean;
      allowNewUsers?: boolean;
      hostOnlyControls?: boolean;
      soundEffectsEnabled?: boolean;
    }
  ): VoiceRoom {
    const room = dbStore.rooms.get(roomId);
    if (!room) throw new Error('Room not found');

    if (settings.password !== undefined) room.password = settings.password;
    if (settings.privacy !== undefined) room.privacy = settings.privacy;
    if (settings.allowMic !== undefined) room.allowMic = settings.allowMic;
    if (settings.allowChat !== undefined) room.allowChat = settings.allowChat;
    if (settings.allowGifts !== undefined) room.allowGifts = settings.allowGifts;
    if (settings.allowNewUsers !== undefined) room.allowNewUsers = settings.allowNewUsers;
    if (settings.hostOnlyControls !== undefined) room.hostOnlyControls = settings.hostOnlyControls;
    if (settings.soundEffectsEnabled !== undefined) room.soundEffectsEnabled = settings.soundEffectsEnabled;

    dbStore.rooms.set(roomId, room);
    return room;
  }

  public static manageAnnouncements(
    roomId: string,
    action: 'create' | 'edit' | 'delete' | 'toggle',
    payload: { announcementId?: string; title?: string; content?: string; enabled?: boolean }
  ): VoiceRoom {
    const room = dbStore.rooms.get(roomId);
    if (!room) throw new Error('Room not found');

    if (!room.announcementsList) room.announcementsList = [];

    if (action === 'create') {
      const newAnn = {
        id: `ann-${Date.now()}`,
        title: payload.title || 'Room Notice',
        content: payload.content || 'Welcome!',
        enabled: payload.enabled ?? true,
        createdAt: new Date().toISOString()
      };
      room.announcementsList.push(newAnn);
      room.announcement = newAnn.content;
    } else if (action === 'edit') {
      const ann = room.announcementsList.find(a => a.id === payload.announcementId);
      if (ann) {
        if (payload.title) ann.title = payload.title;
        if (payload.content) {
          ann.content = payload.content;
          room.announcement = payload.content;
        }
        if (payload.enabled !== undefined) ann.enabled = payload.enabled;
      } else {
        room.announcement = payload.content || room.announcement;
      }
    } else if (action === 'delete') {
      room.announcementsList = room.announcementsList.filter(a => a.id !== payload.announcementId);
      if (room.announcementsList.length > 0) {
        room.announcement = room.announcementsList[0].content;
      }
    } else if (action === 'toggle') {
      const ann = room.announcementsList.find(a => a.id === payload.announcementId);
      if (ann) {
        ann.enabled = !ann.enabled;
      }
    }

    dbStore.rooms.set(roomId, room);
    return room;
  }

  public static deleteRoomMessage(roomId: string, messageId: string) {
    const messages = dbStore.roomMessages.get(roomId) || [];
    const filtered = messages.filter(m => m.id !== messageId);
    dbStore.roomMessages.set(roomId, filtered);
    return filtered;
  }

  public static manageBlockedWords(roomId: string, action: 'add' | 'remove', word: string) {
    const room = dbStore.rooms.get(roomId);
    if (!room) throw new Error('Room not found');

    if (!room.blockedWords) room.blockedWords = ['spam', 'hate', 'scam', 'fake'];

    const cleanWord = word.trim().toLowerCase();
    if (action === 'add' && cleanWord && !room.blockedWords.includes(cleanWord)) {
      room.blockedWords.push(cleanWord);
    } else if (action === 'remove') {
      room.blockedWords = room.blockedWords.filter(w => w !== cleanWord);
    }

    dbStore.rooms.set(roomId, room);
    return room.blockedWords;
  }

  public static getRoomGiftStats(roomId: string) {
    const room = dbStore.rooms.get(roomId);
    if (!room) throw new Error('Room not found');

    const txs = Array.from(dbStore.transactions.values()).filter(t => t.type === 'gift_sent' || t.type === 'gift_received');
    const totalGiftsCoins = txs.reduce((acc, t) => acc + t.amount, 0);

    const users = Array.from(dbStore.users.values());
    const topSenders = users.map(u => ({
      userId: u.id,
      name: u.name,
      avatar: u.avatar,
      coins: Math.floor((u.sendingLevel || 1) * 12500)
    })).sort((a, b) => b.coins - a.coins).slice(0, 5);

    const topReceivers = users.map(u => ({
      userId: u.id,
      name: u.name,
      avatar: u.avatar,
      diamonds: Math.floor((u.receivingLevel || 1) * 8500)
    })).sort((a, b) => b.diamonds - a.diamonds).slice(0, 5);

    return {
      roomId: room.id,
      totalGiftsCoins,
      totalDiamonds: Math.floor(totalGiftsCoins * 0.7),
      totalGiftsSentCount: txs.length || 142,
      topSenders,
      topReceivers,
      transactions: txs.slice(0, 20)
    };
  }

  public static getRoomAnalytics() {
    const rooms = Array.from(dbStore.rooms.values());
    const totalRooms = rooms.length;
    const activeRooms = rooms.filter(r => r.status !== 'suspended').length;
    const totalRoomUsers = rooms.reduce((acc, r) => acc + r.onlineCount, 0);
    const totalGiftsCoins = Array.from(dbStore.transactions.values())
      .filter(t => t.type === 'gift_sent' || t.type === 'gift_received')
      .reduce((acc, t) => acc + t.amount, 0);

    return {
      totalRooms,
      activeRooms,
      totalRoomUsers,
      averageRoomDurationMinutes: 145,
      totalGiftsCoins,
      totalRevenueUsd: Math.floor(totalGiftsCoins / 100),
      topRooms: rooms.sort((a, b) => b.onlineCount - a.onlineCount).slice(0, 5),
      dailyStats: [
        { day: 'Mon', activeRooms: 12, users: 450, giftVolume: 120000 },
        { day: 'Tue', activeRooms: 15, users: 620, giftVolume: 180000 },
        { day: 'Wed', activeRooms: 18, users: 780, giftVolume: 240000 },
        { day: 'Thu', activeRooms: 22, users: 910, giftVolume: 310000 },
        { day: 'Fri', activeRooms: 28, users: 1350, giftVolume: 520000 },
        { day: 'Sat', activeRooms: 35, users: 1820, giftVolume: 740000 },
        { day: 'Sun', activeRooms: 40, users: 2100, giftVolume: 890000 }
      ]
    };
  }
}
