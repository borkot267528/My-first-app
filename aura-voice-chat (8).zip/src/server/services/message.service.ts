/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { dbStore } from '../db/store';
import { PrivateMessage } from '../../types';

export class MessageService {
  private static getConversationKey(userAId: string, userBId: string): string {
    return [userAId, userBId].sort().join('_');
  }

  public static getPrivateMessages(userId: string, peerId: string): PrivateMessage[] {
    const key = this.getConversationKey(userId, peerId);
    const msgs = dbStore.privateMessages.get(key) || [];
    
    // Mark messages sent to userId as read
    msgs.forEach(m => {
      if (m.receiverId === userId) m.read = true;
    });
    
    return msgs;
  }

  public static sendPrivateMessage(senderId: string, receiverId: string, content: string, type: 'text' | 'image' | 'voice' | 'gift' = 'text'): PrivateMessage {
    const sender = dbStore.users.get(senderId);
    const receiver = dbStore.users.get(receiverId);
    if (!sender || !receiver) throw new Error('Sender or Receiver not found');

    const key = this.getConversationKey(senderId, receiverId);
    const list = dbStore.privateMessages.get(key) || [];

    const newMsg: PrivateMessage = {
      id: `pmsg-${Date.now()}-${Math.floor(Math.random()*1000)}`,
      senderId,
      receiverId,
      type,
      content,
      read: false,
      timestamp: new Date().toISOString()
    };

    list.push(newMsg);
    if (list.length > 200) list.shift(); // Keep last 200 per conversation
    dbStore.privateMessages.set(key, list);

    // Also trigger system notification if receiver is offline or busy
    if (!receiver.isOnline || type === 'gift') {
      dbStore.addNotification(receiverId, {
        title: `💬 New Message from ${sender.name}`,
        message: type === 'gift' ? `${sender.name} sent you a special gift in DM!` : `${content.slice(0, 50)}${content.length > 50 ? '...' : ''}`,
        type: type === 'gift' ? 'gift' : 'system'
      });
    }

    return newMsg;
  }

  public static getConversationsList(userId: string): { peerId: string; peerName: string; peerAvatar: string; lastMessage: string; timestamp: string; unreadCount: number }[] {
    const conversationsMap = new Map<string, { peerId: string; peerName: string; peerAvatar: string; lastMessage: string; timestamp: string; unreadCount: number }>();

    for (const [key, msgs] of dbStore.privateMessages.entries()) {
      if (key.includes(userId) && msgs.length > 0) {
        const lastMsg = msgs[msgs.length - 1];
        const peerId = lastMsg.senderId === userId ? lastMsg.receiverId : lastMsg.senderId;
        const peer = dbStore.users.get(peerId);
        if (!peer) continue;

        const unreadCount = msgs.filter(m => m.receiverId === userId && !m.read).length;

        conversationsMap.set(peerId, {
          peerId,
          peerName: peer.name,
          peerAvatar: peer.avatar,
          lastMessage: lastMsg.content,
          timestamp: lastMsg.timestamp,
          unreadCount
        });
      }
    }

    return Array.from(conversationsMap.values()).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }
}
