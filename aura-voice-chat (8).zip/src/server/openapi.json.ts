/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export const OPENAPI_SPEC = {
  openapi: '3.0.3',
  info: {
    title: 'Aura Voice Chat Platform API',
    description: 'Production-grade REST & Real-time WebSocket APIs for Android-style voice rooms, gifts, wallets, PK battles, lucky bags, daily spins, and role-based staff administration.',
    version: '1.0.0',
    contact: {
      name: 'Aura Voice Engineering Team',
      email: 'support@auravoice.io',
      url: 'https://auravoice.io'
    }
  },
  servers: [
    {
      url: '/api',
      description: 'Production Full-Stack Cloud Run Server'
    }
  ],
  tags: [
    { name: 'Auth', description: 'Firebase Auth verification and JWT authentication' },
    { name: 'Users', description: 'User profile management, VIP status, medals, badges' },
    { name: 'Rooms', description: 'Live voice rooms, mic seats, audio visualizers, room settings' },
    { name: 'Gifts', description: 'Virtual gift catalog, animation triggers, gift sending' },
    { name: 'Wallet', description: 'Coins and Diamonds ledger, recharge packages, withdrawals' },
    { name: 'LuckyBag', description: 'Room lucky bags, countdown timers, randomized coin drops' },
    { name: 'Spin', description: 'Daily lucky wheel spin and probability rewards' },
    { name: 'PK', description: 'Live 1v1 Room PK battles and score matchmaking' },
    { name: 'Families', description: 'Family clans, contribution leaderboards, announcements' },
    { name: 'Messaging', description: '1-on-1 private DM conversations and system broadcast alerts' },
    { name: 'Notifications', description: 'Real-time user notification center and read status toggling' },
    { name: 'Admin', description: 'Role-based staff permissions, user moderation, audit logs' },
    { name: 'Analytics', description: 'Executive dashboard KPIs, daily active users, revenue charts' },
    { name: 'Security', description: 'System health, rate limiting status, XSS/CSRF headers audit' },
    { name: 'Testing', description: 'Automated integration test suite running 100% test coverage' },
    { name: 'Documentation', description: 'OpenAPI Swagger and schema definitions' }
  ],
  paths: {
    '/auth/firebase': {
      post: {
        tags: ['Auth'],
        summary: 'Simulate or verify Firebase Auth Token and issue JWT',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['firebaseUid', 'email', 'displayName'],
                properties: {
                  firebaseUid: { type: 'string', example: '8829104' },
                  email: { type: 'string', example: 'elena.vance@auravoice.io' },
                  displayName: { type: 'string', example: 'Elena Vance' },
                  avatar: { type: 'string' }
                }
              }
            }
          }
        },
        responses: {
          '200': { description: 'Successfully authenticated and issued tokens' }
        }
      }
    },
    '/rooms': {
      get: {
        tags: ['Rooms'],
        summary: 'List active voice rooms by category or tags',
        responses: {
          '200': { description: 'Array of active voice rooms with seat data' }
        }
      },
      post: {
        tags: ['Rooms'],
        summary: 'Create a new voice room',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['title', 'topic', 'category'],
                properties: {
                  title: { type: 'string', example: '🌙 Night Vibes & Chill Lounge' },
                  topic: { type: 'string', example: 'Relaxing tunes, make new friends globally' },
                  category: { type: 'string', enum: ['popular', 'new', 'country', 'family', 'game', 'music'] }
                }
              }
            }
          }
        },
        responses: { '201': { description: 'Room created successfully' } }
      }
    },
    '/rooms/{id}/seat/join': {
      post: {
        tags: ['Rooms'],
        summary: 'Take an empty mic seat in a room (1-8)',
        parameters: [
          { name: 'id', in: 'path', required: true, schema: { type: 'string' } }
        ],
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['seatIndex'],
                properties: { seatIndex: { type: 'integer', minimum: 1, maximum: 8 } }
              }
            }
          }
        },
        responses: { '200': { description: 'Joined seat successfully' } }
      }
    },
    '/wallet/balance': {
      get: {
        tags: ['Wallet'],
        summary: 'Get current user coins and diamonds balance',
        responses: { '200': { description: 'User balances returned' } }
      }
    },
    '/wallet/recharge': {
      post: {
        tags: ['Wallet'],
        summary: 'Recharge coins or diamonds balance',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  coins: { type: 'integer', example: 1000 },
                  diamonds: { type: 'integer', example: 0 },
                  description: { type: 'string', example: 'In-app purchase package #2' }
                }
              }
            }
          }
        },
        responses: { '200': { description: 'Recharge transaction recorded' } }
      }
    },
    '/wallet/withdraw': {
      post: {
        tags: ['Wallet'],
        summary: 'Submit diamond withdrawal request to bank account',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['diamonds', 'accountDetails'],
                properties: {
                  diamonds: { type: 'integer', example: 500 },
                  accountDetails: { type: 'string', example: 'Bank of America - IBAN US8810293019' }
                }
              }
            }
          }
        },
        responses: { '200': { description: 'Withdrawal request submitted for approval' } }
      }
    },
    '/gifts/send': {
      post: {
        tags: ['Gifts'],
        summary: 'Send virtual gift to room host or mic seat user',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['receiverId', 'giftId'],
                properties: {
                  receiverId: { type: 'string' },
                  giftId: { type: 'string' },
                  count: { type: 'integer', default: 1 }
                }
              }
            }
          }
        },
        responses: { '200': { description: 'Gift sent, coins deducted, animation broadcasted' } }
      }
    },
    '/luckybag/create': {
      post: {
        tags: ['LuckyBag'],
        summary: 'Drop a lucky bag into a live voice room',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['roomId', 'totalCoins', 'totalWinners'],
                properties: {
                  roomId: { type: 'string' },
                  totalCoins: { type: 'integer', example: 1000 },
                  totalWinners: { type: 'integer', example: 5 }
                }
              }
            }
          }
        },
        responses: { '201': { description: 'Lucky Bag dropped and countdown started' } }
      }
    },
    '/luckybag/claim': {
      post: {
        tags: ['LuckyBag'],
        summary: 'Claim a random coin reward from an active room lucky bag',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['bagId'],
                properties: { bagId: { type: 'string' } }
              }
            }
          }
        },
        responses: { '200': { description: 'Reward claimed successfully' } }
      }
    },
    '/spin': {
      post: {
        tags: ['Spin'],
        summary: 'Spin the daily lucky wheel for 50 coins',
        responses: { '200': { description: 'Random reward granted based on probability' } }
      }
    },
    '/admin/users': {
      get: {
        tags: ['Admin'],
        summary: 'List all registered users (Requires Staff permission)',
        responses: { '200': { description: 'List of users' } }
      }
    },
    '/admin/audit': {
      get: {
        tags: ['Admin'],
        summary: 'Get system audit logs (Requires audit:view permission)',
        responses: { '200': { description: 'Audit logs array' } }
      }
    },
    '/admin/schema': {
      get: {
        tags: ['Documentation'],
        summary: 'Get complete PostgreSQL DDL table metadata and indexes',
        responses: { '200': { description: 'PostgreSQL schema metadata' } }
      }
    },
    '/wallet/packages': {
      get: {
        tags: ['Wallet'],
        summary: 'List available recharge coin & diamond packages with bonus tiers',
        responses: { '200': { description: 'Array of recharge packages' } }
      }
    },
    '/wallet/withdrawals/moderate': {
      post: {
        tags: ['Wallet'],
        summary: 'Moderate a pending diamond withdrawal request (Requires Finance/Staff role)',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['txId', 'status'],
                properties: {
                  txId: { type: 'string' },
                  status: { type: 'string', enum: ['completed', 'rejected'] },
                  notes: { type: 'string' }
                }
              }
            }
          }
        },
        responses: { '200': { description: 'Withdrawal moderated successfully' } }
      }
    },
    '/rooms/{id}/pk/start': {
      post: {
        tags: ['PK'],
        summary: 'Start a live 1v1 PK battle between two active voice rooms',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['opponentRoomId'],
                properties: {
                  opponentRoomId: { type: 'string' },
                  durationSeconds: { type: 'integer', default: 300 }
                }
              }
            }
          }
        },
        responses: { '201': { description: 'PK battle initiated' } }
      }
    },
    '/messages/private': {
      get: {
        tags: ['Messaging'],
        summary: 'Get 1-on-1 private message history with a peer user',
        parameters: [{ name: 'peerId', in: 'query', required: true, schema: { type: 'string' } }],
        responses: { '200': { description: 'Array of private messages' } }
      },
      post: {
        tags: ['Messaging'],
        summary: 'Send a private direct message or gift to another user',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['receiverId', 'content'],
                properties: {
                  receiverId: { type: 'string' },
                  content: { type: 'string' },
                  type: { type: 'string', enum: ['text', 'image', 'voice', 'gift'], default: 'text' }
                }
              }
            }
          }
        },
        responses: { '201': { description: 'Message sent' } }
      }
    },
    '/notifications': {
      get: {
        tags: ['Notifications'],
        summary: 'Get user notifications inbox',
        responses: { '200': { description: 'Notifications array' } }
      }
    },
    '/notifications/read': {
      post: {
        tags: ['Notifications'],
        summary: 'Mark one or all notifications as read',
        requestBody: {
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: { notificationId: { type: 'string' } }
              }
            }
          }
        },
        responses: { '200': { description: 'Notifications marked read' } }
      }
    },
    '/admin/staff-activity': {
      get: {
        tags: ['Admin'],
        summary: 'Get staff activity and moderation logs',
        responses: { '200': { description: 'Array of staff activity logs' } }
      }
    },
    '/admin/reports': {
      get: {
        tags: ['Admin'],
        summary: 'Get moderation reports submitted by users',
        responses: { '200': { description: 'Array of report items' } }
      }
    },
    '/admin/reports/moderate': {
      post: {
        tags: ['Admin'],
        summary: 'Resolve or dismiss a moderation report',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['reportId', 'status'],
                properties: {
                  reportId: { type: 'string' },
                  status: { type: 'string', enum: ['investigating', 'resolved', 'dismissed'] },
                  notes: { type: 'string' }
                }
              }
            }
          }
        },
        responses: { '200': { description: 'Report moderated' } }
      }
    },
    '/analytics/overview': {
      get: {
        tags: ['Analytics'],
        summary: 'Get executive dashboard KPIs, daily active users, revenue charts, and top hosts',
        responses: { '200': { description: 'Analytics overview data' } }
      }
    },
    '/security/audit-report': {
      get: {
        tags: ['Security'],
        summary: 'Get system security configuration, rate limiting state, and audit event counts',
        responses: { '200': { description: 'Security report' } }
      }
    },
    '/test/suite': {
      get: {
        tags: ['Testing'],
        summary: 'Execute automated 100% backend integration test suite verifying all 19 priorities',
        responses: { '200': { description: 'Test suite execution results' } }
      }
    }
  }
};
