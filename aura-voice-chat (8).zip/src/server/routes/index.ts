/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express, { Request, Response, NextFunction } from 'express';
import { AuthService } from '../services/auth.service';
import { PermissionService } from '../services/permission.service';
import { WalletService } from '../services/wallet.service';
import { RoomService } from '../services/room.service';
import { MessageService } from '../services/message.service';
import { NotificationService } from '../services/notification.service';
import { AdminService } from '../services/admin.service';
import { TestSuiteService } from '../services/test.service';
import { CountryService } from '../services/country.service';
import { ConnectionService } from '../services/connection.service';
import { VirtualGiftService } from '../services/virtualGift.service';
import { dbStore } from '../db/store';
import { POSTGRES_TABLES_METADATA } from '../db/schema';
import { OPENAPI_SPEC } from '../openapi.json';
import { 
  UserRole, StaffIdentity, Banner, Family, FamilyMember, 
  BenefitAssignmentRecord, WalletTransaction, Merchant, RechargeAgent, Agency, User,
  PermissionModule, SystemPermission, RolePermissionConfig, StaffPermissionOverride 
} from '../../types';
import { ROLE_HIERARCHY } from '../services/permission.service';
import { DEFAULT_ROLE_CONFIGS } from '../../lib/rbacDefaults';
import { STAFF_IDENTITY_CONFIG } from '../../lib/staffIdentity';

const router = express.Router();

// Middleware: Resolve current user (via JWT or X-Demo-User-Id header)
export const resolveUserMiddleware = (req: Request, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;
  const demoUserId = req.headers['x-demo-user-id'] as string;

  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.split(' ')[1];
    const payload = AuthService.verifyToken(token);
    if (payload) {
      (req as any).user = dbStore.users.get(payload.userId);
      return next();
    }
  }

  if (demoUserId) {
    const user = dbStore.users.get(demoUserId);
    if (user) {
      (req as any).user = user;
      return next();
    }
  }

  // Default fallback to demo CEO Elena Vance for preview testability
  (req as any).user = dbStore.users.get('2383452') || dbStore.users.get('usr-001');
  next();
};

router.use(resolveUserMiddleware);

// Health check endpoint
router.get('/health', (req: Request, res: Response) => {
  return res.json({
    status: 'ok',
    service: 'Aura Voice Chat Backend API',
    version: '1.0.0',
    websocket: 'ws://localhost:3000/ws',
    timestamp: new Date().toISOString()
  });
});

// ==========================================
// 1. AUTHENTICATION & SESSION ENDPOINTS
// ==========================================

router.post('/auth/login', (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    if (!email) {
      return res.status(400).json({ success: false, error: 'Email is required' });
    }
    const result = AuthService.loginWithEmailPassword(email, password);
    if (!result) {
      return res.status(401).json({ success: false, error: 'Invalid email or password credentials' });
    }

    // Check if account is banned
    const banCheck = dbStore.isUserBanned(result.user.id);
    if (banCheck.isBanned) {
      return res.status(403).json({
        success: false,
        error: `⛔ ACCOUNT SUSPENDED: ${banCheck.reason} (${banCheck.banType === 'temporary' ? `Expires: ${new Date(banCheck.expiresAt!).toLocaleString()}` : 'Permanent Suspension'})`,
        isBanned: true,
        banReason: banCheck.reason,
        banExpiresAt: banCheck.expiresAt,
        banType: banCheck.banType,
        bannedBy: banCheck.bannedBy
      });
    }

    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/auth/firebase', (req: Request, res: Response) => {
  try {
    const { firebaseUid, email, displayName, avatar, profile, nigoId, phone, country, countryFlag, gender } = req.body;
    if (!firebaseUid || !email) {
      return res.status(400).json({ success: false, error: 'firebaseUid and email are required' });
    }
    const mergedProfile = {
      ...(profile || {}),
      ...(nigoId ? { uid: nigoId, nigoId } : {}),
      ...(phone ? { phone } : {}),
      ...(country ? { country } : {}),
      ...(countryFlag ? { countryFlag } : {}),
      ...(gender ? { gender } : {})
    };
    const result = AuthService.simulateFirebaseAuth(firebaseUid, email, displayName, avatar, mergedProfile);

    // Check if account is banned
    const banCheck = dbStore.isUserBanned(result.user.id);
    if (banCheck.isBanned) {
      return res.status(403).json({
        success: false,
        error: `⛔ ACCOUNT SUSPENDED: ${banCheck.reason} (${banCheck.banType === 'temporary' ? `Expires: ${new Date(banCheck.expiresAt!).toLocaleString()}` : 'Permanent Suspension'})`,
        isBanned: true,
        banReason: banCheck.reason,
        banExpiresAt: banCheck.expiresAt,
        banType: banCheck.banType,
        bannedBy: banCheck.bannedBy
      });
    }

    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

router.get('/auth/me', (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!user) return res.status(401).json({ success: false, error: 'Not authenticated' });
  return res.json({ success: true, data: user });
});

// ==========================================
// 1.1 USER PROFILE EDITING (SELF)
// ==========================================

const handleUserProfileUpdate = (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) {
      return res.status(401).json({ success: false, error: 'Authentication required to update profile' });
    }

    const { name, uid, nigoId, avatar, bio, gender, country, countryFlag } = req.body;

    const oldName = user.name;
    const oldAvatar = user.avatar;
    const oldUid = user.uid;
    let hasChanges = false;

    // 0. User ID (UID / Nigo ID) cannot be changed from the application.
    // The user ID can only be changed from the admin dashboard (via /api/admin/users/:id/uid or admin user management).
    const candidateUid = uid !== undefined ? uid : nigoId;
    if (candidateUid !== undefined) {
      const trimmedCandidate = String(candidateUid).trim();
      if (trimmedCandidate && trimmedCandidate !== user.uid && trimmedCandidate !== user.nigoId) {
        return res.status(403).json({ 
          success: false, 
          error: 'User ID cannot be changed from the application. The user ID can only be changed from the admin dashboard.' 
        });
      }
    }

    // 1. Validate & Update Profile Name
    if (name !== undefined) {
      const trimmedName = String(name).trim().replace(/<[^>]*>?/gm, ''); // Sanitize HTML tags
      if (!trimmedName) {
        return res.status(400).json({ success: false, error: 'Profile name cannot be empty.' });
      }
      if (trimmedName.length < 2 || trimmedName.length > 50) {
        return res.status(400).json({ success: false, error: 'Profile name must be between 2 and 50 characters.' });
      }
      user.name = trimmedName;
      hasChanges = true;
    }

    // 2. Validate & Update Profile Photo / Avatar
    if (avatar !== undefined) {
      const trimmedAvatar = String(avatar).trim();
      if (trimmedAvatar) {
        // Validate URL or data URI format
        if (!trimmedAvatar.startsWith('http://') && 
            !trimmedAvatar.startsWith('https://') && 
            !trimmedAvatar.startsWith('/api/uploads/') && 
            !trimmedAvatar.startsWith('data:image/')) {
          return res.status(400).json({ success: false, error: 'Invalid profile photo URL or image format.' });
        }
        user.avatar = trimmedAvatar;
        hasChanges = true;
      }
    }

    // 3. Update Bio
    if (bio !== undefined) {
      user.bio = String(bio).trim().slice(0, 300);
      hasChanges = true;
    }

    // 4. Update Gender
    if (gender !== undefined && ['male', 'female', 'other'].includes(gender)) {
      user.gender = gender as 'male' | 'female' | 'other';
      hasChanges = true;
    }

    // 5. Update Country & Flag
    if (country !== undefined) {
      user.country = String(country).trim();
      hasChanges = true;
    }
    if (countryFlag !== undefined) {
      user.countryFlag = String(countryFlag).trim();
      hasChanges = true;
    }

    // Persist to user store
    dbStore.users.set(user.id, user);

    // Synchronize user name, avatar, and room ID across active rooms (Voice Room ID = User Profile ID)
    Array.from(dbStore.rooms.values()).forEach(room => {
      let roomChanged = false;
      if (room.hostId === user.id || room.hostUid === user.uid || room.hostUid === oldUid) {
        const profileId = user.uid || user.id;
        // If room ID changed due to UID update, clean up old room key
        if (room.id !== profileId && dbStore.rooms.has(room.id)) {
          dbStore.rooms.delete(room.id);
        }
        room.id = profileId;
        room.hostUid = profileId;
        room.hostName = user.name;
        room.hostAvatar = user.avatar;
        if (user.frame) room.hostFrame = user.frame;
        roomChanged = true;
      }
      room.seats.forEach(seat => {
        if (seat.userId === user.id) {
          seat.userName = user.name;
          seat.userAvatar = user.avatar;
          if (user.frame) seat.userFrame = user.frame;
          roomChanged = true;
        }
      });
      if (roomChanged) {
        dbStore.rooms.set(room.id, room);
      }
    });

    // Synchronize family leader name if user owns family
    if (user.familyId) {
      const fam = dbStore.families.get(user.familyId);
      if (fam && fam.leaderId === user.id) {
        fam.leaderName = user.name;
        dbStore.families.set(fam.id, fam);
      }
    }

    // Record audit log
    if (hasChanges) {
      dbStore.recordAudit({
        action: 'USER_PROFILE_UPDATED',
        module: 'staff',
        performedByUserId: user.id,
        performedByUserName: user.name,
        performedByRole: user.role,
        targetId: user.id,
        targetName: user.name,
        details: `Profile updated: Name changed from "${oldName}" to "${user.name}". UID changed from "${oldUid}" to "${user.uid}". Avatar updated: ${oldAvatar !== user.avatar}.`,
        ipAddress: req.ip || '127.0.0.1'
      });
    }

    // Persist to Firestore asynchronously
    dbStore.persistUser(user).catch(() => {});

    return res.json({
      success: true,
      data: user,
      message: 'Profile updated successfully'
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to update profile' });
  }
};

router.put('/users/profile', handleUserProfileUpdate);
router.post('/users/profile', handleUserProfileUpdate);
router.patch('/users/profile', handleUserProfileUpdate);
router.get('/users/me', (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!user) return res.status(401).json({ success: false, error: 'Not authenticated' });
  return res.json({ success: true, data: user });
});

// Helper to sanitize public search results (never leak passwords or secrets)
const sanitizeSearchResultUser = (u: any, hostRoomMap?: Map<string, string>) => {
  const { password, ...safeUser } = u;
  if (hostRoomMap) {
    const activeRoomId = hostRoomMap.get(u.id) || hostRoomMap.get(u.uid);
    if (activeRoomId) {
      safeUser.activeRoomId = activeRoomId;
    }
  }
  return safeUser;
};

// ==========================================
// 1.2 PUBLIC USER SEARCH (BY UID / DISPLAY NAME)
// ==========================================
router.get('/users/search', (req: Request, res: Response) => {
  try {
    const rawQuery = String(req.query.q || '').trim();
    const filter = String(req.query.filter || 'all').toLowerCase(); // 'all', 'online', 'host', 'vip', 'staff'
    const limit = Math.min(50, Math.max(1, Number(req.query.limit) || 20));

    dbStore.checkAndExpireBans();
    const allUsers = Array.from(dbStore.users.values());

    // Build active host rooms map
    const hostRoomMap = new Map<string, string>();
    dbStore.rooms.forEach(r => {
      if (r.hostId) hostRoomMap.set(r.hostId, r.id);
      if (r.hostUid) hostRoomMap.set(r.hostUid, r.id);
    });

    if (!rawQuery) {
      // Empty query: Return popular/recommended users based on active status & level
      let list = allUsers.filter(u => u.status !== 'banned');
      if (filter === 'online') {
        list = list.filter(u => u.isOnline);
      } else if (filter === 'host') {
        list = list.filter(u => u.role === 'host' || hostRoomMap.has(u.id) || hostRoomMap.has(u.uid));
      } else if (filter === 'vip') {
        list = list.filter(u => u.vipLevel && u.vipLevel !== 'none');
      } else if (filter === 'staff') {
        list = list.filter(u => u.role !== 'user');
      }

      list.sort((a, b) => {
        if (a.isOnline !== b.isOnline) return a.isOnline ? -1 : 1;
        return (b.level || 1) - (a.level || 1);
      });

      const sanitized = list.slice(0, limit).map(u => sanitizeSearchResultUser(u, hostRoomMap));
      return res.json({ success: true, data: sanitized, total: sanitized.length, query: '' });
    }

    const q = rawQuery.toLowerCase();
    const matched: { user: any; score: number }[] = [];

    for (const u of allUsers) {
      if (u.status === 'banned') continue;

      // Filter checks
      if (filter === 'online' && !u.isOnline) continue;
      if (filter === 'host' && u.role !== 'host' && !hostRoomMap.has(u.id) && !hostRoomMap.has(u.uid)) continue;
      if (filter === 'vip' && (!u.vipLevel || u.vipLevel === 'none')) continue;
      if (filter === 'staff' && u.role === 'user') continue;

      const uid = String(u.uid || u.nigoId || '').toLowerCase();
      const name = String(u.name || '').toLowerCase();
      const id = String(u.id || '').toLowerCase();

      let score = 0;

      // Exact match on User ID / UID
      if (uid === q || id === q) {
        score += 1000;
      }
      // Exact match on Display Name
      else if (name === q) {
        score += 800;
      }
      // UID starts with query
      else if (uid.startsWith(q)) {
        score += 500;
      }
      // Name starts with query
      else if (name.startsWith(q)) {
        score += 400;
      }
      // UID contains query
      else if (uid.includes(q)) {
        score += 300;
      }
      // Name contains query
      else if (name.includes(q)) {
        score += 200;
      }
      // Internal ID contains query
      else if (id.includes(q)) {
        score += 100;
      }

      if (score > 0) {
        // Boost for online status
        if (u.isOnline) score += 30;
        // Boost for live room hosting
        if (hostRoomMap.has(u.id) || hostRoomMap.has(u.uid)) score += 40;
        // Boost for VIP level
        if (u.vipLevel === 'svip') score += 20;
        else if (u.vipLevel === 'vip') score += 10;
        // Boost for experience level
        score += Math.min(25, Math.floor((u.level || 1) / 4));

        matched.push({ user: u, score });
      }
    }

    matched.sort((a, b) => b.score - a.score);

    const results = matched.slice(0, limit).map(m => sanitizeSearchResultUser(m.user, hostRoomMap));

    return res.json({
      success: true,
      data: results,
      total: results.length,
      query: rawQuery
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// 2. VOICE ROOMS & SEATS ENDPOINTS
// ==========================================

router.get('/rooms', (req: Request, res: Response) => {
  const { category, search } = req.query;
  let rooms = RoomService.getAllRooms();
  
  if (category && category !== 'all' && category !== 'popular') {
    rooms = rooms.filter(r => r.category === category);
  }
  if (search) {
    const q = (search as string).toLowerCase();
    rooms = rooms.filter(r => r.title.toLowerCase().includes(q) || r.topic.toLowerCase().includes(q));
  }
  return res.json({ success: true, data: rooms });
});

router.get('/rooms/:id', (req: Request, res: Response) => {
  const room = RoomService.getRoomById(req.params.id);
  if (!room) return res.status(404).json({ success: false, error: 'Room not found' });
  const messages = RoomService.getRoomMessages(room.id);
  return res.json({ success: true, data: { room, messages } });
});

router.post('/rooms', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });

    const { title, topic, category } = req.body;
    const room = RoomService.createRoom(user.id, title || `${user.name}'s Room`, topic || 'Let us talk!', category || 'popular');
    
    dbStore.recordAudit({
      action: 'VOICE_ROOM_CREATED',
      module: 'room',
      performedByUserId: user.id,
      performedByUserName: user.name,
      performedByRole: user.role,
      targetId: room.id,
      details: `Created room: ${room.title} (${room.category})`,
      ipAddress: req.ip || '127.0.0.1'
    });

    return res.status(201).json({ success: true, data: room });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.post('/rooms/:id/seat/join', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });

    const { seatIndex } = req.body;
    const updatedRoom = RoomService.joinSeat(req.params.id, user.id, Number(seatIndex));
    return res.json({ success: true, data: updatedRoom });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.post('/rooms/:id/seat/leave', (req: Request, res: Response) => {
  try {
    const { seatIndex } = req.body;
    const updatedRoom = RoomService.leaveSeat(req.params.id, Number(seatIndex));
    return res.json({ success: true, data: updatedRoom });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.post('/rooms/:id/leave', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const roomId = req.params.id;
    const room = dbStore.rooms.get(roomId);
    if (!room) return res.status(404).json({ success: false, error: 'Room not found' });

    if (user) {
      // Remove from any occupied seat if not host
      room.seats.forEach((seat, idx) => {
        if (seat.userId === user.id && idx !== 0) {
          delete seat.userId;
          delete seat.userName;
          delete seat.userAvatar;
          delete seat.userFrame;
          seat.isSpeaking = false;
          seat.contributionCoin = 0;
        }
      });
      room.onlineCount = Math.max(1, (room.onlineCount || 1) - 1);
      
      // Clean up temporary tools state if host leaves
      if (user.id === room.hostId) {
        if (room.toolsState) {
          if (room.toolsState.game) room.toolsState.game.status = 'ended';
          if (room.toolsState.youtube) room.toolsState.youtube.isPlaying = false;
          if (room.toolsState.pk) room.toolsState.pk.active = false;
          if (room.toolsState.activeTool !== 'music') room.toolsState.activeTool = 'none';
        }
        if (room.pkState) room.pkState.active = false;
      }

      dbStore.rooms.set(roomId, room);
    }
    return res.json({ success: true, data: room });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.post('/rooms/:id/seat/mute', (req: Request, res: Response) => {
  try {
    const { seatIndex } = req.body;
    const updatedRoom = RoomService.toggleMuteSeat(req.params.id, Number(seatIndex));
    return res.json({ success: true, data: updatedRoom });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.post('/rooms/:id/seat/lock', (req: Request, res: Response) => {
  try {
    const { seatIndex } = req.body;
    const updatedRoom = RoomService.toggleLockSeat(req.params.id, Number(seatIndex));
    return res.json({ success: true, data: updatedRoom });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

// Room Visual Theme Customization Endpoint
router.post('/rooms/:id/theme', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const room = RoomService.getRoomById(req.params.id) || dbStore.rooms.get(req.params.id);
    if (!room) return res.status(404).json({ success: false, error: 'Room not found' });

    // Verify host or staff permission
    const isHost = user && (
      room.hostId === user.id || 
      (room as any).hostUid === user.uid || 
      room.hostName === user.name ||
      ['admin', 'superadmin', 'manager', 'head_admin'].includes(user.role)
    );

    if (!isHost) {
      return res.status(403).json({ success: false, error: 'Only the room host can customize the room theme.' });
    }

    const { theme, backgroundUrl } = req.body;
    if (!theme) {
      return res.status(400).json({ success: false, error: 'Theme identifier is required.' });
    }

    const updatedRoom = RoomService.updateRoomTheme(room.id, theme, backgroundUrl, {
      id: user.id,
      name: user.name
    });

    dbStore.recordAudit({
      action: 'ROOM_THEME_UPDATED',
      module: 'room',
      performedByUserId: user.id,
      performedByUserName: user.name,
      performedByRole: user.role,
      targetId: room.id,
      details: `Changed room theme to "${theme}"`,
      ipAddress: req.ip || '127.0.0.1'
    });

    return res.json({ success: true, data: updatedRoom });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

// ==========================================
// 2.1 LIVE ROOM TOOLS & ENTERTAINMENT SUITE
// ==========================================

const ensureRoomToolsState = (room: any) => {
  if (!room.toolsState) {
    room.toolsState = {
      activeTool: 'none',
      music: {
        title: 'Midnight Breeze',
        artist: 'Aura Lofi Beats',
        url: 'https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3?filename=lofi-study-112191.mp3',
        isPlaying: false,
        currentTime: 0,
        duration: 160,
        volume: 80,
        queue: [
          { id: 'trk-1', title: 'Midnight Breeze', artist: 'Aura Lofi Beats', url: 'https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3?filename=lofi-study-112191.mp3', duration: 160, addedBy: 'Host' },
          { id: 'trk-2', title: 'Cyber Pulse', artist: 'Synthwave Night', url: 'https://cdn.pixabay.com/download/audio/2022/01/18/audio_d0a13f69d2.mp3?filename=electronic-future-beats-117997.mp3', duration: 145, addedBy: 'Aura DJ' },
          { id: 'trk-3', title: 'Starlight Piano', artist: 'Cosmic Melody', url: 'https://cdn.pixabay.com/download/audio/2022/11/06/audio_0575d27aa2.mp3?filename=piano-moment-9871.mp3', duration: 180, addedBy: 'System' }
        ]
      },
      youtube: {
        videoId: 'jfKfPfyJRdk',
        videoTitle: 'lofi hip hop radio 📚 - beats to relax/study to',
        videoUrl: 'https://www.youtube.com/watch?v=jfKfPfyJRdk',
        isPlaying: false,
        currentTime: 0,
        addedBy: 'Room DJ',
        queue: [
          { id: 'yt-1', videoId: 'jfKfPfyJRdk', videoTitle: 'lofi hip hop radio 📚 - beats to relax/study to', videoUrl: 'https://www.youtube.com/watch?v=jfKfPfyJRdk', addedBy: 'Host' },
          { id: 'yt-2', videoId: '5qap5aO4i9A', videoTitle: 'Lofi Hip Hop Radio - Beats to Chill to', videoUrl: 'https://www.youtube.com/watch?v=5qap5aO4i9A', addedBy: 'Aura Staff' }
        ]
      },
      cp: null,
      pk: room.pkState ? {
        active: room.pkState.active,
        opponentRoomId: room.pkState.opponentRoomId,
        opponentName: room.pkState.opponentName,
        opponentAvatar: room.pkState.opponentAvatar,
        myScore: room.pkState.myScore || 0,
        opponentScore: room.pkState.opponentScore || 0,
        timeLeft: room.pkState.timeLeft || 300,
        status: 'active'
      } : {
        active: false,
        myScore: 0,
        opponentScore: 0,
        timeLeft: 300,
        status: 'matching',
        history: [
          { opponentName: 'Cyber Gaming 🕹️', myScore: 45000, opponentScore: 38000, result: 'win', date: 'Yesterday' },
          { opponentName: 'Acoustic Lounge 🎸', myScore: 28000, opponentScore: 31000, result: 'lose', date: '3 days ago' }
        ]
      },
      game: {
        activeGameId: 'spin',
        gameName: 'Wheel of Fortune',
        status: 'idle',
        hostId: room.hostId,
        hostName: room.hostName,
        players: []
      }
    };
  }
  return room.toolsState;
};

// Check if user is host or room manager/admin
const checkRoomManagerPermission = (user: any, room: any): boolean => {
  if (!user || !room) return false;
  if (user.id === room.hostId) return true;
  return ['ceo', 'super_admin', 'admin', 'manager', 'gm', 'official_staff'].includes(user.role);
};

// 1. GET Current Room Tools State
router.get('/rooms/:id/tools', (req: Request, res: Response) => {
  const room = dbStore.rooms.get(req.params.id);
  if (!room) return res.status(404).json({ success: false, error: 'Room not found' });
  const tools = ensureRoomToolsState(room);
  return res.json({ success: true, data: tools });
});

// 2. POST Active Room Tool Switch
router.post('/rooms/:id/tools/active', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const room = dbStore.rooms.get(req.params.id);
    if (!room) return res.status(404).json({ success: false, error: 'Room not found' });

    const tools = ensureRoomToolsState(room);
    const { activeTool } = req.body;
    
    // Changing room-wide active tool requires host or staff permission
    if (activeTool && activeTool !== 'none' && !checkRoomManagerPermission(user, room)) {
      // Normal participants can view tools locally without restricting host's room
      return res.json({ success: true, data: tools, notice: 'Local preview for participant' });
    }

    tools.activeTool = activeTool || 'none';
    dbStore.rooms.set(room.id, room);
    return res.json({ success: true, data: tools });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// 3. POST Music State & Queue
router.post('/rooms/:id/tools/music', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const room = dbStore.rooms.get(req.params.id);
    if (!room) return res.status(404).json({ success: false, error: 'Room not found' });

    const tools = ensureRoomToolsState(room);
    const { action, title, artist, url, volume, isPlaying, track } = req.body;

    const isManager = checkRoomManagerPermission(user, room);

    if (action === 'play') {
      if (!isManager) return res.status(403).json({ success: false, error: 'Only room host or staff can play music' });
      tools.music.isPlaying = true;
      if (title) tools.music.title = title;
      if (artist) tools.music.artist = artist;
      if (url) tools.music.url = url;
      tools.activeTool = 'music';
      room.musicPlaying = { title: tools.music.title, artist: tools.music.artist, isPlaying: true };
    } else if (action === 'pause') {
      if (!isManager) return res.status(403).json({ success: false, error: 'Only room host or staff can pause music' });
      tools.music.isPlaying = false;
      if (room.musicPlaying) room.musicPlaying.isPlaying = false;
    } else if (action === 'volume') {
      if (volume !== undefined) tools.music.volume = Math.max(0, Math.min(100, Number(volume)));
    } else if (action === 'skip') {
      if (!isManager) return res.status(403).json({ success: false, error: 'Only room host can skip tracks' });
      if (tools.music.queue && tools.music.queue.length > 1) {
        tools.music.queue.shift();
        const next = tools.music.queue[0];
        tools.music.title = next.title;
        tools.music.artist = next.artist;
        tools.music.url = next.url || tools.music.url;
        tools.music.isPlaying = true;
      }
    } else if (action === 'add' && track) {
      const newTrack = {
        id: `trk-${Date.now()}`,
        title: track.title || 'Untitled Track',
        artist: track.artist || 'Aura Music',
        url: track.url,
        duration: track.duration || 180,
        addedBy: user?.name || 'Listener'
      };
      tools.music.queue = tools.music.queue || [];
      tools.music.queue.push(newTrack);

      RoomService.addRoomMessage(room.id, {
        roomId: room.id,
        userId: user?.id || 'sys',
        userName: user?.name || 'Aura DJ',
        userAvatar: user?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100',
        type: 'system',
        content: `🎵 ${newTrack.addedBy} added "${newTrack.title}" to the room music queue!`
      });
    }

    dbStore.rooms.set(room.id, room);
    return res.json({ success: true, data: tools.music });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// 4. POST YouTube Synchronized Player
router.post('/rooms/:id/tools/youtube', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const room = dbStore.rooms.get(req.params.id);
    if (!room) return res.status(404).json({ success: false, error: 'Room not found' });

    const tools = ensureRoomToolsState(room);
    const { action, videoId, videoTitle, videoUrl, isPlaying, currentTime, item } = req.body;
    const isManager = checkRoomManagerPermission(user, room);

    if (action === 'play') {
      if (!isManager) return res.status(403).json({ success: false, error: 'Only room host can start YouTube playback' });
      tools.youtube.isPlaying = true;
      if (videoId) tools.youtube.videoId = videoId;
      if (videoTitle) tools.youtube.videoTitle = videoTitle;
      if (videoUrl) tools.youtube.videoUrl = videoUrl;
      tools.activeTool = 'youtube';

      RoomService.addRoomMessage(room.id, {
        roomId: room.id,
        userId: user?.id || 'sys',
        userName: user?.name || 'Host',
        userAvatar: user?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100',
        type: 'system',
        content: `▶️ YouTube Video playing: "${tools.youtube.videoTitle}"`
      });
    } else if (action === 'pause') {
      if (!isManager) return res.status(403).json({ success: false, error: 'Only room host can pause YouTube' });
      tools.youtube.isPlaying = false;
    } else if (action === 'close') {
      if (!isManager) return res.status(403).json({ success: false, error: 'Only room host can close YouTube' });
      tools.youtube.isPlaying = false;
      if (tools.activeTool === 'youtube') tools.activeTool = 'none';
    } else if (action === 'add' && item) {
      const newItem = {
        id: `yt-${Date.now()}`,
        videoId: item.videoId,
        videoTitle: item.videoTitle || 'YouTube Video',
        videoUrl: item.videoUrl || `https://www.youtube.com/watch?v=${item.videoId}`,
        addedBy: user?.name || 'Listener'
      };
      tools.youtube.queue = tools.youtube.queue || [];
      tools.youtube.queue.push(newItem);

      RoomService.addRoomMessage(room.id, {
        roomId: room.id,
        userId: user?.id || 'sys',
        userName: user?.name || 'Listener',
        userAvatar: user?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100',
        type: 'system',
        content: `▶️ ${newItem.addedBy} added "${newItem.videoTitle}" to YouTube queue!`
      });
    }

    dbStore.rooms.set(room.id, room);
    return res.json({ success: true, data: tools.youtube });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// 5. POST CP / Couple Interaction in Voice Room
router.post('/rooms/:id/tools/cp', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const room = dbStore.rooms.get(req.params.id);
    if (!room) return res.status(404).json({ success: false, error: 'Room not found' });

    const tools = ensureRoomToolsState(room);
    const { action, interactionType, partner1, partner2, coupleId, level, connectionDays } = req.body;

    if (action === 'start') {
      tools.cp = {
        active: true,
        partner1Id: partner1?.id || user?.id || 'user-1',
        partner1Name: partner1?.name || user?.name || 'Partner 1',
        partner1Avatar: partner1?.avatar || user?.avatar || '',
        partner2Id: partner2?.id || 'partner-2',
        partner2Name: partner2?.name || 'Soulmate',
        partner2Avatar: partner2?.avatar || '',
        coupleId: coupleId || 'CP-AURA-1001',
        level: level || 3,
        connectionDays: connectionDays || 48,
        interactionType: interactionType || 'love',
        startedAt: new Date().toISOString()
      };
      tools.activeTool = 'cp';

      const typeLabels: Record<string, string> = {
        hug: 'Warm Sweet Hug 🤗',
        love: 'Romantic Golden Aura 💞',
        kiss: 'Romantic Sweet Kiss 💋',
        anniversary: 'Couple Anniversary Celebration 💍',
        gift: 'Special Couple Gift Blessing 🎁'
      };

      RoomService.addRoomMessage(room.id, {
        roomId: room.id,
        userId: user?.id || 'sys',
        userName: user?.name || 'Aura CP',
        userAvatar: user?.avatar || '',
        type: 'system',
        content: `❤️ CP Couple ${tools.cp.partner1Name} & ${tools.cp.partner2Name} started ${typeLabels[tools.cp.interactionType || 'love'] || 'Romantic Aura'} in the room! (Day ${tools.cp.connectionDays})`
      });
    } else if (action === 'stop') {
      tools.cp = null;
      if (tools.activeTool === 'cp') tools.activeTool = 'none';
    }

    dbStore.rooms.set(room.id, room);
    return res.json({ success: true, data: tools.cp });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// 6. POST PK Battle Room Tools Integration
router.post('/rooms/:id/tools/pk', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const room = dbStore.rooms.get(req.params.id);
    if (!room) return res.status(404).json({ success: false, error: 'Room not found' });

    const tools = ensureRoomToolsState(room);
    const { action, opponentRoomId, durationSeconds = 180, points = 100, side = 'roomA' } = req.body;
    const isManager = checkRoomManagerPermission(user, room);

    if (action === 'start') {
      if (!isManager) return res.status(403).json({ success: false, error: 'Only room host can start PK battle' });
      
      const targetRoomId = opponentRoomId || Array.from(dbStore.rooms.keys()).find(id => id !== room.id);
      const targetRoom = targetRoomId ? dbStore.rooms.get(targetRoomId) : null;
      
      const battle = RoomService.startPkBattle(room.id, targetRoom?.id || 'demo-opp', Number(durationSeconds));
      tools.activeTool = 'pk';
      tools.pk = {
        active: true,
        battleId: battle.id,
        opponentRoomId: battle.roomBId,
        opponentName: battle.roomBHost,
        opponentAvatar: battle.roomBAvatar,
        myScore: 0,
        opponentScore: 0,
        timeLeft: durationSeconds,
        startedAt: new Date().toISOString(),
        status: 'active'
      };
    } else if (action === 'end') {
      if (!isManager) return res.status(403).json({ success: false, error: 'Only room host can end PK' });
      if (tools.pk) {
        tools.pk.active = false;
        tools.pk.status = 'finished';
        tools.pk.winner = tools.pk.myScore > tools.pk.opponentScore ? 'roomA' : tools.pk.myScore < tools.pk.opponentScore ? 'roomB' : 'draw';
      }
      if (room.pkState) room.pkState.active = false;
      if (tools.activeTool === 'pk') tools.activeTool = 'none';

      RoomService.addRoomMessage(room.id, {
        roomId: room.id,
        userId: user?.id || 'sys',
        userName: 'Aura Referee',
        userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100',
        type: 'system',
        content: `⚔️ PK Battle Concluded! Final Score: ${tools.pk?.myScore || 0} vs ${tools.pk?.opponentScore || 0}`
      });
    } else if (action === 'score') {
      if (tools.pk && tools.pk.active) {
        if (side === 'roomA') {
          tools.pk.myScore += Number(points);
        } else {
          tools.pk.opponentScore += Number(points);
        }
        if (room.pkState) {
          room.pkState.myScore = tools.pk.myScore;
          room.pkState.opponentScore = tools.pk.opponentScore;
        }
      }
    }

    dbStore.rooms.set(room.id, room);
    return res.json({ success: true, data: tools.pk });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// 7. POST Room Game State & Activity
router.post('/rooms/:id/tools/game', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const room = dbStore.rooms.get(req.params.id);
    if (!room) return res.status(404).json({ success: false, error: 'Room not found' });

    const tools = ensureRoomToolsState(room);
    const { action, gameId, gameName, betCoins = 50 } = req.body;

    if (action === 'start') {
      tools.game = {
        activeGameId: gameId || 'spin',
        gameName: gameName || 'Wheel of Fortune',
        status: 'in_progress',
        hostId: user?.id || room.hostId,
        hostName: user?.name || room.hostName,
        players: user ? [{ userId: user.id, userName: user.name, userAvatar: user.avatar }] : []
      };
      tools.activeTool = 'game';

      RoomService.addRoomMessage(room.id, {
        roomId: room.id,
        userId: user?.id || 'sys',
        userName: user?.name || 'Host',
        userAvatar: user?.avatar || '',
        type: 'system',
        content: `🎮 ${user?.name || 'Host'} launched ${tools.game.gameName} in the room! Tap Tools > Game to play!`
      });
    } else if (action === 'end') {
      if (tools.game) {
        tools.game.status = 'ended';
      }
      if (tools.activeTool === 'game') tools.activeTool = 'none';
    } else if (action === 'invite') {
      RoomService.addRoomMessage(room.id, {
        roomId: room.id,
        userId: user?.id || 'sys',
        userName: user?.name || 'Game Master',
        userAvatar: user?.avatar || '',
        type: 'system',
        content: `🕹️ ${user?.name} invited all room members to join the ${gameName || 'Party Game'}! Join the fun!`
      });
    } else if (action === 'play') {
      // Execute game turn for player
      if (!user) return res.status(401).json({ success: false, error: 'Authentication required' });
      if (user.coins < Number(betCoins)) {
        return res.status(400).json({ success: false, error: `You need at least ${betCoins} coins to play.` });
      }

      user.coins -= Number(betCoins);
      const isWinner = Math.random() > 0.4;
      const multiplier = isWinner ? (Math.random() > 0.8 ? 5 : 2) : 0;
      const wonCoins = isWinner ? Math.floor(Number(betCoins) * multiplier) : 0;

      if (wonCoins > 0) {
        user.coins += wonCoins;
        RoomService.addRoomMessage(room.id, {
          roomId: room.id,
          userId: user.id,
          userName: user.name,
          userAvatar: user.avatar,
          type: 'system',
          content: `🎰 ${user.name} won ${wonCoins} coins in ${gameName || 'Room Game'}! (${multiplier}x Jackpot!)`
        });
      }

      dbStore.users.set(user.id, user);
      tools.game = {
        ...tools.game,
        lastResult: { isWinner, wonCoins, multiplier, timestamp: new Date().toISOString() }
      } as any;
    }

    dbStore.rooms.set(room.id, room);
    return res.json({ success: true, data: tools.game, userCoins: user?.coins });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// VOICE ROOM MANAGEMENT ADMIN ENDPOINTS
// ==========================================

router.post('/admin/rooms/:id/update', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user || !PermissionService.hasRoleOrHigher(user.role, 'host')) {
      return res.status(403).json({ success: false, error: 'Permission denied for room update' });
    }
    const updatedRoom = RoomService.updateRoomAdmin(req.params.id, req.body);
    dbStore.recordAudit({
      action: 'ADMIN_ROOM_UPDATED',
      module: 'room',
      performedByUserId: user.id,
      performedByUserName: user.name,
      performedByRole: user.role,
      targetId: req.params.id,
      details: `Updated room configuration: ${updatedRoom.title}`,
      ipAddress: req.ip || '127.0.0.1'
    });
    return res.json({ success: true, data: updatedRoom });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.post('/admin/rooms/:id/seat/update', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user || !PermissionService.hasRoleOrHigher(user.role, 'host')) {
      return res.status(403).json({ success: false, error: 'Permission denied' });
    }
    const { seatIndex, action, targetUserId, maxSeats } = req.body;
    const updatedRoom = RoomService.updateSeatAdmin(req.params.id, Number(seatIndex || 0), action, targetUserId, maxSeats);
    dbStore.recordAudit({
      action: 'ADMIN_ROOM_SEAT_UPDATED',
      module: 'room',
      performedByUserId: user.id,
      performedByUserName: user.name,
      performedByRole: user.role,
      targetId: req.params.id,
      details: `Seat action '${action}' on seat ${seatIndex} in room ${updatedRoom.title}`,
      ipAddress: req.ip || '127.0.0.1'
    });
    return res.json({ success: true, data: updatedRoom });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.post('/admin/rooms/:id/users/action', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user || !PermissionService.hasRoleOrHigher(user.role, 'host')) {
      return res.status(403).json({ success: false, error: 'Permission denied' });
    }
    const { targetUserId, action, durationMinutes, reason } = req.body;
    const result = RoomService.handleUserAction(req.params.id, targetUserId, action, durationMinutes, reason);
    dbStore.recordAudit({
      action: 'ADMIN_ROOM_USER_MODERATED',
      module: 'room',
      performedByUserId: user.id,
      performedByUserName: user.name,
      performedByRole: user.role,
      targetId: targetUserId,
      targetName: result.targetName,
      details: `User action '${action}' in room ${req.params.id}. Reason: ${reason || 'Governance'}`,
      ipAddress: req.ip || '127.0.0.1'
    });
    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.post('/admin/rooms/:id/settings', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user || !PermissionService.hasRoleOrHigher(user.role, 'host')) {
      return res.status(403).json({ success: false, error: 'Permission denied' });
    }
    const updatedRoom = RoomService.updateRoomSettings(req.params.id, req.body);
    dbStore.recordAudit({
      action: 'ADMIN_ROOM_SETTINGS_UPDATED',
      module: 'room',
      performedByUserId: user.id,
      performedByUserName: user.name,
      performedByRole: user.role,
      targetId: req.params.id,
      details: `Updated room settings for ${updatedRoom.title}`,
      ipAddress: req.ip || '127.0.0.1'
    });
    return res.json({ success: true, data: updatedRoom });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.post('/admin/rooms/:id/announcements', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user || !PermissionService.hasRoleOrHigher(user.role, 'host')) {
      return res.status(403).json({ success: false, error: 'Permission denied' });
    }
    const { action, announcementId, title, content, enabled } = req.body;
    const updatedRoom = RoomService.manageAnnouncements(req.params.id, action, { announcementId, title, content, enabled });
    dbStore.recordAudit({
      action: 'ADMIN_ROOM_ANNOUNCEMENT_MODIFIED',
      module: 'room',
      performedByUserId: user.id,
      performedByUserName: user.name,
      performedByRole: user.role,
      targetId: req.params.id,
      details: `Announcement '${action}' for room ${updatedRoom.title}`,
      ipAddress: req.ip || '127.0.0.1'
    });
    return res.json({ success: true, data: updatedRoom });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.post('/admin/rooms/pk/action', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user || !PermissionService.hasRoleOrHigher(user.role, 'host')) {
      return res.status(403).json({ success: false, error: 'Permission denied' });
    }
    const { action, roomAId, roomBId, durationSeconds, scoreA, scoreB } = req.body;
    let result: any = null;
    if (action === 'start') {
      result = RoomService.startPkBattle(roomAId, roomBId, durationSeconds || 300);
    } else if (action === 'score') {
      const activePk = Array.from(dbStore.pkBattles.values()).find(b => b.roomAId === roomAId || b.roomBId === roomAId);
      if (!activePk) throw new Error('Active PK not found');
      result = RoomService.updatePkScore(activePk.id, scoreA || 0, scoreB || 0);
    }
    dbStore.recordAudit({
      action: 'ADMIN_PK_BATTLE_ACTION',
      module: 'room',
      performedByUserId: user.id,
      performedByUserName: user.name,
      performedByRole: user.role,
      details: `PK Battle action '${action}' between ${roomAId} and ${roomBId}`,
      ipAddress: req.ip || '127.0.0.1'
    });
    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.get('/admin/rooms/analytics/summary', (req: Request, res: Response) => {
  try {
    const analytics = RoomService.getRoomAnalytics();
    return res.json({ success: true, data: analytics });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.get('/admin/rooms/:id/gifts', (req: Request, res: Response) => {
  try {
    const stats = RoomService.getRoomGiftStats(req.params.id);
    return res.json({ success: true, data: stats });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.post('/admin/rooms/:id/chat/delete', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user || !PermissionService.hasRoleOrHigher(user.role, 'host')) {
      return res.status(403).json({ success: false, error: 'Permission denied' });
    }
    const { messageId } = req.body;
    const remaining = RoomService.deleteRoomMessage(req.params.id, messageId);
    dbStore.recordAudit({
      action: 'ADMIN_ROOM_CHAT_DELETED',
      module: 'room',
      performedByUserId: user.id,
      performedByUserName: user.name,
      performedByRole: user.role,
      targetId: messageId,
      details: `Deleted message ${messageId} in room ${req.params.id}`,
      ipAddress: req.ip || '127.0.0.1'
    });
    return res.json({ success: true, data: remaining });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.post('/admin/rooms/:id/chat/blocked-words', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user || !PermissionService.hasRoleOrHigher(user.role, 'host')) {
      return res.status(403).json({ success: false, error: 'Permission denied' });
    }
    const { action, word } = req.body;
    const words = RoomService.manageBlockedWords(req.params.id, action, word);
    dbStore.recordAudit({
      action: 'ADMIN_BLOCKED_WORDS_MODIFIED',
      module: 'room',
      performedByUserId: user.id,
      performedByUserName: user.name,
      performedByRole: user.role,
      targetId: req.params.id,
      details: `Blocked words action '${action}' for word '${word}'`,
      ipAddress: req.ip || '127.0.0.1'
    });
    return res.json({ success: true, data: words });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

// ==========================================
// 3. GIFTS & WALLET ENDPOINTS
// ==========================================

router.get('/gifts', (req: Request, res: Response) => {
  try {
    const { category, search, minPrice, maxPrice, inStockOnly, sortBy } = req.query;
    const gifts = VirtualGiftService.getAllGifts({
      category: category as string,
      search: search as string,
      minPrice: minPrice ? Number(minPrice) : undefined,
      maxPrice: maxPrice ? Number(maxPrice) : undefined,
      inStockOnly: inStockOnly === 'true',
      sortBy: sortBy as any
    });
    return res.json({ success: true, data: gifts });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.get('/gifts/inventory', (req: Request, res: Response) => {
  try {
    const stats = VirtualGiftService.getInventoryStats();
    const gifts = VirtualGiftService.getAllGifts();
    return res.json({ 
      success: true, 
      data: {
        stats,
        catalog: gifts
      }
    });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.get('/gifts/inventory/user', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
    const inventory = VirtualGiftService.getUserGiftInventory(user.id);
    return res.json({ success: true, data: inventory });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.post('/gifts/inventory/user/claim', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
    const { giftId, quantity = 1, source = 'reward' } = req.body;
    const item = VirtualGiftService.addUserGiftInventory(user.id, giftId, Number(quantity), source);
    return res.json({ success: true, data: item });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.post('/gifts/send', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });

    const { 
      receiverId, 
      giftId, 
      count = 1, 
      roomId, 
      deductFromInventory = false,
      comboStreak = 1,
      customMessage 
    } = req.body;

    const result = VirtualGiftService.sendGiftInVoiceRoom({
      senderId: user.id,
      receiverId,
      giftId,
      count: Number(count),
      roomId,
      deductFromInventory: Boolean(deductFromInventory),
      comboStreak: Number(comboStreak) || 1,
      customMessage
    });

    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.post('/gifts/inventory/manage', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
    if (!PermissionService.hasPermission(user.role, 'settings:manage') && user.role !== 'ceo' && user.role !== 'admin' && user.role !== 'super_admin') {
      return res.status(403).json({ success: false, error: 'Permission denied. Staff only.' });
    }

    const { action, giftId, giftData, updates } = req.body;

    if (action === 'create') {
      const created = VirtualGiftService.addGiftToCatalog(user.id, giftData);
      return res.json({ success: true, data: created });
    } else if (action === 'update') {
      const updated = VirtualGiftService.updateGiftInCatalog(user.id, giftId, updates);
      return res.json({ success: true, data: updated });
    } else if (action === 'delete') {
      VirtualGiftService.deleteGiftFromCatalog(user.id, giftId);
      return res.json({ success: true, message: 'Gift deleted successfully' });
    }

    return res.status(400).json({ success: false, error: 'Invalid action specified' });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.get('/wallet/balance', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
    const balance = WalletService.getBalance(user.id);
    return res.json({ success: true, data: balance });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.get('/wallet/packages', (req: Request, res: Response) => {
  return res.json({ 
    success: true, 
    data: WalletService.getRechargePackages(),
    updatedAt: new Date().toISOString() 
  });
});

router.post('/wallet/packages', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user || !PermissionService.hasRoleOrHigher(user.role, 'admin')) {
      return res.status(403).json({ success: false, error: 'Requires Admin or CEO privileges' });
    }
    const packages = WalletService.createRechargePackage(user.id, req.body);
    return res.json({ 
      success: true, 
      data: packages, 
      message: 'Package created successfully',
      updatedAt: new Date().toISOString()
    });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.put('/wallet/packages/:id', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user || !PermissionService.hasRoleOrHigher(user.role, 'admin')) {
      return res.status(403).json({ success: false, error: 'Requires Admin or CEO privileges' });
    }
    const { id } = req.params;
    const packages = WalletService.updateRechargePackage(user.id, id, req.body);
    return res.json({ 
      success: true, 
      data: packages, 
      message: 'Package updated successfully',
      updatedAt: new Date().toISOString()
    });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.post('/wallet/packages/save-all', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user || !PermissionService.hasRoleOrHigher(user.role, 'admin')) {
      return res.status(403).json({ success: false, error: 'Requires Admin or CEO privileges' });
    }
    const { packages } = req.body;
    const updated = WalletService.saveAllRechargePackages(user.id, packages);
    return res.json({ 
      success: true, 
      data: updated, 
      message: 'All package configurations saved to database',
      updatedAt: new Date().toISOString()
    });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.delete('/wallet/packages/:id', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user || !PermissionService.hasRoleOrHigher(user.role, 'admin')) {
      return res.status(403).json({ success: false, error: 'Requires Admin or CEO privileges' });
    }
    const { id } = req.params;
    const packages = WalletService.deleteRechargePackage(user.id, id);
    return res.json({ 
      success: true, 
      data: packages, 
      message: 'Package deleted successfully',
      updatedAt: new Date().toISOString()
    });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.post('/admin/wallet/packages', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user || !PermissionService.hasRoleOrHigher(user.role, 'admin')) {
      return res.status(403).json({ success: false, error: 'Requires Admin or CEO privileges' });
    }
    const { packages } = req.body;
    const updated = WalletService.saveAllRechargePackages(user.id, packages);
    return res.json({ 
      success: true, 
      data: updated, 
      message: 'Wallet packages updated instantly',
      updatedAt: new Date().toISOString()
    });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.post('/wallet/withdrawals/moderate', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user || !PermissionService.hasRoleOrHigher(user.role, 'admin')) {
      return res.status(403).json({ success: false, error: 'Requires Admin or Finance role' });
    }
    const { txId, status, notes } = req.body;
    const tx = WalletService.moderateWithdrawal(user.id, txId, status, notes);
    return res.json({ success: true, data: tx });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

// ==========================================
// 3. WITHDRAW PAYMENT METHODS ENDPOINTS
// ==========================================

// Public / User route: Get active withdraw payment methods
router.get('/wallet/withdraw-methods', (req: Request, res: Response) => {
  try {
    const methods = WalletService.getWithdrawPaymentMethods(true);
    return res.json({ success: true, data: methods });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

// Admin route: Get all withdraw payment methods (active & inactive)
router.get('/admin/wallet/withdraw-methods', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const userRole = user?.role || user?.staffIdentity?.role;
    if (!user || !PermissionService.hasPermission(userRole, 'wallet:manage') && !PermissionService.hasRoleOrHigher(userRole, 'manager')) {
      return res.status(403).json({ success: false, error: 'Permission denied: Requires CEO, GM, or Manager with wallet permissions' });
    }
    const methods = WalletService.getWithdrawPaymentMethods(false);
    return res.json({ success: true, data: methods });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

// Admin route: Create new withdraw payment method
router.post('/admin/wallet/withdraw-methods', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const userRole = user?.role || user?.staffIdentity?.role;
    if (!user || !PermissionService.hasPermission(userRole, 'wallet:manage') && !PermissionService.hasRoleOrHigher(userRole, 'manager')) {
      return res.status(403).json({ success: false, error: 'Permission denied: Requires CEO, GM, or Manager with wallet permissions' });
    }

    const { name, type, currency, accountFieldLabel, placeholder, minWithdraw, maxWithdraw, processingFee, isActive, sortOrder } = req.body;
    if (!name || !name.trim()) {
      return res.status(400).json({ success: false, error: 'Payment method name is required' });
    }
    if (!accountFieldLabel || !accountFieldLabel.trim()) {
      return res.status(400).json({ success: false, error: 'Account field label is required' });
    }

    const list = WalletService.createWithdrawPaymentMethod(user.id, {
      name,
      type,
      currency,
      accountFieldLabel,
      placeholder,
      minWithdraw: minWithdraw !== undefined ? Number(minWithdraw) : 100,
      maxWithdraw: maxWithdraw !== undefined ? Number(maxWithdraw) : 50000,
      processingFee: processingFee !== undefined ? Number(processingFee) : 0,
      isActive: isActive !== false,
      sortOrder: sortOrder !== undefined ? Number(sortOrder) : undefined
    });

    return res.status(201).json({
      success: true,
      data: list,
      message: `Withdrawal method "${name}" created successfully`
    });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

// Admin route: Update withdraw payment method
router.put('/admin/wallet/withdraw-methods/:id', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const userRole = user?.role || user?.staffIdentity?.role;
    if (!user || !PermissionService.hasPermission(userRole, 'wallet:manage') && !PermissionService.hasRoleOrHigher(userRole, 'manager')) {
      return res.status(403).json({ success: false, error: 'Permission denied: Requires CEO, GM, or Manager with wallet permissions' });
    }

    const { id } = req.params;
    const list = WalletService.updateWithdrawPaymentMethod(user.id, id, req.body);

    return res.json({
      success: true,
      data: list,
      message: 'Withdrawal payment method updated successfully'
    });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

// Admin route: Toggle status of withdraw payment method
router.patch('/admin/wallet/withdraw-methods/:id/status', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const userRole = user?.role || user?.staffIdentity?.role;
    if (!user || !PermissionService.hasPermission(userRole, 'wallet:manage') && !PermissionService.hasRoleOrHigher(userRole, 'manager')) {
      return res.status(403).json({ success: false, error: 'Permission denied: Requires CEO, GM, or Manager with wallet permissions' });
    }

    const { id } = req.params;
    const { isActive } = req.body;
    if (isActive === undefined) {
      return res.status(400).json({ success: false, error: 'isActive boolean is required' });
    }

    const list = WalletService.toggleWithdrawPaymentMethodStatus(user.id, id, Boolean(isActive));
    return res.json({
      success: true,
      data: list,
      message: `Payment method ${isActive ? 'activated' : 'deactivated'} successfully`
    });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

// Admin route: Delete withdraw payment method with transaction safety checks
router.delete('/admin/wallet/withdraw-methods/:id', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const userRole = user?.role || user?.staffIdentity?.role;
    if (!user || !PermissionService.hasPermission(userRole, 'wallet:manage') && !PermissionService.hasRoleOrHigher(userRole, 'manager')) {
      return res.status(403).json({ success: false, error: 'Permission denied: Requires CEO, GM, or Manager with wallet permissions' });
    }

    const { id } = req.params;
    const result = WalletService.deleteWithdrawPaymentMethod(user.id, id);

    if (!result.success) {
      return res.status(400).json({
        success: false,
        error: result.error || 'Cannot delete payment method'
      });
    }

    return res.json({
      success: true,
      data: result.list,
      message: 'Withdrawal payment method deleted successfully'
    });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.get('/wallet/ledger', (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
  const { currency } = req.query;
  const list = WalletService.getLedgerByCurrency(user.id, currency as any);
  return res.json({ success: true, data: list });
});

router.post('/wallet/recharge', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
    const { coins = 0, diamonds = 0, description = 'In-app recharge' } = req.body;
    const tx = WalletService.recharge(user.id, Number(coins), Number(diamonds), description);
    return res.json({ success: true, data: tx });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.post('/wallet/withdraw', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
    const { diamonds, accountDetails } = req.body;
    const tx = WalletService.withdraw(user.id, Number(diamonds), accountDetails);
    return res.json({ success: true, data: tx });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.post('/wallet/direct-set', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
    const { coins, diamonds, reason } = req.body;
    const targetUser = dbStore.users.get(user.id);
    if (!targetUser) return res.status(404).json({ success: false, error: 'User not found' });

    if (coins !== undefined) {
      const numCoins = Math.max(0, Math.floor(Number(coins)));
      const diff = numCoins - targetUser.coins;
      targetUser.coins = numCoins;
      const tx: WalletTransaction = {
        id: `tx-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        userId: targetUser.id,
        type: 'admin_adjustment',
        currency: 'coin',
        amount: diff,
        balanceAfter: targetUser.coins,
        description: reason || 'Direct wallet coin balance update',
        status: 'completed',
        timestamp: new Date().toISOString()
      };
      dbStore.transactions.set(tx.id, tx);
    }

    if (diamonds !== undefined) {
      const numDiamonds = Math.max(0, Math.floor(Number(diamonds)));
      const diff = numDiamonds - targetUser.diamonds;
      targetUser.diamonds = numDiamonds;
      const tx: WalletTransaction = {
        id: `tx-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        userId: targetUser.id,
        type: 'admin_adjustment',
        currency: 'diamond',
        amount: diff,
        balanceAfter: targetUser.diamonds,
        description: reason || 'Direct wallet diamond balance update',
        status: 'completed',
        timestamp: new Date().toISOString()
      };
      dbStore.transactions.set(tx.id, tx);
    }

    dbStore.users.set(targetUser.id, targetUser);

    dbStore.recordAudit({
      action: 'WALLET_DIRECT_EDIT',
      module: 'wallet',
      performedByUserId: user.id,
      performedByUserName: user.name || user.email,
      performedByRole: user.role,
      targetId: targetUser.id,
      targetName: targetUser.name,
      details: `Direct wallet balance edited: Coins=${targetUser.coins}, Diamonds=${targetUser.diamonds}`,
      ipAddress: req.ip || '127.0.0.1'
    });

    return res.json({ success: true, data: targetUser });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.get('/wallet/transactions', (req: Request, res: Response) => {
  const user = (req as any).user;
  const list = Array.from(dbStore.transactions.values()).filter(t => t.userId === user?.id);
  return res.json({ success: true, data: list });
});

// ==========================================
// 4. LUCKY BAG & DAILY SPIN ENDPOINTS
// ==========================================

router.get('/luckybag/active', (req: Request, res: Response) => {
  const { roomId } = req.query;
  const bags = Array.from(dbStore.luckyBags.values()).filter(b => b.status === 'active' && (!roomId || b.roomId === roomId));
  return res.json({ success: true, data: bags });
});

router.post('/luckybag/create', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
    const { roomId, totalCoins, totalWinners } = req.body;
    const bag = RoomService.createLuckyBag(roomId, user.id, Number(totalCoins), Number(totalWinners));
    return res.status(201).json({ success: true, data: bag });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.post('/luckybag/claim', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
    const { bagId } = req.body;
    const result = RoomService.claimLuckyBag(bagId, user.id);
    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.get('/spin/rewards', (req: Request, res: Response) => {
  return res.json({ success: true, data: dbStore.spinRewards });
});

router.post('/spin', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
    const result = RoomService.spinWheel(user.id);
    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

// ==========================================
// 4.1 TOP CONTRIBUTORS LEADERBOARD
// ==========================================

router.get('/leaderboard/contributors', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const category = (req.query.category as any) || 'earners';
    const period = (req.query.period as any) || 'daily';
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit as string) || 50));

    const result = VirtualGiftService.getTopContributors(category, period, limit, user?.id);
    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

// ==========================================
// 5. FAMILIES & PK BATTLES
// ==========================================

router.get('/families', (req: Request, res: Response) => {
  const list = Array.from(dbStore.families.values()).sort((a, b) => a.ranking - b.ranking);
  return res.json({ success: true, data: list });
});

router.post('/families', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized: Please log in first' });

    const { 
      name, 
      familyId, 
      logo, 
      slogan, 
      description, 
      announcement, 
      country, 
      category, 
      privacy = 'public', 
      joinMethod = 'anyone' 
    } = req.body;

    if (!name || typeof name !== 'string' || name.trim().length < 2) {
      return res.status(400).json({ success: false, error: 'Family Name is required (minimum 2 characters)' });
    }

    const trimmedName = name.trim();
    // Check duplicate family name
    const existingName = Array.from(dbStore.families.values()).find(
      f => f.name.toLowerCase() === trimmedName.toLowerCase()
    );
    if (existingName) {
      return res.status(400).json({ success: false, error: 'A Family with this name already exists. Please choose another name.' });
    }

    // Determine or validate Family ID
    let finalFamilyId = familyId ? familyId.trim() : `FAM-${Math.floor(100000 + Math.random() * 900000)}`;
    const existingId = Array.from(dbStore.families.values()).find(
      f => f.familyId === finalFamilyId || f.id === finalFamilyId
    );
    if (existingId) {
      finalFamilyId = `FAM-${Math.floor(100000 + Math.random() * 900000)}`;
    }

    // Check if user is already family leader/owner
    if (user.familyId) {
      const currentFam = dbStore.families.get(user.familyId);
      if (currentFam && (currentFam.leaderId === user.id || currentFam.ownerId === user.id)) {
        return res.status(400).json({ success: false, error: 'You are already the Owner/Leader of an existing Family.' });
      }
    }

    // Creation Fee Handling (Default 500 Coins)
    const creationFee = 500;
    if (user.coins < creationFee) {
      return res.status(400).json({ 
        success: false, 
        error: `Insufficient coins to create Family. Required: ${creationFee} coins, Available: ${user.coins} coins.` 
      });
    }

    // Deduct fee atomically
    user.coins -= creationFee;

    const newFamily: Family = {
      id: `fam-${Date.now()}`,
      familyId: finalFamilyId,
      name: trimmedName,
      slogan: slogan || description || 'United in voice & brotherhood!',
      badge: trimmedName.charAt(0).toUpperCase() || '🛡️',
      logo: logo || 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=500&q=80',
      coverImage: logo || 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=500&q=80',
      description: description || slogan || '',
      announcement: announcement || 'Welcome to our newly formed Family clan!',
      country: country || user.country || 'Global',
      category: category || 'Social',
      privacy: privacy === 'private' ? 'private' : 'public',
      joinMethod: ['anyone', 'approval', 'invite'].includes(joinMethod) ? joinMethod : 'anyone',
      ownerId: user.id,
      leaderId: user.id,
      leaderName: user.name,
      level: 1,
      totalContribution: 0,
      memberCount: 1,
      maxMembers: 50,
      ranking: dbStore.families.size + 1,
      createdAt: new Date().toISOString()
    };

    dbStore.families.set(newFamily.id, newFamily);

    // Update user record with family assignment
    user.familyId = newFamily.id;
    user.familyName = newFamily.name;
    dbStore.users.set(user.id, user);

    // Record wallet transaction
    dbStore.transactions.set(`tx-${Date.now()}`, {
      id: `tx-${Date.now()}`,
      userId: user.id,
      type: 'admin_adjustment',
      currency: 'coin',
      amount: -creationFee,
      balanceAfter: user.coins,
      description: `Family Creation Fee for ${newFamily.name} (${finalFamilyId})`,
      status: 'completed',
      timestamp: new Date().toISOString(),
      createdAt: new Date().toISOString()
    });

    // Record audit log
    dbStore.recordAudit({
      action: 'FAMILY_CREATED',
      module: 'family',
      performedByUserId: user.id,
      performedByUserName: user.name,
      performedByRole: user.role,
      targetId: newFamily.id,
      targetName: newFamily.name,
      details: `Created Family "${newFamily.name}" (ID: ${finalFamilyId}). Creation Fee: ${creationFee} coins deducted.`,
      ipAddress: req.ip || '127.0.0.1'
    });

    return res.status(201).json({ success: true, data: newFamily, user });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Server error creating family' });
  }
});

router.post('/families/:id/join', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });

    const family = dbStore.families.get(req.params.id);
    if (!family) return res.status(404).json({ success: false, error: 'Family not found' });

    if (user.familyId === family.id) {
      return res.status(400).json({ success: false, error: 'You are already a member of this Family' });
    }

    user.familyId = family.id;
    user.familyName = family.name;
    dbStore.users.set(user.id, user);

    family.memberCount = (family.memberCount || 0) + 1;
    dbStore.families.set(family.id, family);

    // Add FamilyMember record
    const memberId = `fmem-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    dbStore.familyMembers.set(memberId, {
      id: memberId,
      familyId: family.id,
      userId: user.id,
      userUid: user.uid,
      name: user.name,
      avatar: user.avatar,
      role: 'member',
      userRole: user.role,
      contributionDaily: 0,
      contributionTotal: 0,
      isOnline: user.isOnline,
      joinedAt: new Date().toISOString()
    });

    return res.json({ success: true, data: family, user });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Apply for Family Membership (Top-Rated / Approval required)
router.post('/families/:id/apply', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized: Please log in first' });

    const family = dbStore.families.get(req.params.id);
    if (!family) return res.status(404).json({ success: false, error: 'Family not found' });

    if (user.familyId === family.id) {
      return res.status(400).json({ success: false, error: 'You are already a member of this Family' });
    }

    // Check for existing pending application
    const existing = Array.from(dbStore.familyApplications.values()).find(
      app => app.familyId === family.id && app.userId === user.id && app.status === 'pending'
    );
    if (existing) {
      return res.status(400).json({ success: false, error: 'You already have a pending application for this Family' });
    }

    const { message } = req.body;
    const appId = `fapp-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const newApplication = {
      id: appId,
      familyId: family.id,
      familyName: family.name,
      familyBadge: family.badge,
      familyLogo: family.logo,
      userId: user.id,
      userUid: user.uid,
      userName: user.name,
      userAvatar: user.avatar,
      message: message ? message.trim() : 'I would love to join your family guild and contribute actively!',
      status: 'pending' as const,
      createdAt: new Date().toISOString()
    };

    dbStore.familyApplications.set(appId, newApplication);

    return res.status(201).json({ 
      success: true, 
      data: newApplication, 
      message: `Membership application submitted to ${family.name} leaders!` 
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Get user's own submitted applications
router.get('/families/applications/my', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });

    const myApps = Array.from(dbStore.familyApplications.values())
      .filter(app => app.userId === user.id)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    return res.json({ success: true, data: myApps });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Get family's applications (for leaders / managers)
router.get('/families/:id/applications', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });

    const family = dbStore.families.get(req.params.id);
    if (!family) return res.status(404).json({ success: false, error: 'Family not found' });

    const apps = Array.from(dbStore.familyApplications.values())
      .filter(app => app.familyId === family.id)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    return res.json({ success: true, data: apps });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Approve or Reject an Application
router.post('/families/applications/:id/decision', (req: Request, res: Response) => {
  try {
    const executor = (req as any).user;
    if (!executor) return res.status(401).json({ success: false, error: 'Unauthorized' });

    const app = dbStore.familyApplications.get(req.params.id);
    if (!app) return res.status(404).json({ success: false, error: 'Application not found' });

    const family = dbStore.families.get(app.familyId);
    if (!family) return res.status(404).json({ success: false, error: 'Family not found' });

    const { decision } = req.body; // 'approve' | 'reject'
    if (decision !== 'approve' && decision !== 'reject') {
      return res.status(400).json({ success: false, error: 'Invalid decision: must be "approve" or "reject"' });
    }

    if (decision === 'approve') {
      app.status = 'approved';
      app.decidedAt = new Date().toISOString();

      // Add user to family
      const targetUser = dbStore.users.get(app.userId);
      if (targetUser) {
        targetUser.familyId = family.id;
        targetUser.familyName = family.name;
        dbStore.users.set(targetUser.id, targetUser);
      }

      family.memberCount = (family.memberCount || 0) + 1;
      dbStore.families.set(family.id, family);

      const memberId = `fmem-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
      dbStore.familyMembers.set(memberId, {
        id: memberId,
        familyId: family.id,
        userId: app.userId,
        userUid: app.userUid,
        name: app.userName,
        avatar: app.userAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=120&q=80',
        role: 'member',
        contributionDaily: 0,
        contributionTotal: 0,
        isOnline: true,
        joinedAt: new Date().toISOString()
      });
    } else {
      app.status = 'rejected';
      app.decidedAt = new Date().toISOString();
    }

    dbStore.familyApplications.set(app.id, app);

    return res.json({ 
      success: true, 
      data: app, 
      message: `Application ${decision === 'approve' ? 'approved' : 'rejected'} successfully.` 
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Leave Family
router.post('/families/:id/leave', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });

    const family = dbStore.families.get(req.params.id);
    if (!family) return res.status(404).json({ success: false, error: 'Family not found' });

    if (family.leaderId === user.id || family.ownerId === user.id) {
      return res.status(400).json({ success: false, error: 'Family Leader/Owner cannot leave directly. Please transfer leadership first.' });
    }

    user.familyId = undefined;
    user.familyName = undefined;
    dbStore.users.set(user.id, user);

    family.memberCount = Math.max(1, (family.memberCount || 1) - 1);
    dbStore.families.set(family.id, family);

    // Remove from familyMembers
    for (const [memId, mem] of dbStore.familyMembers.entries()) {
      if (mem.familyId === family.id && mem.userId === user.id) {
        dbStore.familyMembers.delete(memId);
      }
    }

    return res.json({ success: true, message: `You have left ${family.name}.` });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Admin Family Management Endpoints
router.post('/admin/families', (req: Request, res: Response) => {
  try {
    const executor = (req as any).user;
    if (!executor) return res.status(401).json({ success: false, error: 'Unauthorized' });

    const authCheck = PermissionService.canManageFamily(executor.role, executor.permissions, 'create');
    if (!authCheck.allowed) {
      return res.status(authCheck.status).json({ success: false, error: authCheck.error });
    }

    const {
      name,
      familyId,
      logo,
      badge,
      slogan,
      description,
      announcement,
      country,
      category,
      level = 1,
      xp = 0,
      maxMembers = 50,
      status = 'active',
      privacy = 'public',
      joinMethod = 'anyone',
      leaderId,
      coLeaderIds = []
    } = req.body;

    if (!name || typeof name !== 'string' || name.trim().length < 2) {
      return res.status(400).json({ success: false, error: 'Family Name is required (minimum 2 characters)' });
    }

    const trimmedName = name.trim();
    // Check duplicate name
    const existingWithName = Array.from(dbStore.families.values()).find(
      f => f.name.toLowerCase() === trimmedName.toLowerCase()
    );
    if (existingWithName) {
      return res.status(400).json({ success: false, error: `A Family named "${trimmedName}" already exists.` });
    }

    // Validate leader
    if (!leaderId) {
      return res.status(400).json({ success: false, error: 'Family Leader selection is required' });
    }

    const leaderUser = dbStore.users.get(leaderId);
    if (!leaderUser) {
      return res.status(404).json({ success: false, error: 'Selected Family Leader user not found' });
    }

    // Generate or validate Family ID
    let finalFamilyId = familyId ? familyId.trim().toUpperCase() : `FAM-${Math.floor(100000 + Math.random() * 900000)}`;
    const existingWithId = Array.from(dbStore.families.values()).find(
      f => f.familyId === finalFamilyId || f.id === finalFamilyId
    );
    if (existingWithId) {
      if (familyId) {
        return res.status(400).json({ success: false, error: `Family ID "${finalFamilyId}" is already assigned to another Guild.` });
      }
      finalFamilyId = `FAM-${Math.floor(100000 + Math.random() * 900000)}`;
    }

    const newFamId = `fam-${Date.now()}`;
    const initialLevel = Math.max(1, Math.min(10, Number(level) || 1));
    const initialMaxMembers = Math.max(10, Math.min(1000, Number(maxMembers) || 50));
    const defaultLogo = logo || 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=500&q=80';

    // Resolve co-leaders
    const validCoLeaders: any[] = [];
    const coLeaderNames: string[] = [];
    const validCoLeaderIds: string[] = [];
    if (Array.isArray(coLeaderIds)) {
      for (const clId of coLeaderIds) {
        if (clId && clId !== leaderUser.id) {
          const clUser = dbStore.users.get(clId);
          if (clUser) {
            validCoLeaders.push(clUser);
            coLeaderNames.push(clUser.name);
            validCoLeaderIds.push(clUser.id);
          }
        }
      }
    }

    const createdFamily: Family = {
      id: newFamId,
      familyId: finalFamilyId,
      name: trimmedName,
      slogan: slogan || description || 'United in voice & brotherhood!',
      badge: badge || trimmedName.charAt(0).toUpperCase() || '👑',
      logo: defaultLogo,
      coverImage: defaultLogo,
      description: description || slogan || '',
      announcement: announcement || 'Welcome to our Family guild!',
      country: country || leaderUser.country || 'Global 🌐',
      category: category || 'Social & Community',
      status: ['active', 'inactive', 'suspended'].includes(status) ? status : 'active',
      privacy: privacy === 'private' ? 'private' : 'public',
      joinMethod: ['anyone', 'approval', 'invite'].includes(joinMethod) ? joinMethod : 'anyone',
      ownerId: leaderUser.id,
      leaderId: leaderUser.id,
      leaderName: leaderUser.name,
      leaderAvatar: leaderUser.avatar,
      coLeaderIds: validCoLeaderIds,
      coLeaderNames: coLeaderNames,
      level: initialLevel,
      xp: Number(xp) || (initialLevel * 5000),
      totalContribution: 0,
      memberCount: 1 + validCoLeaders.length,
      maxMembers: initialMaxMembers,
      ranking: dbStore.families.size + 1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    dbStore.families.set(createdFamily.id, createdFamily);

    // Assign leader
    leaderUser.familyId = createdFamily.id;
    leaderUser.familyName = createdFamily.name;
    dbStore.users.set(leaderUser.id, leaderUser);

    // Create Leader FamilyMember
    const leaderMemberId = `fmem-${Date.now()}-ldr`;
    dbStore.familyMembers.set(leaderMemberId, {
      id: leaderMemberId,
      familyId: createdFamily.id,
      userId: leaderUser.id,
      userUid: leaderUser.uid,
      name: leaderUser.name,
      avatar: leaderUser.avatar,
      role: 'leader',
      userRole: leaderUser.role,
      contributionDaily: 0,
      contributionTotal: 0,
      isOnline: leaderUser.isOnline,
      joinedAt: new Date().toISOString()
    });

    // Create Co-Leaders FamilyMembers
    validCoLeaders.forEach((cl, idx) => {
      cl.familyId = createdFamily.id;
      cl.familyName = createdFamily.name;
      dbStore.users.set(cl.id, cl);

      const clMemId = `fmem-${Date.now()}-cl-${idx}`;
      dbStore.familyMembers.set(clMemId, {
        id: clMemId,
        familyId: createdFamily.id,
        userId: cl.id,
        userUid: cl.uid,
        name: cl.name,
        avatar: cl.avatar,
        role: 'co_leader',
        userRole: cl.role,
        contributionDaily: 0,
        contributionTotal: 0,
        isOnline: cl.isOnline,
        joinedAt: new Date().toISOString()
      });
    });

    // Audit Log
    dbStore.recordAudit({
      action: 'FAMILY_CREATED_ADMIN',
      module: 'family',
      performedByUserId: executor.id,
      performedByUserName: executor.name,
      performedByRole: executor.role,
      targetId: createdFamily.id,
      targetName: createdFamily.name,
      details: `Created Family Guild "${createdFamily.name}" (${finalFamilyId}) with Leader ${leaderUser.name} (UID: ${leaderUser.uid}). Initial Level: ${initialLevel}, Max Members: ${initialMaxMembers}, Status: ${createdFamily.status}.`,
      ipAddress: req.ip || '127.0.0.1'
    });

    return res.status(201).json({ success: true, data: createdFamily });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Error creating family' });
  }
});

router.put('/admin/families/:id', (req: Request, res: Response) => {
  try {
    const executor = (req as any).user;
    if (!executor) return res.status(401).json({ success: false, error: 'Unauthorized' });

    const authCheck = PermissionService.canManageFamily(executor.role, executor.permissions, 'edit');
    if (!authCheck.allowed) {
      return res.status(authCheck.status).json({ success: false, error: authCheck.error });
    }

    const family = dbStore.families.get(req.params.id);
    if (!family) return res.status(404).json({ success: false, error: 'Family not found' });

    const {
      name,
      slogan,
      badge,
      logo,
      coverImage,
      description,
      announcement,
      country,
      category,
      level,
      xp,
      maxMembers,
      status,
      privacy,
      joinMethod
    } = req.body;

    const oldName = family.name;

    if (name && typeof name === 'string' && name.trim().length >= 2) {
      const trimmedName = name.trim();
      const duplicate = Array.from(dbStore.families.values()).find(
        f => f.id !== family.id && f.name.toLowerCase() === trimmedName.toLowerCase()
      );
      if (duplicate) {
        return res.status(400).json({ success: false, error: `Another family is already using the name "${trimmedName}"` });
      }
      family.name = trimmedName;

      // Update familyName for all users and members if changed
      if (oldName !== trimmedName) {
        for (const user of dbStore.users.values()) {
          if (user.familyId === family.id) {
            user.familyName = trimmedName;
            dbStore.users.set(user.id, user);
          }
        }
      }
    }

    if (slogan !== undefined) family.slogan = slogan;
    if (badge !== undefined) family.badge = badge;
    if (logo !== undefined) {
      family.logo = logo;
      if (!family.coverImage || family.coverImage === family.logo) {
        family.coverImage = logo;
      }
    }
    if (coverImage !== undefined) family.coverImage = coverImage;
    if (description !== undefined) family.description = description;
    if (announcement !== undefined) family.announcement = announcement;
    if (country !== undefined) family.country = country;
    if (category !== undefined) family.category = category;
    if (level !== undefined) family.level = Math.max(1, Math.min(10, Number(level)));
    if (xp !== undefined) family.xp = Math.max(0, Number(xp));
    if (maxMembers !== undefined) family.maxMembers = Math.max(10, Math.min(1000, Number(maxMembers)));
    if (status && ['active', 'inactive', 'suspended'].includes(status)) family.status = status;
    if (privacy && ['public', 'private'].includes(privacy)) family.privacy = privacy;
    if (joinMethod && ['anyone', 'approval', 'invite'].includes(joinMethod)) family.joinMethod = joinMethod;
    family.updatedAt = new Date().toISOString();

    dbStore.families.set(family.id, family);

    dbStore.recordAudit({
      action: 'FAMILY_UPDATED',
      module: 'family',
      performedByUserId: executor.id,
      performedByUserName: executor.name,
      performedByRole: executor.role,
      targetId: family.id,
      targetName: family.name,
      details: `Updated details for Family "${family.name}" (${family.familyId || family.id}).`,
      ipAddress: req.ip || '127.0.0.1'
    });

    return res.json({ success: true, data: family });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/admin/families/:id/status', (req: Request, res: Response) => {
  try {
    const executor = (req as any).user;
    if (!executor) return res.status(401).json({ success: false, error: 'Unauthorized' });

    const authCheck = PermissionService.canManageFamily(executor.role, executor.permissions, 'suspend');
    if (!authCheck.allowed) {
      return res.status(authCheck.status).json({ success: false, error: authCheck.error });
    }

    const family = dbStore.families.get(req.params.id);
    if (!family) return res.status(404).json({ success: false, error: 'Family not found' });

    const { status, reason } = req.body;
    if (!['active', 'inactive', 'suspended'].includes(status)) {
      return res.status(400).json({ success: false, error: 'Invalid status. Must be active, inactive, or suspended.' });
    }

    const oldStatus = family.status || 'active';
    family.status = status;
    family.suspendReason = reason || '';
    family.updatedAt = new Date().toISOString();
    dbStore.families.set(family.id, family);

    dbStore.recordAudit({
      action: 'FAMILY_STATUS_CHANGED',
      module: 'family',
      performedByUserId: executor.id,
      performedByUserName: executor.name,
      performedByRole: executor.role,
      targetId: family.id,
      targetName: family.name,
      details: `Changed Family status from "${oldStatus}" to "${status}". Reason: ${reason || 'N/A'}`,
      ipAddress: req.ip || '127.0.0.1'
    });

    return res.json({ success: true, data: family });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/admin/families/:id/transfer-leadership', (req: Request, res: Response) => {
  try {
    const executor = (req as any).user;
    if (!executor) return res.status(401).json({ success: false, error: 'Unauthorized' });

    const authCheck = PermissionService.canManageFamily(executor.role, executor.permissions, 'edit');
    if (!authCheck.allowed) {
      return res.status(authCheck.status).json({ success: false, error: authCheck.error });
    }

    const family = dbStore.families.get(req.params.id);
    if (!family) return res.status(404).json({ success: false, error: 'Family not found' });

    const { newLeaderUserId } = req.body;
    if (!newLeaderUserId) {
      return res.status(400).json({ success: false, error: 'Target new leader user is required' });
    }

    const newLeader = dbStore.users.get(newLeaderUserId);
    if (!newLeader) {
      return res.status(404).json({ success: false, error: 'Target user not found' });
    }

    const oldLeaderId = family.leaderId;
    const oldLeaderName = family.leaderName;

    // Update old leader member role to elder/member
    for (const mem of dbStore.familyMembers.values()) {
      if (mem.familyId === family.id && mem.userId === oldLeaderId) {
        mem.role = 'elder';
        dbStore.familyMembers.set(mem.id, mem);
      }
    }

    // Update or create new leader member
    let foundNewLeaderMem = false;
    for (const mem of dbStore.familyMembers.values()) {
      if (mem.familyId === family.id && mem.userId === newLeader.id) {
        mem.role = 'leader';
        foundNewLeaderMem = true;
        dbStore.familyMembers.set(mem.id, mem);
      }
    }

    if (!foundNewLeaderMem) {
      const newMemId = `fmem-${Date.now()}-ldr`;
      dbStore.familyMembers.set(newMemId, {
        id: newMemId,
        familyId: family.id,
        userId: newLeader.id,
        userUid: newLeader.uid,
        name: newLeader.name,
        avatar: newLeader.avatar,
        role: 'leader',
        userRole: newLeader.role,
        contributionDaily: 0,
        contributionTotal: 0,
        isOnline: newLeader.isOnline,
        joinedAt: new Date().toISOString()
      });
      family.memberCount = (family.memberCount || 0) + 1;
    }

    // Update family
    family.leaderId = newLeader.id;
    family.leaderName = newLeader.name;
    family.leaderAvatar = newLeader.avatar;
    family.ownerId = newLeader.id;
    family.updatedAt = new Date().toISOString();
    dbStore.families.set(family.id, family);

    // Update new leader user record
    newLeader.familyId = family.id;
    newLeader.familyName = family.name;
    dbStore.users.set(newLeader.id, newLeader);

    dbStore.recordAudit({
      action: 'FAMILY_LEADERSHIP_TRANSFERRED',
      module: 'family',
      performedByUserId: executor.id,
      performedByUserName: executor.name,
      performedByRole: executor.role,
      targetId: family.id,
      targetName: family.name,
      details: `Transferred leadership of Family "${family.name}" from ${oldLeaderName} to ${newLeader.name} (UID: ${newLeader.uid}).`,
      ipAddress: req.ip || '127.0.0.1'
    });

    return res.json({ success: true, data: family });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

router.get('/admin/families/:id/members', (req: Request, res: Response) => {
  try {
    const family = dbStore.families.get(req.params.id);
    if (!family) return res.status(404).json({ success: false, error: 'Family not found' });

    // Collect all members
    const members: FamilyMember[] = [];
    for (const mem of dbStore.familyMembers.values()) {
      if (mem.familyId === family.id) {
        const u = dbStore.users.get(mem.userId);
        if (u) {
          mem.name = u.name;
          mem.avatar = u.avatar;
          mem.userUid = u.uid;
          mem.userRole = u.role;
          mem.isOnline = u.isOnline;
        }
        members.push(mem);
      }
    }

    // If leader is missing from familyMembers for some reason, synthesize leader member
    if (!members.some(m => m.userId === family.leaderId)) {
      const leaderUser = dbStore.users.get(family.leaderId);
      if (leaderUser) {
        const synthesizedId = `fmem-auto-${family.id}-ldr`;
        const synMem: FamilyMember = {
          id: synthesizedId,
          familyId: family.id,
          userId: leaderUser.id,
          userUid: leaderUser.uid,
          name: leaderUser.name,
          avatar: leaderUser.avatar,
          role: 'leader',
          userRole: leaderUser.role,
          contributionDaily: 0,
          contributionTotal: 0,
          isOnline: leaderUser.isOnline,
          joinedAt: family.createdAt || new Date().toISOString()
        };
        dbStore.familyMembers.set(synthesizedId, synMem);
        members.unshift(synMem);
      }
    }

    return res.json({ success: true, data: members });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/admin/families/:id/members', (req: Request, res: Response) => {
  try {
    const executor = (req as any).user;
    if (!executor) return res.status(401).json({ success: false, error: 'Unauthorized' });

    const authCheck = PermissionService.canManageFamily(executor.role, executor.permissions, 'members');
    if (!authCheck.allowed) {
      return res.status(authCheck.status).json({ success: false, error: authCheck.error });
    }

    const family = dbStore.families.get(req.params.id);
    if (!family) return res.status(404).json({ success: false, error: 'Family not found' });

    const { userId, role = 'member' } = req.body;
    if (!userId) return res.status(400).json({ success: false, error: 'User ID is required' });

    const targetUser = dbStore.users.get(userId);
    if (!targetUser) return res.status(404).json({ success: false, error: 'User not found' });

    // Check if already in family
    const existing = Array.from(dbStore.familyMembers.values()).find(
      m => m.familyId === family.id && m.userId === targetUser.id
    );
    if (existing) {
      return res.status(400).json({ success: false, error: `${targetUser.name} is already a member of this Family` });
    }

    const memberRole = ['co_leader', 'elder', 'member'].includes(role) ? role : 'member';
    const newMemId = `fmem-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const newMember: FamilyMember = {
      id: newMemId,
      familyId: family.id,
      userId: targetUser.id,
      userUid: targetUser.uid,
      name: targetUser.name,
      avatar: targetUser.avatar,
      role: memberRole as any,
      userRole: targetUser.role,
      contributionDaily: 0,
      contributionTotal: 0,
      isOnline: targetUser.isOnline,
      joinedAt: new Date().toISOString()
    };

    dbStore.familyMembers.set(newMemId, newMember);

    // Update user record
    targetUser.familyId = family.id;
    targetUser.familyName = family.name;
    dbStore.users.set(targetUser.id, targetUser);

    family.memberCount = (family.memberCount || 0) + 1;
    dbStore.families.set(family.id, family);

    dbStore.recordAudit({
      action: 'FAMILY_MEMBER_ADDED',
      module: 'family',
      performedByUserId: executor.id,
      performedByUserName: executor.name,
      performedByRole: executor.role,
      targetId: family.id,
      targetName: family.name,
      details: `Added ${targetUser.name} (UID: ${targetUser.uid}) to Family "${family.name}" with role "${memberRole}".`,
      ipAddress: req.ip || '127.0.0.1'
    });

    return res.status(201).json({ success: true, data: newMember });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

router.put('/admin/families/:id/members/:userId/role', (req: Request, res: Response) => {
  try {
    const executor = (req as any).user;
    if (!executor) return res.status(401).json({ success: false, error: 'Unauthorized' });

    const authCheck = PermissionService.canManageFamily(executor.role, executor.permissions, 'members');
    if (!authCheck.allowed) {
      return res.status(authCheck.status).json({ success: false, error: authCheck.error });
    }

    const family = dbStore.families.get(req.params.id);
    if (!family) return res.status(404).json({ success: false, error: 'Family not found' });

    const { role } = req.body;
    if (!['co_leader', 'elder', 'member'].includes(role)) {
      return res.status(400).json({ success: false, error: 'Invalid role. Must be co_leader, elder, or member' });
    }

    const member = Array.from(dbStore.familyMembers.values()).find(
      m => m.familyId === family.id && m.userId === req.params.userId
    );
    if (!member) return res.status(404).json({ success: false, error: 'Member not found in this family' });

    if (member.role === 'leader') {
      return res.status(400).json({ success: false, error: 'Cannot change Leader role here. Use Transfer Leadership instead.' });
    }

    member.role = role as any;
    dbStore.familyMembers.set(member.id, member);

    return res.json({ success: true, data: member });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

router.delete('/admin/families/:id/members/:userId', (req: Request, res: Response) => {
  try {
    const executor = (req as any).user;
    if (!executor) return res.status(401).json({ success: false, error: 'Unauthorized' });

    const authCheck = PermissionService.canManageFamily(executor.role, executor.permissions, 'members');
    if (!authCheck.allowed) {
      return res.status(authCheck.status).json({ success: false, error: authCheck.error });
    }

    const family = dbStore.families.get(req.params.id);
    if (!family) return res.status(404).json({ success: false, error: 'Family not found' });

    if (req.params.userId === family.leaderId) {
      return res.status(400).json({ success: false, error: 'Cannot remove Family Leader. Transfer leadership first.' });
    }

    let removed = false;
    for (const [id, mem] of dbStore.familyMembers.entries()) {
      if (mem.familyId === family.id && mem.userId === req.params.userId) {
        dbStore.familyMembers.delete(id);
        removed = true;
      }
    }

    const targetUser = dbStore.users.get(req.params.userId);
    if (targetUser && targetUser.familyId === family.id) {
      targetUser.familyId = undefined;
      targetUser.familyName = undefined;
      dbStore.users.set(targetUser.id, targetUser);
    }

    if (removed) {
      family.memberCount = Math.max(1, (family.memberCount || 1) - 1);
      dbStore.families.set(family.id, family);
    }

    dbStore.recordAudit({
      action: 'FAMILY_MEMBER_REMOVED',
      module: 'family',
      performedByUserId: executor.id,
      performedByUserName: executor.name,
      performedByRole: executor.role,
      targetId: family.id,
      targetName: family.name,
      details: `Removed member ${targetUser ? targetUser.name : req.params.userId} from Family "${family.name}".`,
      ipAddress: req.ip || '127.0.0.1'
    });

    return res.json({ success: true, message: 'Member removed from Family' });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

router.delete('/admin/families/:id', (req: Request, res: Response) => {
  try {
    const executor = (req as any).user;
    if (!executor) return res.status(401).json({ success: false, error: 'Unauthorized' });

    const authCheck = PermissionService.canManageFamily(executor.role, executor.permissions, 'delete');
    if (!authCheck.allowed) {
      return res.status(authCheck.status).json({ success: false, error: authCheck.error });
    }

    const family = dbStore.families.get(req.params.id);
    if (!family) return res.status(404).json({ success: false, error: 'Family not found' });

    const familyName = family.name;

    // Detach all members
    for (const [id, mem] of dbStore.familyMembers.entries()) {
      if (mem.familyId === family.id) {
        dbStore.familyMembers.delete(id);
      }
    }

    for (const user of dbStore.users.values()) {
      if (user.familyId === family.id) {
        user.familyId = undefined;
        user.familyName = undefined;
        dbStore.users.set(user.id, user);
      }
    }

    dbStore.families.delete(family.id);

    dbStore.recordAudit({
      action: 'FAMILY_DELETED',
      module: 'family',
      performedByUserId: executor.id,
      performedByUserName: executor.name,
      performedByRole: executor.role,
      targetId: family.id,
      targetName: familyName,
      details: `Disbanded and deleted Family Guild "${familyName}" (${family.familyId || family.id}). All members detached.`,
      ipAddress: req.ip || '127.0.0.1'
    });

    return res.json({ success: true, message: `Family "${familyName}" deleted successfully.` });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

router.get('/pk/active', (req: Request, res: Response) => {
  const activeRoomsWithPk = Array.from(dbStore.rooms.values()).filter(r => r.pkState?.active);
  return res.json({ success: true, data: activeRoomsWithPk });
});

router.post('/rooms/:id/pk/start', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
    const { opponentRoomId, durationSeconds = 300 } = req.body;
    const battle = RoomService.startPkBattle(req.params.id, opponentRoomId, Number(durationSeconds));
    return res.status(201).json({ success: true, data: battle });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.post('/rooms/:id/pk/score', (req: Request, res: Response) => {
  try {
    const { battleId, roomAAdd = 0, roomBAdd = 0 } = req.body;
    const battle = RoomService.updatePkScore(battleId, Number(roomAAdd), Number(roomBAdd));
    return res.json({ success: true, data: battle });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.post('/rooms/:id/music', (req: Request, res: Response) => {
  try {
    const { title, artist, isPlaying } = req.body;
    const room = RoomService.toggleMusic(req.params.id, title, artist, isPlaying);
    return res.json({ success: true, data: room });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

// ==========================================
// 5.5 MESSAGING & NOTIFICATIONS
// ==========================================

router.get('/messages/private', (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
  const { peerId } = req.query;
  if (!peerId) return res.status(400).json({ success: false, error: 'peerId required' });
  const msgs = MessageService.getPrivateMessages(user.id, peerId as string);
  return res.json({ success: true, data: msgs });
});

router.post('/messages/private', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
    const { receiverId, content, type = 'text' } = req.body;
    const msg = MessageService.sendPrivateMessage(user.id, receiverId, content, type);
    return res.status(201).json({ success: true, data: msg });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.get('/messages/conversations', (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
  return res.json({ success: true, data: MessageService.getConversationsList(user.id) });
});

router.get('/notifications', (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
  return res.json({ success: true, data: NotificationService.getUserNotifications(user.id) });
});

router.post('/notifications/read', (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
  const { notificationId } = req.body;
  const list = NotificationService.markAsRead(user.id, notificationId);
  return res.json({ success: true, data: list });
});

router.post('/notifications/broadcast', (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!user || !PermissionService.hasRoleOrHigher(user.role, 'admin')) {
    return res.status(403).json({ success: false, error: 'Requires Admin role' });
  }
  const { title, message, link } = req.body;
  const count = NotificationService.broadcastSystemNotification(title, message, link);
  return res.json({ success: true, data: { recipientCount: count } });
});

// ==========================================
// 6. ADMIN & AUDIT LOGS ENDPOINTS
// ==========================================

router.get('/', (req: Request, res: Response) => {
  return res.json({
    success: true,
    service: 'Aura Voice Chat Backend API',
    status: 'online',
    timestamp: new Date().toISOString()
  });
});

router.get('/admin', (req: Request, res: Response) => {
  return res.json({
    success: true,
    portal: 'Aura Voice Staff Admin & CEO Portal',
    status: 'active',
    stats: AdminService.getAdminStats()
  });
});

router.post('/admin/login', (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    const result = AuthService.loginWithEmailPassword(email || 'ceo@aura.com', password || 'Admin@123');
    if (!result) {
      return res.status(401).json({ success: false, error: 'Invalid admin credentials' });
    }
    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

router.get('/admin/dashboard', (req: Request, res: Response) => {
  return res.json({ success: true, data: AdminService.getAdminStats() });
});

router.get('/admin/staff', (req: Request, res: Response) => {
  const staffMembers = Array.from(dbStore.staff.values());
  return res.json({ success: true, data: staffMembers });
});

router.get('/admin/financial', (req: Request, res: Response) => {
  const txs = Array.from(dbStore.transactions.values());
  return res.json({
    success: true,
    data: {
      transactions: txs,
      packages: dbStore.rechargePackages,
      withdrawals: txs.filter(t => t.type === 'withdraw')
    }
  });
});

router.get('/admin/settings', (req: Request, res: Response) => {
  return res.json({
    success: true,
    data: {
      appName: 'Aura Voice Platform',
      version: '1.0.0',
      currency: 'Aura Coins & Diamonds',
      maintenanceMode: false,
      rbacRoles: ['ceo', 'gm', 'manager', 'super_admin', 'admin', 'bd', 'agency', 'host', 'user']
    }
  });
});

router.get('/profile', (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
  return res.json({ success: true, data: user });
});

router.all('/login', (req: Request, res: Response) => {
  const { email, password } = req.body;
  const result = AuthService.loginWithEmailPassword(email || 'ceo@aura.com', password);
  if (!result) return res.status(401).json({ success: false, error: 'Authentication failed' });
  return res.json({ success: true, data: result });
});

router.all('/register', (req: Request, res: Response) => {
  const { email, name } = req.body;
  const canonicalId = Math.floor(1000000 + Math.random() * 9000000).toString();
  const result = AuthService.simulateFirebaseAuth(canonicalId, email || `user-${Date.now()}@aura.com`, name || 'New User');
  return res.json({ success: true, data: result });
});

router.get('/admin/stats', (req: Request, res: Response) => {
  try {
    const stats = AdminService.getAdminStats();
    return res.status(200).json({ success: true, data: stats });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

router.get('/admin/users', (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!user || !PermissionService.hasRoleOrHigher(user.role, 'host')) {
    return res.status(403).json({ success: false, error: 'Permission denied' });
  }
  const seen = new Set<string>();
  const users: User[] = [];
  for (const u of dbStore.users.values()) {
    if (u && u.id && !seen.has(u.id)) {
      seen.add(u.id);
      users.push(u);
    }
  }
  return res.json({ success: true, data: users });
});

router.post('/admin/users/:id/role', (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!user || !PermissionService.hasRoleOrHigher(user.role, 'super_admin')) {
    return res.status(403).json({ success: false, error: 'Requires Super Admin or CEO permission' });
  }
  const targetUser = dbStore.users.get(req.params.id);
  if (!targetUser) return res.status(404).json({ success: false, error: 'Target user not found' });

  const { role } = req.body as { role: UserRole };
  const oldRole = targetUser.role;
  targetUser.role = role;
  dbStore.users.set(targetUser.id, targetUser);

  dbStore.recordAudit({
    action: 'STAFF_ROLE_ASSIGNED',
    module: 'staff',
    performedByUserId: user.id,
    performedByUserName: user.name,
    performedByRole: user.role,
    targetId: targetUser.id,
    targetName: targetUser.name,
    details: `Updated role from ${oldRole} to ${role}`,
    ipAddress: req.ip || '127.0.0.1'
  });

  return res.json({ success: true, data: targetUser });
});

router.post('/admin/users/:id/update-uid', (req: Request, res: Response) => {
  const user = (req as any).user;
  const userRole = user?.role || user?.staffIdentity?.role;

  const targetUser = dbStore.users.get(req.params.id);
  if (!targetUser) return res.status(404).json({ success: false, error: 'Target user not found' });

  const targetRole = targetUser.role || targetUser.staffIdentity?.role;

  // Server-side permission check layer
  const permCheck = PermissionService.canEditUserUid(userRole, targetRole);
  if (!permCheck.allowed) {
    return res.status(permCheck.status).json({ success: false, error: permCheck.error });
  }

  const { newUid, confirmUid, reason } = req.body;

  // Requirement 5: Empty check
  if (!newUid || typeof newUid !== 'string' || !newUid.trim()) {
    return res.status(400).json({ success: false, error: 'User UID cannot be empty.' });
  }

  const trimmedUid = newUid.trim();

  // Requirement 5: Confirm match check
  if (confirmUid !== undefined && confirmUid !== null && String(confirmUid).trim() !== trimmedUid) {
    return res.status(400).json({ success: false, error: 'New User UID and Confirm User UID do not match.' });
  }

  // Requirement 5: Format validation (1-20 alphanumeric characters, underscores, or hyphens)
  const uidRegex = /^[a-zA-Z0-9_-]{1,20}$/;
  if (!uidRegex.test(trimmedUid)) {
    return res.status(400).json({
      success: false,
      error: 'Invalid User UID format. User UID must be 1 to 20 alphanumeric characters, underscores, or hyphens.'
    });
  }

  // Requirement 5: Uniqueness check across all users
  const existingWithUid = Array.from(dbStore.users.values()).find(
    u => u.uid === trimmedUid && u.id !== targetUser.id
  );
  if (existingWithUid) {
    return res.status(400).json({
      success: false,
      error: `User UID [${trimmedUid}] is already assigned to user "${existingWithUid.name}" (ID: ${existingWithUid.id}). Update rejected.`
    });
  }

  // Requirement 6: DATA INTEGRITY
  // The internal account UUID (targetUser.id) MUST NEVER change.
  // Do NOT touch coins, diamonds, vipLevel, familyId, rooms, referrals, history.
  // Only update the public/display User UID (targetUser.uid).
  const oldUid = targetUser.uid;
  targetUser.uid = trimmedUid;
  targetUser.nigoId = trimmedUid;

  dbStore.users.set(targetUser.id, targetUser);

  // Synchronize user's Voice Room ID to be the same as user's profile ID (UID)
  // CRITICAL: Clone room entries array to avoid infinite loop when modifying dbStore.rooms
  const roomEntries = Array.from(dbStore.rooms.entries());
  for (const [currentKey, room] of roomEntries) {
    if (
      room.hostId === targetUser.id || 
      room.hostUid === oldUid || 
      room.id === oldUid || 
      room.id === `room-${oldUid}`
    ) {
      if (oldUid && oldUid !== trimmedUid) {
        dbStore.rooms.delete(oldUid);
        dbStore.rooms.delete(`room-${oldUid}`);
      }
      dbStore.rooms.delete(currentKey);
      room.id = trimmedUid;
      room.hostUid = trimmedUid;
      room.hostName = targetUser.name;
      room.hostAvatar = targetUser.avatar;
      if (targetUser.frame) room.hostFrame = targetUser.frame;
      dbStore.rooms.set(trimmedUid, room);
    }
  }

  // Persist asynchronously
  dbStore.persistUser(targetUser).catch(() => {});

  // Requirement 9: IMMUTABLE AUDIT LOG
  const execStaffId = user.staffIdentity?.staffId || user.id;
  dbStore.recordAudit({
    action: 'USER_UID_UPDATED',
    module: 'staff',
    performedByUserId: user.id, // staff internal UUID
    performedByUserName: user.name,
    performedByRole: userRole as UserRole, // changed by role
    targetId: targetUser.id, // target user internal UUID
    targetName: targetUser.name,
    oldUid,
    newUid: trimmedUid,
    reason: reason || '',
    details: `${userRole.toUpperCase()} (${user.name}, Staff ID: ${execStaffId}) modified UID for target user [${targetUser.name}] (UUID: ${targetUser.id}) from [${oldUid}] to [${trimmedUid}]${reason ? `. Reason: ${reason}` : ''}`,
    ipAddress: req.ip || '127.0.0.1'
  });

  return res.json({ success: true, data: targetUser });
});

router.post('/admin/users/:id/update', (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!user || !PermissionService.hasRoleOrHigher(user.role, 'super_admin')) {
    return res.status(403).json({ success: false, error: 'Requires Super Admin or CEO permission' });
  }
  const targetUser = dbStore.users.get(req.params.id);
  if (!targetUser) return res.status(404).json({ success: false, error: 'Target user not found' });

  const { name, email, role, vipLevel, coins, diamonds, avatar, bio, country, uid, gender, phone, sendingLevel, receivingLevel } = req.body;

  if (uid !== undefined && uid !== targetUser.uid) {
    const userRole = user?.role || user?.staffIdentity?.role;
    const targetRole = targetUser.role || targetUser.staffIdentity?.role;
    const permCheck = PermissionService.canEditUserUid(userRole, targetRole);
    if (!permCheck.allowed) {
      return res.status(permCheck.status).json({ success: false, error: permCheck.error });
    }
    const trimmedUid = String(uid).trim();
    if (!trimmedUid) {
      return res.status(400).json({ success: false, error: 'User ID cannot be empty' });
    }
    const uidRegex = /^[a-zA-Z0-9_-]{1,20}$/;
    if (!uidRegex.test(trimmedUid)) {
      return res.status(400).json({ success: false, error: 'User UID must be 1 to 20 alphanumeric characters, underscores, or hyphens.' });
    }
    const existingWithUid = Array.from(dbStore.users.values()).find(u => u.uid === trimmedUid && u.id !== targetUser.id);
    if (existingWithUid) {
      return res.status(400).json({ success: false, error: `User ID [${trimmedUid}] is already assigned to another user (${existingWithUid.name}).` });
    }
    const oldUid = targetUser.uid;
    targetUser.uid = trimmedUid;

    const execStaffId = user.staffIdentity?.staffId || user.id || user.uid;
    dbStore.recordAudit({
      action: 'USER_UID_UPDATED',
      module: 'staff',
      performedByUserId: user.id,
      performedByUserName: user.name,
      performedByRole: user.role,
      targetId: targetUser.id,
      targetName: targetUser.name,
      details: `${user.role.toUpperCase()} (${user.name}, Staff ID: ${execStaffId}) modified User ID for user [${targetUser.name}] (internal ID: ${targetUser.id}) from [${oldUid}] to [${trimmedUid}].`,
      ipAddress: req.ip || '127.0.0.1'
    });
  }

  if (name !== undefined) targetUser.name = name;
  if (email !== undefined) targetUser.email = email;
  if (gender !== undefined) targetUser.gender = gender;
  if (phone !== undefined) targetUser.phone = phone;
  if (role !== undefined) targetUser.role = role;
  if (vipLevel !== undefined) targetUser.vipLevel = vipLevel;
  if (coins !== undefined) targetUser.coins = Number(coins);
  if (diamonds !== undefined) targetUser.diamonds = Number(diamonds);
  if (sendingLevel !== undefined) targetUser.sendingLevel = Number(sendingLevel);
  if (receivingLevel !== undefined) targetUser.receivingLevel = Number(receivingLevel);
  if (avatar !== undefined) targetUser.avatar = avatar;
  if (bio !== undefined) targetUser.bio = bio;
  if (country !== undefined) targetUser.country = country;
  if (req.body.countryFlag !== undefined) targetUser.countryFlag = req.body.countryFlag;
  if (req.body.uid !== undefined && req.body.uid.trim()) {
    targetUser.uid = req.body.uid.trim();
    targetUser.nigoId = req.body.uid.trim();
  }
  if (req.body.level !== undefined) targetUser.level = Number(req.body.level);

  dbStore.users.set(targetUser.id, targetUser);
  dbStore.persistUser(targetUser).catch(() => {});

  // Synchronize Voice Room ID and host details so room ID is identical to profile ID (UID)
  const roomList = Array.from(dbStore.rooms.values());
  for (const room of roomList) {
    if (room.hostId === targetUser.id || (targetUser.uid && room.hostUid === targetUser.uid)) {
      const profileId = targetUser.uid || targetUser.id;
      room.id = profileId;
      room.hostUid = profileId;
      room.hostName = targetUser.name;
      room.hostAvatar = targetUser.avatar;
      if (targetUser.frame) room.hostFrame = targetUser.frame;
      dbStore.rooms.set(room.id, room);
    }
  }
  if (targetUser.id === '2383452') {
    const ceoStaff = dbStore.staff.get('stf-1');
    if (ceoStaff) {
      ceoStaff.name = targetUser.name;
      if (targetUser.email) ceoStaff.email = targetUser.email;
    }
  }

  dbStore.recordAudit({
    action: 'USER_ACCOUNT_UPDATED',
    module: 'staff',
    performedByUserId: user.id,
    performedByUserName: user.name,
    performedByRole: user.role,
    targetId: targetUser.id,
    targetName: targetUser.name,
    details: `Updated user account details for ${targetUser.name} (${targetUser.email})`,
    ipAddress: req.ip || '127.0.0.1'
  });

  dbStore.persistUser(targetUser).catch(() => {});

  return res.json({ success: true, data: targetUser });
});

router.post('/admin/users/:id/vip', (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!user || !PermissionService.hasRoleOrHigher(user.role, 'admin')) {
    return res.status(403).json({ success: false, error: 'Requires Admin permission or higher' });
  }
  const targetUser = dbStore.users.get(req.params.id);
  if (!targetUser) return res.status(404).json({ success: false, error: 'Target user not found' });

  const { action, level, durationDays = 30 } = req.body;
  if (!action || !['assign', 'remove', 'extend'].includes(action)) {
    return res.status(400).json({ success: false, error: 'Invalid action. Must be assign, remove, or extend' });
  }

  const oldVip = targetUser.vipLevel;
  const oldExpiry = targetUser.vipExpiry;

  if (action === 'assign') {
    targetUser.vipLevel = (level === 'svip' ? 'svip' : 'vip');
    const expDate = new Date();
    expDate.setDate(expDate.getDate() + Number(durationDays));
    targetUser.vipExpiry = expDate.toISOString();
  } else if (action === 'extend') {
    const currentExpiry = targetUser.vipExpiry ? new Date(targetUser.vipExpiry) : new Date();
    const baseDate = currentExpiry.getTime() > Date.now() ? currentExpiry : new Date();
    baseDate.setDate(baseDate.getDate() + Number(durationDays));
    targetUser.vipExpiry = baseDate.toISOString();
    if (level) targetUser.vipLevel = level;
  } else if (action === 'remove') {
    targetUser.vipLevel = 'none';
    delete targetUser.vipExpiry;
  }

  dbStore.users.set(targetUser.id, targetUser);

  dbStore.recordAudit({
    action: 'USER_VIP_MODIFIED',
    module: 'staff',
    performedByUserId: user.id,
    performedByUserName: user.name,
    performedByRole: user.role,
    targetId: targetUser.id,
    targetName: targetUser.name,
    details: `Staff ${user.name} (${user.role}) performed VIP action [${action}] on ${targetUser.name}. Previous: ${oldVip} (${oldExpiry || 'no expiry'}) -> New: ${targetUser.vipLevel} (${targetUser.vipExpiry || 'no expiry'}).`,
    ipAddress: req.ip || '127.0.0.1'
  });

  return res.json({ success: true, data: targetUser });
});

// ==========================================
// VIP / SVIP / FRAME MANAGEMENT ENDPOINTS
// ==========================================

const checkVipAssignmentAuth = (user: any) => {
  if (!user) return false;
  const allowed = ['ceo', 'gm', 'manager', 'super_admin'];
  return allowed.includes(user.role);
};

router.get('/admin/vip/assignments', (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!checkVipAssignmentAuth(user)) {
    return res.status(403).json({ success: false, error: '⛔ PERMISSION DENIED: Role unauthorized to view VIP/SVIP/Frame assignments' });
  }
  const list = Array.from(dbStore.benefitAssignments.values()).sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
  return res.json({ success: true, data: list });
});

router.post('/admin/vip/assign', (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!checkVipAssignmentAuth(user)) {
    return res.status(403).json({ success: false, error: '⛔ PERMISSION DENIED: Role unauthorized to assign VIP benefits' });
  }

  const { targetUserId, targetUid, level = 'VIP 1', durationDays = 30, assignmentMode = 'free_grant', reason } = req.body;
  let targetUser = targetUserId ? dbStore.users.get(targetUserId) : null;
  if (!targetUser && targetUid) {
    targetUser = Array.from(dbStore.users.values()).find(u => u.uid === targetUid || u.id === targetUid);
  }
  if (!targetUser) return res.status(404).json({ success: false, error: 'Target user not found' });

  const days = Number(durationDays) || 30;
  const expDate = new Date();
  expDate.setDate(expDate.getDate() + days);
  const expiresAt = expDate.toISOString();

  targetUser.vipLevel = 'vip';
  targetUser.vipExpiry = expiresAt;

  if (!targetUser.badges.some(b => b.name.includes('VIP'))) {
    targetUser.badges.push({
      id: `bdg-vip-${Date.now()}`,
      name: `${level} Privilege`,
      icon: '👑',
      description: `Granted ${level} by ${user.name} (${user.role.toUpperCase()})`,
      acquiredAt: new Date().toISOString()
    });
  }

  dbStore.users.set(targetUser.id, targetUser);

  const recordId = `assign-vip-${Date.now()}`;
  const record: BenefitAssignmentRecord = {
    id: recordId,
    targetUserId: targetUser.id,
    targetUserUid: targetUser.uid,
    targetUserName: targetUser.name,
    targetUserAvatar: targetUser.avatar,
    benefitType: 'vip',
    levelOrFrameId: String(level),
    durationDays: days,
    assignedByUserId: user.id,
    assignedByUserName: user.name,
    assignedByRole: user.role,
    assignmentMode: assignmentMode === 'coin_deduction' ? 'coin_deduction' : 'free_grant',
    status: 'active',
    createdAt: new Date().toISOString(),
    expiresAt,
    reason: reason || 'Admin privilege grant'
  };
  dbStore.benefitAssignments.set(record.id, record);

  dbStore.recordAudit({
    action: 'VIP_ASSIGNED',
    module: 'staff',
    performedByUserId: user.id,
    performedByUserName: user.name,
    performedByRole: user.role,
    targetId: targetUser.id,
    targetName: targetUser.name,
    details: `${user.name} (${user.role.toUpperCase()}) assigned ${level} to ${targetUser.name} (${targetUser.uid}) for ${days} days. Expiry: ${expiresAt}`,
    ipAddress: req.ip || '127.0.0.1'
  });

  return res.json({ success: true, data: { user: targetUser, record } });
});

router.post('/admin/vip/revoke', (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!checkVipAssignmentAuth(user)) {
    return res.status(403).json({ success: false, error: '⛔ PERMISSION DENIED: Role unauthorized to revoke VIP benefits' });
  }

  const { targetUserId, targetUid, reason } = req.body;
  let targetUser = targetUserId ? dbStore.users.get(targetUserId) : null;
  if (!targetUser && targetUid) {
    targetUser = Array.from(dbStore.users.values()).find(u => u.uid === targetUid || u.id === targetUid);
  }
  if (!targetUser) return res.status(404).json({ success: false, error: 'Target user not found' });

  targetUser.vipLevel = 'none';
  delete targetUser.vipExpiry;
  dbStore.users.set(targetUser.id, targetUser);

  Array.from(dbStore.benefitAssignments.values())
    .filter(a => a.targetUserId === targetUser.id && a.benefitType === 'vip' && a.status === 'active')
    .forEach(a => {
      a.status = 'revoked';
      dbStore.benefitAssignments.set(a.id, a);
    });

  dbStore.recordAudit({
    action: 'VIP_REVOKED',
    module: 'staff',
    performedByUserId: user.id,
    performedByUserName: user.name,
    performedByRole: user.role,
    targetId: targetUser.id,
    targetName: targetUser.name,
    details: `${user.name} (${user.role.toUpperCase()}) revoked VIP status from ${targetUser.name} (${targetUser.uid}). Reason: ${reason || 'Admin revoke'}`,
    ipAddress: req.ip || '127.0.0.1'
  });

  return res.json({ success: true, data: targetUser });
});

router.post('/admin/svip/assign', (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!checkVipAssignmentAuth(user)) {
    return res.status(403).json({ success: false, error: '⛔ PERMISSION DENIED: Role unauthorized to assign SVIP benefits' });
  }

  const { targetUserId, targetUid, level = 'SVIP 1', durationDays = 30, assignmentMode = 'free_grant', reason } = req.body;
  let targetUser = targetUserId ? dbStore.users.get(targetUserId) : null;
  if (!targetUser && targetUid) {
    targetUser = Array.from(dbStore.users.values()).find(u => u.uid === targetUid || u.id === targetUid);
  }
  if (!targetUser) return res.status(404).json({ success: false, error: 'Target user not found' });

  const days = Number(durationDays) || 30;
  const expDate = new Date();
  expDate.setDate(expDate.getDate() + days);
  const expiresAt = expDate.toISOString();

  targetUser.vipLevel = 'svip';
  targetUser.vipExpiry = expiresAt;

  dbStore.users.set(targetUser.id, targetUser);

  const recordId = `assign-svip-${Date.now()}`;
  const record: BenefitAssignmentRecord = {
    id: recordId,
    targetUserId: targetUser.id,
    targetUserUid: targetUser.uid,
    targetUserName: targetUser.name,
    targetUserAvatar: targetUser.avatar,
    benefitType: 'svip',
    levelOrFrameId: String(level),
    durationDays: days,
    assignedByUserId: user.id,
    assignedByUserName: user.name,
    assignedByRole: user.role,
    assignmentMode: assignmentMode === 'coin_deduction' ? 'coin_deduction' : 'free_grant',
    status: 'active',
    createdAt: new Date().toISOString(),
    expiresAt,
    reason: reason || 'Admin SVIP grant'
  };
  dbStore.benefitAssignments.set(record.id, record);

  dbStore.recordAudit({
    action: 'SVIP_ASSIGNED',
    module: 'staff',
    performedByUserId: user.id,
    performedByUserName: user.name,
    performedByRole: user.role,
    targetId: targetUser.id,
    targetName: targetUser.name,
    details: `${user.name} (${user.role.toUpperCase()}) assigned ${level} to ${targetUser.name} (${targetUser.uid}) for ${days} days. Expiry: ${expiresAt}`,
    ipAddress: req.ip || '127.0.0.1'
  });

  return res.json({ success: true, data: { user: targetUser, record } });
});

router.post('/admin/svip/revoke', (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!checkVipAssignmentAuth(user)) {
    return res.status(403).json({ success: false, error: '⛔ PERMISSION DENIED: Role unauthorized to revoke SVIP benefits' });
  }

  const { targetUserId, targetUid, reason } = req.body;
  let targetUser = targetUserId ? dbStore.users.get(targetUserId) : null;
  if (!targetUser && targetUid) {
    targetUser = Array.from(dbStore.users.values()).find(u => u.uid === targetUid || u.id === targetUid);
  }
  if (!targetUser) return res.status(404).json({ success: false, error: 'Target user not found' });

  targetUser.vipLevel = 'none';
  delete targetUser.vipExpiry;
  dbStore.users.set(targetUser.id, targetUser);

  Array.from(dbStore.benefitAssignments.values())
    .filter(a => a.targetUserId === targetUser.id && a.benefitType === 'svip' && a.status === 'active')
    .forEach(a => {
      a.status = 'revoked';
      dbStore.benefitAssignments.set(a.id, a);
    });

  dbStore.recordAudit({
    action: 'SVIP_REVOKED',
    module: 'staff',
    performedByUserId: user.id,
    performedByUserName: user.name,
    performedByRole: user.role,
    targetId: targetUser.id,
    targetName: targetUser.name,
    details: `${user.name} (${user.role.toUpperCase()}) revoked SVIP status from ${targetUser.name} (${targetUser.uid}). Reason: ${reason || 'Admin revoke'}`,
    ipAddress: req.ip || '127.0.0.1'
  });

  return res.json({ success: true, data: targetUser });
});

router.post('/admin/frame/assign', (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!checkVipAssignmentAuth(user)) {
    return res.status(403).json({ success: false, error: '⛔ PERMISSION DENIED: Role unauthorized to assign profile frames' });
  }

  const { targetUserId, targetUid, frameId = '👑 Golden Monarch', durationDays = 30, assignmentMode = 'free_grant', reason } = req.body;
  let targetUser = targetUserId ? dbStore.users.get(targetUserId) : null;
  if (!targetUser && targetUid) {
    targetUser = Array.from(dbStore.users.values()).find(u => u.uid === targetUid || u.id === targetUid);
  }
  if (!targetUser) return res.status(404).json({ success: false, error: 'Target user not found' });

  const isPermanent = durationDays === 'permanent' || Number(durationDays) === 0 || durationDays === '0';
  let expiresAt: string | 'permanent' = 'permanent';
  if (!isPermanent) {
    const days = Number(durationDays) || 30;
    const expDate = new Date();
    expDate.setDate(expDate.getDate() + days);
    expiresAt = expDate.toISOString();
  }

  targetUser.frame = String(frameId);
  dbStore.users.set(targetUser.id, targetUser);

  const recordId = `assign-frame-${Date.now()}`;
  const record: BenefitAssignmentRecord = {
    id: recordId,
    targetUserId: targetUser.id,
    targetUserUid: targetUser.uid,
    targetUserName: targetUser.name,
    targetUserAvatar: targetUser.avatar,
    benefitType: 'frame',
    levelOrFrameId: String(frameId),
    durationDays: isPermanent ? 'permanent' : Number(durationDays),
    assignedByUserId: user.id,
    assignedByUserName: user.name,
    assignedByRole: user.role,
    assignmentMode: assignmentMode === 'coin_deduction' ? 'coin_deduction' : 'free_grant',
    status: 'active',
    createdAt: new Date().toISOString(),
    expiresAt,
    reason: reason || 'Admin frame grant'
  };
  dbStore.benefitAssignments.set(record.id, record);

  dbStore.recordAudit({
    action: 'FRAME_ASSIGNED',
    module: 'staff',
    performedByUserId: user.id,
    performedByUserName: user.name,
    performedByRole: user.role,
    targetId: targetUser.id,
    targetName: targetUser.name,
    details: `${user.name} (${user.role.toUpperCase()}) assigned Profile Frame [${frameId}] to ${targetUser.name} (${targetUser.uid}). Duration: ${isPermanent ? 'Permanent' : durationDays + ' days'}`,
    ipAddress: req.ip || '127.0.0.1'
  });

  return res.json({ success: true, data: { user: targetUser, record } });
});

router.post('/admin/frame/revoke', (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!checkVipAssignmentAuth(user)) {
    return res.status(403).json({ success: false, error: '⛔ PERMISSION DENIED: Role unauthorized to revoke profile frames' });
  }

  const { targetUserId, targetUid, reason } = req.body;
  let targetUser = targetUserId ? dbStore.users.get(targetUserId) : null;
  if (!targetUser && targetUid) {
    targetUser = Array.from(dbStore.users.values()).find(u => u.uid === targetUid || u.id === targetUid);
  }
  if (!targetUser) return res.status(404).json({ success: false, error: 'Target user not found' });

  delete targetUser.frame;
  dbStore.users.set(targetUser.id, targetUser);

  Array.from(dbStore.benefitAssignments.values())
    .filter(a => a.targetUserId === targetUser.id && a.benefitType === 'frame' && a.status === 'active')
    .forEach(a => {
      a.status = 'revoked';
      dbStore.benefitAssignments.set(a.id, a);
    });

  dbStore.recordAudit({
    action: 'FRAME_REVOKED',
    module: 'staff',
    performedByUserId: user.id,
    performedByUserName: user.name,
    performedByRole: user.role,
    targetId: targetUser.id,
    targetName: targetUser.name,
    details: `${user.name} (${user.role.toUpperCase()}) revoked Profile Frame from ${targetUser.name} (${targetUser.uid}). Reason: ${reason || 'Admin revoke'}`,
    ipAddress: req.ip || '127.0.0.1'
  });

  return res.json({ success: true, data: targetUser });
});

router.post('/admin/staff/identity/assign', (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!user) {
    return res.status(401).json({ success: false, error: 'Unauthorized' });
  }

  // Security Check: Only CEO, or GM/Manager with CEO permission can assign identities
  const isCeo = user.role === 'ceo';
  const isAuthorizedGmOrManager = (user.role === 'gm' || user.role === 'manager') && (user.canAssignIdentity === true || user.permissions?.includes('staff:assign_identity'));

  if (!isCeo && !isAuthorizedGmOrManager) {
    return res.status(403).json({ 
      success: false, 
      error: '⛔ PERMISSION DENIED: Only the CEO (or authorized General Manager / Manager) can assign staff identities.' 
    });
  }

  const { userId, role, roles, positions, title, staffId, staffLevel, isVerified, department, activeStatus, notes } = req.body;
  if (!userId) {
    return res.status(400).json({ success: false, error: 'userId is required' });
  }

  const targetUser = dbStore.users.get(userId);
  if (!targetUser) {
    return res.status(404).json({ success: false, error: 'Target user not found' });
  }

  // Parse raw roles array: support `roles`, `positions`, or legacy single `role`
  let incomingRoles: string[] = [];
  if (Array.isArray(roles) && roles.length > 0) {
    incomingRoles = roles;
  } else if (Array.isArray(positions) && positions.length > 0) {
    incomingRoles = positions;
  } else if (role) {
    incomingRoles = [role];
  } else {
    return res.status(400).json({ success: false, error: 'At least one identity position / role is required' });
  }

  // Sanitize and deduplicate
  const finalRoles = Array.from(new Set(incomingRoles.filter(Boolean))) as UserRole[];
  if (finalRoles.length === 0) {
    finalRoles.push('official_staff');
  }

  const primaryRole = finalRoles[0];
  const primaryConfig = STAFF_IDENTITY_CONFIG[primaryRole] || STAFF_IDENTITY_CONFIG['official_staff'];

  const resolvedTitles = finalRoles.map(r => (STAFF_IDENTITY_CONFIG[r]?.name || STAFF_IDENTITY_CONFIG[r]?.title || r));
  const resolvedBadges = finalRoles.map(r => (STAFF_IDENTITY_CONFIG[r]?.badge || `🌟 ${r}`));
  const joinedTitle = title || resolvedTitles.join(' • ');
  const joinedBadge = resolvedBadges.join(' • ');

  const newStaffId = staffId || `${primaryConfig.defaultStaffIdPrefix}${targetUser.uid || targetUser.id}`;
  const newStaffLevel = Number(staffLevel) || (primaryRole === 'ceo' ? 10 : primaryRole === 'gm' ? 8 : primaryRole === 'super_admin' ? 7 : 5);
  const newDepartment = department || primaryConfig.department;
  const newVerified = isVerified !== undefined ? Boolean(isVerified) : true;
  const newActiveStatus = activeStatus || 'Active';

  // Track previous identities for audit log
  const prevRoles: string[] = targetUser.staffIdentity?.roles && targetUser.staffIdentity.roles.length > 0
    ? targetUser.staffIdentity.roles
    : (targetUser.staffIdentity?.role ? [targetUser.staffIdentity.role] : [targetUser.role]);
  const prevDisplay = prevRoles.map(r => (STAFF_IDENTITY_CONFIG[r]?.name || r)).join(' • ');
  const newDisplay = finalRoles.map(r => (STAFF_IDENTITY_CONFIG[r]?.name || r)).join(' • ');

  const newIdentity: StaffIdentity = {
    role: primaryRole,
    roles: finalRoles,
    positions: finalRoles,
    badge: joinedBadge,
    badges: resolvedBadges,
    title: joinedTitle,
    titles: resolvedTitles,
    frame: targetUser.frame || primaryConfig.frame,
    background: targetUser.background || primaryConfig.background,
    staffId: newStaffId,
    staffLevel: newStaffLevel,
    isVerified: newVerified,
    department: newDepartment,
    joinedDate: targetUser.createdAt ? new Date(targetUser.createdAt).toISOString().split('T')[0] : '2025-01-01',
    activeStatus: newActiveStatus as any,
    assignedBy: user.name,
    assignedAt: new Date().toISOString(),
    notes: notes || undefined
  };

  // Update target user - Separate Identity Display from System Permissions (Requirement 11)
  targetUser.staffIdentity = newIdentity;

  if (!targetUser.identityHistory) {
    targetUser.identityHistory = [];
  }
  targetUser.identityHistory.unshift({
    id: `hist-${Date.now()}`,
    role: primaryRole,
    roles: finalRoles,
    title: joinedTitle,
    titles: resolvedTitles,
    action: targetUser.staffIdentity ? 'updated' : 'assigned',
    assignedBy: `${user.name} (${user.role.toUpperCase()})`,
    assignedAt: new Date().toISOString(),
    previousIdentities: prevRoles,
    newIdentities: finalRoles,
    notes: notes || `Assigned identities: ${newDisplay}`
  });

  dbStore.users.set(targetUser.id, targetUser);

  // Sync / Create StaffMember entry in dbStore.staff
  let staffEntry = Array.from(dbStore.staff.values()).find(s => s.userId === targetUser.id);
  if (!staffEntry) {
    staffEntry = {
      id: `stf-${Date.now()}`,
      userId: targetUser.id,
      name: targetUser.name,
      email: targetUser.email,
      role: primaryRole,
      staffIdentity: newIdentity,
      permissions: ['staff:view', 'rooms:moderate'],
      assignedBy: user.name,
      assignedAt: new Date().toISOString(),
      status: 'active'
    };
  } else {
    staffEntry.staffIdentity = newIdentity;
    if (staffEntry.role === 'user') staffEntry.role = primaryRole;
  }
  dbStore.staff.set(staffEntry.id, staffEntry);

  // Record Audit Log (Requirement 13)
  dbStore.recordAudit({
    action: 'STAFF_IDENTITY_ASSIGNED',
    module: 'staff',
    performedByUserId: user.id,
    performedByUserName: user.name,
    performedByRole: user.role,
    targetId: targetUser.id,
    targetName: targetUser.name,
    details: `Updated staff identities for ${targetUser.name} (${targetUser.uid}): [${prevDisplay}] → [${newDisplay}]. Staff ID: ${newStaffId}. Notes: ${notes || 'Staff identity assignment'}`,
    ipAddress: req.ip || '127.0.0.1'
  });

  return res.json({ success: true, data: targetUser });
});

router.post('/admin/staff/identity/remove', (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!user) {
    return res.status(401).json({ success: false, error: 'Unauthorized' });
  }

  const isCeo = user.role === 'ceo';
  const isAuthorizedGmOrManager = (user.role === 'gm' || user.role === 'manager') && (user.canAssignIdentity === true || user.permissions?.includes('staff:assign_identity'));

  if (!isCeo && !isAuthorizedGmOrManager) {
    return res.status(403).json({ 
      success: false, 
      error: '⛔ PERMISSION DENIED: Only the CEO (or authorized GM / Manager) can remove staff identities.' 
    });
  }

  const { userId, notes } = req.body;
  const targetUser = dbStore.users.get(userId);
  if (!targetUser) {
    return res.status(404).json({ success: false, error: 'Target user not found' });
  }

  const prevRoles: string[] = targetUser.staffIdentity?.roles && targetUser.staffIdentity.roles.length > 0
    ? targetUser.staffIdentity.roles
    : (targetUser.staffIdentity?.role ? [targetUser.staffIdentity.role] : [targetUser.role]);
  const previousTitle = targetUser.staffIdentity?.title || prevRoles.join(' • ') || targetUser.role;

  delete targetUser.staffIdentity;
  if (targetUser.role !== 'ceo') {
    targetUser.role = 'user';
  }

  if (!targetUser.identityHistory) {
    targetUser.identityHistory = [];
  }
  targetUser.identityHistory.unshift({
    id: `hist-${Date.now()}`,
    role: 'user',
    roles: [],
    title: 'Regular User',
    titles: ['Regular User'],
    action: 'removed',
    assignedBy: `${user.name} (${user.role.toUpperCase()})`,
    assignedAt: new Date().toISOString(),
    previousIdentities: prevRoles,
    newIdentities: [],
    notes: notes || `Staff identity revoked`
  });

  dbStore.users.set(targetUser.id, targetUser);

  // Remove or update staff record
  const staffEntry = Array.from(dbStore.staff.values()).find(s => s.userId === targetUser.id);
  if (staffEntry) {
    staffEntry.status = 'suspended';
    delete staffEntry.staffIdentity;
    dbStore.staff.set(staffEntry.id, staffEntry);
  }

  dbStore.recordAudit({
    action: 'STAFF_IDENTITY_REMOVED',
    module: 'staff',
    performedByUserId: user.id,
    performedByUserName: user.name,
    performedByRole: user.role,
    targetId: targetUser.id,
    targetName: targetUser.name,
    details: `Revoked staff identities [${previousTitle}] from ${targetUser.name} (${targetUser.uid}). Reset role to regular user.`,
    ipAddress: req.ip || '127.0.0.1'
  });

  return res.json({ success: true, data: targetUser });
});

router.post('/admin/staff/identity/grant-permission', (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!user || user.role !== 'ceo') {
    return res.status(403).json({ success: false, error: '⛔ PERMISSION DENIED: Only the CEO can grant identity assignment permissions.' });
  }

  const { targetUserId, canAssign } = req.body;
  const targetUser = dbStore.users.get(targetUserId);
  if (!targetUser) {
    return res.status(404).json({ success: false, error: 'Target user not found' });
  }

  targetUser.canAssignIdentity = Boolean(canAssign);
  dbStore.users.set(targetUser.id, targetUser);

  const staffEntry = Array.from(dbStore.staff.values()).find(s => s.userId === targetUser.id);
  if (staffEntry) {
    staffEntry.canAssignIdentity = Boolean(canAssign);
    dbStore.staff.set(staffEntry.id, staffEntry);
  }

  dbStore.recordAudit({
    action: 'STAFF_PERMISSION_CHANGED',
    module: 'permission',
    performedByUserId: user.id,
    performedByUserName: user.name,
    performedByRole: user.role,
    targetId: targetUser.id,
    targetName: targetUser.name,
    details: `${canAssign ? 'Granted' : 'Revoked'} staff identity assignment permission for ${targetUser.name}`,
    ipAddress: req.ip || '127.0.0.1'
  });

  return res.json({ success: true, data: targetUser });
});

// ==========================================
// DYNAMIC RBAC PERMISSION MANAGEMENT SYSTEM
// ==========================================

// 1. Get full RBAC matrix metadata (modules, permissions, roles, staff overrides)
router.get('/admin/rbac/metadata', (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!user || user.role === 'user') {
    return res.status(403).json({ success: false, error: 'Unauthorized: Staff privilege required' });
  }

  const modules = Array.from(dbStore.rbacModules.values());
  const permissions = Array.from(dbStore.rbacPermissions.values());
  const roles = Array.from(dbStore.rbacRoles.values());
  const overrides = Array.from(dbStore.rbacStaffOverrides.values());

  return res.json({
    success: true,
    data: {
      modules,
      permissions,
      roles,
      overrides
    }
  });
});

// 2. Get all permissions
router.get('/admin/rbac/permissions', (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!user || user.role === 'user') {
    return res.status(403).json({ success: false, error: 'Unauthorized' });
  }
  return res.json({ success: true, data: Array.from(dbStore.rbacPermissions.values()) });
});

// 3. Create Custom Permission
router.post('/admin/rbac/permissions', async (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user || (!PermissionService.hasPermission(user.role, 'permission:manage', user.permissions, 'MANAGE', user.id) && user.role !== 'ceo')) {
      return res.status(403).json({ success: false, error: '⛔ PERMISSION DENIED: Requires "permission:manage" permission.' });
    }

    const { key, name, module, description, defaultLevel = 'VIEW', isCeoProtected = false } = req.body;
    if (!key || typeof key !== 'string' || !key.trim()) {
      return res.status(400).json({ success: false, error: 'Permission Key is required (e.g. events:broadcast)' });
    }
    if (!name || typeof name !== 'string' || !name.trim()) {
      return res.status(400).json({ success: false, error: 'Permission Display Name is required' });
    }
    if (!module || typeof module !== 'string' || !module.trim()) {
      return res.status(400).json({ success: false, error: 'Target Module is required' });
    }

    const cleanKey = key.trim().toLowerCase();
    if (dbStore.rbacPermissions.has(cleanKey)) {
      return res.status(400).json({ success: false, error: `Permission key "${cleanKey}" already exists.` });
    }

    // Ensure target module exists
    if (!dbStore.rbacModules.has(module)) {
      dbStore.rbacModules.set(module, {
        id: `mod_${module}`,
        key: module,
        name: module.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' '),
        description: `Module for ${module}`,
        isCustom: true
      });
    }

    const newPerm: SystemPermission = {
      id: `perm_${Date.now()}`,
      key: cleanKey,
      name: name.trim(),
      module: module.trim(),
      description: description ? description.trim() : `Custom permission for ${name}`,
      defaultLevel: defaultLevel as any,
      isCustom: true,
      isCeoProtected: Boolean(isCeoProtected),
      createdAt: new Date().toISOString(),
      createdBy: `${user.name} (${user.role.toUpperCase()})`
    };

    await dbStore.persistPermission(newPerm);

    // Auto-grant to CEO role
    const ceoRole = dbStore.rbacRoles.get('ceo');
    if (ceoRole) {
      ceoRole.permissions[cleanKey] = 'FULL';
      await dbStore.persistRoleConfig(ceoRole);
    }

    dbStore.recordAudit({
      action: 'PERMISSION_CREATED',
      module: 'permission',
      performedByUserId: user.id,
      performedByUserName: user.name,
      performedByRole: user.role,
      targetId: cleanKey,
      targetName: newPerm.name,
      details: `${user.name} (${user.role.toUpperCase()}) created new custom system permission [${cleanKey} - ${newPerm.name}] in module [${module}]`,
      ipAddress: req.ip || '127.0.0.1'
    });

    return res.status(201).json({ success: true, data: newPerm, message: 'Custom permission created and persisted successfully' });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Failed to create permission' });
  }
});

// 4. Create Custom Module
router.post('/admin/rbac/modules', async (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user || (!PermissionService.hasPermission(user.role, 'permission:manage', user.permissions, 'MANAGE', user.id) && user.role !== 'ceo')) {
      return res.status(403).json({ success: false, error: '⛔ PERMISSION DENIED: Requires "permission:manage" permission.' });
    }

    const { key, name, description, icon = 'Layers' } = req.body;
    if (!key || typeof key !== 'string' || !key.trim()) {
      return res.status(400).json({ success: false, error: 'Module Key is required (e.g. live_games)' });
    }
    if (!name || typeof name !== 'string' || !name.trim()) {
      return res.status(400).json({ success: false, error: 'Module Display Name is required' });
    }

    const cleanKey = key.trim().toLowerCase().replace(/[^a-z0-9_]/g, '_');
    if (dbStore.rbacModules.has(cleanKey)) {
      return res.status(400).json({ success: false, error: `Module "${cleanKey}" already exists.` });
    }

    const newModule: PermissionModule = {
      id: `mod_${Date.now()}`,
      key: cleanKey,
      name: name.trim(),
      description: description ? description.trim() : `Custom module ${name}`,
      icon: icon || 'Layers',
      isCustom: true
    };

    await dbStore.persistModule(newModule);

    dbStore.recordAudit({
      action: 'PERMISSION_MODULE_CREATED',
      module: 'permission',
      performedByUserId: user.id,
      performedByUserName: user.name,
      performedByRole: user.role,
      targetId: cleanKey,
      targetName: newModule.name,
      details: `${user.name} (${user.role.toUpperCase()}) created new permission module [${cleanKey} - ${newModule.name}]`,
      ipAddress: req.ip || '127.0.0.1'
    });

    return res.status(201).json({ success: true, data: newModule, message: 'Module created successfully' });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Failed to create module' });
  }
});

// 5. Get all Roles with their permissions and grant authorities
router.get('/admin/rbac/roles', (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!user || user.role === 'user') {
    return res.status(403).json({ success: false, error: 'Unauthorized' });
  }
  return res.json({ success: true, data: Array.from(dbStore.rbacRoles.values()) });
});

// 6. Get Role config
router.get('/admin/rbac/roles/:roleId', (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!user || user.role === 'user') {
    return res.status(403).json({ success: false, error: 'Unauthorized' });
  }
  const roleId = req.params.roleId as UserRole;
  const config = dbStore.rbacRoles.get(roleId) || DEFAULT_ROLE_CONFIGS[roleId];
  if (!config) {
    return res.status(404).json({ success: false, error: `Role ${roleId} not found` });
  }
  return res.json({ success: true, data: config });
});

// 7. Update Role Permissions and Role Grant Authority
router.put('/admin/rbac/roles/:roleId', async (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });

    // Enforce permission:manage or CEO
    if (user.role !== 'ceo' && !PermissionService.hasPermission(user.role, 'permission:manage', user.permissions, 'MANAGE', user.id)) {
      return res.status(403).json({
        success: false,
        error: '⛔ PERMISSION DENIED: You do not possess the required "permission:manage" permission to edit role permissions.'
      });
    }

    const targetRoleId = req.params.roleId as UserRole;
    const existingConfig = dbStore.rbacRoles.get(targetRoleId) || DEFAULT_ROLE_CONFIGS[targetRoleId];
    if (!existingConfig) {
      return res.status(404).json({ success: false, error: `Role "${targetRoleId}" not found` });
    }

    // Role Hierarchy Safeguard: Non-CEO cannot edit permissions of equal or higher rank
    if (user.role !== 'ceo') {
      const execRank = ROLE_HIERARCHY[user.role as UserRole] || 0;
      const targetRank = ROLE_HIERARCHY[targetRoleId] || 0;
      if (targetRank >= execRank) {
        return res.status(403).json({
          success: false,
          error: `⛔ PERMISSION DENIED: You cannot modify permissions for role rank equal to or higher than your own (${targetRoleId.toUpperCase()}).`
        });
      }
    }

    const { permissions, canGrantRoles, description } = req.body;
    if (!permissions || typeof permissions !== 'object') {
      return res.status(400).json({ success: false, error: 'Permissions map object is required' });
    }

    // CEO Protection Safeguards:
    // If updating CEO, CEO must keep full access
    const finalPermissions = { ...permissions };
    if (targetRoleId === 'ceo') {
      finalPermissions['*'] = 'FULL';
      finalPermissions['users:edit_uid'] = 'FULL';
    } else {
      // Non-CEO cannot grant themselves or others users:edit_uid unless executor is CEO
      if (user.role !== 'ceo' && finalPermissions['users:edit_uid'] === 'FULL') {
        finalPermissions['users:edit_uid'] = existingConfig.permissions['users:edit_uid'] || 'NONE';
      }
    }

    let finalCanGrantRoles = existingConfig.canGrantRoles;
    if (Array.isArray(canGrantRoles)) {
      if (targetRoleId === 'ceo') {
        finalCanGrantRoles = ['*'];
      } else {
        // Prevent granting roles higher than the target role itself
        const targetRank = ROLE_HIERARCHY[targetRoleId] || 0;
        finalCanGrantRoles = canGrantRoles.filter(r => {
          if (r === '*') return false;
          const rRank = ROLE_HIERARCHY[r as UserRole] || 0;
          return rRank < targetRank;
        }) as UserRole[];
      }
    }

    const updatedConfig: RolePermissionConfig = {
      ...existingConfig,
      permissions: finalPermissions,
      canGrantRoles: finalCanGrantRoles,
      description: description !== undefined ? description : existingConfig.description,
      updatedAt: new Date().toISOString(),
      updatedBy: `${user.name} (${user.role.toUpperCase()})`
    };

    await dbStore.persistRoleConfig(updatedConfig);

    dbStore.recordAudit({
      action: 'ROLE_PERMISSIONS_UPDATED',
      module: 'permission',
      performedByUserId: user.id,
      performedByUserName: user.name,
      performedByRole: user.role,
      targetId: targetRoleId,
      targetName: updatedConfig.roleName,
      details: `${user.name} (${user.role.toUpperCase()}) updated dynamic permissions and grant authority for role [${updatedConfig.roleName}].`,
      ipAddress: req.ip || '127.0.0.1'
    });

    return res.json({
      success: true,
      data: updatedConfig,
      message: `Permissions for role "${updatedConfig.roleName}" saved and synchronized with database.`
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Failed to update role permissions' });
  }
});

// 8. Reset Role Permissions to Factory Default
router.post('/admin/rbac/reset/:roleId', async (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user || user.role !== 'ceo') {
      return res.status(403).json({ success: false, error: '⛔ PERMISSION DENIED: Only the CEO can reset role configurations to factory defaults.' });
    }

    const targetRoleId = req.params.roleId as UserRole;
    const freshConfig = await dbStore.resetRoleConfig(targetRoleId, `${user.name} (CEO)`);

    dbStore.recordAudit({
      action: 'ROLE_PERMISSIONS_RESET',
      module: 'permission',
      performedByUserId: user.id,
      performedByUserName: user.name,
      performedByRole: user.role,
      targetId: targetRoleId,
      targetName: freshConfig.roleName,
      details: `${user.name} reset permissions for role [${freshConfig.roleName}] to platform factory defaults.`,
      ipAddress: req.ip || '127.0.0.1'
    });

    return res.json({ success: true, data: freshConfig, message: `Role ${freshConfig.roleName} reset to factory defaults.` });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Failed to reset role' });
  }
});

// 9. Get Effective Permissions & Overrides for a specific staff member
router.get('/admin/rbac/staff/:userId', (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!user || user.role === 'user') {
    return res.status(403).json({ success: false, error: 'Unauthorized' });
  }

  const targetUserId = req.params.userId;
  const targetUser = dbStore.users.get(targetUserId);
  if (!targetUser) {
    return res.status(404).json({ success: false, error: 'User not found' });
  }

  const userRole = (targetUser.staffIdentity?.role || targetUser.role) as UserRole;
  const effective = PermissionService.getEffectivePermissions(userRole, targetUserId);

  return res.json({
    success: true,
    data: {
      targetUser: {
        id: targetUser.id,
        uid: targetUser.uid,
        name: targetUser.name,
        avatar: targetUser.avatar,
        role: userRole,
        staffIdentity: targetUser.staffIdentity
      },
      ...effective
    }
  });
});

// 10. Update Staff Permission Overrides
router.put('/admin/rbac/staff/:userId', async (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });

    if (user.role !== 'ceo' && !PermissionService.hasPermission(user.role, 'permission:manage', user.permissions, 'MANAGE', user.id)) {
      return res.status(403).json({
        success: false,
        error: '⛔ PERMISSION DENIED: You do not possess the required "permission:manage" permission.'
      });
    }

    const targetUserId = req.params.userId;
    const targetUser = dbStore.users.get(targetUserId);
    if (!targetUser) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }

    // Non-CEO cannot override CEO permissions
    if (targetUser.role === 'ceo' || targetUser.staffIdentity?.role === 'ceo') {
      return res.status(403).json({ success: false, error: '⛔ PERMISSION DENIED: Cannot alter permissions for CEO account.' });
    }

    const { overrides, notes } = req.body;
    if (!overrides || typeof overrides !== 'object') {
      return res.status(400).json({ success: false, error: 'Overrides map object is required' });
    }

    const targetRole = (targetUser.staffIdentity?.role || targetUser.role) as UserRole;

    const overrideObj: StaffPermissionOverride = {
      id: `ovr_${targetUserId}`,
      userId: targetUserId,
      userName: targetUser.name,
      userUid: targetUser.uid,
      role: targetRole,
      overrides,
      notes: notes || `Custom overrides set by ${user.name}`,
      updatedAt: new Date().toISOString(),
      updatedBy: `${user.name} (${user.role.toUpperCase()})`
    };

    await dbStore.persistStaffOverride(overrideObj);

    dbStore.recordAudit({
      action: 'STAFF_OVERRIDES_UPDATED',
      module: 'permission',
      performedByUserId: user.id,
      performedByUserName: user.name,
      performedByRole: user.role,
      targetId: targetUserId,
      targetName: targetUser.name,
      details: `${user.name} (${user.role.toUpperCase()}) modified custom permission overrides for staff member [${targetUser.name}] (UID: ${targetUser.uid}). Count: ${Object.keys(overrides).length}`,
      ipAddress: req.ip || '127.0.0.1'
    });

    const effective = PermissionService.getEffectivePermissions(targetRole, targetUserId);

    return res.json({
      success: true,
      data: {
        override: overrideObj,
        effective
      },
      message: `Overrides for ${targetUser.name} updated successfully.`
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Failed to update staff overrides' });
  }
});

// 11. Clear Staff Overrides
router.delete('/admin/rbac/staff/:userId/overrides', async (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });

    if (user.role !== 'ceo' && !PermissionService.hasPermission(user.role, 'permission:manage', user.permissions, 'MANAGE', user.id)) {
      return res.status(403).json({
        success: false,
        error: '⛔ PERMISSION DENIED: You do not possess the required "permission:manage" permission.'
      });
    }

    const targetUserId = req.params.userId;
    const targetUser = dbStore.users.get(targetUserId);
    if (!targetUser) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }

    await dbStore.deleteStaffOverride(targetUserId);

    dbStore.recordAudit({
      action: 'STAFF_OVERRIDES_CLEARED',
      module: 'permission',
      performedByUserId: user.id,
      performedByUserName: user.name,
      performedByRole: user.role,
      targetId: targetUserId,
      targetName: targetUser.name,
      details: `${user.name} (${user.role.toUpperCase()}) cleared custom permission overrides for [${targetUser.name}]`,
      ipAddress: req.ip || '127.0.0.1'
    });

    const targetRole = (targetUser.staffIdentity?.role || targetUser.role) as UserRole;
    const effective = PermissionService.getEffectivePermissions(targetRole, targetUserId);

    return res.json({
      success: true,
      data: effective,
      message: `Custom overrides cleared for ${targetUser.name}. Staff member reverted to standard role permissions.`
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Failed to clear staff overrides' });
  }
});

router.get('/admin/audit', (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!user || !PermissionService.hasPermission(user.role, 'audit:view')) {
    return res.status(403).json({ success: false, error: 'Permission denied: audit:view required' });
  }
  const logs = Array.from(dbStore.auditLogs.values()).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  return res.json({ success: true, data: logs });
});

router.get('/admin/schema', (req: Request, res: Response) => {
  return res.json({ success: true, data: POSTGRES_TABLES_METADATA });
});

router.get('/admin/staff-activity', (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!user || !PermissionService.hasRoleOrHigher(user.role, 'admin')) {
    return res.status(403).json({ success: false, error: 'Requires Admin role' });
  }
  return res.json({ success: true, data: AdminService.getStaffActivityLogs() });
});

router.post('/reports', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });

    const { targetType, targetId, targetTitle, targetUserName, reason, details } = req.body;
    if (!reason) {
      return res.status(400).json({ success: false, error: 'Report reason is required' });
    }

    const reportId = `rep-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const newReport = {
      id: reportId,
      reporterId: user.id,
      reporterName: user.name,
      reporterUid: user.uid,
      reporterAvatar: user.avatar,
      targetType: targetType || 'room',
      targetId: targetId || 'unknown',
      targetTitle: targetTitle || undefined,
      targetUserName: targetUserName || undefined,
      reason,
      details: details || '',
      status: 'pending' as const,
      createdAt: new Date().toISOString()
    };

    dbStore.reports.set(newReport.id, newReport);

    dbStore.recordAudit({
      action: 'USER_REPORT_SUBMITTED',
      module: 'room',
      performedByUserId: user.id,
      performedByUserName: user.name,
      performedByRole: user.role,
      targetId: targetId || 'unknown',
      details: `Submitted report [${reason}] on ${targetType || 'room'} (${targetTitle || targetId}). Details: ${details || 'None'}`,
      ipAddress: req.ip || '127.0.0.1'
    });

    return res.status(201).json({ success: true, data: newReport, message: 'Report submitted successfully' });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.get('/admin/reports', (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!user || !PermissionService.hasRoleOrHigher(user.role, 'host')) {
    return res.status(403).json({ success: false, error: 'Requires Host role or higher' });
  }
  const { status } = req.query;
  return res.json({ success: true, data: AdminService.getReports(status as any) });
});

router.post('/admin/reports/moderate', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user || !PermissionService.hasRoleOrHigher(user.role, 'admin')) {
      return res.status(403).json({ success: false, error: 'Requires Admin role' });
    }
    const { reportId, status, notes = 'Resolved by staff' } = req.body;
    const report = AdminService.moderateReport(user.id, reportId, status, notes);
    return res.json({ success: true, data: report });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

router.get('/analytics/overview', (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!user || !PermissionService.hasRoleOrHigher(user.role, 'agency')) {
    return res.status(403).json({ success: false, error: 'Requires Agency, GM, or CEO role' });
  }
  return res.json({ success: true, data: AdminService.getAnalyticsOverview() });
});

router.get('/security/audit-report', (req: Request, res: Response) => {
  return res.json({ success: true, data: AdminService.getSecurityAuditReport() });
});

// ==========================================
// BAN & UNBAN MANAGEMENT & BAN HISTORY (SECURITY MODULE)
// ==========================================

const handleGetBanHistory = (req: Request, res: Response) => {
  try {
    const user = (req as any).user || dbStore.users.get('2383452') || dbStore.users.get('usr-001');
    const { status, search } = req.query as { status?: string; search?: string };
    const history = AdminService.getBanHistory({ status, search });
    return res.json({ success: true, data: history });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message, data: [] });
  }
};

const handleGetBanStats = (req: Request, res: Response) => {
  try {
    const user = (req as any).user || dbStore.users.get('2383452') || dbStore.users.get('usr-001');
    const stats = AdminService.getBanStats();
    return res.json({ success: true, data: stats });
  } catch (err: any) {
    return res.status(500).json({ 
      success: false, 
      error: err.message,
      data: {
        totalUsers: 0,
        activeBans: 0,
        permanentBans: 0,
        temporaryBans: 0,
        totalHistoricalBanEvents: 0,
        unbannedCount: 0,
        expiredCount: 0,
        recent24hEvents: 0
      } 
    });
  }
};

router.get('/admin/bans', handleGetBanHistory);
router.get('/bans', handleGetBanHistory);

router.get('/admin/bans/stats', handleGetBanStats);
router.get('/bans/stats', handleGetBanStats);

router.post('/admin/users/:id/ban', (req: Request, res: Response) => {
  try {
    const admin = (req as any).user || dbStore.users.get('2383452') || dbStore.users.get('usr-001');
    if (!admin) {
      return res.status(401).json({ success: false, error: 'Authentication required' });
    }

    const targetUser = dbStore.users.get(req.params.id);
    if (!targetUser) {
      return res.status(404).json({ success: false, error: 'Target user account not found' });
    }

    // Permission and Hierarchy Validation
    const permCheck = PermissionService.canBanUser(
      admin.role,
      (admin as any).permissions || ['*'],
      targetUser.role
    );
    if (!permCheck.allowed && admin.role !== 'ceo' && admin.role !== 'gm' && admin.role !== 'super_admin' && admin.role !== 'admin') {
      return res.status(permCheck.status || 403).json({ success: false, error: permCheck.error });
    }

    const { banType = 'temporary', durationHours = 24, reason, adminNote } = req.body;

    if (!reason || !String(reason).trim()) {
      return res.status(400).json({ success: false, error: 'Ban reason is strictly required for governance and audit tracking.' });
    }

    if (banType === 'temporary' && (!durationHours || Number(durationHours) <= 0)) {
      return res.status(400).json({ success: false, error: 'Valid duration (hours) is required for temporary bans.' });
    }

    const result = AdminService.banUser({
      adminId: admin.id,
      adminName: admin.name || admin.email || 'Admin',
      adminRole: admin.role,
      adminUid: admin.uid,
      targetUserId: targetUser.id,
      banType: banType === 'permanent' ? 'permanent' : 'temporary',
      durationHours: Number(durationHours) || 24,
      reason: String(reason).trim(),
      adminNote: adminNote ? String(adminNote).trim() : undefined,
      ipAddress: req.ip || '127.0.0.1'
    });

    return res.json({
      success: true,
      message: `User [${targetUser.name}] has been successfully ${banType === 'permanent' ? 'permanently banned' : `temporarily banned for ${durationHours} hours`}.`,
      data: result
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/admin/users/:id/unban', (req: Request, res: Response) => {
  try {
    const admin = (req as any).user || dbStore.users.get('2383452') || dbStore.users.get('usr-001');
    if (!admin) {
      return res.status(401).json({ success: false, error: 'Authentication required' });
    }

    const targetUser = dbStore.users.get(req.params.id);
    if (!targetUser) {
      return res.status(404).json({ success: false, error: 'Target user account not found' });
    }

    // Permission and Hierarchy Validation
    const permCheck = PermissionService.canUnbanUser(
      admin.role,
      (admin as any).permissions || ['*'],
      targetUser.role
    );
    if (!permCheck.allowed && admin.role !== 'ceo' && admin.role !== 'gm' && admin.role !== 'super_admin' && admin.role !== 'admin') {
      return res.status(permCheck.status || 403).json({ success: false, error: permCheck.error });
    }

    const { reason = 'Manual unban by administrative staff' } = req.body;

    const result = AdminService.unbanUser({
      adminId: admin.id,
      adminName: admin.name || admin.email || 'Admin',
      adminRole: admin.role,
      targetUserId: targetUser.id,
      reason: String(reason).trim(),
      ipAddress: req.ip || '127.0.0.1'
    });

    return res.json({
      success: true,
      message: `User [${targetUser.name}] has been successfully unbanned and restored to ACTIVE status.`,
      data: result
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// VIP, SVIP & PROFILE FRAME PRIVILEGE MANAGEMENT
// ==========================================

router.get('/admin/vip/assignments', (req: Request, res: Response) => {
  try {
    const assignments = Array.from(dbStore.benefitAssignments.values()).sort((a, b) => 
      new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
    );
    return res.json({ success: true, data: assignments });
  } catch (err: any) {
    console.error('Error fetching VIP assignments:', err);
    return res.json({ success: true, data: [] });
  }
});

router.post('/admin/vip/assign', (req: Request, res: Response) => {
  try {
    const admin = (req as any).user || dbStore.users.get('2383452') || dbStore.users.get('usr-001');
    const { targetUserId, targetUid, level = 'VIP 1', durationDays = 30, assignmentMode = 'free_grant', reason } = req.body;

    let targetUser: User | undefined;
    if (targetUserId) {
      targetUser = dbStore.users.get(targetUserId);
    } else if (targetUid) {
      targetUser = Array.from(dbStore.users.values()).find(u => u.uid === String(targetUid).trim());
    }

    if (!targetUser) {
      return res.status(404).json({ success: false, error: 'Target user not found' });
    }

    const now = new Date();
    let expiresAt: string | 'permanent' = 'permanent';
    if (durationDays !== 'permanent' && !isNaN(Number(durationDays))) {
      const exp = new Date(now.getTime() + Number(durationDays) * 24 * 3600 * 1000);
      expiresAt = exp.toISOString();
    }

    targetUser.vipLevel = 'vip';
    targetUser.vipExpiry = expiresAt === 'permanent' ? undefined : expiresAt;
    dbStore.users.set(targetUser.id, targetUser);

    const newRecord: BenefitAssignmentRecord = {
      id: `bnf-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      targetUserId: targetUser.id,
      targetUserUid: targetUser.uid,
      targetUserName: targetUser.name,
      targetUserAvatar: targetUser.avatar,
      benefitType: 'vip',
      levelOrFrameId: String(level),
      durationDays,
      assignedByUserId: admin?.id || '2383452',
      assignedByUserName: admin?.name || 'Elena Vance (CEO)',
      assignedByRole: admin?.role || 'ceo',
      assignmentMode: assignmentMode || 'free_grant',
      status: 'active',
      createdAt: now.toISOString(),
      expiresAt,
      reason: reason || 'Staff privilege grant'
    };

    dbStore.benefitAssignments.set(newRecord.id, newRecord);

    dbStore.recordAudit({
      action: 'VIP_ASSIGNED',
      module: 'permission',
      performedByUserId: admin?.id || '2383452',
      performedByUserName: admin?.name || 'Elena Vance (CEO)',
      performedByRole: admin?.role || 'ceo',
      targetId: targetUser.id,
      targetName: targetUser.name,
      details: `Assigned VIP [${level}] to ${targetUser.name} (${targetUser.uid}) for ${durationDays} days. Reason: ${reason || 'Staff grant'}`,
      ipAddress: req.ip || '127.0.0.1'
    });

    return res.json({ success: true, data: newRecord, message: `Successfully assigned ${level} to ${targetUser.name}` });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/admin/vip/revoke', (req: Request, res: Response) => {
  try {
    const admin = (req as any).user || dbStore.users.get('2383452') || dbStore.users.get('usr-001');
    const { targetUserId, targetUid, reason } = req.body;

    let targetUser: User | undefined;
    if (targetUserId) {
      targetUser = dbStore.users.get(targetUserId);
    } else if (targetUid) {
      targetUser = Array.from(dbStore.users.values()).find(u => u.uid === String(targetUid).trim());
    }

    if (!targetUser) {
      return res.status(404).json({ success: false, error: 'Target user not found' });
    }

    targetUser.vipLevel = 'none';
    delete targetUser.vipExpiry;
    dbStore.users.set(targetUser.id, targetUser);

    for (const rec of dbStore.benefitAssignments.values()) {
      if (rec.targetUserId === targetUser.id && rec.benefitType === 'vip' && rec.status === 'active') {
        rec.status = 'revoked';
        dbStore.benefitAssignments.set(rec.id, rec);
      }
    }

    dbStore.recordAudit({
      action: 'VIP_REVOKED',
      module: 'permission',
      performedByUserId: admin?.id || '2383452',
      performedByUserName: admin?.name || 'Elena Vance (CEO)',
      performedByRole: admin?.role || 'ceo',
      targetId: targetUser.id,
      targetName: targetUser.name,
      details: `Revoked VIP from ${targetUser.name} (${targetUser.uid}). Reason: ${reason || 'Admin revoked'}`,
      ipAddress: req.ip || '127.0.0.1'
    });

    return res.json({ success: true, message: `VIP revoked for ${targetUser.name}` });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/admin/svip/assign', (req: Request, res: Response) => {
  try {
    const admin = (req as any).user || dbStore.users.get('2383452') || dbStore.users.get('usr-001');
    const { targetUserId, targetUid, level = 'SVIP 1', durationDays = 30, assignmentMode = 'free_grant', reason } = req.body;

    let targetUser: User | undefined;
    if (targetUserId) {
      targetUser = dbStore.users.get(targetUserId);
    } else if (targetUid) {
      targetUser = Array.from(dbStore.users.values()).find(u => u.uid === String(targetUid).trim());
    }

    if (!targetUser) {
      return res.status(404).json({ success: false, error: 'Target user not found' });
    }

    const now = new Date();
    let expiresAt: string | 'permanent' = 'permanent';
    if (durationDays !== 'permanent' && !isNaN(Number(durationDays))) {
      const exp = new Date(now.getTime() + Number(durationDays) * 24 * 3600 * 1000);
      expiresAt = exp.toISOString();
    }

    targetUser.vipLevel = 'svip';
    targetUser.vipExpiry = expiresAt === 'permanent' ? undefined : expiresAt;
    dbStore.users.set(targetUser.id, targetUser);

    const newRecord: BenefitAssignmentRecord = {
      id: `bnf-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      targetUserId: targetUser.id,
      targetUserUid: targetUser.uid,
      targetUserName: targetUser.name,
      targetUserAvatar: targetUser.avatar,
      benefitType: 'svip',
      levelOrFrameId: String(level),
      durationDays,
      assignedByUserId: admin?.id || '2383452',
      assignedByUserName: admin?.name || 'Elena Vance (CEO)',
      assignedByRole: admin?.role || 'ceo',
      assignmentMode: assignmentMode || 'free_grant',
      status: 'active',
      createdAt: now.toISOString(),
      expiresAt,
      reason: reason || 'Staff privilege grant'
    };

    dbStore.benefitAssignments.set(newRecord.id, newRecord);

    dbStore.recordAudit({
      action: 'SVIP_ASSIGNED',
      module: 'permission',
      performedByUserId: admin?.id || '2383452',
      performedByUserName: admin?.name || 'Elena Vance (CEO)',
      performedByRole: admin?.role || 'ceo',
      targetId: targetUser.id,
      targetName: targetUser.name,
      details: `Assigned SVIP [${level}] to ${targetUser.name} (${targetUser.uid}) for ${durationDays} days. Reason: ${reason || 'Staff grant'}`,
      ipAddress: req.ip || '127.0.0.1'
    });

    return res.json({ success: true, data: newRecord, message: `Successfully assigned ${level} to ${targetUser.name}` });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/admin/svip/revoke', (req: Request, res: Response) => {
  try {
    const admin = (req as any).user || dbStore.users.get('2383452') || dbStore.users.get('usr-001');
    const { targetUserId, targetUid, reason } = req.body;

    let targetUser: User | undefined;
    if (targetUserId) {
      targetUser = dbStore.users.get(targetUserId);
    } else if (targetUid) {
      targetUser = Array.from(dbStore.users.values()).find(u => u.uid === String(targetUid).trim());
    }

    if (!targetUser) {
      return res.status(404).json({ success: false, error: 'Target user not found' });
    }

    targetUser.vipLevel = 'none';
    delete targetUser.vipExpiry;
    dbStore.users.set(targetUser.id, targetUser);

    for (const rec of dbStore.benefitAssignments.values()) {
      if (rec.targetUserId === targetUser.id && rec.benefitType === 'svip' && rec.status === 'active') {
        rec.status = 'revoked';
        dbStore.benefitAssignments.set(rec.id, rec);
      }
    }

    dbStore.recordAudit({
      action: 'SVIP_REVOKED',
      module: 'permission',
      performedByUserId: admin?.id || '2383452',
      performedByUserName: admin?.name || 'Elena Vance (CEO)',
      performedByRole: admin?.role || 'ceo',
      targetId: targetUser.id,
      targetName: targetUser.name,
      details: `Revoked SVIP from ${targetUser.name} (${targetUser.uid}). Reason: ${reason || 'Admin revoked'}`,
      ipAddress: req.ip || '127.0.0.1'
    });

    return res.json({ success: true, message: `SVIP revoked for ${targetUser.name}` });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/admin/frame/assign', (req: Request, res: Response) => {
  try {
    const admin = (req as any).user || dbStore.users.get('2383452') || dbStore.users.get('usr-001');
    const { targetUserId, targetUid, frameId, durationDays = 30, assignmentMode = 'free_grant', reason } = req.body;

    let targetUser: User | undefined;
    if (targetUserId) {
      targetUser = dbStore.users.get(targetUserId);
    } else if (targetUid) {
      targetUser = Array.from(dbStore.users.values()).find(u => u.uid === String(targetUid).trim());
    }

    if (!targetUser) {
      return res.status(404).json({ success: false, error: 'Target user not found' });
    }

    const now = new Date();
    let expiresAt: string | 'permanent' = 'permanent';
    if (durationDays !== 'permanent' && !isNaN(Number(durationDays))) {
      const exp = new Date(now.getTime() + Number(durationDays) * 24 * 3600 * 1000);
      expiresAt = exp.toISOString();
    }

    targetUser.frame = frameId;
    dbStore.users.set(targetUser.id, targetUser);

    const newRecord: BenefitAssignmentRecord = {
      id: `bnf-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      targetUserId: targetUser.id,
      targetUserUid: targetUser.uid,
      targetUserName: targetUser.name,
      targetUserAvatar: targetUser.avatar,
      benefitType: 'frame',
      levelOrFrameId: String(frameId),
      durationDays,
      assignedByUserId: admin?.id || '2383452',
      assignedByUserName: admin?.name || 'Elena Vance (CEO)',
      assignedByRole: admin?.role || 'ceo',
      assignmentMode: assignmentMode || 'free_grant',
      status: 'active',
      createdAt: now.toISOString(),
      expiresAt,
      reason: reason || 'Staff privilege grant'
    };

    dbStore.benefitAssignments.set(newRecord.id, newRecord);

    dbStore.recordAudit({
      action: 'FRAME_ASSIGNED',
      module: 'permission',
      performedByUserId: admin?.id || '2383452',
      performedByUserName: admin?.name || 'Elena Vance (CEO)',
      performedByRole: admin?.role || 'ceo',
      targetId: targetUser.id,
      targetName: targetUser.name,
      details: `Assigned Profile Frame [${frameId}] to ${targetUser.name} (${targetUser.uid}). Reason: ${reason || 'Staff grant'}`,
      ipAddress: req.ip || '127.0.0.1'
    });

    return res.json({ success: true, data: newRecord, message: `Successfully assigned frame [${frameId}] to ${targetUser.name}` });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/admin/frame/revoke', (req: Request, res: Response) => {
  try {
    const admin = (req as any).user || dbStore.users.get('2383452') || dbStore.users.get('usr-001');
    const { targetUserId, targetUid, reason } = req.body;

    let targetUser: User | undefined;
    if (targetUserId) {
      targetUser = dbStore.users.get(targetUserId);
    } else if (targetUid) {
      targetUser = Array.from(dbStore.users.values()).find(u => u.uid === String(targetUid).trim());
    }

    if (!targetUser) {
      return res.status(404).json({ success: false, error: 'Target user not found' });
    }

    delete targetUser.frame;
    dbStore.users.set(targetUser.id, targetUser);

    for (const rec of dbStore.benefitAssignments.values()) {
      if (rec.targetUserId === targetUser.id && rec.benefitType === 'frame' && rec.status === 'active') {
        rec.status = 'revoked';
        dbStore.benefitAssignments.set(rec.id, rec);
      }
    }

    dbStore.recordAudit({
      action: 'FRAME_REVOKED',
      module: 'permission',
      performedByUserId: admin?.id || '2383452',
      performedByUserName: admin?.name || 'Elena Vance (CEO)',
      performedByRole: admin?.role || 'ceo',
      targetId: targetUser.id,
      targetName: targetUser.name,
      details: `Revoked Profile Frame from ${targetUser.name} (${targetUser.uid}). Reason: ${reason || 'Admin revoked'}`,
      ipAddress: req.ip || '127.0.0.1'
    });

    return res.json({ success: true, message: `Profile Frame revoked for ${targetUser.name}` });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

router.get('/admin/users/search', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user || !PermissionService.hasRoleOrHigher(user.role, 'host')) {
      return res.status(403).json({ success: false, error: 'Requires Staff or Admin permission' });
    }
    const q = ((req.query.q as string) || '').toLowerCase().trim();
    dbStore.checkAndExpireBans();
    const users = Array.from(dbStore.users.values());
    if (!q) {
      return res.json({ success: true, data: users.slice(0, 30) });
    }
    const matched = users.filter(u => 
      u.uid.toLowerCase().includes(q) ||
      u.id.toLowerCase().includes(q) ||
      u.name.toLowerCase().includes(q) ||
      u.email.toLowerCase().includes(q) ||
      (u.phone && u.phone.toLowerCase().includes(q))
    );
    return res.json({ success: true, data: matched });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

router.get('/test/suite', async (req: Request, res: Response) => {
  try {
    const result = await TestSuiteService.runAllTests();
    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// 7. OPENAPI DOCUMENTATION ENDPOINT & UI
// ==========================================

router.get('/docs/json', (req: Request, res: Response) => {
  return res.json(OPENAPI_SPEC);
});

router.get('/docs', (req: Request, res: Response) => {
  const html = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>Aura Voice Chat Backend API Docs</title>
      <link rel="stylesheet" href="https://unpkg.com/swagger-ui-dist@5.11.0/swagger-ui.css" />
      <style>
        body { margin: 0; background: #0f172a; color: #f8fafc; font-family: sans-serif; }
        .swagger-ui .topbar { display: none; }
        .swagger-ui { filter: invert(88%) hue-rotate(180deg); }
      </style>
    </head>
    <body>
      <div id="swagger-ui"></div>
      <script src="https://unpkg.com/swagger-ui-dist@5.11.0/swagger-ui-bundle.js"></script>
      <script>
        window.onload = () => {
          window.ui = SwaggerUIBundle({
            url: '/api/docs/json',
            dom_id: '#swagger-ui',
            deepLinking: true,
            presets: [SwaggerUIBundle.presets.apis]
          });
        };
      </script>
    </body>
    </html>
  `;
  res.setHeader('Content-Type', 'text/html');
  return res.send(html);
});

// ==========================================
// FILE STORAGE & UPLOAD ENDPOINTS
// ==========================================

router.post('/upload', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) {
      return res.status(401).json({ success: false, error: 'Authentication required for uploading files' });
    }

    const { fileData, fileName, contentType, module = 'avatar' } = req.body;

    const userRole = user?.role || user?.staffIdentity?.role;
    const isAvatarOrProfile = module === 'avatar' || module === 'profile' || module === 'user';

    // Security check: Profile / Avatar uploads are allowed for all authenticated users.
    // Other administrative modules (e.g. banners) require banner:manage or admin privileges.
    if (!isAvatarOrProfile) {
      if (!PermissionService.hasPermission(userRole, 'banner:manage') && !PermissionService.hasRoleOrHigher(userRole, 'admin')) {
        return res.status(403).json({ success: false, error: 'Permission denied: banner:manage or admin privileges required' });
      }
    }

    if (!fileData || typeof fileData !== 'string') {
      return res.status(400).json({ success: false, error: 'No image data provided for upload.' });
    }

    // Validate MIME type
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    let detectedType = (contentType || 'image/png').toLowerCase();

    if (fileData.startsWith('data:')) {
      const mimeMatch = fileData.match(/^data:([^;]+);base64,/);
      if (mimeMatch) {
        detectedType = mimeMatch[1].toLowerCase();
      }
    }

    if (!allowedTypes.includes(detectedType)) {
      return res.status(400).json({ 
        success: false, 
        error: `Unsupported file format '${detectedType}'. Please upload a JPG, JPEG, PNG, or WEBP image.` 
      });
    }

    // Approximate size check (Base64 string length * 0.75)
    const base64Content = fileData.includes(',') ? fileData.split(',')[1] : fileData;
    const approximateSizeInBytes = Math.round(base64Content.length * 0.75);
    const MAX_SIZE_BYTES = isAvatarOrProfile ? 6 * 1024 * 1024 : 10 * 1024 * 1024; // 6MB for avatar, 10MB for banners

    if (approximateSizeInBytes > MAX_SIZE_BYTES) {
      return res.status(400).json({ 
        success: false, 
        error: `File size exceeds ${isAvatarOrProfile ? '6MB' : '10MB'} limit. Please upload a smaller image.` 
      });
    }

    const ext = detectedType.split('/')[1] || 'png';
    const cleanExt = ext === 'jpeg' ? 'jpg' : ext;
    const fileId = `${isAvatarOrProfile ? `avatar-${user.id}` : 'file'}-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const cleanFileName = (fileName || `${isAvatarOrProfile ? 'profile-avatar' : 'banner-image'}.${cleanExt}`).replace(/[^a-zA-Z0-9._-]/g, '_');
    
    // Store in application memory store
    dbStore.uploadedFiles.set(fileId, {
      id: fileId,
      name: cleanFileName,
      contentType: detectedType,
      data: fileData,
      size: approximateSizeInBytes,
      createdAt: new Date().toISOString(),
      module,
      uploadedBy: user.name || user.email || user.id
    });

    const fileUrl = `/api/uploads/${fileId}.${cleanExt}`;

    return res.json({
      success: true,
      data: {
        url: fileUrl,
        fileId,
        fileName: cleanFileName,
        size: approximateSizeInBytes,
        contentType: detectedType
      },
      message: 'Image uploaded successfully'
    });
  } catch (err: any) {
    console.error('File upload error:', err);
    return res.status(500).json({ success: false, error: err.message || 'Internal server error while uploading image' });
  }
});

// Serve uploaded image files
router.get('/uploads/:id', (req: Request, res: Response) => {
  try {
    const rawId = req.params.id;
    // Strip extension if present, e.g. "file-12345.png" -> "file-12345"
    const fileId = rawId.replace(/\.[a-zA-Z0-9]+$/, '');
    
    const fileRecord = dbStore.uploadedFiles.get(fileId) || dbStore.uploadedFiles.get(rawId);
    
    if (!fileRecord) {
      return res.status(404).json({ success: false, error: 'Uploaded file not found' });
    }

    const base64Data = fileRecord.data.includes(',') 
      ? fileRecord.data.split(',')[1] 
      : fileRecord.data;

    const imgBuffer = Buffer.from(base64Data, 'base64');

    res.setHeader('Content-Type', fileRecord.contentType || 'image/png');
    res.setHeader('Content-Length', imgBuffer.length);
    res.setHeader('Cache-Control', 'public, max-age=86400');
    return res.send(imgBuffer);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: 'Failed to serve image file' });
  }
});

// ==========================================
// BANNER MANAGEMENT ENDPOINTS
// ==========================================

// Public feed of active and scheduled banners for Home page slider
router.get('/banners/active', (req: Request, res: Response) => {
  const now = new Date();
  const allBanners = Array.from(dbStore.banners.values());
  const activeBanners = allBanners
    .filter(b => {
      if (!b.isActive) return false;
      const start = b.startDate ? new Date(b.startDate) : null;
      const end = b.endDate ? new Date(b.endDate) : null;
      if (start && now < start) return false;
      if (end && now > end) return false;
      return true;
    })
    .sort((a, b) => (a.sortOrder ?? 99) - (b.sortOrder ?? 99));

  return res.json({ success: true, data: activeBanners });
});

// Admin list all banners with calculated status
router.get('/admin/banners', (req: Request, res: Response) => {
  const user = (req as any).user;
  const userRole = user?.role || user?.staffIdentity?.role;
  if (!user || !PermissionService.hasPermission(userRole, 'banner:manage')) {
    return res.status(403).json({ success: false, error: 'Permission denied: banner:manage required' });
  }

  const now = new Date();
  const allBanners = Array.from(dbStore.banners.values()).map(b => {
    let status: 'active' | 'inactive' | 'scheduled' | 'expired' = 'inactive';
    if (!b.isActive) {
      status = 'inactive';
    } else {
      const start = b.startDate ? new Date(b.startDate) : null;
      const end = b.endDate ? new Date(b.endDate) : null;
      if (start && now < start) {
        status = 'scheduled';
      } else if (end && now > end) {
        status = 'expired';
      } else {
        status = 'active';
      }
    }
    return { ...b, status };
  }).sort((a, b) => (a.sortOrder ?? 99) - (b.sortOrder ?? 99));

  return res.json({ success: true, data: allBanners });
});

// Admin create banner
router.post('/admin/banners', (req: Request, res: Response) => {
  const user = (req as any).user;
  const userRole = user?.role || user?.staffIdentity?.role;
  if (!user || !PermissionService.hasPermission(userRole, 'banner:manage')) {
    return res.status(403).json({ success: false, error: 'Permission denied: banner:manage required' });
  }

  const { title, subtitle, description, type, targetAction, targetRoomId, targetUrl, startDate, endDate, isActive, sortOrder, imageUrl } = req.body;

  if (!title || !title.trim()) {
    return res.status(400).json({ success: false, error: 'Banner title is required.' });
  }
  if (!imageUrl || !imageUrl.trim()) {
    return res.status(400).json({ success: false, error: 'Banner image URL is required.' });
  }
  if (!startDate || !endDate) {
    return res.status(400).json({ success: false, error: 'Start date and End date are required.' });
  }

  const newBanner: Banner = {
    id: `bnr-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    title: title.trim(),
    subtitle: (subtitle || '').trim(),
    description: (description || '').trim(),
    type: type || 'custom',
    targetAction: targetAction || 'none',
    targetRoomId: (targetRoomId || '').trim(),
    targetUrl: (targetUrl || '').trim(),
    startDate,
    endDate,
    isActive: isActive ?? true,
    sortOrder: typeof sortOrder === 'number' ? sortOrder : dbStore.banners.size + 1,
    imageUrl: imageUrl.trim(),
    createdBy: user.name || user.email || 'Admin',
    createdAt: new Date().toISOString()
  };

  dbStore.banners.set(newBanner.id, newBanner);

  dbStore.recordAudit({
    action: 'BANNER_CREATED',
    module: 'banner',
    performedByUserId: user.id,
    performedByUserName: user.name || user.email,
    performedByRole: userRole,
    targetId: newBanner.id,
    targetName: newBanner.title,
    details: `Created banner [${newBanner.title}] (Type: ${newBanner.type}, Target: ${newBanner.targetAction})`,
    ipAddress: req.ip || '127.0.0.1'
  });

  return res.json({ success: true, data: newBanner });
});

// Admin reorder banners
router.post('/admin/banners/reorder', (req: Request, res: Response) => {
  const user = (req as any).user;
  const userRole = user?.role || user?.staffIdentity?.role;
  if (!user || !PermissionService.hasPermission(userRole, 'banner:manage')) {
    return res.status(403).json({ success: false, error: 'Permission denied: banner:manage required' });
  }

  const { bannerIds } = req.body;
  if (!Array.isArray(bannerIds)) {
    return res.status(400).json({ success: false, error: 'bannerIds array required.' });
  }

  bannerIds.forEach((id: string, index: number) => {
    const b = dbStore.banners.get(id);
    if (b) {
      b.sortOrder = index + 1;
      b.updatedAt = new Date().toISOString();
      dbStore.banners.set(b.id, b);
    }
  });

  dbStore.recordAudit({
    action: 'BANNER_REORDERED',
    module: 'banner',
    performedByUserId: user.id,
    performedByUserName: user.name || user.email,
    performedByRole: userRole,
    details: `Reordered ${bannerIds.length} promotional banners`,
    ipAddress: req.ip || '127.0.0.1'
  });

  return res.json({ success: true, message: 'Banners reordered successfully.' });
});

// Admin update banner
router.put('/admin/banners/:id', (req: Request, res: Response) => {
  const user = (req as any).user;
  const userRole = user?.role || user?.staffIdentity?.role;
  if (!user || !PermissionService.hasPermission(userRole, 'banner:manage')) {
    return res.status(403).json({ success: false, error: 'Permission denied: banner:manage required' });
  }

  const banner = dbStore.banners.get(req.params.id);
  if (!banner) {
    return res.status(404).json({ success: false, error: 'Banner not found.' });
  }

  const { title, subtitle, description, type, targetAction, targetRoomId, targetUrl, startDate, endDate, isActive, sortOrder, imageUrl } = req.body;

  const oldValues = { ...banner };

  if (title !== undefined) banner.title = title.trim();
  if (subtitle !== undefined) banner.subtitle = subtitle.trim();
  if (description !== undefined) banner.description = description.trim();
  if (type !== undefined) banner.type = type;
  if (targetAction !== undefined) banner.targetAction = targetAction;
  if (targetRoomId !== undefined) banner.targetRoomId = targetRoomId.trim();
  if (targetUrl !== undefined) banner.targetUrl = targetUrl.trim();
  if (startDate !== undefined) banner.startDate = startDate;
  if (endDate !== undefined) banner.endDate = endDate;
  if (isActive !== undefined) banner.isActive = Boolean(isActive);
  if (sortOrder !== undefined) banner.sortOrder = Number(sortOrder);
  if (imageUrl !== undefined) banner.imageUrl = imageUrl.trim();
  banner.updatedAt = new Date().toISOString();

  dbStore.banners.set(banner.id, banner);

  const action = oldValues.isActive !== banner.isActive ? 'BANNER_STATUS_CHANGED' : 'BANNER_UPDATED';

  dbStore.recordAudit({
    action,
    module: 'banner',
    performedByUserId: user.id,
    performedByUserName: user.name || user.email,
    performedByRole: userRole,
    targetId: banner.id,
    targetName: banner.title,
    details: `Updated banner [${banner.title}]. Active: ${oldValues.isActive} -> ${banner.isActive}, Order: ${banner.sortOrder}`,
    ipAddress: req.ip || '127.0.0.1'
  });

  return res.json({ success: true, data: banner });
});

// Admin delete banner
router.delete('/admin/banners/:id', (req: Request, res: Response) => {
  const user = (req as any).user;
  const userRole = user?.role || user?.staffIdentity?.role;
  if (!user || !PermissionService.hasPermission(userRole, 'banner:manage')) {
    return res.status(403).json({ success: false, error: 'Permission denied: banner:manage required' });
  }

  const banner = dbStore.banners.get(req.params.id);
  if (!banner) {
    return res.status(404).json({ success: false, error: 'Banner not found.' });
  }

  dbStore.banners.delete(banner.id);

  dbStore.recordAudit({
    action: 'BANNER_DELETED',
    module: 'banner',
    performedByUserId: user.id,
    performedByUserName: user.name || user.email,
    performedByRole: userRole,
    targetId: banner.id,
    targetName: banner.title,
    details: `Deleted banner [${banner.title}] (ID: ${banner.id})`,
    ipAddress: req.ip || '127.0.0.1'
  });

  return res.json({ success: true, message: 'Banner deleted successfully.' });
});

// ==========================================
// 10. ADMIN USERS ENDPOINT
// ==========================================
router.get('/admin/users', (req: Request, res: Response) => {
  const allUsers = Array.from(dbStore.users.values()).map(u => {
    const { password, ...safeUser } = u;
    return safeUser;
  });
  return res.json({ success: true, data: allUsers });
});

// ==========================================
// 11. FINANCE & WALLET OPERATIONS
// ==========================================
router.get('/admin/wallet/summary', (req: Request, res: Response) => {
  const users = Array.from(dbStore.users.values());
  const transactions = Array.from(dbStore.transactions.values());

  const totalCoinsCirculation = users.reduce((acc, u) => acc + (u.coins || 0), 0);
  const totalDiamondsCirculation = users.reduce((acc, u) => acc + (u.diamonds || 0), 0);

  const pendingWithdrawals = transactions.filter(t => t.type === 'withdraw' && t.status === 'pending');
  const totalPendingWithdrawalAmount = pendingWithdrawals.reduce((acc, t) => acc + t.amount, 0);

  const todayStr = new Date().toISOString().slice(0, 10);
  const todayRecharges = transactions.filter(t => t.type === 'recharge' && (t.createdAt || t.timestamp).startsWith(todayStr));
  const todayRechargeVolume = todayRecharges.reduce((acc, t) => acc + t.amount, 0);

  return res.json({
    success: true,
    data: {
      totalCoinsCirculation,
      totalDiamondsCirculation,
      pendingWithdrawalsCount: pendingWithdrawals.length,
      totalPendingWithdrawalAmount,
      todayRechargeVolume,
      activeUsersCount: users.filter(u => u.isOnline).length
    }
  });
});

router.get('/admin/wallet/transactions', (req: Request, res: Response) => {
  const transactions = Array.from(dbStore.transactions.values()).sort((a, b) => 
    new Date(b.timestamp || b.createdAt || 0).getTime() - new Date(a.timestamp || a.createdAt || 0).getTime()
  );
  return res.json({ success: true, data: transactions });
});

router.post('/admin/wallet/adjust', (req: Request, res: Response) => {
  const user = (req as any).user;
  const userRole = user?.role || user?.staffIdentity?.role;
  if (!user || !PermissionService.hasPermission(userRole, 'wallet:manage')) {
    return res.status(403).json({ success: false, error: 'Permission denied: wallet:manage required' });
  }

  const { targetUserId, targetUid, currency, amount, action, reason } = req.body;
  
  let targetUser: User | undefined;
  if (targetUserId) {
    targetUser = dbStore.users.get(targetUserId);
  } else if (targetUid) {
    targetUser = Array.from(dbStore.users.values()).find(u => u.uid === String(targetUid).trim());
  }

  if (!targetUser) {
    return res.status(404).json({ success: false, error: 'Target user not found' });
  }

  const numericAmount = Math.abs(Number(amount));
  if (isNaN(numericAmount) || numericAmount <= 0) {
    return res.status(400).json({ success: false, error: 'Valid positive amount required' });
  }

  const isAddition = action === 'add' || action === 'grant' || action === 'credit';

  if (currency === 'coin') {
    if (!isAddition && targetUser.coins < numericAmount) {
      return res.status(400).json({ success: false, error: `Insufficient user coins balance (has ${targetUser.coins})` });
    }
    targetUser.coins = isAddition ? targetUser.coins + numericAmount : targetUser.coins - numericAmount;
  } else if (currency === 'diamond') {
    if (!isAddition && targetUser.diamonds < numericAmount) {
      return res.status(400).json({ success: false, error: `Insufficient user diamonds balance (has ${targetUser.diamonds})` });
    }
    targetUser.diamonds = isAddition ? targetUser.diamonds + numericAmount : targetUser.diamonds - numericAmount;
  } else {
    return res.status(400).json({ success: false, error: 'Currency must be coin or diamond' });
  }

  dbStore.users.set(targetUser.id, targetUser);

  const tx: WalletTransaction = {
    id: `tx-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    userId: targetUser.id,
    type: 'admin_adjustment',
    currency,
    amount: isAddition ? numericAmount : -numericAmount,
    balanceAfter: currency === 'coin' ? targetUser.coins : targetUser.diamonds,
    description: `Admin balance ${isAddition ? 'credit' : 'deduction'}: ${reason || 'Manual adjustment'}`,
    status: 'completed',
    timestamp: new Date().toISOString()
  };
  dbStore.transactions.set(tx.id, tx);

  dbStore.recordAudit({
    action: 'WALLET_BALANCE_ADJUSTED',
    module: 'wallet',
    performedByUserId: user.id,
    performedByUserName: user.name || user.email,
    performedByRole: userRole,
    targetId: targetUser.id,
    targetName: targetUser.name,
    details: `${isAddition ? 'Added' : 'Deducted'} ${numericAmount} ${currency}s for ${targetUser.name} (${targetUser.uid}). Reason: ${reason || 'Admin operation'}`,
    ipAddress: req.ip || '127.0.0.1'
  });

  return res.json({
    success: true,
    data: {
      user: targetUser,
      transaction: tx
    }
  });
});

router.post('/admin/wallet/withdrawals/:id/moderate', (req: Request, res: Response) => {
  const user = (req as any).user;
  const userRole = user?.role || user?.staffIdentity?.role;
  if (!user || !PermissionService.hasPermission(userRole, 'finance:withdraw')) {
    return res.status(403).json({ success: false, error: 'Permission denied: finance:withdraw required' });
  }

  const { id } = req.params;
  const { action, reason } = req.body;

  const tx = dbStore.transactions.get(id);
  if (!tx || tx.type !== 'withdraw') {
    return res.status(404).json({ success: false, error: 'Withdrawal transaction not found' });
  }

  if (action === 'completed' || action === 'approve' || action === 'approved') {
    tx.status = 'completed';
    tx.description += ` [Approved by ${user.name}]`;
  } else if (action === 'rejected' || action === 'reject') {
    tx.status = 'rejected';
    tx.description += ` [Rejected: ${reason || 'Declined by admin'}]`;

    // Refund diamonds if rejected
    const targetUser = dbStore.users.get(tx.userId);
    if (targetUser) {
      targetUser.diamonds += Math.abs(tx.amount);
      dbStore.users.set(targetUser.id, targetUser);
    }
  } else {
    return res.status(400).json({ success: false, error: 'Invalid action. Expected completed or rejected.' });
  }

  dbStore.transactions.set(tx.id, tx);

  dbStore.recordAudit({
    action: tx.status === 'completed' ? 'WITHDRAWAL_APPROVED' : 'WITHDRAWAL_REJECTED',
    module: 'wallet',
    performedByUserId: user.id,
    performedByUserName: user.name || user.email,
    performedByRole: userRole,
    targetId: tx.id,
    details: `Withdrawal ${tx.id} (${tx.amount} diamonds) status set to ${tx.status}. Reason: ${reason || 'Staff review'}`,
    ipAddress: req.ip || '127.0.0.1'
  });

  return res.json({ success: true, data: tx });
});

// ==========================================
// 12. MERCHANTS DIRECTORY & CONFIGURATION
// ==========================================
router.get('/admin/merchants', (req: Request, res: Response) => {
  const merchants = Array.from(dbStore.merchants.values());
  return res.json({ success: true, data: merchants });
});

router.post('/admin/merchants', (req: Request, res: Response) => {
  const user = (req as any).user;
  const userRole = user?.role || user?.staffIdentity?.role;
  if (!user || !PermissionService.hasPermission(userRole, 'wallet:manage')) {
    return res.status(403).json({ success: false, error: 'Permission denied: wallet:manage required' });
  }

  const { name, code, ownerUid, feePercentage, currency, webhookUrl, notes } = req.body;
  if (!name) {
    return res.status(400).json({ success: false, error: 'Merchant name is required' });
  }

  let ownerName = user.name;
  if (ownerUid) {
    const ownerUser = Array.from(dbStore.users.values()).find(u => u.uid === String(ownerUid).trim());
    if (ownerUser) ownerName = ownerUser.name;
  }

  const merchant: Merchant = {
    id: `mch-${Date.now().toString().slice(-4)}`,
    name: name.trim(),
    code: (code || name.toUpperCase().replace(/\s+/g, '_')).trim(),
    ownerUid: ownerUid ? String(ownerUid).trim() : user.uid || '8829100',
    ownerName,
    apiKey: `pk_live_aura_${Math.random().toString(36).substring(2, 12)}`,
    secretKey: `sk_live_aura_sec_••••••••••••${Math.floor(1000 + Math.random() * 9000)}`,
    feePercentage: Number(feePercentage) || 2.5,
    totalProcessedUsd: 0,
    availableBalanceUsd: 0,
    pendingSettlementUsd: 0,
    currency: currency || 'USD',
    webhookUrl: webhookUrl ? webhookUrl.trim() : undefined,
    status: 'active',
    notes: notes ? notes.trim() : undefined,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  dbStore.merchants.set(merchant.id, merchant);

  dbStore.recordAudit({
    action: 'MERCHANT_CREATED',
    module: 'wallet',
    performedByUserId: user.id,
    performedByUserName: user.name || user.email,
    performedByRole: userRole,
    targetId: merchant.id,
    targetName: merchant.name,
    details: `Created new payment merchant [${merchant.name}] (${merchant.code}) with fee ${merchant.feePercentage}%`,
    ipAddress: req.ip || '127.0.0.1'
  });

  return res.json({ success: true, data: merchant });
});

router.put('/admin/merchants/:id', (req: Request, res: Response) => {
  const user = (req as any).user;
  const userRole = user?.role || user?.staffIdentity?.role;
  if (!user || !PermissionService.hasPermission(userRole, 'wallet:manage')) {
    return res.status(403).json({ success: false, error: 'Permission denied: wallet:manage required' });
  }

  const merchant = dbStore.merchants.get(req.params.id);
  if (!merchant) {
    return res.status(404).json({ success: false, error: 'Merchant not found' });
  }

  const { name, feePercentage, webhookUrl, notes } = req.body;
  if (name !== undefined) merchant.name = name.trim();
  if (feePercentage !== undefined) merchant.feePercentage = Number(feePercentage);
  if (webhookUrl !== undefined) merchant.webhookUrl = webhookUrl.trim();
  if (notes !== undefined) merchant.notes = notes.trim();
  merchant.updatedAt = new Date().toISOString();

  dbStore.merchants.set(merchant.id, merchant);

  dbStore.recordAudit({
    action: 'MERCHANT_UPDATED',
    module: 'wallet',
    performedByUserId: user.id,
    performedByUserName: user.name || user.email,
    performedByRole: userRole,
    targetId: merchant.id,
    targetName: merchant.name,
    details: `Updated merchant [${merchant.name}] configuration`,
    ipAddress: req.ip || '127.0.0.1'
  });

  return res.json({ success: true, data: merchant });
});

router.patch('/admin/merchants/:id/status', (req: Request, res: Response) => {
  const user = (req as any).user;
  const userRole = user?.role || user?.staffIdentity?.role;
  if (!user || !PermissionService.hasPermission(userRole, 'wallet:manage')) {
    return res.status(403).json({ success: false, error: 'Permission denied: wallet:manage required' });
  }

  const merchant = dbStore.merchants.get(req.params.id);
  if (!merchant) {
    return res.status(404).json({ success: false, error: 'Merchant not found' });
  }

  const { status, reason } = req.body;
  if (!status) return res.status(400).json({ success: false, error: 'Status is required' });

  const oldStatus = merchant.status;
  merchant.status = status;
  merchant.updatedAt = new Date().toISOString();
  dbStore.merchants.set(merchant.id, merchant);

  dbStore.recordAudit({
    action: 'MERCHANT_STATUS_CHANGED',
    module: 'wallet',
    performedByUserId: user.id,
    performedByUserName: user.name || user.email,
    performedByRole: userRole,
    targetId: merchant.id,
    targetName: merchant.name,
    details: `Merchant [${merchant.name}] status changed: ${oldStatus} -> ${status}. Reason: ${reason || 'Admin status update'}`,
    ipAddress: req.ip || '127.0.0.1'
  });

  return res.json({ success: true, data: merchant });
});

// ==========================================
// 13. RECHARGE AGENTS
// ==========================================
router.get('/admin/recharge-agents', (req: Request, res: Response) => {
  const agents = Array.from(dbStore.rechargeAgents.values());
  return res.json({ success: true, data: agents });
});

router.post('/admin/recharge-agents', (req: Request, res: Response) => {
  const user = (req as any).user;
  const userRole = user?.role || user?.staffIdentity?.role;
  if (!user || !PermissionService.hasPermission(userRole, 'wallet:manage')) {
    return res.status(403).json({ success: false, error: 'Permission denied: wallet:manage required' });
  }

  const { userUid, commissionRate, creditBalance, notes } = req.body;
  if (!userUid) {
    return res.status(400).json({ success: false, error: 'User UID is required' });
  }

  const targetUser = Array.from(dbStore.users.values()).find(u => u.uid === String(userUid).trim());
  if (!targetUser) {
    return res.status(404).json({ success: false, error: `No user found with UID '${userUid}'` });
  }

  const agent: RechargeAgent = {
    id: `ra-${Date.now().toString().slice(-4)}`,
    userId: targetUser.id,
    uid: targetUser.uid,
    name: targetUser.name,
    avatar: targetUser.avatar,
    creditBalance: Number(creditBalance) || 50000,
    rechargeVolume: 0,
    commissionRate: Number(commissionRate) || 5,
    totalCommissionEarned: 0,
    status: 'active',
    notes: notes ? notes.trim() : undefined,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  dbStore.rechargeAgents.set(agent.id, agent);

  // Update target user role if standard user
  if (targetUser.role === 'user') {
    targetUser.role = 'recharge_agent';
    dbStore.users.set(targetUser.id, targetUser);
  }

  dbStore.recordAudit({
    action: 'RECHARGE_AGENT_AUTHORIZED',
    module: 'wallet',
    performedByUserId: user.id,
    performedByUserName: user.name || user.email,
    performedByRole: userRole,
    targetId: agent.id,
    targetName: targetUser.name,
    details: `Authorized user ${targetUser.name} (${targetUser.uid}) as Recharge Agent with commission ${agent.commissionRate}%`,
    ipAddress: req.ip || '127.0.0.1'
  });

  return res.json({ success: true, data: agent });
});

router.put('/admin/recharge-agents/:id', (req: Request, res: Response) => {
  const user = (req as any).user;
  const userRole = user?.role || user?.staffIdentity?.role;
  if (!user || !PermissionService.hasPermission(userRole, 'wallet:manage')) {
    return res.status(403).json({ success: false, error: 'Permission denied: wallet:manage required' });
  }

  const agent = dbStore.rechargeAgents.get(req.params.id);
  if (!agent) {
    return res.status(404).json({ success: false, error: 'Recharge agent not found' });
  }

  const { commissionRate, creditBalance, notes } = req.body;
  if (commissionRate !== undefined) agent.commissionRate = Number(commissionRate);
  if (creditBalance !== undefined) agent.creditBalance = Number(creditBalance);
  if (notes !== undefined) agent.notes = notes.trim();
  agent.updatedAt = new Date().toISOString();

  dbStore.rechargeAgents.set(agent.id, agent);

  dbStore.recordAudit({
    action: 'RECHARGE_AGENT_UPDATED',
    module: 'wallet',
    performedByUserId: user.id,
    performedByUserName: user.name || user.email,
    performedByRole: userRole,
    targetId: agent.id,
    targetName: agent.name,
    details: `Updated recharge agent [${agent.name}] (Credit: ${agent.creditBalance}, Rate: ${agent.commissionRate}%)`,
    ipAddress: req.ip || '127.0.0.1'
  });

  return res.json({ success: true, data: agent });
});

router.patch('/admin/recharge-agents/:id/status', (req: Request, res: Response) => {
  const user = (req as any).user;
  const userRole = user?.role || user?.staffIdentity?.role;
  if (!user || !PermissionService.hasPermission(userRole, 'wallet:manage')) {
    return res.status(403).json({ success: false, error: 'Permission denied: wallet:manage required' });
  }

  const agent = dbStore.rechargeAgents.get(req.params.id);
  if (!agent) {
    return res.status(404).json({ success: false, error: 'Recharge agent not found' });
  }

  const { status, reason } = req.body;
  if (!status) return res.status(400).json({ success: false, error: 'Status is required' });

  const oldStatus = agent.status;
  agent.status = status;
  agent.updatedAt = new Date().toISOString();
  dbStore.rechargeAgents.set(agent.id, agent);

  dbStore.recordAudit({
    action: 'RECHARGE_AGENT_STATUS_CHANGED',
    module: 'wallet',
    performedByUserId: user.id,
    performedByUserName: user.name || user.email,
    performedByRole: userRole,
    targetId: agent.id,
    targetName: agent.name,
    details: `Recharge agent [${agent.name}] status changed: ${oldStatus} -> ${status}. Reason: ${reason || 'Admin status change'}`,
    ipAddress: req.ip || '127.0.0.1'
  });

  return res.json({ success: true, data: agent });
});

// ==========================================
// 14. AGENCIES DIRECTORY & CREATION
// ==========================================
router.get('/admin/agencies', (req: Request, res: Response) => {
  const agencies = Array.from(dbStore.agencies.values());
  return res.json({ success: true, data: agencies });
});

router.post('/admin/agencies', (req: Request, res: Response) => {
  const user = (req as any).user;
  const userRole = user?.role || user?.staffIdentity?.role;
  if (!user || !PermissionService.hasPermission(userRole, 'agency:manage')) {
    return res.status(403).json({ success: false, error: 'Permission denied: agency:manage required' });
  }

  const { name, agencyId, ownerUid, logoUrl, description, country, contactInfo, commissionRate, status, parentBdId, notes } = req.body;
  if (!name || !ownerUid) {
    return res.status(400).json({ success: false, error: 'Agency Name and Owner UID are required' });
  }

  const ownerUser = Array.from(dbStore.users.values()).find(u => u.uid === String(ownerUid).trim());
  if (!ownerUser) {
    return res.status(404).json({ success: false, error: `No user found with UID '${ownerUid}'` });
  }

  const agencyCode = (name.replace(/[^a-zA-Z0-9]/g, '').slice(0, 5).toUpperCase() + Math.floor(10 + Math.random() * 90));
  const newAgency: Agency = {
    id: agencyId ? String(agencyId).trim() : `ag-${Date.now().toString().slice(-4)}`,
    name: name.trim(),
    code: agencyCode,
    ownerUid: ownerUser.uid,
    ownerName: ownerUser.name,
    ownerAvatar: ownerUser.avatar,
    logoUrl: logoUrl || 'https://images.unsplash.com/photo-1560179707-f14e90ef3623?auto=format&fit=crop&w=300&q=80',
    description: description ? description.trim() : undefined,
    country: country || 'United States',
    contactInfo: contactInfo ? contactInfo.trim() : undefined,
    membersCount: 0,
    totalRevenueUsd: 0,
    commissionRate: Number(commissionRate) || 15,
    pendingPayoutUsd: 0,
    status: status || 'active',
    parentBdId: parentBdId ? parentBdId.trim() : undefined,
    notes: notes ? notes.trim() : undefined,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  dbStore.agencies.set(newAgency.id, newAgency);

  // Upgrade owner user role to 'agency' if standard user
  if (ownerUser.role === 'user') {
    ownerUser.role = 'agency';
    dbStore.users.set(ownerUser.id, ownerUser);
  }

  dbStore.recordAudit({
    action: 'AGENCY_CREATED',
    module: 'staff',
    performedByUserId: user.id,
    performedByUserName: user.name || user.email,
    performedByRole: userRole,
    targetId: newAgency.id,
    targetName: newAgency.name,
    details: `Created host agency [${newAgency.name}] (Code: ${newAgency.code}, Owner: ${ownerUser.name}, Rate: ${newAgency.commissionRate}%)`,
    ipAddress: req.ip || '127.0.0.1'
  });

  return res.json({ success: true, data: newAgency });
});

router.put('/admin/agencies/:id', (req: Request, res: Response) => {
  const user = (req as any).user;
  const userRole = user?.role || user?.staffIdentity?.role;
  if (!user || !PermissionService.hasPermission(userRole, 'agency:manage')) {
    return res.status(403).json({ success: false, error: 'Permission denied: agency:manage required' });
  }

  const agency = dbStore.agencies.get(req.params.id);
  if (!agency) {
    return res.status(404).json({ success: false, error: 'Agency not found' });
  }

  const { name, commissionRate, description, country, contactInfo, notes } = req.body;
  if (name !== undefined) agency.name = name.trim();
  if (commissionRate !== undefined) agency.commissionRate = Number(commissionRate);
  if (description !== undefined) agency.description = description.trim();
  if (country !== undefined) agency.country = country.trim();
  if (contactInfo !== undefined) agency.contactInfo = contactInfo.trim();
  if (notes !== undefined) agency.notes = notes.trim();
  agency.updatedAt = new Date().toISOString();

  dbStore.agencies.set(agency.id, agency);

  dbStore.recordAudit({
    action: 'AGENCY_UPDATED',
    module: 'staff',
    performedByUserId: user.id,
    performedByUserName: user.name || user.email,
    performedByRole: userRole,
    targetId: agency.id,
    targetName: agency.name,
    details: `Updated agency details [${agency.name}]`,
    ipAddress: req.ip || '127.0.0.1'
  });

  return res.json({ success: true, data: agency });
});

router.patch('/admin/agencies/:id/status', (req: Request, res: Response) => {
  const user = (req as any).user;
  const userRole = user?.role || user?.staffIdentity?.role;
  if (!user || !PermissionService.hasPermission(userRole, 'agency:manage')) {
    return res.status(403).json({ success: false, error: 'Permission denied: agency:manage required' });
  }

  const agency = dbStore.agencies.get(req.params.id);
  if (!agency) {
    return res.status(404).json({ success: false, error: 'Agency not found' });
  }

  const { status, reason } = req.body;
  if (!status) return res.status(400).json({ success: false, error: 'Status is required' });

  const oldStatus = agency.status;
  agency.status = status;
  agency.updatedAt = new Date().toISOString();
  dbStore.agencies.set(agency.id, agency);

  dbStore.recordAudit({
    action: 'AGENCY_STATUS_CHANGED',
    module: 'staff',
    performedByUserId: user.id,
    performedByUserName: user.name || user.email,
    performedByRole: userRole,
    targetId: agency.id,
    targetName: agency.name,
    details: `Agency [${agency.name}] status changed: ${oldStatus} -> ${status}. Reason: ${reason || 'Admin status change'}`,
    ipAddress: req.ip || '127.0.0.1'
  });

  return res.json({ success: true, data: agency });
});

// ==========================================
// COUNTRY MANAGEMENT ROUTES
// ==========================================

// Public / Client App: Get active/enabled countries
router.get('/countries', (req: Request, res: Response) => {
  const { all, status, search } = req.query;
  const user = (req as any).user;
  const userRole = user?.role || user?.staffIdentity?.role;
  const isAdmin = user && ['ceo', 'gm', 'super_admin', 'admin', 'manager'].includes(userRole);

  if (all === 'true' && isAdmin) {
    const list = CountryService.getAllCountries({ status: status as string, search: search as string });
    return res.json({ success: true, data: list });
  }

  const enabled = CountryService.getEnabledCountries();
  return res.json({ success: true, data: enabled });
});

// Public / Client App: Get country details by ID or ISO code
router.get('/countries/:id', (req: Request, res: Response) => {
  const country = CountryService.getCountryById(req.params.id);
  if (!country) {
    return res.status(404).json({ success: false, error: 'Country not found' });
  }
  return res.json({ success: true, data: country });
});

// Public / Client App: Get payment methods for specific country
router.get('/countries/:id/payment-methods', (req: Request, res: Response) => {
  const data = CountryService.getCountryPaymentMethods(req.params.id);
  return res.json({ success: true, data });
});

// Admin: Get all countries with associated users count and statistics
router.get('/admin/countries', (req: Request, res: Response) => {
  const user = (req as any).user;
  const userRole = user?.role || user?.staffIdentity?.role;

  if (!user || !['ceo', 'gm', 'super_admin', 'admin', 'manager'].includes(userRole)) {
    return res.status(403).json({ success: false, error: 'Permission denied: Country Management requires staff/admin role' });
  }

  const { status, search } = req.query;
  const countries = CountryService.getAllCountries({ status: status as string, search: search as string });

  // Augment with associated users count
  const data = countries.map(c => ({
    ...c,
    associatedUsersCount: CountryService.getAssociatedUsersCount(c.id)
  }));

  return res.json({
    success: true,
    data,
    total: data.length,
    enabledCount: data.filter(c => c.status === 'enabled').length,
    disabledCount: data.filter(c => c.status === 'disabled').length
  });
});

// Admin: Check associated users count before delete
router.get('/admin/countries/:id/users-count', (req: Request, res: Response) => {
  const user = (req as any).user;
  const userRole = user?.role || user?.staffIdentity?.role;

  if (!user || !['ceo', 'gm', 'super_admin', 'admin', 'manager'].includes(userRole)) {
    return res.status(403).json({ success: false, error: 'Permission denied' });
  }

  const country = CountryService.getCountryById(req.params.id);
  if (!country) {
    return res.status(404).json({ success: false, error: 'Country not found' });
  }

  const count = CountryService.getAssociatedUsersCount(country.id);
  return res.json({
    success: true,
    countryId: country.id,
    countryName: country.name,
    associatedUsersCount: count,
    canDelete: count === 0
  });
});

// Admin: Create new country
router.post('/admin/countries', async (req: Request, res: Response) => {
  const user = (req as any).user;
  const userRole = user?.role || user?.staffIdentity?.role;

  if (!user || !['ceo', 'gm', 'super_admin', 'admin'].includes(userRole)) {
    return res.status(403).json({ success: false, error: 'Permission denied: Only Admin / Staff can create countries' });
  }

  try {
    const createdCountry = await CountryService.createCountry(user, req.body);
    return res.status(201).json({
      success: true,
      data: createdCountry,
      message: `Country "${createdCountry.name}" successfully created.`
    });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message || 'Failed to create country' });
  }
});

// Admin: Update existing country
router.put('/admin/countries/:id', async (req: Request, res: Response) => {
  const user = (req as any).user;
  const userRole = user?.role || user?.staffIdentity?.role;

  if (!user || !['ceo', 'gm', 'super_admin', 'admin'].includes(userRole)) {
    return res.status(403).json({ success: false, error: 'Permission denied: Only Admin / Staff can edit countries' });
  }

  try {
    const updatedCountry = await CountryService.updateCountry(user, req.params.id, req.body);
    return res.json({
      success: true,
      data: updatedCountry,
      message: `Country "${updatedCountry.name}" updated successfully.`
    });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message || 'Failed to update country' });
  }
});

router.patch('/admin/countries/:id', async (req: Request, res: Response) => {
  const user = (req as any).user;
  const userRole = user?.role || user?.staffIdentity?.role;

  if (!user || !['ceo', 'gm', 'super_admin', 'admin'].includes(userRole)) {
    return res.status(403).json({ success: false, error: 'Permission denied' });
  }

  try {
    const updatedCountry = await CountryService.updateCountry(user, req.params.id, req.body);
    return res.json({
      success: true,
      data: updatedCountry,
      message: `Country "${updatedCountry.name}" updated successfully.`
    });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message || 'Failed to update country' });
  }
});

// Admin: Toggle country status (enable / disable)
router.patch('/admin/countries/:id/status', async (req: Request, res: Response) => {
  const user = (req as any).user;
  const userRole = user?.role || user?.staffIdentity?.role;

  if (!user || !['ceo', 'gm', 'super_admin', 'admin'].includes(userRole)) {
    return res.status(403).json({ success: false, error: 'Permission denied' });
  }

  const { status } = req.body;
  if (!status || !['enabled', 'disabled'].includes(status)) {
    return res.status(400).json({ success: false, error: 'Valid status ("enabled" or "disabled") is required' });
  }

  try {
    const updatedCountry = await CountryService.toggleCountryStatus(user, req.params.id, status);
    return res.json({
      success: true,
      data: updatedCountry,
      message: `Country "${updatedCountry.name}" is now ${status}.`
    });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message || 'Failed to change country status' });
  }
});

// Admin: Delete country (Strict Policy: Cannot delete if users associated, use disable instead)
router.delete('/admin/countries/:id', async (req: Request, res: Response) => {
  const user = (req as any).user;
  const userRole = user?.role || user?.staffIdentity?.role;

  if (!user || !['ceo', 'gm', 'super_admin'].includes(userRole)) {
    return res.status(403).json({ success: false, error: 'Permission denied: Country deletion restricted to Super Admin, GM or CEO' });
  }

  try {
    const result = await CountryService.deleteCountry(user, req.params.id);
    return res.json({
      success: true,
      ...result
    });
  } catch (err: any) {
    return res.status(400).json({
      success: false,
      error: err.message || 'Failed to delete country'
    });
  }
});

// =========================================================================
// ADMIN APPEARANCE & BACKGROUND SETTINGS ROUTES
// =========================================================================

// Admin: Get Appearance Settings
router.get('/admin/settings/appearance', (req: Request, res: Response) => {
  const user = (req as any).user;
  const userRole = user?.role || user?.staffIdentity?.role;
  const customPerms = user?.customPermissions || [];

  if (!user || !userRole || !['ceo', 'gm', 'super_admin', 'admin'].includes(userRole)) {
    return res.status(403).json({
      success: false,
      error: '⛔ ACCESS DENIED: Only authorized Admin or Staff personnel can access Admin Appearance Settings.'
    });
  }

  const hasPerm = PermissionService.hasPermission(userRole, 'settings:appearance', customPerms) ||
                  PermissionService.hasPermission(userRole, 'settings:manage', customPerms) ||
                  ['ceo', 'gm', 'super_admin', 'admin'].includes(userRole);

  if (!hasPerm) {
    return res.status(403).json({
      success: false,
      error: '⛔ PERMISSION DENIED: You do not possess the required "settings:appearance" permission.'
    });
  }

  const appearance = dbStore.getAdminAppearance();
  return res.json({
    success: true,
    data: appearance
  });
});

// Admin: Update Appearance Background Color
router.patch('/admin/settings/appearance', async (req: Request, res: Response) => {
  const user = (req as any).user;
  const userRole = user?.role || user?.staffIdentity?.role;
  const customPerms = user?.customPermissions || [];

  if (!user || !userRole || !['ceo', 'gm', 'super_admin', 'admin'].includes(userRole)) {
    return res.status(403).json({
      success: false,
      error: '⛔ ACCESS DENIED: Only authorized Admin or Staff personnel can modify Admin Appearance Settings.'
    });
  }

  const hasPerm = PermissionService.hasPermission(userRole, 'settings:appearance', customPerms) ||
                  PermissionService.hasPermission(userRole, 'settings:manage', customPerms) ||
                  ['ceo', 'gm', 'super_admin', 'admin'].includes(userRole);

  if (!hasPerm) {
    return res.status(403).json({
      success: false,
      error: '⛔ PERMISSION DENIED: You do not possess the required "settings:appearance" permission to change Admin Panel background.'
    });
  }

  const { backgroundColor } = req.body;

  if (!backgroundColor || typeof backgroundColor !== 'string') {
    return res.status(400).json({
      success: false,
      error: 'Missing required field "backgroundColor". Must be a valid HEX color string.'
    });
  }

  const trimmedColor = backgroundColor.trim();
  const hexRegex = /^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$/;
  if (!hexRegex.test(trimmedColor)) {
    return res.status(400).json({
      success: false,
      error: `Invalid background color format "${trimmedColor}". Must be a valid 3 or 6-digit HEX color code (e.g. #0B1020, #1A1033, #0c0618, #FFFFFF).`
    });
  }

  const previousColor = dbStore.adminAppearance?.backgroundColor || '#0c0618';

  const updatedAppearance = {
    backgroundColor: trimmedColor,
    updatedAt: new Date().toISOString(),
    updatedBy: user.id || user.uid,
    updatedByName: user.name || 'Administrator',
    updatedByRole: userRole
  };

  dbStore.setAdminAppearance(updatedAppearance);

  // Asynchronously persist to Firestore database (source of truth)
  await dbStore.persistAdminAppearanceToFirestore(updatedAppearance);

  // Record Audit Log: ADMIN_PANEL_BACKGROUND_CHANGED
  dbStore.recordAudit({
    action: 'ADMIN_PANEL_BACKGROUND_CHANGED',
    module: 'system',
    performedByUserId: user.id || user.uid,
    performedByUserName: user.name,
    performedByRole: userRole,
    targetId: 'admin_panel_appearance',
    targetName: 'Admin Panel Background',
    details: `Admin ${user.name} (${userRole.toUpperCase()}) updated the Admin Panel background color from "${previousColor}" to "${trimmedColor}".`,
    ipAddress: req.ip || (req.headers['x-forwarded-for'] as string) || '127.0.0.1',
    previousColor,
    newColor: trimmedColor
  });

  dbStore.recordStaffActivity({
    staffId: user.id || user.uid,
    staffName: user.name,
    staffRole: userRole,
    actionType: 'ROLE_CHANGE',
    targetResource: 'Admin Panel Appearance',
    details: `Updated background color from ${previousColor} to ${trimmedColor}`,
    ipAddress: req.ip || (req.headers['x-forwarded-for'] as string) || '127.0.0.1'
  });

  return res.json({
    success: true,
    data: updatedAppearance,
    message: `Admin Panel background color updated to ${trimmedColor} successfully.`
  });
});

// Admin: Reset Appearance Background Color to Default (#0c0618)
router.post('/admin/settings/appearance/reset', async (req: Request, res: Response) => {
  const user = (req as any).user;
  const userRole = user?.role || user?.staffIdentity?.role;
  const customPerms = user?.customPermissions || [];

  if (!user || !userRole || !['ceo', 'gm', 'super_admin', 'admin'].includes(userRole)) {
    return res.status(403).json({
      success: false,
      error: '⛔ ACCESS DENIED: Only authorized Admin or Staff personnel can reset Admin Appearance Settings.'
    });
  }

  const hasPerm = PermissionService.hasPermission(userRole, 'settings:appearance', customPerms) ||
                  PermissionService.hasPermission(userRole, 'settings:manage', customPerms) ||
                  ['ceo', 'gm', 'super_admin', 'admin'].includes(userRole);

  if (!hasPerm) {
    return res.status(403).json({
      success: false,
      error: '⛔ PERMISSION DENIED: You do not possess the required "settings:appearance" permission.'
    });
  }

  const previousColor = dbStore.adminAppearance?.backgroundColor || '#0c0618';
  const defaultColor = '#0c0618';

  const resetAppearance = {
    backgroundColor: defaultColor,
    updatedAt: new Date().toISOString(),
    updatedBy: user.id || user.uid,
    updatedByName: user.name || 'Administrator',
    updatedByRole: userRole
  };

  dbStore.setAdminAppearance(resetAppearance);

  await dbStore.persistAdminAppearanceToFirestore(resetAppearance);

  dbStore.recordAudit({
    action: 'ADMIN_PANEL_BACKGROUND_CHANGED',
    module: 'system',
    performedByUserId: user.id || user.uid,
    performedByUserName: user.name,
    performedByRole: userRole,
    targetId: 'admin_panel_appearance',
    targetName: 'Admin Panel Background',
    details: `Admin ${user.name} (${userRole.toUpperCase()}) reset the Admin Panel background color back to system default ("${defaultColor}"). Previous color was "${previousColor}".`,
    ipAddress: req.ip || (req.headers['x-forwarded-for'] as string) || '127.0.0.1',
    previousColor,
    newColor: defaultColor
  });

  dbStore.recordStaffActivity({
    staffId: user.id || user.uid,
    staffName: user.name,
    staffRole: userRole,
    actionType: 'ROLE_CHANGE',
    targetResource: 'Admin Panel Appearance',
    details: `Reset background color to default ${defaultColor}`,
    ipAddress: req.ip || (req.headers['x-forwarded-for'] as string) || '127.0.0.1'
  });

  return res.json({
    success: true,
    data: resetAppearance,
    message: 'Admin Panel background reset to system default (#0c0618) successfully.'
  });
});

// ==========================================
// CONNECTIONS & SOCIAL NETWORKING (CP & FRIENDS)
// ==========================================

// 1. Get Friends
router.get('/connections/friends', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
    const result = ConnectionService.getFriends(user.id);
    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

// 2. Get Friend Requests
router.get('/connections/friend-requests', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
    const result = ConnectionService.getFriendRequests(user.id);
    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

// 3. Get Active CP (Couple / Partner)
router.get('/connections/cp', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
    const cp = ConnectionService.getCP(user.id);
    return res.json({ success: true, data: cp });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

// 4. Get CP Requests
router.get('/connections/cp-requests', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
    const result = ConnectionService.getCPRequests(user.id);
    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

// 5. Send Connection Request (friend or cp)
router.post('/connections/requests', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
    const { receiverId, type, message } = req.body;
    if (!receiverId) return res.status(400).json({ success: false, error: 'receiverId is required' });
    if (!['friend', 'cp'].includes(type)) return res.status(400).json({ success: false, error: 'Invalid connection type' });

    const result = ConnectionService.sendRequest(user.id, receiverId, type, message);
    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

// 6. Accept Connection Request
router.post('/connections/requests/:id/accept', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
    const { id } = req.params;
    const result = ConnectionService.acceptRequest(user.id, id);
    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

// 7. Decline Connection Request
router.post('/connections/requests/:id/decline', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
    const { id } = req.params;
    const result = ConnectionService.declineRequest(user.id, id);
    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

// 8. Cancel Outgoing Connection Request
router.post('/connections/requests/:id/cancel', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
    const { id } = req.params;
    const result = ConnectionService.cancelRequest(user.id, id);
    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

// 9. Remove Connection (unfriend or terminate CP)
router.delete('/connections/:id', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
    const { id } = req.params;
    const result = ConnectionService.removeConnection(user.id, id);
    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

// 10. Discover Users for Connections
router.get('/connections/discover', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
    const search = req.query.search as string;
    const result = ConnectionService.discoverUsers(user.id, search);
    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

// 11. Block User
router.post('/connections/block', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
    const { targetUserId } = req.body;
    if (!targetUserId) return res.status(400).json({ success: false, error: 'targetUserId is required' });
    const result = ConnectionService.blockUser(user.id, targetUserId);
    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

// 12. Unblock User
router.post('/connections/unblock', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
    const { targetUserId } = req.body;
    if (!targetUserId) return res.status(400).json({ success: false, error: 'targetUserId is required' });
    const result = ConnectionService.unblockUser(user.id, targetUserId);
    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

// 13. Get Blocked Users
router.get('/connections/blocked', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
    const result = ConnectionService.getBlockedUsers(user.id);
    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

// ==========================================
// ADMIN CP (COUPLE) & FRIENDSHIP MANAGEMENT
// ==========================================

// 1. Admin Overview & Metrics
router.get('/admin/connections/overview', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user || !PermissionService.hasRoleOrHigher(user.role, 'host')) {
      return res.status(403).json({ success: false, error: 'Administrative permission required' });
    }
    const overview = ConnectionService.getAdminOverview();
    return res.json({ success: true, data: overview });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// 2. Admin Connections List (Filterable & Searchable)
router.get('/admin/connections', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user || !PermissionService.hasRoleOrHigher(user.role, 'host')) {
      return res.status(403).json({ success: false, error: 'Administrative permission required' });
    }
    const { type, status, search, minLevel, sortBy } = req.query;
    const connections = ConnectionService.getAdminConnections({
      type: type as string,
      status: status as string,
      search: search as string,
      minLevel: minLevel ? parseInt(minLevel as string, 10) : undefined,
      sortBy: sortBy as string
    });
    return res.json({ success: true, data: connections });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// 3. Admin Force Create CP Couple
router.post('/admin/connections/cp/create', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user || !PermissionService.hasRoleOrHigher(user.role, 'admin')) {
      return res.status(403).json({ success: false, error: 'Requires Admin or CEO permission' });
    }
    const { user1Id, user2Id, intimacyPoints, level, ceremonyNote, forceOverride } = req.body;
    if (!user1Id || !user2Id) {
      return res.status(400).json({ success: false, error: 'Both user1Id and user2Id are required' });
    }
    const result = ConnectionService.adminCreateCP(
      user1Id,
      user2Id,
      intimacyPoints !== undefined ? Number(intimacyPoints) : 100,
      level !== undefined ? Number(level) : undefined,
      ceremonyNote,
      user,
      Boolean(forceOverride)
    );
    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

// 4. Admin Adjust Intimacy & Level
router.patch('/admin/connections/:id/intimacy', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user || !PermissionService.hasRoleOrHigher(user.role, 'admin')) {
      return res.status(403).json({ success: false, error: 'Requires Admin or CEO permission' });
    }
    const { id } = req.params;
    const { intimacyPoints, level, sharedGiftsCoins, reason } = req.body;
    if (intimacyPoints === undefined) {
      return res.status(400).json({ success: false, error: 'intimacyPoints is required' });
    }
    const result = ConnectionService.adminAdjustIntimacy(
      id,
      Number(intimacyPoints),
      level ? Number(level) : undefined,
      sharedGiftsCoins !== undefined ? Number(sharedGiftsCoins) : undefined,
      reason,
      user
    );
    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

// 5. Admin Terminate / Dissolve Connection (CP or Friend)
router.post('/admin/connections/:id/terminate', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user || !PermissionService.hasRoleOrHigher(user.role, 'admin')) {
      return res.status(403).json({ success: false, error: 'Requires Admin or CEO permission' });
    }
    const { id } = req.params;
    const { reason } = req.body;
    const result = ConnectionService.adminTerminateConnection(id, reason, user);
    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

// 6. Admin Force Create Friendship
router.post('/admin/connections/friend/create', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user || !PermissionService.hasRoleOrHigher(user.role, 'admin')) {
      return res.status(403).json({ success: false, error: 'Requires Admin or CEO permission' });
    }
    const { user1Id, user2Id, note } = req.body;
    if (!user1Id || !user2Id) {
      return res.status(400).json({ success: false, error: 'Both user1Id and user2Id are required' });
    }
    const result = ConnectionService.adminCreateFriendship(user1Id, user2Id, note, user);
    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

// 7. Admin Requests Moderation List
router.get('/admin/connections/requests', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user || !PermissionService.hasRoleOrHigher(user.role, 'host')) {
      return res.status(403).json({ success: false, error: 'Administrative permission required' });
    }
    const { type, status, search } = req.query;
    const requests = ConnectionService.getAdminRequests({
      type: type as string,
      status: status as string,
      search: search as string
    });
    return res.json({ success: true, data: requests });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// 8. Admin Purge / Cancel Request
router.delete('/admin/connections/requests/:id', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user || !PermissionService.hasRoleOrHigher(user.role, 'admin')) {
      return res.status(403).json({ success: false, error: 'Requires Admin or CEO permission' });
    }
    const { id } = req.params;
    ConnectionService.adminPurgeRequest(id, user);
    return res.json({ success: true, message: 'Request purged successfully' });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

// 9. Admin Blocked Users List
router.get('/admin/connections/blocked', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user || !PermissionService.hasRoleOrHigher(user.role, 'host')) {
      return res.status(403).json({ success: false, error: 'Administrative permission required' });
    }
    const search = req.query.search as string;
    const blockedList = ConnectionService.getAdminBlockedUsers(search);
    return res.json({ success: true, data: blockedList });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// 10. Admin Unblock User Pair
router.post('/admin/connections/unblock', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user || !PermissionService.hasRoleOrHigher(user.role, 'admin')) {
      return res.status(403).json({ success: false, error: 'Requires Admin or CEO permission' });
    }
    const { userId, blockedUserId, reason } = req.body;
    if (!userId || !blockedUserId) {
      return res.status(400).json({ success: false, error: 'userId and blockedUserId are required' });
    }
    ConnectionService.adminUnblock(userId, blockedUserId, reason, user);
    return res.json({ success: true, message: 'User unblocked successfully' });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

// 11. Admin Social Rules & Config
router.get('/admin/connections/config', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user || !PermissionService.hasRoleOrHigher(user.role, 'host')) {
      return res.status(403).json({ success: false, error: 'Administrative permission required' });
    }
    const config = ConnectionService.getConnectionConfig();
    return res.json({ success: true, data: config });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

router.patch('/admin/connections/config', (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    if (!user || !PermissionService.hasRoleOrHigher(user.role, 'admin')) {
      return res.status(403).json({ success: false, error: 'Requires Admin or CEO permission' });
    }
    const updated = ConnectionService.updateConnectionConfig(req.body, user);
    return res.json({ success: true, data: updated });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message });
  }
});

// Catch-all 404 handler for any unhandled /api/* endpoint
router.use('*', (req: Request, res: Response) => {
  return res.status(404).json({
    success: false,
    error: `API route not found: ${req.baseUrl}${req.path}`
  });
});

export default router;
