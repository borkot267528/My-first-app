/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { WebSocketServer, WebSocket } from 'ws';
import { Server } from 'http';
import { dbStore } from '../db/store';
import { RoomService } from '../services/room.service';

export interface WsClient extends WebSocket {
  id?: string;
  userId?: string;
  userName?: string;
  roomId?: string;
}

export class RealtimeServer {
  private wss: WebSocketServer;
  private clients: Set<WsClient> = new Set();

  constructor(server: Server) {
    this.wss = new WebSocketServer({ server, path: '/ws' });
    this.wss.on('error', (err) => {
      console.warn('RealtimeServer WebSocket warning:', err.message);
    });
    this.init();
  }

  private init() {
    this.wss.on('connection', (ws: WsClient) => {
      ws.id = `ws-${Date.now()}-${Math.floor(Math.random()*1000)}`;
      this.clients.add(ws);

      ws.on('message', (message: string) => {
        try {
          const data = JSON.parse(message.toString());
          this.handleMessage(ws, data);
        } catch (err) {
          console.error('WebSocket parse error:', err);
        }
      });

      ws.on('close', () => {
        if (ws.roomId && ws.userId) {
          this.broadcastToRoom(ws.roomId, {
            type: 'USER_LEFT',
            payload: { userId: ws.userId, userName: ws.userName }
          });
        }
        this.clients.delete(ws);
      });
    });
  }

  private handleMessage(ws: WsClient, data: { action: string; payload: any }) {
    const { action, payload } = data;

    switch (action) {
      case 'JOIN_ROOM': {
        const { roomId, userId } = payload;
        ws.roomId = roomId;
        ws.userId = userId;
        const user = dbStore.users.get(userId);
        ws.userName = user ? user.name : 'Guest';

        const room = dbStore.rooms.get(roomId);
        if (room) {
          room.onlineCount = Math.max(room.onlineCount, Array.from(this.clients).filter(c => c.roomId === roomId).length);
        }

        // Notify room
        this.broadcastToRoom(roomId, {
          type: 'ROOM_STATE_UPDATED',
          payload: { room }
        });
        break;
      }
      case 'SPEAKING_STATE': {
        const { roomId, seatIndex, isSpeaking } = payload;
        const room = dbStore.rooms.get(roomId);
        if (room && room.seats[seatIndex]) {
          room.seats[seatIndex].isSpeaking = isSpeaking;
          this.broadcastToRoom(roomId, {
            type: 'SEAT_UPDATED',
            payload: { roomId, seatIndex, seat: room.seats[seatIndex] }
          });
        }
        break;
      }
      case 'SEND_CHAT': {
        const { roomId, userId, content, type = 'text', giftId } = payload;
        const user = dbStore.users.get(userId);
        if (user && roomId) {
          const gift = giftId ? dbStore.gifts.get(giftId) : undefined;
          const msg = RoomService.addRoomMessage(roomId, {
            roomId,
            userId: user.id,
            userName: user.name,
            userAvatar: user.avatar,
            vipLevel: user.vipLevel,
            type: gift ? 'gift' : type,
            content,
            giftId: gift?.id,
            giftName: gift?.name,
            giftIcon: gift?.icon
          });

          this.broadcastToRoom(roomId, {
            type: 'NEW_MESSAGE',
            payload: msg
          });
        }
        break;
      }
      case 'TRIGGER_ANIMATION': {
        const { roomId, gift } = payload;
        if (roomId) {
          this.broadcastToRoom(roomId, {
            type: 'GIFT_ANIMATION',
            payload: { gift, senderName: ws.userName }
          });
        }
        break;
      }
      case 'PK_UPDATE': {
        const { roomId, battle } = payload;
        if (roomId) {
          this.broadcastToRoom(roomId, {
            type: 'PK_STATE_UPDATED',
            payload: { battle }
          });
        }
        break;
      }
      case 'MUSIC_TOGGLE': {
        const { roomId, musicPlaying } = payload;
        if (roomId) {
          this.broadcastToRoom(roomId, {
            type: 'MUSIC_STATE_UPDATED',
            payload: { musicPlaying }
          });
        }
        break;
      }
      case 'LUCKY_BAG_DROP': {
        const { roomId, bag } = payload;
        if (roomId) {
          this.broadcastToRoom(roomId, {
            type: 'NEW_LUCKY_BAG',
            payload: { bag }
          });
        }
        break;
      }
      case 'DIRECT_MESSAGE': {
        const { receiverId, message } = payload;
        this.clients.forEach(c => {
          if (c.userId === receiverId && c.readyState === WebSocket.OPEN) {
            c.send(JSON.stringify({ type: 'NEW_DIRECT_MESSAGE', payload: message }));
          }
        });
        break;
      }
    }
  }

  public broadcastToRoom(roomId: string, message: { type: string; payload: any }) {
    const json = JSON.stringify(message);
    this.clients.forEach(c => {
      if (c.roomId === roomId && c.readyState === WebSocket.OPEN) {
        c.send(json);
      }
    });
  }

  public broadcastGlobal(message: { type: string; payload: any }) {
    const json = JSON.stringify(message);
    this.clients.forEach(c => {
      if (c.readyState === WebSocket.OPEN) {
        c.send(json);
      }
    });
  }
}
