/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ApiClient } from '../lib/api';
import { 
  Gift, 
  UserGiftInventoryItem, 
  SendGiftParams, 
  SendGiftResult, 
  GiftInventoryStats 
} from '../types';

export class VirtualGiftService {
  /**
   * Fetches full gift catalog with optional filters and sorting.
   */
  public static async getGiftCatalog(filter?: {
    category?: string;
    search?: string;
    minPrice?: number;
    maxPrice?: number;
    inStockOnly?: boolean;
    sortBy?: 'price_asc' | 'price_desc' | 'popular' | 'name';
  }): Promise<Gift[]> {
    return ApiClient.getGifts(filter);
  }

  /**
   * Fetches gifts together with inventory statistics.
   */
  public static async getInventoryStats(): Promise<{ stats: GiftInventoryStats; catalog: Gift[] }> {
    return ApiClient.getGiftInventoryCatalog();
  }

  /**
   * Gets the currently authenticated user's backpack/inventory gifts.
   */
  public static async getUserBackpack(): Promise<UserGiftInventoryItem[]> {
    return ApiClient.getUserGiftInventory();
  }

  /**
   * Claims an inventory gift item into the user's backpack (e.g. from spin or event).
   */
  public static async claimInventoryGift(giftId: string, quantity: number = 1, source: string = 'reward'): Promise<UserGiftInventoryItem> {
    return ApiClient.claimUserGiftInventory(giftId, quantity, source);
  }

  /**
   * Sends a virtual gift in a voice room or directly to a user.
   * Handles user balance deduction, inventory consumption, and triggers live notifications.
   */
  public static async sendGift(params: SendGiftParams): Promise<SendGiftResult> {
    return ApiClient.sendVirtualGift(params);
  }

  /**
   * Admin/Staff method to add a new virtual gift into the inventory.
   */
  public static async createGift(giftData: Partial<Gift>): Promise<Gift> {
    const res = await ApiClient.manageGiftCatalog('create', { giftData });
    return res;
  }

  /**
   * Admin/Staff method to update an existing gift's inventory properties.
   */
  public static async updateGift(giftId: string, updates: Partial<Gift>): Promise<Gift> {
    const res = await ApiClient.manageGiftCatalog('update', { giftId, updates });
    return res;
  }

  /**
   * Admin/Staff method to delete a gift from the inventory.
   */
  public static async deleteGift(giftId: string): Promise<boolean> {
    await ApiClient.manageGiftCatalog('delete', { giftId });
    return true;
  }

  /**
   * Helper to format diamond yield based on coins spent.
   */
  public static calculateDiamondYield(gift: Gift, count: number): number {
    const totalCoins = gift.priceCoins * count;
    const rate = gift.diamondYieldRate !== undefined ? gift.diamondYieldRate : 0.5;
    return Math.floor(totalCoins * rate);
  }

  /**
   * Helper to get styling for gift rarity badges.
   */
  public static getRarityBadgeStyle(rarity?: Gift['rarity']): { bg: string; text: string; border: string } {
    switch (rarity) {
      case 'mythic':
        return { bg: 'bg-purple-900/60', text: 'text-fuchsia-300', border: 'border-fuchsia-500/50' };
      case 'legendary':
        return { bg: 'bg-amber-900/60', text: 'text-amber-300', border: 'border-amber-500/50' };
      case 'epic':
        return { bg: 'bg-indigo-900/60', text: 'text-indigo-300', border: 'border-indigo-500/50' };
      case 'rare':
        return { bg: 'bg-blue-900/60', text: 'text-sky-300', border: 'border-sky-500/50' };
      case 'common':
      default:
        return { bg: 'bg-slate-800/60', text: 'text-slate-300', border: 'border-white/10' };
    }
  }
}

export default VirtualGiftService;
