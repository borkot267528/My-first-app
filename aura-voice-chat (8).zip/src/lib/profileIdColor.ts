/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface ProfileIdColorInfo {
  range: string;
  groupId: number;
  groupName: string;
  colorHex: string;
  textColor: string;
  textClass: string;
  badgeBg: string;
  badgeBorder: string;
  badgeClass: string;
  gradientClass: string;
  glowClass: string;
  icon: string;
}

/**
 * Extracts a valid numeric value from a Profile ID or UID string/number.
 * Handles strings like "85", "250", "STF-CEO-01" -> 1, "USR-100" -> 100, etc.
 */
export function getProfileIdNumeric(profileId: string | number | undefined | null): number {
  if (profileId === undefined || profileId === null) return 0;
  if (typeof profileId === 'number') {
    return isNaN(profileId) ? 0 : Math.floor(profileId);
  }
  const str = String(profileId).trim();
  // If pure number string
  const directNum = parseInt(str, 10);
  if (!isNaN(directNum) && /^\d+$/.test(str)) {
    return directNum;
  }
  // If mixed string (e.g. "UID-85" or "STF-250"), extract the digits
  const matched = str.match(/\d+/g);
  if (matched && matched.length > 0) {
    const extracted = parseInt(matched.join(''), 10);
    return isNaN(extracted) ? 0 : extracted;
  }
  return 0;
}

/**
 * Core Profile ID Color System Helper.
 * Derives dynamic styling & branding colors based strictly on the current numeric UID range.
 * 
 * Boundary Rules:
 *  - 1–100    -> Color Group 1 (Supreme Mythic Gold)
 *  - 101–199  -> Next / Default Color Group (Emerald Jade)
 *  - 200–300  -> Color Group 2 (Electric Azure Cyan)
 *  - 301–399  -> Next Color Group (Cosmic Orchid Purple)
 *  - 400–499  -> Color Group (Crimson Ruby)
 *  - 500–599  -> Color Group (Solar Amber)
 *  - 600–699  -> Color Group (Neon Lime)
 *  - 700–799  -> Color Group (Cyber Magenta)
 *  - 800–899  -> Color Group (Royal Sapphire)
 *  - 900–999  -> Color Group (Teal Frost)
 *  - 1000–9999-> Color Group (Platinum Titanium)
 *  - 10000+   -> Color Group (Classic Steel)
 */
export function getProfileIdColor(profileId: string | number | undefined | null): ProfileIdColorInfo {
  const num = getProfileIdNumeric(profileId);

  // Group 1: 1 - 100
  if (num >= 1 && num <= 100) {
    return {
      range: '1–100',
      groupId: 1,
      groupName: 'Color Group 1 (Supreme Gold)',
      colorHex: '#f59e0b',
      textColor: 'text-amber-300',
      textClass: 'text-amber-300 font-black',
      badgeBg: 'bg-gradient-to-r from-amber-500/30 via-yellow-400/20 to-amber-600/30',
      badgeBorder: 'border-amber-400/80',
      badgeClass: 'bg-gradient-to-r from-amber-500/25 via-yellow-400/20 to-amber-600/25 border-amber-400/80 text-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.45)]',
      gradientClass: 'from-amber-400 via-yellow-300 to-amber-500',
      glowClass: 'shadow-[0_0_15px_rgba(245,158,11,0.5)]',
      icon: '👑'
    };
  }

  // Next Group: 101 - 199
  if (num >= 101 && num <= 199) {
    return {
      range: '101–199',
      groupId: 2,
      groupName: 'Color Group (Emerald Jade)',
      colorHex: '#10b981',
      textColor: 'text-emerald-300',
      textClass: 'text-emerald-300 font-bold',
      badgeBg: 'bg-gradient-to-r from-emerald-500/30 via-teal-400/20 to-emerald-600/30',
      badgeBorder: 'border-emerald-400/80',
      badgeClass: 'bg-gradient-to-r from-emerald-500/25 via-teal-400/20 to-emerald-600/25 border-emerald-400/80 text-emerald-300 shadow-[0_0_12px_rgba(16,185,129,0.45)]',
      gradientClass: 'from-emerald-400 via-teal-300 to-emerald-500',
      glowClass: 'shadow-[0_0_15px_rgba(16,185,129,0.5)]',
      icon: '🌿'
    };
  }

  // Group 2: 200 - 300
  if (num >= 200 && num <= 300) {
    return {
      range: '200–300',
      groupId: 3,
      groupName: 'Color Group 2 (Electric Cyan)',
      colorHex: '#06b6d4',
      textColor: 'text-cyan-300',
      textClass: 'text-cyan-300 font-bold',
      badgeBg: 'bg-gradient-to-r from-cyan-500/30 via-sky-400/20 to-blue-600/30',
      badgeBorder: 'border-cyan-400/80',
      badgeClass: 'bg-gradient-to-r from-cyan-500/25 via-sky-400/20 to-blue-600/25 border-cyan-400/80 text-cyan-300 shadow-[0_0_12px_rgba(6,182,212,0.45)]',
      gradientClass: 'from-cyan-400 via-sky-300 to-blue-500',
      glowClass: 'shadow-[0_0_15px_rgba(6,182,212,0.5)]',
      icon: '⚡'
    };
  }

  // Next Group: 301 - 399
  if (num >= 301 && num <= 399) {
    return {
      range: '301–399',
      groupId: 4,
      groupName: 'Color Group (Cosmic Orchid)',
      colorHex: '#a855f7',
      textColor: 'text-purple-300',
      textClass: 'text-purple-300 font-bold',
      badgeBg: 'bg-gradient-to-r from-purple-500/30 via-fuchsia-400/20 to-purple-600/30',
      badgeBorder: 'border-purple-400/80',
      badgeClass: 'bg-gradient-to-r from-purple-500/25 via-fuchsia-400/20 to-purple-600/25 border-purple-400/80 text-purple-300 shadow-[0_0_12px_rgba(168,85,247,0.45)]',
      gradientClass: 'from-purple-400 via-fuchsia-300 to-purple-600',
      glowClass: 'shadow-[0_0_15px_rgba(168,85,247,0.5)]',
      icon: '🔮'
    };
  }

  // Group: 400 - 499
  if (num >= 400 && num <= 499) {
    return {
      range: '400–499',
      groupId: 5,
      groupName: 'Color Group (Crimson Ruby)',
      colorHex: '#f43f5e',
      textColor: 'text-rose-300',
      textClass: 'text-rose-300 font-bold',
      badgeBg: 'bg-gradient-to-r from-rose-500/30 via-red-400/20 to-rose-600/30',
      badgeBorder: 'border-rose-400/80',
      badgeClass: 'bg-gradient-to-r from-rose-500/25 via-red-400/20 to-rose-600/25 border-rose-400/80 text-rose-300 shadow-[0_0_12px_rgba(244,63,94,0.45)]',
      gradientClass: 'from-rose-400 via-red-300 to-rose-600',
      glowClass: 'shadow-[0_0_15px_rgba(244,63,94,0.5)]',
      icon: '🔥'
    };
  }

  // Group: 500 - 599
  if (num >= 500 && num <= 599) {
    return {
      range: '500–599',
      groupId: 6,
      groupName: 'Color Group (Solar Amber)',
      colorHex: '#f97316',
      textColor: 'text-orange-300',
      textClass: 'text-orange-300 font-bold',
      badgeBg: 'bg-gradient-to-r from-orange-500/30 via-amber-400/20 to-orange-600/30',
      badgeBorder: 'border-orange-400/80',
      badgeClass: 'bg-gradient-to-r from-orange-500/25 via-amber-400/20 to-orange-600/25 border-orange-400/80 text-orange-300 shadow-[0_0_12px_rgba(249,115,22,0.45)]',
      gradientClass: 'from-orange-400 via-amber-300 to-orange-500',
      glowClass: 'shadow-[0_0_15px_rgba(249,115,22,0.5)]',
      icon: '☀️'
    };
  }

  // Group: 600 - 699
  if (num >= 600 && num <= 699) {
    return {
      range: '600–699',
      groupId: 7,
      groupName: 'Color Group (Neon Lime)',
      colorHex: '#84cc16',
      textColor: 'text-lime-300',
      textClass: 'text-lime-300 font-bold',
      badgeBg: 'bg-gradient-to-r from-lime-500/30 via-green-400/20 to-lime-600/30',
      badgeBorder: 'border-lime-400/80',
      badgeClass: 'bg-gradient-to-r from-lime-500/25 via-green-400/20 to-lime-600/25 border-lime-400/80 text-lime-300 shadow-[0_0_12px_rgba(132,204,22,0.45)]',
      gradientClass: 'from-lime-400 via-green-300 to-lime-500',
      glowClass: 'shadow-[0_0_15px_rgba(132,204,22,0.5)]',
      icon: '🍏'
    };
  }

  // Group: 700 - 799
  if (num >= 700 && num <= 799) {
    return {
      range: '700–799',
      groupId: 8,
      groupName: 'Color Group (Cyber Magenta)',
      colorHex: '#ec4899',
      textColor: 'text-pink-300',
      textClass: 'text-pink-300 font-bold',
      badgeBg: 'bg-gradient-to-r from-pink-500/30 via-rose-400/20 to-pink-600/30',
      badgeBorder: 'border-pink-400/80',
      badgeClass: 'bg-gradient-to-r from-pink-500/25 via-rose-400/20 to-pink-600/25 border-pink-400/80 text-pink-300 shadow-[0_0_12px_rgba(236,72,153,0.45)]',
      gradientClass: 'from-pink-400 via-rose-300 to-pink-500',
      glowClass: 'shadow-[0_0_15px_rgba(236,72,153,0.5)]',
      icon: '💖'
    };
  }

  // Group: 800 - 899
  if (num >= 800 && num <= 899) {
    return {
      range: '800–899',
      groupId: 9,
      groupName: 'Color Group (Royal Sapphire)',
      colorHex: '#6366f1',
      textColor: 'text-indigo-300',
      textClass: 'text-indigo-300 font-bold',
      badgeBg: 'bg-gradient-to-r from-indigo-500/30 via-blue-400/20 to-indigo-600/30',
      badgeBorder: 'border-indigo-400/80',
      badgeClass: 'bg-gradient-to-r from-indigo-500/25 via-blue-400/20 to-indigo-600/25 border-indigo-400/80 text-indigo-300 shadow-[0_0_12px_rgba(99,102,241,0.45)]',
      gradientClass: 'from-indigo-400 via-blue-300 to-indigo-600',
      glowClass: 'shadow-[0_0_15px_rgba(99,102,241,0.5)]',
      icon: '💎'
    };
  }

  // Group: 900 - 999
  if (num >= 900 && num <= 999) {
    return {
      range: '900–999',
      groupId: 10,
      groupName: 'Color Group (Teal Frost)',
      colorHex: '#14b8a6',
      textColor: 'text-teal-300',
      textClass: 'text-teal-300 font-bold',
      badgeBg: 'bg-gradient-to-r from-teal-500/30 via-cyan-400/20 to-teal-600/30',
      badgeBorder: 'border-teal-400/80',
      badgeClass: 'bg-gradient-to-r from-teal-500/25 via-cyan-400/20 to-teal-600/25 border-teal-400/80 text-teal-300 shadow-[0_0_12px_rgba(20,184,166,0.45)]',
      gradientClass: 'from-teal-400 via-cyan-300 to-teal-600',
      glowClass: 'shadow-[0_0_15px_rgba(20,184,166,0.5)]',
      icon: '❄️'
    };
  }

  // Group: 1000 - 9999
  if (num >= 1000 && num <= 9999) {
    return {
      range: '1000–9999',
      groupId: 11,
      groupName: 'Color Group (Platinum Titanium)',
      colorHex: '#e2e8f0',
      textColor: 'text-slate-200',
      textClass: 'text-slate-200 font-bold',
      badgeBg: 'bg-gradient-to-r from-slate-600/40 via-slate-500/30 to-slate-700/40',
      badgeBorder: 'border-slate-300/80',
      badgeClass: 'bg-gradient-to-r from-slate-600/30 via-slate-500/20 to-slate-700/30 border-slate-300/70 text-slate-200 shadow-[0_0_10px_rgba(226,232,240,0.25)]',
      gradientClass: 'from-slate-200 via-slate-100 to-slate-300',
      glowClass: 'shadow-[0_0_12px_rgba(226,232,240,0.3)]',
      icon: '🛡️'
    };
  }

  // Group: 10000+ or default/fallback
  return {
    range: '10000+',
    groupId: 12,
    groupName: 'Color Group (Classic Steel)',
    colorHex: '#94a3b8',
    textColor: 'text-slate-300',
    textClass: 'text-slate-300 font-medium',
    badgeBg: 'bg-black/40',
    badgeBorder: 'border-white/10',
    badgeClass: 'bg-black/40 border-white/15 text-slate-300 shadow-sm',
    gradientClass: 'from-slate-300 via-blue-200 to-slate-400',
    glowClass: 'shadow-sm',
    icon: '🆔'
  };
}

/**
 * Formats a Profile ID for clean presentation (e.g. "85" or "STF-CEO-01").
 */
export function formatProfileId(profileId: string | number | undefined | null): string {
  if (profileId === undefined || profileId === null) return 'N/A';
  return String(profileId).trim();
}
