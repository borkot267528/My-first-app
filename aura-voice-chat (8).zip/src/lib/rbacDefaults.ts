/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { 
  UserRole, 
  PermissionModule, 
  SystemPermission, 
  RolePermissionConfig, 
  PermissionAccessLevel 
} from '../types';

export const DEFAULT_RBAC_MODULES: PermissionModule[] = [
  {
    id: 'mod_user_mgmt',
    key: 'user_management',
    name: 'User Management Center',
    description: 'User profiles, UID customization, moderation, bans, password reset and wallet adjustments.',
    icon: 'Users',
    isCustom: false
  },
  {
    id: 'mod_staff_mgmt',
    key: 'staff_management',
    name: 'Staff & Hierarchy Management',
    description: 'Staff member assignment, roles, dynamic RBAC permission management and audit trail logs.',
    icon: 'Shield',
    isCustom: false
  },
  {
    id: 'mod_voice_room',
    key: 'voice_room',
    name: 'Voice Room Management',
    description: 'Voice room configuration, seat moderation, room lock, audio controls and room closing.',
    icon: 'Mic',
    isCustom: false
  },
  {
    id: 'mod_financial_wallet',
    key: 'financial_wallet',
    name: 'Financial & Wallet Center',
    description: 'Wallet transactions, manual recharges/deductions, withdrawal approval and package management.',
    icon: 'Wallet',
    isCustom: false
  },
  {
    id: 'mod_agency_merchant',
    key: 'agency_merchant',
    name: 'Agency & Merchant Center',
    description: 'Agency applications, commission settlements, recharge agents and coin merchants.',
    icon: 'Building2',
    isCustom: false
  },
  {
    id: 'mod_family_comm',
    key: 'family_community',
    name: 'Family & Community Center',
    description: 'Family guild oversight, creation, editing, suspensions and member governance.',
    icon: 'Crown',
    isCustom: false
  },
  {
    id: 'mod_store_items',
    key: 'store_items',
    name: 'Store & Items Center',
    description: 'Virtual store catalog, gifts, custom animated avatar frames, badges and chat bubbles.',
    icon: 'Gift',
    isCustom: false
  },
  {
    id: 'mod_system_config',
    key: 'system_config',
    name: 'System & App Configuration',
    description: 'Appearance settings, country configurations, promotional banners and maintenance mode.',
    icon: 'Sliders',
    isCustom: false
  }
];

export const DEFAULT_RBAC_PERMISSIONS: SystemPermission[] = [
  // 1. User Management Center
  {
    id: 'perm_users_view',
    key: 'users:view',
    name: 'View Users',
    module: 'user_management',
    description: 'View user directory, profiles, account stats and public information.',
    defaultLevel: 'VIEW'
  },
  {
    id: 'perm_users_edit_profile',
    key: 'users:edit_profile',
    name: 'Edit User Profile',
    module: 'user_management',
    description: 'Modify user nicknames, bios, avatars, frames and profile attributes.',
    defaultLevel: 'MANAGE'
  },
  {
    id: 'perm_users_edit_uid',
    key: 'users:edit_uid',
    name: 'Edit User UID / ID',
    module: 'user_management',
    description: 'Change user vanity numerical profile UID. (CEO Protected Exclusive Action)',
    defaultLevel: 'NONE',
    isCeoProtected: true
  },
  {
    id: 'perm_users_ban',
    key: 'users:ban',
    name: 'Ban / Unban User',
    module: 'user_management',
    description: 'Issue temporary or permanent bans, suspensions, and unban accounts.',
    defaultLevel: 'MANAGE'
  },
  {
    id: 'perm_users_reset_pwd',
    key: 'users:reset_password',
    name: 'Reset User Password',
    module: 'user_management',
    description: 'Authorize security password resets or credential reassignments.',
    defaultLevel: 'MANAGE'
  },
  {
    id: 'perm_wallet_manage_user',
    key: 'wallet:manage_user',
    name: 'Manage User Balance / Wallets',
    module: 'user_management',
    description: 'Adjust user coins, diamonds, and manual transaction balancing.',
    defaultLevel: 'MANAGE'
  },
  {
    id: 'perm_users_assign_badges',
    key: 'users:assign_badges',
    name: 'Assign VIP / SVIP Badges',
    module: 'user_management',
    description: 'Grant or revoke VIP tiers, SVIP subscriptions, and special platform medals.',
    defaultLevel: 'MANAGE'
  },

  // 2. Staff & Hierarchy Management
  {
    id: 'perm_staff_view',
    key: 'staff:view',
    name: 'View Staff',
    module: 'staff_management',
    description: 'Inspect staff roster, active shifts, departments, and position assignments.',
    defaultLevel: 'VIEW'
  },
  {
    id: 'perm_staff_assign_role',
    key: 'staff:assign_role',
    name: 'Assign Staff Role',
    module: 'staff_management',
    description: 'Appoint members to staff roles subject to Role Grant Authority.',
    defaultLevel: 'MANAGE'
  },
  {
    id: 'perm_staff_remove_role',
    key: 'staff:remove_role',
    name: 'Remove Staff Role',
    module: 'staff_management',
    description: 'Revoke staff positions, demote to user, and remove administrative badges.',
    defaultLevel: 'MANAGE'
  },
  {
    id: 'perm_permission_manage',
    key: 'permission:manage',
    name: 'Edit Permissions (Grant Authority)',
    module: 'staff_management',
    description: 'Configure dynamic RBAC matrix, grant authorities, and staff overrides.',
    defaultLevel: 'NONE'
  },
  {
    id: 'perm_audit_view',
    key: 'audit:view',
    name: 'View Audit Logs',
    module: 'staff_management',
    description: 'Examine immutable platform audit trails, security records, and staff actions.',
    defaultLevel: 'VIEW'
  },

  // 3. Voice Room Management
  {
    id: 'perm_rooms_view',
    key: 'rooms:view',
    name: 'View Voice Rooms',
    module: 'voice_room',
    description: 'List active voice rooms, seat occupancies, and live room telemetry.',
    defaultLevel: 'VIEW'
  },
  {
    id: 'perm_rooms_lock',
    key: 'rooms:lock',
    name: 'Lock / Unlock Room',
    module: 'voice_room',
    description: 'Password protect, freeze, or lock voice room entrances.',
    defaultLevel: 'MANAGE'
  },
  {
    id: 'perm_rooms_moderate',
    key: 'rooms:moderate',
    name: 'Kick / Mute User in Room',
    module: 'voice_room',
    description: 'Mute microphone slots, kick abusive speakers, or ban users from room.',
    defaultLevel: 'MANAGE'
  },
  {
    id: 'perm_rooms_close',
    key: 'rooms:close',
    name: 'Close / Delete Room',
    module: 'voice_room',
    description: 'Force-terminate live room sessions and dismantle voice stages.',
    defaultLevel: 'FULL'
  },
  {
    id: 'perm_rooms_seats',
    key: 'rooms:seats',
    name: 'Manage Room Seats',
    module: 'voice_room',
    description: 'Configure speaker seat layouts, lock specific mics, and move listeners.',
    defaultLevel: 'MANAGE'
  },

  // 4. Financial & Wallet Center
  {
    id: 'perm_wallet_view_tx',
    key: 'wallet:view_transactions',
    name: 'View Transactions',
    module: 'financial_wallet',
    description: 'Inspect platform cashflows, coin gifts, diamond conversions and receipts.',
    defaultLevel: 'VIEW'
  },
  {
    id: 'perm_wallet_recharge',
    key: 'wallet:recharge',
    name: 'Manual Balance Recharge',
    module: 'financial_wallet',
    description: 'Credit coin or diamond balances directly to user or merchant accounts.',
    defaultLevel: 'MANAGE'
  },
  {
    id: 'perm_wallet_deduct',
    key: 'wallet:deduct',
    name: 'Manual Balance Deduction',
    module: 'financial_wallet',
    description: 'Deduct coins or diamonds in chargeback, dispute, or correction cases.',
    defaultLevel: 'MANAGE'
  },
  {
    id: 'perm_finance_withdraw',
    key: 'finance:withdraw',
    name: 'Approve / Reject Withdrawals',
    module: 'financial_wallet',
    description: 'Review merchant, agency, and host cash-out requests and disbursements.',
    defaultLevel: 'MANAGE'
  },
  {
    id: 'perm_recharge_packages',
    key: 'recharge:manage_packages',
    name: 'Manage Recharge Packages',
    module: 'financial_wallet',
    description: 'Create, price, discount, and adjust coin recharge packages and bundles.',
    defaultLevel: 'MANAGE'
  },

  // 5. Agency & Merchant Center
  {
    id: 'perm_agency_view',
    key: 'agency:view',
    name: 'View Agencies',
    module: 'agency_merchant',
    description: 'Review agency rosters, registered hosts, and performance statistics.',
    defaultLevel: 'VIEW'
  },
  {
    id: 'perm_agency_approve',
    key: 'agency:approve',
    name: 'Approve Agency Application',
    module: 'agency_merchant',
    description: 'Authorize new talent agencies, sign contracts, and assign quotas.',
    defaultLevel: 'MANAGE'
  },
  {
    id: 'perm_agency_settlement',
    key: 'agency:settlement',
    name: 'Commission Settlement',
    module: 'agency_merchant',
    description: 'Calculate, verify, and disburse agency monthly commission splits.',
    defaultLevel: 'FULL'
  },
  {
    id: 'perm_recharge_agent_view',
    key: 'recharge_agent:view',
    name: 'View Recharge Agents',
    module: 'agency_merchant',
    description: 'Monitor authorized local payment distributors and reseller logs.',
    defaultLevel: 'VIEW'
  },
  {
    id: 'perm_coin_merchant_view',
    key: 'coin_merchant:view',
    name: 'View Coin Merchants',
    module: 'agency_merchant',
    description: 'Audit peer-to-peer coin merchants, escrow reserves, and transfer flows.',
    defaultLevel: 'VIEW'
  },

  // 6. Family & Community Center
  {
    id: 'perm_families_view',
    key: 'families:view',
    name: 'View Families',
    module: 'family_community',
    description: 'Browse community families, rankings, member counts, and activity logs.',
    defaultLevel: 'VIEW'
  },
  {
    id: 'perm_family_create_edit',
    key: 'family:create_edit',
    name: 'Create / Edit Family',
    module: 'family_community',
    description: 'Create new official families, adjust badges, banners, names, and notices.',
    defaultLevel: 'MANAGE'
  },
  {
    id: 'perm_family_suspend_delete',
    key: 'family:suspend_delete',
    name: 'Suspend / Delete Family',
    module: 'family_community',
    description: 'Freeze non-compliant families or delete dissolved organizations.',
    defaultLevel: 'FULL'
  },
  {
    id: 'perm_family_manage_members',
    key: 'family:manage_members',
    name: 'Manage Family Members',
    module: 'family_community',
    description: 'Appoint leaders, co-leaders, elders, or transfer family ownership.',
    defaultLevel: 'MANAGE'
  },

  // 7. Store & Items Center
  {
    id: 'perm_gifts_manage',
    key: 'gifts:manage',
    name: 'Manage Gifts',
    module: 'store_items',
    description: 'Create, upload, animate, and price interactive gifts and lucky bags.',
    defaultLevel: 'MANAGE'
  },
  {
    id: 'perm_store_avatar_frames',
    key: 'store:avatar_frames',
    name: 'Manage Avatar Frames',
    module: 'store_items',
    description: 'Publish luxury dynamic animated avatar border frames in store.',
    defaultLevel: 'MANAGE'
  },
  {
    id: 'perm_store_badges',
    key: 'store:badges',
    name: 'Manage Badges',
    module: 'store_items',
    description: 'Design and distribute honor badges, event badges, and prestige ribbons.',
    defaultLevel: 'MANAGE'
  },
  {
    id: 'perm_store_chat_bubbles',
    key: 'store:chat_bubbles',
    name: 'Manage Chat Bubbles',
    module: 'store_items',
    description: 'Upload custom decorative room chat bubble themes and entry vehicles.',
    defaultLevel: 'MANAGE'
  },

  // 8. System & App Configuration
  {
    id: 'perm_settings_appearance',
    key: 'settings:appearance',
    name: 'Edit App Settings / Appearance',
    module: 'system_config',
    description: 'Configure Admin background colors, branding assets, and layout styling.',
    defaultLevel: 'MANAGE'
  },
  {
    id: 'perm_countries_manage',
    key: 'countries:manage',
    name: 'Manage Countries & Currencies',
    module: 'system_config',
    description: 'Add and toggle countries, dial codes, localized currencies and methods.',
    defaultLevel: 'MANAGE'
  },
  {
    id: 'perm_banner_manage',
    key: 'banner:manage',
    name: 'Manage Banners & Events',
    module: 'system_config',
    description: 'Publish live event announcements, carousel banners, and PK tournaments.',
    defaultLevel: 'MANAGE'
  },
  {
    id: 'perm_system_maintenance',
    key: 'system:maintenance',
    name: 'System Maintenance Mode',
    module: 'system_config',
    description: 'Trigger platform maintenance mode, broadcast alerts, and isolate servers.',
    defaultLevel: 'FULL'
  }
];

export const ACCESS_LEVEL_WEIGHT: Record<PermissionAccessLevel, number> = {
  NONE: 0,
  VIEW: 1,
  OPERATE: 2,
  MANAGE: 3,
  FULL: 4
};

export function isAccessLevelSufficient(
  userLevel: PermissionAccessLevel | undefined, 
  requiredLevel: PermissionAccessLevel = 'VIEW'
): boolean {
  const current = userLevel || 'NONE';
  return ACCESS_LEVEL_WEIGHT[current] >= ACCESS_LEVEL_WEIGHT[requiredLevel];
}

export const DEFAULT_ROLE_CONFIGS: Record<UserRole, RolePermissionConfig> = {
  ceo: {
    id: 'role_ceo',
    roleId: 'ceo',
    roleName: 'Chief Executive Officer (CEO)',
    rank: 100,
    description: 'Supreme executive authority. Unrestricted FULL access to all platform controls and exclusive UID editor.',
    canGrantRoles: ['*'],
    permissions: {
      '*': 'FULL',
      'users:view': 'FULL',
      'users:edit_profile': 'FULL',
      'users:edit_uid': 'FULL',
      'users:ban': 'FULL',
      'users:reset_password': 'FULL',
      'wallet:manage_user': 'FULL',
      'users:assign_badges': 'FULL',
      'staff:view': 'FULL',
      'staff:assign_role': 'FULL',
      'staff:remove_role': 'FULL',
      'permission:manage': 'FULL',
      'audit:view': 'FULL',
      'rooms:view': 'FULL',
      'rooms:lock': 'FULL',
      'rooms:moderate': 'FULL',
      'rooms:close': 'FULL',
      'rooms:seats': 'FULL',
      'wallet:view_transactions': 'FULL',
      'wallet:recharge': 'FULL',
      'wallet:deduct': 'FULL',
      'finance:withdraw': 'FULL',
      'recharge:manage_packages': 'FULL',
      'agency:view': 'FULL',
      'agency:approve': 'FULL',
      'agency:settlement': 'FULL',
      'recharge_agent:view': 'FULL',
      'coin_merchant:view': 'FULL',
      'families:view': 'FULL',
      'family:create_edit': 'FULL',
      'family:suspend_delete': 'FULL',
      'family:manage_members': 'FULL',
      'gifts:manage': 'FULL',
      'store:avatar_frames': 'FULL',
      'store:badges': 'FULL',
      'store:chat_bubbles': 'FULL',
      'settings:appearance': 'FULL',
      'countries:manage': 'FULL',
      'banner:manage': 'FULL',
      'system:maintenance': 'FULL'
    },
    updatedAt: '2025-01-01T00:00:00.000Z',
    updatedBy: 'System'
  },
  gm: {
    id: 'role_gm',
    roleId: 'gm',
    roleName: 'General Manager (GM)',
    rank: 90,
    description: 'Executive management operations. Wide administrative reach with financial and room approval powers.',
    canGrantRoles: ['manager', 'super_admin', 'admin', 'bd', 'seller', 'recharge_agent', 'coin_merchant', 'agency', 'official_staff', 'host', 'user'],
    permissions: {
      'users:view': 'FULL',
      'users:edit_profile': 'FULL',
      'users:edit_uid': 'NONE', // CEO Protected
      'users:ban': 'FULL',
      'users:reset_password': 'MANAGE',
      'wallet:manage_user': 'MANAGE',
      'users:assign_badges': 'FULL',
      'staff:view': 'FULL',
      'staff:assign_role': 'FULL',
      'staff:remove_role': 'MANAGE',
      'permission:manage': 'VIEW',
      'audit:view': 'FULL',
      'rooms:view': 'FULL',
      'rooms:lock': 'FULL',
      'rooms:moderate': 'FULL',
      'rooms:close': 'FULL',
      'rooms:seats': 'FULL',
      'wallet:view_transactions': 'FULL',
      'wallet:recharge': 'MANAGE',
      'wallet:deduct': 'MANAGE',
      'finance:withdraw': 'FULL',
      'recharge:manage_packages': 'FULL',
      'agency:view': 'FULL',
      'agency:approve': 'FULL',
      'agency:settlement': 'FULL',
      'recharge_agent:view': 'FULL',
      'coin_merchant:view': 'FULL',
      'families:view': 'FULL',
      'family:create_edit': 'FULL',
      'family:suspend_delete': 'FULL',
      'family:manage_members': 'FULL',
      'gifts:manage': 'FULL',
      'store:avatar_frames': 'FULL',
      'store:badges': 'FULL',
      'store:chat_bubbles': 'FULL',
      'settings:appearance': 'FULL',
      'countries:manage': 'FULL',
      'banner:manage': 'FULL',
      'system:maintenance': 'VIEW'
    },
    updatedAt: '2025-01-01T00:00:00.000Z',
    updatedBy: 'System'
  },
  manager: {
    id: 'role_manager',
    roleId: 'manager',
    roleName: 'Operations Manager',
    rank: 80,
    description: 'Departmental management, staff supervision, community governance, and room moderation.',
    canGrantRoles: ['admin', 'bd', 'seller', 'recharge_agent', 'coin_merchant', 'agency', 'official_staff', 'host', 'user'],
    permissions: {
      'users:view': 'FULL',
      'users:edit_profile': 'MANAGE',
      'users:edit_uid': 'NONE',
      'users:ban': 'MANAGE',
      'users:reset_password': 'VIEW',
      'wallet:manage_user': 'VIEW',
      'users:assign_badges': 'MANAGE',
      'staff:view': 'VIEW',
      'staff:assign_role': 'MANAGE',
      'staff:remove_role': 'NONE',
      'permission:manage': 'NONE',
      'audit:view': 'VIEW',
      'rooms:view': 'FULL',
      'rooms:lock': 'FULL',
      'rooms:moderate': 'FULL',
      'rooms:close': 'MANAGE',
      'rooms:seats': 'FULL',
      'wallet:view_transactions': 'VIEW',
      'wallet:recharge': 'NONE',
      'wallet:deduct': 'NONE',
      'finance:withdraw': 'VIEW',
      'recharge:manage_packages': 'VIEW',
      'agency:view': 'FULL',
      'agency:approve': 'MANAGE',
      'agency:settlement': 'VIEW',
      'recharge_agent:view': 'VIEW',
      'coin_merchant:view': 'VIEW',
      'families:view': 'FULL',
      'family:create_edit': 'MANAGE',
      'family:suspend_delete': 'NONE',
      'family:manage_members': 'FULL',
      'gifts:manage': 'VIEW',
      'store:avatar_frames': 'VIEW',
      'store:badges': 'VIEW',
      'store:chat_bubbles': 'VIEW',
      'settings:appearance': 'VIEW',
      'countries:manage': 'VIEW',
      'banner:manage': 'MANAGE',
      'system:maintenance': 'NONE'
    },
    updatedAt: '2025-01-01T00:00:00.000Z',
    updatedBy: 'System'
  },
  super_admin: {
    id: 'role_super_admin',
    roleId: 'super_admin',
    roleName: 'Super Administrator',
    rank: 70,
    description: 'Senior administrative authority overseeing moderation, families, and room interventions.',
    canGrantRoles: ['admin', 'official_staff', 'host', 'user'],
    permissions: {
      'users:view': 'FULL',
      'users:edit_profile': 'VIEW',
      'users:edit_uid': 'NONE',
      'users:ban': 'FULL',
      'users:reset_password': 'NONE',
      'wallet:manage_user': 'NONE',
      'users:assign_badges': 'VIEW',
      'staff:view': 'VIEW',
      'staff:assign_role': 'VIEW',
      'staff:remove_role': 'NONE',
      'permission:manage': 'NONE',
      'audit:view': 'VIEW',
      'rooms:view': 'FULL',
      'rooms:lock': 'FULL',
      'rooms:moderate': 'FULL',
      'rooms:close': 'MANAGE',
      'rooms:seats': 'FULL',
      'wallet:view_transactions': 'VIEW',
      'wallet:recharge': 'NONE',
      'wallet:deduct': 'NONE',
      'finance:withdraw': 'NONE',
      'recharge:manage_packages': 'NONE',
      'agency:view': 'VIEW',
      'agency:approve': 'NONE',
      'agency:settlement': 'NONE',
      'recharge_agent:view': 'VIEW',
      'coin_merchant:view': 'VIEW',
      'families:view': 'FULL',
      'family:create_edit': 'MANAGE',
      'family:suspend_delete': 'MANAGE',
      'family:manage_members': 'FULL',
      'gifts:manage': 'NONE',
      'store:avatar_frames': 'NONE',
      'store:badges': 'NONE',
      'store:chat_bubbles': 'NONE',
      'settings:appearance': 'VIEW',
      'countries:manage': 'VIEW',
      'banner:manage': 'MANAGE',
      'system:maintenance': 'NONE'
    },
    updatedAt: '2025-01-01T00:00:00.000Z',
    updatedBy: 'System'
  },
  admin: {
    id: 'role_admin',
    roleId: 'admin',
    roleName: 'Administrator',
    rank: 60,
    description: 'Standard moderation and community supervisor. Enforces platform rules and room conduct.',
    canGrantRoles: [],
    permissions: {
      'users:view': 'FULL',
      'users:edit_profile': 'NONE',
      'users:edit_uid': 'NONE',
      'users:ban': 'MANAGE',
      'users:reset_password': 'NONE',
      'wallet:manage_user': 'NONE',
      'users:assign_badges': 'NONE',
      'staff:view': 'NONE',
      'staff:assign_role': 'NONE',
      'staff:remove_role': 'NONE',
      'permission:manage': 'NONE',
      'audit:view': 'NONE',
      'rooms:view': 'FULL',
      'rooms:lock': 'MANAGE',
      'rooms:moderate': 'FULL',
      'rooms:close': 'NONE',
      'rooms:seats': 'MANAGE',
      'wallet:view_transactions': 'NONE',
      'wallet:recharge': 'NONE',
      'wallet:deduct': 'NONE',
      'finance:withdraw': 'NONE',
      'recharge:manage_packages': 'NONE',
      'agency:view': 'VIEW',
      'agency:approve': 'NONE',
      'agency:settlement': 'NONE',
      'recharge_agent:view': 'NONE',
      'coin_merchant:view': 'NONE',
      'families:view': 'VIEW',
      'family:create_edit': 'VIEW',
      'family:suspend_delete': 'NONE',
      'family:manage_members': 'VIEW',
      'gifts:manage': 'NONE',
      'store:avatar_frames': 'NONE',
      'store:badges': 'NONE',
      'store:chat_bubbles': 'NONE',
      'settings:appearance': 'NONE',
      'countries:manage': 'VIEW',
      'banner:manage': 'VIEW',
      'system:maintenance': 'NONE'
    },
    updatedAt: '2025-01-01T00:00:00.000Z',
    updatedBy: 'System'
  },
  bd: {
    id: 'role_bd',
    roleId: 'bd',
    roleName: 'Business Development (BD)',
    rank: 50,
    description: 'Agency relations, talent recruitment, and creator partner onboarding.',
    canGrantRoles: ['agency', 'host'],
    permissions: {
      'users:view': 'VIEW',
      'agency:view': 'FULL',
      'agency:approve': 'VIEW',
      'rooms:view': 'VIEW',
      'banner:manage': 'VIEW'
    },
    updatedAt: '2025-01-01T00:00:00.000Z',
    updatedBy: 'System'
  },
  seller: {
    id: 'role_seller',
    roleId: 'seller',
    roleName: 'Authorized Item Seller',
    rank: 48,
    description: 'Virtual goods seller, inventory trading, and diamond settlements.',
    canGrantRoles: [],
    permissions: {
      'wallet:view_transactions': 'VIEW',
      'gifts:manage': 'VIEW'
    },
    updatedAt: '2025-01-01T00:00:00.000Z',
    updatedBy: 'System'
  },
  recharge_agent: {
    id: 'role_recharge_agent',
    roleId: 'recharge_agent',
    roleName: 'Recharge Agent',
    rank: 45,
    description: 'Direct coin distribution partner with wallet recharge capabilities.',
    canGrantRoles: [],
    permissions: {
      'wallet:view_transactions': 'VIEW',
      'wallet:recharge': 'MANAGE'
    },
    updatedAt: '2025-01-01T00:00:00.000Z',
    updatedBy: 'System'
  },
  coin_merchant: {
    id: 'role_coin_merchant',
    roleId: 'coin_merchant',
    roleName: 'Coin Merchant',
    rank: 42,
    description: 'Community coin exchange operator and balance remittance.',
    canGrantRoles: [],
    permissions: {
      'wallet:view_transactions': 'VIEW'
    },
    updatedAt: '2025-01-01T00:00:00.000Z',
    updatedBy: 'System'
  },
  agency: {
    id: 'role_agency',
    roleId: 'agency',
    roleName: 'Agency Manager',
    rank: 40,
    description: 'Talent management agency owner overseeing affiliated voice room hosts.',
    canGrantRoles: ['host'],
    permissions: {
      'agency:view': 'VIEW',
      'rooms:view': 'VIEW'
    },
    updatedAt: '2025-01-01T00:00:00.000Z',
    updatedBy: 'System'
  },
  official_staff: {
    id: 'role_official_staff',
    roleId: 'official_staff',
    roleName: 'Official Staff Member',
    rank: 35,
    description: 'Platform representative supporting users and voice room events.',
    canGrantRoles: [],
    permissions: {
      'users:view': 'VIEW',
      'rooms:view': 'VIEW',
      'rooms:moderate': 'VIEW'
    },
    updatedAt: '2025-01-01T00:00:00.000Z',
    updatedBy: 'System'
  },
  host: {
    id: 'role_host',
    roleId: 'host',
    roleName: 'Voice Host / Streamer',
    rank: 30,
    description: 'Certified room host with stage moderation in their own broadcasts.',
    canGrantRoles: [],
    permissions: {
      'rooms:view': 'VIEW',
      'rooms:moderate': 'VIEW',
      'rooms:seats': 'VIEW'
    },
    updatedAt: '2025-01-01T00:00:00.000Z',
    updatedBy: 'System'
  },
  user: {
    id: 'role_user',
    roleId: 'user',
    roleName: 'Standard User',
    rank: 10,
    description: 'Regular platform account with standard user features.',
    canGrantRoles: [],
    permissions: {},
    updatedAt: '2025-01-01T00:00:00.000Z',
    updatedBy: 'System'
  }
};

export const ROLE_HIERARCHY: Record<UserRole, number> = {
  ceo: 100,
  gm: 90,
  manager: 80,
  super_admin: 70,
  admin: 60,
  bd: 50,
  seller: 48,
  recharge_agent: 45,
  coin_merchant: 42,
  agency: 40,
  official_staff: 35,
  host: 30,
  user: 10
};
