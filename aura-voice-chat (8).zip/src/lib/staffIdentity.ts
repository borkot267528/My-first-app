/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { User, UserRole, StaffIdentity } from '../types';

export interface StaffRoleConfig {
  role: UserRole;
  name: string;
  title: string;
  badge: string;
  badgeIcon: string;
  frame: string;
  background: string;
  department: string;
  bgClasses: string;
  badgeStyle: string;
  textColor: string;
  borderColor: string;
  gradientHeader: string;
  defaultStaffIdPrefix: string;
}

export interface StaffPositionOption {
  id: UserRole;
  label: string;
  name: string;
  icon: string;
  department: string;
  description: string;
}

export const STAFF_IDENTITY_CONFIG: Record<string, StaffRoleConfig> = {
  ceo: {
    role: 'ceo',
    name: 'CEO',
    title: 'Chief Executive Officer',
    badge: '👑 CEO',
    badgeIcon: '👑',
    frame: '👑 Golden Monarch Frame',
    background: '🌌 Nebula Deep Glass',
    department: 'Executive Board',
    bgClasses: 'bg-gradient-to-br from-amber-500/40 via-purple-900/60 to-yellow-500/40 border-amber-400/50 shadow-[0_0_30px_rgba(245,158,11,0.35)]',
    badgeStyle: 'bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500 text-black font-black border border-amber-300 shadow-md',
    textColor: 'text-amber-300',
    borderColor: 'border-amber-400/50',
    gradientHeader: 'from-amber-400 via-yellow-300 to-amber-500',
    defaultStaffIdPrefix: 'STF-CEO-'
  },
  gm: {
    role: 'gm',
    name: 'General Manager',
    title: 'General Manager',
    badge: '⚡ General Manager',
    badgeIcon: '⚡',
    frame: '⚡ Arc Electric Frame',
    background: '🌊 Deep Azure Glass',
    department: 'Regional Operations',
    bgClasses: 'bg-gradient-to-br from-blue-950 via-slate-900 to-indigo-950 border-blue-500/40 shadow-[0_0_25px_rgba(59,130,246,0.25)]',
    badgeStyle: 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-black border border-blue-400/50 shadow',
    textColor: 'text-blue-300',
    borderColor: 'border-blue-500/40',
    gradientHeader: 'from-blue-400 to-indigo-400',
    defaultStaffIdPrefix: 'STF-GM-'
  },
  manager: {
    role: 'manager',
    name: 'Manager',
    title: 'Operations Manager',
    badge: '🛡️ Manager',
    badgeIcon: '🛡️',
    frame: '🛡️ Aegis Shield Frame',
    background: '🌲 Emerald Frost Glass',
    department: 'Guild & Platform Ops',
    bgClasses: 'bg-gradient-to-br from-emerald-950 via-teal-900 to-slate-900 border-emerald-500/40 shadow-[0_0_25px_rgba(16,185,129,0.25)]',
    badgeStyle: 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-black border border-emerald-400/50 shadow',
    textColor: 'text-emerald-300',
    borderColor: 'border-emerald-500/40',
    gradientHeader: 'from-emerald-400 to-teal-400',
    defaultStaffIdPrefix: 'STF-MGR-'
  },
  super_admin: {
    role: 'super_admin',
    name: 'Super Admin',
    title: 'Super Administrator',
    badge: '🔥 Super Admin',
    badgeIcon: '🔥',
    frame: '🔥 Infernal Phoenix Frame',
    background: '🌋 Obsidian Red Glass',
    department: 'Security & Governance',
    bgClasses: 'bg-gradient-to-br from-rose-950 via-red-900 to-slate-900 border-red-500/40 shadow-[0_0_25px_rgba(239,68,68,0.25)]',
    badgeStyle: 'bg-gradient-to-r from-rose-600 to-red-600 text-white font-black border border-red-400/50 shadow',
    textColor: 'text-rose-300',
    borderColor: 'border-red-500/40',
    gradientHeader: 'from-rose-400 to-red-400',
    defaultStaffIdPrefix: 'STF-SADM-'
  },
  admin: {
    role: 'admin',
    name: 'Admin',
    title: 'Platform Administrator',
    badge: '⚔️ Admin',
    badgeIcon: '⚔️',
    frame: '⚔️ Vanguard Blade Frame',
    background: '🍊 Ember Glow Glass',
    department: 'Moderation & Safety',
    bgClasses: 'bg-gradient-to-br from-orange-950 via-amber-900 to-slate-900 border-orange-500/40 shadow-[0_0_25px_rgba(249,115,22,0.25)]',
    badgeStyle: 'bg-gradient-to-r from-orange-600 to-amber-600 text-white font-black border border-orange-400/50 shadow',
    textColor: 'text-orange-300',
    borderColor: 'border-orange-500/40',
    gradientHeader: 'from-orange-400 to-amber-400',
    defaultStaffIdPrefix: 'STF-ADM-'
  },
  bd: {
    role: 'bd',
    name: 'BD',
    title: 'Business Development',
    badge: '💼 BD',
    badgeIcon: '💼',
    frame: '💼 Platinum Executive Frame',
    background: '🏙️ Cyan Horizon Glass',
    department: 'Global Partnerships',
    bgClasses: 'bg-gradient-to-br from-cyan-950 via-teal-900 to-slate-900 border-cyan-500/40 shadow-[0_0_25px_rgba(6,182,212,0.25)]',
    badgeStyle: 'bg-gradient-to-r from-cyan-500 to-teal-500 text-black font-black border border-cyan-300 shadow',
    textColor: 'text-cyan-300',
    borderColor: 'border-cyan-500/40',
    gradientHeader: 'from-cyan-400 to-teal-400',
    defaultStaffIdPrefix: 'STF-BD-'
  },
  seller: {
    role: 'seller',
    name: 'Seller',
    title: 'Official Seller',
    badge: '🏷️ Seller',
    badgeIcon: '🏷️',
    frame: '🏷️ Merchant Guild Frame',
    background: '🪙 Golden Amber Glass',
    department: 'Commerce & Marketplace',
    bgClasses: 'bg-gradient-to-br from-amber-950 via-yellow-950 to-slate-900 border-amber-500/40 shadow-[0_0_25px_rgba(245,158,11,0.25)]',
    badgeStyle: 'bg-gradient-to-r from-amber-500 to-yellow-500 text-black font-black border border-amber-300 shadow',
    textColor: 'text-amber-300',
    borderColor: 'border-amber-500/40',
    gradientHeader: 'from-amber-400 to-yellow-400',
    defaultStaffIdPrefix: 'STF-SLR-'
  },
  agency: {
    role: 'agency',
    name: 'Agency',
    title: 'Talent Agency Guild',
    badge: '🏛️ Agency',
    badgeIcon: '🏛️',
    frame: '🏛️ Imperial Guild Frame',
    background: '🍇 Amethyst Velvet Glass',
    department: 'Talent Operations',
    bgClasses: 'bg-gradient-to-br from-purple-950 via-violet-900 to-slate-900 border-purple-500/40 shadow-[0_0_25px_rgba(168,85,247,0.25)]',
    badgeStyle: 'bg-gradient-to-r from-purple-600 to-violet-600 text-white font-black border border-purple-400/50 shadow',
    textColor: 'text-purple-300',
    borderColor: 'border-purple-500/40',
    gradientHeader: 'from-purple-400 to-violet-400',
    defaultStaffIdPrefix: 'STF-AGY-'
  },
  host: {
    role: 'host',
    name: 'Host',
    title: 'Official Streamer Host',
    badge: '🎤 Host',
    badgeIcon: '🎤',
    frame: '🎤 Diamond Spotlight Frame',
    background: '🌸 Rose Quartz Glass',
    department: 'Live Broadcasting',
    bgClasses: 'bg-gradient-to-br from-pink-950 via-rose-900 to-slate-900 border-pink-500/40 shadow-[0_0_25px_rgba(236,72,153,0.25)]',
    badgeStyle: 'bg-gradient-to-r from-pink-600 to-rose-600 text-white font-black border border-pink-400/50 shadow',
    textColor: 'text-pink-300',
    borderColor: 'border-pink-500/40',
    gradientHeader: 'from-pink-400 to-rose-400',
    defaultStaffIdPrefix: 'STF-HST-'
  },
  recharge_agent: {
    role: 'recharge_agent',
    name: 'Recharge Agent',
    title: 'Recharge Agent',
    badge: '💳 Recharge Agent',
    badgeIcon: '💳',
    frame: '💳 Emerald Vault Frame',
    background: '🌿 Jade Mint Glass',
    department: 'Payment Gateway',
    bgClasses: 'bg-gradient-to-br from-green-950 via-emerald-900 to-slate-900 border-green-500/40 shadow-[0_0_25px_rgba(34,197,94,0.25)]',
    badgeStyle: 'bg-gradient-to-r from-green-600 to-emerald-600 text-white font-black border border-green-400/50 shadow',
    textColor: 'text-green-300',
    borderColor: 'border-green-500/40',
    gradientHeader: 'from-green-400 to-emerald-400',
    defaultStaffIdPrefix: 'STF-RCH-'
  },
  coin_merchant: {
    role: 'coin_merchant',
    name: 'Coin Merchant',
    title: 'Coin Merchant',
    badge: '🪙 Coin Merchant',
    badgeIcon: '🪙',
    frame: '🪙 Silver Aureus Frame',
    background: '🌫️ Metallic Frost Glass',
    department: 'P2P Exchange',
    bgClasses: 'bg-gradient-to-br from-slate-800 via-gray-700 to-slate-900 border-slate-400/50 shadow-[0_0_25px_rgba(148,163,184,0.25)]',
    badgeStyle: 'bg-gradient-to-r from-slate-300 via-gray-200 to-slate-400 text-slate-950 font-black border border-slate-200 shadow',
    textColor: 'text-slate-200',
    borderColor: 'border-slate-400/50',
    gradientHeader: 'from-slate-200 to-gray-300',
    defaultStaffIdPrefix: 'STF-MCH-'
  },
  official_staff: {
    role: 'official_staff',
    name: 'Official Staff',
    title: 'Official Staff',
    badge: '🌟 Official Staff',
    badgeIcon: '🌟',
    frame: '🌟 Astral Stellar Frame',
    background: '🌑 Midnight Glass',
    department: 'Platform Operations',
    bgClasses: 'bg-gradient-to-br from-black via-zinc-900 to-neutral-950 border-zinc-700/60 shadow-[0_0_25px_rgba(0,0,0,0.6)]',
    badgeStyle: 'bg-gradient-to-r from-zinc-800 to-zinc-900 text-amber-300 font-black border border-amber-400/40 shadow',
    textColor: 'text-zinc-300',
    borderColor: 'border-zinc-700/60',
    gradientHeader: 'from-zinc-300 to-amber-300',
    defaultStaffIdPrefix: 'STF-OFF-'
  }
};

export const AVAILABLE_STAFF_POSITIONS: StaffPositionOption[] = [
  { id: 'manager', label: 'Manager', name: 'Manager', icon: '🛡️', department: 'Guild & Platform Ops', description: 'Operations & Community Management' },
  { id: 'super_admin', label: 'Super Admin', name: 'Super Admin', icon: '🔥', department: 'Security & Governance', description: 'Advanced Platform & Security Control' },
  { id: 'admin', label: 'Admin', name: 'Admin', icon: '⚔️', department: 'Moderation & Safety', description: 'Moderation, Chat Safety & User Governance' },
  { id: 'bd', label: 'BD', name: 'Business Development', icon: '💼', department: 'Global Partnerships', description: 'Business Partnerships & Guild Expansion' },
  { id: 'seller', label: 'Seller', name: 'Seller', icon: '🏷️', department: 'Commerce & Marketplace', description: 'Official Diamond & Asset Seller' },
  { id: 'ceo', label: 'CEO', name: 'Chief Executive Officer', icon: '👑', department: 'Executive Board', description: 'Executive Leadership & Full Ownership' },
  { id: 'gm', label: 'General Manager', name: 'General Manager', icon: '⚡', department: 'Regional Operations', description: 'Regional Management & Operations' },
  { id: 'agency', label: 'Agency', name: 'Talent Agency', icon: '🏛️', department: 'Talent Operations', description: 'Host Recruiting & Agency Guild Head' },
  { id: 'host', label: 'Host', name: 'Official Host', icon: '🎤', department: 'Live Broadcasting', description: 'Verified Streamer & Broadcaster' },
  { id: 'recharge_agent', label: 'Recharge Agent', name: 'Recharge Agent', icon: '💳', department: 'Payment Gateway', description: 'Authorized Direct Recharge Partner' },
  { id: 'coin_merchant', label: 'Coin Merchant', name: 'Coin Merchant', icon: '🪙', department: 'P2P Exchange', description: 'Authorized Coin Reseller / Exchange' },
  { id: 'official_staff', label: 'Official Staff', name: 'Official Staff', icon: '🌟', department: 'Platform Operations', description: 'General Platform Staff & Support' }
];

export interface ResolvedStaffRole {
  role: UserRole;
  name: string;
  title: string;
  badge: string;
  badgeIcon: string;
  badgeStyle: string;
  textColor: string;
  department: string;
  config: StaffRoleConfig;
}

/**
 * Returns a list of all resolved role information for every assigned position in a StaffIdentity.
 */
export function getStaffIdentitiesList(identity: StaffIdentity | null | undefined): ResolvedStaffRole[] {
  if (!identity) return [];

  const rawRoles = identity.roles && identity.roles.length > 0 
    ? identity.roles 
    : (identity.role ? [identity.role] : ['official_staff']);

  // Filter and deduplicate
  const uniqueRoles = Array.from(new Set(rawRoles)) as UserRole[];

  return uniqueRoles.map(r => {
    const config = STAFF_IDENTITY_CONFIG[r] || STAFF_IDENTITY_CONFIG['official_staff'] || {
      role: r,
      name: r.toUpperCase(),
      title: r.toUpperCase(),
      badge: `🌟 ${r}`,
      badgeIcon: '🌟',
      frame: '✨ Golden Frame',
      background: '🌌 Dark Glass',
      department: 'Staff Operations',
      bgClasses: 'bg-white/5 border-white/10',
      badgeStyle: 'bg-white/10 text-white',
      textColor: 'text-white',
      borderColor: 'border-white/20',
      gradientHeader: 'from-amber-400 to-yellow-400',
      defaultStaffIdPrefix: 'STF-'
    };

    return {
      role: r,
      name: config.name,
      title: config.title,
      badge: config.badge,
      badgeIcon: config.badgeIcon,
      badgeStyle: config.badgeStyle,
      textColor: config.textColor,
      department: config.department,
      config
    };
  });
}

/**
 * Returns the effective staff identity object for a given user.
 * Supports multiple roles (roles: string[]) and guarantees backward compatibility.
 */
export function getEffectiveStaffIdentity(user: Partial<User> | null | undefined): StaffIdentity | null {
  if (!user) return null;

  if (user.staffIdentity) {
    const existing = user.staffIdentity;
    const rawRoles = existing.roles && existing.roles.length > 0 
      ? existing.roles 
      : (existing.role ? [existing.role] : ['official_staff']);

    const uniqueRoles = Array.from(new Set(rawRoles)) as UserRole[];
    const primaryRole = uniqueRoles[0] || 'official_staff';
    const primaryConfig = STAFF_IDENTITY_CONFIG[primaryRole] || STAFF_IDENTITY_CONFIG['official_staff'];

    const titles = uniqueRoles.map(r => (STAFF_IDENTITY_CONFIG[r]?.name || STAFF_IDENTITY_CONFIG[r]?.title || r));
    const badges = uniqueRoles.map(r => (STAFF_IDENTITY_CONFIG[r]?.badge || `🌟 ${r}`));
    const joinedTitle = titles.join(' • ');
    const joinedBadge = badges.join(' • ');

    return {
      ...existing,
      role: primaryRole,
      roles: uniqueRoles,
      positions: uniqueRoles,
      title: existing.title || joinedTitle,
      titles,
      badge: existing.badge || joinedBadge,
      badges,
      frame: existing.frame || user.frame || primaryConfig?.frame || '👑 Golden Monarch Frame',
      background: existing.background || user.background || primaryConfig?.background || '🌌 Nebula Deep Glass'
    };
  }

  const role = user.role;
  if (!role || role === 'user' || !STAFF_IDENTITY_CONFIG[role]) {
    // Standard User Receiving Identity
    return {
      role: 'user',
      roles: ['user'],
      positions: ['user'],
      badge: user.vipLevel === 'svip' ? '💎 SVIP Elite' : user.vipLevel === 'vip' ? '👑 VIP Member' : '⭐ Member',
      badges: [user.vipLevel === 'svip' ? '💎 SVIP Elite' : user.vipLevel === 'vip' ? '👑 VIP Member' : '⭐ Member'],
      title: user.vipLevel === 'svip' ? 'SVIP Elite Member' : user.vipLevel === 'vip' ? 'VIP Preferred Member' : 'Verified Community Member',
      titles: [user.vipLevel === 'svip' ? 'SVIP Elite Member' : user.vipLevel === 'vip' ? 'VIP Preferred Member' : 'Verified Community Member'],
      frame: user.frame || '✨ Star Glow Frame',
      background: user.background || '🌌 Nebula Deep Glass',
      staffId: `USR-${user.uid || user.id || '880000'}`,
      staffLevel: user.level || 1,
      isVerified: user.vipLevel === 'svip' || user.vipLevel === 'vip' || true,
      department: 'Community & Voice',
      joinedDate: user.createdAt ? new Date(user.createdAt).toISOString().split('T')[0] : '2025-01-01',
      activeStatus: user.isOnline ? 'Active' : 'Offline'
    };
  }

  const config = STAFF_IDENTITY_CONFIG[role];
  return {
    role: role as UserRole,
    roles: [role as UserRole],
    positions: [role as UserRole],
    badge: config.badge,
    badges: [config.badge],
    title: config.title,
    titles: [config.name || config.title],
    frame: user.frame || config.frame,
    background: user.background || config.background,
    staffId: `${config.defaultStaffIdPrefix}${user.uid || user.id || '880000'}`,
    staffLevel: role === 'ceo' ? 10 : role === 'gm' ? 8 : role === 'super_admin' ? 7 : 5,
    isVerified: true,
    department: config.department,
    joinedDate: user.createdAt ? new Date(user.createdAt).toISOString().split('T')[0] : '2025-01-01',
    activeStatus: user.isOnline ? 'Active' : 'On Shift'
  };
}
