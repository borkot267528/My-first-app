/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { 
  User, VoiceRoom, Gift, Family, FamilyMember, FamilyApplication, WalletTransaction, LuckyBag, RoomMessage,
  RechargePackage, StaffActivityLog, NotificationItem, ReportItem, AnalyticsOverview, PrivateMessage, PkBattle, Banner,
  Agency, RechargeAgent, Merchant, WithdrawPaymentMethod, BanRecord, Country, CountryFormData,
  PermissionModule, SystemPermission, RolePermissionConfig, StaffPermissionOverride, UserRole,
  Connection, ConnectionRequest, BlockedUserRecord, ConnectionType, AdminAppearanceSettings,
  AdminConnectionOverview, ConnectionSystemConfig,
  UserGiftInventoryItem, SendGiftParams, SendGiftResult, GiftInventoryStats,
  RoomToolsState, RoomMusicState, RoomYouTubeState, RoomCPInteractionState, RoomGameState,
  ContributorLeaderboardCategory, ContributorLeaderboardPeriod, ContributorLeaderboardResponse
} from '../types';

export function getProductionBaseUrl(): string {
  if (typeof window !== 'undefined' && window.location && window.location.origin && window.location.origin.startsWith('http')) {
    return window.location.origin.replace(/\/$/, '');
  }
  const envUrl = (import.meta as any).env?.VITE_APP_URL || (import.meta as any).env?.VITE_SERVER_URL;
  if (envUrl && envUrl.startsWith('http')) {
    return envUrl.replace(/\/$/, '');
  }
  return '';
}

export function isCapacitorNative(): boolean {
  if (typeof window === 'undefined') return false;
  const cap = (window as any).Capacitor;
  if (cap && typeof cap.isNativePlatform === 'function') {
    return cap.isNativePlatform();
  }
  return window.location.protocol === 'capacitor:';
}

export function getApiBaseUrl(): string {
  if (isCapacitorNative()) {
    const base = getProductionBaseUrl();
    return base ? `${base}/api` : '/api';
  }
  return '/api';
}

export function getWebSocketUrl(): string {
  if (isCapacitorNative()) {
    const base = getProductionBaseUrl().replace(/^http/, 'ws');
    return base ? `${base}/ws` : '/ws';
  }
  if (typeof window !== 'undefined') {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    return `${protocol}//${window.location.host}/ws`;
  }
  return '/ws';
}

const API_BASE = {
  toString() {
    return getApiBaseUrl();
  }
};

export class ApiClient {
  private static getHeaders() {
    const activeUserId = localStorage.getItem('aura_demo_user_id') || '2383452';
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'X-Demo-User-Id': activeUserId
    };
    const token = localStorage.getItem('aura_access_token');
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    return headers;
  }

  private static async safeFetch(url: string, init?: RequestInit, retries = 2): Promise<any> {
    let lastError: any = null;
    let targetUrl = url;
    if (typeof window !== 'undefined' && url.startsWith('/')) {
      targetUrl = window.location.origin + url;
    }
    for (let attempt = 0; attempt <= retries; attempt++) {
      try {
        const res = await fetch(targetUrl, init);
        const contentType = res.headers.get('content-type') || '';
        if (!contentType.includes('application/json')) {
          const text = await res.text();
          throw new Error(`API returned non-JSON (${res.status}): ${text.slice(0, 80)}`);
        }
        const json = await res.json();
        if (!res.ok) {
          const errMsg = (json && (json.error || json.message)) || `HTTP ${res.status} ${res.statusText}`;
          throw new Error(errMsg);
        }
        return json;
      } catch (err: any) {
        lastError = err;
        if (attempt < retries) {
          await new Promise(resolve => setTimeout(resolve, 250 * (attempt + 1)));
        }
      }
    }
    console.warn(`ApiClient fetch failed after retries for ${targetUrl}:`, lastError?.message);
    throw lastError || new Error(`Failed to connect to ${targetUrl}`);
  }

  public static async getMe(): Promise<User> {
    const json = await this.safeFetch(`${API_BASE}/auth/me`, { headers: this.getHeaders() });
    if (!json.success || !json.data) throw new Error(json.error || 'Failed to fetch user');
    return json.data;
  }

  public static async updateProfile(data: {
    name?: string;
    uid?: string;
    nigoId?: string;
    avatar?: string;
    bio?: string;
    gender?: 'male' | 'female' | 'other';
    country?: string;
    countryFlag?: string;
  }): Promise<User> {
    const json = await this.safeFetch(`${API_BASE}/users/profile`, {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!json.success || !json.data) throw new Error(json.error || 'Failed to update profile');
    return json.data;
  }

  public static async searchUsers(
    queryText: string, 
    options?: { filter?: string; limit?: number }
  ): Promise<User[]> {
    const params = new URLSearchParams();
    if (queryText) params.set('q', queryText);
    if (options?.filter && options.filter !== 'all') params.set('filter', options.filter);
    if (options?.limit) params.set('limit', String(options.limit));

    const json = await this.safeFetch(`${API_BASE}/users/search?${params.toString()}`, {
      headers: this.getHeaders()
    });
    if (!json.success || !json.data) return [];
    return json.data;
  }

  public static async login(email: string, password?: string): Promise<{ user: User; token: string }> {
    const json = await this.safeFetch(`${API_BASE}/auth/login`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ email, password })
    });
    if (json.success && json.data) {
      localStorage.setItem('aura_access_token', json.data.tokens.accessToken);
      localStorage.setItem('aura_demo_user_id', json.data.user.id);
      return { user: json.data.user, token: json.data.tokens.accessToken };
    }
    throw new Error(json.error || 'Login failed');
  }

  public static async syncFirebaseAuth(
    firebaseUid: string, 
    email: string, 
    displayName?: string, 
    avatar?: string,
    profile?: Partial<User>
  ): Promise<{ user: User; token: string }> {
    const json = await this.safeFetch(`${API_BASE}/auth/firebase`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ 
        firebaseUid, 
        email, 
        displayName, 
        avatar, 
        profile,
        nigoId: profile?.uid || profile?.nigoId,
        phone: profile?.phone,
        country: profile?.country,
        countryFlag: profile?.countryFlag,
        gender: profile?.gender
      })
    });
    if (json.success && json.data) {
      localStorage.setItem('aura_access_token', json.data.tokens.accessToken);
      localStorage.setItem('aura_demo_user_id', json.data.user.id);
      return { user: json.data.user, token: json.data.tokens.accessToken };
    }
    throw new Error(json.error || 'Firebase authentication sync failed');
  }

  public static async simulateFirebaseAuth(firebaseUid: string, email: string, displayName?: string, avatar?: string): Promise<{ user: User; token: string }> {
    return this.syncFirebaseAuth(firebaseUid, email, displayName, avatar);
  }

  public static async getRooms(category?: string, search?: string): Promise<VoiceRoom[]> {
    const params = new URLSearchParams();
    if (category && category !== 'all') params.append('category', category);
    if (search) params.append('search', search);
    
    const json = await this.safeFetch(`${API_BASE}/rooms?${params.toString()}`, { headers: this.getHeaders() });
    return json.data || [];
  }

  public static async getRoomById(id: string): Promise<{ room: VoiceRoom; messages: RoomMessage[] }> {
    const json = await this.safeFetch(`${API_BASE}/rooms/${id}`, { headers: this.getHeaders() });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async createRoom(title: string, topic: string, category: string): Promise<VoiceRoom> {
    const json = await this.safeFetch(`${API_BASE}/rooms`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ title, topic, category })
    });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async updateRoomTheme(roomId: string, theme: string, backgroundUrl?: string): Promise<VoiceRoom> {
    const json = await this.safeFetch(`${API_BASE}/rooms/${roomId}/theme`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ theme, backgroundUrl })
    });
    if (!json.success) throw new Error(json.error || 'Failed to update room theme');
    return json.data;
  }

  // Room Tools & Entertainment methods
  public static async getRoomTools(roomId: string): Promise<RoomToolsState> {
    const json = await this.safeFetch(`${API_BASE}/rooms/${roomId}/tools`, { headers: this.getHeaders() });
    if (!json.success) throw new Error(json.error || 'Failed to fetch room tools');
    return json.data;
  }

  public static async setActiveRoomTool(roomId: string, activeTool: string): Promise<RoomToolsState> {
    const json = await this.safeFetch(`${API_BASE}/rooms/${roomId}/tools/active`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ activeTool })
    });
    if (!json.success) throw new Error(json.error || 'Failed to set active room tool');
    return json.data;
  }

  public static async updateRoomMusic(roomId: string, payload: any): Promise<RoomMusicState> {
    const json = await this.safeFetch(`${API_BASE}/rooms/${roomId}/tools/music`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(payload)
    });
    if (!json.success) throw new Error(json.error || 'Failed to update music');
    return json.data;
  }

  public static async updateRoomYouTube(roomId: string, payload: any): Promise<RoomYouTubeState> {
    const json = await this.safeFetch(`${API_BASE}/rooms/${roomId}/tools/youtube`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(payload)
    });
    if (!json.success) throw new Error(json.error || 'Failed to update youtube');
    return json.data;
  }

  public static async updateRoomCP(roomId: string, payload: any): Promise<RoomCPInteractionState> {
    const json = await this.safeFetch(`${API_BASE}/rooms/${roomId}/tools/cp`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(payload)
    });
    if (!json.success) throw new Error(json.error || 'Failed to update couple interaction');
    return json.data;
  }

  public static async updateRoomPK(roomId: string, payload: any): Promise<any> {
    const json = await this.safeFetch(`${API_BASE}/rooms/${roomId}/tools/pk`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(payload)
    });
    if (!json.success) throw new Error(json.error || 'Failed to update PK battle');
    return json.data;
  }

  public static async updateRoomGame(roomId: string, payload: any): Promise<any> {
    const json = await this.safeFetch(`${API_BASE}/rooms/${roomId}/tools/game`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(payload)
    });
    if (!json.success) throw new Error(json.error || 'Failed to update room game');
    return json.data;
  }

  // Voice Room Management Admin API methods
  public static async updateAdminRoom(id: string, payload: Partial<VoiceRoom>): Promise<VoiceRoom> {
    const json = await this.safeFetch(`${API_BASE}/admin/rooms/${id}/update`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(payload)
    });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async updateAdminSeat(
    id: string,
    payload: { seatIndex: number; action: string; targetUserId?: string; maxSeats?: number }
  ): Promise<VoiceRoom> {
    const json = await this.safeFetch(`${API_BASE}/admin/rooms/${id}/seat/update`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(payload)
    });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async moderateRoomUser(
    id: string,
    payload: { targetUserId: string; action: string; durationMinutes?: number; reason?: string }
  ): Promise<any> {
    const json = await this.safeFetch(`${API_BASE}/admin/rooms/${id}/users/action`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(payload)
    });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async updateRoomSettings(id: string, settings: any): Promise<VoiceRoom> {
    const json = await this.safeFetch(`${API_BASE}/admin/rooms/${id}/settings`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(settings)
    });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async manageRoomAnnouncements(id: string, payload: any): Promise<VoiceRoom> {
    const json = await this.safeFetch(`${API_BASE}/admin/rooms/${id}/announcements`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(payload)
    });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async managePkBattleAdmin(payload: any): Promise<any> {
    const json = await this.safeFetch(`${API_BASE}/admin/rooms/pk/action`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(payload)
    });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async getRoomGiftsStats(id: string): Promise<any> {
    const json = await this.safeFetch(`${API_BASE}/admin/rooms/${id}/gifts`, { headers: this.getHeaders() });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async deleteRoomChatMessage(id: string, messageId: string): Promise<RoomMessage[]> {
    const json = await this.safeFetch(`${API_BASE}/admin/rooms/${id}/chat/delete`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ messageId })
    });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async manageBlockedWords(id: string, action: 'add' | 'remove', word: string): Promise<string[]> {
    const json = await this.safeFetch(`${API_BASE}/admin/rooms/${id}/chat/blocked-words`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ action, word })
    });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async getRoomAnalyticsSummary(): Promise<any> {
    const json = await this.safeFetch(`${API_BASE}/admin/rooms/analytics/summary`, { headers: this.getHeaders() });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async joinSeat(roomId: string, seatIndex: number): Promise<VoiceRoom> {
    const json = await this.safeFetch(`${API_BASE}/rooms/${roomId}/seat/join`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ seatIndex })
    });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async leaveSeat(roomId: string, seatIndex: number): Promise<VoiceRoom> {
    const json = await this.safeFetch(`${API_BASE}/rooms/${roomId}/seat/leave`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ seatIndex })
    });
    return json.data;
  }

  public static async toggleMuteSeat(roomId: string, seatIndex: number): Promise<VoiceRoom> {
    const json = await this.safeFetch(`${API_BASE}/rooms/${roomId}/seat/mute`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ seatIndex })
    });
    return json.data;
  }

  public static async toggleLockSeat(roomId: string, seatIndex: number): Promise<VoiceRoom> {
    const json = await this.safeFetch(`${API_BASE}/rooms/${roomId}/seat/lock`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ seatIndex })
    });
    return json.data;
  }

  public static async getGifts(filter?: { category?: string; search?: string; minPrice?: number; maxPrice?: number; inStockOnly?: boolean; sortBy?: string }): Promise<Gift[]> {
    const params = new URLSearchParams();
    if (filter?.category && filter.category !== 'all') params.append('category', filter.category);
    if (filter?.search) params.append('search', filter.search);
    if (filter?.minPrice !== undefined) params.append('minPrice', String(filter.minPrice));
    if (filter?.maxPrice !== undefined) params.append('maxPrice', String(filter.maxPrice));
    if (filter?.inStockOnly) params.append('inStockOnly', 'true');
    if (filter?.sortBy) params.append('sortBy', filter.sortBy);

    const query = params.toString() ? `?${params.toString()}` : '';
    const json = await this.safeFetch(`${API_BASE}/gifts${query}`, { headers: this.getHeaders() });
    return json.data || [];
  }

  public static async getGiftInventoryCatalog(): Promise<{ stats: GiftInventoryStats; catalog: Gift[] }> {
    const json = await this.safeFetch(`${API_BASE}/gifts/inventory`, { headers: this.getHeaders() });
    return json.data || { stats: {} as any, catalog: [] };
  }

  public static async getUserGiftInventory(): Promise<UserGiftInventoryItem[]> {
    const json = await this.safeFetch(`${API_BASE}/gifts/inventory/user`, { headers: this.getHeaders() });
    return json.data || [];
  }

  public static async claimUserGiftInventory(giftId: string, quantity: number = 1, source: string = 'reward'): Promise<UserGiftInventoryItem> {
    const json = await this.safeFetch(`${API_BASE}/gifts/inventory/user/claim`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ giftId, quantity, source })
    });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async sendGift(
    receiverIdOrParams: string | SendGiftParams, 
    giftId?: string, 
    count: number = 1, 
    roomId?: string,
    deductFromInventory: boolean = false
  ): Promise<SendGiftResult> {
    let payload: SendGiftParams;
    if (typeof receiverIdOrParams === 'object') {
      payload = receiverIdOrParams;
    } else {
      payload = {
        senderId: '', // set by server via auth/demo header
        receiverId: receiverIdOrParams,
        giftId: giftId!,
        count,
        roomId,
        deductFromInventory
      };
    }

    const json = await this.safeFetch(`${API_BASE}/gifts/send`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(payload)
    });
    if (!json.success) throw new Error(json.error);
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('aura_leaderboard_updated', { detail: json.data }));
      window.dispatchEvent(new CustomEvent('aura_gift_sent', { detail: json.data }));
    }
    return json.data;
  }

  public static async getTopContributors(
    category: ContributorLeaderboardCategory = 'earners',
    period: ContributorLeaderboardPeriod = 'daily',
    limit: number = 50
  ): Promise<ContributorLeaderboardResponse> {
    const params = new URLSearchParams();
    if (category) params.append('category', category);
    if (period) params.append('period', period);
    if (limit) params.append('limit', String(limit));

    const json = await this.safeFetch(`${API_BASE}/leaderboard/contributors?${params.toString()}`, {
      headers: this.getHeaders()
    });
    if (!json.success) throw new Error(json.error || 'Failed to fetch contributor leaderboard');
    return json.data;
  }

  public static async sendVirtualGift(params: SendGiftParams): Promise<SendGiftResult> {
    return this.sendGift(params);
  }

  public static async manageGiftCatalog(action: 'create' | 'update' | 'delete', payload: any): Promise<any> {
    const json = await this.safeFetch(`${API_BASE}/gifts/inventory/manage`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ action, ...payload })
    });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async rechargeWallet(coins: number, diamonds: number, description: string): Promise<WalletTransaction> {
    const json = await this.safeFetch(`${API_BASE}/wallet/recharge`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ coins, diamonds, description })
    });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async withdrawWallet(diamonds: number, accountDetails: string): Promise<WalletTransaction> {
    const json = await this.safeFetch(`${API_BASE}/wallet/withdraw`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ diamonds, accountDetails })
    });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async setWalletBalance(coins?: number, diamonds?: number, reason?: string): Promise<User> {
    const json = await this.safeFetch(`${API_BASE}/wallet/direct-set`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ coins, diamonds, reason })
    });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async rechargeCoins(userId: string, coins: number, bonus?: number): Promise<{ newCoins: number }> {
    const total = coins + (bonus || 0);
    const tx = await this.rechargeWallet(total, 0, `Recharged ${total.toLocaleString()} Coins`);
    return { newCoins: tx.balanceAfter };
  }

  public static async rechargeDiamonds(userId: string, diamonds: number): Promise<{ newDiamonds: number }> {
    const tx = await this.rechargeWallet(0, diamonds, 'Recharged Diamond Package');
    return { newDiamonds: tx.balanceAfter };
  }

  public static async withdrawCash(userId: string, diamonds: number, details: string): Promise<{ newDiamonds: number }> {
    const tx = await this.withdrawWallet(diamonds, details);
    return { newDiamonds: tx.balanceAfter };
  }

  public static async getTransactions(): Promise<WalletTransaction[]> {
    const json = await this.safeFetch(`${API_BASE}/wallet/transactions`, { headers: this.getHeaders() });
    return json.data || [];
  }

  public static async getRechargePackages(): Promise<RechargePackage[]> {
    const json = await this.safeFetch(`${API_BASE}/wallet/packages`, { headers: this.getHeaders() });
    return json.data || [];
  }

  public static async updateRechargePackage(id: string, data: Partial<RechargePackage>): Promise<RechargePackage[]> {
    const json = await this.safeFetch(`${API_BASE}/wallet/packages/${id}`, {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!json.success) throw new Error(json.error || 'Failed to update package');
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('wallet_packages_updated', { detail: json.data }));
      localStorage.setItem('aura_wallet_packages_version', String(Date.now()));
    }
    return json.data;
  }

  public static async saveAllRechargePackages(packages: RechargePackage[]): Promise<RechargePackage[]> {
    const json = await this.safeFetch(`${API_BASE}/wallet/packages/save-all`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ packages })
    });
    if (!json.success) throw new Error(json.error || 'Failed to save packages');
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('wallet_packages_updated', { detail: json.data }));
      localStorage.setItem('aura_wallet_packages_version', String(Date.now()));
    }
    return json.data;
  }

  public static async createRechargePackage(data: Partial<RechargePackage>): Promise<RechargePackage[]> {
    const json = await this.safeFetch(`${API_BASE}/wallet/packages`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!json.success) throw new Error(json.error || 'Failed to create package');
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('wallet_packages_updated', { detail: json.data }));
      localStorage.setItem('aura_wallet_packages_version', String(Date.now()));
    }
    return json.data;
  }

  public static async deleteRechargePackage(id: string): Promise<RechargePackage[]> {
    const json = await this.safeFetch(`${API_BASE}/wallet/packages/${id}`, {
      method: 'DELETE',
      headers: this.getHeaders()
    });
    if (!json.success) throw new Error(json.error || 'Failed to delete package');
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('wallet_packages_updated', { detail: json.data }));
      localStorage.setItem('aura_wallet_packages_version', String(Date.now()));
    }
    return json.data;
  }

  // ==========================================
  // WITHDRAW PAYMENT METHODS API CLIENT
  // ==========================================

  public static async getWithdrawPaymentMethods(): Promise<WithdrawPaymentMethod[]> {
    const json = await this.safeFetch(`${API_BASE}/wallet/withdraw-methods`, { headers: this.getHeaders() });
    return json.data || [];
  }

  public static async getAdminWithdrawPaymentMethods(): Promise<WithdrawPaymentMethod[]> {
    const json = await this.safeFetch(`${API_BASE}/admin/wallet/withdraw-methods`, { headers: this.getHeaders() });
    if (!json.success) throw new Error(json.error || 'Failed to fetch withdraw methods');
    return json.data || [];
  }

  public static async createWithdrawPaymentMethod(data: Partial<WithdrawPaymentMethod>): Promise<WithdrawPaymentMethod[]> {
    const json = await this.safeFetch(`${API_BASE}/admin/wallet/withdraw-methods`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!json.success) throw new Error(json.error || 'Failed to create payment method');
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('withdraw_methods_updated', { detail: json.data }));
      localStorage.setItem('aura_withdraw_methods_version', String(Date.now()));
    }
    return json.data;
  }

  public static async updateWithdrawPaymentMethod(id: string, data: Partial<WithdrawPaymentMethod>): Promise<WithdrawPaymentMethod[]> {
    const json = await this.safeFetch(`${API_BASE}/admin/wallet/withdraw-methods/${id}`, {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!json.success) throw new Error(json.error || 'Failed to update payment method');
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('withdraw_methods_updated', { detail: json.data }));
      localStorage.setItem('aura_withdraw_methods_version', String(Date.now()));
    }
    return json.data;
  }

  public static async toggleWithdrawPaymentMethodStatus(id: string, isActive: boolean): Promise<WithdrawPaymentMethod[]> {
    const json = await this.safeFetch(`${API_BASE}/admin/wallet/withdraw-methods/${id}/status`, {
      method: 'PATCH',
      headers: this.getHeaders(),
      body: JSON.stringify({ isActive })
    });
    if (!json.success) throw new Error(json.error || 'Failed to update payment method status');
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('withdraw_methods_updated', { detail: json.data }));
      localStorage.setItem('aura_withdraw_methods_version', String(Date.now()));
    }
    return json.data;
  }

  public static async deleteWithdrawPaymentMethod(id: string): Promise<WithdrawPaymentMethod[]> {
    const json = await this.safeFetch(`${API_BASE}/admin/wallet/withdraw-methods/${id}`, {
      method: 'DELETE',
      headers: this.getHeaders()
    });
    if (!json.success) throw new Error(json.error || 'Failed to delete payment method');
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('withdraw_methods_updated', { detail: json.data }));
      localStorage.setItem('aura_withdraw_methods_version', String(Date.now()));
    }
    return json.data;
  }

  public static async getActiveLuckyBags(roomId?: string): Promise<LuckyBag[]> {
    const json = await this.safeFetch(`${API_BASE}/luckybag/active${roomId ? `?roomId=${roomId}` : ''}`, { headers: this.getHeaders() });
    return json.data || [];
  }

  public static async createLuckyBag(roomId: string, totalCoins: number, totalWinners: number): Promise<LuckyBag> {
    const json = await this.safeFetch(`${API_BASE}/luckybag/create`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ roomId, totalCoins, totalWinners })
    });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async claimLuckyBag(bagId: string): Promise<{ reward: number; bag: LuckyBag }> {
    const json = await this.safeFetch(`${API_BASE}/luckybag/claim`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ bagId })
    });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async spinWheel(): Promise<{ reward: any; userCoins: number; userDiamonds: number }> {
    const json = await this.safeFetch(`${API_BASE}/spin`, {
      method: 'POST',
      headers: this.getHeaders()
    });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async getFamilies(): Promise<Family[]> {
    const json = await this.safeFetch(`${API_BASE}/families`, { headers: this.getHeaders() });
    return json.data || [];
  }

  public static async createFamily(data: Partial<Family>): Promise<Family> {
    const json = await this.safeFetch(`${API_BASE}/families`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!json.success) throw new Error(json.error);
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('families_updated', { detail: json.data }));
    }
    return json.data;
  }

  public static async createAdminFamily(data: any): Promise<Family> {
    const json = await this.safeFetch(`${API_BASE}/admin/families`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!json.success) throw new Error(json.error);
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('families_updated', { detail: json.data }));
    }
    return json.data;
  }

  public static async updateFamily(id: string, data: Partial<Family>): Promise<Family> {
    const json = await this.safeFetch(`${API_BASE}/admin/families/${id}`, {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!json.success) throw new Error(json.error);
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('families_updated', { detail: json.data }));
    }
    return json.data;
  }

  public static async updateFamilyStatus(id: string, status: 'active' | 'inactive' | 'suspended', reason?: string): Promise<Family> {
    const json = await this.safeFetch(`${API_BASE}/admin/families/${id}/status`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ status, reason })
    });
    if (!json.success) throw new Error(json.error);
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('families_updated', { detail: json.data }));
    }
    return json.data;
  }

  public static async transferFamilyLeadership(id: string, newLeaderUserId: string): Promise<Family> {
    const json = await this.safeFetch(`${API_BASE}/admin/families/${id}/transfer-leadership`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ newLeaderUserId })
    });
    if (!json.success) throw new Error(json.error);
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('families_updated', { detail: json.data }));
    }
    return json.data;
  }

  public static async getFamilyMembers(id: string): Promise<FamilyMember[]> {
    const json = await this.safeFetch(`${API_BASE}/admin/families/${id}/members`, { headers: this.getHeaders() });
    return json.data || [];
  }

  public static async addFamilyMember(id: string, data: { userId: string; role?: string }): Promise<FamilyMember> {
    const json = await this.safeFetch(`${API_BASE}/admin/families/${id}/members`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async updateFamilyMemberRole(id: string, userId: string, role: string): Promise<FamilyMember> {
    const json = await this.safeFetch(`${API_BASE}/admin/families/${id}/members/${userId}/role`, {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify({ role })
    });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async removeFamilyMember(id: string, userId: string): Promise<{ success: boolean; message: string }> {
    const json = await this.safeFetch(`${API_BASE}/admin/families/${id}/members/${userId}`, {
      method: 'DELETE',
      headers: this.getHeaders()
    });
    if (!json.success) throw new Error(json.error);
    return json;
  }

  public static async deleteFamily(id: string): Promise<{ success: boolean; message: string }> {
    const json = await this.safeFetch(`${API_BASE}/admin/families/${id}`, {
      method: 'DELETE',
      headers: this.getHeaders()
    });
    if (!json.success) throw new Error(json.error);
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('families_updated'));
    }
    return json;
  }

  public static async getAdminUsers(): Promise<User[]> {
    const json = await this.safeFetch(`${API_BASE}/admin/users`, { headers: this.getHeaders() });
    return json.data || [];
  }

  public static async getAdminStats(): Promise<any> {
    const json = await this.safeFetch(`${API_BASE}/admin/stats`, { headers: this.getHeaders() });
    return json.data || {};
  }

  public static async getAdminDashboard(): Promise<any> {
    const json = await this.safeFetch(`${API_BASE}/admin/dashboard`, { headers: this.getHeaders() });
    return json.data || {};
  }

  public static async getAdminStaff(): Promise<any[]> {
    const json = await this.safeFetch(`${API_BASE}/admin/staff`, { headers: this.getHeaders() });
    return json.data || [];
  }

  public static async getAdminFinancial(): Promise<any> {
    const json = await this.safeFetch(`${API_BASE}/admin/financial`, { headers: this.getHeaders() });
    return json.data || {};
  }

  public static async getAdminSettings(): Promise<any> {
    const json = await this.safeFetch(`${API_BASE}/admin/settings`, { headers: this.getHeaders() });
    return json.data || {};
  }

  public static async getAdminAppearance(): Promise<AdminAppearanceSettings> {
    const json = await this.safeFetch(`${API_BASE}/admin/settings/appearance`, { headers: this.getHeaders() });
    if (!json.success) throw new Error(json.error || 'Failed to fetch admin appearance');
    return json.data;
  }

  public static async updateAdminAppearance(backgroundColor: string): Promise<AdminAppearanceSettings> {
    const json = await this.safeFetch(`${API_BASE}/admin/settings/appearance`, {
      method: 'PATCH',
      headers: this.getHeaders(),
      body: JSON.stringify({ backgroundColor })
    });
    if (!json.success) throw new Error(json.error || 'Failed to update admin appearance');
    return json.data;
  }

  public static async resetAdminAppearance(): Promise<AdminAppearanceSettings> {
    const json = await this.safeFetch(`${API_BASE}/admin/settings/appearance/reset`, {
      method: 'POST',
      headers: this.getHeaders()
    });
    if (!json.success) throw new Error(json.error || 'Failed to reset admin appearance');
    return json.data;
  }

  public static async getAdminRooms(): Promise<VoiceRoom[]> {
    return this.getRooms();
  }

  public static async updateUserRole(userId: string, role: string): Promise<User> {
    const json = await this.safeFetch(`${API_BASE}/admin/users/${userId}/role`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ role })
    });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async updateUserAccount(userId: string, data: Partial<User>): Promise<User> {
    const json = await this.safeFetch(`${API_BASE}/admin/users/${userId}/update`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!json.success) throw new Error(json.error);
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('user_profile_updated', { detail: json.data }));
      window.dispatchEvent(new CustomEvent('users_updated', { detail: json.data }));
    }
    return json.data;
  }

  public static async adjustUserBalance(
    userId: string, 
    typeOrData: 'coins' | 'diamonds' | { coins?: number; diamonds?: number; reason?: string },
    amount?: number,
    reason?: string
  ): Promise<User> {
    if (typeof typeOrData === 'string') {
      const payload: Partial<User> = {};
      if (typeOrData === 'coins' && typeof amount === 'number') payload.coins = amount;
      if (typeOrData === 'diamonds' && typeof amount === 'number') payload.diamonds = amount;
      return this.updateUserAccount(userId, payload);
    }
    return this.updateUserAccount(userId, {
      ...(typeof typeOrData.coins === 'number' ? { coins: typeOrData.coins } : {}),
      ...(typeof typeOrData.diamonds === 'number' ? { diamonds: typeOrData.diamonds } : {})
    });
  }

  public static async updateUserId(userId: string, newUid: string, confirmUid?: string, reason?: string): Promise<User> {
    const json = await this.safeFetch(`${API_BASE}/admin/users/${userId}/update-uid`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ newUid, confirmUid, reason })
    });
    if (!json.success) throw new Error(json.error);
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('user_profile_updated', { detail: json.data }));
      window.dispatchEvent(new CustomEvent('users_updated', { detail: json.data }));
    }
    return json.data;
  }

  public static async updateUserVip(userId: string, data: { action: 'assign' | 'remove' | 'extend'; level?: 'vip' | 'svip'; durationDays?: number }): Promise<User> {
    const json = await this.safeFetch(`${API_BASE}/admin/users/${userId}/vip`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async assignStaffIdentity(userId: string, data: {
    role?: string;
    roles?: string[];
    positions?: string[];
    title?: string;
    staffId?: string;
    staffLevel?: number;
    isVerified?: boolean;
    department?: string;
    activeStatus?: string;
    notes?: string;
  }): Promise<User> {
    const json = await this.safeFetch(`${API_BASE}/admin/staff/identity/assign`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ userId, ...data })
    });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async removeStaffIdentity(userId: string, notes?: string): Promise<User> {
    const json = await this.safeFetch(`${API_BASE}/admin/staff/identity/remove`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ userId, notes })
    });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async grantIdentityPermission(targetUserId: string, canAssign: boolean): Promise<User> {
    const json = await this.safeFetch(`${API_BASE}/admin/staff/identity/grant-permission`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ targetUserId, canAssign })
    });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async getAuditLogs(): Promise<any[]> {
    const json = await this.safeFetch(`${API_BASE}/admin/audit`, { headers: this.getHeaders() });
    return json.data || [];
  }

  public static async getOpenApiSpec(): Promise<any> {
    const json = await this.safeFetch(`${API_BASE}/docs/json`);
    return json;
  }

  public static async getLedger(currency?: 'coin' | 'diamond'): Promise<WalletTransaction[]> {
    const url = currency ? `${API_BASE}/wallet/ledger?currency=${currency}` : `${API_BASE}/wallet/ledger`;
    const json = await this.safeFetch(url, { headers: this.getHeaders() });
    return json.data || [];
  }

  public static async startPkBattle(roomId: string, opponentRoomId: string, durationSeconds: number = 300): Promise<PkBattle> {
    const json = await this.safeFetch(`${API_BASE}/rooms/${roomId}/pk/start`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ opponentRoomId, durationSeconds })
    });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async updatePkScore(battleId: string, roomAAdd: number = 0, roomBAdd: number = 0): Promise<PkBattle> {
    const json = await this.safeFetch(`${API_BASE}/rooms/pk/score`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ battleId, roomAAdd, roomBAdd })
    });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async toggleMusic(roomId: string, title?: string, artist?: string, isPlaying?: boolean): Promise<VoiceRoom> {
    const json = await this.safeFetch(`${API_BASE}/rooms/${roomId}/music`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ title, artist, isPlaying })
    });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async getPrivateMessages(peerId: string): Promise<PrivateMessage[]> {
    const json = await this.safeFetch(`${API_BASE}/messages/private?peerId=${encodeURIComponent(peerId)}`, { headers: this.getHeaders() });
    return json.data || [];
  }

  public static async sendPrivateMessage(receiverId: string, content: string, type: 'text' | 'image' | 'voice' | 'gift' = 'text'): Promise<PrivateMessage> {
    const json = await this.safeFetch(`${API_BASE}/messages/private`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ receiverId, content, type })
    });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async getConversations(): Promise<any[]> {
    const json = await this.safeFetch(`${API_BASE}/messages/conversations`, { headers: this.getHeaders() });
    return json.data || [];
  }

  public static async getNotifications(): Promise<NotificationItem[]> {
    const json = await this.safeFetch(`${API_BASE}/notifications`, { headers: this.getHeaders() });
    return json.data || [];
  }

  public static async markNotificationRead(notificationId?: string): Promise<NotificationItem[]> {
    const json = await this.safeFetch(`${API_BASE}/notifications/read`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ notificationId })
    });
    return json.data || [];
  }

  public static async broadcastNotification(title: string, message: string, link?: string): Promise<any> {
    const json = await this.safeFetch(`${API_BASE}/notifications/broadcast`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ title, message, link })
    });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async getStaffActivityLogs(): Promise<StaffActivityLog[]> {
    const json = await this.safeFetch(`${API_BASE}/admin/staff-activity`, { headers: this.getHeaders() });
    return json.data || [];
  }

  public static async leaveRoom(roomId: string): Promise<VoiceRoom | null> {
    try {
      const json = await this.safeFetch(`${API_BASE}/rooms/${roomId}/leave`, {
        method: 'POST',
        headers: this.getHeaders()
      });
      return json.data || null;
    } catch {
      return null;
    }
  }

  public static async submitReport(payload: {
    targetType?: 'room' | 'user' | 'message';
    targetId: string;
    targetTitle?: string;
    targetUserName?: string;
    reason: string;
    details?: string;
  }): Promise<ReportItem> {
    const json = await this.safeFetch(`${API_BASE}/reports`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(payload)
    });
    if (!json.success) throw new Error(json.error || 'Failed to submit report');
    return json.data;
  }

  public static async getReports(status?: string): Promise<ReportItem[]> {
    const url = status && status !== 'all' ? `${API_BASE}/admin/reports?status=${status}` : `${API_BASE}/admin/reports`;
    const json = await this.safeFetch(url, { headers: this.getHeaders() });
    return json.data || [];
  }

  public static async moderateReport(reportId: string, status: string, notes?: string): Promise<ReportItem> {
    const json = await this.safeFetch(`${API_BASE}/admin/reports/moderate`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ reportId, status, notes })
    });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async getAnalyticsOverview(): Promise<AnalyticsOverview> {
    const json = await this.safeFetch(`${API_BASE}/analytics/overview`, { headers: this.getHeaders() });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  public static async getSecurityAuditReport(): Promise<any> {
    const json = await this.safeFetch(`${API_BASE}/security/audit-report`, { headers: this.getHeaders() });
    return json.data || {};
  }

  public static async runTestSuite(): Promise<any> {
    const json = await this.safeFetch(`${API_BASE}/test/suite`, { headers: this.getHeaders() });
    if (!json.success) throw new Error(json.error);
    return json.data;
  }

  // ==========================================
  // BANNER MANAGEMENT & UPLOAD API METHODS
  // ==========================================

  public static async uploadImage(
    fileOrBase64: File | string,
    fileName?: string,
    contentType?: string,
    module: string = 'avatar'
  ): Promise<{ url: string; fileId: string; fileName: string; size: number; contentType: string }> {
    let base64Data: string;
    let actualFileName = fileName || 'image.png';
    let actualContentType = contentType || 'image/png';
    let actualSize = 0;

    if (typeof fileOrBase64 === 'string') {
      base64Data = fileOrBase64;
      if (fileOrBase64.startsWith('data:')) {
        const match = fileOrBase64.match(/^data:([^;]+);base64,/);
        if (match) actualContentType = match[1];
      }
      actualSize = Math.round(base64Data.length * 0.75);
    } else {
      actualFileName = fileOrBase64.name;
      actualContentType = fileOrBase64.type || 'image/png';
      actualSize = fileOrBase64.size;
      base64Data = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = (err) => reject(err);
        reader.readAsDataURL(fileOrBase64);
      });
    }

    const json = await this.safeFetch(`${API_BASE}/upload`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({
        fileData: base64Data,
        fileName: actualFileName,
        contentType: actualContentType,
        size: actualSize,
        module
      })
    });

    if (!json.success || !json.data?.url) {
      throw new Error(json.error || 'Failed to upload image');
    }

    return json.data;
  }

  public static async getActiveBanners(): Promise<Banner[]> {
    const json = await this.safeFetch(`${API_BASE}/banners/active`, { headers: this.getHeaders() });
    return json.data || [];
  }

  public static async getAdminBanners(): Promise<Banner[]> {
    const json = await this.safeFetch(`${API_BASE}/admin/banners`, { headers: this.getHeaders() });
    return json.data || [];
  }

  public static async createBanner(bannerData: Partial<Banner>): Promise<Banner> {
    const json = await this.safeFetch(`${API_BASE}/admin/banners`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(bannerData)
    });
    if (!json.success) throw new Error(json.error || 'Failed to create banner');
    return json.data;
  }

  public static async updateBanner(id: string, bannerData: Partial<Banner>): Promise<Banner> {
    const json = await this.safeFetch(`${API_BASE}/admin/banners/${id}`, {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify(bannerData)
    });
    if (!json.success) throw new Error(json.error || 'Failed to update banner');
    return json.data;
  }

  public static async deleteBanner(id: string): Promise<boolean> {
    const json = await this.safeFetch(`${API_BASE}/admin/banners/${id}`, {
      method: 'DELETE',
      headers: this.getHeaders()
    });
    if (!json.success) throw new Error(json.error || 'Failed to delete banner');
    return true;
  }

  public static async reorderBanners(bannerIds: string[]): Promise<boolean> {
    const json = await this.safeFetch(`${API_BASE}/admin/banners/reorder`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ bannerIds })
    });
    if (!json.success) throw new Error(json.error || 'Failed to reorder banners');
    return true;
  }

  // Family Management
  public static async joinFamily(familyId: string): Promise<any> {
    const json = await this.safeFetch(`${API_BASE}/families/${familyId}/join`, {
      method: 'POST',
      headers: this.getHeaders()
    });
    if (!json.success) throw new Error(json.error || 'Failed to join family');
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('families_updated'));
    }
    return json;
  }

  public static async applyToFamily(familyId: string, message?: string): Promise<FamilyApplication> {
    const json = await this.safeFetch(`${API_BASE}/families/${familyId}/apply`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ message })
    });
    if (!json.success) throw new Error(json.error || 'Failed to apply for family membership');
    return json.data;
  }

  public static async getMyFamilyApplications(): Promise<FamilyApplication[]> {
    const json = await this.safeFetch(`${API_BASE}/families/applications/my`, {
      headers: this.getHeaders()
    });
    return json.data || [];
  }

  public static async getFamilyApplications(familyId: string): Promise<FamilyApplication[]> {
    const json = await this.safeFetch(`${API_BASE}/families/${familyId}/applications`, {
      headers: this.getHeaders()
    });
    return json.data || [];
  }

  public static async decideFamilyApplication(applicationId: string, decision: 'approve' | 'reject'): Promise<any> {
    const json = await this.safeFetch(`${API_BASE}/families/applications/${applicationId}/decision`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ decision })
    });
    if (!json.success) throw new Error(json.error || 'Failed to process application');
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('families_updated'));
    }
    return json;
  }

  public static async leaveFamily(familyId: string): Promise<any> {
    const json = await this.safeFetch(`${API_BASE}/families/${familyId}/leave`, {
      method: 'POST',
      headers: this.getHeaders()
    });
    if (!json.success) throw new Error(json.error || 'Failed to leave family');
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('families_updated'));
    }
    return json;
  }

  // VIP / SVIP / Frame Assignment Methods
  public static async getBenefitAssignments(): Promise<any[]> {
    try {
      const json = await this.safeFetch(`${API_BASE}/admin/vip/assignments`, {
        headers: this.getHeaders()
      });
      return json?.data || [];
    } catch (err: any) {
      console.warn('ApiClient.getBenefitAssignments graceful fallback:', err?.message || err);
      return [];
    }
  }

  public static async assignVip(data: { targetUserId?: string; targetUid?: string; level: string; durationDays: number | 'permanent'; assignmentMode?: string; reason?: string }): Promise<any> {
    const json = await this.safeFetch(`${API_BASE}/admin/vip/assign`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!json.success) throw new Error(json.error || 'Failed to assign VIP');
    return json.data;
  }

  public static async revokeVip(data: { targetUserId?: string; targetUid?: string; reason?: string }): Promise<any> {
    const json = await this.safeFetch(`${API_BASE}/admin/vip/revoke`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!json.success) throw new Error(json.error || 'Failed to revoke VIP');
    return json.data;
  }

  public static async assignSvip(data: { targetUserId?: string; targetUid?: string; level: string; durationDays: number | 'permanent'; assignmentMode?: string; reason?: string }): Promise<any> {
    const json = await this.safeFetch(`${API_BASE}/admin/svip/assign`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!json.success) throw new Error(json.error || 'Failed to assign SVIP');
    return json.data;
  }

  public static async revokeSvip(data: { targetUserId?: string; targetUid?: string; reason?: string }): Promise<any> {
    const json = await this.safeFetch(`${API_BASE}/admin/svip/revoke`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!json.success) throw new Error(json.error || 'Failed to revoke SVIP');
    return json.data;
  }

  public static async assignFrame(data: { targetUserId?: string; targetUid?: string; frameId: string; durationDays: number | 'permanent'; assignmentMode?: string; reason?: string }): Promise<any> {
    const json = await this.safeFetch(`${API_BASE}/admin/frame/assign`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!json.success) throw new Error(json.error || 'Failed to assign frame');
    return json.data;
  }

  public static async revokeFrame(data: { targetUserId?: string; targetUid?: string; reason?: string }): Promise<any> {
    const json = await this.safeFetch(`${API_BASE}/admin/frame/revoke`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!json.success) throw new Error(json.error || 'Failed to revoke frame');
    return json.data;
  }

  // Users
  public static async getUsers(): Promise<User[]> {
    const json = await this.safeFetch(`${API_BASE}/admin/users`, {
      headers: this.getHeaders()
    });
    return json.data || [];
  }

  // Wallet & Finance
  public static async getWalletSummary(): Promise<any> {
    const json = await this.safeFetch(`${API_BASE}/admin/wallet/summary`, {
      headers: this.getHeaders()
    });
    return json.data || {};
  }

  public static async getWalletTransactions(): Promise<WalletTransaction[]> {
    const json = await this.safeFetch(`${API_BASE}/admin/wallet/transactions`, {
      headers: this.getHeaders()
    });
    return json.data || [];
  }

  public static async adjustUserWallet(data: {
    targetUserId?: string;
    targetUid?: string;
    currency: 'coin' | 'diamond';
    amount: number;
    action: 'add' | 'deduct';
    reason?: string;
  }): Promise<any> {
    const json = await this.safeFetch(`${API_BASE}/admin/wallet/adjust`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!json.success) throw new Error(json.error || 'Failed to adjust wallet');
    return json.data;
  }

  public static async moderateWithdrawal(id: string, action: 'completed' | 'rejected' | 'approve' | 'reject', reason?: string): Promise<any> {
    const normalizedAction = action === 'approve' ? 'completed' : action === 'reject' ? 'rejected' : action;
    const json = await this.safeFetch(`${API_BASE}/admin/wallet/withdrawals/${id}/moderate`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ action: normalizedAction, reason })
    });
    if (!json.success) throw new Error(json.error || 'Failed to moderate withdrawal');
    return json.data;
  }

  // Merchants
  public static async getMerchants(): Promise<Merchant[]> {
    const json = await this.safeFetch(`${API_BASE}/admin/merchants`, {
      headers: this.getHeaders()
    });
    return json.data || [];
  }

  public static async createMerchant(data: Partial<Merchant>): Promise<Merchant> {
    const json = await this.safeFetch(`${API_BASE}/admin/merchants`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!json.success) throw new Error(json.error || 'Failed to create merchant');
    return json.data;
  }

  public static async updateMerchant(id: string, data: Partial<Merchant>): Promise<Merchant> {
    const json = await this.safeFetch(`${API_BASE}/admin/merchants/${id}`, {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!json.success) throw new Error(json.error || 'Failed to update merchant');
    return json.data;
  }

  public static async updateMerchantStatus(id: string, status: string, reason?: string): Promise<Merchant> {
    const json = await this.safeFetch(`${API_BASE}/admin/merchants/${id}/status`, {
      method: 'PATCH',
      headers: this.getHeaders(),
      body: JSON.stringify({ status, reason })
    });
    if (!json.success) throw new Error(json.error || 'Failed to update merchant status');
    return json.data;
  }

  // Recharge Agents
  public static async getRechargeAgents(): Promise<RechargeAgent[]> {
    const json = await this.safeFetch(`${API_BASE}/admin/recharge-agents`, {
      headers: this.getHeaders()
    });
    return json.data || [];
  }

  public static async createRechargeAgent(data: { userUid: string; commissionRate: number; creditBalance: number; notes?: string }): Promise<RechargeAgent> {
    const json = await this.safeFetch(`${API_BASE}/admin/recharge-agents`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!json.success) throw new Error(json.error || 'Failed to create recharge agent');
    return json.data;
  }

  public static async updateRechargeAgent(id: string, data: { commissionRate?: number; creditBalance?: number; notes?: string }): Promise<RechargeAgent> {
    const json = await this.safeFetch(`${API_BASE}/admin/recharge-agents/${id}`, {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!json.success) throw new Error(json.error || 'Failed to update recharge agent');
    return json.data;
  }

  public static async updateRechargeAgentStatus(id: string, status: string, reason?: string): Promise<RechargeAgent> {
    const json = await this.safeFetch(`${API_BASE}/admin/recharge-agents/${id}/status`, {
      method: 'PATCH',
      headers: this.getHeaders(),
      body: JSON.stringify({ status, reason })
    });
    if (!json.success) throw new Error(json.error || 'Failed to update recharge agent status');
    return json.data;
  }

  // Agencies
  public static async getAgencies(): Promise<Agency[]> {
    const json = await this.safeFetch(`${API_BASE}/admin/agencies`, {
      headers: this.getHeaders()
    });
    return json.data || [];
  }

  public static async createAgency(data: Partial<Agency> & { ownerUid: string; name: string }): Promise<Agency> {
    const json = await this.safeFetch(`${API_BASE}/admin/agencies`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!json.success) throw new Error(json.error || 'Failed to create agency');
    return json.data;
  }

  public static async updateAgency(id: string, data: Partial<Agency>): Promise<Agency> {
    const json = await this.safeFetch(`${API_BASE}/admin/agencies/${id}`, {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!json.success) throw new Error(json.error || 'Failed to update agency');
    return json.data;
  }

  public static async updateAgencyStatus(id: string, status: string, reason?: string): Promise<Agency> {
    const json = await this.safeFetch(`${API_BASE}/admin/agencies/${id}/status`, {
      method: 'PATCH',
      headers: this.getHeaders(),
      body: JSON.stringify({ status, reason })
    });
    if (!json.success) throw new Error(json.error || 'Failed to update agency status');
    return json.data;
  }

  // Ban Management & Ban History
  public static async getBanHistory(params?: { status?: string; search?: string }): Promise<BanRecord[]> {
    try {
      const query = new URLSearchParams();
      if (params?.status && params.status !== 'all') query.append('status', params.status);
      if (params?.search && params.search.trim()) query.append('search', params.search.trim());
      const qs = query.toString() ? `?${query.toString()}` : '';
      const json = await this.safeFetch(`${API_BASE}/admin/bans${qs}`, {
        headers: this.getHeaders()
      });
      return json?.data || [];
    } catch (err) {
      console.warn('ApiClient.getBanHistory graceful fallback:', err);
      return [];
    }
  }

  public static async getBanStats(): Promise<{
    totalUsers: number;
    activeBans: number;
    permanentBans: number;
    temporaryBans: number;
    totalHistoricalBanEvents: number;
    unbannedCount: number;
    expiredCount: number;
    recent24hEvents: number;
  }> {
    try {
      const json = await this.safeFetch(`${API_BASE}/admin/bans/stats`, {
        headers: this.getHeaders()
      });
      return json?.data || {
        totalUsers: 0,
        activeBans: 0,
        permanentBans: 0,
        temporaryBans: 0,
        totalHistoricalBanEvents: 0,
        unbannedCount: 0,
        expiredCount: 0,
        recent24hEvents: 0
      };
    } catch (err) {
      console.warn('ApiClient.getBanStats graceful fallback:', err);
      return {
        totalUsers: 0,
        activeBans: 0,
        permanentBans: 0,
        temporaryBans: 0,
        totalHistoricalBanEvents: 0,
        unbannedCount: 0,
        expiredCount: 0,
        recent24hEvents: 0
      };
    }
  }

  public static async banUser(
    userId: string,
    data: {
      banType: 'temporary' | 'permanent';
      durationHours?: number;
      reason: string;
      adminNote?: string;
    }
  ): Promise<{ success: boolean; message: string; data: { user: User; banRecord: BanRecord } }> {
    const json = await this.safeFetch(`${API_BASE}/admin/users/${userId}/ban`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!json.success) {
      throw new Error(json.error || 'Failed to ban user account');
    }
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('user_ban_status_updated', { detail: { userId, status: 'banned' } }));
    }
    return json;
  }

  public static async unbanUser(
    userId: string,
    data?: { reason?: string }
  ): Promise<{ success: boolean; message: string; data: { user: User } }> {
    const json = await this.safeFetch(`${API_BASE}/admin/users/${userId}/unban`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data || {})
    });
    if (!json.success) {
      throw new Error(json.error || 'Failed to unban user account');
    }
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('user_ban_status_updated', { detail: { userId, status: 'active' } }));
    }
    return json;
  }

  public static async searchAdminUsers(query: string): Promise<User[]> {
    const json = await this.safeFetch(`${API_BASE}/admin/users/search?q=${encodeURIComponent(query)}`, {
      headers: this.getHeaders()
    });
    return json.data || [];
  }

  // ====================================================
  // Dynamic Country Management APIs
  // ====================================================

  public static async getCountries(enabledOnly = true): Promise<Country[]> {
    const url = enabledOnly ? `${API_BASE}/countries` : `${API_BASE}/countries?all=true`;
    const json = await this.safeFetch(url, {
      headers: this.getHeaders()
    });
    return json.data || [];
  }

  public static async getCountryById(idOrCode: string): Promise<Country | null> {
    const json = await this.safeFetch(`${API_BASE}/countries/${encodeURIComponent(idOrCode)}`, {
      headers: this.getHeaders()
    });
    return json.data || null;
  }

  public static async getCountryPaymentMethods(idOrCode: string): Promise<{ rechargeMethods: string[]; withdrawalMethods: string[]; currency: string; currencySymbol: string }> {
    const json = await this.safeFetch(`${API_BASE}/countries/${encodeURIComponent(idOrCode)}/payment-methods`, {
      headers: this.getHeaders()
    });
    return json.data || { rechargeMethods: [], withdrawalMethods: [], currency: 'USD', currencySymbol: '$' };
  }

  public static async getAdminCountries(filters?: { status?: string; search?: string }): Promise<{
    data: (Country & { associatedUsersCount: number })[];
    total: number;
    enabledCount: number;
    disabledCount: number;
  }> {
    const params = new URLSearchParams();
    if (filters?.status && filters.status !== 'all') params.append('status', filters.status);
    if (filters?.search) params.append('search', filters.search);

    const qs = params.toString() ? `?${params.toString()}` : '';
    const json = await this.safeFetch(`${API_BASE}/admin/countries${qs}`, {
      headers: this.getHeaders()
    });
    return {
      data: json.data || [],
      total: json.total || (json.data ? json.data.length : 0),
      enabledCount: json.enabledCount || 0,
      disabledCount: json.disabledCount || 0
    };
  }

  public static async getCountryUsersCount(countryId: string): Promise<{
    countryId: string;
    countryName: string;
    associatedUsersCount: number;
    canDelete: boolean;
  }> {
    const json = await this.safeFetch(`${API_BASE}/admin/countries/${encodeURIComponent(countryId)}/users-count`, {
      headers: this.getHeaders()
    });
    return json;
  }

  public static async createCountry(data: CountryFormData): Promise<Country> {
    const json = await this.safeFetch(`${API_BASE}/admin/countries`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!json.success) {
      throw new Error(json.error || 'Failed to create country');
    }
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('country_data_updated', { detail: json.data }));
    }
    return json.data;
  }

  public static async updateCountry(id: string, data: Partial<CountryFormData>): Promise<Country> {
    const json = await this.safeFetch(`${API_BASE}/admin/countries/${encodeURIComponent(id)}`, {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!json.success) {
      throw new Error(json.error || 'Failed to update country');
    }
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('country_data_updated', { detail: json.data }));
    }
    return json.data;
  }

  public static async toggleCountryStatus(id: string, status: 'enabled' | 'disabled'): Promise<Country> {
    const json = await this.safeFetch(`${API_BASE}/admin/countries/${encodeURIComponent(id)}/status`, {
      method: 'PATCH',
      headers: this.getHeaders(),
      body: JSON.stringify({ status })
    });
    if (!json.success) {
      throw new Error(json.error || 'Failed to change country status');
    }
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('country_data_updated', { detail: json.data }));
    }
    return json.data;
  }

  public static async deleteCountry(id: string): Promise<{ deleted: boolean; countryId: string; message: string }> {
    const json = await this.safeFetch(`${API_BASE}/admin/countries/${encodeURIComponent(id)}`, {
      method: 'DELETE',
      headers: this.getHeaders()
    });
    if (!json.success) {
      throw new Error(json.error || 'Failed to delete country');
    }
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('country_data_updated', { detail: { countryId: id, deleted: true } }));
    }
    return json;
  }

  // ==========================================
  // DYNAMIC RBAC PERMISSION MANAGEMENT
  // ==========================================

  public static async getRbacMetadata(): Promise<{
    modules: PermissionModule[];
    permissions: SystemPermission[];
    roles: RolePermissionConfig[];
    overrides: StaffPermissionOverride[];
  }> {
    const json = await this.safeFetch(`${API_BASE}/admin/rbac/metadata`, { headers: this.getHeaders() });
    if (!json.success) throw new Error(json.error || 'Failed to load RBAC matrix metadata');
    return json.data;
  }

  public static async getRbacPermissions(): Promise<SystemPermission[]> {
    const json = await this.safeFetch(`${API_BASE}/admin/rbac/permissions`, { headers: this.getHeaders() });
    if (!json.success) throw new Error(json.error || 'Failed to load system permissions');
    return json.data || [];
  }

  public static async createRbacPermission(data: {
    key: string;
    name: string;
    module: string;
    description?: string;
    defaultLevel?: string;
    isCeoProtected?: boolean;
  }): Promise<SystemPermission> {
    const json = await this.safeFetch(`${API_BASE}/admin/rbac/permissions`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!json.success) throw new Error(json.error || 'Failed to create permission');
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('rbac_updated', { detail: json.data }));
    }
    return json.data;
  }

  public static async createRbacModule(data: {
    key: string;
    name: string;
    description?: string;
    icon?: string;
  }): Promise<PermissionModule> {
    const json = await this.safeFetch(`${API_BASE}/admin/rbac/modules`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!json.success) throw new Error(json.error || 'Failed to create module');
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('rbac_updated', { detail: json.data }));
    }
    return json.data;
  }

  public static async getRbacRoles(): Promise<RolePermissionConfig[]> {
    const json = await this.safeFetch(`${API_BASE}/admin/rbac/roles`, { headers: this.getHeaders() });
    if (!json.success) throw new Error(json.error || 'Failed to load role configurations');
    return json.data || [];
  }

  public static async getRbacRoleConfig(roleId: string): Promise<RolePermissionConfig> {
    const json = await this.safeFetch(`${API_BASE}/admin/rbac/roles/${roleId}`, { headers: this.getHeaders() });
    if (!json.success) throw new Error(json.error || 'Failed to load role config');
    return json.data;
  }

  public static async updateRbacRolePermissions(roleId: string, data: {
    permissions: Record<string, string>;
    canGrantRoles?: string[];
    description?: string;
  }): Promise<RolePermissionConfig> {
    const json = await this.safeFetch(`${API_BASE}/admin/rbac/roles/${roleId}`, {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!json.success) throw new Error(json.error || 'Failed to update role permissions');
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('rbac_updated', { detail: json.data }));
    }
    return json.data;
  }

  public static async resetRbacRoleToDefault(roleId: string): Promise<RolePermissionConfig> {
    const json = await this.safeFetch(`${API_BASE}/admin/rbac/reset/${roleId}`, {
      method: 'POST',
      headers: this.getHeaders()
    });
    if (!json.success) throw new Error(json.error || 'Failed to reset role permissions');
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('rbac_updated', { detail: json.data }));
    }
    return json.data;
  }

  public static async getStaffRbac(userId: string): Promise<{
    targetUser: any;
    role: UserRole;
    roleBaseline: Record<string, string>;
    overrides: Record<string, string>;
    effective: Record<string, string>;
  }> {
    const json = await this.safeFetch(`${API_BASE}/admin/rbac/staff/${userId}`, { headers: this.getHeaders() });
    if (!json.success) throw new Error(json.error || 'Failed to get staff RBAC details');
    return json.data;
  }

  public static async updateStaffRbacOverrides(userId: string, data: {
    overrides: Record<string, string>;
    notes?: string;
  }): Promise<any> {
    const json = await this.safeFetch(`${API_BASE}/admin/rbac/staff/${userId}`, {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });
    if (!json.success) throw new Error(json.error || 'Failed to update staff overrides');
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('rbac_updated', { detail: json.data }));
    }
    return json.data;
  }

  public static async clearStaffRbacOverrides(userId: string): Promise<any> {
    const json = await this.safeFetch(`${API_BASE}/admin/rbac/staff/${userId}/overrides`, {
      method: 'DELETE',
      headers: this.getHeaders()
    });
    if (!json.success) throw new Error(json.error || 'Failed to clear staff overrides');
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('rbac_updated', { detail: json.data }));
    }
    return json.data;
  }

  // ==========================================
  // CONNECTIONS & SOCIAL NETWORKING (CP & FRIENDS)
  // ==========================================

  public static async getFriends(): Promise<{ connections: Connection[]; friends: User[] }> {
    const json = await this.safeFetch(`${API_BASE}/connections/friends`, {
      headers: this.getHeaders()
    });
    if (!json.success) throw new Error(json.error || 'Failed to fetch friends');
    return json.data || { connections: [], friends: [] };
  }

  public static async getFriendRequests(): Promise<{ incoming: ConnectionRequest[]; outgoing: ConnectionRequest[] }> {
    const json = await this.safeFetch(`${API_BASE}/connections/friend-requests`, {
      headers: this.getHeaders()
    });
    if (!json.success) throw new Error(json.error || 'Failed to fetch friend requests');
    return json.data || { incoming: [], outgoing: [] };
  }

  public static async getCP(): Promise<Connection | null> {
    const json = await this.safeFetch(`${API_BASE}/connections/cp`, {
      headers: this.getHeaders()
    });
    if (!json.success) throw new Error(json.error || 'Failed to fetch CP');
    return json.data || null;
  }

  public static async getCPRequests(): Promise<{ incoming: ConnectionRequest[]; outgoing: ConnectionRequest[] }> {
    const json = await this.safeFetch(`${API_BASE}/connections/cp-requests`, {
      headers: this.getHeaders()
    });
    if (!json.success) throw new Error(json.error || 'Failed to fetch CP requests');
    return json.data || { incoming: [], outgoing: [] };
  }

  public static async sendConnectionRequest(
    receiverId: string, 
    type: ConnectionType, 
    message?: string
  ): Promise<ConnectionRequest> {
    const json = await this.safeFetch(`${API_BASE}/connections/requests`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ receiverId, type, message })
    });
    if (!json.success) throw new Error(json.error || 'Failed to send connection request');
    return json.data;
  }

  public static async acceptConnectionRequest(requestId: string): Promise<{ connection: Connection; request: ConnectionRequest }> {
    const json = await this.safeFetch(`${API_BASE}/connections/requests/${requestId}/accept`, {
      method: 'POST',
      headers: this.getHeaders()
    });
    if (!json.success) throw new Error(json.error || 'Failed to accept connection request');
    return json.data;
  }

  public static async declineConnectionRequest(requestId: string): Promise<ConnectionRequest> {
    const json = await this.safeFetch(`${API_BASE}/connections/requests/${requestId}/decline`, {
      method: 'POST',
      headers: this.getHeaders()
    });
    if (!json.success) throw new Error(json.error || 'Failed to decline connection request');
    return json.data;
  }

  public static async cancelConnectionRequest(requestId: string): Promise<ConnectionRequest> {
    const json = await this.safeFetch(`${API_BASE}/connections/requests/${requestId}/cancel`, {
      method: 'POST',
      headers: this.getHeaders()
    });
    if (!json.success) throw new Error(json.error || 'Failed to cancel connection request');
    return json.data;
  }

  public static async removeConnection(connectionId: string): Promise<any> {
    const json = await this.safeFetch(`${API_BASE}/connections/${connectionId}`, {
      method: 'DELETE',
      headers: this.getHeaders()
    });
    if (!json.success) throw new Error(json.error || 'Failed to remove connection');
    return json.data;
  }

  public static async discoverUsers(search?: string): Promise<(User & { connectionStatus: string })[]> {
    const query = search ? `?search=${encodeURIComponent(search)}` : '';
    const json = await this.safeFetch(`${API_BASE}/connections/discover${query}`, {
      headers: this.getHeaders()
    });
    if (!json.success) throw new Error(json.error || 'Failed to discover users');
    return json.data || [];
  }

  public static async blockUser(targetUserId: string): Promise<any> {
    const json = await this.safeFetch(`${API_BASE}/connections/block`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ targetUserId })
    });
    if (!json.success) throw new Error(json.error || 'Failed to block user');
    return json.data;
  }

  public static async unblockUser(targetUserId: string): Promise<any> {
    const json = await this.safeFetch(`${API_BASE}/connections/unblock`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ targetUserId })
    });
    if (!json.success) throw new Error(json.error || 'Failed to unblock user');
    return json.data;
  }

  public static async getBlockedUsers(): Promise<User[]> {
    const json = await this.safeFetch(`${API_BASE}/connections/blocked`, {
      headers: this.getHeaders()
    });
    if (!json.success) throw new Error(json.error || 'Failed to fetch blocked users');
    return json.data || [];
  }

  // ==========================================
  // ADMIN CP & FRIENDSHIP MANAGEMENT API
  // ==========================================

  public static async getAdminConnectionsOverview(): Promise<AdminConnectionOverview> {
    const json = await this.safeFetch(`${API_BASE}/admin/connections/overview`, {
      headers: this.getHeaders()
    });
    if (!json.success) throw new Error(json.error || 'Failed to fetch connections overview');
    return json.data;
  }

  public static async getAdminConnections(filters?: {
    type?: string;
    status?: string;
    search?: string;
    minLevel?: number;
    sortBy?: string;
  }): Promise<Connection[]> {
    const params = new URLSearchParams();
    if (filters?.type) params.set('type', filters.type);
    if (filters?.status) params.set('status', filters.status);
    if (filters?.search) params.set('search', filters.search);
    if (filters?.minLevel) params.set('minLevel', filters.minLevel.toString());
    if (filters?.sortBy) params.set('sortBy', filters.sortBy);

    const query = params.toString() ? `?${params.toString()}` : '';
    const json = await this.safeFetch(`${API_BASE}/admin/connections${query}`, {
      headers: this.getHeaders()
    });
    if (!json.success) throw new Error(json.error || 'Failed to fetch connections');
    return json.data || [];
  }

  public static async adminCreateCP(payload: {
    user1Id: string;
    user2Id: string;
    intimacyPoints?: number;
    level?: number;
    ceremonyNote?: string;
    forceOverride?: boolean;
  }): Promise<Connection> {
    const json = await this.safeFetch(`${API_BASE}/admin/connections/cp/create`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(payload)
    });
    if (!json.success) throw new Error(json.error || 'Failed to establish CP bond');
    return json.data;
  }

  public static async adminAdjustIntimacy(
    connectionId: string,
    payload: {
      intimacyPoints: number;
      level?: number;
      sharedGiftsCoins?: number;
      reason: string;
    }
  ): Promise<Connection> {
    const json = await this.safeFetch(`${API_BASE}/admin/connections/${connectionId}/intimacy`, {
      method: 'PATCH',
      headers: this.getHeaders(),
      body: JSON.stringify(payload)
    });
    if (!json.success) throw new Error(json.error || 'Failed to adjust intimacy');
    return json.data;
  }

  public static async adminTerminateConnection(
    connectionId: string,
    payload: { reason: string }
  ): Promise<Connection> {
    const json = await this.safeFetch(`${API_BASE}/admin/connections/${connectionId}/terminate`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(payload)
    });
    if (!json.success) throw new Error(json.error || 'Failed to terminate connection');
    return json.data;
  }

  public static async adminCreateFriendship(payload: {
    user1Id: string;
    user2Id: string;
    note?: string;
  }): Promise<Connection> {
    const json = await this.safeFetch(`${API_BASE}/admin/connections/friend/create`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(payload)
    });
    if (!json.success) throw new Error(json.error || 'Failed to create friendship');
    return json.data;
  }

  public static async getAdminConnectionRequests(filters?: {
    type?: string;
    status?: string;
    search?: string;
  }): Promise<ConnectionRequest[]> {
    const params = new URLSearchParams();
    if (filters?.type) params.set('type', filters.type);
    if (filters?.status) params.set('status', filters.status);
    if (filters?.search) params.set('search', filters.search);

    const query = params.toString() ? `?${params.toString()}` : '';
    const json = await this.safeFetch(`${API_BASE}/admin/connections/requests${query}`, {
      headers: this.getHeaders()
    });
    if (!json.success) throw new Error(json.error || 'Failed to fetch connection requests');
    return json.data || [];
  }

  public static async adminPurgeConnectionRequest(requestId: string): Promise<boolean> {
    const json = await this.safeFetch(`${API_BASE}/admin/connections/requests/${requestId}`, {
      method: 'DELETE',
      headers: this.getHeaders()
    });
    if (!json.success) throw new Error(json.error || 'Failed to purge connection request');
    return true;
  }

  public static async getAdminBlockedRelations(search?: string): Promise<BlockedUserRecord[]> {
    const query = search ? `?search=${encodeURIComponent(search)}` : '';
    const json = await this.safeFetch(`${API_BASE}/admin/connections/blocked${query}`, {
      headers: this.getHeaders()
    });
    if (!json.success) throw new Error(json.error || 'Failed to fetch blocked users');
    return json.data || [];
  }

  public static async adminUnblockRelation(payload: {
    userId: string;
    blockedUserId: string;
    reason?: string;
  }): Promise<boolean> {
    const json = await this.safeFetch(`${API_BASE}/admin/connections/unblock`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(payload)
    });
    if (!json.success) throw new Error(json.error || 'Failed to unblock user');
    return true;
  }

  public static async getAdminConnectionConfig(): Promise<ConnectionSystemConfig> {
    const json = await this.safeFetch(`${API_BASE}/admin/connections/config`, {
      headers: this.getHeaders()
    });
    if (!json.success) throw new Error(json.error || 'Failed to fetch connection config');
    return json.data;
  }

  public static async updateAdminConnectionConfig(
    config: Partial<ConnectionSystemConfig>
  ): Promise<ConnectionSystemConfig> {
    const json = await this.safeFetch(`${API_BASE}/admin/connections/config`, {
      method: 'PATCH',
      headers: this.getHeaders(),
      body: JSON.stringify(config)
    });
    if (!json.success) throw new Error(json.error || 'Failed to update connection config');
    return json.data;
  }
}
