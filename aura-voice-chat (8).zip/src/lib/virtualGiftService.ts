/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export { VirtualGiftService, VirtualGiftService as default } from '../services/VirtualGiftService';
