/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { 
  doc, 
  getDoc, 
  setDoc, 
  collection, 
  getDocs, 
  query, 
  orderBy, 
  limit, 
  onSnapshot, 
  Unsubscribe,
  serverTimestamp
} from 'firebase/firestore';
import { db, auth } from './firebase';
import { ApiClient } from './api';
import { sanitizeForFirestore } from './firestoreUsers';

export interface FirebaseWalletData {
  userId: string;
  coins: number;
  diamonds: number;
  totalRecharged?: number;
  lastRechargedAt?: string;
  updatedAt?: string;
}

export interface FirebaseWalletTransaction {
  id: string;
  userId: string;
  type: 'recharge' | 'gift_sent' | 'gift_received' | 'spin' | 'lucky_bag' | 'admin_adjust';
  amount: number;
  currency: 'coins' | 'diamonds';
  balanceAfter: number;
  description: string;
  paymentMethod?: string;
  createdAt: string;
}

export interface RechargeOptions {
  packageId?: string;
  packageName?: string;
  priceUsd?: number;
  paymentMethod?: string;
  bonusCoins?: number;
  note?: string;
}

/**
 * Service to store, update, and observe user currency in Firebase Firestore
 */
export class FirebaseWalletService {
  /**
   * Listen to real-time wallet currency changes directly in Firebase Firestore.
   */
  public static listenToWallet(
    userId: string, 
    callback: (wallet: { coins: number; diamonds: number }) => void
  ): Unsubscribe {
    if (!userId) {
      return () => {};
    }

    const userDocRef = doc(db, 'users', userId);
    return onSnapshot(
      userDocRef,
      (snapshot) => {
        if (snapshot.exists()) {
          const data = snapshot.data();
          callback({
            coins: Number(data.coins ?? 0),
            diamonds: Number(data.diamonds ?? 0)
          });
        }
      },
      (error) => {
        console.warn('FirebaseWalletService listen error (fallback to local state):', error);
      }
    );
  }

  /**
   * Fetch current user currency balance from Firebase Firestore.
   */
  public static async getWallet(userId: string): Promise<FirebaseWalletData> {
    const defaultData: FirebaseWalletData = {
      userId,
      coins: 0,
      diamonds: 0,
      updatedAt: new Date().toISOString()
    };

    try {
      // Check user document first
      const userDocRef = doc(db, 'users', userId);
      const userSnap = await getDoc(userDocRef);

      if (userSnap.exists()) {
        const uData = userSnap.data();
        return {
          userId,
          coins: Number(uData.coins ?? 0),
          diamonds: Number(uData.diamonds ?? 0),
          totalRecharged: Number(uData.totalRecharged ?? 0),
          lastRechargedAt: uData.lastRechargedAt,
          updatedAt: uData.updatedAt || new Date().toISOString()
        };
      }

      // Check dedicated wallet document
      const walletDocRef = doc(db, 'wallets', userId);
      const walletSnap = await getDoc(walletDocRef);
      if (walletSnap.exists()) {
        const wData = walletSnap.data();
        return {
          userId,
          coins: Number(wData.coins ?? 0),
          diamonds: Number(wData.diamonds ?? 0),
          totalRecharged: Number(wData.totalRecharged ?? 0),
          lastRechargedAt: wData.lastRechargedAt,
          updatedAt: wData.updatedAt || new Date().toISOString()
        };
      }

      return defaultData;
    } catch (err) {
      console.warn('FirebaseWalletService.getWallet notice:', err);
      return defaultData;
    }
  }

  /**
   * Recharge coins: Stores and updates user currency in Firebase,
   * creates an audit transaction log in Firestore, and syncs with backend API.
   */
  public static async rechargeCoins(
    userId: string,
    coinsToAdd: number,
    options: RechargeOptions = {}
  ): Promise<{ newCoins: number; transactionId: string; diamonds: number }> {
    if (coinsToAdd <= 0) {
      throw new Error('Recharge coin amount must be greater than zero.');
    }

    const bonus = Math.max(0, Math.floor(options.bonusCoins || 0));
    const totalCredit = coinsToAdd + bonus;
    const nowIso = new Date().toISOString();
    const txId = `tx-fb-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

    let currentCoins = 0;
    let currentDiamonds = 0;
    let prevTotalRecharged = 0;

    // 1. Read existing balance from Firebase
    try {
      const userDocRef = doc(db, 'users', userId);
      const userSnap = await getDoc(userDocRef);
      if (userSnap.exists()) {
        const data = userSnap.data();
        currentCoins = Number(data.coins ?? 0);
        currentDiamonds = Number(data.diamonds ?? 0);
        prevTotalRecharged = Number(data.totalRecharged ?? 0);
      }
    } catch (readErr) {
      console.warn('Could not read existing coins from Firebase, falling back:', readErr);
    }

    const newCoins = currentCoins + totalCredit;
    const newTotalRecharged = prevTotalRecharged + coinsToAdd;

    // 2. Persist updated currency in Firebase Firestore: /users/{userId}
    try {
      const userDocRef = doc(db, 'users', userId);
      const userPayload = sanitizeForFirestore({
        coins: newCoins,
        totalRecharged: newTotalRecharged,
        lastRechargedAt: nowIso,
        updatedAt: nowIso
      });
      await setDoc(userDocRef, userPayload, { merge: true });
    } catch (fbErr) {
      console.warn('Failed to write coins to /users in Firebase:', fbErr);
    }

    // 3. Persist in dedicated /wallets/{userId} document in Firebase
    try {
      const walletDocRef = doc(db, 'wallets', userId);
      const walletPayload = sanitizeForFirestore({
        userId,
        coins: newCoins,
        diamonds: currentDiamonds,
        totalRecharged: newTotalRecharged,
        lastRechargedAt: nowIso,
        updatedAt: nowIso
      });
      await setDoc(walletDocRef, walletPayload, { merge: true });

      // Record transaction ledger subcollection in Firebase
      const txDocRef = doc(db, 'wallets', userId, 'transactions', txId);
      const txPayload = sanitizeForFirestore({
        id: txId,
        userId,
        type: 'recharge',
        amount: totalCredit,
        currency: 'coins',
        balanceAfter: newCoins,
        description: options.packageName 
          ? `Recharged ${options.packageName} (+${totalCredit.toLocaleString()} coins)`
          : `Recharged ${totalCredit.toLocaleString()} coins`,
        paymentMethod: options.paymentMethod || 'Google Pay',
        createdAt: nowIso
      });
      await setDoc(txDocRef, txPayload, { merge: true });
    } catch (walletErr) {
      console.warn('Failed to record wallet document in Firebase:', walletErr);
    }

    // 4. Synchronize with Node backend API ledger
    try {
      await ApiClient.rechargeCoins(userId, coinsToAdd, bonus);
    } catch (apiErr) {
      console.warn('Backend API recharge sync notice:', apiErr);
    }

    // Dispatch event so other components immediately know about the recharge
    try {
      window.dispatchEvent(new CustomEvent('wallet_recharged', {
        detail: { userId, newCoins, totalCredit, txId }
      }));
    } catch (e) {}

    return {
      newCoins,
      transactionId: txId,
      diamonds: currentDiamonds
    };
  }

  /**
   * Directly set or adjust coin/diamond balance in Firebase Firestore.
   */
  public static async updateCurrency(
    userId: string,
    newCoins: number,
    newDiamonds?: number
  ): Promise<void> {
    const nowIso = new Date().toISOString();
    const updateData: Record<string, any> = {
      coins: Math.max(0, Math.floor(newCoins)),
      updatedAt: nowIso
    };
    if (newDiamonds !== undefined) {
      updateData.diamonds = Math.max(0, Math.floor(newDiamonds));
    }

    // Update /users/{userId} in Firebase
    const userDocRef = doc(db, 'users', userId);
    await setDoc(userDocRef, sanitizeForFirestore(updateData), { merge: true });

    // Update /wallets/{userId} in Firebase
    const walletDocRef = doc(db, 'wallets', userId);
    await setDoc(walletDocRef, sanitizeForFirestore({
      userId,
      ...updateData
    }), { merge: true });

    // Sync with backend API
    try {
      await ApiClient.setWalletBalance(newCoins, newDiamonds, 'Updated via Firebase Wallet Service');
    } catch (err) {
      console.warn('Backend setWalletBalance notice:', err);
    }
  }

  /**
   * Fetch recent transactions from Firebase Firestore
   */
  public static async getFirebaseTransactions(userId: string, maxItems: number = 20): Promise<FirebaseWalletTransaction[]> {
    if (!auth.currentUser || !userId) {
      return [];
    }
    try {
      const txColRef = collection(db, 'wallets', userId, 'transactions');
      const q = query(txColRef, orderBy('createdAt', 'desc'), limit(maxItems));
      const snap = await getDocs(q);
      const list: FirebaseWalletTransaction[] = [];
      snap.forEach(d => {
        list.push(d.data() as FirebaseWalletTransaction);
      });
      return list;
    } catch (err) {
      console.warn('Failed to fetch Firebase transactions:', err);
      return [];
    }
  }
}
