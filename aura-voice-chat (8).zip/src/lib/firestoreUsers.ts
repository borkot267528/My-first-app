/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { 
  collection, 
  doc, 
  getDocs, 
  getDoc,
  setDoc, 
  updateDoc, 
  onSnapshot, 
  query, 
  orderBy,
  serverTimestamp,
  Unsubscribe
} from 'firebase/firestore';
import { db, auth } from './firebase';
import { User, UserRole } from '../types';
import { ApiClient } from './api';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid || null,
      email: auth.currentUser?.email || null,
      emailVerified: auth.currentUser?.emailVerified || null,
      isAnonymous: auth.currentUser?.isAnonymous || null,
      tenantId: auth.currentUser?.tenantId || null,
      providerInfo: auth.currentUser?.providerData?.map(p => ({
        providerId: p.providerId,
        email: p.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export interface BanUserPayload {
  reason: string;
  banType?: 'temporary' | 'permanent' | 'room_mute';
  durationHours?: number;
  bannedByUserId?: string;
  bannedByName?: string;
  bannedByRole?: string;
}

export interface UnbanUserPayload {
  reason?: string;
  unbannedByUserId?: string;
  unbannedByName?: string;
}

/**
 * Strips all `undefined` values recursively so that Firestore setDoc/updateDoc never fails
 */
export function sanitizeForFirestore<T>(data: T): T {
  if (data === null || data === undefined) {
    return null as any;
  }
  if (Array.isArray(data)) {
    return data
      .filter((item) => item !== undefined)
      .map((item) => sanitizeForFirestore(item)) as any;
  }
  if (typeof data === 'object' && !(data instanceof Date)) {
    const clean: Record<string, any> = {};
    for (const [key, value] of Object.entries(data)) {
      if (value !== undefined) {
        clean[key] = sanitizeForFirestore(value);
      }
    }
    return clean as any;
  }
  return data;
}

/**
 * Generates a unique 7-digit numeric Nigo ID (e.g. 5829104)
 */
export function generateUniqueNigoId(existingUids: Iterable<string> = []): string {
  const existingSet = new Set(existingUids);
  existingSet.add('2383452'); // Reserved CEO ID

  for (let attempt = 0; attempt < 100; attempt++) {
    const candidate = Math.floor(1000000 + Math.random() * 9000000).toString();
    if (!existingSet.has(candidate)) {
      return candidate;
    }
  }
  return (Date.now() % 9000000 + 1000000).toString();
}

/**
 * Normalizes raw Firestore document data to a full User object
 */
export function normalizeFirestoreUser(docId: string, data: any): User {
  const rawId = String(data.id || docId || '');
  const rawUid = String(data.uid || data.nigoId || docId || '');

  // Determine canonical user ID and customizable UID (Nigo ID)
  let canonicalId = rawId || docId;
  // If user has set a custom uid or nigoId, respect it! Fallback to rawUid or 2383452 for CEO
  let canonicalUid = data.uid || data.nigoId || (rawUid && rawUid !== docId ? rawUid : null);
  if (!canonicalUid) {
    if (docId === '2383452' || rawId === '2383452' || data.email === 'imoborkot@gmail.com') {
      canonicalUid = '2383452';
    } else {
      canonicalUid = docId;
    }
  }
  if (docId === '2383452' || rawId === '2383452' || data.email === 'imoborkot@gmail.com') {
    canonicalId = '2383452';
  } else {
    canonicalId = data.id || docId;
  }

  const firebaseUid = data.firebaseUid || (docId.length > 20 ? docId : undefined);
  const nigoId = data.nigoId || canonicalUid;

  return {
    id: canonicalId,
    uid: canonicalUid,
    firebaseUid,
    nigoId,
    name: data.name || data.displayName || 'Aura Member',
    email: data.email || `${canonicalUid}@aura.com`,
    avatar: data.avatar || data.photoURL || `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80`,
    role: (data.role || 'user') as UserRole,
    coins: Number(data.coins ?? 0),
    diamonds: Number(data.diamonds ?? 0),
    vipLevel: data.vipLevel || 'none',
    status: data.status || 'active',
    banReason: data.banReason || undefined,
    banType: data.banType || undefined,
    banStartedAt: data.banStartedAt || data.bannedAt || undefined,
    banExpiresAt: data.banExpiresAt || undefined,
    bannedByName: data.bannedByName || undefined,
    bannedByRole: data.bannedByRole || undefined,
    isOnline: Boolean(data.isOnline),
    level: Number(data.level ?? 1),
    sendingLevel: Number(data.sendingLevel ?? data.level ?? 1),
    receivingLevel: Number(data.receivingLevel ?? Math.max(1, Math.floor((data.level || 1) * 0.85))),
    bio: data.bio || '',
    country: data.country || 'US',
    countryFlag: data.countryFlag || '🇺🇸',
    phone: data.phone || '',
    gender: data.gender || 'other',
    badges: Array.isArray(data.badges) ? data.badges : [],
    medals: Array.isArray(data.medals) ? data.medals : [],
    staffIdentity: data.staffIdentity || undefined,
    createdAt: data.createdAt || new Date().toISOString()
  };
}

/**
 * Creates canonical real user profile in Firestore
 */
export async function createRealFirestoreUserProfile(
  firebaseUid: string,
  data: {
    name: string;
    email: string;
    phone?: string;
    country?: string;
    countryFlag?: string;
    gender?: 'male' | 'female' | 'other';
    avatar?: string;
  }
): Promise<User> {
  const existingUsers = await fetchUsersFromFirestore();
  const existingUids = existingUsers.map(u => u.uid);
  const nigoId = generateUniqueNigoId(existingUids);

  const safeName = (data.name?.trim() || 'Aura Member').slice(0, 100);
  const safeEmail = (data.email?.toLowerCase().trim() || `${firebaseUid}@aura.com`).slice(0, 150);

  const newProfile: User = {
    id: firebaseUid,
    uid: nigoId,
    firebaseUid,
    nigoId,
    name: safeName,
    email: safeEmail.length >= 5 ? safeEmail : `${firebaseUid}@aura.com`,
    phone: data.phone?.trim() || '',
    country: data.country?.trim() || 'United States',
    countryFlag: data.countryFlag || '🇺🇸',
    gender: data.gender || 'other',
    avatar: data.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    role: 'user', // REQUIREMENT 7: Default role must always be "user"
    coins: 10000, // Welcome bonus
    diamonds: 500,
    vipLevel: 'none',
    status: 'active',
    isOnline: true,
    level: 1,
    sendingLevel: 1,
    receivingLevel: 1,
    bio: 'Just joined Aura Voice Chat! Say hello 👋',
    badges: [
      { id: 'bdg-new', name: 'Newcomer', icon: '🌱', description: 'Joined the Aura Voice platform', acquiredAt: new Date().toISOString().split('T')[0] }
    ],
    medals: [],
    createdAt: new Date().toISOString()
  };

  const docRef = doc(db, 'users', firebaseUid);
  await setDoc(docRef, sanitizeForFirestore({
    ...newProfile,
    updatedAt: new Date().toISOString()
  }), { merge: true });

  return newProfile;
}

/**
 * Live subscription to Firestore /users collection with real-time updates
 */
export function subscribeToFirestoreUsers(
  onUpdate: (users: User[]) => void,
  onError?: (error: any) => void
): Unsubscribe {
  // If not signed in with Firebase Auth, avoid establishing collection stream that would be rejected
  if (!auth.currentUser) {
    return () => {};
  }

  const usersPath = 'users';
  try {
    const colRef = collection(db, usersPath);
    return onSnapshot(
      colRef,
      (snapshot) => {
        const list: User[] = [];
        snapshot.forEach((d) => {
          list.push(normalizeFirestoreUser(d.id, d.data()));
        });
        onUpdate(list);
      },
      (error) => {
        // Benign stream cancellation or disconnection
        if (error.code !== 'cancelled') {
          console.warn('Firestore subscription notice:', error.message);
        }
        if (onError) onError(error);
      }
    );
  } catch (err: any) {
    console.warn('Firestore subscription init error:', err?.message);
    if (onError) onError(err);
    return () => {};
  }
}

/**
 * Fetch all users directly from Firestore /users collection
 */
export async function fetchUsersFromFirestore(): Promise<User[]> {
  const usersPath = 'users';
  try {
    const colRef = collection(db, usersPath);
    const snap = await getDocs(colRef);
    const users: User[] = [];
    snap.forEach((d) => {
      users.push(normalizeFirestoreUser(d.id, d.data()));
    });
    return users;
  } catch (err: any) {
    console.warn('fetchUsersFromFirestore notice:', err?.message);
    return [];
  }
}

/**
 * Fetch a single user document from Firestore
 */
export async function fetchUserFromFirestore(userId: string): Promise<User | null> {
  const path = `users/${userId}`;
  try {
    const docRef = doc(db, 'users', userId);
    const snap = await getDoc(docRef);
    if (!snap.exists()) return null;
    return normalizeFirestoreUser(snap.id, snap.data());
  } catch (err: any) {
    console.warn(`fetchUserFromFirestore error for ${userId}:`, err?.message);
    return null;
  }
}

/**
 * Save or update user document in Firestore
 */
export async function saveUserToFirestore(user: Partial<User> & { id: string }): Promise<void> {
  const path = `users/${user.id}`;
  if (!auth.currentUser) {
    try {
      await ApiClient.updateUserAccount(user.id, user);
    } catch (apiErr) {
      console.warn('Backend API updateUserAccount fallback notice:', apiErr);
    }
    return;
  }
  try {
    const docRef = doc(db, 'users', user.id);
    const payload = sanitizeForFirestore({
      ...user,
      updatedAt: new Date().toISOString()
    });
    await setDoc(docRef, payload, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

/**
 * Enforce a ban on a user document in Firestore
 */
export async function banUserInFirestore(userId: string, payload: BanUserPayload): Promise<void> {
  const path = `users/${userId}`;
  if (!auth.currentUser) {
    try {
      await ApiClient.banUser(userId, {
        reason: payload.reason,
        banType: payload.banType === 'permanent' ? 'permanent' : 'temporary',
        durationHours: payload.durationHours
      });
    } catch (apiErr) {
      console.warn('Backend API banUser fallback notice:', apiErr);
    }
    return;
  }
  try {
    const docRef = doc(db, 'users', userId);
    const durationHrs = payload.durationHours || 24;
    const isPermanent = payload.banType === 'permanent';
    const expiresAt = isPermanent
      ? null
      : new Date(Date.now() + durationHrs * 60 * 60 * 1000).toISOString();

    const banUpdate = sanitizeForFirestore({
      status: 'banned',
      banReason: payload.reason || 'Policy violation',
      banType: payload.banType || 'temporary',
      banExpiresAt: expiresAt,
      bannedByName: payload.bannedByName || 'Administrator',
      bannedByRole: payload.bannedByRole || 'super_admin',
      bannedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });

    await setDoc(docRef, banUpdate, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

/**
 * Lift a ban and restore account in Firestore
 */
export async function unbanUserInFirestore(userId: string, payload?: UnbanUserPayload): Promise<void> {
  const path = `users/${userId}`;
  if (!auth.currentUser) {
    try {
      await ApiClient.unbanUser(userId, { reason: payload?.reason });
    } catch (apiErr) {
      console.warn('Backend API unbanUser fallback notice:', apiErr);
    }
    return;
  }
  try {
    const docRef = doc(db, 'users', userId);
    const unbanUpdate = sanitizeForFirestore({
      status: 'active',
      banReason: null,
      banType: null,
      banExpiresAt: null,
      bannedByName: null,
      bannedByRole: null,
      bannedAt: null,
      unbannedAt: new Date().toISOString(),
      unbannedByName: payload?.unbannedByName || 'Administrator',
      updatedAt: new Date().toISOString()
    });

    await setDoc(docRef, unbanUpdate, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

/**
 * Sync server users array to Firestore if missing, ensuring Firestore is populated
 */
export async function syncServerUsersToFirestore(serverUsers: User[]): Promise<void> {
  if (!serverUsers || serverUsers.length === 0 || !auth.currentUser) return;
  const path = 'users';
  try {
    const existing = await fetchUsersFromFirestore();
    const existingIds = new Set(existing.map(u => u.id));

    // Batch seed missing users to Firestore
    const promises = serverUsers
      .filter(u => !existingIds.has(u.id))
      .map(u => {
        const docRef = doc(db, 'users', u.id);
        const payload = sanitizeForFirestore({
          ...u,
          status: u.status || 'active',
          isOnline: Boolean(u.isOnline),
          createdAt: u.createdAt || new Date().toISOString()
        });
        return setDoc(docRef, payload, { merge: true });
      });

    if (promises.length > 0) {
      await Promise.all(promises);
      console.log(`Synced ${promises.length} users into Firestore.`);
    }
  } catch (err) {
    console.warn('Could not batch sync users to Firestore:', err);
  }
}

/**
 * Search users in Firestore by User ID (UID / Nigo ID) or Display Name
 */
export async function searchUsersInFirestore(queryText: string): Promise<User[]> {
  try {
    const all = await fetchUsersFromFirestore();
    const q = (queryText || '').toLowerCase().trim();
    if (!q) {
      return all.filter(u => u.status !== 'banned').slice(0, 20);
    }

    return all.filter(u => {
      if (u.status === 'banned') return false;
      const uid = (u.uid || u.nigoId || '').toLowerCase();
      const name = (u.name || '').toLowerCase();
      const id = (u.id || '').toLowerCase();
      return uid.includes(q) || name.includes(q) || id.includes(q);
    }).slice(0, 30);
  } catch (err) {
    console.warn('searchUsersInFirestore error:', err);
    return [];
  }
}
