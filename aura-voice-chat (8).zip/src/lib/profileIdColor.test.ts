/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { getProfileIdColor, getProfileIdNumeric } from './profileIdColor';

/**
 * Boundary Value Test Suite for Profile ID Color System.
 * Tests required boundary points:
 *  - 1
 *  - 100
 *  - 101
 *  - 199
 *  - 200
 *  - 300
 *  - 301
 *  - and higher ranges.
 */
export function runProfileIdColorTests(): { passed: boolean; results: { test: string; passed: boolean; expected: string; actual: string }[] } {
  const tests: { input: any; expectedRange: string; expectedHex: string; label: string }[] = [
    // Requirement boundary values:
    { input: 1, expectedRange: '1–100', expectedHex: '#f59e0b', label: 'Lower boundary 1' },
    { input: 85, expectedRange: '1–100', expectedHex: '#f59e0b', label: 'Mid-range 85 (Group 1)' },
    { input: 100, expectedRange: '1–100', expectedHex: '#f59e0b', label: 'Upper boundary 100 (Group 1)' },
    { input: 101, expectedRange: '101–199', expectedHex: '#10b981', label: 'Lower boundary 101 (Group 101-199)' },
    { input: 150, expectedRange: '101–199', expectedHex: '#10b981', label: 'Mid-range 150' },
    { input: 199, expectedRange: '101–199', expectedHex: '#10b981', label: 'Upper boundary 199' },
    { input: 200, expectedRange: '200–300', expectedHex: '#06b6d4', label: 'Lower boundary 200 (Group 2)' },
    { input: 250, expectedRange: '200–300', expectedHex: '#06b6d4', label: 'Mid-range 250 (Group 2)' },
    { input: 300, expectedRange: '200–300', expectedHex: '#06b6d4', label: 'Upper boundary 300 (Group 2)' },
    { input: 301, expectedRange: '301–399', expectedHex: '#a855f7', label: 'Lower boundary 301 (Group 301-399)' },
    { input: 399, expectedRange: '301–399', expectedHex: '#a855f7', label: 'Upper boundary 399' },
    { input: 400, expectedRange: '400–499', expectedHex: '#f43f5e', label: 'Boundary 400 (Ruby)' },
    { input: 500, expectedRange: '500–599', expectedHex: '#f97316', label: 'Boundary 500 (Amber)' },
    { input: 600, expectedRange: '600–699', expectedHex: '#84cc16', label: 'Boundary 600 (Lime)' },
    { input: 700, expectedRange: '700–799', expectedHex: '#ec4899', label: 'Boundary 700 (Magenta)' },
    { input: 800, expectedRange: '800–899', expectedHex: '#6366f1', label: 'Boundary 800 (Indigo)' },
    { input: 900, expectedRange: '900–999', expectedHex: '#14b8a6', label: 'Boundary 900 (Teal)' },
    { input: 1000, expectedRange: '1000–9999', expectedHex: '#e2e8f0', label: 'Boundary 1000 (Platinum)' },
    { input: '85', expectedRange: '1–100', expectedHex: '#f59e0b', label: 'String "85"' },
    { input: '250', expectedRange: '200–300', expectedHex: '#06b6d4', label: 'String "250"' },
    { input: 'STF-CEO-01', expectedRange: '1–100', expectedHex: '#f59e0b', label: 'Alphanumeric with digits "STF-CEO-01"' },
    { input: 8829104, expectedRange: '10000+', expectedHex: '#94a3b8', label: 'Large UID 8829104' }
  ];

  const results = tests.map(t => {
    const colorInfo = getProfileIdColor(t.input);
    const passed = colorInfo.range === t.expectedRange && colorInfo.colorHex === t.expectedHex;
    return {
      test: `${t.label} (Input: ${JSON.stringify(t.input)})`,
      passed,
      expected: `Range: ${t.expectedRange}, Hex: ${t.expectedHex}`,
      actual: `Range: ${colorInfo.range}, Hex: ${colorInfo.colorHex}`
    };
  });

  const allPassed = results.every(r => r.passed);
  return { passed: allPassed, results };
}

// Auto-run verification on load in dev / test
if (typeof window !== 'undefined' && (window as any).__RUN_UID_TESTS__) {
  console.log('Running Profile ID Color Tests:', runProfileIdColorTests());
}
