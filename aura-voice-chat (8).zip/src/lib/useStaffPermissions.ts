/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { User, UserRole } from '../types';

export interface StaffPermissions {
  currentUser: User | null;
  role: UserRole;
  isCeo: boolean;
  isGm: boolean;
  isManager: boolean;
  isSuperAdmin: boolean;
  isAdmin: boolean;
  isBd: boolean;
  isAgency: boolean;
  isHost: boolean;
  isOfficialStaff: boolean;
  isStaff: boolean;
  canEditUid: boolean;
  canAssignIdentity: boolean;
  canManageStaff: boolean;
  canManageRooms: boolean;
  canManageWallet: boolean;
  canManageBanners: boolean;
  canViewAuditLogs: boolean;
  canAccessAdmin: boolean;
}

export function useStaffPermissions(): StaffPermissions {
  const { currentUser } = useApp();

  return useMemo(() => {
    const role: UserRole = currentUser?.role || 'user';
    const staffIdentity = currentUser?.staffIdentity;
    const effectiveRole = staffIdentity?.role || role;

    const isCeo = effectiveRole === 'ceo';
    const isGm = effectiveRole === 'gm';
    const isManager = effectiveRole === 'manager';
    const isSuperAdmin = effectiveRole === 'super_admin';
    const isAdmin = effectiveRole === 'admin';
    const isBd = effectiveRole === 'bd';
    const isAgency = effectiveRole === 'agency';
    const isHost = effectiveRole === 'host';
    const isOfficialStaff = effectiveRole === 'official_staff';

    const isStaff = [
      'ceo', 'gm', 'manager', 'super_admin', 'admin', 
      'official_staff', 'bd', 'seller', 'agency'
    ].includes(effectiveRole);

    // Permission rules:
    // CEO and GM are authorized to edit User Profile ID / UID
    const canEditUid = isCeo || isGm;
    const canAssignIdentity = isCeo || (isGm && currentUser?.canAssignIdentity === true) || (isManager && currentUser?.canAssignIdentity === true);
    const canManageStaff = isCeo || isGm || isSuperAdmin;
    const canManageRooms = isCeo || isGm || isSuperAdmin || isAdmin || isManager || isHost;
    const canManageWallet = isCeo || isGm || isManager;
    const canManageBanners = isCeo || isGm || isSuperAdmin || isAdmin;
    const canViewAuditLogs = isCeo || isGm || isSuperAdmin;
    const canAccessAdmin = isCeo || isGm || isSuperAdmin || isAdmin || isManager || (currentUser?.canAssignIdentity === true);

    return {
      currentUser,
      role: effectiveRole,
      isCeo,
      isGm,
      isManager,
      isSuperAdmin,
      isAdmin,
      isBd,
      isAgency,
      isHost,
      isOfficialStaff,
      isStaff,
      canEditUid,
      canAssignIdentity,
      canManageStaff,
      canManageRooms,
      canManageWallet,
      canManageBanners,
      canViewAuditLogs,
      canAccessAdmin
    };
  }, [currentUser]);
}
