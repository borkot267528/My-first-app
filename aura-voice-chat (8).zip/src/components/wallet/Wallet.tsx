/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Coins, 
  CreditCard, 
  Sparkles, 
  CheckCircle, 
  ShieldCheck, 
  Zap, 
  Flame, 
  History, 
  RefreshCw, 
  Database,
  ArrowUpRight,
  X,
  Plus,
  Gem,
  Award,
  Wallet as WalletIcon
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { FirebaseWalletService, FirebaseWalletTransaction } from '../../lib/firebaseWallet';

export interface WalletProps {
  /** Optional custom class name */
  className?: string;
  /** Optional close callback if displayed in a modal */
  onClose?: () => void;
  /** Whether to show full screen card view or compact widget */
  variant?: 'full' | 'compact' | 'card';
}

interface DefaultPackage {
  id: string;
  name: string;
  coins: number;
  bonus: number;
  priceUsd: number;
  isPopular?: boolean;
  isBestValue?: boolean;
}

const DEFAULT_RECHARGE_PACKAGES: DefaultPackage[] = [
  { id: 'pkg-1', name: 'Starter Pouch', coins: 1000, bonus: 0, priceUsd: 0.99 },
  { id: 'pkg-2', name: 'Voice Enthusiast', coins: 5000, bonus: 250, priceUsd: 4.99 },
  { id: 'pkg-3', name: 'Popular Star', coins: 10000, bonus: 1000, priceUsd: 9.99, isPopular: true },
  { id: 'pkg-4', name: 'VIP High Roller', coins: 50000, bonus: 7500, priceUsd: 49.99 },
  { id: 'pkg-5', name: 'Crown Champion', coins: 100000, bonus: 20000, priceUsd: 99.99, isBestValue: true },
  { id: 'pkg-6', name: 'Royal Whale Vault', coins: 500000, bonus: 125000, priceUsd: 499.99 }
];

export const Wallet: React.FC<WalletProps> = ({ 
  className = '', 
  onClose,
  variant = 'full'
}) => {
  const { currentUser, setCurrentUser, showNotification } = useApp();

  // Local state initialized from currentUser
  const [liveCoins, setLiveCoins] = useState<number>(currentUser?.coins || 0);
  const [liveDiamonds, setLiveDiamonds] = useState<number>(currentUser?.diamonds || 0);
  const [isFirebaseSynced, setIsFirebaseSynced] = useState<boolean>(true);
  
  // Recharge modal / drawer state
  const [isRechargeOpen, setIsRechargeOpen] = useState<boolean>(false);
  const [selectedPackage, setSelectedPackage] = useState<DefaultPackage>(DEFAULT_RECHARGE_PACKAGES[2]);
  const [customCoins, setCustomCoins] = useState<string>('20000');
  const [useCustomAmount, setUseCustomAmount] = useState<boolean>(false);
  const [paymentMethod, setPaymentMethod] = useState<string>('google_pay');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [rechargeSuccess, setRechargeSuccess] = useState<boolean>(false);
  const [lastTxId, setLastTxId] = useState<string>('');

  // History tab
  const [showHistory, setShowHistory] = useState<boolean>(false);
  const [transactions, setTransactions] = useState<FirebaseWalletTransaction[]>([]);
  const [isLoadingHistory, setIsLoadingHistory] = useState<boolean>(false);

  // 1. Subscribe to real-time Firebase Firestore updates for user's wallet
  useEffect(() => {
    if (!currentUser?.id) return;

    setLiveCoins(currentUser.coins || 0);
    setLiveDiamonds(currentUser.diamonds || 0);

    const unsubscribe = FirebaseWalletService.listenToWallet(currentUser.id, (wallet) => {
      setLiveCoins(wallet.coins);
      setLiveDiamonds(wallet.diamonds);
      setIsFirebaseSynced(true);

      // Sync with AppContext currentUser
      setCurrentUser(prev => {
        if (!prev) return prev;
        if (prev.coins === wallet.coins && prev.diamonds === wallet.diamonds) return prev;
        return {
          ...prev,
          coins: wallet.coins,
          diamonds: wallet.diamonds
        };
      });
    });

    return () => {
      unsubscribe();
    };
  }, [currentUser?.id]);

  // Load Firebase transactions when history tab opened
  const loadHistory = async () => {
    if (!currentUser?.id) return;
    setIsLoadingHistory(true);
    try {
      const list = await FirebaseWalletService.getFirebaseTransactions(currentUser.id, 15);
      setTransactions(list);
    } catch (e) {
      console.warn('Could not load Firebase transactions:', e);
    } finally {
      setIsLoadingHistory(false);
    }
  };

  useEffect(() => {
    if (showHistory) {
      loadHistory();
    }
  }, [showHistory, currentUser?.id]);

  // Handle Recharge execution
  const handleRechargeSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!currentUser?.id) {
      showNotification('Please log in to recharge coins.');
      return;
    }

    const coinsToCredit = useCustomAmount 
      ? Math.max(100, Math.floor(Number(customCoins) || 0))
      : selectedPackage.coins;

    const bonusCoins = useCustomAmount
      ? (coinsToCredit >= 10000 ? Math.floor(coinsToCredit * 0.15) : 0)
      : selectedPackage.bonus;

    const totalCoins = coinsToCredit + bonusCoins;
    const packageName = useCustomAmount 
      ? `Custom Recharge (${coinsToCredit.toLocaleString()} coins)`
      : selectedPackage.name;

    const priceUsd = useCustomAmount 
      ? Number((coinsToCredit * 0.001).toFixed(2))
      : selectedPackage.priceUsd;

    setIsSubmitting(true);
    try {
      // 1. Store and update currency directly in Firebase Firestore
      const res = await FirebaseWalletService.rechargeCoins(currentUser.id, coinsToCredit, {
        bonusCoins,
        packageName,
        priceUsd,
        paymentMethod: paymentMethod === 'google_pay' ? 'Google Pay' : paymentMethod === 'card' ? 'Credit Card' : 'In-App Vault'
      });

      // 2. Update local state and AppContext
      setLiveCoins(res.newCoins);
      setLastTxId(res.transactionId);
      setCurrentUser(prev => prev ? { ...prev, coins: res.newCoins } : null);

      setRechargeSuccess(true);
      showNotification(`🎉 Successfully recharged ${totalCoins.toLocaleString()} Coins to Firebase!`);
      
      // Auto close after brief celebration
      setTimeout(() => {
        setRechargeSuccess(false);
        setIsRechargeOpen(false);
      }, 2000);

      // Refresh history if active
      if (showHistory) {
        loadHistory();
      }
    } catch (err: any) {
      showNotification(err.message || 'Failed to update currency in Firebase.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Compact Widget Variant (e.g. for header or room bars)
  if (variant === 'compact') {
    return (
      <div className={`inline-flex items-center gap-2 bg-gradient-to-r from-amber-500/10 via-purple-900/30 to-purple-800/20 border border-amber-500/30 rounded-full px-3 py-1.5 shadow-sm backdrop-blur-md ${className}`}>
        <div className="flex items-center gap-1.5">
          <span className="text-amber-400 font-black text-sm">🪙</span>
          <span className="text-amber-300 font-extrabold text-sm tracking-wide">
            {liveCoins.toLocaleString()}
          </span>
        </div>
        <button
          onClick={() => setIsRechargeOpen(true)}
          className="ml-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 hover:brightness-110 active:scale-95 transition-all shadow-sm flex items-center gap-1 cursor-pointer"
        >
          <Plus className="w-3 h-3" />
          <span>Recharge</span>
        </button>
      </div>
    );
  }

  // Full Screen / Standard Component View
  return (
    <div className={`w-full max-w-2xl mx-auto flex flex-col rounded-3xl bg-[#0f0720]/95 border border-purple-800/40 text-white shadow-2xl backdrop-blur-xl overflow-hidden ${className}`}>
      
      {/* Top Header */}
      <div className="relative px-6 pt-6 pb-4 border-b border-purple-800/30 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500/20 to-purple-600/30 border border-amber-500/40 flex items-center justify-center shadow-inner">
            <WalletIcon className="w-5 h-5 text-amber-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-black tracking-wide text-white">Wallet & Currency</h2>
              <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                <Database className="w-2.5 h-2.5" />
                Firebase Live
              </span>
            </div>
            <p className="text-xs text-slate-400">Persistent real-time coin balance stored in Firestore</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowHistory(!showHistory)}
            className={`p-2 rounded-xl border transition-all text-xs font-semibold flex items-center gap-1.5 cursor-pointer ${
              showHistory 
                ? 'bg-purple-600/30 border-purple-500/60 text-purple-300' 
                : 'bg-white/5 border-white/10 text-slate-400 hover:text-white hover:bg-white/10'
            }`}
            title="Firebase Transaction History"
          >
            <History className="w-4 h-4" />
            <span className="hidden sm:inline">Ledger</span>
          </button>

          {onClose && (
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-white/5 border border-white/10 text-slate-400 hover:text-white hover:bg-white/10 transition-all cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      <div className="p-6 space-y-6 overflow-y-auto max-h-[80vh]">
        
        {/* Main Coin Balance Display Card */}
        <div className="relative rounded-3xl p-6 bg-gradient-to-br from-[#1a0f35] via-[#241348] to-[#160a2c] border border-amber-500/30 shadow-xl overflow-hidden">
          {/* Ambient Gold Glow Background */}
          <div className="absolute -top-12 -right-12 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-12 -left-12 w-48 h-48 bg-purple-600/15 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-amber-300/80 flex items-center gap-1.5">
                  <Coins className="w-4 h-4 text-amber-400" />
                  Available Coin Balance
                </span>
                <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              </div>

              {/* Prominent Coin Number */}
              <div className="flex items-baseline gap-3">
                <span className="text-4xl sm:text-5xl font-black tracking-tight text-white drop-shadow-[0_2px_10px_rgba(245,158,11,0.3)]">
                  {liveCoins.toLocaleString()}
                </span>
                <span className="text-base sm:text-lg font-extrabold text-amber-400">
                  Coins 🪙
                </span>
              </div>

              <div className="flex items-center gap-3 pt-1 text-xs text-slate-400">
                <span>Account: <strong className="text-slate-200">{currentUser?.name || 'Aura Member'}</strong></span>
                <span>•</span>
                <span>UID: <strong className="text-slate-200">{currentUser?.uid || currentUser?.id || '—'}</strong></span>
              </div>
            </div>

            {/* Primary 'Recharge' Action Button */}
            <div className="flex flex-col sm:flex-row gap-3">
              <button
                id="wallet-recharge-btn"
                onClick={() => setIsRechargeOpen(true)}
                className="px-6 py-3.5 rounded-2xl font-black text-slate-950 text-sm sm:text-base bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 active:scale-98 transition-all shadow-[0_4px_20px_rgba(245,158,11,0.4)] flex items-center justify-center gap-2.5 cursor-pointer group"
              >
                <Zap className="w-5 h-5 fill-slate-950 text-slate-950 group-hover:scale-110 transition-transform" />
                <span>Recharge</span>
                <ArrowUpRight className="w-4 h-4 opacity-75 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </button>
            </div>
          </div>

          {/* Secondary stats bar: Diamonds & VIP status */}
          <div className="mt-6 pt-5 border-t border-purple-800/30 grid grid-cols-2 sm:grid-cols-3 gap-4">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center">
                <Gem className="w-4 h-4 text-cyan-400" />
              </div>
              <div>
                <p className="text-[10px] text-slate-400 font-semibold uppercase">Diamonds</p>
                <p className="text-sm font-extrabold text-cyan-300">{liveDiamonds.toLocaleString()} 💎</p>
              </div>
            </div>

            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center">
                <Award className="w-4 h-4 text-purple-400" />
              </div>
              <div>
                <p className="text-[10px] text-slate-400 font-semibold uppercase">VIP Tier</p>
                <p className="text-sm font-extrabold text-purple-300 capitalize">{currentUser?.vipLevel || 'Member'}</p>
              </div>
            </div>

            <div className="col-span-2 sm:col-span-1 flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
              </div>
              <div>
                <p className="text-[10px] text-slate-400 font-semibold uppercase">Firebase Cloud</p>
                <p className="text-sm font-extrabold text-emerald-300">Synchronized</p>
              </div>
            </div>
          </div>
        </div>

        {/* RECHARGE INTERFACE: Preset Packages & Custom Recharge */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <h3 className="text-sm font-extrabold text-slate-200 uppercase tracking-wider">
                Select Recharge Amount
              </h3>
            </div>
            <span className="text-xs text-amber-400 font-semibold flex items-center gap-1">
              <Flame className="w-3.5 h-3.5" /> Up to +25% Bonus Coins
            </span>
          </div>

          {/* Preset Packages Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {DEFAULT_RECHARGE_PACKAGES.map((pkg) => {
              const isSelected = !useCustomAmount && selectedPackage.id === pkg.id;
              return (
                <div
                  key={pkg.id}
                  onClick={() => {
                    setSelectedPackage(pkg);
                    setUseCustomAmount(false);
                  }}
                  className={`relative p-3.5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
                    isSelected
                      ? 'bg-gradient-to-b from-amber-500/20 via-purple-900/30 to-[#1e103a] border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.25)] scale-[1.02]'
                      : 'bg-white/5 border-purple-800/30 hover:bg-white/10 hover:border-purple-600/50'
                  }`}
                >
                  {/* Badges */}
                  {pkg.isPopular && (
                    <span className="absolute -top-2.5 right-2 px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-gradient-to-r from-amber-500 to-pink-500 text-slate-950 shadow-md">
                      Hot 🔥
                    </span>
                  )}
                  {pkg.isBestValue && (
                    <span className="absolute -top-2.5 right-2 px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-gradient-to-r from-emerald-400 to-teal-500 text-slate-950 shadow-md">
                      Best Value 💎
                    </span>
                  )}

                  <div>
                    <div className="flex items-center gap-1.5 text-amber-300 font-black text-base">
                      <span>🪙</span>
                      <span>{pkg.coins.toLocaleString()}</span>
                    </div>

                    {pkg.bonus > 0 ? (
                      <p className="text-[11px] font-bold text-emerald-400 mt-0.5">
                        +{pkg.bonus.toLocaleString()} Bonus Free
                      </p>
                    ) : (
                      <p className="text-[11px] text-slate-500 mt-0.5">Standard Pack</p>
                    )}
                  </div>

                  <div className="mt-3 pt-2.5 border-t border-white/5 flex items-center justify-between">
                    <span className="text-xs font-bold text-white">${pkg.priceUsd}</span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-lg ${
                      isSelected ? 'bg-amber-400 text-slate-950 font-black' : 'bg-white/10 text-slate-300'
                    }`}>
                      {isSelected ? 'Selected' : 'Choose'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Custom Recharge Accordion / Toggle */}
          <div className="rounded-2xl p-4 bg-white/5 border border-purple-800/30 space-y-3">
            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-slate-300">
                <input
                  type="checkbox"
                  checked={useCustomAmount}
                  onChange={(e) => setUseCustomAmount(e.target.checked)}
                  className="rounded border-purple-500 text-amber-400 focus:ring-amber-400 bg-purple-950"
                />
                <span>Custom Coin Quantity (Direct Input)</span>
              </label>
              {useCustomAmount && (
                <span className="text-[11px] text-emerald-400 font-semibold">+15% bonus on 10k+</span>
              )}
            </div>

            {useCustomAmount && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Enter Coins to Credit</label>
                  <div className="relative">
                    <input
                      type="number"
                      min={100}
                      step={1000}
                      value={customCoins}
                      onChange={(e) => setCustomCoins(e.target.value)}
                      placeholder="e.g. 25000"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-purple-950/80 border border-purple-700/60 text-white font-bold focus:border-amber-400 focus:outline-none"
                    />
                    <span className="absolute right-3 top-2.5 text-xs text-amber-400 font-bold">Coins</span>
                  </div>
                </div>

                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Estimated Cost / Yield</label>
                  <div className="px-3.5 py-2 rounded-xl bg-purple-900/30 border border-purple-800/40 flex items-center justify-between">
                    <div>
                      <span className="text-xs font-black text-amber-300">
                        {Math.floor(Number(customCoins) || 0) >= 10000 
                          ? `+${(Math.floor(Number(customCoins) * 0.15)).toLocaleString()} Bonus`
                          : 'No Bonus'}
                      </span>
                    </div>
                    <span className="text-sm font-extrabold text-white">
                      ${((Number(customCoins) || 0) * 0.001).toFixed(2)} USD
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Payment Method Selector */}
          <div className="rounded-2xl p-4 bg-white/5 border border-purple-800/30 space-y-2.5">
            <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
              Payment Gateway
            </span>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'google_pay', label: 'Google Pay', icon: '⚡' },
                { id: 'card', label: 'Credit Card', icon: '💳' },
                { id: 'in_app', label: 'Vault Credit', icon: '🏦' }
              ].map(m => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setPaymentMethod(m.id)}
                  className={`py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    paymentMethod === m.id
                      ? 'bg-amber-500/20 border-amber-400 text-amber-300 shadow-sm'
                      : 'bg-white/5 border-white/5 text-slate-400 hover:text-white'
                  }`}
                >
                  <span>{m.icon}</span>
                  <span>{m.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Big Confirm Recharge Button */}
          <button
            onClick={() => handleRechargeSubmit()}
            disabled={isSubmitting}
            className={`w-full py-4 rounded-2xl font-black text-base transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg ${
              rechargeSuccess 
                ? 'bg-emerald-500 text-slate-950 shadow-emerald-500/30'
                : 'bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-slate-950 active:scale-99 shadow-amber-500/20'
            } ${isSubmitting ? 'opacity-70 cursor-not-allowed' : ''}`}
          >
            {isSubmitting ? (
              <>
                <RefreshCw className="w-5 h-5 animate-spin" />
                <span>Storing & Updating in Firebase...</span>
              </>
            ) : rechargeSuccess ? (
              <>
                <CheckCircle className="w-5 h-5 text-slate-950" />
                <span>Currency Updated in Firebase!</span>
              </>
            ) : (
              <>
                <Coins className="w-5 h-5" />
                <span>
                  Confirm & Recharge{' '}
                  {useCustomAmount 
                    ? `${(Math.floor(Number(customCoins) || 0) + (Math.floor(Number(customCoins) || 0) >= 10000 ? Math.floor(Number(customCoins) * 0.15) : 0)).toLocaleString()} Coins`
                    : `${(selectedPackage.coins + selectedPackage.bonus).toLocaleString()} Coins`}
                </span>
              </>
            )}
          </button>
        </div>

        {/* Real-time Firebase Transaction Ledger Tab */}
        {showHistory && (
          <div className="pt-4 border-t border-purple-800/30 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-300 flex items-center gap-2">
                <Database className="w-3.5 h-3.5 text-purple-400" />
                Firebase Transaction Ledger
              </h4>
              <button
                onClick={loadHistory}
                disabled={isLoadingHistory}
                className="text-[11px] text-purple-400 hover:text-purple-300 flex items-center gap-1 cursor-pointer"
              >
                <RefreshCw className={`w-3 h-3 ${isLoadingHistory ? 'animate-spin' : ''}`} />
                <span>Refresh</span>
              </button>
            </div>

            {isLoadingHistory ? (
              <div className="py-6 text-center text-xs text-slate-400">Loading Firestore audit records...</div>
            ) : transactions.length === 0 ? (
              <div className="py-6 text-center text-xs text-slate-500 bg-white/5 rounded-2xl border border-purple-800/20">
                No recharge transactions recorded yet in Firebase. Recharge above to create your first record!
              </div>
            ) : (
              <div className="space-y-2">
                {transactions.map((tx) => (
                  <div 
                    key={tx.id}
                    className="p-3 rounded-xl bg-purple-950/40 border border-purple-800/30 flex items-center justify-between text-xs"
                  >
                    <div>
                      <p className="font-bold text-white flex items-center gap-1.5">
                        <span className="text-amber-400">🪙</span>
                        <span>{tx.description}</span>
                      </p>
                      <p className="text-[10px] text-slate-400 mt-0.5">
                        {new Date(tx.createdAt).toLocaleString()} • {tx.paymentMethod || 'In-App'}
                      </p>
                    </div>
                    <div className="text-right">
                      <span className="font-black text-emerald-400 text-sm">
                        +{tx.amount.toLocaleString()}
                      </span>
                      <p className="text-[10px] text-slate-400">Bal: {tx.balanceAfter.toLocaleString()}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

      </div>

      {/* Footer Info */}
      <div className="px-6 py-3 bg-[#0a0416] border-t border-purple-800/30 flex items-center justify-between text-[11px] text-slate-400">
        <span className="flex items-center gap-1">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          Secured with Firebase Firestore & RBAC Rules
        </span>
        <span className="text-slate-500 font-mono">
          UID: {currentUser?.uid || '2383452'}
        </span>
      </div>

    </div>
  );
};
