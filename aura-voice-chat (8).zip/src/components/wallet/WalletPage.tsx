/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Wallet, DollarSign, ArrowUpRight, ArrowDownLeft, Gift, ShieldCheck, 
  ChevronLeft, CreditCard, Sparkles, CheckCircle, Edit3, PlusCircle, 
  MinusCircle, Save, X, RefreshCw, Sliders, Shield, Zap, TrendingUp, Globe
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ApiClient } from '../../lib/api';
import { WalletTransaction, RechargePackage, WithdrawPaymentMethod, Country } from '../../types';
import { Wallet as FirebaseWalletComponent } from './Wallet';
import { FirebaseWalletService } from '../../lib/firebaseWallet';

export const WalletPage: React.FC = () => {
  const { setActiveModal, showNotification, currentUser, setCurrentUser } = useApp();
  const [activeTab, setActiveTab] = useState<'recharge' | 'withdraw' | 'history' | 'firebase_wallet'>('recharge');
  const [historyTab, setHistoryTab] = useState<'all' | 'coin' | 'diamond' | 'gift'>('all');
  const [transactions, setTransactions] = useState<WalletTransaction[]>([]);
  
  // Dynamic Countries State
  const [countries, setCountries] = useState<Country[]>([]);
  const [selectedCountryId, setSelectedCountryId] = useState<string>('');

  const selectedCountry = countries.find(c => c.id === selectedCountryId) || countries[0];

  // Dynamic Packages State
  const [packages, setPackages] = useState<RechargePackage[]>([]);
  const [loadingPackages, setLoadingPackages] = useState<boolean>(false);

  // Dynamic Withdraw Methods State
  const [withdrawMethods, setWithdrawMethods] = useState<WithdrawPaymentMethod[]>([]);
  const [selectedMethodId, setSelectedMethodId] = useState<string>('');
  const [loadingWithdrawMethods, setLoadingWithdrawMethods] = useState<boolean>(false);

  // Custom Coin Recharge State
  const [customCoinAmount, setCustomCoinAmount] = useState<string>('50000');
  const [customRecharging, setCustomRecharging] = useState<boolean>(false);

  // Edit Balance Modal State
  const [isEditModalOpen, setIsEditModalOpen] = useState<boolean>(false);
  const [editTargetCurrency, setEditTargetCurrency] = useState<'coin' | 'diamond'>('coin');
  const [editMode, setEditMode] = useState<'set_exact' | 'quick_adjust'>('set_exact');
  const [exactBalanceInput, setExactBalanceInput] = useState<string>('');
  const [adjustAmountInput, setAdjustAmountInput] = useState<string>('');
  const [adjustAction, setAdjustAction] = useState<'add' | 'deduct'>('add');
  const [savingBalance, setSavingBalance] = useState<boolean>(false);

  // Withdraw Form State
  const [withdrawAmount, setWithdrawAmount] = useState<string>('500');
  const [bankAccount, setBankAccount] = useState<string>('');
  const [bankName, setBankName] = useState<string>('');

  const fetchPackages = async () => {
    try {
      setLoadingPackages(true);
      const res = await ApiClient.getRechargePackages();
      if (Array.isArray(res) && res.length > 0) {
        setPackages(res);
      }
    } catch (err) {
      console.warn('Failed to load dynamic packages from API, keeping current state:', err);
    } finally {
      setLoadingPackages(false);
    }
  };

  const fetchWithdrawMethods = async () => {
    try {
      setLoadingWithdrawMethods(true);
      const res = await ApiClient.getWithdrawPaymentMethods();
      if (Array.isArray(res)) {
        setWithdrawMethods(res);
        if (res.length > 0 && !selectedMethodId) {
          setSelectedMethodId(res[0].id);
          setBankName(res[0].name);
        }
      }
    } catch (err) {
      console.warn('Failed to load withdraw payment methods:', err);
    } finally {
      setLoadingWithdrawMethods(false);
    }
  };

  const fetchCountries = async () => {
    try {
      const data = await ApiClient.getCountries(true);
      if (Array.isArray(data) && data.length > 0) {
        setCountries(data);
        setSelectedCountryId(prev => {
          if (prev && data.some(c => c.id === prev)) return prev;
          const match = data.find(c => c.name.toLowerCase() === currentUser?.country?.toLowerCase());
          return match ? match.id : data[0].id;
        });
      }
    } catch (e) {
      // Fallback
    }
  };

  useEffect(() => {
    fetchPackages();
    fetchWithdrawMethods();
    fetchCountries();

    // ⚡ INSTANT INVALIDATION & REFETCH EVENT LISTENER
    const handlePackagesUpdated = (event?: any) => {
      if (event?.detail && Array.isArray(event.detail)) {
        setPackages(event.detail);
      } else {
        fetchPackages();
      }
    };

    const handleWithdrawMethodsUpdated = (event?: any) => {
      if (event?.detail && Array.isArray(event.detail)) {
        setWithdrawMethods(event.detail);
      } else {
        fetchWithdrawMethods();
      }
    };

    const handleCountryUpdated = () => {
      fetchCountries();
    };

    window.addEventListener('wallet_packages_updated', handlePackagesUpdated);
    window.addEventListener('withdraw_methods_updated', handleWithdrawMethodsUpdated);
    window.addEventListener('country_data_updated', handleCountryUpdated);
    window.addEventListener('focus', () => {
      fetchPackages();
      fetchWithdrawMethods();
      fetchCountries();
    });

    // Periodic live sync every 8 seconds to ensure seamless multi-tab consistency
    const interval = setInterval(() => {
      fetchPackages();
      fetchWithdrawMethods();
      fetchCountries();
    }, 8000);

    return () => {
      window.removeEventListener('wallet_packages_updated', handlePackagesUpdated);
      window.removeEventListener('withdraw_methods_updated', handleWithdrawMethodsUpdated);
      window.removeEventListener('country_data_updated', handleCountryUpdated);
      clearInterval(interval);
    };
  }, []);

  useEffect(() => {
    if (currentUser && activeTab === 'history') {
      ApiClient.getTransactions().then(res => setTransactions(res)).catch(() => {});
    }
  }, [currentUser?.id, activeTab]);

  // Separate and filter active packages
  const activeCoinPackages = packages
    .filter(p => p.currencyType === 'coin' && p.isActive)
    .sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0));

  const activeDiamondPackages = packages
    .filter(p => p.currencyType === 'diamond' && p.isActive)
    .sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0));

  const openEditModal = (curr: 'coin' | 'diamond') => {
    setEditTargetCurrency(curr);
    setExactBalanceInput(String(curr === 'coin' ? (currentUser?.coins || 0) : (currentUser?.diamonds || 0)));
    setAdjustAmountInput('10000');
    setAdjustAction('add');
    setEditMode('set_exact');
    setIsEditModalOpen(true);
  };

  const handleSaveExactBalance = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    const newAmount = Math.max(0, Math.floor(Number(exactBalanceInput)));
    if (isNaN(newAmount)) {
      showNotification('Please enter a valid numeric balance');
      return;
    }

    setSavingBalance(true);
    try {
      if (editTargetCurrency === 'coin') {
        const updatedUser = await ApiClient.setWalletBalance(newAmount, undefined, 'Manual coin balance update from wallet editor');
        setCurrentUser(updatedUser);
        showNotification(`🪙 Coin balance set to ${newAmount.toLocaleString()} coins!`);
      } else {
        const updatedUser = await ApiClient.setWalletBalance(undefined, newAmount, 'Manual diamond balance update from wallet editor');
        setCurrentUser(updatedUser);
        showNotification(`💎 Diamond balance set to ${newAmount.toLocaleString()} diamonds!`);
      }
      setIsEditModalOpen(false);
    } catch (err: any) {
      showNotification(err.message || 'Failed to update balance');
    } finally {
      setSavingBalance(false);
    }
  };

  const handleQuickAdjust = async (amount: number, action: 'add' | 'deduct') => {
    if (!currentUser) return;
    if (amount <= 0) return;

    setSavingBalance(true);
    try {
      const currentVal = editTargetCurrency === 'coin' ? (currentUser.coins || 0) : (currentUser.diamonds || 0);
      const calculatedNew = action === 'add' ? currentVal + amount : Math.max(0, currentVal - amount);

      if (editTargetCurrency === 'coin') {
        const updatedUser = await ApiClient.setWalletBalance(calculatedNew, undefined, `Quick ${action} ${amount.toLocaleString()} coins`);
        setCurrentUser(updatedUser);
        showNotification(`🪙 ${action === 'add' ? 'Added' : 'Deducted'} ${amount.toLocaleString()} coins! New balance: ${calculatedNew.toLocaleString()}`);
      } else {
        const updatedUser = await ApiClient.setWalletBalance(undefined, calculatedNew, `Quick ${action} ${amount.toLocaleString()} diamonds`);
        setCurrentUser(updatedUser);
        showNotification(`💎 ${action === 'add' ? 'Added' : 'Deducted'} ${amount.toLocaleString()} diamonds! New balance: ${calculatedNew.toLocaleString()}`);
      }
      setIsEditModalOpen(false);
    } catch (err: any) {
      showNotification(err.message || 'Failed to adjust balance');
    } finally {
      setSavingBalance(false);
    }
  };

  const handleCustomRecharge = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!currentUser) return;

    if (selectedCountry && selectedCountry.rechargeAllowed === false) {
      showNotification(`Recharges are currently restricted under ${selectedCountry.name} regulations.`);
      return;
    }

    const amount = Math.floor(Number(customCoinAmount));
    if (!amount || amount <= 0) {
      showNotification('Please enter a positive coin amount');
      return;
    }

    setCustomRecharging(true);
    try {
      // Calculate bonus for custom amounts (e.g. 10% bonus for 10k+)
      const bonus = amount >= 10000 ? Math.floor(amount * 0.15) : 0;
      
      // Store & update currency in Firebase Firestore
      await FirebaseWalletService.rechargeCoins(currentUser.id, amount, {
        bonusCoins: bonus,
        packageName: `Custom Recharge (${amount.toLocaleString()} coins)`,
        priceUsd: Number((amount * 0.001).toFixed(2))
      });

      const res = await ApiClient.rechargeCoins(currentUser.id, amount, bonus);
      setCurrentUser({ ...currentUser, coins: res.newCoins });
      showNotification(`🎉 Added ${amount.toLocaleString()} coins ${bonus > 0 ? `(+${bonus.toLocaleString()} bonus)` : ''}! Balance: ${res.newCoins.toLocaleString()}`);
    } catch (err: any) {
      showNotification(err.message || 'Recharge failed');
    } finally {
      setCustomRecharging(false);
    }
  };

  const handleRechargePackage = async (pkg: RechargePackage) => {
    if (!currentUser) return;

    if (selectedCountry && selectedCountry.rechargeAllowed === false) {
      showNotification(`Recharges are currently restricted under ${selectedCountry.name} regulations.`);
      return;
    }

    try {
      if (pkg.currencyType === 'coin' || pkg.coins) {
        const coins = pkg.coins || 0;

        // Store & update currency in Firebase Firestore
        await FirebaseWalletService.rechargeCoins(currentUser.id, coins, {
          bonusCoins: pkg.bonus || 0,
          packageName: pkg.name || `${coins.toLocaleString()} Coins Pack`,
          priceUsd: pkg.priceUsd,
          packageId: pkg.id
        });

        const res = await ApiClient.rechargeCoins(currentUser.id, coins, pkg.bonus);
        setCurrentUser({ ...currentUser, coins: res.newCoins });
        showNotification(`🎉 Recharged ${(coins + (pkg.bonus || 0)).toLocaleString()} coins successfully to Firebase for $${pkg.priceUsd}!`);
      } else if (pkg.currencyType === 'diamond' || pkg.diamonds) {
        const diamonds = pkg.diamonds || 0;
        const res = await ApiClient.rechargeDiamonds(currentUser.id, diamonds);
        setCurrentUser({ ...currentUser, diamonds: res.newDiamonds });
        showNotification(`💎 Recharged ${diamonds.toLocaleString()} diamonds successfully for $${pkg.priceUsd}!`);
      }
    } catch (err: any) {
      showNotification(err.message || 'Recharge failed');
    }
  };

  const handleWithdraw = async (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedCountry && selectedCountry.withdrawalAllowed === false) {
      showNotification(`Withdrawals are currently restricted under ${selectedCountry.name} regulations.`);
      return;
    }

    const amount = parseInt(withdrawAmount, 10);
    if (!amount || amount <= 0 || !currentUser) return;
    if (amount > (currentUser.diamonds || 0)) {
      showNotification('Insufficient diamond balance for withdrawal!');
      return;
    }

    const currentMethod = withdrawMethods.find(m => m.id === selectedMethodId) || withdrawMethods[0];
    const methodName = currentMethod ? currentMethod.name : (bankName || 'Payout');

    if (currentMethod?.minWithdraw && amount < currentMethod.minWithdraw) {
      showNotification(`Minimum withdrawal for ${methodName} is ${currentMethod.minWithdraw.toLocaleString()} 💎`);
      return;
    }
    if (currentMethod?.maxWithdraw && amount > currentMethod.maxWithdraw) {
      showNotification(`Maximum withdrawal for ${methodName} is ${currentMethod.maxWithdraw.toLocaleString()} 💎`);
      return;
    }

    try {
      const details = `${methodName} (${currentMethod?.accountFieldLabel || 'Account'}: ${bankAccount})`;
      const res = await ApiClient.withdrawCash(currentUser.id, amount, details);
      setCurrentUser({ ...currentUser, diamonds: res.newDiamonds });
      showNotification(`💸 Withdrawal request submitted! $${(amount * 0.05).toFixed(2)} USD sent to ${methodName}.`);
      setBankAccount('');
    } catch (err: any) {
      showNotification(err.message || 'Withdrawal failed');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-2xl overflow-y-auto p-4 sm:p-6 animate-fadeIn text-white space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-white/10 pb-4 max-w-4xl mx-auto">
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setActiveModal('none')} 
            className="p-2.5 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/10 text-white transition-all shadow"
            title="Back to App"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-xl font-black flex items-center gap-2">
              <Wallet className="w-6 h-6 text-amber-400" /> My Wallet & Ledger
            </h2>
            <p className="text-xs text-slate-300">Manage instant coin recharge, balance direct editing, and diamond cash payouts</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => openEditModal('coin')}
            className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 text-black font-black text-xs flex items-center gap-1.5 shadow-lg hover:scale-105 transition-transform"
          >
            <Edit3 className="w-3.5 h-3.5" /> Edit Coin Amount
          </button>
        </div>
      </div>

      <div className="max-w-4xl mx-auto space-y-6">
        {/* Balance Cards with Direct Edit Buttons */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* COIN BALANCE CARD */}
          <div className="relative overflow-hidden p-6 rounded-3xl bg-gradient-to-br from-amber-950/60 via-purple-950/40 to-black/80 backdrop-blur-xl border border-amber-500/40 space-y-3 shadow-2xl">
            <div className="flex items-center justify-between">
              <span className="text-xs text-amber-300 font-black uppercase tracking-wider flex items-center gap-1.5">
                🪙 Coin Balance
              </span>
              <button
                onClick={() => openEditModal('coin')}
                className="px-2.5 py-1 rounded-lg bg-amber-400/20 hover:bg-amber-400 text-amber-300 hover:text-black font-black text-[11px] flex items-center gap-1 border border-amber-400/40 transition-colors shadow"
              >
                <Edit3 className="w-3 h-3" /> Edit Amount
              </button>
            </div>

            <div className="flex items-baseline justify-between">
              <h3 className="text-3xl sm:text-4xl font-black text-amber-300 font-mono tracking-tight">
                {currentUser?.coins?.toLocaleString() || 0}
              </h3>
              <span className="text-[11px] text-amber-200/80 font-bold bg-amber-400/10 px-2 py-0.5 rounded-full border border-amber-400/20">
                Gifting Currency
              </span>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-amber-500/20">
              <p className="text-[11px] text-slate-300">Used for sending luxury gifts in voice rooms & games</p>
              <div className="flex gap-1.5">
                <button
                  onClick={() => {
                    setCustomCoinAmount('100000');
                    setActiveTab('recharge');
                  }}
                  className="text-[10px] font-bold text-amber-300 bg-black/50 hover:bg-amber-400 hover:text-black px-2 py-0.5 rounded-md border border-amber-400/30 transition-colors"
                >
                  +100K Quick
                </button>
                <button
                  onClick={() => {
                    setCustomCoinAmount('1000000');
                    setActiveTab('recharge');
                  }}
                  className="text-[10px] font-bold text-amber-300 bg-black/50 hover:bg-amber-400 hover:text-black px-2 py-0.5 rounded-md border border-amber-400/30 transition-colors"
                >
                  +1M Quick
                </button>
              </div>
            </div>
          </div>

          {/* DIAMOND BALANCE CARD */}
          <div className="relative overflow-hidden p-6 rounded-3xl bg-gradient-to-br from-cyan-950/60 via-purple-950/40 to-black/80 backdrop-blur-xl border border-cyan-500/40 space-y-3 shadow-2xl">
            <div className="flex items-center justify-between">
              <span className="text-xs text-cyan-300 font-black uppercase tracking-wider flex items-center gap-1.5">
                💎 Diamond Balance
              </span>
              <button
                onClick={() => openEditModal('diamond')}
                className="px-2.5 py-1 rounded-lg bg-cyan-400/20 hover:bg-cyan-400 text-cyan-300 hover:text-black font-black text-[11px] flex items-center gap-1 border border-cyan-400/40 transition-colors shadow"
              >
                <Edit3 className="w-3 h-3" /> Edit Amount
              </button>
            </div>

            <div className="flex items-baseline justify-between">
              <h3 className="text-3xl sm:text-4xl font-black text-cyan-300 font-mono tracking-tight">
                {currentUser?.diamonds?.toLocaleString() || 0}
              </h3>
              <span className="text-[11px] text-cyan-200/80 font-bold bg-cyan-400/10 px-2 py-0.5 rounded-full border border-cyan-400/20">
                ≈ ${(((currentUser?.diamonds || 0) * 0.05)).toFixed(2)} USD
              </span>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-cyan-500/20">
              <p className="text-[11px] text-slate-300">Earned from broadcast gifts • Withdraw anytime for real cash</p>
              <button
                onClick={() => setActiveTab('withdraw')}
                className="text-[10px] font-bold text-cyan-300 bg-black/50 hover:bg-cyan-400 hover:text-black px-2 py-0.5 rounded-md border border-cyan-400/30 transition-colors"
              >
                Withdraw ➔
              </button>
            </div>
          </div>
        </div>

        {/* REGIONAL BILLING & PAYMENT GATEWAY BAR */}
        {countries.length > 0 && (
          <div className="p-4 rounded-3xl bg-white/5 border border-white/10 backdrop-blur-xl flex flex-wrap items-center justify-between gap-4 shadow-xl">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-400/20 border border-amber-400/40 flex items-center justify-center text-xl shadow-inner">
                {selectedCountry?.flag || '🌐'}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-black text-white">Payment Region:</span>
                  <select
                    value={selectedCountryId}
                    onChange={(e) => setSelectedCountryId(e.target.value)}
                    className="bg-black/60 text-amber-300 font-bold text-xs px-3 py-1.5 rounded-xl border border-white/20 focus:outline-none focus:border-amber-400 cursor-pointer"
                  >
                    {countries.map((c) => (
                      <option key={c.id} value={c.id} className="bg-slate-900 text-white">
                        {c.flag} {c.name} ({c.currencyCode} {c.currencySymbol})
                      </option>
                    ))}
                  </select>
                </div>
                <div className="flex flex-wrap items-center gap-2 mt-1 text-[11px] text-slate-400 font-mono">
                  <span>Code: {selectedCountry?.countryCode} ({selectedCountry?.iso2})</span>
                  <span>•</span>
                  <span>Dial: {selectedCountry?.dialCode}</span>
                  <span>•</span>
                  <span>Currency: {selectedCountry?.currencyName} ({selectedCountry?.currencySymbol})</span>
                  <span>•</span>
                  <span>TZ: {selectedCountry?.timeZone}</span>
                </div>
              </div>
            </div>

            {/* Methods supported */}
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
                {activeTab === 'withdraw' ? 'Supported Cashout Methods:' : 'Supported Gateway Methods:'}
              </span>
              <div className="flex items-center gap-1.5 flex-wrap max-w-sm">
                {(activeTab === 'withdraw' ? selectedCountry?.supportedWithdrawalMethods : selectedCountry?.supportedPaymentMethods)?.map((m) => (
                  <span key={m} className="px-2 py-0.5 rounded-lg bg-amber-400/15 text-amber-300 border border-amber-400/30 text-[10px] font-black">
                    {m}
                  </span>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* REGIONAL RESTRICTION ALERTS */}
        {activeTab === 'recharge' && selectedCountry && selectedCountry.rechargeAllowed === false && (
          <div className="p-4 bg-rose-500/15 border-2 border-rose-500/40 rounded-3xl text-rose-200 text-xs flex items-center gap-3">
            <span className="text-xl">⚠️</span>
            <div>
              <p className="font-bold">Recharge is temporarily restricted in {selectedCountry.name}.</p>
              <p className="text-[11px] text-rose-300/80">Local payment gateways and instant mint are disabled under this jurisdiction.</p>
            </div>
          </div>
        )}

        {activeTab === 'withdraw' && selectedCountry && selectedCountry.withdrawalAllowed === false && (
          <div className="p-4 bg-rose-500/15 border-2 border-rose-500/40 rounded-3xl text-rose-200 text-xs flex items-center gap-3">
            <span className="text-xl">⚠️</span>
            <div>
              <p className="font-bold">Withdrawals are temporarily restricted in {selectedCountry.name}.</p>
              <p className="text-[11px] text-rose-300/80">Cashout requests cannot be initiated under this jurisdiction.</p>
            </div>
          </div>
        )}

        {/* Tabs */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 p-1.5 bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 shadow-lg">
          {[
            { id: 'recharge', label: 'Recharge 🪙' },
            { id: 'firebase_wallet', label: 'Firebase Wallet ☁️' },
            { id: 'withdraw', label: 'Withdraw 💵' },
            { id: 'history', label: 'Ledger 📊' }
          ].map(t => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id as any)}
              className={`py-2.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === t.id ? 'bg-gradient-to-r from-amber-500 to-yellow-600 text-black font-black shadow-md' : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* TAB: FIREBASE WALLET (REAL-TIME FIRESTORE CURRENCY) */}
        {activeTab === 'firebase_wallet' && (
          <div className="animate-fadeIn">
            <FirebaseWalletComponent variant="full" />
          </div>
        )}

        {/* TAB 1: RECHARGE WITH CUSTOM COIN AMOUNT FEATURE */}
        {activeTab === 'recharge' && (
          <div className="space-y-6 animate-fadeIn">
            {/* ⚡ CUSTOM COIN AMOUNT RECHARGE & DIRECT MINT SECTION */}
            <div className="p-6 rounded-3xl bg-gradient-to-br from-amber-950/70 via-slate-900/80 to-purple-950/70 border-2 border-amber-500/50 shadow-2xl space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-amber-500/30 pb-3">
                <div>
                  <h4 className="text-sm font-black text-amber-300 uppercase tracking-wider flex items-center gap-2">
                    <Zap className="w-5 h-5 text-amber-400 fill-amber-400 animate-pulse" /> Custom Coin Amount Recharge & Instant Mint
                  </h4>
                  <p className="text-xs text-slate-300 mt-0.5">
                    Type any custom quantity of coins to credit your wallet instantly without restrictions
                  </p>
                </div>
                <span className="px-2.5 py-1 bg-amber-400 text-black font-black text-[10px] rounded-full uppercase shadow">
                  ⚡ INSTANT WALLET CREDIT
                </span>
              </div>

              <form onSubmit={handleCustomRecharge} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 items-end">
                  <div className="md:col-span-2 space-y-1.5">
                    <label className="block text-xs font-bold text-amber-200">
                      Enter Coin Quantity (e.g. 50,000, 100,000, 1,000,000)
                    </label>
                    <div className="relative">
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-xl">🪙</span>
                      <input
                        type="number"
                        min="1"
                        step="1000"
                        value={customCoinAmount}
                        onChange={(e) => setCustomCoinAmount(e.target.value)}
                        placeholder="Enter coin amount..."
                        className="w-full bg-black/60 text-amber-300 font-mono font-black text-base pl-12 pr-4 py-3.5 rounded-2xl border border-amber-500/40 focus:outline-none focus:border-amber-400 shadow-inner"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={customRecharging}
                    className="w-full py-3.5 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-yellow-300 text-black font-black text-sm rounded-2xl shadow-xl hover:scale-[1.02] transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    <Sparkles className="w-4 h-4 text-black" />
                    {customRecharging ? 'Processing...' : 'Add Coins Instantly'}
                  </button>
                </div>

                {/* Quick Add Presets */}
                <div className="space-y-1.5 pt-1">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider">
                    Quick Preset Amounts:
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {[
                      { label: '+10,000 Coins', val: '10000' },
                      { label: '+25,000 Coins', val: '25000' },
                      { label: '+50,000 Coins', val: '50000' },
                      { label: '+100,000 Coins', val: '100000' },
                      { label: '+500,000 Coins', val: '500000' },
                      { label: '+1,000,000 Coins (1M)', val: '1000000' },
                      { label: '+5,000,000 Coins (5M)', val: '5000000' }
                    ].map((preset) => (
                      <button
                        key={preset.val}
                        type="button"
                        onClick={() => {
                          setCustomCoinAmount(preset.val);
                        }}
                        className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all border ${
                          customCoinAmount === preset.val
                            ? 'bg-amber-400 text-black border-amber-300 shadow-md scale-105'
                            : 'bg-black/40 text-amber-200 border-white/10 hover:border-amber-400 hover:bg-amber-400/20'
                        }`}
                      >
                        {preset.label}
                      </button>
                    ))}
                  </div>
                </div>
              </form>
            </div>

            {/* PREDEFINED RECHARGE PACKAGES */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-xs font-black text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-amber-400" /> Standard Coin Recharge Packages (Gifting)
                </h4>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={fetchPackages}
                    title="Refresh live package prices"
                    className="text-[10px] text-amber-400/80 hover:text-amber-300 flex items-center gap-1 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/20"
                  >
                    <RefreshCw className={`w-2.5 h-2.5 ${loadingPackages ? 'animate-spin' : ''}`} />
                    Live Rates
                  </button>
                </div>
              </div>

              {activeCoinPackages.length === 0 ? (
                <div className="p-6 text-center rounded-2xl bg-white/5 border border-white/10">
                  <p className="text-xs text-slate-400">Loading live coin packages...</p>
                </div>
              ) : (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {activeCoinPackages.map((pkg) => (
                    <div
                      key={pkg.id}
                      onClick={() => handleRechargePackage(pkg)}
                      className="cursor-pointer relative p-4 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 hover:border-amber-400 hover:scale-[1.02] transition-all text-center space-y-2 shadow-xl group"
                    >
                      {pkg.badge && (
                        <span className="absolute -top-2.5 left-1/2 -translate-x-1/2 bg-purple-600 text-white text-[9px] font-black px-2.5 py-0.5 rounded-full shadow border border-purple-400/40">
                          {pkg.badge}
                        </span>
                      )}
                      {!pkg.badge && pkg.popular && (
                        <span className="absolute -top-2.5 left-1/2 -translate-x-1/2 bg-amber-500 text-black text-[9px] font-black px-2.5 py-0.5 rounded-full shadow">
                          POPULAR
                        </span>
                      )}
                      {!pkg.badge && !pkg.popular && pkg.bestValue && (
                        <span className="absolute -top-2.5 left-1/2 -translate-x-1/2 bg-gradient-to-r from-red-500 to-pink-500 text-white text-[9px] font-black px-2.5 py-0.5 rounded-full shadow">
                          BEST VALUE
                        </span>
                      )}
                      <div className="text-3xl group-hover:scale-110 transition-transform">🪙</div>
                      <h5 className="font-black text-white text-base">
                        {(pkg.coins || 0).toLocaleString()} <span className="text-xs text-slate-300">Coins</span>
                      </h5>
                      {(pkg.bonus || 0) > 0 && (
                        <span className="bg-emerald-500/20 text-emerald-300 text-[10px] font-bold px-2 py-0.5 rounded-md inline-block border border-emerald-500/30">
                          +{(pkg.bonus || 0).toLocaleString()} Free Bonus
                        </span>
                      )}
                      <div className="pt-2">
                        <button className="w-full py-2 bg-white text-purple-900 group-hover:bg-amber-400 group-hover:text-black font-black text-xs rounded-xl transition-all shadow">
                          ${pkg.priceUsd} USD
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* DIAMOND PACKAGES */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-xs font-black text-cyan-300 uppercase tracking-wider flex items-center gap-1.5">
                  💎 Diamond Packages (Host & Agency)
                </h4>
              </div>

              {activeDiamondPackages.length === 0 ? (
                <div className="p-6 text-center rounded-2xl bg-white/5 border border-white/10">
                  <p className="text-xs text-slate-400">Loading live diamond packages...</p>
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {activeDiamondPackages.map((pkg) => (
                    <div
                      key={pkg.id}
                      onClick={() => handleRechargePackage(pkg)}
                      className="cursor-pointer relative p-4 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 hover:border-cyan-400 hover:scale-[1.02] transition-all text-center space-y-2 shadow-xl group"
                    >
                      {pkg.badge && (
                        <span className="absolute -top-2.5 left-1/2 -translate-x-1/2 bg-cyan-600 text-white text-[9px] font-black px-2.5 py-0.5 rounded-full shadow">
                          {pkg.badge}
                        </span>
                      )}
                      {!pkg.badge && pkg.popular && (
                        <span className="absolute -top-2.5 left-1/2 -translate-x-1/2 bg-cyan-500 text-black text-[9px] font-black px-2.5 py-0.5 rounded-full shadow">
                          POPULAR
                        </span>
                      )}
                      <div className="text-3xl group-hover:scale-110 transition-transform">💎</div>
                      <h5 className="font-black text-white text-sm">{(pkg.diamonds || 0).toLocaleString()} <span className="text-xs text-slate-300">Diamonds</span></h5>
                      <div className="pt-2">
                        <button className="w-full py-1.5 bg-white text-purple-900 group-hover:bg-cyan-400 group-hover:text-black font-black text-xs rounded-xl shadow transition-all">
                          ${pkg.priceUsd} USD
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 2: WITHDRAW FORM */}
        {activeTab === 'withdraw' && (
          <form onSubmit={handleWithdraw} className="bg-white/5 backdrop-blur-xl p-6 rounded-3xl border border-white/10 space-y-4 shadow-xl animate-fadeIn">
            {(() => {
              const currentMethod = withdrawMethods.find(m => m.id === selectedMethodId) || withdrawMethods[0];
              const minLimit = currentMethod?.minWithdraw || 100;
              const maxLimit = currentMethod?.maxWithdraw || 50000;
              const fee = currentMethod?.processingFee || 0;
              const currency = currentMethod?.currency || 'USD';

              return (
                <>
                  <div className="p-4 rounded-2xl bg-black/40 border border-cyan-500/30 flex items-center justify-between shadow">
                    <div>
                      <span className="text-xs text-slate-300">Available Withdraw Diamonds</span>
                      <h4 className="text-2xl font-black text-cyan-300 font-mono">💎 {currentUser?.diamonds?.toLocaleString() || 0}</h4>
                    </div>
                    <div className="text-right">
                      <span className="text-xs text-emerald-400 font-extrabold block">Rate: 100 💎 = $5.00 USD</span>
                      <span className="text-[10px] text-slate-400">Min. withdraw: {minLimit.toLocaleString()} 💎</span>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">
                      Withdraw Amount (Diamonds) <span className="text-slate-400 font-normal">({minLimit.toLocaleString()} - {maxLimit.toLocaleString()} 💎)</span>
                    </label>
                    <input
                      type="number"
                      required
                      min={minLimit}
                      max={maxLimit}
                      step="10"
                      value={withdrawAmount}
                      onChange={(e) => setWithdrawAmount(e.target.value)}
                      className="w-full bg-black/40 text-white font-mono text-xs px-4 py-3 rounded-xl border border-white/10 focus:outline-none focus:border-cyan-400 font-bold"
                    />
                    <div className="flex items-center justify-between text-[10px] text-slate-400 mt-1">
                      <p>
                        Estimated Payout: <span className="text-emerald-400 font-bold">${((parseInt(withdrawAmount || '0') * 0.05) * (1 - fee / 100)).toFixed(2)} {currency}</span>
                      </p>
                      {fee > 0 ? (
                        <span className="text-amber-400">Processing Fee: {fee}%</span>
                      ) : (
                        <span className="text-emerald-400">Processing Fee: Free (0%)</span>
                      )}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1.5">
                      Select Payout Gateway / Method
                    </label>
                    {loadingWithdrawMethods && withdrawMethods.length === 0 ? (
                      <div className="p-3 bg-black/40 rounded-xl border border-white/10 text-xs text-slate-400">
                        Loading payout gateways...
                      </div>
                    ) : withdrawMethods.length === 0 ? (
                      <div className="p-3 bg-black/40 rounded-xl border border-amber-500/30 text-xs text-amber-300">
                        No active withdrawal methods available. Please contact admin.
                      </div>
                    ) : (
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mb-2">
                        {withdrawMethods.map((method) => {
                          const isSelected = (selectedMethodId ? selectedMethodId === method.id : withdrawMethods[0]?.id === method.id);
                          return (
                            <button
                              key={method.id}
                              type="button"
                              onClick={() => {
                                setSelectedMethodId(method.id);
                                setBankName(method.name);
                              }}
                              className={`p-3 rounded-xl border text-left transition-all relative ${
                                isSelected
                                  ? 'bg-gradient-to-br from-emerald-500/20 to-teal-500/20 border-emerald-400 shadow-md shadow-emerald-500/10'
                                  : 'bg-black/40 border-white/10 hover:border-white/20 text-slate-300'
                              }`}
                            >
                              <div className="flex items-center justify-between mb-1">
                                <span className="font-black text-xs text-white">{method.name}</span>
                                <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono text-[9px] font-bold">
                                  {method.currency}
                                </span>
                              </div>
                              <p className="text-[10px] text-slate-400 truncate">
                                {method.accountFieldLabel}
                              </p>
                              {isSelected && (
                                <div className="absolute top-1 right-1 w-2 h-2 rounded-full bg-emerald-400 shadow" />
                              )}
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">
                      {currentMethod?.accountFieldLabel || 'Account Number / ID / Email'} <span className="text-cyan-400">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      placeholder={currentMethod?.placeholder || 'Enter your payout account details'}
                      value={bankAccount}
                      onChange={(e) => setBankAccount(e.target.value)}
                      className="w-full bg-black/40 text-white text-xs px-4 py-3 rounded-xl border border-white/10 focus:outline-none focus:border-cyan-400 font-medium placeholder:text-slate-500"
                    />
                    <p className="text-[10px] text-slate-400 mt-1">
                      Ensure your {currentMethod?.name || 'payout'} account details are accurate before submitting.
                    </p>
                  </div>

                  <button
                    type="submit"
                    disabled={withdrawMethods.length === 0}
                    className="w-full py-4 bg-gradient-to-r from-emerald-400 via-teal-400 to-cyan-400 hover:from-emerald-300 hover:to-cyan-300 text-black font-black text-sm rounded-2xl shadow-xl transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    <CreditCard className="w-4 h-4" /> Request Cash Payout via {currentMethod?.name || 'Selected Gateway'}
                  </button>
                </>
              );
            })()}
          </form>
        )}

        {/* TAB 3: TRANSACTION LEDGER */}
        {activeTab === 'history' && (
          <div className="space-y-4 animate-fadeIn">
            <div className="flex gap-1 overflow-x-auto pb-1">
              {['all', 'coin', 'diamond', 'gift'].map((ht) => (
                <button
                  key={ht}
                  onClick={() => setHistoryTab(ht as any)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold capitalize flex-shrink-0 transition-all ${
                    historyTab === ht ? 'bg-amber-400 text-black font-black shadow' : 'bg-white/5 backdrop-blur-md text-slate-300 hover:text-white border border-white/10'
                  }`}
                >
                  {ht === 'all' ? 'All Ledger' : `${ht}s`}
                </button>
              ))}
            </div>

            <div className="space-y-2.5">
              {transactions.filter(t => historyTab === 'all' || t.currency === historyTab || (historyTab === 'gift' && t.type === 'gift_send')).length === 0 ? (
                <p className="text-xs text-slate-400 text-center py-8">No transactions recorded in this filter yet.</p>
              ) : (
                transactions.filter(t => historyTab === 'all' || t.currency === historyTab || (historyTab === 'gift' && t.type === 'gift_send')).map((tx) => (
                  <div key={tx.id} className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 flex items-center justify-between shadow-xl">
                    <div className="flex items-center gap-3">
                      <span className="w-9 h-9 rounded-xl bg-white/10 border border-white/10 flex items-center justify-center text-lg">
                        {tx.type === 'recharge' ? '⚡' : tx.type === 'gift_send' ? '🎁' : tx.type === 'withdraw' ? '💸' : '💎'}
                      </span>
                      <div>
                        <h5 className="font-bold text-white text-xs">{tx.description}</h5>
                        <span className="text-[10px] text-slate-400">{new Date(tx.timestamp).toLocaleTimeString()} • {tx.status.toUpperCase()}</span>
                      </div>
                    </div>
                    <span className={`font-black text-xs font-mono ${tx.amount > 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {tx.amount > 0 ? `+${tx.amount.toLocaleString()}` : tx.amount.toLocaleString()} {tx.currency === 'coin' ? '🪙' : '💎'}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* 🛠️ EDIT WALLET BALANCE MODAL (DIRECT COIN / DIAMOND EDITOR) */}
      {/* ========================================================================= */}
      {isEditModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
          <div className="w-full max-w-lg bg-slate-900 border border-amber-500/40 rounded-3xl p-6 shadow-2xl space-y-5 animate-scaleUp">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-amber-400/20 border border-amber-400/40 text-amber-400">
                  <Sliders className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white flex items-center gap-2">
                    Edit {editTargetCurrency === 'coin' ? 'Coin 🪙' : 'Diamond 💎'} Balance
                  </h3>
                  <p className="text-[11px] text-slate-400">Directly set or modify wallet balance in real-time</p>
                </div>
              </div>
              <button
                onClick={() => setIsEditModalOpen(false)}
                className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Currency Selector */}
            <div className="grid grid-cols-2 gap-2 p-1 bg-black/40 rounded-2xl border border-white/10">
              <button
                type="button"
                onClick={() => {
                  setEditTargetCurrency('coin');
                  setExactBalanceInput(String(currentUser?.coins || 0));
                }}
                className={`py-2 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all ${
                  editTargetCurrency === 'coin'
                    ? 'bg-amber-400 text-black shadow-md'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                🪙 Coin Balance ({currentUser?.coins?.toLocaleString() || 0})
              </button>
              <button
                type="button"
                onClick={() => {
                  setEditTargetCurrency('diamond');
                  setExactBalanceInput(String(currentUser?.diamonds || 0));
                }}
                className={`py-2 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all ${
                  editTargetCurrency === 'diamond'
                    ? 'bg-cyan-400 text-black shadow-md'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                💎 Diamond Balance ({currentUser?.diamonds?.toLocaleString() || 0})
              </button>
            </div>

            {/* Mode Switch: Set Exact vs Quick Adjust */}
            <div className="flex border-b border-white/10 gap-4 text-xs font-bold">
              <button
                type="button"
                onClick={() => setEditMode('set_exact')}
                className={`pb-2 border-b-2 transition-all ${
                  editMode === 'set_exact'
                    ? 'border-amber-400 text-amber-300 font-black'
                    : 'border-transparent text-slate-400 hover:text-white'
                }`}
              >
                1. Set Exact Total Amount
              </button>
              <button
                type="button"
                onClick={() => setEditMode('quick_adjust')}
                className={`pb-2 border-b-2 transition-all ${
                  editMode === 'quick_adjust'
                    ? 'border-amber-400 text-amber-300 font-black'
                    : 'border-transparent text-slate-400 hover:text-white'
                }`}
              >
                2. Quick Add / Deduct (+ / -)
              </button>
            </div>

            {/* MODE 1: SET EXACT BALANCE */}
            {editMode === 'set_exact' && (
              <form onSubmit={handleSaveExactBalance} className="space-y-4">
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-300">
                    New Total {editTargetCurrency === 'coin' ? 'Coin' : 'Diamond'} Amount
                  </label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-xl">
                      {editTargetCurrency === 'coin' ? '🪙' : '💎'}
                    </span>
                    <input
                      type="number"
                      required
                      min="0"
                      value={exactBalanceInput}
                      onChange={(e) => setExactBalanceInput(e.target.value)}
                      className="w-full bg-black/60 text-white font-mono font-black text-lg pl-12 pr-4 py-3.5 rounded-2xl border border-white/20 focus:outline-none focus:border-amber-400"
                    />
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Current balance: <span className="font-mono text-white font-bold">{editTargetCurrency === 'coin' ? currentUser?.coins?.toLocaleString() : currentUser?.diamonds?.toLocaleString()}</span>
                  </p>
                </div>

                {/* Preset shortcuts */}
                <div className="space-y-1">
                  <span className="text-[10px] font-black text-slate-400 uppercase">Preset Total Targets:</span>
                  <div className="flex flex-wrap gap-1.5">
                    {['100000', '500000', '1000000', '2500000', '5000000', '10000000'].map((preset) => (
                      <button
                        key={preset}
                        type="button"
                        onClick={() => setExactBalanceInput(preset)}
                        className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-amber-400 hover:text-black border border-white/10 text-[11px] font-mono font-bold text-slate-200 transition-colors"
                      >
                        {Number(preset).toLocaleString()}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsEditModalOpen(false)}
                    className="flex-1 py-3 bg-white/10 hover:bg-white/20 text-white font-bold text-xs rounded-2xl"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={savingBalance}
                    className="flex-1 py-3 bg-amber-400 hover:bg-amber-300 text-black font-black text-xs rounded-2xl shadow-xl flex items-center justify-center gap-1.5 disabled:opacity-50"
                  >
                    <Save className="w-4 h-4" />
                    {savingBalance ? 'Saving...' : 'Save New Balance'}
                  </button>
                </div>
              </form>
            )}

            {/* MODE 2: QUICK ADD / DEDUCT */}
            {editMode === 'quick_adjust' && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <span className="text-[11px] font-black text-slate-300 uppercase block">1-Click Fast Adjustments:</span>
                  <div className="grid grid-cols-3 gap-2">
                    {[10000, 50000, 100000, 500000, 1000000, 5000000].map((amt) => (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => handleQuickAdjust(amt, 'add')}
                        disabled={savingBalance}
                        className="p-2.5 rounded-xl bg-emerald-950/60 hover:bg-emerald-600 border border-emerald-500/40 text-emerald-300 hover:text-white font-black text-xs flex items-center justify-center gap-1 transition-all shadow"
                      >
                        <PlusCircle className="w-3.5 h-3.5" /> +{amt >= 1000000 ? `${amt / 1000000}M` : `${amt / 1000}K`}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2 pt-2 border-t border-white/10">
                  <span className="text-[11px] font-black text-slate-300 uppercase block">Deduct Balance:</span>
                  <div className="grid grid-cols-3 gap-2">
                    {[10000, 50000, 100000].map((amt) => (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => handleQuickAdjust(amt, 'deduct')}
                        disabled={savingBalance}
                        className="p-2.5 rounded-xl bg-rose-950/60 hover:bg-rose-600 border border-rose-500/40 text-rose-300 hover:text-white font-black text-xs flex items-center justify-center gap-1 transition-all shadow"
                      >
                        <MinusCircle className="w-3.5 h-3.5" /> -{amt / 1000}K
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    type="button"
                    onClick={() => setIsEditModalOpen(false)}
                    className="px-6 py-2.5 bg-white/10 hover:bg-white/20 text-white font-bold text-xs rounded-xl"
                  >
                    Close
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
