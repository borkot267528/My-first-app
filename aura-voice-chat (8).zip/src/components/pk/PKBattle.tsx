/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  Swords, 
  Flame, 
  Shield, 
  Trophy, 
  Clock, 
  Zap, 
  Gift as GiftIcon, 
  Users, 
  Volume2, 
  VolumeX, 
  Eye, 
  Sparkles, 
  ArrowRight,
  TrendingUp,
  Award,
  Crown
} from 'lucide-react';
import { VoiceRoom } from '../../types';

export interface CompetingVoiceRoom {
  id?: string;
  name: string;
  hostName: string;
  hostAvatar: string;
  score: number;
  viewersCount?: number;
  isHostSpeaking?: boolean;
  topSupporters?: Array<{
    name: string;
    avatar: string;
    contribution: number;
  }>;
}

export interface PKBattleProps {
  /** Room A (Red Challenger side) */
  roomA?: Partial<VoiceRoom> | CompetingVoiceRoom;
  /** Room B (Blue Defender side) */
  roomB?: Partial<VoiceRoom> | CompetingVoiceRoom;
  /** Real-time score for Room A */
  scoreA?: number;
  /** Real-time score for Room B */
  scoreB?: number;
  /** Initial or countdown remaining time in seconds or string (e.g. 180, "2:45", "3m 00s") */
  timeLeft?: number | string;
  /** Total battle duration in seconds (defaults to 180 = 3 mins) */
  durationSeconds?: number;
  /** Display variant: 'split' (full arena clash), 'compact' (in-room floating split bar), or 'card' (lobby widget) */
  variant?: 'split' | 'compact' | 'card';
  /** Callback fired when user cheers / sends gift points to a room side */
  onCheer?: (side: 'roomA' | 'roomB', points: number) => void;
  /** Callback fired when the battle ends */
  onBattleEnd?: (winner: 'roomA' | 'roomB' | 'draw') => void;
  /** Callback when user clicks to enter/watch a competing room */
  onWatchRoom?: (roomId: string, roomName: string) => void;
  /** Optional container class name */
  className?: string;
  /** Sound effects toggle */
  enableSound?: boolean;
}

/**
 * PKBattle: High-energy split-screen progress bar with real-time score indicators
 * for two competing voice rooms in live streaming battles.
 */
export const PKBattle: React.FC<PKBattleProps> = ({
  roomA: propRoomA,
  roomB: propRoomB,
  scoreA: controlledScoreA,
  scoreB: controlledScoreB,
  timeLeft: propTimeLeft,
  durationSeconds = 180,
  variant = 'split',
  onCheer,
  onBattleEnd,
  onWatchRoom,
  className = '',
  enableSound = true,
}) => {
  // Parse duration & countdown
  const initialCountdown = useMemo(() => {
    if (typeof propTimeLeft === 'number') return Math.max(0, propTimeLeft);
    if (typeof propTimeLeft === 'string') {
      const minMatch = propTimeLeft.match(/(\d+)\s*m/i);
      const secMatch = propTimeLeft.match(/(\d+)\s*s/i);
      const m = minMatch ? parseInt(minMatch[1], 10) : 0;
      const s = secMatch ? parseInt(secMatch[1], 10) : 0;
      if (m > 0 || s > 0) return m * 60 + s;
      const colonSplit = propTimeLeft.split(':');
      if (colonSplit.length === 2) {
        const mins = parseInt(colonSplit[0], 10);
        const secs = parseInt(colonSplit[1], 10);
        if (!isNaN(mins) && !isNaN(secs)) return mins * 60 + secs;
      }
      const plain = parseInt(propTimeLeft, 10);
      if (!isNaN(plain)) return plain;
    }
    return durationSeconds;
  }, [propTimeLeft, durationSeconds]);

  const [countdown, setCountdown] = useState<number>(initialCountdown);
  const [soundActive, setSoundActive] = useState<boolean>(enableSound);
  const [giftToast, setGiftToast] = useState<{ side: 'roomA' | 'roomB'; amount: number; message: string } | null>(null);

  // Internal live scores with real-time fallback defaults
  const [scoreA, setScoreA] = useState<number>(() => {
    if (controlledScoreA !== undefined) return controlledScoreA;
    if (propRoomA && 'score' in propRoomA && typeof propRoomA.score === 'number') return propRoomA.score;
    return 48500;
  });

  const [scoreB, setScoreB] = useState<number>(() => {
    if (controlledScoreB !== undefined) return controlledScoreB;
    if (propRoomB && 'score' in propRoomB && typeof propRoomB.score === 'number') return propRoomB.score;
    return 42200;
  });

  // Track latest score changes for animation pop
  const [pulseSide, setPulseSide] = useState<'roomA' | 'roomB' | null>(null);

  // Sync external score props if provided
  useEffect(() => {
    if (controlledScoreA !== undefined) {
      setScoreA(controlledScoreA);
      setPulseSide('roomA');
      const timer = setTimeout(() => setPulseSide(null), 600);
      return () => clearTimeout(timer);
    }
  }, [controlledScoreA]);

  useEffect(() => {
    if (controlledScoreB !== undefined) {
      setScoreB(controlledScoreB);
      setPulseSide('roomB');
      const timer = setTimeout(() => setPulseSide(null), 600);
      return () => clearTimeout(timer);
    }
  }, [controlledScoreB]);

  // Sync external timeLeft updates
  useEffect(() => {
    if (typeof propTimeLeft === 'number') {
      setCountdown(propTimeLeft);
    }
  }, [propTimeLeft]);

  // Live Countdown Loop
  useEffect(() => {
    if (countdown <= 0) {
      if (onBattleEnd) {
        const winner = scoreA > scoreB ? 'roomA' : scoreB > scoreA ? 'roomB' : 'draw';
        onBattleEnd(winner);
      }
      return;
    }

    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          if (onBattleEnd) {
            const winner = scoreA > scoreB ? 'roomA' : scoreB > scoreA ? 'roomB' : 'draw';
            onBattleEnd(winner);
          }
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [countdown, scoreA, scoreB, onBattleEnd]);

  // Normalization of Room Data
  const redRoom: CompetingVoiceRoom = useMemo(() => ({
    id: (propRoomA as any)?.id || 'room-red-01',
    name: (propRoomA as any)?.title || (propRoomA as any)?.name || 'Red Flame Empire 🔥',
    hostName: (propRoomA as any)?.hostName || 'Elena Vance',
    hostAvatar: (propRoomA as any)?.hostAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200',
    score: scoreA,
    viewersCount: (propRoomA as any)?.onlineCount || (propRoomA as any)?.viewersCount || 1840,
    isHostSpeaking: true,
    topSupporters: (propRoomA as any)?.topSupporters || [
      { name: 'Kaiser_99', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100', contribution: 15400 },
      { name: 'Aria_Star', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100', contribution: 9800 },
      { name: 'Leo_VIP', avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=100', contribution: 6200 }
    ]
  }), [propRoomA, scoreA]);

  const blueRoom: CompetingVoiceRoom = useMemo(() => ({
    id: (propRoomB as any)?.id || 'room-blue-02',
    name: (propRoomB as any)?.title || (propRoomB as any)?.name || 'Blue Cyber Legends 🛡️',
    hostName: (propRoomB as any)?.hostName || 'Alex Chen',
    hostAvatar: (propRoomB as any)?.hostAvatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200',
    score: scoreB,
    viewersCount: (propRoomB as any)?.onlineCount || (propRoomB as any)?.viewersCount || 1620,
    isHostSpeaking: false,
    topSupporters: (propRoomB as any)?.topSupporters || [
      { name: 'DragonKing', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100', contribution: 14200 },
      { name: 'Mia_Cyber', avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100', contribution: 8500 },
      { name: 'ShadowZero', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100', contribution: 5900 }
    ]
  }), [propRoomB, scoreB]);

  // Real-time Score Calculations
  const totalScore = Math.max(1, scoreA + scoreB);
  // Red percentage between 10% and 90% so neither bar disappears completely
  const rawRedPct = Math.round((scoreA / totalScore) * 100);
  const redPercentage = Math.min(90, Math.max(10, rawRedPct));
  const bluePercentage = 100 - redPercentage;
  const scoreDifference = Math.abs(scoreA - scoreB);
  const leadingSide = scoreA > scoreB ? 'roomA' : scoreB > scoreA ? 'roomB' : 'draw';

  // Timer formatting
  const minutes = Math.floor(countdown / 60).toString().padStart(2, '0');
  const seconds = (countdown % 60).toString().padStart(2, '0');
  const isUrgent = countdown <= 30 && countdown > 0;
  const isFinished = countdown === 0;

  // Real-time Cheer / Boost handler
  const handleBoost = (side: 'roomA' | 'roomB', amount: number, message: string) => {
    if (side === 'roomA') {
      setScoreA(prev => prev + amount);
    } else {
      setScoreB(prev => prev + amount);
    }

    setPulseSide(side);
    setGiftToast({ side, amount, message });
    setTimeout(() => setGiftToast(null), 2200);

    if (onCheer) {
      onCheer(side, amount);
    }
  };

  // =========================================================================
  // 1. COMPACT VARIANT (Voice Room Stage Header / Banner Strip)
  // =========================================================================
  if (variant === 'compact') {
    return (
      <div className={`relative overflow-hidden rounded-2xl bg-gradient-to-r from-red-950/85 via-black/80 to-blue-950/85 backdrop-blur-xl border border-white/15 p-2.5 sm:p-3 shadow-2xl text-white space-y-2 select-none ${className}`}>
        {/* Header Strip */}
        <div className="flex items-center justify-between gap-2 text-xs">
          {/* Room A Host & Live Score */}
          <div className="flex items-center gap-2 min-w-0 max-w-[42%]">
            <div className="relative shrink-0">
              <img
                src={redRoom.hostAvatar}
                alt={redRoom.hostName}
                className="w-8 h-8 rounded-full object-cover border-2 border-red-500 shadow-md"
              />
              {leadingSide === 'roomA' && (
                <span className="absolute -top-1.5 -left-1 text-xs animate-bounce" title="Leading">👑</span>
              )}
            </div>
            <div className="min-w-0">
              <p className="font-black text-red-400 text-xs truncate flex items-center gap-1">
                <Flame className="w-3 h-3 text-red-500 fill-red-500 shrink-0" />
                <span className="truncate">{redRoom.hostName}</span>
              </p>
              <p className={`font-mono font-extrabold text-white text-xs ${pulseSide === 'roomA' ? 'text-amber-300 scale-105' : ''} transition-transform`}>
                {scoreA.toLocaleString()}
              </p>
            </div>
          </div>

          {/* Center Countdown Clock */}
          <div className="flex flex-col items-center justify-center shrink-0">
            <div className={`px-2.5 py-0.5 rounded-full text-[10px] font-black flex items-center gap-1 shadow-inner ${
              isUrgent ? 'bg-red-600 text-white animate-pulse' : isFinished ? 'bg-emerald-600/30 text-emerald-300 border border-emerald-500/40' : 'bg-white/10 text-amber-300 border border-white/10'
            }`}>
              <Clock className="w-3 h-3" />
              <span className="font-mono">{isFinished ? 'FINAL' : `${minutes}:${seconds}`}</span>
            </div>
            <span className="text-[9px] font-black tracking-widest text-slate-400 uppercase mt-0.5">
              {isFinished ? 'ENDED' : 'PK CLASH'}
            </span>
          </div>

          {/* Room B Host & Live Score */}
          <div className="flex items-center justify-end gap-2 min-w-0 max-w-[42%] text-right">
            <div className="min-w-0">
              <p className="font-black text-blue-400 text-xs truncate flex items-center justify-end gap-1">
                <span className="truncate">{blueRoom.hostName}</span>
                <Shield className="w-3 h-3 text-blue-500 fill-blue-500 shrink-0" />
              </p>
              <p className={`font-mono font-extrabold text-white text-xs ${pulseSide === 'roomB' ? 'text-amber-300 scale-105' : ''} transition-transform`}>
                {scoreB.toLocaleString()}
              </p>
            </div>
            <div className="relative shrink-0">
              <img
                src={blueRoom.hostAvatar}
                alt={blueRoom.hostName}
                className="w-8 h-8 rounded-full object-cover border-2 border-blue-500 shadow-md"
              />
              {leadingSide === 'roomB' && (
                <span className="absolute -top-1.5 -right-1 text-xs animate-bounce" title="Leading">👑</span>
              )}
            </div>
          </div>
        </div>

        {/* Real-Time Split-Screen Progress Bar */}
        <div className="relative h-2.5 w-full bg-blue-600 rounded-full overflow-hidden flex shadow-inner border border-white/10">
          <div
            style={{ width: `${redPercentage}%` }}
            className="h-full bg-gradient-to-r from-red-600 via-rose-500 to-pink-500 transition-all duration-500"
          />
          {/* Clash Sword Center Icon */}
          <div
            style={{ left: `${redPercentage}%` }}
            className="absolute top-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 rounded-full bg-white text-black text-[9px] font-black flex items-center justify-center shadow-lg border border-white transition-all duration-500"
          >
            ⚔️
          </div>
        </div>
      </div>
    );
  }

  // =========================================================================
  // 2. CARD VARIANT (Lobby, Search, or Discovery Feeds)
  // =========================================================================
  if (variant === 'card') {
    return (
      <div className={`p-4 rounded-3xl bg-[#120822]/90 backdrop-blur-xl border border-white/10 hover:border-red-500/40 shadow-xl transition-all duration-300 space-y-3.5 select-none ${className}`}>
        {/* Card Header */}
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5 font-black text-red-400 uppercase text-[11px]">
            <Swords className="w-4 h-4 text-red-500 animate-pulse" />
            <span>Voice PK War</span>
          </div>
          <div className={`px-2.5 py-0.5 rounded-full text-xs font-black flex items-center gap-1 ${
            isUrgent ? 'bg-red-600 text-white animate-pulse' : 'bg-white/10 text-amber-300 border border-white/10'
          }`}>
            <Clock className="w-3.5 h-3.5" />
            <span className="font-mono">{minutes}:{seconds}</span>
          </div>
        </div>

        {/* Competing Face-off Split Grid */}
        <div className="grid grid-cols-2 gap-3 items-center relative">
          {/* Room A Side */}
          <div className="p-3 rounded-2xl bg-red-950/30 border border-red-500/30 text-center space-y-1.5">
            <div className="relative w-12 h-12 mx-auto">
              <img
                src={redRoom.hostAvatar}
                alt={redRoom.hostName}
                className="w-12 h-12 rounded-full object-cover ring-2 ring-red-500 shadow-md"
              />
              {leadingSide === 'roomA' && <span className="absolute -top-2 -right-1 text-xs">👑</span>}
            </div>
            <p className="font-black text-white text-xs truncate">{redRoom.hostName}</p>
            <p className="text-[10px] text-slate-400 truncate">{redRoom.name}</p>
            <p className="font-black text-sm text-red-400 font-mono">
              🔥 {scoreA.toLocaleString()}
            </p>
          </div>

          {/* Central VS Badge */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10 w-7 h-7 rounded-full bg-gradient-to-tr from-red-600 to-blue-600 text-white font-black text-[10px] flex items-center justify-center shadow-lg border border-white/40">
            VS
          </div>

          {/* Room B Side */}
          <div className="p-3 rounded-2xl bg-blue-950/30 border border-blue-500/30 text-center space-y-1.5">
            <div className="relative w-12 h-12 mx-auto">
              <img
                src={blueRoom.hostAvatar}
                alt={blueRoom.hostName}
                className="w-12 h-12 rounded-full object-cover ring-2 ring-blue-500 shadow-md"
              />
              {leadingSide === 'roomB' && <span className="absolute -top-2 -right-1 text-xs">👑</span>}
            </div>
            <p className="font-black text-white text-xs truncate">{blueRoom.hostName}</p>
            <p className="text-[10px] text-slate-400 truncate">{blueRoom.name}</p>
            <p className="font-black text-sm text-blue-400 font-mono">
              🛡️ {scoreB.toLocaleString()}
            </p>
          </div>
        </div>

        {/* Split-Screen Progress Bar */}
        <div className="space-y-1">
          <div className="h-2 w-full bg-blue-600 rounded-full overflow-hidden flex shadow-inner">
            <div
              style={{ width: `${redPercentage}%` }}
              className="h-full bg-gradient-to-r from-red-500 to-pink-500 transition-all duration-500"
            />
          </div>
          <div className="flex justify-between text-[10px] font-mono text-slate-400">
            <span className="text-red-400 font-bold">{redPercentage}%</span>
            <span className="text-blue-400 font-bold">{bluePercentage}%</span>
          </div>
        </div>

        {/* Watch Button */}
        {onWatchRoom && (
          <button
            type="button"
            onClick={() => onWatchRoom(redRoom.id || '', redRoom.name)}
            className="w-full py-2 rounded-xl bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-500 hover:to-pink-500 text-white font-black text-xs shadow-md transition-all flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Enter PK Battle Arena</span>
          </button>
        )}
      </div>
    );
  }

  // =========================================================================
  // 3. FULL SPLIT-SCREEN ARENA VARIANT (Default)
  // =========================================================================
  return (
    <div className={`relative overflow-hidden rounded-3xl bg-gradient-to-b from-[#180828] via-[#0d041a] to-[#07020f] border border-white/15 p-4 sm:p-6 shadow-2xl text-white space-y-6 select-none ${className}`}>
      
      {/* Background Lighting Ambience */}
      <div className="absolute -top-24 -left-24 w-80 h-80 bg-red-600/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -right-24 w-80 h-80 bg-blue-600/15 rounded-full blur-3xl pointer-events-none" />

      {/* Floating Real-time Gift Celebration Toast */}
      {giftToast && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-30 animate-bounce pointer-events-none">
          <div className={`px-4 py-1.5 rounded-full text-xs font-black shadow-2xl border flex items-center gap-2 ${
            giftToast.side === 'roomA'
              ? 'bg-red-600 text-white border-red-400 shadow-red-500/40'
              : 'bg-blue-600 text-white border-blue-400 shadow-blue-500/40'
          }`}>
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>{giftToast.message}</span>
            <span className="bg-white/20 px-2 py-0.5 rounded-full font-mono">+{giftToast.amount}</span>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* TOP HEADER: Battle Name, Status, Countdown & Audio Toggle  */}
      {/* ========================================================= */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-4 relative z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-red-600 via-rose-500 to-amber-500 p-0.5 shadow-lg shadow-red-900/40 flex items-center justify-center">
            <div className="w-full h-full bg-[#170624] rounded-[14px] flex items-center justify-center">
              <Swords className="w-5 h-5 text-amber-300 animate-pulse" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base sm:text-lg font-black tracking-tight text-white">
                Live PK Battle Arena
              </h3>
              <span className={`text-[10px] px-2 py-0.5 rounded-md font-extrabold border uppercase tracking-wider ${
                isFinished 
                  ? 'bg-emerald-600/20 text-emerald-300 border-emerald-500/40' 
                  : 'bg-red-600/30 text-red-300 border-red-500/40'
              }`}>
                {isFinished ? 'Finished' : 'Live Match'}
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-0.5">
              Two competing voice rooms battling for gift supremacy and victory points!
            </p>
          </div>
        </div>

        {/* Timer Box & Sound Toggle */}
        <div className="flex items-center gap-2.5">
          <div className={`px-4 py-2 rounded-2xl backdrop-blur-md border flex items-center gap-2.5 shadow-lg transition-all ${
            isUrgent
              ? 'bg-red-600/30 border-red-500 text-white animate-pulse shadow-red-500/20'
              : isFinished
              ? 'bg-emerald-600/20 border-emerald-500 text-emerald-300'
              : 'bg-white/10 border-white/15 text-amber-300'
          }`}>
            <Clock className={`w-4 h-4 ${isUrgent ? 'text-red-400 animate-spin' : 'text-amber-400'}`} />
            <div>
              <p className="text-[9px] uppercase tracking-wider font-extrabold text-slate-300">
                {isFinished ? 'Match Completed' : isUrgent ? 'Final Countdown' : 'Time Remaining'}
              </p>
              <p className="font-mono text-base sm:text-lg font-black tracking-wider text-white">
                {isFinished ? '00:00' : `${minutes}:${seconds}`}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setSoundActive(!soundActive)}
            className="p-2.5 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/10 text-slate-300 hover:text-white transition-colors cursor-pointer"
            title={soundActive ? 'Mute PK SFX' : 'Enable PK SFX'}
          >
            {soundActive ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4 text-slate-400" />}
          </button>
        </div>
      </div>

      {/* ========================================================= */}
      {/* ARENA: SPLIT-SCREEN COMPETING ROOMS (RED VS BLUE)          */}
      {/* ========================================================= */}
      <div className="grid grid-cols-1 lg:grid-cols-11 gap-4 items-center relative z-10">
        
        {/* ROOM A: RED CHALLENGER CORNER (Col 5) */}
        <div className="lg:col-span-5 p-4 sm:p-5 rounded-3xl bg-gradient-to-br from-red-950/40 via-red-900/10 to-transparent border border-red-500/30 relative overflow-hidden shadow-xl space-y-4">
          {/* Header Row */}
          <div className="flex items-center justify-between">
            <span className="px-2.5 py-1 rounded-xl bg-red-600/30 border border-red-500/40 text-red-300 text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 shadow">
              <Flame className="w-3.5 h-3.5 fill-red-500 text-red-500" /> Red Corner
            </span>
            <div className="flex items-center gap-1.5 text-xs text-slate-300 bg-black/40 px-2.5 py-0.5 rounded-full border border-white/10">
              <Users className="w-3.5 h-3.5 text-red-400" />
              <span className="font-mono font-bold">{redRoom.viewersCount?.toLocaleString()}</span>
              <span className="text-[10px] text-slate-400">listeners</span>
            </div>
          </div>

          {/* Host & Room Info */}
          <div className="flex items-center gap-3.5">
            <div className="relative shrink-0">
              <img
                src={redRoom.hostAvatar}
                alt={redRoom.hostName}
                className="w-16 h-16 sm:w-18 sm:h-18 rounded-2xl object-cover ring-2 ring-red-500 shadow-xl"
              />
              {leadingSide === 'roomA' && (
                <div className="absolute -top-3 -right-2 bg-amber-400 text-black text-[10px] font-black px-1.5 py-0.5 rounded-md shadow-md flex items-center gap-0.5">
                  <Crown className="w-3 h-3 fill-current" /> Leader
                </div>
              )}
              {redRoom.isHostSpeaking && (
                <span className="absolute -bottom-1 -left-1 w-3.5 h-3.5 bg-emerald-500 border-2 border-black rounded-full animate-ping" />
              )}
            </div>

            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5">
                <h4 className="font-black text-base text-white truncate">
                  {redRoom.hostName}
                </h4>
                <span className="text-[9px] text-red-300 font-bold px-1.5 py-0.2 bg-red-500/25 border border-red-500/30 rounded uppercase">
                  HOST
                </span>
              </div>
              <p className="text-xs text-slate-300 truncate mt-0.5">{redRoom.name}</p>
              <div className="mt-1 flex items-center gap-2">
                <span className="text-[11px] text-red-300 font-mono font-bold">Room #{redRoom.id?.slice(0, 8)}</span>
              </div>
            </div>
          </div>

          {/* Real-time Numeric Score Box */}
          <div className="p-3.5 rounded-2xl bg-black/50 border border-red-500/25 flex items-center justify-between shadow-inner">
            <span className="text-xs text-slate-300 font-bold uppercase tracking-wider">Score</span>
            <div className="text-right">
              <div className={`text-xl sm:text-2xl font-black text-red-400 font-mono tracking-tight flex items-center justify-end gap-1.5 ${
                pulseSide === 'roomA' ? 'scale-105 text-amber-300' : ''
              } transition-all`}>
                <Flame className="w-5 h-5 fill-red-500 text-red-500" />
                <span>{scoreA.toLocaleString()}</span>
              </div>
              {leadingSide === 'roomA' && scoreDifference > 0 && (
                <p className="text-[10px] font-extrabold text-amber-400 mt-0.5">
                  +{scoreDifference.toLocaleString()} Ahead
                </p>
              )}
            </div>
          </div>

          {/* Top Supporters Preview */}
          {redRoom.topSupporters && redRoom.topSupporters.length > 0 && (
            <div className="space-y-1.5 pt-1">
              <div className="text-[10px] text-slate-300 font-bold uppercase tracking-wider flex items-center justify-between">
                <span>Top MVPs</span>
                <span className="text-red-400 font-mono">3 Contributors</span>
              </div>
              <div className="flex items-center gap-2">
                {redRoom.topSupporters.map((s, idx) => (
                  <div key={idx} className="flex items-center gap-1.5 px-2 py-1 rounded-xl bg-white/5 border border-white/10 text-[10px]">
                    <img src={s.avatar} alt={s.name} className="w-5 h-5 rounded-full object-cover" />
                    <span className="text-slate-200 font-bold truncate max-w-[65px]">{s.name}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Interactive Real-Time Gift Boost Buttons */}
          <div className="grid grid-cols-3 gap-1.5 pt-1">
            <button
              type="button"
              onClick={() => handleBoost('roomA', 100, `🌹 Sent Rose to ${redRoom.hostName}`)}
              className="py-1.5 px-2 rounded-xl bg-red-600/30 hover:bg-red-600/50 border border-red-500/40 text-red-200 text-xs font-black transition-transform active:scale-95 flex items-center justify-center gap-1 shadow cursor-pointer"
            >
              🌹 +100
            </button>
            <button
              type="button"
              onClick={() => handleBoost('roomA', 500, `🚀 Sent Rocket to ${redRoom.hostName}`)}
              className="py-1.5 px-2 rounded-xl bg-red-600/50 hover:bg-red-600/70 border border-red-500/50 text-white text-xs font-black transition-transform active:scale-95 flex items-center justify-center gap-1 shadow cursor-pointer"
            >
              🚀 +500
            </button>
            <button
              type="button"
              onClick={() => handleBoost('roomA', 2000, `👑 Sent Crown to ${redRoom.hostName}`)}
              className="py-1.5 px-2 rounded-xl bg-gradient-to-r from-red-600 to-amber-600 hover:scale-105 text-white text-xs font-black transition-all active:scale-95 flex items-center justify-center gap-1 shadow-lg cursor-pointer"
            >
              👑 +2K
            </button>
          </div>

          {/* Watch Room Action */}
          {onWatchRoom && (
            <button
              type="button"
              onClick={() => onWatchRoom(redRoom.id || '', redRoom.name)}
              className="w-full py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 hover:text-white text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Watch {redRoom.hostName}&apos;s Room</span>
            </button>
          )}
        </div>

        {/* CENTER EMBLEM (Col 1) */}
        <div className="lg:col-span-1 flex flex-col items-center justify-center py-2 lg:py-0">
          <div className="relative">
            <div className="w-14 h-14 rounded-full bg-gradient-to-br from-red-600 via-purple-700 to-blue-600 p-[2px] shadow-2xl animate-spin-slow">
              <div className="w-full h-full bg-[#0d041a] rounded-full flex items-center justify-center">
                <span className="font-black text-sm tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-red-400 to-blue-400">
                  VS
                </span>
              </div>
            </div>
            <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 rounded-full bg-red-500 blur-[2px]" />
            <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-2 h-2 rounded-full bg-blue-500 blur-[2px]" />
          </div>
        </div>

        {/* ROOM B: BLUE DEFENDER CORNER (Col 5) */}
        <div className="lg:col-span-5 p-4 sm:p-5 rounded-3xl bg-gradient-to-bl from-blue-950/40 via-blue-900/10 to-transparent border border-blue-500/30 relative overflow-hidden shadow-xl space-y-4">
          {/* Header Row */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-xs text-slate-300 bg-black/40 px-2.5 py-0.5 rounded-full border border-white/10">
              <Users className="w-3.5 h-3.5 text-blue-400" />
              <span className="font-mono font-bold">{blueRoom.viewersCount?.toLocaleString()}</span>
              <span className="text-[10px] text-slate-400">listeners</span>
            </div>
            <span className="px-2.5 py-1 rounded-xl bg-blue-600/30 border border-blue-500/40 text-blue-300 text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 shadow">
              <Shield className="w-3.5 h-3.5 fill-blue-500 text-blue-500" /> Blue Corner
            </span>
          </div>

          {/* Host & Room Info */}
          <div className="flex items-center justify-end gap-3.5 text-right">
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-end gap-1.5">
                <span className="text-[9px] text-blue-300 font-bold px-1.5 py-0.2 bg-blue-500/25 border border-blue-500/30 rounded uppercase">
                  HOST
                </span>
                <h4 className="font-black text-base text-white truncate">
                  {blueRoom.hostName}
                </h4>
              </div>
              <p className="text-xs text-slate-300 truncate mt-0.5">{blueRoom.name}</p>
              <div className="mt-1 flex items-center justify-end gap-2">
                <span className="text-[11px] text-blue-300 font-mono font-bold">Room #{blueRoom.id?.slice(0, 8)}</span>
              </div>
            </div>

            <div className="relative shrink-0">
              <img
                src={blueRoom.hostAvatar}
                alt={blueRoom.hostName}
                className="w-16 h-16 sm:w-18 sm:h-18 rounded-2xl object-cover ring-2 ring-blue-500 shadow-xl"
              />
              {leadingSide === 'roomB' && (
                <div className="absolute -top-3 -left-2 bg-amber-400 text-black text-[10px] font-black px-1.5 py-0.5 rounded-md shadow-md flex items-center gap-0.5">
                  <Crown className="w-3 h-3 fill-current" /> Leader
                </div>
              )}
            </div>
          </div>

          {/* Real-time Numeric Score Box */}
          <div className="p-3.5 rounded-2xl bg-black/50 border border-blue-500/25 flex items-center justify-between shadow-inner">
            <div className="text-left">
              <div className={`text-xl sm:text-2xl font-black text-blue-400 font-mono tracking-tight flex items-center gap-1.5 ${
                pulseSide === 'roomB' ? 'scale-105 text-amber-300' : ''
              } transition-all`}>
                <Shield className="w-5 h-5 fill-blue-500 text-blue-500" />
                <span>{scoreB.toLocaleString()}</span>
              </div>
              {leadingSide === 'roomB' && scoreDifference > 0 && (
                <p className="text-[10px] font-extrabold text-amber-400 mt-0.5">
                  +{scoreDifference.toLocaleString()} Ahead
                </p>
              )}
            </div>
            <span className="text-xs text-slate-300 font-bold uppercase tracking-wider">Score</span>
          </div>

          {/* Top Supporters Preview */}
          {blueRoom.topSupporters && blueRoom.topSupporters.length > 0 && (
            <div className="space-y-1.5 pt-1 text-right">
              <div className="text-[10px] text-slate-300 font-bold uppercase tracking-wider flex items-center justify-between">
                <span className="text-blue-400 font-mono">3 Contributors</span>
                <span>Top MVPs</span>
              </div>
              <div className="flex items-center justify-end gap-2">
                {blueRoom.topSupporters.map((s, idx) => (
                  <div key={idx} className="flex items-center gap-1.5 px-2 py-1 rounded-xl bg-white/5 border border-white/10 text-[10px]">
                    <span className="text-slate-200 font-bold truncate max-w-[65px]">{s.name}</span>
                    <img src={s.avatar} alt={s.name} className="w-5 h-5 rounded-full object-cover" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Interactive Real-Time Gift Boost Buttons */}
          <div className="grid grid-cols-3 gap-1.5 pt-1">
            <button
              type="button"
              onClick={() => handleBoost('roomB', 100, `💎 Sent Diamond to ${blueRoom.hostName}`)}
              className="py-1.5 px-2 rounded-xl bg-blue-600/30 hover:bg-blue-600/50 border border-blue-500/40 text-blue-200 text-xs font-black transition-transform active:scale-95 flex items-center justify-center gap-1 shadow cursor-pointer"
            >
              💎 +100
            </button>
            <button
              type="button"
              onClick={() => handleBoost('roomB', 500, `⚡ Sent Energy to ${blueRoom.hostName}`)}
              className="py-1.5 px-2 rounded-xl bg-blue-600/50 hover:bg-blue-600/70 border border-blue-500/50 text-white text-xs font-black transition-transform active:scale-95 flex items-center justify-center gap-1 shadow cursor-pointer"
            >
              ⚡ +500
            </button>
            <button
              type="button"
              onClick={() => handleBoost('roomB', 2000, `🏰 Sent Castle to ${blueRoom.hostName}`)}
              className="py-1.5 px-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:scale-105 text-white text-xs font-black transition-all active:scale-95 flex items-center justify-center gap-1 shadow-lg cursor-pointer"
            >
              🏰 +2K
            </button>
          </div>

          {/* Watch Room Action */}
          {onWatchRoom && (
            <button
              type="button"
              onClick={() => onWatchRoom(blueRoom.id || '', blueRoom.name)}
              className="w-full py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 hover:text-white text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Watch {blueRoom.hostName}&apos;s Room</span>
            </button>
          )}
        </div>
      </div>

      {/* ========================================================= */}
      {/* SPLIT-SCREEN REAL-TIME PROGRESS BAR & TUG-OF-WAR RATIO     */}
      {/* ========================================================= */}
      <div className="space-y-2.5 pt-3 border-t border-white/10 relative z-10">
        <div className="flex items-center justify-between text-xs font-mono font-black">
          {/* Left percentage & room */}
          <div className="flex items-center gap-2 text-red-400">
            <span className="truncate max-w-[140px] sm:max-w-[200px]">🔥 {redRoom.name}</span>
            <span className="bg-red-500/20 px-2 py-0.5 rounded border border-red-500/30 text-[11px]">
              {redPercentage}%
            </span>
          </div>

          {/* Center status message */}
          <div className="text-center text-[11px] text-slate-300 font-sans font-bold">
            {isFinished ? (
              <span className="text-amber-400 flex items-center gap-1">
                <Trophy className="w-3.5 h-3.5 fill-current" />
                Winner: {scoreA > scoreB ? redRoom.hostName : scoreB > scoreA ? blueRoom.hostName : 'Tied Battle!'}
              </span>
            ) : (
              <span className="text-slate-400 flex items-center gap-1">
                <TrendingUp className="w-3 h-3 text-amber-400" />
                Tug-of-War Split-Screen Real-Time Score Ratio
              </span>
            )}
          </div>

          {/* Right percentage & room */}
          <div className="flex items-center gap-2 text-blue-400">
            <span className="bg-blue-500/20 px-2 py-0.5 rounded border border-blue-500/30 text-[11px]">
              {bluePercentage}%
            </span>
            <span className="truncate max-w-[140px] sm:max-w-[200px]">{blueRoom.name} 🛡️</span>
          </div>
        </div>

        {/* Dual-Side Split-Screen Progress Bar */}
        <div className="relative h-5 w-full bg-blue-600 rounded-full overflow-hidden shadow-2xl flex p-[2px] border border-white/20">
          {/* Red Progress Side */}
          <div
            style={{ width: `${redPercentage}%` }}
            className="h-full bg-gradient-to-r from-red-600 via-rose-500 to-pink-500 rounded-l-full transition-all duration-500 shadow-[0_0_15px_rgba(239,68,68,0.5)]"
          />

          {/* Clash Sword Tug Divider */}
          <div
            style={{ left: `${redPercentage}%` }}
            className="absolute top-1/2 -translate-x-1/2 -translate-y-1/2 z-20 w-7 h-7 rounded-full bg-white text-black text-xs font-black flex items-center justify-center shadow-2xl border-2 border-amber-300 transition-all duration-500"
          >
            ⚔️
          </div>
        </div>
      </div>

    </div>
  );
};

export default PKBattle;
