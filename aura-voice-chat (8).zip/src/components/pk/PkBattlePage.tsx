/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Swords, Trophy, Shield, Flame, ChevronLeft, Award, Play } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { PKBattleBoard } from './PKBattleBoard';

export const PkBattlePage: React.FC = () => {
  const { setActiveModal, showNotification, activeRoom, setActiveRoom, rooms } = useApp();
  const [activeTab, setActiveTab] = useState<'live' | 'history' | 'leaderboard'>('live');

  const livePks = [
    { id: 'pk-01', roomA: 'Midnight Chill 🌙', hostA: 'Elena Vance', scoreA: 45000, roomB: 'Cyber Gaming 🕹️', hostB: 'Alex Chen', scoreB: 38000, timeLeft: '1m 20s' },
    { id: 'pk-02', roomA: 'Acoustic Lounge 🎸', hostA: 'Sophia Taylor', scoreA: 12000, roomB: 'Tokyo Anime Talk 🌸', hostB: 'Kenji Sato', scoreB: 19500, timeLeft: '3m 45s' }
  ];

  const handleStartMatchmaking = () => {
    if (!activeRoom) {
      showNotification('⚠️ You must be inside your own voice room to start a live PK battle!');
      return;
    }
    showNotification('🔍 Matchmaking initiated! Found opponent: Cyber Gaming 🕹️. PK Battle starting in 3 seconds!');
    setActiveModal('none');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xl overflow-y-auto p-4 animate-fadeIn text-white space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-white/10 pb-3">
        <div className="flex items-center gap-3">
          <button onClick={() => setActiveModal('none')} className="p-2 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/10">
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-lg font-black flex items-center gap-2">
              <Swords className="w-5 h-5 text-red-500 animate-pulse" /> Live PK Battles Center
            </h2>
            <p className="text-xs text-slate-300">Head-to-head room gifting competitions</p>
          </div>
        </div>
      </div>

      {/* Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-red-500/20 via-purple-900/30 to-blue-500/20 backdrop-blur-xl border border-red-500/40 text-center space-y-3 shadow-xl">
        <span className="text-4xl inline-block animate-bounce">⚔️</span>
        <h3 className="text-xl font-black text-white">ROOM vs ROOM WARFARE</h3>
        <p className="text-xs text-slate-200">Challenge another room host. Whoever receives the most gift value in 5 minutes takes the glory and bonus experience points!</p>
        <button
          onClick={handleStartMatchmaking}
          className="px-8 py-3 bg-gradient-to-r from-red-600 to-pink-600 hover:scale-105 text-white font-black text-xs rounded-2xl shadow-lg transition-transform"
        >
          {activeRoom ? 'Start PK Matchmaker Now 🔥' : 'Enter Room to Start PK'}
        </button>
      </div>

      {/* Tabs */}
      <div className="grid grid-cols-3 gap-2 p-1.5 bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 shadow-lg">
        {[
          { id: 'live', label: 'Live Battles 🔥' },
          { id: 'history', label: 'History & Stats' },
          { id: 'leaderboard', label: 'Top PK Hosts 🏆' }
        ].map(t => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id as any)}
            className={`py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === t.id ? 'bg-gradient-to-r from-red-600 to-pink-600 text-white font-black shadow' : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Tab Contents */}
      {activeTab === 'live' && (
        <div className="space-y-6 animate-fadeIn">
          {/* Featured Headline Live Battle Board */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h4 className="font-black text-white text-sm flex items-center gap-1.5">
                <Swords className="w-4 h-4 text-red-500 animate-pulse" /> Main Arena Clash
              </h4>
              <span className="text-[11px] text-amber-400 font-bold">● Active Room PK</span>
            </div>
            <PKBattleBoard
              variant="board"
              roomA={{
                name: 'Midnight Chill 🌙',
                hostName: 'Elena Vance',
                hostAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
                score: 45000,
                viewersCount: 1420
              }}
              roomB={{
                name: 'Cyber Gaming 🕹️',
                hostName: 'Alex Chen',
                hostAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
                score: 38000,
                viewersCount: 1180
              }}
              scoreA={45000}
              scoreB={38000}
              timeLeft="2m 30s"
              onWatchRoom={(roomId, roomName) => {
                if (rooms && rooms.length > 0) {
                  setActiveRoom(rooms[0]);
                }
                showNotification(`Entering ${roomName} to watch live!`);
                setActiveModal('none');
              }}
              onSendGift={(side, amount) => {
                showNotification(`🎉 Cheered ${side === 'roomA' ? 'Elena Vance' : 'Alex Chen'} with +${amount} score boost!`);
              }}
            />
          </div>

          {/* Other Live Battle Matches in Card Variant */}
          <div className="space-y-3 pt-2">
            <h4 className="font-bold text-white text-xs flex items-center justify-between">
              <span>Concurrent Live Battles</span>
              <span className="text-slate-400 font-normal">2 Battles Online</span>
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {livePks.map(pk => (
                <PKBattleBoard
                  key={pk.id}
                  variant="card"
                  roomA={{
                    name: pk.roomA,
                    hostName: pk.hostA,
                    hostAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
                    score: pk.scoreA
                  }}
                  roomB={{
                    name: pk.roomB,
                    hostName: pk.hostB,
                    hostAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
                    score: pk.scoreB
                  }}
                  scoreA={pk.scoreA}
                  scoreB={pk.scoreB}
                  timeLeft={pk.timeLeft}
                  onWatchRoom={(roomId, roomName) => {
                    if (rooms && rooms.length > 0) {
                      setActiveRoom(rooms[0]);
                    }
                    showNotification(`Entering ${pk.roomA} to watch the live battle!`);
                    setActiveModal('none');
                  }}
                />
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'leaderboard' && (
        <div className="space-y-3 animate-fadeIn">
          <h4 className="font-bold text-white text-xs">All-Time PK Champions</h4>
          {[
            { name: 'Elena Vance', wins: 142, winRate: '88%', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80' },
            { name: 'Alex Chen', wins: 110, winRate: '82%', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80' },
            { name: 'Marcus Aurelius', wins: 95, winRate: '79%', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80' }
          ].map((sp, i) => (
            <div key={i} className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 flex items-center justify-between shadow-xl">
              <div className="flex items-center gap-3">
                <span className={`w-7 h-7 rounded-xl flex items-center justify-center font-black text-xs ${i === 0 ? 'bg-amber-400 text-black shadow' : 'bg-white/10 text-white border border-white/10'}`}>#{i + 1}</span>
                <img src={sp.avatar} alt={sp.name} className="w-10 h-10 rounded-full object-cover border border-white/20" />
                <div>
                  <h5 className="font-bold text-white text-xs">{sp.name}</h5>
                  <p className="text-[10px] text-slate-400">{sp.wins} Wins • {sp.winRate} Win Rate</p>
                </div>
              </div>
              <span className="font-black text-amber-400 text-xs">🏆 Grandmaster</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
