/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { Swords, Flame, Shield, Trophy, Clock, Zap, Gift as GiftIcon, Users, Volume2, VolumeX, Eye, ArrowRight, Sparkles, CheckCircle2 } from 'lucide-react';
import { VoiceRoom, PkBattle } from '../../types';

export interface CompetingRoomData {
  id?: string;
  name: string;
  hostName: string;
  hostAvatar: string;
  score: number;
  viewersCount?: number;
  topGifters?: Array<{
    name: string;
    avatar: string;
    contribution: number;
  }>;
  isHostSpeaking?: boolean;
}

export interface PKBattleBoardProps {
  /** Optional PK Battle object from backend */
  battle?: PkBattle;
  /** Room A (Red / Challenger) data */
  roomA?: Partial<VoiceRoom> | CompetingRoomData;
  /** Room B (Blue / Defender) data */
  roomB?: Partial<VoiceRoom> | CompetingRoomData;
  /** Score for Room A */
  scoreA?: number;
  /** Score for Room B */
  scoreB?: number;
  /** Countdown time remaining in seconds, or formatted string like "2m 30s" */
  timeLeft?: number | string;
  /** Initial battle duration in seconds (defaults to 180 = 3 minutes) */
  durationSeconds?: number;
  /** Battle state */
  status?: 'matching' | 'active' | 'finished';
  /** Display variant: 'board' (full interactive arena), 'compact' (live stage banner), or 'card' (lobby list card) */
  variant?: 'board' | 'compact' | 'card' | 'modal';
  /** Callback when the countdown timer expires */
  onBattleEnd?: (winner: 'roomA' | 'roomB' | 'draw') => void;
  /** Callback when user clicks to enter or watch a specific room */
  onWatchRoom?: (roomId: string, roomName: string) => void;
  /** Callback when user cheers or sends a gift */
  onSendGift?: (targetSide: 'roomA' | 'roomB', amount?: number) => void;
  /** Custom class name */
  className?: string;
}

export const PKBattleBoard: React.FC<PKBattleBoardProps> = ({
  battle,
  roomA: propRoomA,
  roomB: propRoomB,
  scoreA: propScoreA,
  scoreB: propScoreB,
  timeLeft: propTimeLeft,
  durationSeconds = 180,
  status: propStatus = 'active',
  variant = 'board',
  onBattleEnd,
  onWatchRoom,
  onSendGift,
  className = '',
}) => {
  // Parse initial countdown seconds
  const initialSeconds = useMemo(() => {
    if (typeof propTimeLeft === 'number') return Math.max(0, propTimeLeft);
    if (typeof propTimeLeft === 'string') {
      const minMatch = propTimeLeft.match(/(\d+)\s*m/i);
      const secMatch = propTimeLeft.match(/(\d+)\s*s/i);
      const m = minMatch ? parseInt(minMatch[1], 10) : 0;
      const s = secMatch ? parseInt(secMatch[1], 10) : 0;
      if (m > 0 || s > 0) return m * 60 + s;
      const plainNum = parseInt(propTimeLeft, 10);
      if (!isNaN(plainNum)) return plainNum;
    }
    if (battle?.remainingSeconds !== undefined) return battle.remainingSeconds;
    return durationSeconds;
  }, [propTimeLeft, battle, durationSeconds]);

  const [countdown, setCountdown] = useState<number>(initialSeconds);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [liveScoreA, setLiveScoreA] = useState<number>(() => {
    if (propScoreA !== undefined) return propScoreA;
    if (battle?.roomAScore !== undefined) return battle.roomAScore;
    if (propRoomA && 'score' in propRoomA && typeof propRoomA.score === 'number') return propRoomA.score;
    return 38450;
  });
  const [liveScoreB, setLiveScoreB] = useState<number>(() => {
    if (propScoreB !== undefined) return propScoreB;
    if (battle?.roomBScore !== undefined) return battle.roomBScore;
    if (propRoomB && 'score' in propRoomB && typeof propRoomB.score === 'number') return propRoomB.score;
    return 34200;
  });
  const [recentGiftEffect, setRecentGiftEffect] = useState<{ side: 'roomA' | 'roomB'; amount: number; label: string } | null>(null);

  // Sync props if parent updates scores
  useEffect(() => {
    if (propScoreA !== undefined) setLiveScoreA(propScoreA);
  }, [propScoreA]);

  useEffect(() => {
    if (propScoreB !== undefined) setLiveScoreB(propScoreB);
  }, [propScoreB]);

  // Synchronize incoming timeLeft changes
  useEffect(() => {
    if (typeof propTimeLeft === 'number') {
      setCountdown(propTimeLeft);
    }
  }, [propTimeLeft]);

  // Active Countdown Timer Loop
  useEffect(() => {
    if (countdown <= 0) {
      if (onBattleEnd) {
        const winner = liveScoreA > liveScoreB ? 'roomA' : liveScoreB > liveScoreA ? 'roomB' : 'draw';
        onBattleEnd(winner);
      }
      return;
    }

    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          if (onBattleEnd) {
            const winner = liveScoreA > liveScoreB ? 'roomA' : liveScoreB > liveScoreA ? 'roomB' : 'draw';
            onBattleEnd(winner);
          }
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [countdown, liveScoreA, liveScoreB, onBattleEnd]);

  // Normalized Room Data
  const redTeam: CompetingRoomData = useMemo(() => {
    if (propRoomA) {
      return {
        id: (propRoomA as any).id || battle?.roomAId || 'room-red-01',
        name: (propRoomA as any).title || (propRoomA as any).name || battle?.roomAName || 'Midnight Chill Lounge 🌙',
        hostName: (propRoomA as any).hostName || battle?.roomAHost || 'Elena Vance',
        hostAvatar: (propRoomA as any).hostAvatar || battle?.roomAAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
        score: liveScoreA,
        viewersCount: (propRoomA as any).onlineCount || (propRoomA as any).viewersCount || 1420,
        topGifters: (propRoomA as any).topGifters || [
          { name: 'Kaiser_99', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=120&q=80', contribution: 12500 },
          { name: 'Aria_Star', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=120&q=80', contribution: 8400 },
          { name: 'Leo_VIP', avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=120&q=80', contribution: 5200 },
        ],
        isHostSpeaking: true,
      };
    }
    if (battle) {
      return {
        id: battle.roomAId,
        name: battle.roomAName,
        hostName: battle.roomAHost,
        hostAvatar: battle.roomAAvatar,
        score: liveScoreA,
        viewersCount: 980,
      };
    }
    return {
      id: 'room-alpha',
      name: 'Cyber Neon Beats 🎧',
      hostName: 'Elena Vance',
      hostAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
      score: liveScoreA,
      viewersCount: 1540,
      topGifters: [
        { name: 'Kaiser_99', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=120&q=80', contribution: 12500 },
        { name: 'Aria_Star', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=120&q=80', contribution: 8400 },
        { name: 'Leo_VIP', avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=120&q=80', contribution: 5200 },
      ],
      isHostSpeaking: true,
    };
  }, [propRoomA, battle, liveScoreA]);

  const blueTeam: CompetingRoomData = useMemo(() => {
    if (propRoomB) {
      return {
        id: (propRoomB as any).id || battle?.roomBId || 'room-blue-02',
        name: (propRoomB as any).title || (propRoomB as any).name || battle?.roomBName || 'Tokyo Anime & Gaming 🕹️',
        hostName: (propRoomB as any).hostName || battle?.roomBHost || 'Alex Chen',
        hostAvatar: (propRoomB as any).hostAvatar || battle?.roomBAvatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
        score: liveScoreB,
        viewersCount: (propRoomB as any).onlineCount || (propRoomB as any).viewersCount || 1280,
        topGifters: (propRoomB as any).topGifters || [
          { name: 'DragonKing', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=120&q=80', contribution: 11000 },
          { name: 'Mia_Cyber', avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=120&q=80', contribution: 7800 },
          { name: 'ShadowZero', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=120&q=80', contribution: 4900 },
        ],
        isHostSpeaking: false,
      };
    }
    if (battle) {
      return {
        id: battle.roomBId,
        name: battle.roomBName,
        hostName: battle.roomBHost,
        hostAvatar: battle.roomBAvatar,
        score: liveScoreB,
        viewersCount: 860,
      };
    }
    return {
      id: 'room-beta',
      name: 'Tokyo Anime & Gaming 🕹️',
      hostName: 'Alex Chen',
      hostAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
      score: liveScoreB,
      viewersCount: 1280,
      topGifters: [
        { name: 'DragonKing', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=120&q=80', contribution: 11000 },
        { name: 'Mia_Cyber', avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=120&q=80', contribution: 7800 },
        { name: 'ShadowZero', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=120&q=80', contribution: 4900 },
      ],
      isHostSpeaking: false,
    };
  }, [propRoomB, battle, liveScoreB]);

  // Score Calculations
  const totalScore = liveScoreA + liveScoreB;
  const redPercentage = totalScore > 0 ? Math.round((liveScoreA / totalScore) * 100) : 50;
  const bluePercentage = 100 - redPercentage;
  const scoreLead = Math.abs(liveScoreA - liveScoreB);
  const leadingTeam = liveScoreA > liveScoreB ? 'roomA' : liveScoreB > liveScoreA ? 'roomB' : 'tied';

  // Format Countdown Display (MM:SS)
  const formattedMinutes = Math.floor(countdown / 60).toString().padStart(2, '0');
  const formattedSeconds = (countdown % 60).toString().padStart(2, '0');
  const isUrgent = countdown <= 30 && countdown > 0;
  const isBattleEnded = countdown === 0;

  // Handle boosting score with instant feedback
  const handleCheer = (side: 'roomA' | 'roomB', amount: number, label: string) => {
    if (side === 'roomA') {
      setLiveScoreA((prev) => prev + amount);
    } else {
      setLiveScoreB((prev) => prev + amount);
    }
    setRecentGiftEffect({ side, amount, label });
    setTimeout(() => setRecentGiftEffect(null), 2400);

    if (onSendGift) {
      onSendGift(side, amount);
    }
  };

  // =========================================================================
  // 1. COMPACT VARIANT: Stage Header / In-Room PK Floating Strip
  // =========================================================================
  if (variant === 'compact') {
    return (
      <div className={`relative overflow-hidden rounded-2xl bg-gradient-to-r from-red-950/80 via-black/80 to-blue-950/80 backdrop-blur-xl border border-white/10 p-2.5 shadow-2xl space-y-1.5 ${className}`}>
        {/* Top bar: Hosts, Scores, Timer */}
        <div className="flex items-center justify-between text-xs">
          {/* Room A side */}
          <div className="flex items-center gap-1.5 min-w-0 max-w-[38%]">
            <div className="relative flex-shrink-0">
              <img
                src={redTeam.hostAvatar}
                alt={redTeam.hostName}
                className="w-7 h-7 rounded-full object-cover ring-2 ring-red-500"
              />
              {leadingTeam === 'roomA' && (
                <div className="absolute -top-1.5 -left-1 text-[10px] animate-bounce">👑</div>
              )}
            </div>
            <div className="min-w-0">
              <div className="font-black text-red-400 truncate text-[11px] flex items-center gap-1">
                <Flame className="w-3 h-3 flex-shrink-0 text-red-500 fill-red-500" />
                <span className="truncate">{redTeam.hostName}</span>
              </div>
              <div className="text-[10px] font-extrabold text-white font-mono">
                {liveScoreA.toLocaleString()}
              </div>
            </div>
          </div>

          {/* Countdown Center */}
          <div className="flex flex-col items-center justify-center flex-shrink-0 px-2">
            <div className={`px-2 py-0.5 rounded-full text-[10px] font-black tracking-wider flex items-center gap-1 ${
              isUrgent ? 'bg-red-600 text-white animate-pulse' : 'bg-white/10 text-amber-300'
            }`}>
              <Clock className="w-3 h-3" />
              <span>{isBattleEnded ? 'FINAL' : `${formattedMinutes}:${formattedSeconds}`}</span>
            </div>
            <span className="text-[8px] tracking-widest text-slate-400 font-bold uppercase mt-0.5">
              {isBattleEnded ? 'ENDED' : 'PK LIVE'}
            </span>
          </div>

          {/* Room B side */}
          <div className="flex items-center justify-end gap-1.5 min-w-0 max-w-[38%] text-right">
            <div className="min-w-0">
              <div className="font-black text-blue-400 truncate text-[11px] flex items-center justify-end gap-1">
                <span className="truncate">{blueTeam.hostName}</span>
                <Shield className="w-3 h-3 flex-shrink-0 text-blue-500 fill-blue-500" />
              </div>
              <div className="text-[10px] font-extrabold text-white font-mono">
                {liveScoreB.toLocaleString()}
              </div>
            </div>
            <div className="relative flex-shrink-0">
              <img
                src={blueTeam.hostAvatar}
                alt={blueTeam.hostName}
                className="w-7 h-7 rounded-full object-cover ring-2 ring-blue-500"
              />
              {leadingTeam === 'roomB' && (
                <div className="absolute -top-1.5 -right-1 text-[10px] animate-bounce">👑</div>
              )}
            </div>
          </div>
        </div>

        {/* Tug-of-war bar */}
        <div className="relative h-2 w-full bg-blue-600 rounded-full overflow-hidden shadow-inner flex">
          <div
            style={{ width: `${redPercentage}%` }}
            className="h-full bg-gradient-to-r from-red-600 via-rose-500 to-pink-500 transition-all duration-500"
          />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 rounded-full bg-white text-black text-[8px] font-black flex items-center justify-center shadow-lg border border-white">
            ⚔️
          </div>
        </div>
      </div>
    );
  }

  // =========================================================================
  // 2. CARD VARIANT: Used in lists, lobbies or grids
  // =========================================================================
  if (variant === 'card') {
    return (
      <div className={`p-4 rounded-3xl bg-[#130d22]/90 backdrop-blur-xl border border-white/10 hover:border-red-500/40 shadow-xl transition-all duration-300 space-y-3.5 ${className}`}>
        {/* Header: Status & Countdown */}
        <div className="flex items-center justify-between text-xs">
          <span className="flex items-center gap-1.5 font-black text-[11px] tracking-wide text-red-400 uppercase">
            <Swords className="w-4 h-4 text-red-500 animate-pulse" />
            Live PK Arena
          </span>
          <div className={`px-2.5 py-0.5 rounded-full text-xs font-black flex items-center gap-1.5 shadow ${
            isUrgent ? 'bg-red-600 text-white animate-pulse' : 'bg-white/10 text-amber-300'
          }`}>
            <Clock className="w-3.5 h-3.5" />
            <span className="font-mono">{formattedMinutes}:{formattedSeconds}</span>
          </div>
        </div>

        {/* Competing Face-off */}
        <div className="grid grid-cols-2 gap-3 items-center relative">
          {/* Room A Cardlet */}
          <div className="p-2.5 rounded-2xl bg-red-950/30 border border-red-500/20 text-center space-y-1.5 relative overflow-hidden">
            <div className="relative w-12 h-12 mx-auto">
              <img
                src={redTeam.hostAvatar}
                alt={redTeam.hostName}
                className="w-12 h-12 rounded-full object-cover ring-2 ring-red-500"
              />
              {leadingTeam === 'roomA' && (
                <span className="absolute -top-2 -right-1 text-xs">👑</span>
              )}
            </div>
            <div className="truncate font-black text-white text-xs">{redTeam.hostName}</div>
            <div className="truncate text-[10px] text-slate-400">{redTeam.name}</div>
            <div className="font-black text-sm text-red-400 font-mono">
              🔥 {liveScoreA.toLocaleString()}
            </div>
          </div>

          {/* VS Clash Emblem */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10 w-7 h-7 rounded-full bg-gradient-to-tr from-red-600 to-blue-600 text-white font-black text-[10px] flex items-center justify-center shadow-lg border border-white/30">
            VS
          </div>

          {/* Room B Cardlet */}
          <div className="p-2.5 rounded-2xl bg-blue-950/30 border border-blue-500/20 text-center space-y-1.5 relative overflow-hidden">
            <div className="relative w-12 h-12 mx-auto">
              <img
                src={blueTeam.hostAvatar}
                alt={blueTeam.hostName}
                className="w-12 h-12 rounded-full object-cover ring-2 ring-blue-500"
              />
              {leadingTeam === 'roomB' && (
                <span className="absolute -top-2 -right-1 text-xs">👑</span>
              )}
            </div>
            <div className="truncate font-black text-white text-xs">{blueTeam.hostName}</div>
            <div className="truncate text-[10px] text-slate-400">{blueTeam.name}</div>
            <div className="font-black text-sm text-blue-400 font-mono">
              🛡️ {liveScoreB.toLocaleString()}
            </div>
          </div>
        </div>

        {/* Progress tug-of-war */}
        <div className="space-y-1">
          <div className="h-2 w-full bg-blue-600 rounded-full overflow-hidden flex shadow-inner">
            <div
              style={{ width: `${redPercentage}%` }}
              className="h-full bg-gradient-to-r from-red-500 to-pink-500 transition-all duration-500"
            />
          </div>
          <div className="flex justify-between text-[10px] font-mono text-slate-400">
            <span>{redPercentage}%</span>
            <span>{bluePercentage}%</span>
          </div>
        </div>

        {/* Action Button */}
        <button
          onClick={() => onWatchRoom ? onWatchRoom(redTeam.id || '', redTeam.name) : undefined}
          className="w-full py-2 rounded-xl bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-500 hover:to-pink-500 text-white font-black text-xs shadow-md transition-all flex items-center justify-center gap-1.5"
        >
          <Eye className="w-3.5 h-3.5" /> Watch PK Battle
        </button>
      </div>
    );
  }

  // =========================================================================
  // 3. FULL BOARD VARIANT (Default): Feature-Rich PK War Room
  // =========================================================================
  return (
    <div className={`relative overflow-hidden rounded-3xl bg-gradient-to-b from-[#180a29] via-[#0d0718] to-[#0a0512] border border-white/15 p-5 md:p-6 shadow-2xl text-white space-y-6 ${className}`}>
      {/* Background Ambience Glow */}
      <div className="absolute -top-24 -left-24 w-72 h-72 bg-red-600/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -right-24 w-72 h-72 bg-blue-600/15 rounded-full blur-3xl pointer-events-none" />

      {/* Floating Gift Effect Alert */}
      {recentGiftEffect && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-30 animate-bounce pointer-events-none">
          <div className={`px-4 py-1.5 rounded-full text-xs font-black shadow-2xl border flex items-center gap-2 ${
            recentGiftEffect.side === 'roomA'
              ? 'bg-red-600/90 text-white border-red-400'
              : 'bg-blue-600/90 text-white border-blue-400'
          }`}>
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>{recentGiftEffect.label}</span>
            <span className="bg-white/20 px-2 py-0.5 rounded-full font-mono">+{recentGiftEffect.amount}</span>
          </div>
        </div>
      )}

      {/* HEADER: Battle Title, Countdown Timer & Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-4 relative z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-red-600 to-amber-600 flex items-center justify-center shadow-lg border border-white/20">
            <Swords className="w-5 h-5 text-white animate-pulse" />
          </div>
          <div>
            <h3 className="text-base md:text-lg font-black tracking-tight text-white flex items-center gap-2">
              Voice Room PK War
              <span className="text-[10px] px-2 py-0.5 rounded-md bg-red-600/30 text-red-300 font-extrabold border border-red-500/30 uppercase tracking-wider">
                {isBattleEnded ? 'Finished' : 'Live Match'}
              </span>
            </h3>
            <p className="text-xs text-slate-300">Gifts sent during the battle directly convert to room victory points!</p>
          </div>
        </div>

        {/* Countdown Box & Sound */}
        <div className="flex items-center gap-2.5">
          <div className={`px-4 py-2 rounded-2xl backdrop-blur-md border flex items-center gap-2.5 shadow-lg transition-all ${
            isUrgent
              ? 'bg-red-600/30 border-red-500 text-white animate-pulse shadow-red-500/20'
              : isBattleEnded
              ? 'bg-emerald-600/20 border-emerald-500 text-emerald-300'
              : 'bg-white/10 border-white/15 text-amber-300'
          }`}>
            <Clock className={`w-4 h-4 ${isUrgent ? 'text-red-400 animate-spin' : 'text-amber-400'}`} />
            <div className="text-left">
              <div className="text-[9px] uppercase tracking-wider font-extrabold text-slate-300">
                {isBattleEnded ? 'Battle Finished' : isUrgent ? 'Final Countdown' : 'Time Remaining'}
              </div>
              <div className="font-mono text-base md:text-lg font-black tracking-wider text-white">
                {isBattleEnded ? '00:00' : `${formattedMinutes}:${formattedSeconds}`}
              </div>
            </div>
          </div>

          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            aria-label="Toggle Battle Audio"
            className="p-2.5 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/10 text-slate-300 hover:text-white transition-colors"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4 text-slate-400" />}
          </button>
        </div>
      </div>

      {/* ARENA: Two Competing Rooms Clash Layout */}
      <div className="grid grid-cols-1 md:grid-cols-11 gap-4 items-center relative z-10">
        {/* ROOM A (RED TEAM) */}
        <div className="md:col-span-5 p-4 rounded-3xl bg-gradient-to-br from-red-950/40 via-red-900/10 to-transparent border border-red-500/30 relative overflow-hidden shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <span className="px-2.5 py-1 rounded-xl bg-red-600/30 border border-red-500/40 text-red-300 text-[10px] font-black uppercase tracking-wider flex items-center gap-1">
              <Flame className="w-3.5 h-3.5 fill-red-500 text-red-500" /> Red Corner
            </span>
            <div className="flex items-center gap-1.5 text-xs text-slate-300">
              <Users className="w-3.5 h-3.5 text-red-400" />
              <span className="font-mono font-bold">{redTeam.viewersCount?.toLocaleString()}</span>
            </div>
          </div>

          <div className="flex items-center gap-3.5">
            <div className="relative flex-shrink-0">
              <img
                src={redTeam.hostAvatar}
                alt={redTeam.hostName}
                className="w-16 h-16 md:w-18 md:h-18 rounded-2xl object-cover ring-2 ring-red-500 shadow-xl"
              />
              {leadingTeam === 'roomA' && (
                <div className="absolute -top-3 -right-2 bg-amber-400 text-black text-[10px] font-black px-1.5 py-0.5 rounded-md shadow-md flex items-center gap-0.5">
                  <Trophy className="w-3 h-3 fill-current" /> Leader
                </div>
              )}
              {redTeam.isHostSpeaking && (
                <span className="absolute -bottom-1 -left-1 w-3.5 h-3.5 bg-emerald-500 border-2 border-black rounded-full animate-ping" />
              )}
            </div>

            <div className="min-w-0 flex-1">
              <h4 className="font-black text-base text-white truncate flex items-center gap-1.5">
                {redTeam.hostName}
                <span className="text-[10px] text-red-400 font-bold px-1.5 py-0.2 bg-red-500/20 rounded">HOST</span>
              </h4>
              <p className="text-xs text-slate-300 truncate mt-0.5">{redTeam.name}</p>
              <div className="mt-1 flex items-center gap-2">
                <span className="text-xs text-red-300 font-mono font-bold">Room #{redTeam.id?.slice(0, 8)}</span>
              </div>
            </div>
          </div>

          {/* Score Box */}
          <div className="p-3 rounded-2xl bg-black/40 border border-red-500/20 flex items-center justify-between">
            <span className="text-xs text-slate-300 font-bold uppercase tracking-wider">Score</span>
            <div className="text-right">
              <div className="text-xl md:text-2xl font-black text-red-400 font-mono tracking-tight flex items-center gap-1.5">
                <Flame className="w-5 h-5 fill-red-500 text-red-500" />
                {liveScoreA.toLocaleString()}
              </div>
              {leadingTeam === 'roomA' && scoreLead > 0 && (
                <div className="text-[10px] font-extrabold text-amber-400">
                  +{scoreLead.toLocaleString()} Ahead
                </div>
              )}
            </div>
          </div>

          {/* Top Supporters */}
          {redTeam.topGifters && redTeam.topGifters.length > 0 && (
            <div className="space-y-1.5 pt-1">
              <div className="text-[10px] text-slate-300 font-bold uppercase tracking-wider flex items-center justify-between">
                <span>Top MVPs</span>
                <span className="text-red-400 font-mono">3 Contributors</span>
              </div>
              <div className="flex items-center gap-2">
                {redTeam.topGifters.map((g, idx) => (
                  <div key={idx} className="flex items-center gap-1.5 px-2 py-1 rounded-xl bg-white/5 border border-white/10 text-[10px]">
                    <img src={g.avatar} alt={g.name} className="w-5 h-5 rounded-full object-cover" />
                    <span className="text-slate-200 font-bold truncate max-w-[60px]">{g.name}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Interactive Boost Buttons */}
          <div className="grid grid-cols-3 gap-1.5 pt-1">
            <button
              onClick={() => handleCheer('roomA', 100, `🌹 Sent Rose to ${redTeam.hostName}`)}
              className="py-1.5 px-2 rounded-xl bg-red-600/30 hover:bg-red-600/50 border border-red-500/40 text-red-200 text-[11px] font-black transition-transform active:scale-95 flex items-center justify-center gap-1 shadow"
            >
              🌹 +100
            </button>
            <button
              onClick={() => handleCheer('roomA', 500, `🚀 Sent Rocket to ${redTeam.hostName}`)}
              className="py-1.5 px-2 rounded-xl bg-red-600/50 hover:bg-red-600/70 border border-red-500/50 text-white text-[11px] font-black transition-transform active:scale-95 flex items-center justify-center gap-1 shadow"
            >
              🚀 +500
            </button>
            <button
              onClick={() => handleCheer('roomA', 2000, `👑 Sent Crown to ${redTeam.hostName}`)}
              className="py-1.5 px-2 rounded-xl bg-gradient-to-r from-red-600 to-amber-600 hover:scale-105 text-white text-[11px] font-black transition-all active:scale-95 flex items-center justify-center gap-1 shadow-lg"
            >
              👑 +2K
            </button>
          </div>

          {/* Watch Room A Button */}
          {onWatchRoom && (
            <button
              onClick={() => onWatchRoom(redTeam.id || '', redTeam.name)}
              className="w-full py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 hover:text-white text-xs font-bold transition-colors flex items-center justify-center gap-1.5"
            >
              <Eye className="w-3.5 h-3.5" /> Watch {redTeam.hostName}&apos;s Room
            </button>
          )}
        </div>

        {/* CENTER VS BADGE & TUG-OF-WAR INDICATOR */}
        <div className="md:col-span-1 flex flex-col items-center justify-center py-2 md:py-0">
          <div className="relative">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-red-600 via-purple-700 to-blue-600 p-[2px] shadow-2xl animate-spin-slow">
              <div className="w-full h-full bg-[#0e071a] rounded-full flex items-center justify-center">
                <span className="font-black text-xs tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-red-400 to-blue-400">
                  VS
                </span>
              </div>
            </div>
            <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 rounded-full bg-red-500 blur-[2px]" />
            <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-2 h-2 rounded-full bg-blue-500 blur-[2px]" />
          </div>
        </div>

        {/* ROOM B (BLUE TEAM) */}
        <div className="md:col-span-5 p-4 rounded-3xl bg-gradient-to-bl from-blue-950/40 via-blue-900/10 to-transparent border border-blue-500/30 relative overflow-hidden shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-xs text-slate-300">
              <Users className="w-3.5 h-3.5 text-blue-400" />
              <span className="font-mono font-bold">{blueTeam.viewersCount?.toLocaleString()}</span>
            </div>
            <span className="px-2.5 py-1 rounded-xl bg-blue-600/30 border border-blue-500/40 text-blue-300 text-[10px] font-black uppercase tracking-wider flex items-center gap-1">
              <Shield className="w-3.5 h-3.5 fill-blue-500 text-blue-500" /> Blue Corner
            </span>
          </div>

          <div className="flex items-center justify-end gap-3.5 text-right">
            <div className="min-w-0 flex-1">
              <h4 className="font-black text-base text-white truncate flex items-center justify-end gap-1.5">
                <span className="text-[10px] text-blue-400 font-bold px-1.5 py-0.2 bg-blue-500/20 rounded">HOST</span>
                {blueTeam.hostName}
              </h4>
              <p className="text-xs text-slate-300 truncate mt-0.5">{blueTeam.name}</p>
              <div className="mt-1 flex items-center justify-end gap-2">
                <span className="text-xs text-blue-300 font-mono font-bold">Room #{blueTeam.id?.slice(0, 8)}</span>
              </div>
            </div>

            <div className="relative flex-shrink-0">
              <img
                src={blueTeam.hostAvatar}
                alt={blueTeam.hostName}
                className="w-16 h-16 md:w-18 md:h-18 rounded-2xl object-cover ring-2 ring-blue-500 shadow-xl"
              />
              {leadingTeam === 'roomB' && (
                <div className="absolute -top-3 -left-2 bg-amber-400 text-black text-[10px] font-black px-1.5 py-0.5 rounded-md shadow-md flex items-center gap-0.5">
                  <Trophy className="w-3 h-3 fill-current" /> Leader
                </div>
              )}
            </div>
          </div>

          {/* Score Box */}
          <div className="p-3 rounded-2xl bg-black/40 border border-blue-500/20 flex items-center justify-between">
            <div className="text-left">
              <div className="text-xl md:text-2xl font-black text-blue-400 font-mono tracking-tight flex items-center gap-1.5">
                <Shield className="w-5 h-5 fill-blue-500 text-blue-500" />
                {liveScoreB.toLocaleString()}
              </div>
              {leadingTeam === 'roomB' && scoreLead > 0 && (
                <div className="text-[10px] font-extrabold text-amber-400">
                  +{scoreLead.toLocaleString()} Ahead
                </div>
              )}
            </div>
            <span className="text-xs text-slate-300 font-bold uppercase tracking-wider">Score</span>
          </div>

          {/* Top Supporters */}
          {blueTeam.topGifters && blueTeam.topGifters.length > 0 && (
            <div className="space-y-1.5 pt-1 text-right">
              <div className="text-[10px] text-slate-300 font-bold uppercase tracking-wider flex items-center justify-between">
                <span className="text-blue-400 font-mono">3 Contributors</span>
                <span>Top MVPs</span>
              </div>
              <div className="flex items-center justify-end gap-2">
                {blueTeam.topGifters.map((g, idx) => (
                  <div key={idx} className="flex items-center gap-1.5 px-2 py-1 rounded-xl bg-white/5 border border-white/10 text-[10px]">
                    <span className="text-slate-200 font-bold truncate max-w-[60px]">{g.name}</span>
                    <img src={g.avatar} alt={g.name} className="w-5 h-5 rounded-full object-cover" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Interactive Boost Buttons */}
          <div className="grid grid-cols-3 gap-1.5 pt-1">
            <button
              onClick={() => handleCheer('roomB', 100, `💎 Sent Diamond to ${blueTeam.hostName}`)}
              className="py-1.5 px-2 rounded-xl bg-blue-600/30 hover:bg-blue-600/50 border border-blue-500/40 text-blue-200 text-[11px] font-black transition-transform active:scale-95 flex items-center justify-center gap-1 shadow"
            >
              💎 +100
            </button>
            <button
              onClick={() => handleCheer('roomB', 500, `⚡ Sent Energy to ${blueTeam.hostName}`)}
              className="py-1.5 px-2 rounded-xl bg-blue-600/50 hover:bg-blue-600/70 border border-blue-500/50 text-white text-[11px] font-black transition-transform active:scale-95 flex items-center justify-center gap-1 shadow"
            >
              ⚡ +500
            </button>
            <button
              onClick={() => handleCheer('roomB', 2000, `🏰 Sent Castle to ${blueTeam.hostName}`)}
              className="py-1.5 px-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:scale-105 text-white text-[11px] font-black transition-all active:scale-95 flex items-center justify-center gap-1 shadow-lg"
            >
              🏰 +2K
            </button>
          </div>

          {/* Watch Room B Button */}
          {onWatchRoom && (
            <button
              onClick={() => onWatchRoom(blueTeam.id || '', blueTeam.name)}
              className="w-full py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 hover:text-white text-xs font-bold transition-colors flex items-center justify-center gap-1.5"
            >
              <Eye className="w-3.5 h-3.5" /> Watch {blueTeam.hostName}&apos;s Room
            </button>
          )}
        </div>
      </div>

      {/* FOOTER: Tug of War Gauge & Ratio */}
      <div className="space-y-2 pt-2 border-t border-white/10 relative z-10">
        <div className="flex items-center justify-between text-xs font-mono font-black">
          <div className="flex items-center gap-2 text-red-400">
            <span>🔥 {redTeam.name}</span>
            <span className="bg-red-500/20 px-2 py-0.5 rounded text-[11px]">{redPercentage}%</span>
          </div>
          <div className="text-center text-[11px] text-slate-300 font-sans font-bold">
            {isBattleEnded ? (
              <span className="text-amber-400 flex items-center gap-1">
                <Trophy className="w-3.5 h-3.5 fill-current" />
                Winner: {liveScoreA > liveScoreB ? redTeam.hostName : liveScoreB > liveScoreA ? blueTeam.hostName : 'Tied Battle!'}
              </span>
            ) : (
              <span>Tug-of-War Real-Time Gift Ratio</span>
            )}
          </div>
          <div className="flex items-center gap-2 text-blue-400">
            <span className="bg-blue-500/20 px-2 py-0.5 rounded text-[11px]">{bluePercentage}%</span>
            <span>{blueTeam.name} 🛡️</span>
          </div>
        </div>

        {/* Meter */}
        <div className="relative h-4 w-full bg-blue-600 rounded-full overflow-hidden shadow-inner flex p-[2px] border border-white/20">
          <div
            style={{ width: `${redPercentage}%` }}
            className="h-full bg-gradient-to-r from-red-600 via-rose-500 to-pink-500 rounded-l-full transition-all duration-500 shadow"
          />
          {/* Glowing Tug Indicator */}
          <div
            style={{ left: `${redPercentage}%` }}
            className="absolute top-1/2 -translate-x-1/2 -translate-y-1/2 z-20 w-6 h-6 rounded-full bg-white text-black text-[10px] font-black flex items-center justify-center shadow-2xl border-2 border-amber-300 transition-all duration-500"
          >
            ⚔️
          </div>
        </div>
      </div>
    </div>
  );
};

export default PKBattleBoard;
