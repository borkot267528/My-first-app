/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Crown, Check, Sparkles, Shield, Zap, ChevronLeft, Gift } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ApiClient } from '../../lib/api';

export const VipShopPage: React.FC = () => {
  const { setActiveModal, showNotification, currentUser, setCurrentUser, refreshUser } = useApp();
  const [activeTab, setActiveTab] = useState<'vip' | 'svip' | 'frames' | 'themes'>('svip');
  const [selectedPlan, setSelectedPlan] = useState<'1m' | '3m' | '12m'>('12m');

  const plans = [
    { id: '1m', duration: '1 Month', priceCoins: 3000, priceUsd: '$9.99', save: '' },
    { id: '3m', duration: '3 Months', priceCoins: 8000, priceUsd: '$24.99', save: 'Save 15%' },
    { id: '12m', duration: '12 Months (Pro)', priceCoins: 25000, priceUsd: '$69.99', save: 'Save 40%' }
  ];

  const benefits = [
    { title: 'Exclusive Royal Crown Frame', vip: true, svip: true },
    { title: 'Entrance Sports Car Animation', vip: false, svip: true },
    { title: 'Anti-Kick & Anti-Mute Room Privilege', vip: false, svip: true },
    { title: '+20% Gift Experience Bonus', vip: true, svip: true },
    { title: 'Golden SVIP Nameplate & Chat Bubble', vip: false, svip: true },
    { title: '10 Exclusive Luxury Emojis', vip: true, svip: true },
    { title: 'Daily 200 Coins Stipend', vip: true, svip: true }
  ];

  const frames = [
    { name: '👑 Golden Monarch', price: 'SVIP Only', icon: '👑', active: true },
    { name: '⚡ Cyber Pulse', price: '5,000 Coins', icon: '⚡', active: false },
    { name: '🔥 Phoenix Fire', price: '8,000 Coins', icon: '🔥', active: false },
    { name: '💖 Neon Heart', price: '2,000 Coins', icon: '💖', active: false }
  ];

  const handlePurchase = async () => {
    const planObj = plans.find(p => p.id === selectedPlan);
    const cost = planObj?.priceCoins || 3000;
    if (currentUser && currentUser.coins < cost) {
      showNotification(`❌ Insufficient coins! You need ${cost} coins to upgrade.`);
      return;
    }
    try {
      if (currentUser) {
        await ApiClient.rechargeCoins(currentUser.id, -cost);
        await refreshUser();
      }
    } catch (e) {
      // fallback
    }
    if (currentUser) {
      setCurrentUser({ ...currentUser, vipLevel: activeTab === 'vip' ? 'vip' : 'svip' });
    }
    showNotification(`🎉 Successfully upgraded to ${activeTab.toUpperCase()}! All perks unlocked.`);
    setActiveModal('none');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xl overflow-y-auto p-4 animate-fadeIn text-white space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-white/10 pb-3">
        <div className="flex items-center gap-3">
          <button onClick={() => setActiveModal('none')} className="p-2 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/10">
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-lg font-black flex items-center gap-2">
              <Crown className="w-5 h-5 text-amber-400 animate-bounce" /> VIP & SVIP Shop
            </h2>
            <p className="text-xs text-slate-300">Unlock luxury frames and prestige privileges</p>
          </div>
        </div>
        <span className="text-xs bg-amber-500 text-black font-black px-2.5 py-1 rounded-xl shadow">
          🪙 {currentUser?.coins?.toLocaleString() || 0}
        </span>
      </div>

      {/* Tabs */}
      <div className="grid grid-cols-4 gap-2 p-1.5 bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 shadow-lg">
        {[
          { id: 'svip', label: 'SVIP (Best)' },
          { id: 'vip', label: 'VIP' },
          { id: 'frames', label: 'Frames' },
          { id: 'themes', label: 'Themes' }
        ].map(t => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id as any)}
            className={`py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === t.id ? 'bg-gradient-to-r from-amber-500 to-yellow-600 text-black font-black shadow' : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Tab Contents */}
      {(activeTab === 'svip' || activeTab === 'vip') && (
        <div className="space-y-6 animate-fadeIn">
          {/* Banner Card */}
          <div className="p-6 rounded-3xl bg-gradient-to-tr from-amber-500/20 via-purple-900/30 to-yellow-500/20 backdrop-blur-xl border border-amber-400/40 text-center space-y-2 shadow-[0_0_30px_rgba(245,158,11,0.2)]">
            <span className="text-5xl inline-block animate-bounce">👑</span>
            <h3 className="text-2xl font-black text-amber-300">{activeTab.toUpperCase()} PASS</h3>
            <p className="text-xs text-slate-200">The absolute pinnacle of status in Aura Voice Chat rooms</p>
          </div>

          {/* Pricing Plans */}
          <div>
            <h4 className="text-xs font-bold text-slate-300 mb-3 uppercase tracking-wider">Select Duration Plan</h4>
            <div className="grid grid-cols-3 gap-3">
              {plans.map(plan => (
                <div
                  key={plan.id}
                  onClick={() => setSelectedPlan(plan.id as any)}
                  className={`cursor-pointer p-4 rounded-2xl border text-center relative transition-all ${
                    selectedPlan === plan.id
                      ? 'bg-amber-500/20 border-amber-400 scale-105 shadow-[0_0_15px_rgba(245,158,11,0.3)]'
                      : 'bg-white/5 backdrop-blur-xl border-white/10 hover:border-white/20'
                  }`}
                >
                  {plan.save && (
                    <span className="absolute -top-2.5 left-1/2 -translate-x-1/2 bg-gradient-to-r from-red-500 to-pink-500 text-white text-[9px] font-black px-2 py-0.5 rounded-full shadow">
                      {plan.save}
                    </span>
                  )}
                  <h5 className="font-bold text-white text-xs mt-1">{plan.duration}</h5>
                  <p className="text-base font-black text-amber-300 mt-2">{plan.priceCoins} 🪙</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">{plan.priceUsd}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Benefits Comparison */}
          <div className="bg-white/5 backdrop-blur-xl p-5 rounded-3xl border border-white/10 space-y-3 shadow-xl">
            <h4 className="font-bold text-white text-sm flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" /> Exclusive Privileges Table
            </h4>
            <div className="space-y-2.5 text-xs">
              {benefits.map((b, i) => (
                <div key={i} className="flex items-center justify-between p-2.5 rounded-xl bg-black/40 border border-white/10">
                  <span className="text-slate-200">{b.title}</span>
                  <div className="flex items-center gap-4">
                    <span className={`font-bold ${b[activeTab] ? 'text-emerald-400' : 'text-slate-500'}`}>
                      {b[activeTab] ? '✓ Unlocked' : '✕'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Purchase Button */}
          <button
            onClick={handlePurchase}
            className="w-full py-4 bg-gradient-to-r from-amber-500 via-yellow-500 to-pink-600 hover:scale-105 text-black font-black text-sm rounded-2xl shadow-[0_0_25px_rgba(245,158,11,0.4)] transition-transform"
          >
            Upgrade to {activeTab.toUpperCase()} Now ({plans.find(p => p.id === selectedPlan)?.priceCoins} 🪙)
          </button>
        </div>
      )}

      {activeTab === 'frames' && (
        <div className="grid grid-cols-2 gap-4 animate-fadeIn">
          {frames.map((f, i) => (
            <div key={i} className="p-5 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 hover:border-white/20 transition-all text-center space-y-3 shadow-xl">
              <div className="w-16 h-16 rounded-full bg-white/10 mx-auto flex items-center justify-center text-3xl border border-white/20 animate-pulse">
                {f.icon}
              </div>
              <h5 className="font-extrabold text-white text-sm">{f.name}</h5>
              <p className="text-xs text-amber-400 font-bold">{f.price}</p>
              <button 
                onClick={() => showNotification(`Equipped frame: ${f.name}!`)}
                className={`w-full py-2 rounded-xl text-xs font-bold ${f.active ? 'bg-amber-400 text-black shadow' : 'bg-white/10 text-white hover:bg-white/20 border border-white/10'}`}
              >
                {f.active ? 'Equipped ✓' : 'Equip Frame'}
              </button>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'themes' && (
        <div className="grid grid-cols-2 gap-4 animate-fadeIn">
          {['🌌 Nebula Deep', '🌸 Tokyo Twilight', '⚡ Cyberpunk Neon', '👑 Royal Gold'].map((thm, i) => (
            <div key={i} className="p-5 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 hover:border-white/20 transition-all text-center space-y-3 shadow-xl">
              <div className="w-full h-20 rounded-2xl bg-gradient-to-r from-purple-800 to-pink-600 flex items-center justify-center font-bold text-xs border border-white/20 shadow">
                {thm}
              </div>
              <button onClick={() => showNotification(`Applied profile theme: ${thm}!`)} className="w-full py-2 bg-white text-purple-900 hover:bg-purple-100 font-black text-xs rounded-xl shadow">
                Apply Theme
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
