/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { 
  User, Crown, Shield, DollarSign, Gift, Award, Eye, 
  Image as ImageIcon, Settings, Share2, Copy, Check, 
  ChevronRight, Sparkles, LogOut, Wallet, HelpCircle, Flame, Trophy, ShieldCheck,
  ArrowUpRight, ArrowDownRight, Edit3, Camera, Radio, Heart, Users
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ApiClient } from '../../lib/api';
import { getEffectiveStaffIdentity, STAFF_IDENTITY_CONFIG } from '../../lib/staffIdentity';
import { StaffIdentityBadgeCard } from './StaffIdentityBadgeCard';
import { ProfileIdBadge } from '../common/ProfileIdBadge';
import { getProfileIdColor } from '../../lib/profileIdColor';
import { EditProfileModal } from './EditProfileModal';

export const ProfilePage: React.FC = () => {
  const { 
    currentUser, 
    setCurrentUser, 
    activeRoom,
    setActiveRoom,
    setActiveModal, 
    showNotification, 
    refreshUser,
    firebaseUser,
    signOut,
    setIsAuthModalOpen
  } = useApp();
  const [copied, setCopied] = useState(false);
  const [isEditProfileOpen, setIsEditProfileOpen] = useState(false);
  const [activeSection, setActiveSection] = useState<'overview' | 'medals' | 'gift_wall' | 'visitors' | 'album'>('overview');

  const cachedUser = useMemo(() => {
    try {
      const c = localStorage.getItem('aura_cached_user');
      return c ? JSON.parse(c) : null;
    } catch (e) {
      return null;
    }
  }, []);

  const user = currentUser || cachedUser || {
    id: '2383452',
    uid: '2383452',
    name: 'BORKOT',
    email: 'imoborkot@gmail.com',
    avatar: 'https://lh3.googleusercontent.com/a-/ALV-UjXavpvOoaHAyXJHxQJ3I8kgTY6A73C5Amuv5xg0iwmyUuG_Rxwo0BJ4yWGFHOVZJ0HcisUQiLwlvL_msUMAoAp4sITSkTHsB9UNqkfHU8qKjpAEvVMvIJEpnS4EK0MQhZvxox1NRHmjaiG5vlkIXi4G4JzEOecKz4I6P1UMs2nTbBKuWLRQVR2bQQKr8amGhHvwpOpFgmarbeqe99PpECmCj7bJ243CKFCGbpB3VP1B6c9BBxEE-AQjEvl56vcFN1ERuUmQKAv6KJ6zvYYTJapq5ZWByT8PCfnzOwK4ibKRn7RSg-_-4KcDh6yq8E0IcNgVippiw2h0NAgwVtT423DdmlF_2kw5bOelq0SZ6jBW0NwNwL9QDaJSmBdS7Wzy1hkGI2yxLSJGWZPeC18BvLYxh0wxDgoKcZJx9dO-Q6D6DegtZ9wFMPUfX4kEQLJd2ImJVgYTfodKctibaFJ1tmxQCtO4Ms_VhFnmIezk-YHlwGXElT44kr8db9hcMP6Hx3ldf08EzpU1MVlwjgJ1cCbX-yavO6IgXapYO6jGG1tHaen1qdoGLeLKhiuYH2P6F7Q052BwneEOY7ff4wQplvHSMaFRELBIm8F31OZm0Qt8haOakqhAaXADAOYbKc3g5mqDb6HV2ICMk9_iBE3RoRJ2RIS8Vum1mktLy9JAgCswfINz7mfXCw9g-xjHHwmp_Ksav5G-JAlPdsm0yKzJJpqfBLfVK6sC_p775MFCC2W-06qvAJq32MyVrW24WxBNiVa-qelLO0s_WOQoDCvNAfy4hnv97ER6ZVDYrgMD_gWBmvaGoew6KSB0Kbd5iKdJIqWwJBPrZUQtLgQVs2QUvTCK4JDNWPi80NFo-dH4DNPFDalzR3lzvDgSp3mkFhjk_TodmqeSGRCM7ppClF_tbpET0h5pADduVP7Dq_0W9n8c6ju94xEK27GTe0djVRdeHB66X4JrJ9iSGUbuKA_pvAO-YsbNQucRvn5WDiTZgZlOpcjhjPdIjHfXmDsow9vghFEDlMEJGIsIaZEQG5NYBnEmSc41aavcOMM_mMY6RgoRX_tmFgOAMDNL_g=s96-c',
    frame: '👑 Golden Monarch',
    background: '🌌 Nebula Deep',
    gender: 'male',
    country: 'China',
    countryFlag: '🇨🇳',
    bio: '👑 Platform CEO & Founder of Aura Voice Platform. Full administrative control & staff management.',
    role: 'ceo',
    vipLevel: 'svip',
    coins: 10000000,
    diamonds: 5000000,
    level: 100,
    sendingLevel: 100,
    receivingLevel: 100,
    familyName: 'Royal Dynasty 👑',
    badges: [
      { id: 'b1', name: 'Executive Leader', icon: '👑', description: 'Platform CEO & Owner' },
      { id: 'b2', name: 'Founding Icon', icon: '🌟', description: 'Early adopter of Aura Voice' },
      { id: 'b3', name: 'PK Conqueror', icon: '⚔️', description: 'Won 100+ Live PK Battles' }
    ],
    medals: [
      { id: 'm1', name: 'Owner', icon: '⚡', level: 10 },
      { id: 'm2', name: 'Charisma King', icon: '🔥', level: 9 }
    ]
  };

  const giftWall = [
    { name: 'Royal Crown 👑', count: 142, icon: '👑', sender: 'Marcus' },
    { name: 'Sports Car 🏎️', count: 88, icon: '🏎️', sender: 'Alex Chen' },
    { name: 'Diamond Ring 💍', count: 310, icon: '💍', sender: 'Kenji Sato' },
    { name: 'Rocket Ship 🚀', count: 45, icon: '🚀', sender: 'Sophia' }
  ];

  const visitors = [
    { name: 'Alex Chen', time: '10 mins ago', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80' },
    { name: 'Marcus Aurelius', time: '1 hour ago', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80' },
    { name: 'Sophia Taylor', time: 'Yesterday', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80' }
  ];

  const handleCopyUid = () => {
    navigator.clipboard.writeText(user.uid);
    setCopied(true);
    showNotification('UID copied to clipboard!');
    setTimeout(() => setCopied(false), 2000);
  };

  const effectiveStaffIdentity = getEffectiveStaffIdentity(user);
  const staffRoleConfig = effectiveStaffIdentity ? STAFF_IDENTITY_CONFIG[effectiveStaffIdentity.role] : null;

  return (
    <div className="pb-24 space-y-5 animate-fadeIn">
      {/* 1. PROFILE HEADER CARD WITH EXCLUSIVE ROLE BACKGROUND */}
      <div className={`relative overflow-hidden rounded-3xl p-6 backdrop-blur-xl border shadow-2xl space-y-4 transition-all duration-300 ${
        staffRoleConfig ? staffRoleConfig.bgClasses : 'bg-gradient-to-br from-purple-900/30 via-indigo-900/20 to-pink-900/30 border-white/10'
      }`}>
        {/* Background Tag */}
        <div className="absolute top-3 right-3 text-[10px] text-slate-300 bg-black/50 px-2.5 py-1 rounded-full border border-white/10 backdrop-blur-md flex items-center gap-1 font-mono">
          <span>Theme: {staffRoleConfig ? `${staffRoleConfig.name} Exclusive` : (user.background || 'Standard Dark')}</span>
        </div>

        <div className="flex items-start gap-4">
          <div className="relative group">
            <div className={`w-20 h-20 rounded-3xl p-1 shadow-lg cursor-pointer ${
              staffRoleConfig ? staffRoleConfig.badgeStyle : 'bg-gradient-to-tr from-amber-400 via-pink-500 to-purple-600'
            }`}
            onClick={() => setIsEditProfileOpen(true)}
            title="Click to edit profile photo"
            >
              <img src={user.avatar} alt={user.name} className="w-full h-full rounded-2xl object-cover border-2 border-black/80 group-hover:opacity-80 transition-opacity" />
            </div>

            {/* Quick Camera Edit Button Overlay */}
            <button
              onClick={() => setIsEditProfileOpen(true)}
              className="absolute -top-1.5 -right-1.5 p-1.5 bg-gradient-to-r from-amber-400 to-yellow-500 text-black rounded-xl shadow-md hover:scale-110 active:scale-95 transition-all z-10"
              title="Change Profile Photo"
            >
              <Camera className="w-3 h-3 stroke-[2.5]" />
            </button>

            {/* DUAL LEVEL BADGES ON AVATAR */}
            <div className="absolute -bottom-2 -left-1 -right-1 flex justify-between gap-1 pointer-events-none">
              <span className="bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-600 text-black text-[9px] font-black px-1.5 py-0.5 rounded-full shadow-lg border border-amber-300 flex items-center gap-0.5" title="Sending Level (Coins Spent)">
                <ArrowUpRight className="w-2.5 h-2.5 stroke-[3]" /> Lv.{user.sendingLevel || user.level || 1}
              </span>
              <span className="bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 text-white text-[9px] font-black px-1.5 py-0.5 rounded-full shadow-lg border border-cyan-300 flex items-center gap-0.5" title="Receiving Level (Gifts Earned)">
                <ArrowDownRight className="w-2.5 h-2.5 stroke-[3]" /> Lv.{user.receivingLevel || Math.max(1, Math.floor((user.level || 1) * 0.85))}
              </span>
            </div>
          </div>

          <div className="flex-1 min-w-0">
            {/* User Name & Edit Button */}
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-2 flex-wrap min-w-0">
                <h2 className="text-lg font-black text-white truncate">{user.name}</h2>
                {user.vipLevel === 'svip' && <span className="bg-gradient-to-r from-amber-400 to-yellow-600 text-black text-[10px] font-black px-1.5 py-0.2 rounded shadow">SVIP</span>}
                {user.vipLevel === 'vip' && <span className="bg-purple-600 text-white text-[10px] font-bold px-1.5 py-0.2 rounded">VIP</span>}
              </div>

              {/* EDIT PROFILE BUTTON */}
              <button
                onClick={() => setIsEditProfileOpen(true)}
                className="px-2.5 py-1 bg-white/10 hover:bg-amber-400 hover:text-black text-slate-200 font-bold text-xs rounded-xl border border-white/15 hover:border-amber-400 flex items-center gap-1.5 shadow transition-all active:scale-95 shrink-0"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Edit</span>
              </button>
            </div>

            {/* STAFF IDENTITY DISPLAY: Clean Compact Badge in App Profile */}
            {effectiveStaffIdentity && (
              <StaffIdentityBadgeCard identity={effectiveStaffIdentity} compact={true} />
            )}

            {/* Profile ID / UID with Dynamic Color System */}
            <div className="flex items-center gap-2 mt-1.5 flex-wrap">
              <ProfileIdBadge
                uid={user.uid}
                size="md"
                showLabel={true}
                showIcon={true}
                showGroupTag={false}
                canCopy={true}
                onCopy={() => showNotification('UID copied to clipboard!')}
              />
            </div>

            <div className="flex items-center gap-2 mt-2 text-[11px] text-slate-200">
              <span className="bg-black/40 px-2 py-0.5 rounded-lg border border-white/10 font-medium">
                {user.gender === 'female' ? '♀ Female' : user.gender === 'male' ? '♂ Male' : '⚲ Other'}
              </span>
              <span className="bg-black/40 px-2 py-0.5 rounded-lg border border-white/10 font-medium">
                {user.countryFlag} {user.country}
              </span>
            </div>
          </div>
        </div>

        <p className="text-xs text-slate-200 leading-relaxed bg-black/40 backdrop-blur-md p-3 rounded-2xl border border-white/10">
          {user.bio}
        </p>

        {/* 2-LEVEL ID STATUS PANEL: SENDING LEVEL & RECEIVING LEVEL */}
        <div className="space-y-2 pt-1">
          <div className="flex items-center justify-between">
            <span className="text-xs font-black text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" /> Dual ID Level Classification
            </span>
            <span className="text-[10px] text-slate-400">2-Tier Identity System</span>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {/* SENDING LEVEL ID CARD (Wealth Level) */}
            <div className="relative overflow-hidden p-3.5 rounded-2xl bg-gradient-to-br from-amber-950/80 via-amber-900/40 to-black/80 border border-amber-400/50 shadow-xl space-y-2 group">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-2 bg-gradient-to-tr from-amber-400 to-yellow-500 text-black rounded-xl font-black text-xs shadow-md">
                    <ArrowUpRight className="w-4 h-4 stroke-[3]" />
                  </div>
                  <div>
                    <span className="text-[10px] font-black uppercase text-amber-300 tracking-wider block">Sending ID</span>
                    <h4 className="text-sm font-black text-white font-mono flex items-center gap-1">
                      Lv.{user.sendingLevel || user.level || 1}
                      <span className="text-[10px] text-amber-300/80 font-normal">(Wealth)</span>
                    </h4>
                  </div>
                </div>
                <span className="text-xl">🪙</span>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-[10px] font-bold text-amber-200/90">
                  <span>Coins Sent Tier</span>
                  <span className="font-mono text-amber-300">Level {user.sendingLevel || user.level || 1}</span>
                </div>
                <div className="w-full bg-black/70 rounded-full h-1.5 p-0.5 border border-amber-400/30">
                  <div className="bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 h-full rounded-full shadow" style={{ width: `${Math.min(100, Math.max(20, ((user.sendingLevel || user.level || 1) % 10) * 10 || 75))}%` }} />
                </div>
              </div>
            </div>

            {/* RECEIVING LEVEL ID CARD (Charm Level) */}
            <div className="relative overflow-hidden p-3.5 rounded-2xl bg-gradient-to-br from-cyan-950/80 via-blue-900/40 to-black/80 border border-cyan-400/50 shadow-xl space-y-2 group">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-2 bg-gradient-to-tr from-cyan-400 to-blue-500 text-black rounded-xl font-black text-xs shadow-md">
                    <ArrowDownRight className="w-4 h-4 stroke-[3]" />
                  </div>
                  <div>
                    <span className="text-[10px] font-black uppercase text-cyan-300 tracking-wider block">Receiving ID</span>
                    <h4 className="text-sm font-black text-white font-mono flex items-center gap-1">
                      Lv.{user.receivingLevel || Math.max(1, Math.floor((user.level || 1) * 0.85))}
                      <span className="text-[10px] text-cyan-300/80 font-normal">(Charm)</span>
                    </h4>
                  </div>
                </div>
                <span className="text-xl">💎</span>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-[10px] font-bold text-cyan-200/90">
                  <span>Diamonds Received Tier</span>
                  <span className="font-mono text-cyan-300">Level {user.receivingLevel || Math.max(1, Math.floor((user.level || 1) * 0.85))}</span>
                </div>
                <div className="w-full bg-black/70 rounded-full h-1.5 p-0.5 border border-cyan-400/30">
                  <div className="bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-500 h-full rounded-full shadow" style={{ width: `${Math.min(100, Math.max(20, (((user.receivingLevel || Math.max(1, Math.floor((user.level || 1) * 0.85))) % 10) * 10) || 60))}%` }} />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* MY VOICE ROOM (ROOM ID MATCHES PROFILE ID) */}
        <div 
          onClick={async () => {
            try {
              const profileId = user.uid || user.id;
              let room = await ApiClient.getRoomById(profileId).then(r => r.room).catch(() => null);
              if (!room) {
                room = await ApiClient.createRoom(
                  `${user.name}'s Live Room`, 
                  'Welcome to my voice room! Chat, chill & connect.', 
                  'popular'
                );
              }
              if (room) {
                setActiveRoom(room);
                showNotification(`Entered voice room (ID: ${profileId})`);
              }
            } catch (err: any) {
              showNotification(err.message || 'Could not open voice room');
            }
          }}
          className="cursor-pointer p-4 rounded-2xl bg-gradient-to-r from-purple-900/60 via-indigo-950/60 to-black/60 border border-purple-500/40 text-white shadow-xl flex items-center justify-between hover:scale-[1.01] hover:border-purple-400 transition-all group"
        >
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-purple-600/30 rounded-xl border border-purple-400/50 text-purple-300 shadow">
              <Radio className="w-6 h-6 animate-pulse text-purple-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h4 className="font-black text-sm text-white">
                  🎙️ My Voice Room
                </h4>
                <ProfileIdBadge uid={user.uid} size="xs" />
              </div>
              <p className="text-[11px] font-medium text-purple-200/80">
                Voice Room ID is identical to your Profile ID ({user.uid})
              </p>
            </div>
          </div>
          <span className="px-3.5 py-1.5 bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-black text-xs rounded-xl shadow-lg border border-purple-300/30 group-hover:scale-105 transition-all">
            ENTER →
          </span>
        </div>

        {/* STAFF / CEO ADMIN PORTAL ACCESS BANNER */}
        {['ceo', 'gm', 'manager', 'super_admin', 'admin', 'bd', 'agency', 'host'].includes(user.role) && (
          <div 
            onClick={() => setActiveModal('admin')}
            className="cursor-pointer p-4 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-600 to-purple-800 border border-amber-300/40 text-black shadow-2xl flex items-center justify-between hover:scale-[1.02] transition-transform group"
          >
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-black/80 rounded-xl border border-amber-400 text-amber-400 shadow">
                <Shield className="w-6 h-6 animate-pulse" />
              </div>
              <div>
                <h4 className="font-black text-sm text-white flex items-center gap-1.5">
                  🛡️ Staff Admin & CEO Portal
                </h4>
                <p className="text-[11px] font-bold text-amber-200">
                  Full RBAC Governance, Staff Permissions & Ledger Audit
                </p>
              </div>
            </div>
            <span className="px-3 py-1 bg-black text-amber-400 font-black text-xs rounded-xl border border-amber-400/50 shadow group-hover:bg-amber-400 group-hover:text-black transition-colors">
              OPEN →
            </span>
          </div>
        )}
      </div>

      {/* 2. CONNECTIONS MENU (❤️ CP & 👥 Friends) */}
      <div className="space-y-2">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
            <Heart className="w-3.5 h-3.5 text-pink-400" /> Connections
          </h3>
          <span className="text-[11px] text-purple-300/80 font-medium">Social Network</span>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {/* CP Option */}
          <div
            onClick={() => setActiveModal('cp')}
            className="cursor-pointer p-4 rounded-3xl bg-gradient-to-br from-pink-950/40 via-purple-950/30 to-black/60 backdrop-blur-xl border border-pink-500/30 hover:border-pink-400 hover:bg-pink-950/60 transition-all shadow-xl space-y-1.5 group"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-pink-300 flex items-center gap-1.5">
                <Heart className="w-4 h-4 text-pink-500 fill-pink-500" /> ❤️ CP
              </span>
              <ChevronRight className="w-4 h-4 text-pink-400 group-hover:translate-x-1 transition-transform" />
            </div>
            <div className="text-sm font-black text-white">Couple Space</div>
            <p className="text-[11px] text-pink-200/70">
              My CP • Discover • Requests
            </p>
          </div>

          {/* Friends Option */}
          <div
            onClick={() => setActiveModal('friends')}
            className="cursor-pointer p-4 rounded-3xl bg-gradient-to-br from-blue-950/40 via-indigo-950/30 to-black/60 backdrop-blur-xl border border-blue-500/30 hover:border-blue-400 hover:bg-blue-950/60 transition-all shadow-xl space-y-1.5 group"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-blue-300 flex items-center gap-1.5">
                <Users className="w-4 h-4 text-blue-400" /> 👥 Friends
              </span>
              <ChevronRight className="w-4 h-4 text-blue-400 group-hover:translate-x-1 transition-transform" />
            </div>
            <div className="text-sm font-black text-white">Friend Network</div>
            <p className="text-[11px] text-blue-200/70">
              My Friends • Requests • Discover
            </p>
          </div>
        </div>
      </div>

      {/* 3. WALLET & RECHARGE OVERVIEW BAR */}
      <div className="grid grid-cols-2 gap-3">
        <div 
          onClick={() => setActiveModal('wallet')}
          className="cursor-pointer p-4 rounded-3xl bg-gradient-to-br from-amber-950/40 to-black/60 backdrop-blur-xl border border-amber-500/30 hover:border-amber-400 hover:bg-amber-950/60 transition-all shadow-xl space-y-1 group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-amber-300">My Coins 🪙</span>
            <ChevronRight className="w-4 h-4 text-amber-400 group-hover:translate-x-1 transition-transform" />
          </div>
          <h3 className="text-xl font-black text-amber-400 font-mono">{user.coins?.toLocaleString()}</h3>
          <div className="flex items-center gap-1.5 pt-0.5">
            <span className="text-[10px] bg-amber-400 text-black px-2 py-0.5 rounded-md font-black inline-block shadow">
              ⚡ Edit Amount +
            </span>
          </div>
        </div>

        <div 
          onClick={() => setActiveModal('wallet')}
          className="cursor-pointer p-4 rounded-3xl bg-gradient-to-br from-cyan-950/40 to-black/60 backdrop-blur-xl border border-cyan-500/30 hover:border-cyan-400 hover:bg-cyan-950/60 transition-all shadow-xl space-y-1 group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-cyan-300">My Diamonds 💎</span>
            <ChevronRight className="w-4 h-4 text-cyan-400 group-hover:translate-x-1 transition-transform" />
          </div>
          <h3 className="text-xl font-black text-cyan-400 font-mono">{user.diamonds?.toLocaleString()}</h3>
          <div className="flex items-center gap-1.5 pt-0.5">
            <span className="text-[10px] bg-cyan-400 text-black px-2 py-0.5 rounded-md font-black inline-block shadow">
              ⚡ Edit / Payout 💵
            </span>
          </div>
        </div>
      </div>

      {/* 3. SECTION NAVIGATION TABS */}
      <div className="grid grid-cols-5 gap-1 p-1.5 bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 text-center shadow-lg">
        {[
          { id: 'overview', label: 'VIP/Shop', icon: <Crown className="w-3.5 h-3.5 mx-auto" /> },
          { id: 'medals', label: 'Medals', icon: <Award className="w-3.5 h-3.5 mx-auto" /> },
          { id: 'gift_wall', label: 'Gift Wall', icon: <Gift className="w-3.5 h-3.5 mx-auto" /> },
          { id: 'visitors', label: 'Visitors', icon: <Eye className="w-3.5 h-3.5 mx-auto" /> },
          { id: 'album', label: 'Album', icon: <ImageIcon className="w-3.5 h-3.5 mx-auto" /> }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveSection(tab.id as any)}
            className={`py-2 px-1 rounded-xl text-[10px] font-bold transition-all ${
              activeSection === tab.id
                ? 'bg-white text-purple-900 font-black shadow'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            {tab.icon}
            <span className="block mt-0.5 truncate">{tab.label}</span>
          </button>
        ))}
      </div>

      {/* SECTION CONTENTS */}
      {activeSection === 'overview' && (
        <div className="space-y-3">
          {/* VIP Banner Card */}
          <div 
            onClick={() => setActiveModal('vip_shop')}
            className="cursor-pointer p-4 rounded-3xl bg-gradient-to-r from-amber-500/20 to-purple-900/30 backdrop-blur-xl border border-amber-500/30 flex items-center justify-between hover:border-amber-400/60 transition-all shadow-xl"
          >
            <div className="flex items-center gap-3">
              <span className="text-3xl animate-bounce">👑</span>
              <div>
                <h4 className="font-black text-amber-300 text-sm">SVIP Exclusive Membership</h4>
                <p className="text-xs text-slate-300">Active until Dec 2027 • 10 Exclusive Perks</p>
              </div>
            </div>
            <button className="px-3 py-1.5 bg-white text-purple-900 font-black text-xs rounded-xl shadow">
              Upgrade
            </button>
          </div>

          {/* Quick Tools */}
          <div className="bg-white/5 backdrop-blur-xl rounded-3xl border border-white/10 overflow-hidden divide-y divide-white/10 shadow-xl">
            <button onClick={() => setActiveModal('cp')} className="w-full p-4 flex items-center justify-between hover:bg-white/10 text-left transition-colors">
              <span className="text-xs font-bold text-white flex items-center gap-2.5">
                <Heart className="w-4 h-4 text-pink-400 fill-pink-400/30" /> ❤️ CP (Couple Space & Level)
              </span>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </button>
            <button onClick={() => setActiveModal('friends')} className="w-full p-4 flex items-center justify-between hover:bg-white/10 text-left transition-colors">
              <span className="text-xs font-bold text-white flex items-center gap-2.5">
                <Users className="w-4 h-4 text-blue-400" /> 👥 Friends & Connection Requests
              </span>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </button>
            <button onClick={() => setActiveModal('lucky_bag')} className="w-full p-4 flex items-center justify-between hover:bg-white/10 text-left transition-colors">
              <span className="text-xs font-bold text-white flex items-center gap-2.5">
                <Gift className="w-4 h-4 text-amber-400" /> Lucky Bag Analytics & Leaderboard
              </span>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </button>
            <button onClick={() => setActiveModal('spin')} className="w-full p-4 flex items-center justify-between hover:bg-white/10 text-left transition-colors">
              <span className="text-xs font-bold text-white flex items-center gap-2.5">
                <Flame className="w-4 h-4 text-pink-400" /> Daily Spin & Prize Rewards
              </span>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </button>
            <button onClick={() => setActiveModal('pk')} className="w-full p-4 flex items-center justify-between hover:bg-white/10 text-left transition-colors">
              <span className="text-xs font-bold text-white flex items-center gap-2.5">
                <Trophy className="w-4 h-4 text-red-400" /> PK Battle History & Matchmaker
              </span>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </button>
            {['ceo', 'super_admin', 'gm', 'manager', 'admin', 'bd', 'agency', 'host'].includes(user.role) && (
              <button onClick={() => setActiveModal('admin')} className="w-full p-4 flex items-center justify-between hover:bg-white/10 text-left transition-colors bg-amber-500/10">
                <span className="text-xs font-extrabold text-amber-400 flex items-center gap-2.5">
                  <Shield className="w-4 h-4 text-amber-400" /> Staff Admin & Permission Portal
                </span>
                <span className="bg-amber-400 text-black text-[9px] font-black px-1.5 py-0.5 rounded">STAFF</span>
              </button>
            )}
          </div>
        </div>
      )}

      {activeSection === 'medals' && (
        <div className="space-y-3">
          <h4 className="font-bold text-white text-xs px-1">My Badges & Medals ({user.badges?.length + user.medals?.length || 0})</h4>
          <div className="grid grid-cols-2 gap-2.5">
            {user.badges?.map((b: any, i: number) => (
              <div key={i} className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 flex items-center gap-3 shadow-xl">
                <span className="text-3xl">{b.icon}</span>
                <div>
                  <h5 className="font-bold text-white text-xs">{b.name}</h5>
                  <p className="text-[10px] text-slate-400 line-clamp-1">{b.description}</p>
                </div>
              </div>
            ))}
            {user.medals?.map((m: any, i: number) => (
              <div key={i} className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 flex items-center gap-3 shadow-xl">
                <span className="text-3xl">{m.icon}</span>
                <div>
                  <h5 className="font-bold text-white text-xs">{m.name}</h5>
                  <span className="text-[10px] bg-amber-500 text-black font-black px-1.5 py-0.2 rounded">LV.{m.level}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeSection === 'gift_wall' && (
        <div className="space-y-3">
          <h4 className="font-bold text-white text-xs px-1">My Gift Wall Showcase</h4>
          <div className="grid grid-cols-2 gap-3">
            {giftWall.map((gw, i) => (
              <div key={i} className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 text-center space-y-1 shadow-xl">
                <span className="text-4xl inline-block animate-bounce">{gw.icon}</span>
                <h5 className="font-extrabold text-white text-xs">{gw.name}</h5>
                <p className="text-xs font-black text-pink-400">Received x{gw.count}</p>
                <span className="text-[9px] text-slate-400 block">Top Sender: {gw.sender}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeSection === 'visitors' && (
        <div className="space-y-2.5">
          <h4 className="font-bold text-white text-xs px-1">Recent Profile Visitors</h4>
          {visitors.map((v, idx) => (
            <div key={idx} className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 flex items-center justify-between shadow-xl">
              <div className="flex items-center gap-3">
                <img src={v.avatar} alt={v.name} className="w-11 h-11 rounded-full object-cover border border-white/20" />
                <div>
                  <h5 className="font-bold text-white text-xs">{v.name}</h5>
                  <p className="text-[10px] text-slate-400">Visited your room & profile</p>
                </div>
              </div>
              <span className="text-[10px] text-slate-500">{v.time}</span>
            </div>
          ))}
        </div>
      )}

      {activeSection === 'album' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <h4 className="font-bold text-white text-xs">My Photo Album (4)</h4>
            <button onClick={() => showNotification('Photo uploaded to album!')} className="text-xs font-bold text-purple-300 hover:text-white">
              + Upload
            </button>
          </div>
          <div className="grid grid-cols-2 gap-2.5">
            {[
              'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=400&q=80',
              'https://images.unsplash.com/photo-1510915361894-db8b60106cb1?auto=format&fit=crop&w=400&q=80',
              'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=400&q=80',
              'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=400&q=80'
            ].map((img, i) => (
              <img key={i} src={img} alt="Album" className="w-full h-32 rounded-2xl object-cover border border-white/20 shadow-xl hover:scale-105 transition-transform" />
            ))}
          </div>
        </div>
      )}

      {/* 4. FIREBASE AUTH & SESSION MANAGEMENT CARD */}
      <div className="p-4 bg-gradient-to-r from-purple-900/30 via-slate-900/60 to-slate-900/30 rounded-3xl border border-white/10 space-y-3 shadow-xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-400 to-yellow-500 flex items-center justify-center text-black font-black text-xs shadow-md">
              🔥
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h4 className="text-xs font-black text-white">Firebase Authentication</h4>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[9px] font-bold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  Active Session
                </span>
              </div>
              <p className="text-[11px] text-slate-300 truncate max-w-[220px]">
                {firebaseUser ? firebaseUser.email : user.email || 'Session Authenticated'}
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsAuthModalOpen(true)}
            className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs border border-white/15 transition-all active:scale-95 flex items-center gap-1"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
            <span>Switch / Sign In</span>
          </button>
        </div>

        <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[11px]">
          <span className="text-slate-400">Security Provider: Firebase Auth &bull; Firestore</span>
          <button
            onClick={() => signOut()}
            className="text-red-400 hover:text-red-300 font-bold flex items-center gap-1 transition-colors"
          >
            <LogOut className="w-3 h-3" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>

      {/* 5. SETTINGS & EDIT PROFILE FOOTER */}
      <div className="grid grid-cols-3 gap-2 pt-2">
        <button 
          onClick={() => setIsEditProfileOpen(true)}
          className="p-3 rounded-2xl bg-gradient-to-r from-amber-400 to-yellow-500 text-black text-xs font-black flex items-center justify-center gap-1.5 shadow-lg shadow-amber-500/10 hover:scale-105 active:scale-95 transition-all"
        >
          <Edit3 className="w-4 h-4" /> Edit Profile
        </button>
        <button 
          onClick={() => showNotification('Settings dialog opened (Version 1.0.0 Pro)')}
          className="p-3 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 text-xs font-bold text-white flex items-center justify-center gap-1.5 hover:bg-white/10 shadow-xl"
        >
          <Settings className="w-4 h-4 text-purple-400" /> Settings
        </button>
        <button 
          onClick={() => showNotification(`Invite link copied: https://auravoice.io/invite/${user.uid}`)}
          className="p-3 rounded-2xl bg-white text-purple-900 text-xs font-black flex items-center justify-center gap-1.5 shadow-xl hover:scale-105 transition-transform"
        >
          <Share2 className="w-4 h-4" /> Invite
        </button>
      </div>

      {/* 6. EDIT PROFILE MODAL */}
      <EditProfileModal
        user={user}
        isOpen={isEditProfileOpen}
        onClose={() => setIsEditProfileOpen(false)}
        onProfileUpdated={(updatedUser) => {
          setCurrentUser(updatedUser);
          refreshUser?.();
        }}
        showNotification={showNotification}
      />
    </div>
  );
};
