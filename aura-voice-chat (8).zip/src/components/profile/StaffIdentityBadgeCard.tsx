/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Building2, Award, CheckCircle2, Sparkles, Frame, Layout, ShieldCheck, Layers } from 'lucide-react';
import { StaffIdentity } from '../../types';
import { STAFF_IDENTITY_CONFIG, getStaffIdentitiesList } from '../../lib/staffIdentity';

interface StaffIdentityBadgeCardProps {
  identity: StaffIdentity;
  compact?: boolean;
  showLevel?: boolean;
}

export const StaffIdentityBadgeCard: React.FC<StaffIdentityBadgeCardProps> = ({ 
  identity, 
  compact = false,
  showLevel = false 
}) => {
  const resolvedRoles = getStaffIdentitiesList(identity);
  const primaryConfig = STAFF_IDENTITY_CONFIG[identity.role] || STAFF_IDENTITY_CONFIG['official_staff'];

  if (compact) {
    return (
      <div className="flex flex-wrap items-center gap-1.5 my-1.5">
        {resolvedRoles.map((item) => (
          <span
            key={item.role}
            className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-black shadow-md backdrop-blur-md ${item.badgeStyle}`}
          >
            <span>{item.badge}</span>
          </span>
        ))}
        {identity.isVerified && (
          <span className="inline-flex items-center gap-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] px-2 py-0.5 rounded-full font-bold">
            <CheckCircle2 className="w-3 h-3 text-emerald-400 fill-emerald-400/20" /> Verified
          </span>
        )}
        {showLevel && (
          <span className="text-[10px] font-mono font-bold text-amber-300 bg-black/40 px-1.5 py-0.5 rounded-full border border-white/10">
            LV.{identity.staffLevel}
          </span>
        )}
      </div>
    );
  }

  return (
    <div className="relative overflow-hidden p-4 rounded-2xl border border-white/20 backdrop-blur-xl bg-white/10 shadow-2xl my-3 space-y-3">
      {/* Header Bar with Frosted Glass Pill Tag */}
      <div className="flex items-center justify-between gap-2 border-b border-white/10 pb-2.5">
        <div className="flex items-center gap-1.5 bg-white/15 px-2.5 py-1 rounded-full border border-white/25 shadow-sm text-[10px] font-black tracking-wider text-amber-300 uppercase">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>Staff Identity ({resolvedRoles.length} {resolvedRoles.length > 1 ? 'Positions' : 'Position'})</span>
        </div>

        <div className="flex items-center gap-1.5">
          {identity.isVerified && (
            <span className="inline-flex items-center gap-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] px-2 py-0.5 rounded-full font-bold shadow-sm backdrop-blur-md">
              <CheckCircle2 className="w-3 h-3 text-emerald-400 fill-emerald-400/20" /> Verified Badge
            </span>
          )}
          <div className="flex items-center gap-1 text-[10px] font-black px-2 py-0.5 rounded-full bg-black/40 border border-white/10 text-amber-300 font-mono shadow-inner">
            <Award className="w-3 h-3 text-amber-400" />
            <span>LV.{identity.staffLevel}</span>
          </div>
        </div>
      </div>

      {/* ALL ASSIGNED IDENTITIES / POSITIONS (SEPARATE BADGES & LABELS) */}
      <div className="bg-black/40 p-3 rounded-xl border border-white/10 backdrop-blur-md space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
            <Layers className="w-3 h-3 text-amber-400" /> Assigned Positions & Badges
          </span>
          <span className="text-[10px] text-amber-300/80 font-bold">
            {resolvedRoles.length} Active {resolvedRoles.length === 1 ? 'Identity' : 'Identities'}
          </span>
        </div>

        {/* Separate Badges Chips */}
        <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
          {resolvedRoles.map((item) => (
            <div
              key={item.role}
              className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-black tracking-wide shadow-md transition-all ${item.badgeStyle}`}
            >
              <span>{item.badge}</span>
            </div>
          ))}
        </div>

        {/* Multi-Position Breakdown List */}
        {resolvedRoles.length > 1 && (
          <div className="mt-2 pt-2 border-t border-white/10 grid grid-cols-1 sm:grid-cols-2 gap-1.5">
            {resolvedRoles.map((item) => (
              <div
                key={item.role}
                className="flex items-center justify-between p-1.5 px-2.5 rounded-lg bg-white/5 border border-white/5 text-[11px]"
              >
                <span className="font-bold text-white flex items-center gap-1">
                  <span>{item.badgeIcon}</span> {item.name}
                </span>
                <span className="text-[10px] text-slate-400 font-medium truncate max-w-[120px]">
                  {item.department}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Grid of Receiving Identity Visual Elements: Frame, Background, Department, Staff ID */}
      <div className="grid grid-cols-2 gap-2 text-[11px]">
        {/* Staff Frame */}
        <div className="bg-black/30 rounded-xl p-2.5 border border-white/10 backdrop-blur-md space-y-0.5">
          <span className="text-slate-400 font-medium flex items-center gap-1 text-[10px] uppercase font-bold text-cyan-300">
            <Frame className="w-3 h-3 text-cyan-400" /> Staff Frame
          </span>
          <p className="font-bold text-white text-xs truncate">{identity.frame || primaryConfig.frame}</p>
        </div>

        {/* Staff Background */}
        <div className="bg-black/30 rounded-xl p-2.5 border border-white/10 backdrop-blur-md space-y-0.5">
          <span className="text-slate-400 font-medium flex items-center gap-1 text-[10px] uppercase font-bold text-purple-300">
            <Layout className="w-3 h-3 text-purple-400" /> Staff Background
          </span>
          <p className="font-bold text-white text-xs truncate">{identity.background || primaryConfig.background}</p>
        </div>

        {/* Department */}
        <div className="bg-black/30 rounded-xl p-2.5 border border-white/10 backdrop-blur-md space-y-0.5">
          <span className="text-slate-400 font-medium flex items-center gap-1 text-[10px] uppercase font-bold text-emerald-300">
            <Building2 className="w-3 h-3 text-emerald-400" /> Primary Dept
          </span>
          <p className="font-bold text-slate-200 text-xs truncate">{identity.department || primaryConfig.department}</p>
        </div>

        {/* Staff ID */}
        <div className="bg-black/30 rounded-xl p-2.5 border border-white/10 backdrop-blur-md space-y-0.5">
          <span className="text-slate-400 font-medium flex items-center gap-1 text-[10px] uppercase font-bold text-amber-300">
            <ShieldCheck className="w-3 h-3 text-amber-400" /> Staff ID
          </span>
          <p className="font-mono font-bold text-white text-xs tracking-wider">{identity.staffId}</p>
        </div>
      </div>
    </div>
  );
};
