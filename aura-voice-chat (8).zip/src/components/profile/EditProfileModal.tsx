/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { 
  X, Camera, Upload, Check, AlertCircle, Sparkles, 
  ZoomIn, ZoomOut, RotateCw, Image as ImageIcon, Globe, User, RefreshCw, Hash, Lock, Copy
} from 'lucide-react';
import { User as UserType, Country } from '../../types';
import { ApiClient } from '../../lib/api';

interface EditProfileModalProps {
  user: UserType;
  isOpen: boolean;
  onClose: () => void;
  onProfileUpdated: (updatedUser: UserType) => void;
  showNotification: (msg: string) => void;
}

const PRESET_AVATARS = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
  'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80',
  'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=300&q=80'
];

const DEFAULT_FALLBACK_COUNTRIES = [
  { name: 'United States', flag: '🇺🇸', code: 'US' },
  { name: 'Bangladesh', flag: '🇧🇩', code: 'BD' },
  { name: 'Saudi Arabia', flag: '🇸🇦', code: 'SA' },
  { name: 'United Arab Emirates', flag: '🇦🇪', code: 'AE' },
  { name: 'United Kingdom', flag: '🇬🇧', code: 'GB' },
  { name: 'India', flag: '🇮🇳', code: 'IN' },
  { name: 'Pakistan', flag: '🇵🇰', code: 'PK' },
  { name: 'Canada', flag: '🇨🇦', code: 'CA' },
  { name: 'Germany', flag: '🇩🇪', code: 'DE' },
  { name: 'Japan', flag: '🇯🇵', code: 'JP' },
  { name: 'Global', flag: '🌐', code: 'GL' }
];

export const EditProfileModal: React.FC<EditProfileModalProps> = ({
  user,
  isOpen,
  onClose,
  onProfileUpdated,
  showNotification
}) => {
  const [name, setName] = useState(user.name || '');
  const [avatar, setAvatar] = useState(user.avatar || '');
  const [bio, setBio] = useState(user.bio || '');
  const [gender, setGender] = useState<'male' | 'female' | 'other'>(user.gender || 'female');
  const [country, setCountry] = useState(user.country || 'United States');
  const [countryFlag, setCountryFlag] = useState(user.countryFlag || '🇺🇸');
  const [availableCountries, setAvailableCountries] = useState<Array<{ name: string; flag: string; code?: string }>>(DEFAULT_FALLBACK_COUNTRIES);

  // Sync state whenever modal opens or user prop changes
  useEffect(() => {
    if (isOpen) {
      setName(user.name || '');
      setAvatar(user.avatar || '');
      setBio(user.bio || '');
      setGender(user.gender || 'female');
      setCountry(user.country || 'United States');
      setCountryFlag(user.countryFlag || '🇺🇸');
      setZoomLevel(1);
      setRotation(0);
      setFormError(null);
    }
  }, [isOpen, user]);

  // Fetch dynamic country list from database
  useEffect(() => {
    let isMounted = true;
    ApiClient.getCountries(true)
      .then((data) => {
        if (isMounted && Array.isArray(data) && data.length > 0) {
          setAvailableCountries(data.map(c => ({
            name: c.name,
            flag: c.flag || '🌐',
            code: c.iso2 || c.countryCode
          })));
        }
      })
      .catch(() => {
        // Keep fallback on error
      });
    return () => {
      isMounted = false;
    };
  }, []);

  // Cropping & Preview adjustment state
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [rotation, setRotation] = useState<number>(0);
  const [previewError, setPreviewError] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleCountryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selected = availableCountries.find(c => c.name === e.target.value);
    if (selected) {
      setCountry(selected.name);
      setCountryFlag(selected.flag);
    }
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFormError(null);
    setPreviewError(null);

    // Validate file type
    const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    if (!validTypes.includes(file.type)) {
      setFormError('Invalid file format. Please choose a JPG, PNG, or WEBP photo.');
      return;
    }

    // Validate file size (max 6MB)
    const MAX_SIZE = 6 * 1024 * 1024;
    if (file.size > MAX_SIZE) {
      setFormError(`Image size too large (${(file.size / (1024 * 1024)).toFixed(1)}MB). Limit is 6MB.`);
      return;
    }

    setIsUploading(true);

    try {
      // Convert to base64
      const reader = new FileReader();
      reader.onload = async (event) => {
        const base64Data = event.target?.result as string;
        if (!base64Data) {
          setFormError('Failed to read image file.');
          setIsUploading(false);
          return;
        }

        try {
          // Upload to server storage system
          const uploadRes = await ApiClient.uploadImage(
            base64Data,
            file.name,
            file.type,
            'avatar'
          );

          if (uploadRes && uploadRes.url) {
            setAvatar(uploadRes.url);
            setZoomLevel(1);
            setRotation(0);
            showNotification('Photo uploaded to storage!');
          } else {
            // Fallback to data URI if server upload response lacks URL
            setAvatar(base64Data);
          }
        } catch (err: any) {
          console.warn('Direct upload failed, using local base64 preview:', err);
          // Still permit base64 preview so user is not blocked
          setAvatar(base64Data);
        } finally {
          setIsUploading(false);
        }
      };

      reader.onerror = () => {
        setFormError('Error reading file from device.');
        setIsUploading(false);
      };

      reader.readAsDataURL(file);
    } catch (err: any) {
      setFormError(err.message || 'Failed to process image');
      setIsUploading(false);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    const trimmedName = name.trim();
    if (!trimmedName) {
      setFormError('Profile Name cannot be empty.');
      return;
    }

    if (trimmedName.length < 2) {
      setFormError('Profile Name must be at least 2 characters long.');
      return;
    }

    if (trimmedName.length > 50) {
      setFormError('Profile Name cannot exceed 50 characters.');
      return;
    }

    setIsSaving(true);

    try {
      const updateData = {
        name: trimmedName,
        avatar: avatar.trim(),
        bio: bio.trim(),
        gender,
        country,
        countryFlag
      };

      // 1. Save to Cloud Firestore (if authenticated with Firebase)
      try {
        const { auth, db } = await import('../../lib/firebase');
        if (auth.currentUser) {
          const { doc, setDoc } = await import('firebase/firestore');
          const targetId = user.firebaseUid || user.id || auth.currentUser.uid;
          const userDocRef = doc(db, 'users', targetId);
          await setDoc(userDocRef, { ...updateData, updatedAt: new Date().toISOString() }, { merge: true });
        }
      } catch (fsErr) {
        console.warn('Firestore update from EditProfileModal notice:', fsErr);
      }

      // 2. Save via API
      const updated = await ApiClient.updateProfile(updateData);

      const merged = { ...user, ...updateData, ...(updated || {}) };
      onProfileUpdated(merged);
      window.dispatchEvent(new CustomEvent('user_profile_updated', { detail: merged }));
      showNotification('Profile updated successfully! ✨');
      onClose();
    } catch (err: any) {
      setFormError(err.message || 'Failed to save profile changes. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-md bg-gradient-to-b from-slate-900 via-[#120726] to-[#0d041a] border border-white/15 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* MODAL HEADER */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-white/10 bg-white/5 backdrop-blur-md sticky top-0 z-20">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-400 to-purple-600 flex items-center justify-center text-black font-black shadow-md">
              <User className="w-4 h-4 text-white" />
            </div>
            <div>
              <h3 className="text-base font-black text-white">Edit User Profile</h3>
              <p className="text-[11px] text-slate-300">Change your Profile Name & Avatar</p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            disabled={isSaving || isUploading}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/15 text-slate-300 hover:text-white transition-colors disabled:opacity-50"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* MODAL BODY (SCROLLABLE) */}
        <form onSubmit={handleSave} className="p-4 sm:p-5 space-y-5 overflow-y-auto flex-1">
          {formError && (
            <div className="p-3 bg-red-500/15 border border-red-500/40 rounded-2xl flex items-start gap-2.5 text-red-300 text-xs animate-shake">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{formError}</span>
            </div>
          )}

          {/* 1. PROFILE PHOTO SECTION */}
          <div className="p-4 bg-white/5 rounded-2xl border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                <Camera className="w-4 h-4 text-amber-400" />
                Profile Photo (Avatar)
              </label>
              <span className="text-[10px] text-slate-400">JPG, PNG, WEBP &bull; Max 6MB</span>
            </div>

            {/* AVATAR PREVIEW WITH CROP / ZOOM CONTROLS */}
            <div className="flex flex-col sm:flex-row items-center gap-4">
              <div className="relative group">
                <div className="w-24 h-24 rounded-2xl overflow-hidden border-2 border-amber-400/80 shadow-xl bg-black relative flex items-center justify-center">
                  <img
                    src={avatar}
                    alt="Avatar Preview"
                    onError={() => setPreviewError('Image preview failed to load')}
                    className="w-full h-full object-cover transition-transform duration-200"
                    style={{
                      transform: `scale(${zoomLevel}) rotate(${rotation}deg)`
                    }}
                  />
                  {isUploading && (
                    <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center gap-1">
                      <RefreshCw className="w-5 h-5 text-amber-400 animate-spin" />
                      <span className="text-[9px] font-black text-amber-300">Uploading...</span>
                    </div>
                  )}
                </div>

                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isUploading || isSaving}
                  className="absolute -bottom-2 -right-2 p-2 bg-gradient-to-r from-amber-400 to-yellow-500 text-black rounded-xl shadow-lg hover:scale-110 active:scale-95 transition-transform"
                  title="Upload from device or camera"
                >
                  <Camera className="w-3.5 h-3.5 stroke-[2.5]" />
                </button>
              </div>

              {/* ACTION BUTTONS & ZOOM CONTROLS */}
              <div className="flex-1 w-full space-y-2.5">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  onChange={handleFileSelect}
                  className="hidden"
                />

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isUploading || isSaving}
                    className="flex-1 py-2 px-3 bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-black font-black text-xs rounded-xl shadow flex items-center justify-center gap-1.5 transition-all disabled:opacity-50"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>{isUploading ? 'Uploading...' : 'Change Photo'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setRotation(r => (r + 90) % 360)}
                    disabled={isUploading || isSaving}
                    className="p-2 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs transition-colors"
                    title="Rotate 90 degrees"
                  >
                    <RotateCw className="w-4 h-4" />
                  </button>
                </div>

                {/* ZOOM ADJUSTER SLIDER */}
                <div className="flex items-center gap-2 px-2 py-1 bg-black/40 rounded-xl border border-white/5">
                  <ZoomOut className="w-3 h-3 text-slate-400" />
                  <input
                    type="range"
                    min="0.8"
                    max="2.2"
                    step="0.1"
                    value={zoomLevel}
                    onChange={(e) => setZoomLevel(parseFloat(e.target.value))}
                    className="flex-1 accent-amber-400 h-1 bg-white/20 rounded-lg cursor-pointer"
                    title="Zoom in/out preview"
                  />
                  <ZoomIn className="w-3 h-3 text-slate-400" />
                  <span className="text-[10px] font-mono text-amber-300 w-8 text-right">
                    {Math.round(zoomLevel * 100)}%
                  </span>
                </div>
              </div>
            </div>

            {/* PRESET AVATARS QUICK PICKER */}
            <div className="space-y-1.5 pt-2 border-t border-white/5">
              <span className="text-[10px] text-slate-400 block font-medium">Or choose a quick preset avatar:</span>
              <div className="flex items-center gap-2 overflow-x-auto py-1">
                {PRESET_AVATARS.map((presetUrl, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setAvatar(presetUrl);
                      setZoomLevel(1);
                      setRotation(0);
                    }}
                    className={`w-9 h-9 rounded-xl overflow-hidden shrink-0 border-2 transition-all ${
                      avatar === presetUrl ? 'border-amber-400 scale-105 shadow-md' : 'border-white/10 opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img src={presetUrl} alt="Preset" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* 2. PROFILE NAME SECTION */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label htmlFor="profile-name-input" className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-amber-400" />
                Profile Name <span className="text-red-400">*</span>
              </label>
              <span className={`text-[10px] font-mono ${name.length > 40 ? 'text-amber-400' : 'text-slate-400'}`}>
                {name.length}/50 chars
              </span>
            </div>

            <input
              id="profile-name-input"
              type="text"
              required
              maxLength={50}
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter your public profile name..."
              className="w-full px-4 py-2.5 bg-black/50 border border-white/15 focus:border-amber-400 rounded-xl text-white text-sm outline-none transition-all placeholder:text-slate-500"
            />
            <p className="text-[11px] text-slate-400">
              This name will be displayed in Voice Rooms, chats, PK matches, and leaderboards.
            </p>
          </div>

          {/* 3. USER ID (UID / NIGO ID) SECTION - LOCKED / ADMIN ONLY */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label htmlFor="profile-uid-input" className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                <Hash className="w-3.5 h-3.5 text-amber-400" />
                <span>User ID (UID / Nigo ID)</span>
              </label>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-500/15 border border-amber-500/30 text-[10px] font-bold text-amber-300">
                <Lock className="w-2.5 h-2.5 text-amber-400" />
                <span>Admin Only</span>
              </span>
            </div>

            <div className="relative flex items-center">
              <input
                id="profile-uid-input"
                type="text"
                readOnly
                disabled
                value={user.uid || user.nigoId || user.id}
                className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-slate-300 font-mono text-sm cursor-not-allowed select-all outline-none"
              />
              <div className="absolute right-2.5 flex items-center gap-1.5 text-slate-400 text-xs">
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard.writeText(user.uid || user.nigoId || user.id);
                    showNotification('User ID copied to clipboard! 📋');
                  }}
                  className="px-2 py-1 rounded-md bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white text-[10px] font-bold transition flex items-center gap-1 cursor-pointer"
                  title="Copy User ID"
                >
                  <Copy className="w-2.5 h-2.5" />
                  <span>Copy</span>
                </button>
                <Lock className="w-3.5 h-3.5 text-amber-400/80" />
              </div>
            </div>
            
            <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/25 flex items-start gap-2 mt-1">
              <Lock className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
              <p className="text-[11px] text-amber-200/90 leading-relaxed">
                User ID cannot be changed from the application. The user ID can only be changed from the <b className="text-amber-300">Admin Dashboard</b>.
              </p>
            </div>
          </div>

          {/* 3. BIO / STATUS STATEMENT */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label htmlFor="bio-input" className="text-xs font-bold text-slate-200">
                Bio &amp; Status
              </label>
              <span className="text-[10px] font-mono text-slate-400">{bio.length}/300</span>
            </div>
            <textarea
              id="bio-input"
              rows={2}
              maxLength={300}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Tell others about yourself or your vibe..."
              className="w-full px-4 py-2 bg-black/50 border border-white/15 focus:border-amber-400 rounded-xl text-white text-xs outline-none transition-all resize-none placeholder:text-slate-500"
            />
          </div>

          {/* 4. GENDER & COUNTRY SELECTION */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-200 block">Gender</label>
              <div className="grid grid-cols-3 gap-1 bg-black/50 p-1 rounded-xl border border-white/10">
                {(['female', 'male', 'other'] as const).map((g) => (
                  <button
                    key={g}
                    type="button"
                    onClick={() => setGender(g)}
                    className={`py-1.5 text-[11px] font-bold rounded-lg capitalize transition-colors ${
                      gender === g 
                        ? 'bg-amber-400 text-black font-black shadow' 
                        : 'text-slate-300 hover:text-white'
                    }`}
                  >
                    {g === 'female' ? '♀ Fem' : g === 'male' ? '♂ Male' : '⚲ Oth'}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-200 block">Region / Flag</label>
              <div className="relative">
                <select
                  value={country}
                  onChange={handleCountryChange}
                  className="w-full px-3 py-2 bg-black/50 border border-white/15 focus:border-amber-400 rounded-xl text-white text-xs outline-none appearance-none font-medium cursor-pointer"
                >
                  {availableCountries.map((c) => (
                    <option key={c.name} value={c.name} className="bg-slate-900 text-white">
                      {c.flag} {c.name}
                    </option>
                  ))}
                </select>
                <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-xs">
                  {countryFlag}
                </div>
              </div>
            </div>
          </div>

          {/* 5. PROTECTED FIELDS NOTICE */}
          <div className="p-3 bg-amber-500/10 border border-amber-400/20 rounded-2xl text-[11px] text-amber-200/90 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
            <span>
              Your UID (<strong>{user.uid}</strong>), role, coins, and levels are preserved and protected by server security rules.
            </span>
          </div>

          {/* MODAL ACTIONS FOOTER */}
          <div className="flex items-center gap-2.5 pt-2 border-t border-white/10 sticky bottom-0 bg-[#0d041a]/95 backdrop-blur-md py-2 z-10">
            <button
              type="button"
              onClick={onClose}
              disabled={isSaving || isUploading}
              className="flex-1 py-3 px-4 bg-white/10 hover:bg-white/15 text-slate-300 font-bold text-xs rounded-2xl transition-colors disabled:opacity-50"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={isSaving || isUploading || !name.trim()}
              className="flex-[2] py-3 px-4 bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-500 hover:from-amber-300 hover:to-yellow-400 text-black font-black text-xs rounded-2xl shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSaving ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-black" />
                  <span>Saving Changes...</span>
                </>
              ) : (
                <>
                  <Check className="w-4 h-4 stroke-[3]" />
                  <span>Save Profile</span>
                </>
              )}
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
