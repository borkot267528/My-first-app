import React, { useState } from 'react';
import { Terminal, Key, Webhook, FileText, CheckCircle2, Shield, RefreshCw } from 'lucide-react';

interface OpenApiCenterProps {
  showNotification: (msg: string) => void;
}

export const OpenApiCenter: React.FC<OpenApiCenterProps> = ({ showNotification }) => {
  const [activeTab, setActiveTab] = useState<'docs' | 'keys' | 'webhooks' | 'logs'>('docs');

  const apiKeys = [
    { id: 'key-01', name: 'Production Mobile App Key', key: 'aura_live_sk_89283741928374', status: 'active', createdAt: '2025-01-10' },
    { id: 'key-02', name: 'Third-Party Merchant Integration', key: 'aura_live_sk_91823719283719', status: 'active', createdAt: '2025-02-15' }
  ];

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* HEADER BAR */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
        <div>
          <h3 className="text-base font-black text-white flex items-center gap-2">
            <Terminal className="w-5 h-5 text-amber-400" /> OpenAPI 3.0 & REST Ecosystem Center
          </h3>
          <p className="text-xs text-slate-300">Swagger API Documentation, Webhooks, API Client Keys & Realtime Endpoints</p>
        </div>
        <a
          href="/api/docs"
          target="_blank"
          rel="noopener noreferrer"
          className="px-3.5 py-1.5 bg-amber-400 text-black font-black text-xs rounded-xl shadow flex items-center gap-1.5 hover:bg-amber-300"
        >
          <Terminal className="w-3.5 h-3.5" /> Launch Swagger UI
        </a>
      </div>

      {/* TABS */}
      <div className="flex gap-2 border-b border-white/10 pb-2 text-xs">
        {[
          { id: 'docs', label: 'API Specs & Endpoints' },
          { id: 'keys', label: 'API Keys' },
          { id: 'webhooks', label: 'Webhooks' },
          { id: 'logs', label: 'API Request Logs' }
        ].map(t => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id as any)}
            className={`px-3.5 py-1.5 rounded-xl font-bold transition-all ${
              activeTab === t.id ? 'bg-amber-400 text-black font-black shadow-md' : 'bg-white/5 text-slate-300 hover:bg-white/10'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {activeTab === 'docs' && (
        <div className="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-4">
          <h4 className="font-extrabold text-white text-sm">Core Platform API Endpoints (v1 / v2 REST)</h4>
          <div className="space-y-2 text-xs font-mono">
            <div className="p-3 rounded-xl bg-black/40 border border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">GET</span>
                <span className="text-white font-bold">/api/admin/stats</span>
              </div>
              <span className="text-slate-400">Returns platform overview analytics</span>
            </div>
            <div className="p-3 rounded-xl bg-black/40 border border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 font-bold">POST</span>
                <span className="text-white font-bold">/api/admin/users/:id/update</span>
              </div>
              <span className="text-slate-400">Updates user account profile & roles</span>
            </div>
            <div className="p-3 rounded-xl bg-black/40 border border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">GET</span>
                <span className="text-white font-bold">/api/rooms</span>
              </div>
              <span className="text-slate-400">Returns list of active voice channels</span>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'keys' && (
        <div className="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-4">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <h4 className="font-extrabold text-white text-sm">Active Administrative API Keys</h4>
            <button
              onClick={() => showNotification('Generated new API Key')}
              className="px-3 py-1.5 bg-amber-400 text-black font-black text-xs rounded-xl"
            >
              Generate Key
            </button>
          </div>
          <div className="space-y-2">
            {apiKeys.map(k => (
              <div key={k.id} className="p-3.5 rounded-xl bg-black/40 border border-white/10 flex items-center justify-between text-xs">
                <div>
                  <p className="font-bold text-white">{k.name}</p>
                  <p className="font-mono text-slate-400">{k.key}</p>
                </div>
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold uppercase text-[10px]">
                  {k.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
