/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Heart, Users, UserCheck, ShieldAlert, Sparkles, Sliders, RefreshCw, 
  Search, Filter, PlusCircle, Trash2, Edit3, Shield, Award, AlertTriangle, 
  CheckCircle2, X, Ban, Gift, ArrowRight, ExternalLink, Flame, Crown, 
  MessageSquare, Clock, ShieldCheck, HeartHandshake, Zap, Info, ChevronDown
} from 'lucide-react';
import { 
  Connection, 
  ConnectionRequest, 
  BlockedUserRecord, 
  User, 
  AdminConnectionOverview, 
  ConnectionSystemConfig 
} from '../../../types';
import { ApiClient } from '../../../lib/api';

interface ConnectionsManagementCenterProps {
  currentUser?: User | null;
  showNotification: (msg: string) => void;
}

const CP_LEVEL_NAMES: Record<number, { name: string; color: string; border: string; bg: string }> = {
  1: { name: 'Kindred Hearts', color: 'text-rose-300', border: 'border-rose-400/40', bg: 'bg-rose-500/10' },
  2: { name: 'Sweet Romance', color: 'text-pink-300', border: 'border-pink-400/40', bg: 'bg-pink-500/10' },
  3: { name: 'Soulmates', color: 'text-purple-300', border: 'border-purple-400/40', bg: 'bg-purple-500/10' },
  4: { name: 'Eternal Flame', color: 'text-amber-300', border: 'border-amber-400/40', bg: 'bg-amber-500/10' },
  5: { name: 'Mythic Dynasty', color: 'text-yellow-300', border: 'border-yellow-400/40', bg: 'bg-yellow-500/10' }
};

export const ConnectionsManagementCenter: React.FC<ConnectionsManagementCenterProps> = ({
  currentUser,
  showNotification
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'cp_bonds' | 'friendships' | 'requests' | 'blocked' | 'config'>('cp_bonds');
  const [loading, setLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);

  // Core Data
  const [overview, setOverview] = useState<AdminConnectionOverview | null>(null);
  const [connections, setConnections] = useState<Connection[]>([]);
  const [requests, setRequests] = useState<ConnectionRequest[]>([]);
  const [blockedUsers, setBlockedUsers] = useState<BlockedUserRecord[]>([]);
  const [systemConfig, setSystemConfig] = useState<ConnectionSystemConfig | null>(null);
  const [allUsers, setAllUsers] = useState<User[]>([]);

  // Filters for Connections
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'terminated'>('all');
  const [minLevelFilter, setMinLevelFilter] = useState<number>(0);
  const [sortBy, setSortBy] = useState<'newest' | 'oldest' | 'intimacy' | 'coins'>('newest');

  // Filters for Requests
  const [reqSearchQuery, setReqSearchQuery] = useState('');
  const [reqTypeFilter, setReqTypeFilter] = useState<'all' | 'cp' | 'friend'>('all');
  const [reqStatusFilter, setReqStatusFilter] = useState<'all' | 'pending' | 'accepted' | 'declined' | 'cancelled'>('all');

  // Filters for Blocked
  const [blockedSearchQuery, setBlockedSearchQuery] = useState('');

  // Modals
  const [showCreateCpModal, setShowCreateCpModal] = useState<boolean>(false);
  const [showCreateFriendModal, setShowCreateFriendModal] = useState<boolean>(false);
  const [editingIntimacyConn, setEditingIntimacyConn] = useState<Connection | null>(null);
  const [terminatingConn, setTerminatingConn] = useState<Connection | null>(null);
  const [unblockingRecord, setUnblockingRecord] = useState<BlockedUserRecord | null>(null);

  // Forms
  const [cpForm, setCpForm] = useState({
    user1Id: '',
    user2Id: '',
    intimacyPoints: 100,
    level: 1,
    ceremonyNote: '',
    forceOverride: false
  });

  const [friendForm, setFriendForm] = useState({
    user1Id: '',
    user2Id: '',
    note: ''
  });

  const [intimacyForm, setIntimacyForm] = useState({
    intimacyPoints: 0,
    level: 1,
    sharedGiftsCoins: 0,
    reason: 'Executive Intimacy Adjustment'
  });

  const [terminationReason, setTerminationReason] = useState<string>('Terminated by Platform Administration');
  const [unblockReason, setUnblockReason] = useState<string>('Administrative safety resolution');

  // Config Form
  const [configForm, setConfigForm] = useState<ConnectionSystemConfig>({
    minUserLevelForCp: 1,
    initialIntimacyPoints: 100,
    giftIntimacyPercent: 10,
    giftIntimacyBasePerGift: 10,
    maxFriendsLimit: 500,
    autoApproveVipCp: false,
    allowSameGenderCp: true,
    updatedAt: '',
    updatedBy: ''
  });
  const [savingConfig, setSavingConfig] = useState<boolean>(false);

  // Load all initial data
  const loadData = async (isSilent = false) => {
    if (!isSilent) setLoading(true);
    setRefreshing(true);
    try {
      const [ovData, connsData, reqsData, blkData, cfgData, usersData] = await Promise.all([
        ApiClient.getAdminConnectionsOverview().catch(() => null),
        ApiClient.getAdminConnections({
          type: activeSubTab === 'cp_bonds' ? 'cp' : activeSubTab === 'friendships' ? 'friend' : undefined,
          status: statusFilter !== 'all' ? statusFilter : undefined,
          search: searchQuery,
          minLevel: minLevelFilter > 0 ? minLevelFilter : undefined,
          sortBy
        }).catch(() => []),
        ApiClient.getAdminConnectionRequests({
          type: reqTypeFilter !== 'all' ? reqTypeFilter : undefined,
          status: reqStatusFilter !== 'all' ? reqStatusFilter : undefined,
          search: reqSearchQuery
        }).catch(() => []),
        ApiClient.getAdminBlockedRelations(blockedSearchQuery).catch(() => []),
        ApiClient.getAdminConnectionConfig().catch(() => null),
        ApiClient.getUsers().catch(() => [])
      ]);

      if (ovData) setOverview(ovData);
      setConnections(connsData || []);
      setRequests(reqsData || []);
      setBlockedUsers(blkData || []);
      if (cfgData) {
        setSystemConfig(cfgData);
        setConfigForm(cfgData);
      }
      setAllUsers(usersData || []);
    } catch (err: any) {
      console.error('Failed to load connection administration data:', err);
      showNotification('Failed to refresh social connections: ' + (err.message || 'Unknown error'));
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [activeSubTab, statusFilter, minLevelFilter, sortBy]);

  // Handle Form Submit: Force Create CP
  const handleCreateCpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!cpForm.user1Id || !cpForm.user2Id) {
      showNotification('Please select both partners for the CP bond');
      return;
    }
    if (cpForm.user1Id === cpForm.user2Id) {
      showNotification('Partners must be two distinct users');
      return;
    }

    try {
      await ApiClient.adminCreateCP({
        user1Id: cpForm.user1Id,
        user2Id: cpForm.user2Id,
        intimacyPoints: Number(cpForm.intimacyPoints),
        level: Number(cpForm.level),
        ceremonyNote: cpForm.ceremonyNote.trim() || undefined,
        forceOverride: cpForm.forceOverride
      });
      showNotification('🎉 CP couple bond established successfully!');
      setShowCreateCpModal(false);
      setCpForm({
        user1Id: '',
        user2Id: '',
        intimacyPoints: 100,
        level: 1,
        ceremonyNote: '',
        forceOverride: false
      });
      loadData(true);
    } catch (err: any) {
      showNotification('Failed to create CP bond: ' + err.message);
    }
  };

  // Handle Form Submit: Adjust Intimacy
  const handleAdjustIntimacySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingIntimacyConn) return;

    try {
      await ApiClient.adminAdjustIntimacy(editingIntimacyConn.id, {
        intimacyPoints: Number(intimacyForm.intimacyPoints),
        level: Number(intimacyForm.level),
        sharedGiftsCoins: Number(intimacyForm.sharedGiftsCoins),
        reason: intimacyForm.reason.trim() || 'Executive adjustment'
      });
      showNotification(`✨ Intimacy for ${editingIntimacyConn.id} adjusted successfully!`);
      setEditingIntimacyConn(null);
      loadData(true);
    } catch (err: any) {
      showNotification('Failed to adjust intimacy: ' + err.message);
    }
  };

  // Handle Terminate Connection
  const handleTerminateSubmit = async () => {
    if (!terminatingConn) return;
    try {
      await ApiClient.adminTerminateConnection(terminatingConn.id, {
        reason: terminationReason.trim() || 'Terminated by Platform Administration'
      });
      showNotification(`🔔 Connection ${terminatingConn.id} dissolved successfully!`);
      setTerminatingConn(null);
      loadData(true);
    } catch (err: any) {
      showNotification('Failed to dissolve connection: ' + err.message);
    }
  };

  // Handle Create Friendship Submit
  const handleCreateFriendSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!friendForm.user1Id || !friendForm.user2Id) {
      showNotification('Please select both users');
      return;
    }
    if (friendForm.user1Id === friendForm.user2Id) {
      showNotification('Users must be distinct');
      return;
    }

    try {
      await ApiClient.adminCreateFriendship({
        user1Id: friendForm.user1Id,
        user2Id: friendForm.user2Id,
        note: friendForm.note.trim() || undefined
      });
      showNotification('👥 Friendship established successfully!');
      setShowCreateFriendModal(false);
      setFriendForm({ user1Id: '', user2Id: '', note: '' });
      loadData(true);
    } catch (err: any) {
      showNotification('Failed to create friendship: ' + err.message);
    }
  };

  // Handle Purge Request
  const handlePurgeRequest = async (requestId: string) => {
    if (!window.confirm('Are you sure you want to purge/cancel this connection request?')) return;
    try {
      await ApiClient.adminPurgeConnectionRequest(requestId);
      showNotification('🗑️ Connection request purged successfully');
      loadData(true);
    } catch (err: any) {
      showNotification('Failed to purge request: ' + err.message);
    }
  };

  // Handle Unblock User Pair
  const handleUnblockSubmit = async () => {
    if (!unblockingRecord) return;
    try {
      await ApiClient.adminUnblockRelation({
        userId: unblockingRecord.userId,
        blockedUserId: unblockingRecord.blockedUserId,
        reason: unblockReason.trim()
      });
      showNotification('🔓 Block relationship removed successfully');
      setUnblockingRecord(null);
      loadData(true);
    } catch (err: any) {
      showNotification('Failed to unblock user: ' + err.message);
    }
  };

  // Handle Save Social Config
  const handleSaveConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingConfig(true);
    try {
      const updated = await ApiClient.updateAdminConnectionConfig({
        minUserLevelForCp: Number(configForm.minUserLevelForCp),
        initialIntimacyPoints: Number(configForm.initialIntimacyPoints),
        giftIntimacyPercent: Number(configForm.giftIntimacyPercent),
        giftIntimacyBasePerGift: Number(configForm.giftIntimacyBasePerGift),
        maxFriendsLimit: Number(configForm.maxFriendsLimit),
        autoApproveVipCp: Boolean(configForm.autoApproveVipCp),
        allowSameGenderCp: Boolean(configForm.allowSameGenderCp)
      });
      setSystemConfig(updated);
      setConfigForm(updated);
      showNotification('⚙️ CP & Friendship platform rules updated successfully!');
    } catch (err: any) {
      showNotification('Failed to update config: ' + err.message);
    } finally {
      setSavingConfig(false);
    }
  };

  // Filtered connections for active tab
  const filteredConnections = connections.filter(conn => {
    if (activeSubTab === 'cp_bonds' && conn.type !== 'cp') return false;
    if (activeSubTab === 'friendships' && conn.type !== 'friend') return false;
    return true;
  });

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* 1. TOP HEADER & REFRESH */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-white/5 border border-white/10 p-5 rounded-3xl backdrop-blur-xl shadow-xl">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-pink-500 to-rose-600 flex items-center justify-center text-white shadow-lg shadow-pink-500/20">
            <Heart className="w-6 h-6 fill-white text-white" />
          </div>
          <div>
            <h1 className="text-xl font-black text-white flex items-center gap-2">
              CP (Couple) & Friendship Administration
              <span className="text-[10px] font-mono uppercase px-2.5 py-0.5 rounded-full bg-pink-500/20 text-pink-300 border border-pink-500/30">
                Official Suite
              </span>
            </h1>
            <p className="text-xs text-slate-300">
              Oversee romantic CP bonds, friendship networks, request moderation, and platform intimacy rules.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          {activeSubTab === 'cp_bonds' && (
            <button
              onClick={() => setShowCreateCpModal(true)}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-500 hover:to-rose-500 text-white font-black text-xs flex items-center gap-2 shadow-lg shadow-pink-500/25 border border-pink-400/40 transition-all hover:scale-[1.02]"
            >
              <PlusCircle className="w-4 h-4" /> Force Create CP Bond
            </button>
          )}

          {activeSubTab === 'friendships' && (
            <button
              onClick={() => setShowCreateFriendModal(true)}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-black text-xs flex items-center gap-2 shadow-lg shadow-blue-500/25 border border-blue-400/40 transition-all hover:scale-[1.02]"
            >
              <Users className="w-4 h-4" /> Establish Friendship
            </button>
          )}

          <button
            onClick={() => loadData(false)}
            disabled={refreshing}
            className="p-2.5 rounded-xl bg-white/10 hover:bg-white/20 border border-white/10 text-white transition-colors flex items-center gap-2 text-xs font-semibold"
            title="Refresh Social Data"
          >
            <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">Refresh</span>
          </button>
        </div>
      </div>

      {/* 2. EXECUTIVE METRICS CARDS */}
      {overview && (
        <div className="space-y-3">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5">
            <div className="p-4 rounded-2xl bg-gradient-to-br from-pink-900/30 to-rose-900/20 border border-pink-500/30 space-y-1 shadow-md">
              <span className="text-[10px] text-pink-300 font-bold block truncate flex items-center gap-1.5">
                <Heart className="w-3.5 h-3.5 fill-pink-400 text-pink-400" /> Active CP Couples
              </span>
              <p className="text-2xl font-black text-pink-400">{overview.totalActiveCp.toLocaleString()}</p>
              <span className="text-[9px] text-slate-400">{overview.totalTerminatedCp} dissolved</span>
            </div>

            <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-900/30 to-indigo-900/20 border border-blue-500/30 space-y-1 shadow-md">
              <span className="text-[10px] text-blue-300 font-bold block truncate flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-blue-400" /> Active Friendships
              </span>
              <p className="text-2xl font-black text-blue-400">{overview.totalActiveFriends.toLocaleString()}</p>
              <span className="text-[9px] text-slate-400">{overview.totalTerminatedFriends} ended</span>
            </div>

            <div className="p-4 rounded-2xl bg-gradient-to-br from-amber-900/30 to-yellow-900/20 border border-amber-500/30 space-y-1 shadow-md">
              <span className="text-[10px] text-amber-300 font-bold block truncate flex items-center gap-1.5">
                <Flame className="w-3.5 h-3.5 text-amber-400" /> Total Intimacy Points
              </span>
              <p className="text-2xl font-black text-amber-400">{overview.totalIntimacyPoints.toLocaleString()}</p>
              <span className="text-[9px] text-amber-200/80">Avg {overview.averageIntimacy} pts/couple</span>
            </div>

            <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-900/30 to-teal-900/20 border border-emerald-500/30 space-y-1 shadow-md">
              <span className="text-[10px] text-emerald-300 font-bold block truncate flex items-center gap-1.5">
                <Gift className="w-3.5 h-3.5 text-emerald-400" /> CP Shared Gifts (Coins)
              </span>
              <p className="text-2xl font-black text-emerald-400">🪙 {overview.totalSharedCoins.toLocaleString()}</p>
              <span className="text-[9px] text-emerald-200/80">Intimacy Drivers</span>
            </div>

            <div className="p-4 rounded-2xl bg-gradient-to-br from-purple-900/30 to-violet-900/20 border border-purple-500/30 space-y-1 shadow-md">
              <span className="text-[10px] text-purple-300 font-bold block truncate flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-purple-400" /> Pending Requests
              </span>
              <p className="text-2xl font-black text-purple-300">{overview.totalPendingRequests.toLocaleString()}</p>
              <span className="text-[9px] text-slate-400">{overview.totalAcceptedRequests} accepted</span>
            </div>

            <div className="p-4 rounded-2xl bg-gradient-to-br from-rose-900/30 to-red-900/20 border border-rose-500/30 space-y-1 shadow-md">
              <span className="text-[10px] text-rose-300 font-bold block truncate flex items-center gap-1.5">
                <Ban className="w-3.5 h-3.5 text-rose-400" /> Blocked Relationships
              </span>
              <p className="text-2xl font-black text-rose-400">{blockedUsers.length.toLocaleString()}</p>
              <span className="text-[9px] text-slate-400">Safety & Moderation</span>
            </div>
          </div>

          {/* Level Distribution Pills */}
          <div className="flex flex-wrap items-center gap-2 p-3 bg-white/5 border border-white/10 rounded-2xl">
            <span className="text-xs font-bold text-slate-300 flex items-center gap-1 mr-2">
              <Award className="w-3.5 h-3.5 text-amber-400" /> CP Level Distribution:
            </span>
            {[1, 2, 3, 4, 5].map(lvl => {
              const info = CP_LEVEL_NAMES[lvl];
              const count = overview.levelDistribution?.[lvl] || 0;
              return (
                <div 
                  key={lvl} 
                  className={`px-3 py-1 rounded-xl text-xs font-bold flex items-center gap-1.5 border ${info.border} ${info.bg} ${info.color}`}
                >
                  <span>Lv.{lvl} {info.name}:</span>
                  <span className="font-mono font-black">{count}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 3. SUB-NAVIGATION TABS */}
      <div className="flex flex-wrap gap-2 border-b border-white/10 pb-3">
        <button
          onClick={() => setActiveSubTab('cp_bonds')}
          className={`px-4 py-2.5 rounded-2xl font-black text-xs flex items-center gap-2 transition-all ${
            activeSubTab === 'cp_bonds'
              ? 'bg-pink-600 text-white shadow-lg shadow-pink-600/30 border border-pink-400/50'
              : 'bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10'
          }`}
        >
          <Heart className="w-4 h-4 fill-current" /> CP Couple Bonds ({overview?.totalActiveCp || 0})
        </button>

        <button
          onClick={() => setActiveSubTab('friendships')}
          className={`px-4 py-2.5 rounded-2xl font-black text-xs flex items-center gap-2 transition-all ${
            activeSubTab === 'friendships'
              ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30 border border-blue-400/50'
              : 'bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10'
          }`}
        >
          <Users className="w-4 h-4" /> Friendship Network ({overview?.totalActiveFriends || 0})
        </button>

        <button
          onClick={() => setActiveSubTab('requests')}
          className={`px-4 py-2.5 rounded-2xl font-black text-xs flex items-center gap-2 transition-all ${
            activeSubTab === 'requests'
              ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/30 border border-purple-400/50'
              : 'bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10'
          }`}
        >
          <MessageSquare className="w-4 h-4" /> Request Moderation ({overview?.totalPendingRequests || 0} Pending)
        </button>

        <button
          onClick={() => setActiveSubTab('blocked')}
          className={`px-4 py-2.5 rounded-2xl font-black text-xs flex items-center gap-2 transition-all ${
            activeSubTab === 'blocked'
              ? 'bg-rose-600 text-white shadow-lg shadow-rose-600/30 border border-rose-400/50'
              : 'bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10'
          }`}
        >
          <Ban className="w-4 h-4" /> Blocked Relationships ({blockedUsers.length})
        </button>

        <button
          onClick={() => setActiveSubTab('config')}
          className={`px-4 py-2.5 rounded-2xl font-black text-xs flex items-center gap-2 transition-all ${
            activeSubTab === 'config'
              ? 'bg-amber-600 text-white shadow-lg shadow-amber-600/30 border border-amber-400/50'
              : 'bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10'
          }`}
        >
          <Sliders className="w-4 h-4" /> Social Rules & Configuration
        </button>
      </div>

      {/* 4. CONTENT SECTIONS */}
      {/* ====================================================
          TAB 1: CP COUPLE BONDS & TAB 2: FRIENDSHIPS
         ==================================================== */}
      {(activeSubTab === 'cp_bonds' || activeSubTab === 'friendships') && (
        <div className="space-y-4">
          {/* Controls Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 bg-white/5 p-4 rounded-2xl border border-white/10">
            {/* Search Input */}
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && loadData(false)}
                placeholder="Search by User Name, UID, ID..."
                className="w-full pl-10 pr-4 py-2 rounded-xl bg-black/40 border border-white/10 text-white placeholder-slate-400 text-xs focus:outline-none focus:border-pink-500"
              />
            </div>

            {/* Status Filter */}
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-300 font-bold shrink-0">Status:</span>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as any)}
                className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:outline-none focus:border-pink-500"
              >
                <option value="all">All Statuses</option>
                <option value="active">Active Only</option>
                <option value="terminated">Terminated Only</option>
              </select>
            </div>

            {/* Min Level Filter (For CP) */}
            {activeSubTab === 'cp_bonds' && (
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-300 font-bold shrink-0">Min Level:</span>
                <select
                  value={minLevelFilter}
                  onChange={(e) => setMinLevelFilter(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:outline-none focus:border-pink-500"
                >
                  <option value="0">All Levels (Lv.1 - 5)</option>
                  <option value="2">Level 2+ (Sweet Romance)</option>
                  <option value="3">Level 3+ (Soulmates)</option>
                  <option value="4">Level 4+ (Eternal Flame)</option>
                  <option value="5">Level 5 (Mythic Dynasty)</option>
                </select>
              </div>
            )}

            {/* Sort Order */}
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-300 font-bold shrink-0">Sort By:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:outline-none focus:border-pink-500"
              >
                <option value="newest">Newest Established</option>
                <option value="oldest">Oldest Established</option>
                <option value="intimacy">Highest Intimacy</option>
                <option value="coins">Most Gift Coins</option>
              </select>
            </div>
          </div>

          {/* Table of Connections */}
          {loading ? (
            <div className="p-12 text-center text-slate-400 bg-white/5 rounded-3xl border border-white/10">
              <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-3 text-pink-400" />
              <p className="text-sm font-semibold">Loading connections from database...</p>
            </div>
          ) : filteredConnections.length === 0 ? (
            <div className="p-12 text-center text-slate-400 bg-white/5 rounded-3xl border border-white/10 space-y-3">
              <Heart className="w-10 h-10 text-slate-500 mx-auto" />
              <p className="text-sm font-semibold text-white">No {activeSubTab === 'cp_bonds' ? 'CP couple' : 'friendship'} records match your criteria.</p>
              <p className="text-xs text-slate-400">Try adjusting your search keywords or filter settings.</p>
            </div>
          ) : (
            <div className="overflow-x-auto rounded-3xl border border-white/10 bg-white/5 backdrop-blur-xl shadow-xl">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-white/10 bg-white/5 text-slate-300 uppercase tracking-wider font-extrabold text-[10px]">
                    <th className="p-4">Connection Details</th>
                    <th className="p-4">Partner 1</th>
                    <th className="p-4">Partner 2</th>
                    {activeSubTab === 'cp_bonds' && <th className="p-4">Level & Intimacy</th>}
                    {activeSubTab === 'cp_bonds' && <th className="p-4">Gifts & Coins</th>}
                    <th className="p-4">Established Date</th>
                    <th className="p-4">Status</th>
                    <th className="p-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {filteredConnections.map((conn) => {
                    const u1 = conn.user1 || allUsers.find(u => u.id === conn.user1Id);
                    const u2 = conn.user2 || allUsers.find(u => u.id === conn.user2Id);
                    const lvlInfo = CP_LEVEL_NAMES[conn.level || 1] || CP_LEVEL_NAMES[1];

                    return (
                      <tr key={conn.id} className="hover:bg-white/5 transition-colors">
                        {/* Connection ID & Type */}
                        <td className="p-4">
                          <div className="space-y-1">
                            <span className="font-mono text-[11px] text-pink-300 font-bold block">
                              #{conn.id}
                            </span>
                            <span className="text-[10px] text-slate-400 uppercase font-semibold flex items-center gap-1">
                              {conn.type === 'cp' ? (
                                <>
                                  <Heart className="w-3 h-3 fill-pink-400 text-pink-400" /> Romantic CP
                                </>
                              ) : (
                                <>
                                  <Users className="w-3 h-3 text-blue-400" /> Friendship
                                </>
                              )}
                            </span>
                          </div>
                        </td>

                        {/* Partner 1 */}
                        <td className="p-4">
                          <div className="flex items-center gap-2.5">
                            <img
                              src={u1?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80'}
                              alt={u1?.name || 'User 1'}
                              className="w-9 h-9 rounded-full object-cover border border-white/20 shrink-0"
                            />
                            <div className="overflow-hidden">
                              <p className="font-bold text-white truncate max-w-[130px]">{u1?.name || conn.user1Id}</p>
                              <span className="text-[10px] text-slate-400 font-mono">UID: {u1?.uid || '—'}</span>
                            </div>
                          </div>
                        </td>

                        {/* Partner 2 */}
                        <td className="p-4">
                          <div className="flex items-center gap-2.5">
                            <img
                              src={u2?.avatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=100&q=80'}
                              alt={u2?.name || 'User 2'}
                              className="w-9 h-9 rounded-full object-cover border border-white/20 shrink-0"
                            />
                            <div className="overflow-hidden">
                              <p className="font-bold text-white truncate max-w-[130px]">{u2?.name || conn.user2Id}</p>
                              <span className="text-[10px] text-slate-400 font-mono">UID: {u2?.uid || '—'}</span>
                            </div>
                          </div>
                        </td>

                        {/* Level & Intimacy (CP only) */}
                        {activeSubTab === 'cp_bonds' && (
                          <td className="p-4">
                            <div className="space-y-1">
                              <span className={`px-2 py-0.5 rounded-full text-[10px] font-black border ${lvlInfo.border} ${lvlInfo.bg} ${lvlInfo.color} inline-flex items-center gap-1`}>
                                <Crown className="w-3 h-3" /> Lv.{conn.level || 1} {lvlInfo.name}
                              </span>
                              <div className="flex items-center gap-1.5 font-mono text-amber-300 text-xs font-bold">
                                <Flame className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                                <span>{(conn.intimacyPoints || 0).toLocaleString()} pts</span>
                              </div>
                            </div>
                          </td>
                        )}

                        {/* Shared Gifts & Coins (CP only) */}
                        {activeSubTab === 'cp_bonds' && (
                          <td className="p-4">
                            <div className="space-y-0.5 text-xs font-mono">
                              <p className="text-emerald-400 font-bold">🪙 {(conn.sharedGiftsCoins || 0).toLocaleString()} coins</p>
                              <p className="text-slate-400 text-[10px]">🎁 {conn.sharedGiftsCount || 0} gifts sent</p>
                            </div>
                          </td>
                        )}

                        {/* Established At */}
                        <td className="p-4 text-slate-300 font-mono text-[11px]">
                          {new Date(conn.establishedAt).toLocaleDateString()}
                          <span className="block text-[10px] text-slate-400">
                            {new Date(conn.establishedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </td>

                        {/* Status */}
                        <td className="p-4">
                          {conn.status === 'active' ? (
                            <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-black uppercase flex items-center gap-1 w-fit">
                              <CheckCircle2 className="w-3 h-3" /> Active
                            </span>
                          ) : (
                            <span className="px-2.5 py-1 rounded-full bg-red-500/20 text-red-300 border border-red-500/40 text-[10px] font-black uppercase flex items-center gap-1 w-fit">
                              <X className="w-3 h-3" /> Dissolved
                            </span>
                          )}
                        </td>

                        {/* Actions */}
                        <td className="p-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            {conn.type === 'cp' && conn.status === 'active' && (
                              <button
                                onClick={() => {
                                  setEditingIntimacyConn(conn);
                                  setIntimacyForm({
                                    intimacyPoints: conn.intimacyPoints || 0,
                                    level: conn.level || 1,
                                    sharedGiftsCoins: conn.sharedGiftsCoins || 0,
                                    reason: 'Executive Intimacy Adjustment'
                                  });
                                }}
                                className="px-2.5 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500 text-amber-300 hover:text-black font-bold text-[11px] border border-amber-500/40 transition-colors flex items-center gap-1"
                                title="Adjust Intimacy Points & Level"
                              >
                                <Edit3 className="w-3.5 h-3.5" /> Adjust
                              </button>
                            )}

                            {conn.status === 'active' && (
                              <button
                                onClick={() => {
                                  setTerminatingConn(conn);
                                  setTerminationReason('Administrative dissolution');
                                }}
                                className="px-2.5 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500 text-rose-300 hover:text-white font-bold text-[11px] border border-rose-500/40 transition-colors flex items-center gap-1"
                                title="Forcefully Terminate Connection"
                              >
                                <Trash2 className="w-3.5 h-3.5" /> Break
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ====================================================
          TAB 3: REQUESTS MODERATION
         ==================================================== */}
      {activeSubTab === 'requests' && (
        <div className="space-y-4">
          {/* Controls Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-white/5 p-4 rounded-2xl border border-white/10">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={reqSearchQuery}
                onChange={(e) => setReqSearchQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && loadData(false)}
                placeholder="Search sender, receiver, message..."
                className="w-full pl-10 pr-4 py-2 rounded-xl bg-black/40 border border-white/10 text-white placeholder-slate-400 text-xs focus:outline-none focus:border-purple-500"
              />
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-300 font-bold shrink-0">Type:</span>
              <select
                value={reqTypeFilter}
                onChange={(e) => setReqTypeFilter(e.target.value as any)}
                className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:outline-none focus:border-purple-500"
              >
                <option value="all">All Request Types</option>
                <option value="cp">CP Proposals Only ❤️</option>
                <option value="friend">Friend Requests Only 👥</option>
              </select>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-300 font-bold shrink-0">Status:</span>
              <select
                value={reqStatusFilter}
                onChange={(e) => setReqStatusFilter(e.target.value as any)}
                className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:outline-none focus:border-purple-500"
              >
                <option value="all">All Statuses</option>
                <option value="pending">Pending</option>
                <option value="accepted">Accepted</option>
                <option value="declined">Declined</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </div>
          </div>

          {requests.length === 0 ? (
            <div className="p-12 text-center text-slate-400 bg-white/5 rounded-3xl border border-white/10 space-y-2">
              <MessageSquare className="w-10 h-10 text-slate-500 mx-auto" />
              <p className="text-sm font-semibold text-white">No connection requests found.</p>
            </div>
          ) : (
            <div className="overflow-x-auto rounded-3xl border border-white/10 bg-white/5 backdrop-blur-xl shadow-xl">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-white/10 bg-white/5 text-slate-300 uppercase tracking-wider font-extrabold text-[10px]">
                    <th className="p-4">Type</th>
                    <th className="p-4">Sender</th>
                    <th className="p-4">Receiver</th>
                    <th className="p-4">Proposal Message</th>
                    <th className="p-4">Sent At</th>
                    <th className="p-4">Status</th>
                    <th className="p-4 text-right">Moderation</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {requests.map((req) => {
                    const sender = req.sender || allUsers.find(u => u.id === req.senderId);
                    const receiver = req.receiver || allUsers.find(u => u.id === req.receiverId);

                    return (
                      <tr key={req.id} className="hover:bg-white/5 transition-colors">
                        <td className="p-4">
                          <span className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase flex items-center gap-1 w-fit ${
                            req.type === 'cp' 
                              ? 'bg-pink-500/20 text-pink-300 border border-pink-500/40'
                              : 'bg-blue-500/20 text-blue-300 border border-blue-500/40'
                          }`}>
                            {req.type === 'cp' ? <Heart className="w-3 h-3 fill-pink-400 text-pink-400" /> : <Users className="w-3 h-3 text-blue-400" />}
                            {req.type.toUpperCase()}
                          </span>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-2">
                            <img
                              src={sender?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80'}
                              alt="Sender"
                              className="w-7 h-7 rounded-full object-cover border border-white/20 shrink-0"
                            />
                            <div>
                              <p className="font-bold text-white truncate max-w-[120px]">{sender?.name || req.senderId}</p>
                              <span className="text-[10px] text-slate-400 font-mono">UID: {sender?.uid || '—'}</span>
                            </div>
                          </div>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-2">
                            <img
                              src={receiver?.avatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=100&q=80'}
                              alt="Receiver"
                              className="w-7 h-7 rounded-full object-cover border border-white/20 shrink-0"
                            />
                            <div>
                              <p className="font-bold text-white truncate max-w-[120px]">{receiver?.name || req.receiverId}</p>
                              <span className="text-[10px] text-slate-400 font-mono">UID: {receiver?.uid || '—'}</span>
                            </div>
                          </div>
                        </td>
                        <td className="p-4 text-slate-300 max-w-[240px] truncate" title={req.message}>
                          "{req.message || 'No custom message'}"
                        </td>
                        <td className="p-4 text-slate-400 font-mono text-[11px]">
                          {new Date(req.createdAt).toLocaleDateString()}
                        </td>
                        <td className="p-4">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                            req.status === 'pending' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' :
                            req.status === 'accepted' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' :
                            req.status === 'declined' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' :
                            'bg-slate-500/20 text-slate-300 border border-slate-500/30'
                          }`}>
                            {req.status}
                          </span>
                        </td>
                        <td className="p-4 text-right">
                          {req.status === 'pending' && (
                            <button
                              onClick={() => handlePurgeRequest(req.id)}
                              className="px-2.5 py-1 rounded-xl bg-red-500/20 hover:bg-red-500 text-red-300 hover:text-white font-bold text-[11px] border border-red-500/40 transition-colors"
                              title="Cancel / Purge spam request"
                            >
                              Purge
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ====================================================
          TAB 4: BLOCKED USERS & SAFETY
         ==================================================== */}
      {activeSubTab === 'blocked' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 bg-white/5 p-4 rounded-2xl border border-white/10">
            <div className="relative flex-1 min-w-[240px]">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={blockedSearchQuery}
                onChange={(e) => setBlockedSearchQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && loadData(false)}
                placeholder="Search blocker or blocked user..."
                className="w-full pl-10 pr-4 py-2 rounded-xl bg-black/40 border border-white/10 text-white placeholder-slate-400 text-xs focus:outline-none focus:border-rose-500"
              />
            </div>
          </div>

          {blockedUsers.length === 0 ? (
            <div className="p-12 text-center text-slate-400 bg-white/5 rounded-3xl border border-white/10 space-y-2">
              <ShieldCheck className="w-10 h-10 text-emerald-400 mx-auto" />
              <p className="text-sm font-semibold text-white">No active user block relations recorded.</p>
            </div>
          ) : (
            <div className="overflow-x-auto rounded-3xl border border-white/10 bg-white/5 backdrop-blur-xl shadow-xl">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-white/10 bg-white/5 text-slate-300 uppercase tracking-wider font-extrabold text-[10px]">
                    <th className="p-4">Block Record ID</th>
                    <th className="p-4">Initiating User (Blocker)</th>
                    <th className="p-4">Target User (Blocked)</th>
                    <th className="p-4">Date Enacted</th>
                    <th className="p-4 text-right">Administrative Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {blockedUsers.map((rec) => {
                    const u = rec.user || allUsers.find(x => x.id === rec.userId);
                    const bu = rec.blockedUser || allUsers.find(x => x.id === rec.blockedUserId);

                    return (
                      <tr key={rec.id} className="hover:bg-white/5 transition-colors">
                        <td className="p-4 font-mono text-slate-400 text-[11px]">{rec.id}</td>
                        <td className="p-4">
                          <div className="flex items-center gap-2">
                            <img
                              src={u?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80'}
                              alt="Blocker"
                              className="w-7 h-7 rounded-full object-cover border border-white/20 shrink-0"
                            />
                            <div>
                              <p className="font-bold text-white truncate max-w-[130px]">{u?.name || rec.userId}</p>
                              <span className="text-[10px] text-slate-400 font-mono">UID: {u?.uid || '—'}</span>
                            </div>
                          </div>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-2">
                            <img
                              src={bu?.avatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=100&q=80'}
                              alt="Blocked"
                              className="w-7 h-7 rounded-full object-cover border border-white/20 shrink-0"
                            />
                            <div>
                              <p className="font-bold text-white truncate max-w-[130px]">{bu?.name || rec.blockedUserId}</p>
                              <span className="text-[10px] text-slate-400 font-mono">UID: {bu?.uid || '—'}</span>
                            </div>
                          </div>
                        </td>
                        <td className="p-4 font-mono text-slate-400 text-[11px]">
                          {new Date(rec.createdAt).toLocaleDateString()}
                        </td>
                        <td className="p-4 text-right">
                          <button
                            onClick={() => {
                              setUnblockingRecord(rec);
                              setUnblockReason('Administrative safety resolution');
                            }}
                            className="px-3 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500 text-emerald-300 hover:text-black font-bold text-xs border border-emerald-500/40 transition-colors"
                          >
                            Lift Block
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ====================================================
          TAB 5: SYSTEM RULES & CONFIGURATION
         ==================================================== */}
      {activeSubTab === 'config' && (
        <form onSubmit={handleSaveConfig} className="max-w-3xl space-y-5 bg-white/5 border border-white/10 p-6 rounded-3xl backdrop-blur-xl shadow-xl">
          <div className="border-b border-white/10 pb-3">
            <h3 className="text-base font-black text-white flex items-center gap-2">
              <Sliders className="w-5 h-5 text-amber-400" /> Platform Social & CP Governance Settings
            </h3>
            <p className="text-xs text-slate-300">
              Configure global relationship eligibility, intimacy scaling factors, and friendship thresholds.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300">Min User Level to Propose CP:</label>
              <input
                type="number"
                min="1"
                max="100"
                value={configForm.minUserLevelForCp}
                onChange={(e) => setConfigForm({ ...configForm, minUserLevelForCp: Number(e.target.value) })}
                className="w-full px-3.5 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:border-amber-500 focus:outline-none"
              />
              <span className="text-[10px] text-slate-400">Prevents low-level spam accounts from proposing CP.</span>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300">Initial CP Intimacy Points Granted:</label>
              <input
                type="number"
                min="0"
                max="10000"
                value={configForm.initialIntimacyPoints}
                onChange={(e) => setConfigForm({ ...configForm, initialIntimacyPoints: Number(e.target.value) })}
                className="w-full px-3.5 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:border-amber-500 focus:outline-none"
              />
              <span className="text-[10px] text-slate-400">Starting points awarded upon accepting a CP ceremony.</span>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300">Gift Intimacy Coin Conversion (%):</label>
              <input
                type="number"
                min="0"
                max="100"
                value={configForm.giftIntimacyPercent}
                onChange={(e) => setConfigForm({ ...configForm, giftIntimacyPercent: Number(e.target.value) })}
                className="w-full px-3.5 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:border-amber-500 focus:outline-none"
              />
              <span className="text-[10px] text-slate-400">Percentage of gift coin price converted into CP intimacy score.</span>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300">Base Intimacy Per Gift Sent:</label>
              <input
                type="number"
                min="0"
                max="500"
                value={configForm.giftIntimacyBasePerGift}
                onChange={(e) => setConfigForm({ ...configForm, giftIntimacyBasePerGift: Number(e.target.value) })}
                className="w-full px-3.5 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:border-amber-500 focus:outline-none"
              />
              <span className="text-[10px] text-slate-400">Flat intimacy bonus awarded for each gift transaction between couple.</span>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300">Max Friends Limit Per User:</label>
              <input
                type="number"
                min="50"
                max="5000"
                value={configForm.maxFriendsLimit}
                onChange={(e) => setConfigForm({ ...configForm, maxFriendsLimit: Number(e.target.value) })}
                className="w-full px-3.5 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:border-amber-500 focus:outline-none"
              />
              <span className="text-[10px] text-slate-400">Maximum active friends an individual user account can have.</span>
            </div>
          </div>

          <div className="pt-2 border-t border-white/10 space-y-3">
            <label className="flex items-center gap-3 cursor-pointer p-3 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 transition-colors">
              <input
                type="checkbox"
                checked={configForm.autoApproveVipCp}
                onChange={(e) => setConfigForm({ ...configForm, autoApproveVipCp: e.target.checked })}
                className="w-4 h-4 rounded text-amber-500 focus:ring-0 bg-black/50 border-white/20"
              />
              <div>
                <p className="text-xs font-bold text-white">Auto-Approve VIP & SVIP CP Proposals</p>
                <p className="text-[10px] text-slate-400">Bypasses proposal waiting periods when both users have active VIP status.</p>
              </div>
            </label>

            <label className="flex items-center gap-3 cursor-pointer p-3 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 transition-colors">
              <input
                type="checkbox"
                checked={configForm.allowSameGenderCp}
                onChange={(e) => setConfigForm({ ...configForm, allowSameGenderCp: e.target.checked })}
                className="w-4 h-4 rounded text-pink-600 focus:ring-0 bg-black/50 border-white/20"
              />
              <div>
                <p className="text-xs font-bold text-white">Allow Same-Gender CP Couple Bonds</p>
                <p className="text-[10px] text-slate-400">Allows users of the same profile gender or unspecified gender to bond as CP.</p>
              </div>
            </label>
          </div>

          {systemConfig?.updatedBy && (
            <div className="text-[10px] text-slate-400 font-mono">
              Last saved by: {systemConfig.updatedBy} at {new Date(systemConfig.updatedAt).toLocaleString()}
            </div>
          )}

          <div className="pt-2 flex justify-end">
            <button
              type="submit"
              disabled={savingConfig}
              className="px-6 py-2.5 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-black font-black text-xs shadow-lg shadow-amber-500/20 flex items-center gap-2 transition-all"
            >
              {savingConfig ? <RefreshCw className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
              Save Social Rules to Firestore
            </button>
          </div>
        </form>
      )}

      {/* ====================================================
          MODAL 1: FORCE CREATE CP COUPLE
         ==================================================== */}
      {showCreateCpModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
          <div className="bg-slate-900 border border-pink-500/40 rounded-3xl max-w-lg w-full p-6 space-y-5 shadow-2xl relative text-white">
            <button
              onClick={() => setShowCreateCpModal(false)}
              className="absolute top-4 right-4 p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-pink-500/20 border border-pink-500/40 flex items-center justify-center text-pink-400">
                <Heart className="w-5 h-5 fill-current" />
              </div>
              <div>
                <h3 className="text-base font-black text-white">Administrative CP Bond Ceremony</h3>
                <p className="text-xs text-slate-300">Forcefully bind two users in a romantic CP partnership.</p>
              </div>
            </div>

            <form onSubmit={handleCreateCpSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-300">Partner 1:</label>
                  <select
                    value={cpForm.user1Id}
                    onChange={(e) => setCpForm({ ...cpForm, user1Id: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:border-pink-500 focus:outline-none"
                    required
                  >
                    <option value="">Select User 1...</option>
                    {allUsers.map((u) => (
                      <option key={u.id} value={u.id}>
                        {u.name} (UID: {u.uid})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-300">Partner 2:</label>
                  <select
                    value={cpForm.user2Id}
                    onChange={(e) => setCpForm({ ...cpForm, user2Id: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:border-pink-500 focus:outline-none"
                    required
                  >
                    <option value="">Select User 2...</option>
                    {allUsers.map((u) => (
                      <option key={u.id} value={u.id}>
                        {u.name} (UID: {u.uid})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-300">Starting Intimacy Points:</label>
                  <input
                    type="number"
                    min="0"
                    max="100000"
                    value={cpForm.intimacyPoints}
                    onChange={(e) => setCpForm({ ...cpForm, intimacyPoints: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:border-pink-500 focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-300">Initial Level:</label>
                  <select
                    value={cpForm.level}
                    onChange={(e) => setCpForm({ ...cpForm, level: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:border-pink-500 focus:outline-none"
                  >
                    <option value="1">Lv.1 Kindred Hearts</option>
                    <option value="2">Lv.2 Sweet Romance</option>
                    <option value="3">Lv.3 Soulmates</option>
                    <option value="4">Lv.4 Eternal Flame</option>
                    <option value="5">Lv.5 Mythic Dynasty</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-300">Ceremony Broadcast Note:</label>
                <input
                  type="text"
                  value={cpForm.ceremonyNote}
                  onChange={(e) => setCpForm({ ...cpForm, ceremonyNote: e.target.value })}
                  placeholder="e.g. Official Platform Anniversary CP Bond 👑❤️"
                  className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:border-pink-500 focus:outline-none"
                />
              </div>

              <label className="flex items-center gap-2.5 p-3 rounded-xl bg-pink-500/10 border border-pink-500/20 cursor-pointer">
                <input
                  type="checkbox"
                  checked={cpForm.forceOverride}
                  onChange={(e) => setCpForm({ ...cpForm, forceOverride: e.target.checked })}
                  className="w-4 h-4 rounded text-pink-600 bg-black/50 border-pink-400"
                />
                <span className="text-xs text-pink-200">
                  <strong>Force Override:</strong> Dissolve existing CP bond if either partner is already coupled.
                </span>
              </label>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateCpModal(false)}
                  className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-500 hover:to-rose-500 text-white font-black text-xs shadow-lg shadow-pink-500/30"
                >
                  Confirm Official Bond
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ====================================================
          MODAL 2: ADJUST CP INTIMACY & LEVEL
         ==================================================== */}
      {editingIntimacyConn && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
          <div className="bg-slate-900 border border-amber-500/40 rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl relative text-white">
            <button
              onClick={() => setEditingIntimacyConn(null)}
              className="absolute top-4 right-4 p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
                <Flame className="w-5 h-5 fill-current" />
              </div>
              <div>
                <h3 className="text-base font-black text-white">Adjust CP Intimacy & Level</h3>
                <p className="text-xs text-slate-300">Connection #{editingIntimacyConn.id}</p>
              </div>
            </div>

            <form onSubmit={handleAdjustIntimacySubmit} className="space-y-3.5 text-xs">
              <div className="space-y-1">
                <label className="font-bold text-slate-300">Intimacy Points:</label>
                <input
                  type="number"
                  min="0"
                  max="1000000"
                  value={intimacyForm.intimacyPoints}
                  onChange={(e) => setIntimacyForm({ ...intimacyForm, intimacyPoints: Number(e.target.value) })}
                  className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:border-amber-500 focus:outline-none"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-300">CP Level Override:</label>
                <select
                  value={intimacyForm.level}
                  onChange={(e) => setIntimacyForm({ ...intimacyForm, level: Number(e.target.value) })}
                  className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:border-amber-500 focus:outline-none"
                >
                  <option value="1">Lv.1 Kindred Hearts</option>
                  <option value="2">Lv.2 Sweet Romance</option>
                  <option value="3">Lv.3 Soulmates</option>
                  <option value="4">Lv.4 Eternal Flame</option>
                  <option value="5">Lv.5 Mythic Dynasty</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-300">Shared Gift Coins Record:</label>
                <input
                  type="number"
                  min="0"
                  value={intimacyForm.sharedGiftsCoins}
                  onChange={(e) => setIntimacyForm({ ...intimacyForm, sharedGiftsCoins: Number(e.target.value) })}
                  className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-300">Reason for Audit Log:</label>
                <input
                  type="text"
                  value={intimacyForm.reason}
                  onChange={(e) => setIntimacyForm({ ...intimacyForm, reason: e.target.value })}
                  placeholder="e.g. VIP Gift Event Compensation"
                  className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:border-amber-500 focus:outline-none"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingIntimacyConn(null)}
                  className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 text-black font-black text-xs shadow-lg shadow-amber-500/20"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ====================================================
          MODAL 3: TERMINATE / DISSOLVE CONNECTION
         ==================================================== */}
      {terminatingConn && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
          <div className="bg-slate-900 border border-red-500/40 rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl relative text-white">
            <button
              onClick={() => setTerminatingConn(null)}
              className="absolute top-4 right-4 p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-red-500/20 border border-red-500/40 flex items-center justify-center text-red-400">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-black text-white">
                  Dissolve {terminatingConn.type.toUpperCase()} Relationship
                </h3>
                <p className="text-xs text-slate-300">Connection #{terminatingConn.id}</p>
              </div>
            </div>

            <p className="text-xs text-red-200">
              This will forcefully break the active bond between the two users. Both users will receive an official administrative notification.
            </p>

            <div className="space-y-1 text-xs">
              <label className="font-bold text-slate-300">Reason for Dissolution:</label>
              <textarea
                value={terminationReason}
                onChange={(e) => setTerminationReason(e.target.value)}
                rows={2}
                className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:border-red-500 focus:outline-none"
                placeholder="Specify reason for audit logs..."
                required
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setTerminatingConn(null)}
                className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleTerminateSubmit}
                className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-black text-xs shadow-lg shadow-red-500/30"
              >
                Confirm Dissolution
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ====================================================
          MODAL 4: ESTABLISH FRIENDSHIP
         ==================================================== */}
      {showCreateFriendModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
          <div className="bg-slate-900 border border-blue-500/40 rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl relative text-white">
            <button
              onClick={() => setShowCreateFriendModal(false)}
              className="absolute top-4 right-4 p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-500/20 border border-blue-500/40 flex items-center justify-center text-blue-400">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-black text-white">Establish Friendship</h3>
                <p className="text-xs text-slate-300">Forcefully create a mutual friendship between two users.</p>
              </div>
            </div>

            <form onSubmit={handleCreateFriendSubmit} className="space-y-3.5 text-xs">
              <div className="space-y-1">
                <label className="font-bold text-slate-300">User 1:</label>
                <select
                  value={friendForm.user1Id}
                  onChange={(e) => setFriendForm({ ...friendForm, user1Id: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:border-blue-500 focus:outline-none"
                  required
                >
                  <option value="">Select User 1...</option>
                  {allUsers.map((u) => (
                    <option key={u.id} value={u.id}>
                      {u.name} (UID: {u.uid})
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-300">User 2:</label>
                <select
                  value={friendForm.user2Id}
                  onChange={(e) => setFriendForm({ ...friendForm, user2Id: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:border-blue-500 focus:outline-none"
                  required
                >
                  <option value="">Select User 2...</option>
                  {allUsers.map((u) => (
                    <option key={u.id} value={u.id}>
                      {u.name} (UID: {u.uid})
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-300">Administrative Note:</label>
                <input
                  type="text"
                  value={friendForm.note}
                  onChange={(e) => setFriendForm({ ...friendForm, note: e.target.value })}
                  placeholder="e.g. Official Ambassador connection"
                  className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:border-blue-500 focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateFriendModal(false)}
                  className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-black text-xs shadow-lg shadow-blue-500/25"
                >
                  Establish Friendship
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ====================================================
          MODAL 5: UNBLOCK USER PAIR
         ==================================================== */}
      {unblockingRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
          <div className="bg-slate-900 border border-emerald-500/40 rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl relative text-white">
            <button
              onClick={() => setUnblockingRecord(null)}
              className="absolute top-4 right-4 p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-black text-white">Administrative Unblock</h3>
                <p className="text-xs text-slate-300">Remove block restriction between users.</p>
              </div>
            </div>

            <div className="space-y-1 text-xs">
              <label className="font-bold text-slate-300">Reason for Unblock:</label>
              <input
                type="text"
                value={unblockReason}
                onChange={(e) => setUnblockReason(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:border-emerald-500 focus:outline-none"
                placeholder="Reason..."
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setUnblockingRecord(null)}
                className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleUnblockSubmit}
                className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs shadow-lg shadow-emerald-500/25"
              >
                Lift Block
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
