import React, { useState, useEffect } from 'react';
import { 
  Building, UserCheck, Shield, Sparkles, CheckCircle2, ArrowLeft,
  Globe, Mail, DollarSign, FileText, AlertCircle, RefreshCw
} from 'lucide-react';
import { ApiClient } from '../../../lib/api';
import { User } from '../../../types';

interface HostAgencyCreateCenterProps {
  showNotification: (msg: string) => void;
  onNavigateToAgencies?: () => void;
}

export const HostAgencyCreateCenter: React.FC<HostAgencyCreateCenterProps> = ({ showNotification, onNavigateToAgencies }) => {
  const [name, setName] = useState('');
  const [customAgencyId, setCustomAgencyId] = useState('');
  const [ownerUid, setOwnerUid] = useState('');
  const [logoUrl, setLogoUrl] = useState('https://images.unsplash.com/photo-1560179707-f14e90ef3623?auto=format&fit=crop&w=300&q=80');
  const [description, setDescription] = useState('');
  const [country, setCountry] = useState('United States');
  const [contactInfo, setContactInfo] = useState('');
  const [commissionRate, setCommissionRate] = useState('15');
  const [status, setStatus] = useState<'active' | 'pending' | 'inactive'>('active');
  const [parentBdId, setParentBdId] = useState('');
  const [notes, setNotes] = useState('');

  // Owner user live lookup
  const [lookedUpUser, setLookedUpUser] = useState<User | null>(null);
  const [isLookingUp, setIsLookingUp] = useState(false);
  const [lookupError, setLookupError] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [createdAgency, setCreatedAgency] = useState<any>(null);

  const handleLookupUser = async (uidToSearch: string) => {
    setOwnerUid(uidToSearch);
    setLookupError('');
    setLookedUpUser(null);

    if (!uidToSearch.trim()) return;

    setIsLookingUp(true);
    try {
      const users = await ApiClient.getUsers();
      const match = users.find(u => u.uid === uidToSearch.trim() || u.id === uidToSearch.trim());
      if (match) {
        setLookedUpUser(match);
        if (!contactInfo && match.email) setContactInfo(match.email);
        if (!country && match.country) setCountry(match.country);
      } else {
        setLookupError(`No user found with UID '${uidToSearch}'`);
      }
    } catch (err: any) {
      setLookupError('Failed to lookup user');
    } finally {
      setIsLookingUp(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      showNotification('Agency Name is required');
      return;
    }
    if (!ownerUid.trim()) {
      showNotification('Owner UID is required');
      return;
    }

    setIsSubmitting(true);
    try {
      const payload = {
        name: name.trim(),
        agencyId: customAgencyId.trim() || undefined,
        ownerUid: ownerUid.trim(),
        logoUrl: logoUrl.trim(),
        description: description.trim(),
        country: country.trim(),
        contactInfo: contactInfo.trim(),
        commissionRate: Number(commissionRate),
        status,
        parentBdId: parentBdId.trim() || undefined,
        notes: notes.trim()
      };

      const agency = await ApiClient.createAgency(payload);
      setCreatedAgency(agency);
      showNotification(`🎉 Host Agency "${agency.name}" created successfully (Code: ${agency.code})`);
    } catch (err: any) {
      showNotification(err.message || 'Failed to create host agency');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResetForm = () => {
    setName('');
    setCustomAgencyId('');
    setOwnerUid('');
    setDescription('');
    setContactInfo('');
    setNotes('');
    setLookedUpUser(null);
    setCreatedAgency(null);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto animate-fadeIn">
      {/* HEADER BAR */}
      <div className="flex items-center justify-between p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
        <div className="flex items-center gap-3">
          {onNavigateToAgencies && (
            <button
              onClick={onNavigateToAgencies}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/10 text-white transition-all"
              title="Back to Agencies"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
          )}
          <div>
            <h3 className="text-base font-black text-white flex items-center gap-2">
              <Building className="w-5 h-5 text-amber-400" /> Host Agency Creation Portal
            </h3>
            <p className="text-xs text-slate-300">Provision official host agency guilds, set owner UIDs, commission structures & BD management</p>
          </div>
        </div>
        {onNavigateToAgencies && (
          <button
            onClick={onNavigateToAgencies}
            className="px-3 py-1.5 bg-white/10 hover:bg-white/20 text-slate-200 text-xs font-bold rounded-xl border border-white/10"
          >
            All Agencies Directory
          </button>
        )}
      </div>

      {/* SUCCESS CARD IF JUST CREATED */}
      {createdAgency && (
        <div className="p-6 rounded-3xl bg-gradient-to-br from-emerald-950/80 to-slate-900 border border-emerald-500/50 space-y-4 shadow-2xl animate-fadeIn">
          <div className="flex items-center gap-3 text-emerald-400">
            <CheckCircle2 className="w-8 h-8" />
            <div>
              <h4 className="text-base font-black text-white">Host Agency Created Successfully!</h4>
              <p className="text-xs text-emerald-300 font-mono">Agency ID: {createdAgency.id} • Invitation Code: {createdAgency.code}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 bg-black/40 rounded-2xl border border-white/10 text-xs">
            <div>
              <span className="text-slate-400 text-[10px] uppercase font-bold block">Agency Name</span>
              <span className="font-bold text-white">{createdAgency.name}</span>
            </div>
            <div>
              <span className="text-slate-400 text-[10px] uppercase font-bold block">Owner</span>
              <span className="font-bold text-amber-300">{createdAgency.ownerName} ({createdAgency.ownerUid})</span>
            </div>
            <div>
              <span className="text-slate-400 text-[10px] uppercase font-bold block">Commission</span>
              <span className="font-bold text-emerald-400">{createdAgency.commissionRate}%</span>
            </div>
            <div>
              <span className="text-slate-400 text-[10px] uppercase font-bold block">Status</span>
              <span className="font-bold text-cyan-300 uppercase">{createdAgency.status}</span>
            </div>
          </div>

          <div className="flex items-center gap-3 pt-2">
            <button
              onClick={handleResetForm}
              className="px-4 py-2 bg-gradient-to-r from-amber-500 to-yellow-600 text-black font-black text-xs rounded-xl shadow hover:brightness-110 flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4" /> Create Another Agency
            </button>
            {onNavigateToAgencies && (
              <button
                onClick={onNavigateToAgencies}
                className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white font-bold text-xs rounded-xl border border-white/10"
              >
                Go to Agency Directory
              </button>
            )}
          </div>
        </div>
      )}

      {/* FORM */}
      {!createdAgency && (
        <form onSubmit={handleSubmit} className="p-6 rounded-3xl bg-slate-900/90 border border-white/10 space-y-6 shadow-2xl backdrop-blur-xl">
          {/* SECTION 1: AGENCY IDENTITY */}
          <div className="space-y-4">
            <h4 className="text-xs font-black text-amber-400 uppercase tracking-wider border-b border-white/10 pb-2 flex items-center gap-2">
              <Building className="w-4 h-4" /> 1. Agency Identity & Branding
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">Agency Name *</label>
                <input
                  type="text"
                  placeholder="e.g. Apex Talent Guild"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-amber-400 font-bold"
                  required
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">Custom Agency ID (Optional)</label>
                <input
                  type="text"
                  placeholder="Auto-generated if left blank"
                  value={customAgencyId}
                  onChange={(e) => setCustomAgencyId(e.target.value)}
                  className="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-xs text-white placeholder:text-slate-500 font-mono focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">Agency Logo Image URL</label>
              <div className="flex items-center gap-3">
                <img src={logoUrl} alt="Logo Preview" className="w-10 h-10 rounded-xl object-cover border border-white/10 bg-black/40 flex-shrink-0" />
                <input
                  type="text"
                  placeholder="https://..."
                  value={logoUrl}
                  onChange={(e) => setLogoUrl(e.target.value)}
                  className="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">Agency Description</label>
              <textarea
                rows={2}
                placeholder="Overview of host agency specialty, voice talents, acoustic music..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none"
              />
            </div>
          </div>

          {/* SECTION 2: AGENCY OWNER ASSIGNMENT */}
          <div className="space-y-4 pt-2">
            <h4 className="text-xs font-black text-amber-400 uppercase tracking-wider border-b border-white/10 pb-2 flex items-center gap-2">
              <UserCheck className="w-4 h-4" /> 2. Owner User Verification & Assignment
            </h4>

            <div>
              <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">Owner User UID *</label>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder="Enter User UID (e.g. 8829107)"
                  value={ownerUid}
                  onChange={(e) => handleLookupUser(e.target.value)}
                  className="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-xs text-white placeholder:text-slate-500 font-mono focus:outline-none focus:border-amber-400"
                  required
                />
              </div>

              {isLookingUp && (
                <p className="text-[10px] text-amber-300 mt-1 flex items-center gap-1.5">
                  <RefreshCw className="w-3 h-3 animate-spin" /> Verifying User UID...
                </p>
              )}

              {lookupError && (
                <p className="text-[10px] text-rose-400 mt-1 flex items-center gap-1.5">
                  <AlertCircle className="w-3 h-3" /> {lookupError}
                </p>
              )}

              {lookedUpUser && (
                <div className="mt-3 p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl flex items-center gap-3">
                  <img src={lookedUpUser.avatar} alt={lookedUpUser.name} className="w-10 h-10 rounded-full object-cover border border-emerald-400" />
                  <div>
                    <h5 className="text-xs font-bold text-white flex items-center gap-2">
                      {lookedUpUser.name} <span className="text-[10px] text-emerald-300 font-mono">(UID: {lookedUpUser.uid})</span>
                    </h5>
                    <p className="text-[10px] text-slate-300">
                      Current Role: <span className="font-bold text-amber-300 uppercase">{lookedUpUser.role}</span> • Email: {lookedUpUser.email}
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* SECTION 3: COMMISSION & REGIONAL DETAILS */}
          <div className="space-y-4 pt-2">
            <h4 className="text-xs font-black text-amber-400 uppercase tracking-wider border-b border-white/10 pb-2 flex items-center gap-2">
              <Globe className="w-4 h-4" /> 3. Commission Rate, Region & BD Manager
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">Commission Rate (%) *</label>
                <input
                  type="number"
                  min="0"
                  max="50"
                  value={commissionRate}
                  onChange={(e) => setCommissionRate(e.target.value)}
                  className="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-xs text-white font-mono focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">Country / Territory</label>
                <input
                  type="text"
                  placeholder="e.g. Australia, US, Global"
                  value={country}
                  onChange={(e) => setCountry(e.target.value)}
                  className="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-xs text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">Initial Status</label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as any)}
                  className="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-xs text-white focus:outline-none"
                >
                  <option value="active">Active</option>
                  <option value="pending">Pending Approval</option>
                  <option value="inactive">Inactive</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">Contact Email / Phone</label>
                <input
                  type="text"
                  placeholder="agency@example.com"
                  value={contactInfo}
                  onChange={(e) => setContactInfo(e.target.value)}
                  className="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-xs text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">Parent BD / Manager ID (Optional)</label>
                <input
                  type="text"
                  placeholder="Optional assigned BD manager ID"
                  value={parentBdId}
                  onChange={(e) => setParentBdId(e.target.value)}
                  className="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-xs text-white font-mono focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">Internal Audit Notes</label>
              <textarea
                rows={2}
                placeholder="Internal executive agreement notes..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full bg-black/60 border border-white/10 rounded-xl p-2.5 text-xs text-white focus:outline-none"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
            <button
              type="button"
              onClick={handleResetForm}
              className="px-5 py-2.5 bg-white/10 hover:bg-white/20 text-slate-300 font-bold text-xs rounded-xl transition-all"
            >
              Clear Form
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2.5 bg-gradient-to-r from-amber-500 to-yellow-600 text-black font-black text-xs rounded-xl shadow-lg hover:brightness-110 disabled:opacity-50 flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              {isSubmitting ? 'Creating Host Agency...' : 'Create Host Agency'}
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
