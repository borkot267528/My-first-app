import React, { useState, useEffect } from 'react';
import { 
  Building2, Search, Plus, RefreshCw, CheckCircle2, XCircle, 
  Sparkles, DollarSign, Edit3, ShieldAlert, FileSpreadsheet, UserCheck
} from 'lucide-react';
import { RechargeAgent } from '../../../types';
import { ApiClient } from '../../../lib/api';
import { exportToExcel } from '../../../lib/exportUtils';

interface RechargeAgentCenterProps {
  showNotification: (msg: string) => void;
}

export const RechargeAgentCenter: React.FC<RechargeAgentCenterProps> = ({ showNotification }) => {
  const [agents, setAgents] = useState<RechargeAgent[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive' | 'suspended'>('all');

  // Add Agent Modal
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [userUid, setUserUid] = useState('');
  const [commissionRate, setCommissionRate] = useState('5');
  const [creditBalance, setCreditBalance] = useState('50000');
  const [addNotes, setAddNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Edit Agent Modal
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [selectedAgent, setSelectedAgent] = useState<RechargeAgent | null>(null);
  const [editCommissionRate, setEditCommissionRate] = useState('5');
  const [editCreditBalance, setEditCreditBalance] = useState('50000');
  const [editNotes, setEditNotes] = useState('');

  const loadAgents = async () => {
    setLoading(true);
    try {
      const data = await ApiClient.getRechargeAgents();
      setAgents(data);
    } catch (err: any) {
      showNotification(err.message || 'Failed to load recharge agents');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAgents();
  }, []);

  const handleCreateAgent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userUid.trim()) {
      showNotification('User UID is required');
      return;
    }

    setIsSubmitting(true);
    try {
      const created = await ApiClient.createRechargeAgent({
        userUid: userUid.trim(),
        commissionRate: Number(commissionRate),
        creditBalance: Number(creditBalance),
        notes: addNotes.trim()
      });
      showNotification(`🎉 Recharge Agent authorized for ${created.name} (${created.uid})`);
      setAddModalOpen(false);
      setUserUid('');
      setAddNotes('');
      loadAgents();
    } catch (err: any) {
      showNotification(err.message || 'Failed to create recharge agent');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUpdateAgent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAgent) return;

    setIsSubmitting(true);
    try {
      await ApiClient.updateRechargeAgent(selectedAgent.id, {
        commissionRate: Number(editCommissionRate),
        creditBalance: Number(editCreditBalance),
        notes: editNotes.trim()
      });
      showNotification('Recharge Agent details updated successfully');
      setEditModalOpen(false);
      loadAgents();
    } catch (err: any) {
      showNotification(err.message || 'Failed to update recharge agent');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleStatusToggle = async (agent: RechargeAgent, newStatus: 'active' | 'inactive' | 'suspended') => {
    const reason = prompt(`Reason for changing status of ${agent.name} to ${newStatus}?`);
    if (reason === null) return;

    try {
      await ApiClient.updateRechargeAgentStatus(agent.id, newStatus, reason);
      showNotification(`Recharge agent status updated to ${newStatus}`);
      loadAgents();
    } catch (err: any) {
      showNotification(err.message || 'Failed to change agent status');
    }
  };

  const filteredAgents = agents.filter(a => {
    const matchesSearch = !searchQuery || 
      a.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      a.uid.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.id.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || a.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleExportExcel = () => {
    exportToExcel('Recharge_Agents_Directory', filteredAgents.map(a => ({
      Agent_ID: a.id,
      Name: a.name,
      UID: a.uid,
      Status: a.status,
      Credit_Balance: a.creditBalance,
      Recharge_Volume: a.rechargeVolume,
      Commission_Rate: `${a.commissionRate}%`,
      Commission_Earned: a.totalCommissionEarned,
      Notes: a.notes,
      Created_At: new Date(a.createdAt).toLocaleDateString()
    })));
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* HEADER BAR */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
        <div>
          <h3 className="text-base font-black text-white flex items-center gap-2">
            <Building2 className="w-5 h-5 text-amber-400" /> Recharge Agent Operations
          </h3>
          <p className="text-xs text-slate-300">Authorize regional top-up recharge agents, credit limits & commission incentives</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={loadAgents} className="p-2 bg-white/10 text-white rounded-xl hover:bg-white/20 transition-all" title="Refresh">
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
          <button onClick={handleExportExcel} className="px-3 py-1.5 bg-emerald-600/80 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition-all">
            <FileSpreadsheet className="w-3.5 h-3.5" /> Export Excel
          </button>
          <button onClick={() => setAddModalOpen(true)} className="px-3 py-1.5 bg-gradient-to-r from-amber-500 to-yellow-600 text-black font-black text-xs rounded-xl shadow hover:brightness-110 flex items-center gap-1.5">
            <Plus className="w-4 h-4" /> Add Recharge Agent
          </button>
        </div>
      </div>

      {/* METRICS SUMMARY */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-1 shadow">
          <span className="text-[10px] text-slate-400 font-bold uppercase">Total Agents</span>
          <p className="text-2xl font-black text-amber-300 font-mono">{agents.length}</p>
        </div>
        <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-1 shadow">
          <span className="text-[10px] text-slate-400 font-bold uppercase">Active Regional Agents</span>
          <p className="text-2xl font-black text-emerald-400 font-mono">{agents.filter(a => a.status === 'active').length}</p>
        </div>
        <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-1 shadow">
          <span className="text-[10px] text-slate-400 font-bold uppercase">Total Agent Credit Pool</span>
          <p className="text-2xl font-black text-cyan-300 font-mono">
            🪙 {agents.reduce((acc, a) => acc + a.creditBalance, 0).toLocaleString()}
          </p>
        </div>
        <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-1 shadow">
          <span className="text-[10px] text-slate-400 font-bold uppercase">Total Agent Recharges</span>
          <p className="text-2xl font-black text-purple-300 font-mono">
            🪙 {agents.reduce((acc, a) => acc + a.rechargeVolume, 0).toLocaleString()}
          </p>
        </div>
      </div>

      {/* AGENTS DIRECTORY TABLE */}
      <div className="rounded-2xl bg-white/5 border border-white/10 overflow-hidden shadow-xl space-y-0">
        <div className="p-4 bg-black/40 border-b border-white/10 flex flex-wrap items-center justify-between gap-3">
          <h4 className="text-xs font-black text-amber-300 uppercase tracking-wider">
            RECHARGE AGENT DIRECTORY
          </h4>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-2 bg-black/60 px-3 py-1 rounded-xl border border-white/10 text-xs">
              <Search className="w-3.5 h-3.5 text-slate-400" />
              <input
                type="text"
                placeholder="Search agent name, UID..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-transparent text-white placeholder:text-slate-500 focus:outline-none w-36 sm:w-48"
              />
            </div>

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="bg-black/60 border border-white/10 text-slate-300 text-xs rounded-xl px-2.5 py-1 focus:outline-none"
            >
              <option value="all">All Status</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
              <option value="suspended">Suspended</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-black/50 text-slate-300 font-bold uppercase border-b border-white/10">
              <tr>
                <th className="p-3">Agent ID</th>
                <th className="p-3">User & UID</th>
                <th className="p-3">Credit Balance</th>
                <th className="p-3">Recharge Volume</th>
                <th className="p-3">Commission Rate</th>
                <th className="p-3">Earned Commission</th>
                <th className="p-3">Status</th>
                <th className="p-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-slate-200">
              {filteredAgents.length > 0 ? (
                filteredAgents.map(a => (
                  <tr key={a.id} className="hover:bg-white/5 transition-colors">
                    <td className="p-3 font-mono font-bold text-amber-300">{a.id}</td>
                    <td className="p-3">
                      <div className="flex items-center gap-2.5">
                        <img src={a.avatar} alt={a.name} className="w-8 h-8 rounded-full object-cover border border-amber-400" />
                        <div>
                          <p className="font-bold text-white">{a.name}</p>
                          <p className="text-[10px] font-mono text-amber-300">UID: {a.uid}</p>
                        </div>
                      </div>
                    </td>
                    <td className="p-3 font-mono font-bold text-cyan-300">
                      🪙 {a.creditBalance.toLocaleString()}
                    </td>
                    <td className="p-3 font-mono text-slate-300">
                      🪙 {a.rechargeVolume.toLocaleString()}
                    </td>
                    <td className="p-3 font-mono font-bold text-emerald-400">
                      {a.commissionRate}%
                    </td>
                    <td className="p-3 font-mono text-purple-300">
                      🪙 {a.totalCommissionEarned.toLocaleString()}
                    </td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase border ${
                        a.status === 'active' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' :
                        a.status === 'suspended' ? 'bg-rose-500/20 text-rose-300 border-rose-500/30' :
                        'bg-slate-500/20 text-slate-300 border-slate-500/30'
                      }`}>
                        {a.status}
                      </span>
                    </td>
                    <td className="p-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => {
                            setSelectedAgent(a);
                            setEditCommissionRate(a.commissionRate.toString());
                            setEditCreditBalance(a.creditBalance.toString());
                            setEditNotes(a.notes || '');
                            setEditModalOpen(true);
                          }}
                          className="px-2.5 py-1 bg-white/10 hover:bg-white/20 text-slate-200 font-bold text-[10px] rounded-lg border border-white/10 flex items-center gap-1"
                        >
                          <Edit3 className="w-3 h-3 text-amber-400" /> Edit
                        </button>

                        {a.status === 'active' ? (
                          <button
                            onClick={() => handleStatusToggle(a, 'suspended')}
                            className="px-2 py-1 bg-rose-500/20 hover:bg-rose-500/40 text-rose-300 text-[10px] font-bold rounded-lg border border-rose-500/30"
                          >
                            Suspend
                          </button>
                        ) : (
                          <button
                            onClick={() => handleStatusToggle(a, 'active')}
                            className="px-2 py-1 bg-emerald-500/20 hover:bg-emerald-500/40 text-emerald-300 text-[10px] font-bold rounded-lg border border-emerald-500/30"
                          >
                            Activate
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-400 text-xs italic">
                    No recharge agents found matching your query.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ADD RECHARGE AGENT MODAL */}
      {addModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-amber-500/40 rounded-3xl p-6 max-w-md w-full space-y-4 shadow-2xl animate-fadeIn">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h4 className="text-sm font-black text-amber-400 flex items-center gap-2">
                <Building2 className="w-4 h-4" /> Authorize Recharge Agent
              </h4>
              <button onClick={() => setAddModalOpen(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleCreateAgent} className="space-y-4">
              <div>
                <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">User UID *</label>
                <input
                  type="text"
                  placeholder="Enter user UID (e.g. 8829106)"
                  value={userUid}
                  onChange={(e) => setUserUid(e.target.value)}
                  className="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-xs text-white placeholder:text-slate-500 font-mono focus:outline-none focus:border-amber-400"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">Commission Rate (%)</label>
                  <input
                    type="number"
                    min="0"
                    max="50"
                    value={commissionRate}
                    onChange={(e) => setCommissionRate(e.target.value)}
                    className="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-xs text-white font-mono focus:outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">Credit Limit Balance</label>
                  <input
                    type="number"
                    min="0"
                    value={creditBalance}
                    onChange={(e) => setCreditBalance(e.target.value)}
                    className="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-xs text-white font-mono focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">Notes / Regional Territory</label>
                <textarea
                  rows={2}
                  placeholder="Notes on region, agency agreement..."
                  value={addNotes}
                  onChange={(e) => setAddNotes(e.target.value)}
                  className="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-xs text-white focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setAddModalOpen(false)}
                  className="px-4 py-2 bg-white/10 text-xs font-bold rounded-xl text-slate-300 hover:bg-white/20"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 bg-gradient-to-r from-amber-500 to-yellow-600 text-black font-black text-xs rounded-xl shadow hover:brightness-110 disabled:opacity-50"
                >
                  {isSubmitting ? 'Creating...' : 'Authorize Agent'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* EDIT RECHARGE AGENT MODAL */}
      {editModalOpen && selectedAgent && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-amber-500/40 rounded-3xl p-6 max-w-md w-full space-y-4 shadow-2xl animate-fadeIn">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h4 className="text-sm font-black text-amber-400 flex items-center gap-2">
                <Edit3 className="w-4 h-4" /> Edit Agent: {selectedAgent.name}
              </h4>
              <button onClick={() => setEditModalOpen(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleUpdateAgent} className="space-y-4">
              <div>
                <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">Commission Rate (%)</label>
                <input
                  type="number"
                  min="0"
                  max="50"
                  value={editCommissionRate}
                  onChange={(e) => setEditCommissionRate(e.target.value)}
                  className="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-xs text-white font-mono focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">Credit Balance</label>
                <input
                  type="number"
                  min="0"
                  value={editCreditBalance}
                  onChange={(e) => setEditCreditBalance(e.target.value)}
                  className="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-xs text-white font-mono focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">Notes</label>
                <textarea
                  rows={2}
                  value={editNotes}
                  onChange={(e) => setEditNotes(e.target.value)}
                  className="w-full bg-black/60 border border-white/10 rounded-xl p-2 text-xs text-white focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditModalOpen(false)}
                  className="px-4 py-2 bg-white/10 text-xs font-bold rounded-xl text-slate-300 hover:bg-white/20"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 bg-gradient-to-r from-amber-500 to-yellow-600 text-black font-black text-xs rounded-xl shadow hover:brightness-110 disabled:opacity-50"
                >
                  {isSubmitting ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
