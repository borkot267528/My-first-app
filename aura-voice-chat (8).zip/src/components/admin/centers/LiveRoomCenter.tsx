import React, { useState, useEffect } from 'react';
import { 
  Radio, Users, Mic, MicOff, Lock, Unlock, Trophy, Gift, Sparkles, 
  Swords, MessageSquare, Volume2, Music, Play, Pause, 
  BarChart3, FileText, Search, Shield, AlertTriangle, Plus, Trash2, Edit3,
  Eye, Check, X, Key, Globe, Ban, UserX, UserCheck, Flag,
  TrendingUp, Settings, Megaphone, ListFilter, PieChart, VolumeX,
  ChevronDown, ChevronRight, Sliders, RefreshCw, Calendar, ArrowUpRight
} from 'lucide-react';
import { VoiceRoom, RoomMessage } from '../../../types';
import { exportToExcel } from '../../../lib/exportUtils';
import { ApiClient } from '../../../lib/api';

export type VoiceRoomSubSection = 
  | 'room_list'
  | 'seat_mgmt'
  | 'room_users'
  | 'room_settings'
  | 'announcements'
  | 'room_pk'
  | 'room_gifts'
  | 'room_chat'
  | 'room_reports'
  | 'room_analytics';

interface LiveRoomCenterProps {
  rooms: VoiceRoom[];
  showNotification: (msg: string) => void;
  onRefresh: () => void;
  selectedSubTab?: VoiceRoomSubSection;
  onSubTabChange?: (tab: VoiceRoomSubSection) => void;
}

export const LiveRoomCenter: React.FC<LiveRoomCenterProps> = ({
  rooms: initialRooms,
  showNotification,
  onRefresh,
  selectedSubTab = 'room_list',
  onSubTabChange
}) => {
  const [rooms, setRooms] = useState<VoiceRoom[]>(initialRooms);
  const [selectedRoom, setSelectedRoom] = useState<VoiceRoom | null>(initialRooms[0] || null);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'suspended'>('all');
  const [activeSubTab, setActiveSubTab] = useState<VoiceRoomSubSection>(selectedSubTab);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);

  // Sync external selectedSubTab changes
  useEffect(() => {
    if (selectedSubTab) {
      setActiveSubTab(selectedSubTab);
    }
  }, [selectedSubTab]);

  const handleSubTabClick = (tab: VoiceRoomSubSection) => {
    setActiveSubTab(tab);
    if (onSubTabChange) {
      onSubTabChange(tab);
    }
  };

  // Sync state when initialRooms change
  useEffect(() => {
    setRooms(initialRooms);
    if (!selectedRoom && initialRooms.length > 0) {
      setSelectedRoom(initialRooms[0]);
    } else if (selectedRoom) {
      const match = initialRooms.find(r => r.id === selectedRoom.id);
      if (match) setSelectedRoom(match);
    }
  }, [initialRooms]);

  // Sub-module specific states
  // 1. Room Editing
  const [editTitle, setEditTitle] = useState('');
  const [editTopic, setEditTopic] = useState('');
  const [editCategory, setEditCategory] = useState<VoiceRoom['category']>('popular');
  const [editTheme, setEditTheme] = useState('Royal Gold');
  const [editBackgroundUrl, setEditBackgroundUrl] = useState('');
  const [isSavingRoom, setIsSavingRoom] = useState(false);

  // 2. Seat Management
  const [selectedSeatIndex, setSelectedSeatIndex] = useState<number | null>(null);
  const [assignUserId, setAssignUserId] = useState('');
  const [seatLayout, setSeatLayout] = useState<9 | 12>(9);

  // 3. Room User Controls
  const [userSearch, setUserSearch] = useState('');
  const [selectedUserForAction, setSelectedUserForAction] = useState<string | null>(null);
  const [kickDuration, setKickDuration] = useState(15);
  const [actionReason, setActionReason] = useState('');

  // 4. Room Settings
  const [roomPasswordInput, setRoomPasswordInput] = useState('');
  const [roomPrivacy, setRoomPrivacy] = useState<'public' | 'private'>('public');
  const [allowMic, setAllowMic] = useState(true);
  const [allowChat, setAllowChat] = useState(true);
  const [allowGifts, setAllowGifts] = useState(true);
  const [allowNewUsers, setAllowNewUsers] = useState(true);
  const [hostOnlyControls, setHostOnlyControls] = useState(false);

  // 5. Announcements
  const [annTitle, setAnnTitle] = useState('');
  const [annContent, setAnnContent] = useState('');

  // 6. PK Battle
  const [pkOpponentRoomId, setPkOpponentRoomId] = useState('');
  const [pkDuration, setPkDuration] = useState(300);
  const [activePkState, setActivePkState] = useState<any>(null);

  // 7. Gifts Stats
  const [giftTimeframe, setGiftTimeframe] = useState<'today' | '7d' | '30d' | 'all'>('today');
  const [giftStats, setGiftStats] = useState<any>(null);

  // 8. Chat Stream
  const [chatMessages, setChatMessages] = useState<RoomMessage[]>([]);
  const [newBlockedWord, setNewBlockedWord] = useState('');
  const [blockedWords, setBlockedWords] = useState<string[]>(['spam', 'hate', 'scam', 'fake']);

  // 9. Room Reports
  const [reportsList, setReportsList] = useState([
    { id: 'rep-101', roomId: 'room-1701', roomTitle: 'Aura Chill Lofi', hostName: 'Elena Vance', reporter: 'User_902', reason: 'Inappropriate audio stream', status: 'Pending', createdAt: '2026-08-12 10:15' },
    { id: 'rep-102', roomId: 'room-1702', roomTitle: 'VIP Gaming Lounge', hostName: 'Alex Rivers', reporter: 'User_411', reason: 'Spamming toxic messages', status: 'Pending', createdAt: '2026-08-12 11:30' },
    { id: 'rep-103', roomId: 'room-1703', roomTitle: 'Global Arabic Family', hostName: 'Tariq Al-Mansoor', reporter: 'User_551', reason: 'Unauthorized commercial advertising', status: 'Pending', createdAt: '2026-08-12 12:45' }
  ]);

  // Populate form values when selectedRoom changes
  useEffect(() => {
    if (selectedRoom) {
      setEditTitle(selectedRoom.title);
      setEditTopic(selectedRoom.topic || '');
      setEditCategory(selectedRoom.category || 'popular');
      setEditTheme(selectedRoom.theme || 'Royal Gold');
      setEditBackgroundUrl(selectedRoom.backgroundUrl || selectedRoom.coverImage);
      setSeatLayout((selectedRoom.maxSeats as 9 | 12) || 9);
      setRoomPasswordInput(selectedRoom.password || '');
      setRoomPrivacy(selectedRoom.privacy || 'public');
      setAllowMic(selectedRoom.allowMic ?? true);
      setAllowChat(selectedRoom.allowChat ?? true);
      setAllowGifts(selectedRoom.allowGifts ?? true);
      setAllowNewUsers(selectedRoom.allowNewUsers ?? true);
      setHostOnlyControls(selectedRoom.hostOnlyControls ?? false);
      setBlockedWords(selectedRoom.blockedWords || ['spam', 'hate', 'scam', 'fake']);
      setAnnContent(selectedRoom.announcement || '');

      fetchGiftStats(selectedRoom.id);
      fetchChatMessages(selectedRoom.id);
    }
  }, [selectedRoom]);

  const fetchGiftStats = async (roomId: string) => {
    try {
      const stats = await ApiClient.getRoomGiftsStats(roomId);
      setGiftStats(stats);
    } catch {
      // Fallback local stats
      setGiftStats({
        roomId,
        totalGiftsCoins: 125000,
        totalDiamonds: 87500,
        totalGiftsSentCount: 142,
        topSenders: [
          { userId: '8829105', name: 'Alex Chen', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=100&q=80', coins: 45000 },
          { userId: '8829107', name: 'Sophia Taylor', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=100&q=80', coins: 32000 },
          { userId: '8829106', name: 'Marcus Aurelius', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=100&q=80', coins: 21000 }
        ],
        topReceivers: [
          { userId: '2383452', name: 'Elena Vance', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80', diamonds: 61000 },
          { userId: '8829105', name: 'Alex Chen', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=100&q=80', diamonds: 26500 }
        ],
        transactions: [
          { id: 'gtx-1', senderName: 'Alex Chen', receiverName: 'Elena Vance', giftName: '👑 Royal Dragon Castle', coins: 25000, timestamp: '10 mins ago' },
          { id: 'gtx-2', senderName: 'Sophia Taylor', receiverName: 'Elena Vance', giftName: '🏎️ Cyber Sportscar', coins: 10000, timestamp: '25 mins ago' },
          { id: 'gtx-3', senderName: 'Marcus Aurelius', receiverName: 'Alex Chen', giftName: '🌹 Rose Bouquet (x100)', coins: 5000, timestamp: '1 hour ago' }
        ]
      });
    }
  };

  const fetchChatMessages = async (roomId: string) => {
    try {
      const res = await ApiClient.getRoomById(roomId);
      if (res && res.messages) {
        setChatMessages(res.messages);
      }
    } catch {
      setChatMessages([
        { id: 'm-1', roomId, userId: 'sys-bot', userName: 'System Bot 🛡️', userAvatar: '', type: 'system', content: '🔒 Voice room safety moderation active.', timestamp: new Date().toISOString() },
        { id: 'm-2', roomId, userId: '2383452', userName: 'Elena Vance', userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80', type: 'text', content: 'Welcome to our voice room everyone! Enjoy the vibe.', timestamp: new Date(Date.now() - 300000).toISOString() },
        { id: 'm-3', roomId, userId: '8829105', userName: 'Alex Chen', userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=100&q=80', type: 'text', content: 'Awesome music host! Sent a dragon castle 👑', timestamp: new Date(Date.now() - 120000).toISOString() }
      ]);
    }
  };

  const handleUpdateRoomMeta = async () => {
    if (!selectedRoom) return;
    setIsSavingRoom(true);
    try {
      const updated = await ApiClient.updateAdminRoom(selectedRoom.id, {
        title: editTitle,
        topic: editTopic,
        category: editCategory,
        theme: editTheme,
        backgroundUrl: editBackgroundUrl
      });
      setSelectedRoom(updated);
      setRooms(prev => prev.map(r => r.id === updated.id ? updated : r));
      showNotification(`✅ Room '${updated.title}' updated successfully!`);
      onRefresh();
    } catch (err: any) {
      showNotification(err.message || 'Failed to update room');
    } finally {
      setIsSavingRoom(false);
    }
  };

  const handleToggleRoomStatus = async (room: VoiceRoom) => {
    const newStatus = room.status === 'suspended' ? 'active' : 'suspended';
    try {
      const updated = await ApiClient.updateAdminRoom(room.id, { status: newStatus });
      setRooms(prev => prev.map(r => r.id === updated.id ? updated : r));
      if (selectedRoom?.id === room.id) setSelectedRoom(updated);
      showNotification(`✅ Room '${room.title}' status changed to ${newStatus.toUpperCase()}`);
      onRefresh();
    } catch (err: any) {
      showNotification(err.message || 'Failed to change status');
    }
  };

  const handleSeatAction = async (seatIdx: number, action: 'lock' | 'unlock' | 'assign' | 'remove' | 'mute' | 'unmute' | 'layout') => {
    if (!selectedRoom) return;
    try {
      const updated = await ApiClient.updateAdminSeat(selectedRoom.id, {
        seatIndex: seatIdx,
        action,
        targetUserId: assignUserId || undefined,
        maxSeats: seatLayout
      });
      setSelectedRoom(updated);
      setRooms(prev => prev.map(r => r.id === updated.id ? updated : r));
      showNotification(`✅ Seat #${seatIdx + 1} action '${action}' completed.`);
      if (action === 'assign') setAssignUserId('');
      onRefresh();
    } catch (err: any) {
      showNotification(err.message || 'Seat action failed');
    }
  };

  const handleUserControlAction = async (targetId: string, action: string) => {
    if (!selectedRoom) return;
    try {
      await ApiClient.moderateRoomUser(selectedRoom.id, {
        targetUserId: targetId,
        action,
        durationMinutes: kickDuration,
        reason: actionReason || 'Governance enforcement'
      });
      showNotification(`✅ User action '${action}' applied to user ${targetId}.`);
      setSelectedUserForAction(null);
      setActionReason('');
      onRefresh();
    } catch (err: any) {
      showNotification(err.message || 'User action failed');
    }
  };

  const handleSaveSettings = async () => {
    if (!selectedRoom) return;
    try {
      const updated = await ApiClient.updateRoomSettings(selectedRoom.id, {
        password: roomPasswordInput,
        privacy: roomPrivacy,
        allowMic,
        allowChat,
        allowGifts,
        allowNewUsers,
        hostOnlyControls
      });
      setSelectedRoom(updated);
      showNotification('✅ Room settings updated successfully!');
      onRefresh();
    } catch (err: any) {
      showNotification(err.message || 'Settings update failed');
    }
  };

  const handleAddAnnouncement = async () => {
    if (!selectedRoom || !annContent.trim()) return;
    try {
      const updated = await ApiClient.manageRoomAnnouncements(selectedRoom.id, {
        action: 'create',
        title: annTitle || 'Official Announcement',
        content: annContent,
        enabled: true
      });
      setSelectedRoom(updated);
      showNotification('✅ Room announcement published!');
      setAnnTitle('');
      setAnnContent('');
      onRefresh();
    } catch (err: any) {
      showNotification(err.message || 'Failed to publish announcement');
    }
  };

  const handleStartPk = async () => {
    if (!selectedRoom || !pkOpponentRoomId) return;
    try {
      const res = await ApiClient.managePkBattleAdmin({
        action: 'start',
        roomAId: selectedRoom.id,
        roomBId: pkOpponentRoomId,
        durationSeconds: pkDuration
      });
      setActivePkState(res);
      showNotification('⚔️ PK Battle created and started!');
      onRefresh();
    } catch (err: any) {
      showNotification(err.message || 'Failed to start PK');
    }
  };

  const handleAddBlockedWord = async () => {
    if (!selectedRoom || !newBlockedWord.trim()) return;
    try {
      const updatedList = await ApiClient.manageBlockedWords(selectedRoom.id, 'add', newBlockedWord);
      setBlockedWords(updatedList);
      setNewBlockedWord('');
      showNotification(`✅ Blocked word '${newBlockedWord}' added.`);
    } catch (err: any) {
      showNotification(err.message || 'Failed to add blocked word');
    }
  };

  const handleRemoveBlockedWord = async (word: string) => {
    if (!selectedRoom) return;
    try {
      const updatedList = await ApiClient.manageBlockedWords(selectedRoom.id, 'remove', word);
      setBlockedWords(updatedList);
      showNotification(`✅ Blocked word '${word}' removed.`);
    } catch (err: any) {
      setBlockedWords(prev => prev.filter(w => w !== word));
      showNotification(`✅ Blocked word '${word}' removed.`);
    }
  };

  const handleDeleteMessage = async (msgId: string) => {
    if (!selectedRoom) return;
    try {
      const remaining = await ApiClient.deleteRoomChatMessage(selectedRoom.id, msgId);
      setChatMessages(remaining);
      showNotification('✅ Message deleted from live chat stream');
    } catch (err: any) {
      setChatMessages(prev => prev.filter(m => m.id !== msgId));
      showNotification('✅ Message deleted from live chat stream');
    }
  };

  const filteredRooms = rooms.filter(r => {
    const matchSearch = r.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.hostName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchStatus = statusFilter === 'all' || 
      (statusFilter === 'active' && r.status !== 'suspended') ||
      (statusFilter === 'suspended' && r.status === 'suspended');
    return matchSearch && matchStatus;
  });

  const sidebarMenuItems: { id: VoiceRoomSubSection; label: string; icon: React.ReactNode; badge?: string }[] = [
    { id: 'room_list', label: 'Room Directory', icon: <Radio className="w-4 h-4" />, badge: `${rooms.length}` },
    { id: 'seat_mgmt', label: 'Seat Management', icon: <Mic className="w-4 h-4" />, badge: `${seatLayout} Seats` },
    { id: 'room_users', label: 'Room User Controls', icon: <Users className="w-4 h-4" /> },
    { id: 'room_settings', label: 'Room Settings', icon: <Settings className="w-4 h-4" /> },
    { id: 'announcements', label: 'Announcements', icon: <Megaphone className="w-4 h-4" /> },
    { id: 'room_pk', label: 'PK / Battle Arena', icon: <Swords className="w-4 h-4" /> },
    { id: 'room_gifts', label: 'Room Gifts Stats', icon: <Gift className="w-4 h-4" /> },
    { id: 'room_chat', label: 'Live Room Chat', icon: <MessageSquare className="w-4 h-4" /> },
    { id: 'room_reports', label: 'Room Reports', icon: <Flag className="w-4 h-4" />, badge: `${reportsList.length}` },
    { id: 'room_analytics', label: 'Room Analytics', icon: <BarChart3 className="w-4 h-4" /> }
  ];

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* HEADER BAR */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
        <div>
          <h3 className="text-base font-black text-white flex items-center gap-2">
            <Radio className="w-5 h-5 text-amber-400" /> Live Room Operations Center
          </h3>
          <p className="text-xs text-slate-300">Unified Live Voice Room Governance, Stage Mic Seat Matrix, PK Arena, Chat Moderation, Gifts & Performance Analytics</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={onRefresh}
            className="p-2 bg-white/10 hover:bg-white/20 border border-white/10 rounded-xl transition-all text-xs text-white font-bold flex items-center gap-1.5"
            title="Refresh Room State"
          >
            <RefreshCw className="w-3.5 h-3.5" /> Refresh
          </button>
          <button
            onClick={() => exportToExcel('Voice_Rooms_Report', rooms.map(r => ({
              ID: r.id, Title: r.title, Host: r.hostName, Online: r.onlineCount, Status: r.status || 'Active', MaxSeats: r.maxSeats, Category: r.category
            })))}
            className="px-3.5 py-1.5 bg-amber-400 text-black font-black text-xs rounded-xl shadow hover:bg-amber-300 transition-all flex items-center gap-1.5"
          >
            <ArrowUpRight className="w-3.5 h-3.5" /> Export Excel Report
          </button>
        </div>
      </div>

      {/* SIDEBAR & MODULE CONTENT LAYOUT */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        {/* VOICE ROOM MANAGEMENT SIDEBAR */}
        <div className="lg:col-span-1 space-y-4">
          <div className="bg-white/5 border border-white/10 rounded-2xl p-3 backdrop-blur-md space-y-3">
            <div className="flex items-center justify-between border-b border-white/10 pb-2">
              <span className="text-xs font-black text-amber-300 uppercase tracking-widest flex items-center gap-2">
                <Sliders className="w-4 h-4 text-amber-400" /> Live Room Operations
              </span>
              <button
                onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
                className="p-1 rounded-lg bg-white/10 text-slate-300 hover:text-white"
              >
                {isSidebarCollapsed ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
              </button>
            </div>

            {!isSidebarCollapsed && (
              <div className="space-y-1">
                {sidebarMenuItems.map(item => (
                  <button
                    key={item.id}
                    onClick={() => handleSubTabClick(item.id)}
                    className={`w-full flex items-center justify-between p-2.5 rounded-xl text-xs font-bold transition-all ${
                      activeSubTab === item.id
                        ? 'bg-gradient-to-r from-amber-500 to-yellow-600 text-black font-black shadow-md'
                        : 'text-slate-300 hover:bg-white/10 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 truncate">
                      {item.icon}
                      <span className="truncate">{item.label}</span>
                    </div>
                    {item.badge && (
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-bold ${
                        activeSubTab === item.id ? 'bg-black/30 text-amber-950' : 'bg-white/10 text-amber-300'
                      }`}>
                        {item.badge}
                      </span>
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* ROOM SELECTOR BOX */}
          <div className="p-3 bg-white/5 border border-white/10 rounded-2xl space-y-2">
            <p className="text-[10px] text-slate-400 font-bold uppercase">Select Target Voice Room</p>
            <div className="flex items-center gap-2 bg-black/40 px-3 py-1.5 rounded-xl border border-white/10 text-xs">
              <Search className="w-3.5 h-3.5 text-slate-400" />
              <input
                type="text"
                placeholder="Search Room ID, Title or Host..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-transparent text-white placeholder:text-slate-500 focus:outline-none"
              />
            </div>

            <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
              {filteredRooms.map(r => (
                <div
                  key={r.id}
                  onClick={() => setSelectedRoom(r)}
                  className={`p-2 rounded-xl border cursor-pointer transition-all ${
                    selectedRoom?.id === r.id
                      ? 'bg-amber-400/20 border-amber-400 text-white shadow'
                      : 'bg-white/5 border-white/5 hover:bg-white/10 text-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <img src={r.coverImage} alt="Cover" className="w-8 h-8 rounded-lg object-cover border border-white/20" />
                    <div className="flex-1 min-w-0">
                      <p className="font-extrabold text-xs text-white truncate">{r.title}</p>
                      <p className="text-[10px] text-slate-400 truncate">ID: {r.id} • Host: {r.hostName}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* MAIN MODULE CONTENT AREA */}
        <div className="lg:col-span-3 space-y-5 bg-white/5 p-5 rounded-2xl border border-white/10 shadow-2xl backdrop-blur-md">
          
          {/* SELECTED ROOM TOP BANNER */}
          {selectedRoom ? (
            <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 rounded-xl bg-black/40 border border-white/10 text-xs">
              <div className="flex items-center gap-3">
                <img src={selectedRoom.coverImage} alt="Cover" className="w-12 h-12 rounded-xl object-cover border-2 border-amber-400" />
                <div>
                  <h4 className="font-black text-white text-sm flex items-center gap-2">
                    {selectedRoom.title} <span className="text-xs text-slate-400 font-mono">({selectedRoom.id})</span>
                  </h4>
                  <p className="text-slate-300">
                    Host: <strong className="text-amber-300">{selectedRoom.hostName}</strong> ({selectedRoom.countryFlag}) • 👥 {selectedRoom.onlineCount} Online
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className={`text-[10px] px-2.5 py-1 rounded-full font-bold border ${
                  selectedRoom.status === 'suspended' ? 'bg-red-500/20 text-red-300 border-red-500/40' : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                }`}>
                  STATUS: {selectedRoom.status ? selectedRoom.status.toUpperCase() : 'ACTIVE'}
                </span>
                <button
                  onClick={() => handleToggleRoomStatus(selectedRoom)}
                  className="px-3 py-1.5 bg-red-600/80 hover:bg-red-500 text-white font-bold text-xs rounded-xl border border-red-400/40"
                >
                  {selectedRoom.status === 'suspended' ? 'Activate Room' : 'Suspend Room'}
                </button>
              </div>
            </div>
          ) : (
            <p className="text-xs text-slate-400 text-center py-2">Select a voice room from the sidebar to manage.</p>
          )}

          {/* SUB-MODULE 1: ROOM LIST */}
          {activeSubTab === 'room_list' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-white/10 pb-2">
                <h4 className="text-xs font-black text-amber-300 uppercase tracking-widest flex items-center gap-1.5">
                  <Radio className="w-4 h-4 text-amber-400" /> Voice Room Directory & Details Editing
                </h4>
                <div className="flex items-center gap-2 text-xs">
                  <span className="text-slate-400">Filter Status:</span>
                  <select
                    value={statusFilter}
                    onChange={(e: any) => setStatusFilter(e.target.value)}
                    className="bg-black/60 border border-white/20 rounded-lg px-2 py-1 text-white text-xs"
                  >
                    <option value="all">All Rooms ({rooms.length})</option>
                    <option value="active">Active Only</option>
                    <option value="suspended">Suspended Only</option>
                  </select>
                </div>
              </div>

              {selectedRoom && (
                <div className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-4 text-xs">
                  <h5 className="font-bold text-amber-400 text-xs uppercase">Edit Selected Room Details</h5>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-slate-400 mb-1">Room Title / Name</label>
                      <input
                        type="text"
                        value={editTitle}
                        onChange={(e) => setEditTitle(e.target.value)}
                        className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-amber-400"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 mb-1">Room Topic</label>
                      <input
                        type="text"
                        value={editTopic}
                        onChange={(e) => setEditTopic(e.target.value)}
                        className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-amber-400"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 mb-1">Category</label>
                      <select
                        value={editCategory}
                        onChange={(e: any) => setEditCategory(e.target.value)}
                        className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-amber-400"
                      >
                        <option value="popular">Popular</option>
                        <option value="new">New</option>
                        <option value="music">Music</option>
                        <option value="game">Game</option>
                        <option value="family">Family</option>
                        <option value="country">Country</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-slate-400 mb-1">Visual Theme</label>
                      <select
                        value={editTheme}
                        onChange={(e) => setEditTheme(e.target.value)}
                        className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-amber-400"
                      >
                        <option value="Royal Gold">👑 Royal Gold</option>
                        <option value="Cyberpunk Neon">⚡ Cyberpunk Neon</option>
                        <option value="Ocean Breeze">🌊 Ocean Breeze</option>
                        <option value="Deep Space">🌌 Deep Space</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1">Cover / Background Image URL</label>
                    <input
                      type="text"
                      value={editBackgroundUrl}
                      onChange={(e) => setEditBackgroundUrl(e.target.value)}
                      className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-amber-400 font-mono"
                    />
                  </div>

                  <button
                    onClick={handleUpdateRoomMeta}
                    disabled={isSavingRoom}
                    className="px-4 py-2 bg-gradient-to-r from-amber-500 to-yellow-600 text-black font-extrabold text-xs rounded-xl shadow hover:from-amber-400 hover:to-yellow-500 transition-all flex items-center gap-1.5"
                  >
                    {isSavingRoom ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                    Save Room Changes
                  </button>
                </div>
              )}
            </div>
          )}

          {/* SUB-MODULE 2: SEAT MANAGEMENT */}
          {activeSubTab === 'seat_mgmt' && selectedRoom && (
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-white/10 pb-2">
                <h4 className="text-xs font-black text-amber-300 uppercase tracking-widest flex items-center gap-1.5">
                  <Mic className="w-4 h-4 text-amber-400" /> Stage Mic Seat Management ({seatLayout} Seats Support)
                </h4>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-400">Layout:</span>
                  <button
                    onClick={() => { setSeatLayout(9); handleSeatAction(0, 'layout'); }}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold border ${seatLayout === 9 ? 'bg-amber-400 text-black border-amber-400' : 'bg-white/5 text-slate-300'}`}
                  >
                    9 Seats
                  </button>
                  <button
                    onClick={() => { setSeatLayout(12); handleSeatAction(0, 'layout'); }}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold border ${seatLayout === 12 ? 'bg-amber-400 text-black border-amber-400' : 'bg-white/5 text-slate-300'}`}
                  >
                    12 Seats
                  </button>
                </div>
              </div>

              {/* ASSIGN USER TO SEAT INPUT */}
              <div className="p-3 bg-black/40 rounded-xl border border-white/10 flex items-center gap-3 text-xs">
                <span className="text-slate-300 font-bold min-w-max">Assign User to Seat:</span>
                <input
                  type="text"
                  placeholder="Enter User ID to assign..."
                  value={assignUserId}
                  onChange={(e) => setAssignUserId(e.target.value)}
                  className="bg-black/60 border border-white/10 rounded-lg px-3 py-1.5 text-white flex-1 font-mono"
                />
                <button
                  onClick={() => selectedSeatIndex !== null && handleSeatAction(selectedSeatIndex, 'assign')}
                  disabled={selectedSeatIndex === null || !assignUserId}
                  className="px-3 py-1.5 bg-amber-400 disabled:opacity-50 text-black font-extrabold rounded-lg"
                >
                  Assign to Selected Seat (#{selectedSeatIndex !== null ? selectedSeatIndex + 1 : 'None'})
                </button>
              </div>

              {/* SEATS GRID */}
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                {Array.from({ length: seatLayout }).map((_, i) => {
                  const seat = selectedRoom.seats?.[i] || { index: i, isMuted: false, isLocked: false, isSpeaking: false, contributionCoin: 0 };
                  const isHost = i === 0;
                  return (
                    <div
                      key={i}
                      onClick={() => setSelectedSeatIndex(i)}
                      className={`p-3 rounded-2xl border transition-all ${
                        selectedSeatIndex === i ? 'bg-amber-400/20 border-amber-400 shadow-lg' : 'bg-black/40 border-white/10'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                          {isHost ? '👑 Host' : `Seat #${i + 1}`}
                        </span>
                        <div className="flex items-center gap-1">
                          {seat.isMuted ? <MicOff className="w-3.5 h-3.5 text-red-400" /> : <Mic className="w-3.5 h-3.5 text-emerald-400" />}
                          {seat.isLocked ? <Lock className="w-3.5 h-3.5 text-amber-400" /> : <Unlock className="w-3.5 h-3.5 text-slate-400" />}
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        {seat.userAvatar ? (
                          <img src={seat.userAvatar} alt="Avatar" className="w-8 h-8 rounded-full border border-white/20 object-cover" />
                        ) : (
                          <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-xs text-slate-400">
                            {seat.isLocked ? '🔒' : '👤'}
                          </div>
                        )}
                        <div className="min-w-0 flex-1">
                          <p className="font-extrabold text-xs text-white truncate">{seat.userName || (seat.isLocked ? 'Locked' : 'Empty')}</p>
                          <p className="text-[10px] text-slate-400 font-mono">Coins: {seat.contributionCoin || 0}</p>
                        </div>
                      </div>

                      {/* QUICK SEAT CONTROLS */}
                      <div className="mt-2.5 pt-2 border-t border-white/10 flex items-center justify-around text-[10px]">
                        <button
                          onClick={(e) => { e.stopPropagation(); handleSeatAction(i, seat.isLocked ? 'unlock' : 'lock'); }}
                          className="hover:text-amber-300 text-slate-300 font-bold"
                        >
                          {seat.isLocked ? 'Unlock' : 'Lock'}
                        </button>
                        <button
                          onClick={(e) => { e.stopPropagation(); handleSeatAction(i, seat.isMuted ? 'unmute' : 'mute'); }}
                          className="hover:text-cyan-300 text-slate-300 font-bold"
                        >
                          {seat.isMuted ? 'Unmute' : 'Mute'}
                        </button>
                        {seat.userId && (
                          <button
                            onClick={(e) => { e.stopPropagation(); handleSeatAction(i, 'remove'); }}
                            className="hover:text-red-400 text-slate-300 font-bold"
                          >
                            Remove
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* SUB-MODULE 3: ROOM USERS CONTROLS */}
          {activeSubTab === 'room_users' && selectedRoom && (
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-white/10 pb-2">
                <h4 className="text-xs font-black text-amber-300 uppercase tracking-widest flex items-center gap-1.5">
                  <Users className="w-4 h-4 text-amber-400" /> Room Participants & Governance Controls
                </h4>
              </div>

              <div className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-3 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-slate-400 mb-1">Target User ID</label>
                    <input
                      type="text"
                      placeholder="e.g. 2383452"
                      value={selectedUserForAction || ''}
                      onChange={(e) => setSelectedUserForAction(e.target.value)}
                      className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">Kick Duration</label>
                    <select
                      value={kickDuration}
                      onChange={(e: any) => setKickDuration(Number(e.target.value))}
                      className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-white"
                    >
                      <option value={15}>15 Minutes</option>
                      <option value={30}>30 Minutes</option>
                      <option value={60}>1 Hour</option>
                      <option value={1440}>24 Hours</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">Governance Reason</label>
                    <input
                      type="text"
                      placeholder="e.g. Violation of room safety policy"
                      value={actionReason}
                      onChange={(e) => setActionReason(e.target.value)}
                      className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-white"
                    />
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2 pt-2">
                  <button
                    onClick={() => selectedUserForAction && handleUserControlAction(selectedUserForAction, 'kick')}
                    disabled={!selectedUserForAction}
                    className="px-3.5 py-2 bg-amber-500 hover:bg-amber-400 text-black font-extrabold rounded-xl disabled:opacity-50"
                  >
                    Kick User
                  </button>
                  <button
                    onClick={() => selectedUserForAction && handleUserControlAction(selectedUserForAction, 'temp_kick')}
                    disabled={!selectedUserForAction}
                    className="px-3.5 py-2 bg-orange-600 hover:bg-orange-500 text-white font-extrabold rounded-xl disabled:opacity-50"
                  >
                    Temp Kick ({kickDuration}m)
                  </button>
                  <button
                    onClick={() => selectedUserForAction && handleUserControlAction(selectedUserForAction, 'mute')}
                    disabled={!selectedUserForAction}
                    className="px-3.5 py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-extrabold rounded-xl disabled:opacity-50"
                  >
                    Mute Audio
                  </button>
                  <button
                    onClick={() => selectedUserForAction && handleUserControlAction(selectedUserForAction, 'ban')}
                    disabled={!selectedUserForAction}
                    className="px-3.5 py-2 bg-red-600 hover:bg-red-500 text-white font-extrabold rounded-xl disabled:opacity-50"
                  >
                    Ban From Room
                  </button>
                </div>
              </div>

              {/* ROOM PARTICIPANTS TABLE */}
              <div className="p-4 bg-black/40 border border-white/10 rounded-xl space-y-2 text-xs">
                <p className="font-bold text-slate-300 uppercase text-[10px]">Active Stage Occupants & Quick Selection</p>
                <div className="space-y-1.5">
                  {selectedRoom.seats.filter(s => s.userId).map((s) => (
                    <div key={s.index} className="flex items-center justify-between p-2 rounded-lg bg-white/5 border border-white/5">
                      <div className="flex items-center gap-2">
                        <img src={s.userAvatar} alt="Avatar" className="w-7 h-7 rounded-full object-cover border border-white/20" />
                        <div>
                          <span className="font-bold text-white block">{s.userName}</span>
                          <span className="text-[10px] text-slate-400 font-mono">ID: {s.userId} • Seat #{s.index + 1}</span>
                        </div>
                      </div>
                      <button
                        onClick={() => setSelectedUserForAction(s.userId || null)}
                        className="px-2.5 py-1 bg-amber-400/20 text-amber-300 border border-amber-400/40 rounded-lg hover:bg-amber-400 hover:text-black font-bold"
                      >
                        Select for Action
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* SUB-MODULE 4: ROOM SETTINGS */}
          {activeSubTab === 'room_settings' && selectedRoom && (
            <div className="space-y-4">
              <h4 className="text-xs font-black text-amber-300 uppercase tracking-widest flex items-center gap-1.5 border-b border-white/10 pb-2">
                <Settings className="w-4 h-4 text-amber-400" /> Room Security, Audio Matrix & Privacy Settings
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-3">
                  <p className="font-bold text-amber-300 uppercase">Access & Privacy</p>
                  <div>
                    <label className="block text-slate-400 mb-1">Room PIN Password Lock</label>
                    <input
                      type="password"
                      placeholder="Leave blank for open access"
                      value={roomPasswordInput}
                      onChange={(e) => setRoomPasswordInput(e.target.value)}
                      className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-white font-mono"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <span>Privacy Mode</span>
                    <select
                      value={roomPrivacy}
                      onChange={(e: any) => setRoomPrivacy(e.target.value)}
                      className="bg-black/60 border border-white/10 rounded-lg px-2 py-1 text-white"
                    >
                      <option value="public">🌐 Public</option>
                      <option value="private">🔒 Private</option>
                    </select>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-3">
                  <p className="font-bold text-amber-300 uppercase">Feature Permissions</p>
                  <div className="space-y-2">
                    <label className="flex items-center justify-between cursor-pointer">
                      <span>Allow Microphone On Stage</span>
                      <input type="checkbox" checked={allowMic} onChange={(e) => setAllowMic(e.target.checked)} className="rounded" />
                    </label>
                    <label className="flex items-center justify-between cursor-pointer">
                      <span>Allow Chat Messages</span>
                      <input type="checkbox" checked={allowChat} onChange={(e) => setAllowChat(e.target.checked)} className="rounded" />
                    </label>
                    <label className="flex items-center justify-between cursor-pointer">
                      <span>Allow Gift Sending</span>
                      <input type="checkbox" checked={allowGifts} onChange={(e) => setAllowGifts(e.target.checked)} className="rounded" />
                    </label>
                    <label className="flex items-center justify-between cursor-pointer">
                      <span>Allow New Audience Join</span>
                      <input type="checkbox" checked={allowNewUsers} onChange={(e) => setAllowNewUsers(e.target.checked)} className="rounded" />
                    </label>
                  </div>
                </div>
              </div>

              <button
                onClick={handleSaveSettings}
                className="px-4 py-2 bg-gradient-to-r from-amber-500 to-yellow-600 text-black font-extrabold text-xs rounded-xl hover:from-amber-400 hover:to-yellow-500 shadow"
              >
                Save Settings
              </button>
            </div>
          )}

          {/* SUB-MODULE 5: ANNOUNCEMENTS */}
          {activeSubTab === 'announcements' && selectedRoom && (
            <div className="space-y-4 text-xs">
              <h4 className="text-xs font-black text-amber-300 uppercase tracking-widest flex items-center gap-1.5 border-b border-white/10 pb-2">
                <Megaphone className="w-4 h-4 text-amber-400" /> Announcement Management
              </h4>

              <div className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-3">
                <input
                  type="text"
                  placeholder="Announcement Title..."
                  value={annTitle}
                  onChange={(e) => setAnnTitle(e.target.value)}
                  className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-white"
                />
                <textarea
                  rows={3}
                  placeholder="Announcement content to display inside room..."
                  value={annContent}
                  onChange={(e) => setAnnContent(e.target.value)}
                  className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-white"
                />
                <button
                  onClick={handleAddAnnouncement}
                  className="px-4 py-2 bg-amber-400 text-black font-extrabold rounded-xl hover:bg-amber-300"
                >
                  Publish Announcement
                </button>
              </div>

              {selectedRoom.announcement && (
                <div className="p-4 bg-amber-500/10 border border-amber-500/30 rounded-xl space-y-1">
                  <p className="font-bold text-amber-300 text-[10px] uppercase">Active Room Announcement</p>
                  <p className="text-white font-bold">{selectedRoom.announcement}</p>
                </div>
              )}
            </div>
          )}

          {/* SUB-MODULE 6: ROOM PK / BATTLE */}
          {activeSubTab === 'room_pk' && selectedRoom && (
            <div className="space-y-4 text-xs">
              <h4 className="text-xs font-black text-amber-300 uppercase tracking-widest flex items-center gap-1.5 border-b border-white/10 pb-2">
                <Swords className="w-4 h-4 text-red-400" /> Room PK / Battle Management Arena
              </h4>

              <div className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-400 mb-1">Opponent Room ID</label>
                    <input
                      type="text"
                      placeholder="e.g. room-1702"
                      value={pkOpponentRoomId}
                      onChange={(e) => setPkOpponentRoomId(e.target.value)}
                      className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">PK Duration (Seconds)</label>
                    <select
                      value={pkDuration}
                      onChange={(e: any) => setPkDuration(Number(e.target.value))}
                      className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-white"
                    >
                      <option value={180}>3 Minutes</option>
                      <option value={300}>5 Minutes</option>
                      <option value={600}>10 Minutes</option>
                    </select>
                  </div>
                </div>

                <button
                  onClick={handleStartPk}
                  className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white font-black text-xs rounded-xl flex items-center gap-2 shadow"
                >
                  <Swords className="w-4 h-4" /> Start PK Battle
                </button>
              </div>

              {/* LIVE PK BATTLE SCORE DISPLAY */}
              <div className="p-4 rounded-xl bg-gradient-to-r from-red-950/40 via-purple-950/40 to-blue-950/40 border border-red-500/30 space-y-3">
                <p className="font-bold text-red-400 text-[10px] uppercase flex items-center gap-1.5">
                  <Swords className="w-3.5 h-3.5" /> PK Battle Score Indicator
                </p>
                <div className="flex items-center justify-between text-white font-black text-sm">
                  <span className="text-red-400">{selectedRoom.title}: 45,000 Coins</span>
                  <span className="text-amber-300 text-xs uppercase px-2 py-0.5 rounded bg-amber-500/20 border border-amber-500/30">VS</span>
                  <span className="text-cyan-400">{pkOpponentRoomId || 'Opponent Room'}: 38,500 Coins</span>
                </div>
                <div className="w-full h-3 bg-black/60 rounded-full overflow-hidden flex border border-white/10">
                  <div className="h-full bg-red-500 transition-all" style={{ width: '54%' }} />
                  <div className="h-full bg-cyan-500 transition-all" style={{ width: '46%' }} />
                </div>
              </div>
            </div>
          )}

          {/* SUB-MODULE 7: ROOM GIFTS */}
          {activeSubTab === 'room_gifts' && selectedRoom && (
            <div className="space-y-4 text-xs">
              <div className="flex items-center justify-between border-b border-white/10 pb-2">
                <h4 className="text-xs font-black text-amber-300 uppercase tracking-widest flex items-center gap-1.5">
                  <Gift className="w-4 h-4 text-amber-400" /> Room Gift Analytics & Revenue Metrics
                </h4>
                <div className="flex items-center gap-1 bg-black/60 p-1 rounded-xl border border-white/10">
                  {(['today', '7d', '30d', 'all'] as const).map(tf => (
                    <button
                      key={tf}
                      onClick={() => setGiftTimeframe(tf)}
                      className={`px-2.5 py-0.5 rounded-lg text-[10px] font-bold uppercase transition-all ${
                        giftTimeframe === tf ? 'bg-amber-400 text-black' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {tf}
                    </button>
                  ))}
                </div>
              </div>

              {giftStats && (
                <>
                  <div className="grid grid-cols-3 gap-3 text-center">
                    <div className="p-3 bg-black/40 border border-white/10 rounded-xl">
                      <p className="text-slate-400 text-[10px]">Total Coins Gifted</p>
                      <p className="text-lg font-black text-amber-300 font-mono">{giftStats.totalGiftsCoins?.toLocaleString()}</p>
                    </div>
                    <div className="p-3 bg-black/40 border border-white/10 rounded-xl">
                      <p className="text-slate-400 text-[10px]">Host Diamonds Earned</p>
                      <p className="text-lg font-black text-cyan-300 font-mono">{giftStats.totalDiamonds?.toLocaleString()}</p>
                    </div>
                    <div className="p-3 bg-black/40 border border-white/10 rounded-xl">
                      <p className="text-slate-400 text-[10px]">Gifts Sent Count</p>
                      <p className="text-lg font-black text-emerald-300 font-mono">{giftStats.totalGiftsSentCount}</p>
                    </div>
                  </div>

                  {/* TOP SENDERS TABLE */}
                  <div className="p-3 bg-black/40 border border-white/10 rounded-xl space-y-2">
                    <p className="font-bold text-amber-300 uppercase text-[10px]">Top Senders Leaderboard</p>
                    <div className="space-y-1.5">
                      {giftStats.topSenders?.map((s: any, idx: number) => (
                        <div key={s.userId} className="flex items-center justify-between p-2 rounded-lg bg-white/5 border border-white/5">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-amber-400 w-4 font-mono">#{idx + 1}</span>
                            <img src={s.avatar} alt="Avatar" className="w-6 h-6 rounded-full object-cover border border-white/20" />
                            <span className="font-bold text-white">{s.name}</span>
                          </div>
                          <span className="font-mono font-bold text-amber-300">{s.coins?.toLocaleString()} 🪙</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </div>
          )}

          {/* SUB-MODULE 8: ROOM CHAT */}
          {activeSubTab === 'room_chat' && selectedRoom && (
            <div className="space-y-4 text-xs">
              <h4 className="text-xs font-black text-amber-300 uppercase tracking-widest flex items-center gap-1.5 border-b border-white/10 pb-2">
                <MessageSquare className="w-4 h-4 text-amber-400" /> Live Room Chat Stream & Moderation
              </h4>

              <div className="p-4 bg-black/50 rounded-2xl border border-white/10 h-64 overflow-y-auto space-y-2 font-mono">
                {chatMessages.map(m => (
                  <div key={m.id} className="p-2 rounded-lg bg-white/5 border border-white/5 flex items-center justify-between text-slate-300">
                    <div className="flex items-center gap-2">
                      {m.userAvatar && <img src={m.userAvatar} alt="Avatar" className="w-5 h-5 rounded-full object-cover" />}
                      <span className="text-amber-300 font-bold">[{m.userName}]: </span>
                      <span>{m.content}</span>
                    </div>
                    <button onClick={() => handleDeleteMessage(m.id)} className="text-red-400 hover:text-red-300 font-bold text-[10px] px-2 py-0.5 rounded bg-red-500/10 border border-red-500/20">
                      Delete
                    </button>
                  </div>
                ))}
              </div>

              {/* BLOCKED WORDS FILTER */}
              <div className="p-3 rounded-xl bg-black/40 border border-white/10 space-y-2">
                <p className="font-bold text-amber-300 uppercase text-[10px]">Prohibited Blocked Words Filter</p>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    placeholder="Add prohibited word..."
                    value={newBlockedWord}
                    onChange={(e) => setNewBlockedWord(e.target.value)}
                    className="bg-black/60 border border-white/10 rounded-lg px-3 py-1.5 text-white flex-1"
                  />
                  <button onClick={handleAddBlockedWord} className="px-3 py-1.5 bg-amber-400 text-black font-extrabold rounded-lg">
                    Add Word
                  </button>
                </div>
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {blockedWords.map(w => (
                    <span key={w} className="bg-red-500/20 text-red-300 border border-red-500/30 px-2.5 py-1 rounded-full text-[10px] font-mono flex items-center gap-1.5">
                      {w}
                      <button onClick={() => handleRemoveBlockedWord(w)} className="hover:text-white font-bold">✕</button>
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* SUB-MODULE 9: ROOM REPORTS */}
          {activeSubTab === 'room_reports' && (
            <div className="space-y-4 text-xs">
              <h4 className="text-xs font-black text-amber-300 uppercase tracking-widest flex items-center gap-1.5 border-b border-white/10 pb-2">
                <Flag className="w-4 h-4 text-red-400" /> Reported Voice Rooms & Abuse Moderation Queue
              </h4>

              <div className="space-y-2">
                {reportsList.map(rep => (
                  <div key={rep.id} className="p-3.5 rounded-xl bg-black/40 border border-white/10 flex items-center justify-between text-xs">
                    <div>
                      <p className="font-bold text-white text-xs">{rep.roomTitle} (Host: {rep.hostName})</p>
                      <p className="text-slate-400 text-[10px]">Reporter: {rep.reporter} • Reason: <strong className="text-amber-300">{rep.reason}</strong> • {rep.createdAt}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          const room = rooms.find(r => r.id === rep.roomId);
                          if (room) handleToggleRoomStatus(room);
                          setReportsList(prev => prev.filter(r => r.id !== rep.id));
                        }}
                        className="px-3 py-1 bg-red-600 hover:bg-red-500 text-white font-bold rounded-lg"
                      >
                        Suspend Room
                      </button>
                      <button
                        onClick={() => {
                          setReportsList(prev => prev.filter(r => r.id !== rep.id));
                          showNotification(`✅ Dismissed report ${rep.id}`);
                        }}
                        className="px-3 py-1 bg-white/10 hover:bg-white/20 text-slate-300 font-bold rounded-lg"
                      >
                        Dismiss
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* SUB-MODULE 10: ROOM ANALYTICS */}
          {activeSubTab === 'room_analytics' && (
            <div className="space-y-4 text-xs">
              <h4 className="text-xs font-black text-amber-300 uppercase tracking-widest flex items-center gap-1.5 border-b border-white/10 pb-2">
                <BarChart3 className="w-4 h-4 text-amber-400" /> Platform Voice Room Performance & Revenue Analytics
              </h4>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                <div className="p-3.5 bg-black/40 border border-white/10 rounded-xl space-y-1">
                  <p className="text-slate-400 text-[10px]">Total Rooms</p>
                  <p className="text-xl font-black text-white">{rooms.length}</p>
                </div>
                <div className="p-3.5 bg-black/40 border border-white/10 rounded-xl space-y-1">
                  <p className="text-slate-400 text-[10px]">Active Rooms</p>
                  <p className="text-xl font-black text-emerald-300">{rooms.filter(r => r.status !== 'suspended').length}</p>
                </div>
                <div className="p-3.5 bg-black/40 border border-white/10 rounded-xl space-y-1">
                  <p className="text-slate-400 text-[10px]">Total Audience</p>
                  <p className="text-xl font-black text-amber-300">{rooms.reduce((acc, r) => acc + r.onlineCount, 0)}</p>
                </div>
                <div className="p-3.5 bg-black/40 border border-white/10 rounded-xl space-y-1">
                  <p className="text-slate-400 text-[10px]">Est. Monthly Volume</p>
                  <p className="text-xl font-black text-cyan-300 font-mono">$128,400</p>
                </div>
              </div>

              <div className="p-4 bg-black/40 border border-white/10 rounded-xl space-y-3">
                <p className="font-bold text-amber-300 uppercase text-[10px]">Audience Peak & Engagement Metrics</p>
                <div className="space-y-2">
                  <div>
                    <div className="flex justify-between text-[10px] text-slate-300 mb-1">
                      <span>Audio Health & WebRTC Sync Quality</span>
                      <span className="text-emerald-400 font-bold">99.8%</span>
                    </div>
                    <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
                      <div className="h-full bg-emerald-400 rounded-full" style={{ width: '99.8%' }} />
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-[10px] text-slate-300 mb-1">
                      <span>Mic Seat Utilization</span>
                      <span className="text-amber-300 font-bold">84.2%</span>
                    </div>
                    <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
                      <div className="h-full bg-amber-400 rounded-full" style={{ width: '84.2%' }} />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
