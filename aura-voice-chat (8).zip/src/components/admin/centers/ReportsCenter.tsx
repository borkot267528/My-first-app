import React, { useState, useEffect } from 'react';
import { 
  BarChart3, FileSpreadsheet, FileText, Download, PieChart, 
  TrendingUp, ShieldAlert, Flag, CheckCircle2, Clock, 
  AlertTriangle, RefreshCw, XCircle, Search, MessageSquare
} from 'lucide-react';
import { exportToExcel, exportToPDF } from '../../../lib/exportUtils';
import { ApiClient } from '../../../lib/api';
import { ReportItem } from '../../../types';

interface ReportsCenterProps {
  showNotification: (msg: string) => void;
}

export const ReportsCenter: React.FC<ReportsCenterProps> = ({ showNotification }) => {
  const [centerTab, setCenterTab] = useState<'moderation' | 'executive'>('moderation');
  
  // Executive Reports State
  const [reportDomain, setReportDomain] = useState<'revenue' | 'recharge' | 'withdraw' | 'gift' | 'room' | 'staff' | 'user' | 'family' | 'agency' | 'host'>('revenue');

  // Moderation Reports State
  const [reports, setReports] = useState<ReportItem[]>([]);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoadingReports, setIsLoadingReports] = useState(false);
  const [selectedReportForAction, setSelectedReportForAction] = useState<ReportItem | null>(null);
  const [actionStatus, setActionStatus] = useState<'resolved' | 'dismissed' | 'investigating'>('resolved');
  const [actionNotes, setActionNotes] = useState('');
  const [isSubmittingAction, setIsSubmittingAction] = useState(false);

  const fetchReports = async () => {
    setIsLoadingReports(true);
    try {
      const data = await ApiClient.getReports(statusFilter === 'all' ? undefined : statusFilter);
      setReports(data || []);
    } catch (err: any) {
      console.error('Failed to fetch reports:', err);
    } finally {
      setIsLoadingReports(false);
    }
  };

  useEffect(() => {
    if (centerTab === 'moderation') {
      fetchReports();
    }
  }, [centerTab, statusFilter]);

  const handleModerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedReportForAction) return;

    setIsSubmittingAction(true);
    try {
      await ApiClient.moderateReport(
        selectedReportForAction.id,
        actionStatus,
        actionNotes.trim() || `Marked as ${actionStatus} by staff`
      );
      showNotification(`✅ Report marked as ${actionStatus}`);
      setSelectedReportForAction(null);
      setActionNotes('');
      fetchReports();
    } catch (err: any) {
      showNotification(err.message || 'Failed to moderate report');
    } finally {
      setIsSubmittingAction(false);
    }
  };

  const executiveData = [
    { period: '2026-Q1', grossVolumeUsd: 342000, netMarginUsd: 85500, activeUsers: 1420, activeRooms: 85 },
    { period: '2026-Q2', grossVolumeUsd: 418000, netMarginUsd: 104500, activeUsers: 1890, activeRooms: 112 },
    { period: '2026-Q3 (YTD)', grossVolumeUsd: 512000, netMarginUsd: 128000, activeUsers: 2450, activeRooms: 148 }
  ];

  const handleExportExcel = () => exportToExcel(`${reportDomain.toUpperCase()}_Executive_Report`, executiveData);
  const handleExportPDF = () => {
    const headers = ['Quarter Period', 'Gross Volume (USD)', 'Net Margin (USD)', 'Active Users', 'Active Rooms'];
    const rows = executiveData.map(r => [r.period, `$${r.grossVolumeUsd.toLocaleString()}`, `$${r.netMarginUsd.toLocaleString()}`, r.activeUsers, r.activeRooms]);
    exportToPDF(`${reportDomain.toUpperCase()} Executive Analytics Report`, headers, rows);
  };

  const filteredReports = reports.filter(r => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      r.reason.toLowerCase().includes(q) ||
      (r.targetTitle && r.targetTitle.toLowerCase().includes(q)) ||
      (r.targetUserName && r.targetUserName.toLowerCase().includes(q)) ||
      r.reporterName.toLowerCase().includes(q) ||
      (r.details && r.details.toLowerCase().includes(q)) ||
      r.targetId.toLowerCase().includes(q)
    );
  });

  const pendingCount = reports.filter(r => r.status === 'pending').length;
  const investigatingCount = reports.filter(r => r.status === 'investigating').length;
  const resolvedCount = reports.filter(r => r.status === 'resolved').length;

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* PRIMARY TAB SELECTOR */}
      <div className="flex items-center justify-between gap-4 p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setCenterTab('moderation')}
            className={`px-4 py-2 rounded-xl font-black text-xs flex items-center gap-2 transition-all shadow ${
              centerTab === 'moderation'
                ? 'bg-amber-400 text-black shadow-amber-400/20'
                : 'bg-white/5 hover:bg-white/10 text-slate-300'
            }`}
          >
            <ShieldAlert className="w-4 h-4" />
            <span>Room & User Safety Reports</span>
            {pendingCount > 0 && (
              <span className="bg-rose-500 text-white text-[10px] px-1.5 py-0.5 rounded-full font-black ml-1">
                {pendingCount}
              </span>
            )}
          </button>
          <button
            onClick={() => setCenterTab('executive')}
            className={`px-4 py-2 rounded-xl font-black text-xs flex items-center gap-2 transition-all shadow ${
              centerTab === 'executive'
                ? 'bg-amber-400 text-black shadow-amber-400/20'
                : 'bg-white/5 hover:bg-white/10 text-slate-300'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            <span>Executive Multi-Domain Analytics</span>
          </button>
        </div>

        {centerTab === 'moderation' ? (
          <button
            onClick={fetchReports}
            disabled={isLoadingReports}
            className="px-3 py-1.5 bg-white/10 hover:bg-white/20 text-slate-200 text-xs font-bold rounded-xl flex items-center gap-1.5 border border-white/10"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoadingReports ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
        ) : (
          <div className="flex items-center gap-2">
            <button onClick={handleExportExcel} className="px-3 py-1.5 bg-emerald-600/80 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl flex items-center gap-1 shadow">
              <FileSpreadsheet className="w-3.5 h-3.5" /> Export Excel
            </button>
            <button onClick={handleExportPDF} className="px-3 py-1.5 bg-rose-600/80 hover:bg-rose-600 text-white font-bold text-xs rounded-xl flex items-center gap-1 shadow">
              <FileText className="w-3.5 h-3.5" /> Export PDF
            </button>
          </div>
        )}
      </div>

      {/* SECTION 1: MODERATION REPORTS */}
      {centerTab === 'moderation' && (
        <div className="space-y-4">
          {/* STATS OVERVIEW CARDS */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 rounded-2xl bg-white/5 border border-white/10">
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Total Reports</div>
              <div className="text-xl font-black text-white mt-1">{reports.length}</div>
            </div>
            <div className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/20">
              <div className="text-[10px] font-bold text-rose-300 uppercase tracking-wider">Pending Action</div>
              <div className="text-xl font-black text-rose-400 mt-1">{pendingCount}</div>
            </div>
            <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/20">
              <div className="text-[10px] font-bold text-amber-300 uppercase tracking-wider">Under Investigation</div>
              <div className="text-xl font-black text-amber-400 mt-1">{investigatingCount}</div>
            </div>
            <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/20">
              <div className="text-[10px] font-bold text-emerald-300 uppercase tracking-wider">Resolved</div>
              <div className="text-xl font-black text-emerald-400 mt-1">{resolvedCount}</div>
            </div>
          </div>

          {/* FILTERS & SEARCH */}
          <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-2xl bg-white/5 border border-white/10">
            <div className="flex flex-wrap items-center gap-1.5 text-xs">
              {['all', 'pending', 'investigating', 'resolved', 'dismissed'].map(st => (
                <button
                  key={st}
                  onClick={() => setStatusFilter(st)}
                  className={`px-3 py-1 rounded-xl font-bold capitalize transition-all ${
                    statusFilter === st
                      ? 'bg-amber-400 text-black font-black'
                      : 'bg-white/5 text-slate-300 hover:bg-white/10'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>

            <div className="relative w-full sm:w-64">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search reports, users, rooms..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-black/40 text-xs text-white pl-8 pr-3 py-1.5 rounded-xl border border-white/10 focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>

          {/* REPORTS TABLE / LIST */}
          <div className="rounded-2xl bg-white/5 border border-white/10 overflow-hidden shadow-xl">
            {filteredReports.length === 0 ? (
              <div className="p-12 text-center text-slate-400 space-y-2">
                <ShieldAlert className="w-8 h-8 mx-auto text-slate-500" />
                <p className="text-sm font-bold">No user reports found</p>
                <p className="text-xs text-slate-400">Reports submitted from voice rooms or user profiles will appear here for staff review.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-black/40 text-slate-300 font-bold uppercase border-b border-white/10">
                    <tr>
                      <th className="p-3">Target & Subject</th>
                      <th className="p-3">Reason</th>
                      <th className="p-3">Reporter</th>
                      <th className="p-3">Date / Status</th>
                      <th className="p-3 text-right">Moderation Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5 text-slate-200">
                    {filteredReports.map((report) => (
                      <tr key={report.id} className="hover:bg-white/5 transition-colors">
                        <td className="p-3">
                          <div className="flex items-center gap-2">
                            <span className="p-1.5 rounded-lg bg-amber-400/10 text-amber-400 font-black text-[10px] uppercase">
                              {report.targetType}
                            </span>
                            <div>
                              <div className="font-extrabold text-white text-xs">
                                {report.targetTitle || report.targetUserName || report.targetId}
                              </div>
                              <div className="text-[10px] text-slate-400 font-mono">
                                ID: {report.targetId}
                              </div>
                            </div>
                          </div>
                        </td>

                        <td className="p-3">
                          <div className="font-bold text-amber-300 text-xs">{report.reason}</div>
                          {report.details && (
                            <div className="text-[11px] text-slate-300 mt-0.5 line-clamp-2 max-w-xs">
                              "{report.details}"
                            </div>
                          )}
                          {report.adminNotes && (
                            <div className="text-[10px] text-emerald-400 mt-1 flex items-center gap-1">
                              <CheckCircle2 className="w-3 h-3 shrink-0" />
                              <span>Staff: {report.adminNotes}</span>
                            </div>
                          )}
                        </td>

                        <td className="p-3">
                          <div className="font-semibold text-white">{report.reporterName}</div>
                          {report.reporterUid && (
                            <div className="text-[10px] text-slate-400 font-mono">
                              UID: {report.reporterUid}
                            </div>
                          )}
                        </td>

                        <td className="p-3">
                          <div className="text-[11px] text-slate-300">
                            {new Date(report.createdAt).toLocaleDateString()} {new Date(report.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </div>
                          <div className="mt-1">
                            <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${
                              report.status === 'pending' ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30' :
                              report.status === 'investigating' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' :
                              report.status === 'resolved' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                              'bg-slate-500/20 text-slate-400 border border-slate-500/30'
                            }`}>
                              {report.status}
                            </span>
                          </div>
                        </td>

                        <td className="p-3 text-right">
                          <button
                            onClick={() => {
                              setSelectedReportForAction(report);
                              setActionStatus(report.status === 'pending' ? 'resolved' : report.status);
                              setActionNotes(report.adminNotes || '');
                            }}
                            className="px-3 py-1.5 bg-amber-400/20 hover:bg-amber-400 text-amber-300 hover:text-black font-bold text-xs rounded-xl transition-all border border-amber-400/40 shadow-sm"
                          >
                            Moderate
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SECTION 2: EXECUTIVE DOMAIN REPORTS */}
      {centerTab === 'executive' && (
        <div className="space-y-4">
          {/* DOMAIN SELECTOR */}
          <div className="flex flex-wrap gap-2 border-b border-white/10 pb-2 text-xs">
            {[
              { id: 'revenue', label: 'Revenue' },
              { id: 'recharge', label: 'Recharge' },
              { id: 'withdraw', label: 'Withdrawal' },
              { id: 'gift', label: 'Gift Sales' },
              { id: 'room', label: 'Rooms' },
              { id: 'staff', label: 'Staff Activity' },
              { id: 'user', label: 'Users' },
              { id: 'family', label: 'Families' },
              { id: 'agency', label: 'Agencies' },
              { id: 'host', label: 'Hosts' }
            ].map(d => (
              <button
                key={d.id}
                onClick={() => setReportDomain(d.id as any)}
                className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
                  reportDomain === d.id ? 'bg-amber-400 text-black font-black shadow-md' : 'bg-white/5 text-slate-300 hover:bg-white/10'
                }`}
              >
                {d.label} Reports
              </button>
            ))}
          </div>

          {/* REPORT DATA TABLE */}
          <div className="rounded-2xl bg-white/5 border border-white/10 overflow-hidden shadow-xl p-4 space-y-3">
            <h4 className="text-xs font-black text-amber-300 uppercase">{reportDomain.toUpperCase()} AUDITED STATEMENTS</h4>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-black/40 text-slate-300 font-bold uppercase border-b border-white/10">
                  <tr>
                    <th className="p-3">Reporting Period</th>
                    <th className="p-3">Gross Volume</th>
                    <th className="p-3">Net Profit Margin</th>
                    <th className="p-3">Active Users</th>
                    <th className="p-3">Active Voice Rooms</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 text-slate-200">
                  {executiveData.map((r, i) => (
                    <tr key={i} className="hover:bg-white/5">
                      <td className="p-3 font-bold text-white">{r.period}</td>
                      <td className="p-3 font-mono font-bold text-emerald-400">${r.grossVolumeUsd.toLocaleString()} USD</td>
                      <td className="p-3 font-mono font-bold text-amber-300">${r.netMarginUsd.toLocaleString()} USD</td>
                      <td className="p-3 font-mono">{r.activeUsers.toLocaleString()}</td>
                      <td className="p-3 font-mono text-cyan-300">{r.activeRooms}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* MODERATION ACTION MODAL */}
      {selectedReportForAction && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-[#1a0b2e]/95 backdrop-blur-2xl border border-white/20 rounded-3xl p-5 w-full max-w-md space-y-4 shadow-2xl animate-scaleUp">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="font-extrabold text-white text-base flex items-center gap-2">
                <ShieldAlert className="w-5 h-5 text-amber-400" /> Moderate Report
              </h3>
              <button onClick={() => setSelectedReportForAction(null)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <div className="p-3 rounded-xl bg-white/5 border border-white/10 space-y-1 text-xs">
              <div className="text-slate-300">
                <span className="text-slate-400">Target:</span> <strong className="text-white">{selectedReportForAction.targetTitle || selectedReportForAction.targetUserName || selectedReportForAction.targetId}</strong>
              </div>
              <div className="text-slate-300">
                <span className="text-slate-400">Reason:</span> <strong className="text-amber-300">{selectedReportForAction.reason}</strong>
              </div>
              {selectedReportForAction.details && (
                <div className="text-slate-300">
                  <span className="text-slate-400">Details:</span> <em>"{selectedReportForAction.details}"</em>
                </div>
              )}
            </div>

            <form onSubmit={handleModerate} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-200 block mb-1">Set Resolution Status</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'resolved', label: 'Resolved', color: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40' },
                    { id: 'investigating', label: 'Investigating', color: 'bg-amber-500/20 text-amber-400 border-amber-500/40' },
                    { id: 'dismissed', label: 'Dismissed', color: 'bg-slate-500/20 text-slate-400 border-slate-500/40' }
                  ].map(st => (
                    <button
                      key={st.id}
                      type="button"
                      onClick={() => setActionStatus(st.id as any)}
                      className={`py-2 rounded-xl font-bold border transition-all ${
                        actionStatus === st.id ? 'bg-amber-400 text-black border-amber-400 font-black' : `${st.color} hover:bg-white/10`
                      }`}
                    >
                      {st.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-200 block mb-1">Staff Moderation Notes</label>
                <textarea
                  value={actionNotes}
                  onChange={(e) => setActionNotes(e.target.value)}
                  placeholder="e.g. Warning issued to host, audio muted, or report dismissed as false alarm..."
                  rows={3}
                  className="w-full bg-black/40 text-xs text-white p-3 rounded-xl border border-white/15 focus:outline-none focus:border-amber-400 resize-none"
                />
              </div>

              <div className="flex items-center gap-2 pt-2 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setSelectedReportForAction(null)}
                  className="flex-1 py-2.5 bg-white/10 hover:bg-white/20 text-slate-300 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingAction}
                  className="flex-1 py-2.5 bg-amber-400 hover:bg-amber-300 text-black font-extrabold rounded-xl shadow-lg disabled:opacity-50 flex items-center justify-center gap-1.5"
                >
                  {isSubmittingAction ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
                  <span>Save Decision</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
