import React, { useState } from 'react';
import { Mic, Award, Clock, DollarSign, Gift, FileSpreadsheet, FileText, Search, Trophy } from 'lucide-react';
import { exportToExcel, exportToPDF } from '../../../lib/exportUtils';

interface HostCenterProps {
  showNotification: (msg: string) => void;
}

export const HostCenter: React.FC<HostCenterProps> = ({ showNotification }) => {
  const [activeSubTab, setActiveSubTab] = useState<'roster' | 'attendance' | 'salary' | 'performance'>('roster');

  const sampleHosts = [
    { id: 'hst-01', name: 'Sophia VIP', agency: 'Star Media Global', liveHoursThisMonth: 124, diamondsEarned: 245000, baseSalaryUsd: 800, diamondIncomeUsd: 1225, totalPayoutUsd: 2025 },
    { id: 'hst-02', name: 'Alex Melody', agency: 'Alpha Agency', liveHoursThisMonth: 98, diamondsEarned: 180000, baseSalaryUsd: 600, diamondIncomeUsd: 900, totalPayoutUsd: 1500 },
    { id: 'hst-03', name: 'Elena Beats', agency: 'Independent', liveHoursThisMonth: 145, diamondsEarned: 310000, baseSalaryUsd: 1000, diamondIncomeUsd: 1550, totalPayoutUsd: 2550 }
  ];

  const handleExportExcel = () => exportToExcel('Host_Performance_Report', sampleHosts);
  const handleExportPDF = () => {
    const headers = ['Host ID', 'Name', 'Agency', 'Live Hours', 'Diamonds', 'Base Salary', 'Diamond Income', 'Total Payout'];
    const rows = sampleHosts.map(h => [h.id, h.name, h.agency, `${h.liveHoursThisMonth} hrs`, h.diamondsEarned, `$${h.baseSalaryUsd}`, `$${h.diamondIncomeUsd}`, `$${h.totalPayoutUsd}`]);
    exportToPDF('Host Streamer Payout & Attendance Audit', headers, rows);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* HEADER BAR */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
        <div>
          <h3 className="text-base font-black text-white flex items-center gap-2">
            <Mic className="w-5 h-5 text-cyan-400" /> Host & Voice Streamer Operations Center
          </h3>
          <p className="text-xs text-slate-300">Live Attendance Tracking, Diamond Revenue, Monthly Salary Settlements & Host Rankings</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={handleExportExcel} className="px-3 py-1.5 bg-emerald-600/80 text-white font-bold text-xs rounded-xl flex items-center gap-1.5">
            <FileSpreadsheet className="w-3.5 h-3.5" /> Excel
          </button>
          <button onClick={handleExportPDF} className="px-3 py-1.5 bg-rose-600/80 text-white font-bold text-xs rounded-xl flex items-center gap-1.5">
            <FileText className="w-3.5 h-3.5" /> PDF
          </button>
        </div>
      </div>

      {/* HOSTS TABLE */}
      <div className="rounded-2xl bg-white/5 border border-white/10 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-black/40 text-slate-300 font-bold uppercase border-b border-white/10">
              <tr>
                <th className="p-3">Host Name</th>
                <th className="p-3">Agency</th>
                <th className="p-3">Live Hours (Month)</th>
                <th className="p-3">Diamonds Earned</th>
                <th className="p-3">Base Salary</th>
                <th className="p-3">Diamond Cut</th>
                <th className="p-3">Total Monthly Settlement</th>
                <th className="p-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-slate-200">
              {sampleHosts.map(h => (
                <tr key={h.id} className="hover:bg-white/5">
                  <td className="p-3 font-bold text-white flex items-center gap-2">
                    <Mic className="w-3.5 h-3.5 text-cyan-400" /> {h.name}
                  </td>
                  <td className="p-3 text-slate-300">{h.agency}</td>
                  <td className="p-3 font-mono text-amber-300 font-bold">{h.liveHoursThisMonth} Hours</td>
                  <td className="p-3 font-mono font-bold text-cyan-300">💎 {h.diamondsEarned.toLocaleString()}</td>
                  <td className="p-3 font-mono">${h.baseSalaryUsd} USD</td>
                  <td className="p-3 font-mono text-emerald-300">${h.diamondIncomeUsd} USD</td>
                  <td className="p-3 font-mono font-black text-amber-300 text-sm">${h.totalPayoutUsd} USD</td>
                  <td className="p-3 text-right">
                    <button
                      onClick={() => showNotification(`Monthly salary settlement executed for ${h.name}`)}
                      className="px-2.5 py-1 bg-cyan-500 text-black font-black text-[11px] rounded-lg hover:bg-cyan-400"
                    >
                      Approve Salary
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
