import React, { useState, useEffect } from 'react';
import { Building, Users, DollarSign, Award, FileSpreadsheet, FileText, Search, Plus, RefreshCw, Edit3, Shield } from 'lucide-react';
import { exportToExcel, exportToPDF } from '../../../lib/exportUtils';
import { ApiClient } from '../../../lib/api';
import { Agency } from '../../../types';

interface AgencyCenterProps {
  showNotification: (msg: string) => void;
  onNavigateToCreateAgency?: () => void;
}

export const AgencyCenter: React.FC<AgencyCenterProps> = ({ showNotification, onNavigateToCreateAgency }) => {
  const [activeSubTab, setActiveSubTab] = useState<'list' | 'members' | 'revenue' | 'settlement'>('list');
  const [agencies, setAgencies] = useState<Agency[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  const loadAgencies = async () => {
    setLoading(true);
    try {
      const data = await ApiClient.getAgencies();
      setAgencies(data);
    } catch (err: any) {
      showNotification(err.message || 'Failed to load agencies');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAgencies();
  }, []);

  const handleExportExcel = () => {
    exportToExcel('Agency_Directory', agencies);
  };

  const handleExportPDF = () => {
    const headers = ['ID', 'Agency Name', 'Owner', 'Code', 'Members', 'Revenue (USD)', 'Commission', 'Pending Payout'];
    const rows = agencies.map(a => [a.id, a.name, a.ownerName, a.code, a.membersCount, `$${a.totalRevenueUsd}`, `${a.commissionRate}%`, `$${a.pendingPayoutUsd}`]);
    exportToPDF('Agency Performance Directory', headers, rows);
  };

  const handleToggleAgencyStatus = async (agency: Agency, newStatus: string) => {
    try {
      await ApiClient.updateAgencyStatus(agency.id, newStatus, 'Admin status update');
      showNotification(`Agency status changed to ${newStatus}`);
      loadAgencies();
    } catch (err: any) {
      showNotification(err.message || 'Status update failed');
    }
  };

  const filteredAgencies = agencies.filter(a => 
    a.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    a.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
    a.ownerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    a.ownerUid.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* HEADER BAR */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
        <div>
          <h3 className="text-base font-black text-white flex items-center gap-2">
            <Building className="w-5 h-5 text-purple-400" /> Agency Operations & Talent Guild Center
          </h3>
          <p className="text-xs text-slate-300">Agency Roster, Commission Rates, Member Host Management & Monthly Settlements</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={loadAgencies} className="p-2 bg-white/10 text-white rounded-xl hover:bg-white/20 transition-all" title="Refresh">
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
          <button onClick={handleExportExcel} className="px-3 py-1.5 bg-emerald-600/80 text-white font-bold text-xs rounded-xl flex items-center gap-1.5">
            <FileSpreadsheet className="w-3.5 h-3.5" /> Excel
          </button>
          <button onClick={handleExportPDF} className="px-3 py-1.5 bg-rose-600/80 text-white font-bold text-xs rounded-xl flex items-center gap-1.5">
            <FileText className="w-3.5 h-3.5" /> PDF
          </button>
          {onNavigateToCreateAgency && (
            <button
              onClick={onNavigateToCreateAgency}
              className="px-3 py-1.5 bg-gradient-to-r from-amber-500 to-yellow-600 text-black font-black text-xs rounded-xl shadow hover:brightness-110 flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" /> Create Host Agency
            </button>
          )}
        </div>
      </div>

      {/* SUB-TABS */}
      <div className="flex gap-2 border-b border-white/10 pb-2 text-xs">
        {[
          { id: 'list', label: 'Agency Directory' },
          { id: 'members', label: 'Bound Agency Hosts' },
          { id: 'revenue', label: 'Revenue & Commission' },
          { id: 'settlement', label: 'Settlement Payouts' }
        ].map(t => (
          <button
            key={t.id}
            onClick={() => setActiveSubTab(t.id as any)}
            className={`px-3.5 py-1.5 rounded-xl font-bold transition-all ${
              activeSubTab === t.id ? 'bg-purple-500 text-white font-black shadow-lg' : 'bg-white/5 text-slate-300 hover:bg-white/10'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* SEARCH BAR */}
      <div className="flex items-center gap-2 bg-black/60 px-3 py-2 rounded-xl border border-white/10 text-xs max-w-md">
        <Search className="w-4 h-4 text-slate-400" />
        <input
          type="text"
          placeholder="Search agency name, owner, code or UID..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="bg-transparent text-white placeholder:text-slate-500 focus:outline-none w-full"
        />
      </div>

      {/* AGENCIES TABLE */}
      <div className="rounded-2xl bg-white/5 border border-white/10 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-black/40 text-slate-300 font-bold uppercase border-b border-white/10">
              <tr>
                <th className="p-3">Agency Name</th>
                <th className="p-3">Code</th>
                <th className="p-3">Owner</th>
                <th className="p-3">Bound Hosts</th>
                <th className="p-3">Total Revenue</th>
                <th className="p-3">Commission %</th>
                <th className="p-3">Pending Settlement</th>
                <th className="p-3">Status</th>
                <th className="p-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-slate-200">
              {filteredAgencies.length > 0 ? (
                filteredAgencies.map(a => (
                  <tr key={a.id} className="hover:bg-white/5">
                    <td className="p-3 font-bold text-white flex items-center gap-2">
                      <img src={a.logoUrl} alt={a.name} className="w-7 h-7 rounded-lg object-cover border border-purple-400" />
                      <div>
                        <p>{a.name}</p>
                        <p className="text-[10px] text-slate-400 font-mono">{a.id}</p>
                      </div>
                    </td>
                    <td className="p-3 font-mono text-amber-300 font-bold">{a.code}</td>
                    <td className="p-3 text-slate-300">
                      <p className="font-bold text-white">{a.ownerName}</p>
                      <p className="text-[10px] text-amber-300/80 font-mono">UID: {a.ownerUid}</p>
                    </td>
                    <td className="p-3 font-bold text-cyan-300">👥 {a.membersCount} Hosts</td>
                    <td className="p-3 font-mono font-bold text-emerald-400">${a.totalRevenueUsd?.toLocaleString() || 0} USD</td>
                    <td className="p-3 font-bold text-amber-300">{a.commissionRate}%</td>
                    <td className="p-3 font-mono font-bold text-purple-300">${a.pendingPayoutUsd?.toLocaleString() || 0} USD</td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase border ${
                        a.status === 'active' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' :
                        'bg-slate-500/20 text-slate-300 border-slate-500/30'
                      }`}>
                        {a.status}
                      </span>
                    </td>
                    <td className="p-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => showNotification(`Settlement processed for ${a.name}`)}
                          className="px-2.5 py-1 bg-purple-500 text-white font-bold text-[11px] rounded-lg hover:bg-purple-400"
                        >
                          Payout
                        </button>
                        {a.status === 'active' ? (
                          <button
                            onClick={() => handleToggleAgencyStatus(a, 'inactive')}
                            className="px-2 py-1 bg-rose-500/20 text-rose-300 text-[10px] font-bold rounded-lg border border-rose-500/30"
                          >
                            Suspend
                          </button>
                        ) : (
                          <button
                            onClick={() => handleToggleAgencyStatus(a, 'active')}
                            className="px-2 py-1 bg-emerald-500/20 text-emerald-300 text-[10px] font-bold rounded-lg border border-emerald-500/30"
                          >
                            Activate
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={9} className="p-8 text-center text-slate-400 text-xs italic">
                    No agencies found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
