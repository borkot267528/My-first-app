/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Gift as GiftIcon, Sparkles, FileSpreadsheet, Plus, Edit2, 
  Trash2, RefreshCw, Search, Filter, Package, AlertCircle, Check
} from 'lucide-react';
import { Gift, GiftInventoryStats } from '../../../types';
import { VirtualGiftService } from '../../../services/VirtualGiftService';
import { exportToExcel } from '../../../lib/exportUtils';

interface GiftCenterProps {
  showNotification: (msg: string) => void;
}

export const GiftCenter: React.FC<GiftCenterProps> = ({ showNotification }) => {
  const [gifts, setGifts] = useState<Gift[]>([]);
  const [stats, setStats] = useState<GiftInventoryStats | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [search, setSearch] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [editingGift, setEditingGift] = useState<Gift | null>(null);

  // Form state for creating or editing
  const [formData, setFormData] = useState<Partial<Gift>>({
    name: '',
    icon: '🎁',
    priceCoins: 100,
    category: 'popular',
    animationType: 'pop',
    svgColor: '#ec4899',
    stockQuantity: -1,
    rarity: 'common',
    diamondYieldRate: 0.5,
    description: ''
  });

  const loadCatalog = async () => {
    try {
      setLoading(true);
      const res = await VirtualGiftService.getInventoryStats();
      setGifts(res.catalog || []);
      setStats(res.stats || null);
    } catch (err: any) {
      showNotification(`Failed to load catalog: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCatalog();
  }, []);

  const handleExport = () => {
    exportToExcel('Virtual_Gift_Inventory_Catalog', gifts);
    showNotification('Catalog exported to Excel successfully.');
  };

  const handleSaveGift = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingGift) {
        await VirtualGiftService.updateGift(editingGift.id, formData);
        showNotification(`Updated gift "${formData.name || editingGift.name}" in inventory.`);
      } else {
        await VirtualGiftService.createGift(formData);
        showNotification(`Created new gift "${formData.name}" in inventory.`);
      }
      setShowAddModal(false);
      setEditingGift(null);
      await loadCatalog();
    } catch (err: any) {
      showNotification(`Error: ${err.message}`);
    }
  };

  const handleDelete = async (giftId: string, name: string) => {
    if (!confirm(`Are you sure you want to remove "${name}" from the inventory?`)) return;
    try {
      await VirtualGiftService.deleteGift(giftId);
      showNotification(`Deleted gift "${name}" from inventory.`);
      await loadCatalog();
    } catch (err: any) {
      showNotification(`Failed to delete gift: ${err.message}`);
    }
  };

  const filteredGifts = gifts.filter(g => {
    const matchesCat = selectedCategory === 'all' || g.category === selectedCategory;
    const matchesSearch = !search.trim() || 
      g.name.toLowerCase().includes(search.toLowerCase()) || 
      (g.description && g.description.toLowerCase().includes(search.toLowerCase()));
    return matchesCat && matchesSearch;
  });

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* HEADER BAR */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
        <div>
          <h3 className="text-base font-black text-white flex items-center gap-2">
            <GiftIcon className="w-5 h-5 text-amber-400" /> Virtual Gift Store & Inventory Center
          </h3>
          <p className="text-xs text-slate-300">Catalog Management, Stock Levels, SVGA Effects & Revenue Commissions</p>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={loadCatalog} 
            className="p-2 bg-white/10 hover:bg-white/20 text-white rounded-xl transition-all"
            title="Reload Inventory"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
          <button onClick={handleExport} className="px-3 py-1.5 bg-emerald-600/80 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 shadow">
            <FileSpreadsheet className="w-3.5 h-3.5" /> Export Catalog
          </button>
          <button 
            onClick={() => {
              setEditingGift(null);
              setFormData({
                name: '',
                icon: '🎁',
                priceCoins: 100,
                category: 'popular',
                animationType: 'pop',
                svgColor: '#ec4899',
                stockQuantity: -1,
                rarity: 'common',
                diamondYieldRate: 0.5,
                description: ''
              });
              setShowAddModal(true);
            }} 
            className="px-3.5 py-1.5 bg-amber-400 hover:bg-amber-300 text-black font-black text-xs rounded-xl shadow flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5" /> Add New Gift
          </button>
        </div>
      </div>

      {/* INVENTORY STATS CARDS */}
      {stats && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10">
            <p className="text-[10px] font-bold uppercase text-slate-400">Total Gift Items</p>
            <p className="text-2xl font-black text-white font-mono mt-1">{stats.totalGifts}</p>
          </div>
          <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10">
            <p className="text-[10px] font-bold uppercase text-slate-400">Categories</p>
            <p className="text-2xl font-black text-purple-300 font-mono mt-1">{stats.totalCategories}</p>
          </div>
          <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10">
            <p className="text-[10px] font-bold uppercase text-slate-400">Limited Stock Units</p>
            <p className="text-2xl font-black text-amber-300 font-mono mt-1">{stats.totalInStock}</p>
          </div>
          <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10">
            <p className="text-[10px] font-bold uppercase text-slate-400">Top Luxury Gift</p>
            <p className="text-sm font-black text-pink-300 truncate mt-2">
              {stats.mostPopularGifts[0]?.name || 'Aura Castle'}
            </p>
          </div>
        </div>
      )}

      {/* FILTER & SEARCH */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-2xl bg-black/40 border border-white/10">
        <div className="flex items-center gap-2 flex-1 min-w-[200px]">
          <Search className="w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search gifts in inventory..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full bg-transparent text-xs text-white placeholder:text-slate-400 focus:outline-none"
          />
        </div>
        <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none">
          {['all', 'popular', 'luxury', 'pk', 'family', 'special'].map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-2.5 py-1 rounded-xl text-xs font-bold capitalize transition-all border ${
                selectedCategory === cat
                  ? 'bg-amber-400 text-black border-amber-300 shadow'
                  : 'bg-white/5 text-slate-300 border-white/10 hover:bg-white/10'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* GIFTS GRID */}
      {loading ? (
        <div className="py-12 text-center text-slate-400">Loading virtual gifts inventory...</div>
      ) : filteredGifts.length === 0 ? (
        <div className="py-12 text-center text-slate-400">No gifts match your filter.</div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {filteredGifts.map(g => {
            const hasStock = g.stockQuantity !== undefined && g.stockQuantity !== -1;
            const rarityStyle = VirtualGiftService.getRarityBadgeStyle(g.rarity);

            return (
              <div key={g.id} className="p-4 rounded-2xl bg-white/5 border border-white/10 flex flex-col justify-between space-y-3 relative group hover:border-amber-400/50 transition-all">
                <div className="flex items-start gap-3">
                  <div className="w-14 h-14 rounded-2xl bg-black/40 border border-white/10 flex items-center justify-center text-3xl shrink-0 group-hover:scale-105 transition-transform">
                    {g.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-bold text-white text-sm truncate">{g.name}</h4>
                    <p className="text-xs text-amber-300 font-mono font-bold">🪙 {g.priceCoins.toLocaleString()} Coins</p>
                    <p className="text-[10px] text-slate-300 line-clamp-1">{g.description || 'Virtual gift'}</p>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[10px] pt-1 border-t border-white/5">
                  <div className="flex items-center gap-1 flex-wrap">
                    <span className="font-bold uppercase px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
                      {g.category}
                    </span>
                    <span className="font-bold uppercase px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                      {g.animationType}
                    </span>
                    {g.rarity && (
                      <span className={`font-bold uppercase px-1.5 py-0.2 rounded border ${rarityStyle.bg} ${rarityStyle.text} ${rarityStyle.border}`}>
                        {g.rarity}
                      </span>
                    )}
                  </div>
                  <span className={`font-mono font-bold ${hasStock ? 'text-amber-400' : 'text-slate-400'}`}>
                    {hasStock ? `${g.stockQuantity} left` : '∞ Stock'}
                  </span>
                </div>

                {/* Card Action Buttons */}
                <div className="flex items-center justify-end gap-1.5 pt-1">
                  <button
                    onClick={() => {
                      setEditingGift(g);
                      setFormData({ ...g });
                      setShowAddModal(true);
                    }}
                    className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-all"
                    title="Edit Gift"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleDelete(g.id, g.name)}
                    className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 transition-all"
                    title="Delete Gift"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* CREATE / EDIT MODAL */}
      {showAddModal && (
        <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-[#150a28] border border-white/20 rounded-3xl p-6 max-w-md w-full space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="font-black text-white text-base">
                {editingGift ? 'Edit Virtual Gift' : 'Add New Gift to Catalog'}
              </h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleSaveGift} className="space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">Gift Name & Emoji Icon</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    required
                    value={formData.icon || '🎁'}
                    onChange={e => setFormData({ ...formData, icon: e.target.value })}
                    className="w-14 bg-black/50 text-center text-xl text-white border border-white/15 rounded-xl p-2"
                  />
                  <input
                    type="text"
                    required
                    placeholder="e.g. Phoenix Wings"
                    value={formData.name || ''}
                    onChange={e => setFormData({ ...formData, name: e.target.value })}
                    className="flex-1 bg-black/50 text-white text-xs border border-white/15 rounded-xl px-3 py-2"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">Price (Coins)</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={formData.priceCoins || 100}
                    onChange={e => setFormData({ ...formData, priceCoins: Number(e.target.value) })}
                    className="w-full bg-black/50 text-white text-xs border border-white/15 rounded-xl px-3 py-2"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">Stock Quantity (-1 for inf)</label>
                  <input
                    type="number"
                    value={formData.stockQuantity ?? -1}
                    onChange={e => setFormData({ ...formData, stockQuantity: Number(e.target.value) })}
                    className="w-full bg-black/50 text-white text-xs border border-white/15 rounded-xl px-3 py-2"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">Category</label>
                  <select
                    value={formData.category || 'popular'}
                    onChange={e => setFormData({ ...formData, category: e.target.value as any })}
                    className="w-full bg-black/50 text-white text-xs border border-white/15 rounded-xl px-3 py-2"
                  >
                    <option value="popular">Popular 🔥</option>
                    <option value="luxury">Luxury 💎</option>
                    <option value="pk">PK Battle ⚔️</option>
                    <option value="family">Family Guild 🛡️</option>
                    <option value="special">Special 👑</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">Animation Type</label>
                  <select
                    value={formData.animationType || 'pop'}
                    onChange={e => setFormData({ ...formData, animationType: e.target.value as any })}
                    className="w-full bg-black/50 text-white text-xs border border-white/15 rounded-xl px-3 py-2"
                  >
                    <option value="pop">Pop Effect</option>
                    <option value="banner">Banner Stream</option>
                    <option value="fullscreen">Fullscreen SVGA</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">Description</label>
                <textarea
                  rows={2}
                  placeholder="Short description of gift animation and effects..."
                  value={formData.description || ''}
                  onChange={e => setFormData({ ...formData, description: e.target.value })}
                  className="w-full bg-black/50 text-white text-xs border border-white/15 rounded-xl px-3 py-2"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-black font-black text-xs shadow-lg"
                >
                  {editingGift ? 'Update Gift' : 'Create Gift'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
