/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Globe, Plus, Search, RefreshCw, Edit2, Trash2, CheckCircle2, 
  XCircle, AlertTriangle, ShieldCheck, DollarSign, Phone, Languages, 
  Clock, CreditCard, Users, ArrowUpDown, ChevronRight, Check, X,
  Shield, ToggleLeft, ToggleRight, Sparkles, Filter, Info, Lock
} from 'lucide-react';
import { ApiClient } from '../../../lib/api';
import { Country, CountryFormData } from '../../../types';
import { useApp } from '../../../context/AppContext';

const PRESET_FLAGS = [
  { flag: '🇧🇩', name: 'Bangladesh', code: 'BD', dial: '+880', cur: 'BDT', sym: '৳', lang: 'Bengali', tz: 'Asia/Dhaka' },
  { flag: '🇮🇳', name: 'India', code: 'IN', dial: '+91', cur: 'INR', sym: '₹', lang: 'Hindi', tz: 'Asia/Kolkata' },
  { flag: '🇺🇸', name: 'United States', code: 'US', dial: '+1', cur: 'USD', sym: '$', lang: 'English', tz: 'America/New_York' },
  { flag: '🇸🇦', name: 'Saudi Arabia', code: 'SA', dial: '+966', cur: 'SAR', sym: '﷼', lang: 'Arabic', tz: 'Asia/Riyadh' },
  { flag: '🇦🇪', name: 'United Arab Emirates', code: 'AE', dial: '+971', cur: 'AED', sym: 'د.إ', lang: 'Arabic', tz: 'Asia/Dubai' },
  { flag: '🇬🇧', name: 'United Kingdom', code: 'GB', dial: '+44', cur: 'GBP', sym: '£', lang: 'English', tz: 'Europe/London' },
  { flag: '🇵🇰', name: 'Pakistan', code: 'PK', dial: '+92', cur: 'PKR', sym: '₨', lang: 'Urdu', tz: 'Asia/Karachi' },
  { flag: '🇨🇦', name: 'Canada', code: 'CA', dial: '+1', cur: 'CAD', sym: 'CA$', lang: 'English', tz: 'America/Toronto' },
  { flag: '🇩🇪', name: 'Germany', code: 'DE', dial: '+49', cur: 'EUR', sym: '€', lang: 'German', tz: 'Europe/Berlin' },
  { flag: '🇯🇵', name: 'Japan', code: 'JP', dial: '+81', cur: 'JPY', sym: '¥', lang: 'Japanese', tz: 'Asia/Tokyo' },
  { flag: '🇸🇬', name: 'Singapore', code: 'SG', dial: '+65', cur: 'SGD', sym: 'S$', lang: 'English', tz: 'Asia/Singapore' },
  { flag: '🇲🇾', name: 'Malaysia', code: 'MY', dial: '+60', cur: 'MYR', sym: 'RM', lang: 'Malay', tz: 'Asia/Kuala_Lumpur' },
  { flag: '🇮🇩', name: 'Indonesia', code: 'ID', dial: '+62', cur: 'IDR', sym: 'Rp', lang: 'Indonesian', tz: 'Asia/Jakarta' },
  { flag: '🇵🇭', name: 'Philippines', code: 'PH', dial: '+63', cur: 'PHP', sym: '₱', lang: 'Filipino', tz: 'Asia/Manila' },
  { flag: '🇧🇷', name: 'Brazil', code: 'BR', dial: '+55', cur: 'BRL', sym: 'R$', lang: 'Portuguese', tz: 'America/Sao_Paulo' },
  { flag: '🇹🇷', name: 'Turkey', code: 'TR', dial: '+90', cur: 'TRY', sym: '₺', lang: 'Turkish', tz: 'Europe/Istanbul' },
  { flag: '🇪🇬', name: 'Egypt', code: 'EG', dial: '+20', cur: 'EGP', sym: 'E£', lang: 'Arabic', tz: 'Africa/Cairo' },
  { flag: '🌐', name: 'Global / International', code: 'GL', dial: '+0', cur: 'USD', sym: '$', lang: 'English', tz: 'UTC' }
];

const SUGGESTED_PAYMENTS = [
  'bKash', 'Nagad', 'Rocket', 'Upay', 'UPI', 'Paytm', 'PhonePe', 'Google Pay',
  'Binance USDT', 'Credit/Debit Card', 'PayPal', 'Apple Pay', 'Stripe', 'Mada',
  'STC Pay', 'Urpay', 'e& money', 'Careem Pay', 'JazzCash', 'Easypaisa', 'SadaPay',
  'Interac e-Transfer', 'SEPA Bank Transfer', 'Sofort', 'PayPay', 'Bank Transfer'
];

interface CountryWithUsers extends Country {
  associatedUsersCount?: number;
}

export const CountryManagementCenter: React.FC = () => {
  const { showNotification } = useApp();

  const [countries, setCountries] = useState<CountryWithUsers[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'enabled' | 'disabled'>('all');

  // Modal states
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [editingCountry, setEditingCountry] = useState<Country | null>(null);
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Delete modal states
  const [countryToDelete, setCountryToDelete] = useState<CountryWithUsers | null>(null);
  const [deleteModalOpen, setDeleteModalOpen] = useState<boolean>(false);
  const [deleting, setDeleting] = useState<boolean>(false);

  // Form State
  const initialFormState: CountryFormData = {
    name: '',
    iso2: '',
    iso3: '',
    dialCode: '',
    flag: '🌐',
    currencyName: '',
    currencyCode: '',
    currencySymbol: '$',
    defaultLanguage: 'English',
    timezone: 'UTC',
    status: 'enabled',
    registrationAllowed: true,
    loginAllowed: true,
    rechargeAllowed: true,
    withdrawalAllowed: true,
    voiceRoomAllowed: true,
    paymentMethods: ['Credit/Debit Card', 'PayPal'],
    withdrawalMethods: ['Bank Transfer', 'PayPal'],
    sortOrder: 1
  };

  const [formData, setFormData] = useState<CountryFormData>(initialFormState);
  const [newPaymentTag, setNewPaymentTag] = useState<string>('');
  const [newWithdrawTag, setNewWithdrawTag] = useState<string>('');

  const loadCountries = async (isSilent = false) => {
    try {
      if (!isSilent) setLoading(true);
      else setRefreshing(true);

      const res = await ApiClient.getAdminCountries({
        status: statusFilter,
        search: searchQuery
      });
      setCountries(res.data || []);
    } catch (err: any) {
      showNotification(err.message || 'Failed to load countries from database');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadCountries();

    const handleUpdate = () => {
      loadCountries(true);
    };

    window.addEventListener('country_data_updated', handleUpdate);
    return () => window.removeEventListener('country_data_updated', handleUpdate);
  }, [statusFilter, searchQuery]);

  // Open Add Modal
  const handleOpenAdd = () => {
    setEditingCountry(null);
    setFormData({
      ...initialFormState,
      sortOrder: countries.length + 1
    });
    setFormError(null);
    setIsModalOpen(true);
  };

  // Open Edit Modal
  const handleOpenEdit = (c: Country) => {
    setEditingCountry(c);
    setFormData({
      name: c.name,
      iso2: c.iso2,
      iso3: c.iso3,
      dialCode: c.dialCode,
      flag: c.flag,
      currencyName: c.currencyName,
      currencyCode: c.currencyCode,
      currencySymbol: c.currencySymbol,
      defaultLanguage: c.defaultLanguage,
      timezone: c.timezone,
      status: c.status,
      registrationAllowed: c.registrationAllowed !== false,
      loginAllowed: c.loginAllowed !== false,
      rechargeAllowed: c.rechargeAllowed !== false,
      withdrawalAllowed: c.withdrawalAllowed !== false,
      voiceRoomAllowed: c.voiceRoomAllowed !== false,
      paymentMethods: c.paymentMethods || [],
      withdrawalMethods: c.withdrawalMethods || c.paymentMethods || [],
      sortOrder: c.sortOrder ?? 1
    });
    setFormError(null);
    setIsModalOpen(true);
  };

  // Auto-fill from preset
  const handleSelectPreset = (preset: typeof PRESET_FLAGS[0]) => {
    setFormData(prev => ({
      ...prev,
      name: prev.name || preset.name,
      flag: preset.flag,
      iso2: preset.code,
      iso3: preset.code === 'US' ? 'USA' : preset.code === 'BD' ? 'BGD' : preset.code === 'IN' ? 'IND' : preset.code === 'SA' ? 'SAU' : preset.code === 'AE' ? 'ARE' : `${preset.code}X`,
      dialCode: preset.dial,
      currencyCode: preset.cur,
      currencySymbol: preset.sym,
      currencyName: `${preset.name} Currency`,
      defaultLanguage: preset.lang,
      timezone: preset.tz
    }));
  };

  // Add / Remove Payment Tags
  const handleAddPaymentTag = (tag: string) => {
    const trimmed = tag.trim();
    if (!trimmed) return;
    if (!formData.paymentMethods.includes(trimmed)) {
      setFormData(prev => ({
        ...prev,
        paymentMethods: [...prev.paymentMethods, trimmed]
      }));
    }
    setNewPaymentTag('');
  };

  const handleRemovePaymentTag = (tag: string) => {
    setFormData(prev => ({
      ...prev,
      paymentMethods: prev.paymentMethods.filter(t => t !== tag)
    }));
  };

  // Add / Remove Withdrawal Tags
  const handleAddWithdrawTag = (tag: string) => {
    const trimmed = tag.trim();
    if (!trimmed) return;
    const current = formData.withdrawalMethods || [];
    if (!current.includes(trimmed)) {
      setFormData(prev => ({
        ...prev,
        withdrawalMethods: [...current, trimmed]
      }));
    }
    setNewWithdrawTag('');
  };

  const handleRemoveWithdrawTag = (tag: string) => {
    const current = formData.withdrawalMethods || [];
    setFormData(prev => ({
      ...prev,
      withdrawalMethods: current.filter(t => t !== tag)
    }));
  };

  // Save Country Form
  const handleSaveCountry = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    // Validation
    if (!formData.name.trim()) {
      setFormError('Please enter a country name');
      return;
    }
    if (!formData.iso2.trim() || formData.iso2.trim().length !== 2) {
      setFormError('ISO 2-letter code must be exactly 2 letters (e.g. BD, US)');
      return;
    }
    if (!formData.iso3.trim() || formData.iso3.trim().length !== 3) {
      setFormError('ISO 3-letter code must be exactly 3 letters (e.g. BGD, USA)');
      return;
    }
    if (!formData.dialCode.trim() || !formData.dialCode.startsWith('+')) {
      setFormError('Dial code must start with "+" (e.g. +880, +1)');
      return;
    }
    if (!formData.currencyCode.trim()) {
      setFormError('Currency code is required (e.g. BDT, USD)');
      return;
    }
    if (!formData.currencySymbol.trim()) {
      setFormError('Currency symbol is required (e.g. ৳, $)');
      return;
    }

    try {
      setSubmitting(true);
      if (editingCountry) {
        await ApiClient.updateCountry(editingCountry.id, formData);
        showNotification(`✅ Country "${formData.name}" updated successfully!`);
      } else {
        await ApiClient.createCountry(formData);
        showNotification(`🎉 Country "${formData.name}" created successfully!`);
      }
      setIsModalOpen(false);
      loadCountries(true);
    } catch (err: any) {
      setFormError(err.message || 'Failed to save country');
    } finally {
      setSubmitting(false);
    }
  };

  // Toggle Status
  const handleToggleStatus = async (c: Country) => {
    const nextStatus = c.status === 'enabled' ? 'disabled' : 'enabled';
    try {
      await ApiClient.toggleCountryStatus(c.id, nextStatus);
      showNotification(`Country "${c.name}" is now ${nextStatus.toUpperCase()}`);
      loadCountries(true);
    } catch (err: any) {
      showNotification(err.message || 'Failed to update country status');
    }
  };

  // Delete Country Check
  const handleInitiateDelete = (c: CountryWithUsers) => {
    setCountryToDelete(c);
    setDeleteModalOpen(true);
  };

  const handleConfirmDelete = async () => {
    if (!countryToDelete) return;
    try {
      setDeleting(true);
      const res = await ApiClient.deleteCountry(countryToDelete.id);
      showNotification(res.message || `Country "${countryToDelete.name}" deleted.`);
      setDeleteModalOpen(false);
      setCountryToDelete(null);
      loadCountries(true);
    } catch (err: any) {
      showNotification(err.message || 'Failed to delete country');
    } finally {
      setDeleting(false);
    }
  };

  const handleDisableInstead = async () => {
    if (!countryToDelete) return;
    try {
      setDeleting(true);
      await ApiClient.toggleCountryStatus(countryToDelete.id, 'disabled');
      showNotification(`Country "${countryToDelete.name}" disabled safely.`);
      setDeleteModalOpen(false);
      setCountryToDelete(null);
      loadCountries(true);
    } catch (err: any) {
      showNotification(err.message || 'Failed to disable country');
    } finally {
      setDeleting(false);
    }
  };

  const enabledCount = countries.filter(c => c.status === 'enabled').length;
  const disabledCount = countries.filter(c => c.status === 'disabled').length;
  const totalUsersAssociated = countries.reduce((acc, c) => acc + (c.associatedUsersCount || 0), 0);

  return (
    <div className="space-y-6 text-slate-100">
      {/* Top Banner / Metrics */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950/70 border border-slate-700/60 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-8 -translate-y-8 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6 relative z-10">
          <div>
            <div className="flex items-center gap-2.5 mb-2">
              <span className="p-2 bg-emerald-500/20 text-emerald-400 rounded-xl border border-emerald-500/30 shadow-inner">
                <Globe className="w-6 h-6" />
              </span>
              <div>
                <h2 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
                  Country Management System
                  <span className="px-2.5 py-0.5 text-xs font-semibold uppercase tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-full">
                    Production Database
                  </span>
                </h2>
                <p className="text-sm text-slate-400">
                  Manage platform geographical jurisdictions, currency symbols, dial codes, and country-specific feature authorizations.
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => loadCountries(true)}
              disabled={refreshing}
              className="px-4 py-2.5 bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-slate-300 hover:text-white rounded-xl text-sm font-medium flex items-center gap-2 transition shadow-sm disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin text-emerald-400' : ''}`} />
              Sync Database
            </button>

            <button
              onClick={handleOpenAdd}
              className="px-5 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-semibold rounded-xl text-sm flex items-center gap-2 shadow-lg shadow-emerald-500/20 transition transform active:scale-95"
            >
              <Plus className="w-4 h-4 text-slate-950" />
              Add Country
            </button>
          </div>
        </div>

        {/* Metric Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 pt-6 border-t border-slate-700/50">
          <div className="bg-slate-800/60 border border-slate-700/50 rounded-xl p-3.5 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <div className="text-2xl font-bold text-white">{countries.length}</div>
              <div className="text-xs text-slate-400 font-medium">Total Countries</div>
            </div>
          </div>

          <div className="bg-slate-800/60 border border-slate-700/50 rounded-xl p-3.5 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <div className="text-2xl font-bold text-emerald-400">{enabledCount}</div>
              <div className="text-xs text-slate-400 font-medium">Active & Enabled</div>
            </div>
          </div>

          <div className="bg-slate-800/60 border border-slate-700/50 rounded-xl p-3.5 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-rose-500/20 text-rose-400 flex items-center justify-center font-bold">
              <XCircle className="w-5 h-5" />
            </div>
            <div>
              <div className="text-2xl font-bold text-rose-400">{disabledCount}</div>
              <div className="text-xs text-slate-400 font-medium">Disabled / Restricted</div>
            </div>
          </div>

          <div className="bg-slate-800/60 border border-slate-700/50 rounded-xl p-3.5 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <div className="text-2xl font-bold text-amber-300">{totalUsersAssociated}</div>
              <div className="text-xs text-slate-400 font-medium">Associated Users</div>
            </div>
          </div>
        </div>
      </div>

      {/* Filter and Search Controls */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by country, code, currency..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-800/80 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
          <span className="text-xs text-slate-400 font-medium hidden sm:inline">Status Filter:</span>
          <div className="inline-flex rounded-xl bg-slate-800 p-1 border border-slate-700/70">
            <button
              onClick={() => setStatusFilter('all')}
              className={`px-3 py-1 text-xs font-semibold rounded-lg transition ${
                statusFilter === 'all'
                  ? 'bg-emerald-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              All ({countries.length})
            </button>
            <button
              onClick={() => setStatusFilter('enabled')}
              className={`px-3 py-1 text-xs font-semibold rounded-lg transition ${
                statusFilter === 'enabled'
                  ? 'bg-emerald-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Enabled ({enabledCount})
            </button>
            <button
              onClick={() => setStatusFilter('disabled')}
              className={`px-3 py-1 text-xs font-semibold rounded-lg transition ${
                statusFilter === 'disabled'
                  ? 'bg-rose-500 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Disabled ({disabledCount})
            </button>
          </div>
        </div>
      </div>

      {/* Main Countries Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        {loading ? (
          <div className="py-20 flex flex-col items-center justify-center text-slate-400">
            <RefreshCw className="w-8 h-8 animate-spin text-emerald-400 mb-3" />
            <p className="text-sm">Synchronizing country database records...</p>
          </div>
        ) : countries.length === 0 ? (
          <div className="py-20 text-center px-4">
            <Globe className="w-12 h-12 text-slate-600 mx-auto mb-3" />
            <h3 className="text-lg font-semibold text-white">No countries found</h3>
            <p className="text-sm text-slate-400 max-w-md mx-auto mt-1 mb-5">
              {searchQuery ? `No results matching "${searchQuery}". Try clearing the search query.` : 'There are currently no countries registered in the database.'}
            </p>
            <button
              onClick={handleOpenAdd}
              className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-xl text-sm font-semibold transition"
            >
              Add First Country
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="bg-slate-800/80 border-b border-slate-700/60 text-xs font-semibold text-slate-300 uppercase tracking-wider">
                  <th className="py-3.5 px-4 w-12 text-center">#</th>
                  <th className="py-3.5 px-4">Country & Region</th>
                  <th className="py-3.5 px-3">ISO Codes</th>
                  <th className="py-3.5 px-3">Dial Code</th>
                  <th className="py-3.5 px-3">Currency</th>
                  <th className="py-3.5 px-4 text-center">Feature Permissions</th>
                  <th className="py-3.5 px-3">Payment Methods</th>
                  <th className="py-3.5 px-3 text-center">Users</th>
                  <th className="py-3.5 px-4 text-center">Status</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {countries.map((c, index) => {
                  const isEnabled = c.status === 'enabled';
                  const usersCount = c.associatedUsersCount || 0;

                  return (
                    <tr
                      key={c.id}
                      className={`hover:bg-slate-800/40 transition ${
                        !isEnabled ? 'bg-slate-950/40 opacity-80' : ''
                      }`}
                    >
                      {/* Sort order / Index */}
                      <td className="py-4 px-4 text-center text-xs font-mono text-slate-500">
                        {c.sortOrder !== undefined ? c.sortOrder : index + 1}
                      </td>

                      {/* Flag + Name + Details */}
                      <td className="py-4 px-4">
                        <div className="flex items-center gap-3">
                          <span className="text-2xl select-none" title={c.name}>
                            {c.flag || '🌐'}
                          </span>
                          <div>
                            <div className="font-semibold text-white flex items-center gap-1.5">
                              {c.name}
                              {!isEnabled && (
                                <span className="text-[10px] uppercase font-bold px-1.5 py-0.2 bg-rose-500/20 text-rose-400 border border-rose-500/30 rounded">
                                  Disabled
                                </span>
                              )}
                            </div>
                            <div className="text-xs text-slate-400 flex items-center gap-2 mt-0.5">
                              <span>🗣 {c.defaultLanguage || 'English'}</span>
                              <span>•</span>
                              <span>🕒 {c.timezone || 'UTC'}</span>
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* ISO Codes */}
                      <td className="py-4 px-3">
                        <div className="flex items-center gap-1.5 font-mono text-xs">
                          <span className="px-2 py-0.5 bg-slate-800 border border-slate-700 rounded text-amber-300 font-bold">
                            {c.iso2 || c.countryCode}
                          </span>
                          <span className="px-1.5 py-0.5 bg-slate-800/70 border border-slate-700/60 rounded text-slate-400">
                            {c.iso3}
                          </span>
                        </div>
                      </td>

                      {/* Dial Code */}
                      <td className="py-4 px-3">
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-indigo-500/10 border border-indigo-500/30 rounded text-xs font-mono text-indigo-300 font-medium">
                          <Phone className="w-3 h-3 text-indigo-400" />
                          {c.dialCode}
                        </span>
                      </td>

                      {/* Currency */}
                      <td className="py-4 px-3">
                        <div>
                          <div className="font-mono text-xs font-bold text-emerald-400 flex items-center gap-1">
                            <span className="text-white font-serif">{c.currencySymbol}</span>
                            {c.currencyCode}
                          </div>
                          <div className="text-[11px] text-slate-400 truncate max-w-[110px]" title={c.currencyName}>
                            {c.currencyName}
                          </div>
                        </div>
                      </td>

                      {/* Feature Matrix */}
                      <td className="py-4 px-4 text-center">
                        <div className="inline-flex items-center gap-1 bg-slate-800/60 p-1 rounded-lg border border-slate-700/60 text-[11px]">
                          <span 
                            title={`Registration: ${c.registrationAllowed ? 'Allowed' : 'Blocked'}`}
                            className={`px-1.5 py-0.5 rounded font-medium ${c.registrationAllowed ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-400'}`}
                          >
                            Reg
                          </span>
                          <span 
                            title={`Login: ${c.loginAllowed ? 'Allowed' : 'Blocked'}`}
                            className={`px-1.5 py-0.5 rounded font-medium ${c.loginAllowed ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-400'}`}
                          >
                            Auth
                          </span>
                          <span 
                            title={`Recharge: ${c.rechargeAllowed ? 'Allowed' : 'Blocked'}`}
                            className={`px-1.5 py-0.5 rounded font-medium ${c.rechargeAllowed ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-400'}`}
                          >
                            Pay
                          </span>
                          <span 
                            title={`Withdrawal: ${c.withdrawalAllowed ? 'Allowed' : 'Blocked'}`}
                            className={`px-1.5 py-0.5 rounded font-medium ${c.withdrawalAllowed ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-400'}`}
                          >
                            Out
                          </span>
                          <span 
                            title={`Voice Rooms: ${c.voiceRoomAllowed ? 'Allowed' : 'Blocked'}`}
                            className={`px-1.5 py-0.5 rounded font-medium ${c.voiceRoomAllowed ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-400'}`}
                          >
                            Room
                          </span>
                        </div>
                      </td>

                      {/* Payment Methods */}
                      <td className="py-4 px-3">
                        <div className="flex flex-wrap gap-1 max-w-[170px]">
                          {(c.paymentMethods && c.paymentMethods.length > 0) ? (
                            c.paymentMethods.slice(0, 2).map((m, i) => (
                              <span key={i} className="px-1.5 py-0.5 bg-slate-800 border border-slate-700 rounded text-[11px] text-slate-300">
                                {m}
                              </span>
                            ))
                          ) : (
                            <span className="text-xs text-slate-500 italic">None</span>
                          )}
                          {c.paymentMethods && c.paymentMethods.length > 2 && (
                            <span className="px-1 py-0.5 bg-slate-800 border border-slate-700 rounded text-[10px] text-slate-400 font-mono">
                              +{c.paymentMethods.length - 2}
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Associated Users */}
                      <td className="py-4 px-3 text-center">
                        <span 
                          className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold ${
                            usersCount > 0 
                              ? 'bg-blue-500/15 text-blue-300 border border-blue-500/30'
                              : 'bg-slate-800 text-slate-400 border border-slate-700'
                          }`}
                          title={`${usersCount} users associated with ${c.name}`}
                        >
                          <Users className="w-3 h-3" />
                          {usersCount}
                        </span>
                      </td>

                      {/* Status Toggle */}
                      <td className="py-4 px-4 text-center">
                        <button
                          onClick={() => handleToggleStatus(c)}
                          className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold transition ${
                            isEnabled
                              ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/25'
                              : 'bg-rose-500/15 text-rose-400 border border-rose-500/30 hover:bg-rose-500/25'
                          }`}
                        >
                          {isEnabled ? (
                            <>
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              Enabled
                            </>
                          ) : (
                            <>
                              <XCircle className="w-3.5 h-3.5" />
                              Disabled
                            </>
                          )}
                        </button>
                      </td>

                      {/* Actions */}
                      <td className="py-4 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleOpenEdit(c)}
                            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-700/60 rounded-lg transition"
                            title="Edit Country Configuration"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() => handleInitiateDelete(c)}
                            className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition"
                            title="Delete Country"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ==================================================== */}
      {/* ADD / EDIT COUNTRY MODAL                             */}
      {/* ==================================================== */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
          <div className="bg-slate-900 border border-slate-700/80 rounded-2xl max-w-2xl w-full shadow-2xl overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="px-6 py-4 bg-slate-800/80 border-b border-slate-700 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="p-2 bg-emerald-500/20 text-emerald-400 rounded-xl border border-emerald-500/30">
                  <Globe className="w-5 h-5" />
                </span>
                <div>
                  <h3 className="text-lg font-bold text-white">
                    {editingCountry ? `Edit Country: ${editingCountry.name}` : 'Add New Country'}
                  </h3>
                  <p className="text-xs text-slate-400">
                    Configure ISO specifications, payment integrations, and regional allowances.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-700/50 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body Form */}
            <form onSubmit={handleSaveCountry} className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
              {formError && (
                <div className="p-3 bg-rose-500/15 border border-rose-500/30 rounded-xl text-rose-300 text-sm flex items-start gap-2.5">
                  <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                  <div>{formError}</div>
                </div>
              )}

              {/* Preset quick selector for rapid configuration */}
              {!editingCountry && (
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-2">
                    ⚡ Quick Preset Selection:
                  </label>
                  <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto p-2 bg-slate-950/60 rounded-xl border border-slate-800">
                    {PRESET_FLAGS.map(p => (
                      <button
                        key={p.code}
                        type="button"
                        onClick={() => handleSelectPreset(p)}
                        className="px-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-xs text-slate-200 flex items-center gap-1.5 transition active:scale-95"
                      >
                        <span>{p.flag}</span>
                        <span>{p.name}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Row 1: Name & Flag */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Country Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Bangladesh, United States"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-3.5 py-2 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Flag (Emoji or URL) *
                  </label>
                  <div className="flex items-center gap-2">
                    <span className="w-10 h-10 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-xl shrink-0 select-none">
                      {formData.flag || '🌐'}
                    </span>
                    <input
                      type="text"
                      placeholder="🇧🇩"
                      value={formData.flag}
                      onChange={(e) => setFormData({ ...formData, flag: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>
              </div>

              {/* Row 2: ISO2, ISO3, Dial Code */}
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    ISO 2-letter Code *
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={2}
                    placeholder="BD"
                    value={formData.iso2}
                    onChange={(e) => setFormData({ ...formData, iso2: e.target.value.toUpperCase() })}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-sm font-mono uppercase text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    ISO 3-letter Code *
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={3}
                    placeholder="BGD"
                    value={formData.iso3}
                    onChange={(e) => setFormData({ ...formData, iso3: e.target.value.toUpperCase() })}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-sm font-mono uppercase text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Dial Code *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="+880"
                    value={formData.dialCode}
                    onChange={(e) => setFormData({ ...formData, dialCode: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-sm font-mono text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              {/* Row 3: Currency Info */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Currency Code *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="BDT"
                    value={formData.currencyCode}
                    onChange={(e) => setFormData({ ...formData, currencyCode: e.target.value.toUpperCase() })}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-sm font-mono uppercase text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Currency Symbol *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="৳"
                    value={formData.currencySymbol}
                    onChange={(e) => setFormData({ ...formData, currencySymbol: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Currency Name
                  </label>
                  <input
                    type="text"
                    placeholder="Bangladeshi Taka"
                    value={formData.currencyName}
                    onChange={(e) => setFormData({ ...formData, currencyName: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              {/* Row 4: Language, Timezone, Sort Order */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Default Language
                  </label>
                  <input
                    type="text"
                    placeholder="Bengali, English"
                    value={formData.defaultLanguage}
                    onChange={(e) => setFormData({ ...formData, defaultLanguage: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Time Zone
                  </label>
                  <input
                    type="text"
                    placeholder="Asia/Dhaka"
                    value={formData.timezone}
                    onChange={(e) => setFormData({ ...formData, timezone: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Sort Order
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={formData.sortOrder}
                    onChange={(e) => setFormData({ ...formData, sortOrder: parseInt(e.target.value, 10) || 1 })}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              {/* Status & Permissions Grid */}
              <div className="bg-slate-950/60 rounded-xl p-4 border border-slate-800 space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <div>
                    <div className="font-semibold text-white text-sm">Country Status</div>
                    <div className="text-xs text-slate-400">Master switch to enable or disable platform operations for this country</div>
                  </div>
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, status: formData.status === 'enabled' ? 'disabled' : 'enabled' })}
                      className={`px-3 py-1.5 rounded-lg font-semibold text-xs transition flex items-center gap-1.5 ${
                        formData.status === 'enabled'
                          ? 'bg-emerald-500 text-slate-950'
                          : 'bg-rose-500 text-white'
                      }`}
                    >
                      {formData.status === 'enabled' ? <Check className="w-3.5 h-3.5" /> : <X className="w-3.5 h-3.5" />}
                      {formData.status === 'enabled' ? 'Enabled' : 'Disabled'}
                    </button>
                  </div>
                </div>

                <div>
                  <div className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                    Regional Feature Permissions
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    <label className="flex items-center gap-2.5 p-2 bg-slate-900 rounded-lg border border-slate-800 hover:border-slate-700 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.registrationAllowed}
                        onChange={(e) => setFormData({ ...formData, registrationAllowed: e.target.checked })}
                        className="rounded border-slate-700 text-emerald-500 focus:ring-emerald-500 w-4 h-4 bg-slate-800"
                      />
                      <span className="text-xs text-slate-200">Registration</span>
                    </label>

                    <label className="flex items-center gap-2.5 p-2 bg-slate-900 rounded-lg border border-slate-800 hover:border-slate-700 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.loginAllowed}
                        onChange={(e) => setFormData({ ...formData, loginAllowed: e.target.checked })}
                        className="rounded border-slate-700 text-emerald-500 focus:ring-emerald-500 w-4 h-4 bg-slate-800"
                      />
                      <span className="text-xs text-slate-200">User Login</span>
                    </label>

                    <label className="flex items-center gap-2.5 p-2 bg-slate-900 rounded-lg border border-slate-800 hover:border-slate-700 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.rechargeAllowed}
                        onChange={(e) => setFormData({ ...formData, rechargeAllowed: e.target.checked })}
                        className="rounded border-slate-700 text-emerald-500 focus:ring-emerald-500 w-4 h-4 bg-slate-800"
                      />
                      <span className="text-xs text-slate-200">Coin Recharge</span>
                    </label>

                    <label className="flex items-center gap-2.5 p-2 bg-slate-900 rounded-lg border border-slate-800 hover:border-slate-700 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.withdrawalAllowed}
                        onChange={(e) => setFormData({ ...formData, withdrawalAllowed: e.target.checked })}
                        className="rounded border-slate-700 text-emerald-500 focus:ring-emerald-500 w-4 h-4 bg-slate-800"
                      />
                      <span className="text-xs text-slate-200">Withdrawal</span>
                    </label>

                    <label className="flex items-center gap-2.5 p-2 bg-slate-900 rounded-lg border border-slate-800 hover:border-slate-700 cursor-pointer sm:col-span-2">
                      <input
                        type="checkbox"
                        checked={formData.voiceRoomAllowed}
                        onChange={(e) => setFormData({ ...formData, voiceRoomAllowed: e.target.checked })}
                        className="rounded border-slate-700 text-emerald-500 focus:ring-emerald-500 w-4 h-4 bg-slate-800"
                      />
                      <span className="text-xs text-slate-200">Voice Party Rooms Access</span>
                    </label>
                  </div>
                </div>
              </div>

              {/* Supported Payment Methods for Recharge */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Supported Recharge Payment Methods
                </label>
                <div className="flex flex-wrap gap-1.5 mb-2 min-h-[36px] p-2 bg-slate-800/80 rounded-xl border border-slate-700">
                  {formData.paymentMethods.map((m, i) => (
                    <span
                      key={i}
                      className="px-2.5 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-lg text-xs flex items-center gap-1.5"
                    >
                      {m}
                      <button
                        type="button"
                        onClick={() => handleRemovePaymentTag(m)}
                        className="text-emerald-400 hover:text-white"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </span>
                  ))}
                </div>

                {/* Tag Input */}
                <div className="flex items-center gap-2 mb-2">
                  <input
                    type="text"
                    placeholder="Add payment method (e.g. bKash, UPI, Stripe)"
                    value={newPaymentTag}
                    onChange={(e) => setNewPaymentTag(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddPaymentTag(newPaymentTag);
                      }
                    }}
                    className="w-full px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500"
                  />
                  <button
                    type="button"
                    onClick={() => handleAddPaymentTag(newPaymentTag)}
                    className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 rounded-xl text-xs font-semibold text-white shrink-0"
                  >
                    Add
                  </button>
                </div>

                {/* Suggestions */}
                <div className="flex flex-wrap gap-1">
                  <span className="text-[11px] text-slate-500 py-0.5">Quick add:</span>
                  {SUGGESTED_PAYMENTS.slice(0, 8).map(s => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => handleAddPaymentTag(s)}
                      className="px-2 py-0.5 bg-slate-800/60 hover:bg-slate-700 border border-slate-700/60 rounded text-[11px] text-slate-400 hover:text-white transition"
                    >
                      + {s}
                    </button>
                  ))}
                </div>
              </div>

              {/* Supported Withdrawal Methods */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Supported Withdrawal Methods
                </label>
                <div className="flex flex-wrap gap-1.5 mb-2 min-h-[36px] p-2 bg-slate-800/80 rounded-xl border border-slate-700">
                  {(formData.withdrawalMethods || []).map((m, i) => (
                    <span
                      key={i}
                      className="px-2.5 py-1 bg-blue-500/20 text-blue-300 border border-blue-500/30 rounded-lg text-xs flex items-center gap-1.5"
                    >
                      {m}
                      <button
                        type="button"
                        onClick={() => handleRemoveWithdrawTag(m)}
                        className="text-blue-400 hover:text-white"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </span>
                  ))}
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    placeholder="Add withdrawal method (e.g. bKash, Bank Transfer)"
                    value={newWithdrawTag}
                    onChange={(e) => setNewWithdrawTag(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddWithdrawTag(newWithdrawTag);
                      }
                    }}
                    className="w-full px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500"
                  />
                  <button
                    type="button"
                    onClick={() => handleAddWithdrawTag(newWithdrawTag)}
                    className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 rounded-xl text-xs font-semibold text-white shrink-0"
                  >
                    Add
                  </button>
                </div>
              </div>

              {/* Modal Footer Buttons */}
              <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl text-sm font-medium text-slate-300 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-6 py-2 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-semibold rounded-xl text-sm transition shadow-lg shadow-emerald-500/20 disabled:opacity-50"
                >
                  {submitting ? 'Saving...' : editingCountry ? 'Update Country' : 'Create Country'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* DELETE / DISABLE SAFETY MODAL                        */}
      {/* ==================================================== */}
      {deleteModalOpen && countryToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-6 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="w-12 h-12 rounded-full bg-rose-500/20 text-rose-400 border border-rose-500/30 flex items-center justify-center mx-auto mb-4">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <h3 className="text-lg font-bold text-center text-white mb-2">
              {countryToDelete.associatedUsersCount && countryToDelete.associatedUsersCount > 0
                ? 'Country Deletion Restricted'
                : 'Confirm Country Deletion'}
            </h3>

            {countryToDelete.associatedUsersCount && countryToDelete.associatedUsersCount > 0 ? (
              <div className="text-sm text-slate-300 text-center space-y-3 mb-6">
                <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl text-amber-300 text-xs text-left">
                  <strong>Strict Policy Enforced:</strong> Users are already associated with <strong>{countryToDelete.name}</strong> ({countryToDelete.associatedUsersCount} active users). Permanent deletion is blocked to prevent orphaned user records.
                </div>
                <p>
                  Instead of permanently deleting, you should <strong>Disable</strong> this country. Disabled countries are hidden from client registration and payment flows while preserving existing user data.
                </p>
              </div>
            ) : (
              <p className="text-sm text-slate-400 text-center mb-6">
                Are you sure you want to permanently delete <strong>{countryToDelete.name}</strong> ({countryToDelete.iso2})? There are 0 users currently linked to this country.
              </p>
            )}

            <div className="flex flex-col sm:flex-row items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => {
                  setDeleteModalOpen(false);
                  setCountryToDelete(null);
                }}
                className="w-full sm:w-auto px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-sm font-medium transition"
              >
                Cancel
              </button>

              {countryToDelete.associatedUsersCount && countryToDelete.associatedUsersCount > 0 ? (
                <button
                  type="button"
                  disabled={deleting}
                  onClick={handleDisableInstead}
                  className="w-full sm:w-auto px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-xl text-sm font-semibold transition"
                >
                  {deleting ? 'Disabling...' : 'Disable Country Instead'}
                </button>
              ) : (
                <button
                  type="button"
                  disabled={deleting}
                  onClick={handleConfirmDelete}
                  className="w-full sm:w-auto px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-sm font-semibold transition"
                >
                  {deleting ? 'Deleting...' : 'Permanently Delete'}
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
