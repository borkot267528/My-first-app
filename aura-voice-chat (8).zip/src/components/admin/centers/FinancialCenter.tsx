import React, { useState } from 'react';
import { 
  DollarSign, Wallet, ArrowUpRight, ArrowDownRight, RefreshCw, 
  FileSpreadsheet, FileText, CheckCircle2, XCircle, Filter, 
  BarChart3, PieChart, LineChart, Shield, Search, CreditCard
} from 'lucide-react';
import { WalletTransaction } from '../../../types';
import { exportToExcel, exportToPDF } from '../../../lib/exportUtils';

interface FinancialCenterProps {
  showNotification: (msg: string) => void;
}

export const FinancialCenter: React.FC<FinancialCenterProps> = ({ showNotification }) => {
  const [activeSubTab, setActiveSubTab] = useState<'recharge' | 'withdraw' | 'coin_ledger' | 'diamond_ledger' | 'revenue' | 'settlement'>('recharge');
  const [searchQuery, setSearchQuery] = useState('');

  // Sample transactions
  const transactions: WalletTransaction[] = [
    { id: 'tx-101', userId: '2383452', type: 'recharge', currency: 'coin', amount: 5000, balanceAfter: 1005000, description: 'Recharge via Stripe ($49.99 USD)', status: 'completed', timestamp: new Date().toISOString() },
    { id: 'tx-102', userId: '8829105', type: 'withdraw', currency: 'diamond', amount: 12000, balanceAfter: 28000, description: 'Withdrawal request to Bank ($120.00 USD)', status: 'pending', timestamp: new Date(Date.now() - 3600000).toISOString() },
    { id: 'tx-103', userId: '8829106', type: 'gift_sent', currency: 'coin', amount: 1200, balanceAfter: 14000, description: 'Sent Luxury Castle Gift in Room 101', status: 'completed', timestamp: new Date(Date.now() - 7200000).toISOString() },
    { id: 'tx-104', userId: '8829107', type: 'recharge', currency: 'coin', amount: 12000, balanceAfter: 45000, description: 'Recharge via PayPal ($99.99 USD)', status: 'completed', timestamp: new Date(Date.now() - 14400000).toISOString() }
  ];

  const handleExportExcel = () => {
    exportToExcel('Financial_Ledger_Export', transactions.map(t => ({
      ID: t.id, UserID: t.userId, Type: t.type, Currency: t.currency, Amount: t.amount, BalanceAfter: t.balanceAfter, Description: t.description, Status: t.status, Date: t.timestamp
    })));
  };

  const handleExportPDF = () => {
    const headers = ['TX ID', 'User ID', 'Type', 'Currency', 'Amount', 'Status', 'Date'];
    const rows = transactions.map(t => [t.id, t.userId, t.type, t.currency, t.amount, t.status.toUpperCase(), new Date(t.timestamp).toLocaleDateString()]);
    exportToPDF('Financial Ledger Audit Report', headers, rows);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* HEADER BAR */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
        <div>
          <h3 className="text-base font-black text-white flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-emerald-400" /> Financial Operations & Ledger Center
          </h3>
          <p className="text-xs text-slate-300">Recharges, Withdrawals, Coin & Diamond Audits, Settlements & Revenue</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={handleExportExcel} className="px-3 py-1.5 bg-emerald-600/80 text-white font-bold text-xs rounded-xl flex items-center gap-1.5">
            <FileSpreadsheet className="w-3.5 h-3.5" /> Excel
          </button>
          <button onClick={handleExportPDF} className="px-3 py-1.5 bg-rose-600/80 text-white font-bold text-xs rounded-xl flex items-center gap-1.5">
            <FileText className="w-3.5 h-3.5" /> PDF
          </button>
        </div>
      </div>

      {/* STATS OVERVIEW CARDS */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-1">
          <span className="text-[10px] text-slate-300 font-bold uppercase">Total Platform Revenue</span>
          <p className="text-xl font-black text-emerald-400 font-mono">$128,450.00 USD</p>
          <span className="text-[10px] text-emerald-300">↑ +14% vs last month</span>
        </div>
        <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-1">
          <span className="text-[10px] text-slate-300 font-bold uppercase">Coins Circulation</span>
          <p className="text-xl font-black text-amber-300 font-mono">🪙 85,420,000</p>
          <span className="text-[10px] text-amber-300/80">Active in User Wallets</span>
        </div>
        <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-1">
          <span className="text-[10px] text-slate-300 font-bold uppercase">Diamonds Pool</span>
          <p className="text-xl font-black text-cyan-300 font-mono">💎 42,100,000</p>
          <span className="text-[10px] text-cyan-300/80">Host Earnings</span>
        </div>
        <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-1">
          <span className="text-[10px] text-slate-300 font-bold uppercase">Pending Withdrawals</span>
          <p className="text-xl font-black text-rose-400 font-mono">$3,420.00 USD</p>
          <span className="text-[10px] text-rose-300">Requires Staff Review</span>
        </div>
      </div>

      {/* SUB-TABS NAVIGATOR */}
      <div className="flex flex-wrap gap-2 border-b border-white/10 pb-2">
        {[
          { id: 'recharge', label: 'Recharge Logs' },
          { id: 'withdraw', label: 'Withdrawal Approvals' },
          { id: 'coin_ledger', label: 'Coin Ledger' },
          { id: 'diamond_ledger', label: 'Diamond Ledger' },
          { id: 'revenue', label: 'Income & Revenue' },
          { id: 'settlement', label: 'Settlement & Payouts' }
        ].map(t => (
          <button
            key={t.id}
            onClick={() => setActiveSubTab(t.id as any)}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeSubTab === t.id ? 'bg-emerald-500 text-black font-black' : 'bg-white/5 text-slate-300 hover:bg-white/10'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* TRANSACTIONS TABLE */}
      <div className="rounded-2xl bg-white/5 border border-white/10 overflow-hidden shadow-xl">
        <div className="p-3 bg-black/40 border-b border-white/10 flex items-center justify-between">
          <h4 className="text-xs font-black text-emerald-300 uppercase">
            {activeSubTab.replace('_', ' ').toUpperCase()} AUDIT LOGS
          </h4>
          <div className="flex items-center gap-2 bg-black/60 px-3 py-1 rounded-xl border border-white/10 text-xs">
            <Search className="w-3.5 h-3.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search transaction..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-transparent text-white placeholder:text-slate-500 focus:outline-none"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-black/40 text-slate-300 font-bold uppercase border-b border-white/10">
              <tr>
                <th className="p-3">TX ID</th>
                <th className="p-3">User</th>
                <th className="p-3">Type</th>
                <th className="p-3">Amount</th>
                <th className="p-3">Description</th>
                <th className="p-3">Status</th>
                <th className="p-3">Timestamp</th>
                <th className="p-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-slate-200">
              {transactions.map(tx => (
                <tr key={tx.id} className="hover:bg-white/5">
                  <td className="p-3 font-mono font-bold text-amber-300">{tx.id}</td>
                  <td className="p-3 font-mono text-slate-300">{tx.userId}</td>
                  <td className="p-3">
                    <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase bg-purple-500/20 text-purple-300 border border-purple-500/30">
                      {tx.type}
                    </span>
                  </td>
                  <td className="p-3 font-mono font-bold">
                    {tx.currency === 'coin' ? `🪙 ${tx.amount}` : `💎 ${tx.amount}`}
                  </td>
                  <td className="p-3 text-slate-300">{tx.description}</td>
                  <td className="p-3">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      tx.status === 'completed' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-amber-500/20 text-amber-300'
                    }`}>
                      {tx.status.toUpperCase()}
                    </span>
                  </td>
                  <td className="p-3 font-mono text-slate-400">{new Date(tx.timestamp).toLocaleString()}</td>
                  <td className="p-3 text-right">
                    {tx.status === 'pending' && (
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => showNotification(`Approved transaction ${tx.id}`)}
                          className="px-2 py-1 bg-emerald-500 text-black font-bold text-[10px] rounded"
                        >
                          Approve
                        </button>
                        <button
                          onClick={() => showNotification(`Rejected transaction ${tx.id}`)}
                          className="px-2 py-1 bg-red-500 text-white font-bold text-[10px] rounded"
                        >
                          Reject
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
