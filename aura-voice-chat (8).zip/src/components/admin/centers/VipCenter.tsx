import React, { useState } from 'react';
import { Crown, Sparkles, Award, FileSpreadsheet, FileText, CheckCircle2, Clock } from 'lucide-react';
import { exportToExcel, exportToPDF } from '../../../lib/exportUtils';

interface VipCenterProps {
  showNotification: (msg: string) => void;
}

export const VipCenter: React.FC<VipCenterProps> = ({ showNotification }) => {
  const [activeTab, setActiveTab] = useState<'plans' | 'frames' | 'themes' | 'badges' | 'subscriptions'>('plans');

  const plans = [
    { id: 'vip-01', name: 'VIP Tier 1', priceCoins: 10000, durationDays: 30, perk: 'Gold Name Badge, Entrance Effect, +10% EXP' },
    { id: 'vip-02', name: 'VIP Tier 2', priceCoins: 25000, durationDays: 30, perk: 'Crown Frame, Exclusive Chat Bubble, +20% EXP' },
    { id: 'svip-01', name: 'Super VIP (SVIP)', priceCoins: 100000, durationDays: 30, perk: 'Monarch Animated Frame, Fullscreen Entrance, Stealth Mode' }
  ];

  const handleExport = () => exportToExcel('VIP_Plans_Report', plans);

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* HEADER BAR */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
        <div>
          <h3 className="text-base font-black text-white flex items-center gap-2">
            <Crown className="w-5 h-5 text-amber-400" /> VIP & SVIP Privilege Management Center
          </h3>
          <p className="text-xs text-slate-300">VIP Plans, Animated Avatar Frames, Entrance Effects, Badges & Expiry Tracking</p>
        </div>
        <button onClick={handleExport} className="px-3.5 py-1.5 bg-amber-400 text-black font-black text-xs rounded-xl shadow">
          Export VIP Directory
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {plans.map(p => (
          <div key={p.id} className="p-5 rounded-2xl bg-white/5 border border-amber-400/30 space-y-3 relative overflow-hidden">
            <div className="flex items-center justify-between">
              <h4 className="font-extrabold text-amber-300 text-base flex items-center gap-2">
                <Crown className="w-5 h-5 text-amber-400" /> {p.name}
              </h4>
              <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                {p.durationDays} Days
              </span>
            </div>
            <p className="text-xl font-mono font-black text-white">🪙 {p.priceCoins.toLocaleString()} Coins</p>
            <p className="text-xs text-slate-300">{p.perk}</p>
            <button
              onClick={() => showNotification(`Saved settings for ${p.name}`)}
              className="w-full py-2 bg-amber-400 text-black font-black text-xs rounded-xl hover:bg-amber-300 transition-all"
            >
              Edit Plan Pricing
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
