/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Palette, RefreshCw, Check, CheckCircle2, AlertTriangle, ShieldCheck, 
  Sparkles, RotateCcw, Info, Eye, Save, Lock, ArrowRight
} from 'lucide-react';
import { ApiClient } from '../../../lib/api';
import { AdminAppearanceSettings, User } from '../../../types';

export const DEFAULT_ADMIN_BACKGROUND = '#0c0618';

export const PRESET_BACKGROUND_COLORS = [
  { id: 'default', name: 'Default Dark', hex: '#0c0618', desc: 'Original Aura theme' },
  { id: 'midnight', name: 'Midnight', hex: '#0b1020', desc: 'Deep night ambience' },
  { id: 'deep_purple', name: 'Deep Purple', hex: '#1a0b2e', desc: 'Regal purple glow' },
  { id: 'navy', name: 'Navy', hex: '#0a192f', desc: 'Classic navy marine' },
  { id: 'dark_blue', name: 'Dark Blue', hex: '#071428', desc: 'Oceanic dark slate' },
  { id: 'charcoal', name: 'Charcoal', hex: '#18181b', desc: 'Modern minimal charcoal' },
  { id: 'dark_gray', name: 'Dark Gray', hex: '#1f2937', desc: 'Neutral slate gray' },
  { id: 'black', name: 'Black', hex: '#050505', desc: 'Ultra-dark contrast' },
];

interface AppearanceCenterProps {
  currentBackgroundColor: string;
  previewBackgroundColor: string;
  onPreviewChange: (color: string) => void;
  onApplySuccess: (newColor: string) => void;
  showNotification: (msg: string) => void;
  currentUser?: User | null;
}

export const AppearanceCenter: React.FC<AppearanceCenterProps> = ({
  currentBackgroundColor,
  previewBackgroundColor,
  onPreviewChange,
  onApplySuccess,
  showNotification,
  currentUser
}) => {
  const [selectedHex, setSelectedHex] = useState<string>(previewBackgroundColor || currentBackgroundColor || DEFAULT_ADMIN_BACKGROUND);
  const [hexInput, setHexInput] = useState<string>(previewBackgroundColor || currentBackgroundColor || DEFAULT_ADMIN_BACKGROUND);
  const [isApplying, setIsApplying] = useState<boolean>(false);
  const [isResetting, setIsResetting] = useState<boolean>(false);
  const [showResetConfirm, setShowResetConfirm] = useState<boolean>(false);
  const [serverMeta, setServerMeta] = useState<AdminAppearanceSettings | null>(null);
  const [loadingMeta, setLoadingMeta] = useState<boolean>(false);
  const [validationError, setValidationError] = useState<string | null>(null);

  // Synchronize when currentBackgroundColor changes externally
  useEffect(() => {
    setSelectedHex(previewBackgroundColor || currentBackgroundColor || DEFAULT_ADMIN_BACKGROUND);
    setHexInput(previewBackgroundColor || currentBackgroundColor || DEFAULT_ADMIN_BACKGROUND);
  }, [currentBackgroundColor, previewBackgroundColor]);

  // Load database appearance metadata
  const loadAppearanceMetadata = async () => {
    setLoadingMeta(true);
    try {
      const data = await ApiClient.getAdminAppearance();
      if (data) {
        setServerMeta(data);
      }
    } catch (err: any) {
      // Non-fatal, just for metadata display
      console.warn('Could not load appearance metadata:', err?.message || err);
    } finally {
      setLoadingMeta(false);
    }
  };

  useEffect(() => {
    loadAppearanceMetadata();
  }, []);

  const isValidHex = (hex: string): boolean => {
    return /^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$/.test(hex.trim());
  };

  const handleColorSelect = (hex: string) => {
    const cleanHex = hex.trim().toUpperCase();
    setSelectedHex(cleanHex);
    setHexInput(cleanHex);
    setValidationError(null);
    // Trigger live preview without saving yet
    onPreviewChange(cleanHex);
  };

  const handleHexInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let val = e.target.value.trim();
    if (!val.startsWith('#') && val.length > 0) {
      val = '#' + val;
    }
    setHexInput(val);

    if (isValidHex(val)) {
      setValidationError(null);
      setSelectedHex(val.toUpperCase());
      onPreviewChange(val.toUpperCase());
    } else {
      setValidationError('Please enter a valid 3 or 6 digit HEX code (e.g. #0B1020)');
    }
  };

  const handleApplyChanges = async () => {
    if (!isValidHex(selectedHex)) {
      setValidationError('Cannot apply invalid HEX color code.');
      showNotification('❌ Invalid HEX color format. Example: #0B1020');
      return;
    }

    setIsApplying(true);
    try {
      const updated = await ApiClient.updateAdminAppearance(selectedHex);
      setServerMeta(updated);
      onApplySuccess(updated.backgroundColor);
      showNotification(`✅ Admin Panel background updated to ${updated.backgroundColor} and saved to database.`);
      await loadAppearanceMetadata();
    } catch (err: any) {
      showNotification(`❌ Error: ${err.message || 'Failed to update Admin Panel appearance'}`);
    } finally {
      setIsApplying(false);
    }
  };

  const handleResetToDefault = async () => {
    setIsResetting(true);
    try {
      const reset = await ApiClient.resetAdminAppearance();
      setSelectedHex(DEFAULT_ADMIN_BACKGROUND);
      setHexInput(DEFAULT_ADMIN_BACKGROUND);
      setServerMeta(reset);
      onApplySuccess(DEFAULT_ADMIN_BACKGROUND);
      onPreviewChange(DEFAULT_ADMIN_BACKGROUND);
      setShowResetConfirm(false);
      showNotification(`✅ Admin Panel background reset to default (${DEFAULT_ADMIN_BACKGROUND}) and saved to database.`);
      await loadAppearanceMetadata();
    } catch (err: any) {
      showNotification(`❌ Error: ${err.message || 'Failed to reset background'}`);
    } finally {
      setIsResetting(false);
    }
  };

  const handleDiscardPreview = () => {
    const original = currentBackgroundColor || DEFAULT_ADMIN_BACKGROUND;
    setSelectedHex(original);
    setHexInput(original);
    setValidationError(null);
    onPreviewChange(original);
    showNotification('ℹ️ Preview discarded. Restored currently saved background.');
  };

  const hasUnsavedChanges = selectedHex.toLowerCase() !== (currentBackgroundColor || DEFAULT_ADMIN_BACKGROUND).toLowerCase();
  const isCurrentlyDefault = (currentBackgroundColor || DEFAULT_ADMIN_BACKGROUND).toLowerCase() === DEFAULT_ADMIN_BACKGROUND.toLowerCase();

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* HEADER BAR */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-5 rounded-3xl bg-white/5 border border-white/10 backdrop-blur-xl shadow-xl">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-purple-500/30 to-indigo-500/30 border border-purple-400/40 flex items-center justify-center text-purple-300 shadow-lg shadow-purple-500/20">
            <Palette className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-black text-white flex items-center gap-2">
              Appearance Settings
              <span className="text-[10px] uppercase font-mono px-2.5 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30">
                Admin Panel Only
              </span>
            </h3>
            <p className="text-xs text-slate-300">
              Customize the visual backdrop and atmosphere for the Nigo Voice Chat Party Admin Suite
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {hasUnsavedChanges && (
            <button
              onClick={handleDiscardPreview}
              className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-slate-300 font-bold text-xs border border-white/15 transition-all flex items-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" /> Discard Preview
            </button>
          )}

          <button
            onClick={handleApplyChanges}
            disabled={isApplying || !hasUnsavedChanges || !!validationError}
            className={`px-5 py-2 rounded-xl font-black text-xs shadow-lg flex items-center gap-2 transition-all ${
              hasUnsavedChanges && !validationError
                ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-black hover:from-amber-300 hover:to-yellow-400 shadow-amber-500/20 cursor-pointer'
                : 'bg-white/10 text-slate-500 border border-white/5 cursor-not-allowed'
            }`}
          >
            {isApplying ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Saving...
              </>
            ) : (
              <>
                <Save className="w-3.5 h-3.5" /> Apply Changes
              </>
            )}
          </button>
        </div>
      </div>

      {/* UNSAVED PREVIEW NOTICE BANNER */}
      {hasUnsavedChanges && (
        <div className="p-4 rounded-2xl bg-amber-500/15 border border-amber-400/40 backdrop-blur-md flex items-center justify-between gap-4 text-xs shadow-lg animate-fadeIn">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-amber-400/20 border border-amber-400/40 flex items-center justify-center text-amber-300">
              <Eye className="w-4 h-4" />
            </div>
            <div>
              <p className="font-extrabold text-amber-200">
                Live Preview Mode Active: <span className="font-mono">{selectedHex}</span>
              </p>
              <p className="text-[11px] text-amber-300/80">
                This preview is visible only in your current session. Click <strong className="text-amber-200">Apply Changes</strong> to permanently persist to the database.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleDiscardPreview}
              className="px-3 py-1.5 rounded-lg bg-black/40 hover:bg-black/60 text-slate-300 text-[11px] font-bold border border-white/10"
            >
              Revert
            </button>
            <button
              onClick={handleApplyChanges}
              disabled={isApplying}
              className="px-4 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-black text-[11px] font-black shadow"
            >
              {isApplying ? 'Applying...' : 'Apply Now'}
            </button>
          </div>
        </div>
      )}

      {/* MAIN SECTION: ADMIN PANEL BACKGROUND */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* LEFT 2 COLUMNS: CONFIGURATION CONTROLS */}
        <div className="lg:col-span-2 space-y-6">
          <div className="p-6 rounded-3xl bg-white/5 border border-white/10 backdrop-blur-xl space-y-6 shadow-xl">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div>
                <h4 className="text-base font-black text-white flex items-center gap-2">
                  Admin Panel Background
                </h4>
                <p className="text-xs text-slate-300">
                  Select a refined preset atmosphere or enter a custom hexadecimal color code.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setShowResetConfirm(true)}
                disabled={isResetting || (isCurrentlyDefault && !hasUnsavedChanges)}
                className={`px-3.5 py-1.5 rounded-xl font-bold text-xs border flex items-center gap-1.5 transition-all ${
                  isCurrentlyDefault && !hasUnsavedChanges
                    ? 'bg-white/5 text-slate-500 border-white/5 cursor-not-allowed'
                    : 'bg-white/10 hover:bg-white/20 text-slate-200 border-white/15 cursor-pointer'
                }`}
                title="Reset to default Admin Panel background"
              >
                <RotateCcw className="w-3.5 h-3.5 text-slate-300" /> Reset to Default
              </button>
            </div>

            {/* PRESET COLORS GRID */}
            <div className="space-y-3">
              <label className="block text-xs font-black text-slate-200 uppercase tracking-wider">
                Preset Colors
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {PRESET_BACKGROUND_COLORS.map((preset) => {
                  const isSelected = selectedHex.toLowerCase() === preset.hex.toLowerCase();
                  return (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => handleColorSelect(preset.hex)}
                      className={`relative p-3.5 rounded-2xl border text-left transition-all group overflow-hidden ${
                        isSelected
                          ? 'border-amber-400 bg-white/10 shadow-lg shadow-amber-500/10 ring-2 ring-amber-400/40'
                          : 'border-white/10 bg-black/30 hover:border-white/20 hover:bg-white/5'
                      }`}
                    >
                      {/* Color swatch circle */}
                      <div className="flex items-center justify-between mb-2">
                        <div 
                          className="w-7 h-7 rounded-xl border border-white/20 shadow-inner flex items-center justify-center transition-transform group-hover:scale-105"
                          style={{ backgroundColor: preset.hex }}
                        >
                          {isSelected && <Check className="w-3.5 h-3.5 text-amber-300 drop-shadow" />}
                        </div>
                        <span className="text-[10px] font-mono font-bold text-slate-400 uppercase">
                          {preset.hex}
                        </span>
                      </div>
                      <p className="text-xs font-black text-white truncate">{preset.name}</p>
                      <p className="text-[10px] text-slate-400 truncate">{preset.desc}</p>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* CUSTOM COLOR PICKER & HEX INPUT */}
            <div className="pt-4 border-t border-white/10 space-y-3">
              <label className="block text-xs font-black text-slate-200 uppercase tracking-wider">
                Custom HEX Color
              </label>

              <div className="flex flex-wrap sm:flex-nowrap items-center gap-3">
                {/* Native HTML5 Color Picker swatch */}
                <div className="relative group">
                  <input
                    type="color"
                    id="admin-bg-color-picker"
                    value={isValidHex(selectedHex) ? selectedHex : DEFAULT_ADMIN_BACKGROUND}
                    onChange={(e) => handleColorSelect(e.target.value)}
                    className="w-14 h-12 rounded-2xl bg-black/40 border border-white/20 cursor-pointer p-1"
                    title="Click to open color picker"
                  />
                </div>

                {/* HEX Input Field */}
                <div className="flex-1 min-w-[200px] relative">
                  <input
                    type="text"
                    id="admin-bg-hex-input"
                    value={hexInput}
                    onChange={handleHexInputChange}
                    placeholder="#0B1020"
                    maxLength={7}
                    className={`w-full bg-black/40 font-mono text-sm font-bold text-white px-4 py-3 rounded-2xl border transition-all focus:outline-none ${
                      validationError 
                        ? 'border-red-500/80 focus:border-red-400' 
                        : 'border-white/15 focus:border-amber-400'
                    }`}
                  />
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-2">
                    {isValidHex(hexInput) && (
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 shadow-sm shadow-emerald-400/50" title="Valid HEX" />
                    )}
                  </div>
                </div>

                {/* Quick select example */}
                <button
                  type="button"
                  onClick={() => handleColorSelect('#0B1020')}
                  className="px-3.5 py-3 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-mono font-bold text-slate-300 transition-colors shrink-0"
                >
                  e.g. #0B1020
                </button>
              </div>

              {validationError && (
                <p className="text-xs text-red-400 flex items-center gap-1.5 animate-fadeIn">
                  <AlertTriangle className="w-3.5 h-3.5" /> {validationError}
                </p>
              )}
            </div>

            {/* ACTION BUTTONS */}
            <div className="pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Protected by dynamic RBAC (<code>settings:appearance</code>)</span>
              </div>

              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setShowResetConfirm(true)}
                  disabled={isCurrentlyDefault && !hasUnsavedChanges}
                  className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 font-bold text-xs border border-white/10 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Reset to Default
                </button>

                <button
                  type="button"
                  onClick={handleApplyChanges}
                  disabled={isApplying || !hasUnsavedChanges || !!validationError}
                  className={`px-6 py-2.5 rounded-xl font-black text-xs shadow-xl flex items-center gap-2 transition-all ${
                    hasUnsavedChanges && !validationError
                      ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-black hover:from-amber-300 hover:to-yellow-400 shadow-amber-500/25 cursor-pointer scale-100 hover:scale-[1.02]'
                      : 'bg-white/10 text-slate-500 border border-white/5 cursor-not-allowed'
                  }`}
                >
                  {isApplying ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" /> Saving to Database...
                    </>
                  ) : (
                    <>
                      <Check className="w-4 h-4" /> Apply Changes
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: PREVIEW CARD & DATABASE PERSISTENCE SPECS */}
        <div className="space-y-6">
          {/* COLOR PREVIEW CARD */}
          <div className="p-6 rounded-3xl bg-white/5 border border-white/10 backdrop-blur-xl space-y-4 shadow-xl">
            <h4 className="text-sm font-black text-white flex items-center gap-2">
              <Eye className="w-4 h-4 text-amber-400" /> Live Preview Card
            </h4>

            {/* Visual preview box simulating admin UI */}
            <div 
              className="w-full h-44 rounded-2xl border border-white/20 p-4 flex flex-col justify-between shadow-2xl transition-colors duration-300 relative overflow-hidden"
              style={{ backgroundColor: selectedHex }}
            >
              {/* Simulated mini header */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 rounded-lg bg-amber-400/30 border border-amber-400/50 flex items-center justify-center">
                    <Sparkles className="w-3 h-3 text-amber-300" />
                  </div>
                  <span className="text-[11px] font-black text-white tracking-wide">Nigo Admin Portal</span>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/10 text-slate-200 border border-white/15">
                  {selectedHex}
                </span>
              </div>

              {/* Simulated content cards */}
              <div className="grid grid-cols-2 gap-2">
                <div className="p-2.5 rounded-xl bg-white/10 border border-white/15 backdrop-blur-sm space-y-1">
                  <span className="text-[9px] text-slate-300 font-bold block">Active Hosts</span>
                  <span className="text-xs font-black text-white">1,482</span>
                </div>
                <div className="p-2.5 rounded-xl bg-white/10 border border-white/15 backdrop-blur-sm space-y-1">
                  <span className="text-[9px] text-slate-300 font-bold block">Coin Volume</span>
                  <span className="text-xs font-black text-amber-300">4.8M</span>
                </div>
              </div>

              {/* Status pill */}
              <div className="flex items-center justify-between text-[10px]">
                <span className="text-slate-300">Status:</span>
                <span className={`font-bold font-mono px-2 py-0.5 rounded-full ${
                  hasUnsavedChanges 
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' 
                    : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                }`}>
                  {hasUnsavedChanges ? '● Unsaved Preview' : '✓ Saved in Database'}
                </span>
              </div>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between py-1.5 border-b border-white/10 text-slate-300">
                <span>Selected HEX:</span>
                <span className="font-mono font-black text-white">{selectedHex}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-white/10 text-slate-300">
                <span>Saved Background:</span>
                <span className="font-mono font-black text-amber-300">{currentBackgroundColor || DEFAULT_ADMIN_BACKGROUND}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-white/10 text-slate-300">
                <span>Database Status:</span>
                <span className="font-mono text-emerald-300">Firestore Authoritative</span>
              </div>
              {serverMeta && (
                <>
                  <div className="flex justify-between py-1.5 border-b border-white/10 text-slate-300">
                    <span>Last Updated:</span>
                    <span className="font-mono text-slate-200">
                      {new Date(serverMeta.updatedAt).toLocaleString()}
                    </span>
                  </div>
                  {serverMeta.updatedByName && (
                    <div className="flex justify-between py-1.5 border-b border-white/10 text-slate-300">
                      <span>Updated By:</span>
                      <span className="font-bold text-white">
                        {serverMeta.updatedByName} ({serverMeta.updatedByRole || 'Admin'})
                      </span>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>

          {/* SCOPE ISOLATION ASSURANCE */}
          <div className="p-5 rounded-3xl bg-white/5 border border-white/10 backdrop-blur-xl space-y-3 shadow-xl">
            <h4 className="text-xs font-black text-slate-200 uppercase tracking-wider flex items-center gap-2">
              <Info className="w-4 h-4 text-cyan-400" /> Isolation Guarantee
            </h4>
            <ul className="text-[11px] text-slate-300 space-y-1.5 list-disc list-inside">
              <li>Changes apply <strong>exclusively</strong> to the Admin Portal interface.</li>
              <li>Mobile app, user rooms, profiles, and login flows remain untouched.</li>
              <li>Setting persists across browser refreshes, logouts, and sessions.</li>
              <li>Immutable audit log recorded on every change: <code>ADMIN_PANEL_BACKGROUND_CHANGED</code>.</li>
            </ul>
          </div>
        </div>

      </div>

      {/* CONFIRMATION MODAL: RESET TO DEFAULT */}
      {showResetConfirm && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#1a0b2e]/95 backdrop-blur-2xl border border-amber-400/40 rounded-3xl p-6 w-full max-w-md space-y-4 shadow-2xl animate-fadeIn">
            <div className="flex items-center gap-3 text-amber-300">
              <div className="w-10 h-10 rounded-xl bg-amber-400/20 border border-amber-400/40 flex items-center justify-center">
                <AlertTriangle className="w-5 h-5 text-amber-300" />
              </div>
              <div>
                <h4 className="font-black text-white text-base">Reset Admin Background?</h4>
                <p className="text-xs text-slate-300">Restore original Nigo Admin Panel theme</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              This will restore the original dark background (<code className="font-mono text-amber-300">{DEFAULT_ADMIN_BACKGROUND}</code>) and save this value to the database immediately.
            </p>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10">
              <button
                type="button"
                onClick={() => setShowResetConfirm(false)}
                className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-slate-300 text-xs font-bold transition-all"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleResetToDefault}
                disabled={isResetting}
                className="px-5 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-black text-xs font-black shadow-lg shadow-amber-500/20 flex items-center gap-1.5"
              >
                {isResetting ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Resetting...
                  </>
                ) : (
                  <>
                    <RotateCcw className="w-3.5 h-3.5" /> Confirm Reset
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
