import React, { useState, useEffect, useRef } from 'react';
import { 
  X, Users, Crown, Shield, Image as ImageIcon, Upload, Check, 
  AlertCircle, Sparkles, Search, UserCheck, ChevronRight, Globe,
  Award, RefreshCw, HelpCircle, Layers, Settings, Lock, Flame
} from 'lucide-react';
import { Family, User } from '../../../../types';
import { ApiClient } from '../../../../lib/api';

interface CreateFamilyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (newFamily: Family) => void;
  showNotification: (msg: string) => void;
}

const CATEGORY_OPTIONS = [
  'VIP & Elite',
  'Gaming & Social',
  'Music & Acoustic',
  'PK Warriors',
  'Global Community',
  'Chat & Chill',
  'Talent & Podcasting',
  'Language Exchange'
];

const PRESET_BADGES = [
  '👑', '🛡️', '⚔️', '🐉', '🦅', '🦁', 
  '⚡', '🔥', '💎', '🌌', '🐺', '🏆', 
  '🌟', '🎯', '🚀', '🎭', '🔱', '⚜️'
];

const MEMBER_LIMIT_PRESETS = [50, 100, 200, 500];

export const CreateFamilyModal: React.FC<CreateFamilyModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  showNotification
}) => {
  // Navigation tabs inside modal
  const [activeTab, setActiveTab] = useState<'basic' | 'branding' | 'leader' | 'settings'>('basic');

  // Form Fields
  const [name, setName] = useState('');
  const [familyId, setFamilyId] = useState('');
  const [slogan, setSlogan] = useState('');
  const [description, setDescription] = useState('');
  const [announcement, setAnnouncement] = useState('');
  const [country, setCountry] = useState('Global 🌐');
  const [category, setCategory] = useState('VIP & Elite');
  const [badge, setBadge] = useState('👑');
  const [logoPreview, setLogoPreview] = useState<string>('');
  const [selectedLeader, setSelectedLeader] = useState<User | null>(null);
  const [selectedCoLeaders, setSelectedCoLeaders] = useState<User[]>([]);
  const [level, setLevel] = useState<number>(1);
  const [xp, setXp] = useState<number>(5000);
  const [maxMembers, setMaxMembers] = useState<number>(50);
  const [status, setStatus] = useState<'active' | 'inactive' | 'suspended'>('active');
  const [privacy, setPrivacy] = useState<'public' | 'private'>('public');
  const [joinMethod, setJoinMethod] = useState<'anyone' | 'approval' | 'invite'>('anyone');

  // Registered Users for search
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [userSearch, setUserSearch] = useState('');
  const [isLoadingUsers, setIsLoadingUsers] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Generate unique family ID
  const generateRandomFamilyId = () => {
    const num = Math.floor(100000 + Math.random() * 900000);
    return `FAM-${num}`;
  };

  useEffect(() => {
    if (isOpen) {
      // Reset or initialize fields
      setFamilyId(generateRandomFamilyId());
      loadUsers();
      setError(null);
      setActiveTab('basic');
    }
  }, [isOpen]);

  const loadUsers = async () => {
    setIsLoadingUsers(true);
    try {
      const users = await ApiClient.getAdminUsers();
      setAllUsers(users || []);
    } catch (e) {
      console.warn('Could not load user list for family leader picker:', e);
    } finally {
      setIsLoadingUsers(false);
    }
  };

  // Filter users by search
  const filteredUsers = allUsers.filter(u => {
    const query = userSearch.toLowerCase().trim();
    if (!query) return true;
    return (
      u.name.toLowerCase().includes(query) ||
      u.uid.toLowerCase().includes(query) ||
      u.id.toLowerCase().includes(query) ||
      (u.email && u.email.toLowerCase().includes(query)) ||
      (u.role && u.role.toLowerCase().includes(query))
    );
  });

  // Handle Logo Upload (Drag & Drop or File Picker)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setError('Please upload a valid image file (PNG, JPG, JPEG, WEBP)');
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      setError('Image file size must be less than 2MB');
      return;
    }

    setError(null);
    const reader = new FileReader();
    reader.onload = () => {
      setLogoPreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.startsWith('image/')) {
      if (file.size > 2 * 1024 * 1024) {
        setError('Image file size must be less than 2MB');
        return;
      }
      setError(null);
      const reader = new FileReader();
      reader.onload = () => {
        setLogoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Validation
  const validate = (): boolean => {
    if (!name.trim() || name.trim().length < 2) {
      setError('Family Name is required and must be at least 2 characters.');
      setActiveTab('basic');
      return false;
    }
    if (!selectedLeader) {
      setError('Please search and select a registered user as the Family Leader.');
      setActiveTab('leader');
      return false;
    }
    setError(null);
    return true;
  };

  // Submit Handler
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    setError(null);

    try {
      const payload = {
        name: name.trim(),
        familyId: familyId.trim().toUpperCase() || generateRandomFamilyId(),
        badge,
        logo: logoPreview || 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=500&q=80',
        slogan: slogan.trim() || `${name.trim()} Clan - Power & Unity!`,
        description: description.trim() || `Official ${name.trim()} Family Guild.`,
        announcement: announcement.trim() || `Welcome all new clan members! Contribute daily and rise together.`,
        country,
        category,
        level,
        xp,
        maxMembers,
        status,
        privacy,
        joinMethod,
        leaderId: selectedLeader!.id,
        coLeaderIds: selectedCoLeaders.map(cl => cl.id)
      };

      const created = await ApiClient.createAdminFamily(payload);
      showNotification(`🎉 Family Guild "${created.name}" created successfully!`);
      onSuccess(created);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to create family. Please check the inputs and try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-3xl max-h-[90vh] bg-slate-900 border border-amber-500/30 rounded-3xl shadow-2xl overflow-hidden flex flex-col">
        
        {/* HEADER */}
        <div className="p-5 bg-gradient-to-r from-amber-950/60 via-slate-900 to-purple-950/60 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center shadow-lg shadow-amber-500/20 text-black font-black text-xl">
              👑
            </div>
            <div>
              <h3 className="text-lg font-black text-white flex items-center gap-2">
                Create New Family Guild
              </h3>
              <p className="text-xs text-slate-300">
                Register an official Family Clan, appoint a Leader, and set membership parameters
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/15 text-slate-300 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* NAVIGATION TABS */}
        <div className="flex border-b border-white/10 bg-black/30 px-5 pt-2 gap-2 overflow-x-auto">
          {[
            { id: 'basic', label: '1. Basic Info', icon: Users },
            { id: 'branding', label: '2. Logo & Badge', icon: ImageIcon },
            { id: 'leader', label: '3. Leadership *', icon: Crown },
            { id: 'settings', label: '4. Governance', icon: Settings }
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold rounded-t-xl transition whitespace-nowrap border-b-2 ${
                  isActive
                    ? 'border-amber-400 text-amber-300 bg-white/5'
                    : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-white/5'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-amber-400' : 'text-slate-400'}`} />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* ERROR DISPLAY */}
        {error && (
          <div className="mx-5 mt-4 p-3 rounded-xl bg-rose-500/20 border border-rose-500/40 text-rose-200 text-xs flex items-center gap-2.5">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <p className="font-medium">{error}</p>
          </div>
        )}

        {/* FORM CONTENT (SCROLLABLE) */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-5 space-y-5">
          
          {/* TAB 1: BASIC INFO */}
          {activeTab === 'basic' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* Family Name */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-200 flex items-center justify-between">
                    <span>Family Guild Name <span className="text-amber-400">*</span></span>
                    <span className="text-[10px] text-slate-400">{name.length}/40</span>
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={40}
                    placeholder="e.g., Royal Dynasty 👑, Cyber Wolves"
                    value={name}
                    onChange={e => setName(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-black/50 border border-white/15 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400 transition"
                  />
                  <p className="text-[10px] text-slate-400">The primary display name shown across rooms, rankings, and user badges.</p>
                </div>

                {/* Family Unique ID */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-200 flex items-center justify-between">
                    <span>Unique Family ID</span>
                    <button
                      type="button"
                      onClick={() => setFamilyId(generateRandomFamilyId())}
                      className="text-[10px] text-amber-400 hover:underline flex items-center gap-1"
                    >
                      <RefreshCw className="w-2.5 h-2.5" /> Generate New
                    </button>
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="e.g., FAM-100001"
                      value={familyId}
                      onChange={e => setFamilyId(e.target.value.toUpperCase())}
                      className="w-full px-3.5 py-2.5 bg-black/50 border border-white/15 rounded-xl text-amber-300 font-mono font-bold text-xs focus:outline-none focus:border-amber-400 transition"
                    />
                  </div>
                  <p className="text-[10px] text-slate-400">System identifier used for invitations, ranking lookups, and audit trails.</p>
                </div>
              </div>

              {/* Category & Region */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-200">Guild Category / Theme</label>
                  <select
                    value={category}
                    onChange={e => setCategory(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-black/50 border border-white/15 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400 transition"
                  >
                    {CATEGORY_OPTIONS.map(c => (
                      <option key={c} value={c} className="bg-slate-900 text-white">{c}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-200">Country / Community Region</label>
                  <input
                    type="text"
                    placeholder="e.g., Global 🌐, United States 🇺🇸, Singapore 🇸🇬"
                    value={country}
                    onChange={e => setCountry(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-black/50 border border-white/15 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400 transition"
                  />
                </div>
              </div>

              {/* Slogan */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-200">Clan Motto / Slogan</label>
                <input
                  type="text"
                  maxLength={100}
                  placeholder="e.g., Where kings and queens unite in harmony!"
                  value={slogan}
                  onChange={e => setSlogan(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-black/50 border border-white/15 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400 transition"
                />
              </div>

              {/* Description */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-200">Family Description & Story</label>
                <textarea
                  rows={2}
                  placeholder="Describe your family's mission, values, and community goals..."
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  className="w-full px-3.5 py-2 bg-black/50 border border-white/15 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400 transition resize-none"
                />
              </div>

              {/* Official Announcement */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-200">Initial Clan Announcement</label>
                <textarea
                  rows={2}
                  placeholder="e.g., Welcome all members! Join our daily voice rooms and weekly tournaments."
                  value={announcement}
                  onChange={e => setAnnouncement(e.target.value)}
                  className="w-full px-3.5 py-2 bg-black/50 border border-white/15 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400 transition resize-none"
                />
              </div>
            </div>
          )}

          {/* TAB 2: BRANDING & LOGO */}
          {activeTab === 'branding' && (
            <div className="space-y-5">
              {/* Logo Upload Card */}
              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3">
                <label className="text-xs font-bold text-slate-200 flex items-center gap-2">
                  <ImageIcon className="w-4 h-4 text-amber-400" />
                  Family Guild Emblem / Logo Upload
                </label>
                <p className="text-[11px] text-slate-300">
                  Upload an image (PNG, JPG, WEBP, max 2MB). Supports drag and drop.
                </p>

                <div 
                  onDragOver={e => e.preventDefault()}
                  onDrop={handleDrop}
                  className="border-2 border-dashed border-white/20 hover:border-amber-400/60 rounded-2xl p-6 text-center transition flex flex-col items-center justify-center gap-3 bg-black/30 cursor-pointer"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />

                  {logoPreview ? (
                    <div className="relative group">
                      <img
                        src={logoPreview}
                        alt="Family Logo Preview"
                        className="w-24 h-24 rounded-2xl object-cover border-2 border-amber-400 shadow-xl"
                      />
                      <div className="absolute inset-0 bg-black/60 rounded-2xl flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
                        <span className="text-[10px] text-white font-bold">Change Logo</span>
                      </div>
                    </div>
                  ) : (
                    <div className="w-16 h-16 rounded-2xl bg-amber-400/10 border border-amber-400/30 flex items-center justify-center text-amber-400">
                      <Upload className="w-7 h-7" />
                    </div>
                  )}

                  <div className="space-y-1">
                    <p className="text-xs font-bold text-white">
                      {logoPreview ? 'Click to replace logo' : 'Click or Drag & Drop to upload Emblem'}
                    </p>
                    <p className="text-[10px] text-slate-400">Recommended 500x500 square image</p>
                  </div>
                </div>

                {logoPreview && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setLogoPreview('');
                    }}
                    className="text-xs text-rose-400 hover:text-rose-300 font-bold hover:underline"
                  >
                    Remove uploaded logo
                  </button>
                )}
              </div>

              {/* Preset Badges Selector */}
              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3">
                <label className="text-xs font-bold text-slate-200 flex items-center gap-2">
                  <Award className="w-4 h-4 text-amber-400" />
                  Select Clan Icon / Badge Symbol
                </label>
                <div className="grid grid-cols-6 sm:grid-cols-9 gap-2">
                  {PRESET_BADGES.map(b => (
                    <button
                      key={b}
                      type="button"
                      onClick={() => setBadge(b)}
                      className={`text-2xl p-2.5 rounded-xl border transition flex items-center justify-center ${
                        badge === b
                          ? 'bg-amber-400/20 border-amber-400 shadow-lg scale-105'
                          : 'bg-black/40 border-white/10 hover:border-white/30'
                      }`}
                    >
                      {b}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: LEADERSHIP & CO-LEADERS */}
          {activeTab === 'leader' && (
            <div className="space-y-4">
              <div className="p-3 rounded-xl bg-amber-400/10 border border-amber-400/20 text-amber-200 text-xs flex items-center gap-2">
                <Crown className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Assign a real registered member from your platform to lead this Family Guild.</span>
              </div>

              {/* Selected Leader Display */}
              {selectedLeader ? (
                <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-950/50 to-slate-900 border border-amber-400/40 flex items-center justify-between shadow-lg">
                  <div className="flex items-center gap-3">
                    <img
                      src={selectedLeader.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80'}
                      alt={selectedLeader.name}
                      className="w-12 h-12 rounded-xl object-cover border-2 border-amber-400"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-black text-white text-sm">{selectedLeader.name}</span>
                        <span className="px-2 py-0.5 rounded-md bg-amber-400 text-black text-[10px] font-black uppercase">
                          Leader 👑
                        </span>
                      </div>
                      <p className="text-xs text-slate-300 font-mono">UID: {selectedLeader.uid} • Role: {selectedLeader.role}</p>
                      <p className="text-[11px] text-amber-300">Balance: 🪙 {(selectedLeader.coins || 0).toLocaleString()} coins</p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setSelectedLeader(null)}
                    className="px-3 py-1.5 bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 text-xs font-bold rounded-xl border border-rose-500/30 transition"
                  >
                    Change Leader
                  </button>
                </div>
              ) : (
                <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4" />
                  <span>No Family Leader selected yet. Please select a user below.</span>
                </div>
              )}

              {/* User Search Input */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-200">Search Registered Platform Users</label>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Search by Name, UID, Email, or Role..."
                    value={userSearch}
                    onChange={e => setUserSearch(e.target.value)}
                    className="w-full pl-9 pr-4 py-2.5 bg-black/50 border border-white/15 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400 transition"
                  />
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                </div>
              </div>

              {/* Users List (Scrollable) */}
              <div className="max-h-56 overflow-y-auto space-y-2 pr-1 custom-scrollbar">
                {isLoadingUsers ? (
                  <div className="p-6 text-center text-xs text-slate-400">Loading platform users...</div>
                ) : filteredUsers.length === 0 ? (
                  <div className="p-6 text-center text-xs text-slate-400">No users found matching "{userSearch}".</div>
                ) : (
                  filteredUsers.map((u, idx) => {
                    const isLeader = selectedLeader?.id === u.id;
                    const isCoLeader = selectedCoLeaders.some(cl => cl.id === u.id);

                    return (
                      <div
                        key={`family-user-${u.id}-${idx}`}
                        className={`p-3 rounded-xl border transition flex items-center justify-between ${
                          isLeader 
                            ? 'bg-amber-400/20 border-amber-400' 
                            : isCoLeader 
                            ? 'bg-purple-500/20 border-purple-400' 
                            : 'bg-white/5 border-white/10 hover:border-white/20'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <img
                            src={u.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80'}
                            alt={u.name}
                            className="w-9 h-9 rounded-xl object-cover border border-white/10"
                          />
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-white text-xs">{u.name}</span>
                              <span className="text-[10px] px-1.5 py-0.5 rounded bg-white/10 text-slate-300 uppercase">
                                {u.role}
                              </span>
                            </div>
                            <span className="text-[11px] text-slate-400 font-mono">UID: {u.uid}</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5">
                          {/* Set as Leader Button */}
                          <button
                            type="button"
                            onClick={() => {
                              setSelectedLeader(u);
                              // Remove from co-leaders if was there
                              setSelectedCoLeaders(prev => prev.filter(cl => cl.id !== u.id));
                            }}
                            className={`px-2.5 py-1 text-xs font-bold rounded-lg transition ${
                              isLeader
                                ? 'bg-amber-400 text-black shadow'
                                : 'bg-amber-400/20 text-amber-300 hover:bg-amber-400/30'
                            }`}
                          >
                            {isLeader ? '✓ Leader' : 'Set Leader'}
                          </button>

                          {/* Set as Co-Leader Button */}
                          {!isLeader && (
                            <button
                              type="button"
                              onClick={() => {
                                if (isCoLeader) {
                                  setSelectedCoLeaders(prev => prev.filter(cl => cl.id !== u.id));
                                } else {
                                  setSelectedCoLeaders(prev => [...prev, u]);
                                }
                              }}
                              className={`px-2.5 py-1 text-xs font-bold rounded-lg transition ${
                                isCoLeader
                                  ? 'bg-purple-500 text-white shadow'
                                  : 'bg-white/10 text-slate-300 hover:bg-white/20'
                              }`}
                            >
                              {isCoLeader ? '✓ Co-Leader' : '+ Co-Leader'}
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          )}

          {/* TAB 4: GOVERNANCE & SETTINGS */}
          {activeTab === 'settings' && (
            <div className="space-y-4">
              
              {/* Max Members Limit */}
              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3">
                <label className="text-xs font-bold text-slate-200 flex items-center justify-between">
                  <span>Maximum Clan Members Limit</span>
                  <span className="text-amber-300 font-bold">{maxMembers} Members</span>
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {MEMBER_LIMIT_PRESETS.map(preset => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setMaxMembers(preset)}
                      className={`py-2 text-xs font-bold rounded-xl border transition ${
                        maxMembers === preset
                          ? 'bg-amber-400 text-black border-amber-400 shadow-md font-black'
                          : 'bg-black/40 text-slate-300 border-white/10 hover:border-white/30'
                      }`}
                    >
                      {preset} Slots
                    </button>
                  ))}
                </div>
              </div>

              {/* Initial Level & XP */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
                  <label className="text-xs font-bold text-slate-200 flex items-center justify-between">
                    <span>Initial Family Level</span>
                    <span className="text-amber-300 font-bold">Level {level}</span>
                  </label>
                  <input
                    type="range"
                    min={1}
                    max={10}
                    value={level}
                    onChange={e => {
                      const lvl = Number(e.target.value);
                      setLevel(lvl);
                      setXp(lvl * 5000);
                    }}
                    className="w-full accent-amber-400 cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400">
                    <span>Lvl 1</span>
                    <span>Lvl 5</span>
                    <span>Lvl 10 (Master)</span>
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
                  <label className="text-xs font-bold text-slate-200">Initial Clan XP</label>
                  <input
                    type="number"
                    min={0}
                    value={xp}
                    onChange={e => setXp(Number(e.target.value))}
                    className="w-full px-3.5 py-2 bg-black/50 border border-white/15 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400 transition font-mono"
                  />
                </div>
              </div>

              {/* Status & Join Method */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-200">Guild Status</label>
                  <select
                    value={status}
                    onChange={e => setStatus(e.target.value as any)}
                    className="w-full px-3 py-2 bg-black/50 border border-white/15 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400 transition"
                  >
                    <option value="active" className="bg-slate-900">Active 🟢</option>
                    <option value="inactive" className="bg-slate-900">Inactive ⚪</option>
                    <option value="suspended" className="bg-slate-900">Suspended 🔴</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-200">Join Policy</label>
                  <select
                    value={joinMethod}
                    onChange={e => setJoinMethod(e.target.value as any)}
                    className="w-full px-3 py-2 bg-black/50 border border-white/15 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400 transition"
                  >
                    <option value="anyone" className="bg-slate-900">Open (Anyone)</option>
                    <option value="approval" className="bg-slate-900">Requires Approval</option>
                    <option value="invite" className="bg-slate-900">Invite Only</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-200">Privacy Visibility</label>
                  <select
                    value={privacy}
                    onChange={e => setPrivacy(e.target.value as any)}
                    className="w-full px-3 py-2 bg-black/50 border border-white/15 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400 transition"
                  >
                    <option value="public" className="bg-slate-900">Public (Visible in directory)</option>
                    <option value="private" className="bg-slate-900">Private (Hidden)</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* FOOTER ACTIONS */}
          <div className="pt-4 border-t border-white/10 flex items-center justify-between">
            <div className="text-xs text-slate-400">
              {activeTab !== 'settings' ? (
                <button
                  type="button"
                  onClick={() => {
                    const order: ('basic' | 'branding' | 'leader' | 'settings')[] = ['basic', 'branding', 'leader', 'settings'];
                    const next = order[order.indexOf(activeTab) + 1];
                    if (next) setActiveTab(next);
                  }}
                  className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white font-bold rounded-xl transition flex items-center gap-1"
                >
                  Next Step <ChevronRight className="w-3.5 h-3.5" />
                </button>
              ) : (
                <span className="text-[11px] text-amber-300">Ready to instantiate Family Guild</span>
              )}
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                disabled={isSubmitting}
                className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white text-xs font-bold rounded-xl transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-6 py-2.5 bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-black font-black text-xs rounded-xl shadow-lg shadow-amber-500/20 hover:scale-105 active:scale-95 transition flex items-center gap-2 disabled:opacity-50 disabled:scale-100"
              >
                {isSubmitting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    Creating Family...
                  </>
                ) : (
                  <>
                    <Crown className="w-4 h-4" />
                    Create Family Guild
                  </>
                )}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
