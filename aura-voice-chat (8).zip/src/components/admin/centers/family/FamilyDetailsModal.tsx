import React, { useState, useEffect } from 'react';
import { 
  X, Users, Crown, Shield, Award, Edit3, Trash2, UserPlus, 
  Check, AlertCircle, RefreshCw, Globe, Flame, Lock, UserX,
  ChevronDown, Search, ArrowRightLeft, Settings, Info, Save
} from 'lucide-react';
import { Family, FamilyMember, User } from '../../../../types';
import { ApiClient } from '../../../../lib/api';

interface FamilyDetailsModalProps {
  family: Family | null;
  isOpen: boolean;
  onClose: () => void;
  onUpdated: (updatedFamily: Family) => void;
  onDeleted: (familyId: string) => void;
  showNotification: (msg: string) => void;
}

export const FamilyDetailsModal: React.FC<FamilyDetailsModalProps> = ({
  family,
  isOpen,
  onClose,
  onUpdated,
  onDeleted,
  showNotification
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'members' | 'edit' | 'governance'>('overview');
  const [members, setMembers] = useState<FamilyMember[]>([]);
  const [isLoadingMembers, setIsLoadingMembers] = useState(false);

  // Edit form state
  const [editName, setEditName] = useState(family?.name || '');
  const [editSlogan, setEditSlogan] = useState(family?.slogan || '');
  const [editDescription, setEditDescription] = useState(family?.description || '');
  const [editAnnouncement, setEditAnnouncement] = useState(family?.announcement || '');
  const [editCategory, setEditCategory] = useState(family?.category || 'VIP & Elite');
  const [editCountry, setEditCountry] = useState(family?.country || 'Global 🌐');
  const [editBadge, setEditBadge] = useState(family?.badge || '👑');
  const [editMaxMembers, setEditMaxMembers] = useState(family?.maxMembers || 50);
  const [editLevel, setEditLevel] = useState(family?.level || 1);
  const [editXp, setEditXp] = useState(family?.xp || 5000);
  const [editStatus, setEditStatus] = useState<'active' | 'inactive' | 'suspended'>(family?.status || 'active');
  const [isSavingEdit, setIsSavingEdit] = useState(false);

  // Add member modal state
  const [showAddMember, setShowAddMember] = useState(false);
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [userSearchQuery, setUserSearchQuery] = useState('');
  const [selectedUserToAdd, setSelectedUserToAdd] = useState<User | null>(null);
  const [newMemberRole, setNewMemberRole] = useState<'co_leader' | 'elder' | 'member'>('member');
  const [isAddingMember, setIsAddingMember] = useState(false);

  // Transfer leadership state
  const [transferTargetUser, setTransferTargetUser] = useState<User | null>(null);
  const [isTransferring, setIsTransferring] = useState(false);

  // Disband state
  const [confirmDisband, setConfirmDisband] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const [memberSearchQuery, setMemberSearchQuery] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (family) {
      setEditName(family.name || '');
      setEditSlogan(family.slogan || '');
      setEditDescription(family.description || '');
      setEditAnnouncement(family.announcement || '');
      setEditCategory(family.category || 'VIP & Elite');
      setEditCountry(family.country || 'Global 🌐');
      setEditBadge(family.badge || '👑');
      setEditMaxMembers(family.maxMembers || 50);
      setEditLevel(family.level || 1);
      setEditXp(family.xp || 5000);
      setEditStatus(family.status || 'active');
      loadFamilyMembers();
      loadAllUsers();
      setError(null);
      setConfirmDisband(false);
    }
  }, [family]);

  const loadFamilyMembers = async () => {
    if (!family) return;
    setIsLoadingMembers(true);
    try {
      const data = await ApiClient.getFamilyMembers(family.id);
      setMembers(data || []);
    } catch (e) {
      console.warn('Failed to load family members:', e);
    } finally {
      setIsLoadingMembers(false);
    }
  };

  const loadAllUsers = async () => {
    try {
      const users = await ApiClient.getAdminUsers();
      setAllUsers(users || []);
    } catch (e) {
      console.warn('Failed to load users:', e);
    }
  };

  // Save Edit Changes
  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!family) return;
    setIsSavingEdit(true);
    setError(null);

    try {
      const updated = await ApiClient.updateFamily(family.id, {
        name: editName.trim(),
        slogan: editSlogan.trim(),
        description: editDescription.trim(),
        announcement: editAnnouncement.trim(),
        category: editCategory,
        country: editCountry,
        badge: editBadge,
        maxMembers: editMaxMembers,
        level: editLevel,
        xp: editXp,
        status: editStatus
      });
      showNotification(`Family "${updated.name}" updated successfully!`);
      onUpdated(updated);
    } catch (err: any) {
      setError(err.message || 'Failed to update family');
    } finally {
      setIsSavingEdit(false);
    }
  };

  // Add Member
  const handleAddMember = async () => {
    if (!family || !selectedUserToAdd) return;
    setIsAddingMember(true);
    setError(null);

    try {
      await ApiClient.addFamilyMember(family.id, {
        userId: selectedUserToAdd.id,
        role: newMemberRole
      });
      showNotification(`Added ${selectedUserToAdd.name} to ${family.name}!`);
      setShowAddMember(false);
      setSelectedUserToAdd(null);
      loadFamilyMembers();
      // Update parent count
      onUpdated({ ...family, memberCount: (family.memberCount || 0) + 1 });
    } catch (err: any) {
      setError(err.message || 'Failed to add member');
    } finally {
      setIsAddingMember(false);
    }
  };

  // Remove Member
  const handleRemoveMember = async (userId: string, memberName: string) => {
    if (!family) return;
    if (!window.confirm(`Are you sure you want to remove ${memberName} from this Family?`)) return;

    try {
      await ApiClient.removeFamilyMember(family.id, userId);
      showNotification(`Removed ${memberName} from Family.`);
      loadFamilyMembers();
      onUpdated({ ...family, memberCount: Math.max(1, (family.memberCount || 1) - 1) });
    } catch (err: any) {
      showNotification(`Error: ${err.message}`);
    }
  };

  // Update Member Role
  const handleUpdateRole = async (userId: string, newRole: string) => {
    if (!family) return;
    try {
      await ApiClient.updateFamilyMemberRole(family.id, userId, newRole);
      showNotification(`Updated member role to ${newRole}`);
      loadFamilyMembers();
    } catch (err: any) {
      showNotification(`Error: ${err.message}`);
    }
  };

  // Transfer Leadership
  const handleTransferLeadership = async () => {
    if (!family || !transferTargetUser) return;
    if (!window.confirm(`Confirm transferring Clan Leadership to ${transferTargetUser.name}?`)) return;

    setIsTransferring(true);
    setError(null);
    try {
      const updated = await ApiClient.transferFamilyLeadership(family.id, transferTargetUser.id);
      showNotification(`Leadership transferred to ${transferTargetUser.name}! 👑`);
      setTransferTargetUser(null);
      loadFamilyMembers();
      onUpdated(updated);
    } catch (err: any) {
      setError(err.message || 'Failed to transfer leadership');
    } finally {
      setIsTransferring(false);
    }
  };

  // Disband Family
  const handleDeleteFamily = async () => {
    if (!family) return;
    setIsDeleting(true);
    setError(null);

    try {
      await ApiClient.deleteFamily(family.id);
      showNotification(`Family "${family.name}" has been disbanded and deleted.`);
      onDeleted(family.id);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to delete family');
    } finally {
      setIsDeleting(false);
    }
  };

  const filteredMembers = members.filter(m => {
    const q = memberSearchQuery.toLowerCase();
    if (!q) return true;
    return (
      m.name.toLowerCase().includes(q) ||
      (m.userUid && m.userUid.toLowerCase().includes(q)) ||
      m.role.toLowerCase().includes(q)
    );
  });

  const availableUsersToAdd = allUsers.filter(u => {
    const isAlreadyMember = members.some(m => m.userId === u.id);
    if (isAlreadyMember) return false;
    const q = userSearchQuery.toLowerCase();
    if (!q) return true;
    return (
      u.name.toLowerCase().includes(q) ||
      u.uid.toLowerCase().includes(q) ||
      (u.email && u.email.toLowerCase().includes(q))
    );
  });

  if (!isOpen || !family) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-4xl max-h-[90vh] bg-slate-900 border border-white/15 rounded-3xl shadow-2xl overflow-hidden flex flex-col">
        
        {/* HEADER HERO */}
        <div className="relative p-6 bg-gradient-to-r from-amber-950/70 via-slate-900 to-purple-950/70 border-b border-white/10 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="relative">
              {family.logo ? (
                <img
                  src={family.logo}
                  alt={family.name}
                  className="w-16 h-16 rounded-2xl object-cover border-2 border-amber-400 shadow-xl"
                />
              ) : (
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-3xl shadow-xl border border-white/20">
                  {family.badge || '👑'}
                </div>
              )}
              <span className="absolute -bottom-2 -right-2 px-2 py-0.5 rounded-full bg-amber-400 text-black text-[10px] font-black shadow-md">
                Lvl {family.level}
              </span>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xl font-black text-white">{family.name}</h3>
                {family.familyId && (
                  <span className="px-2 py-0.5 rounded-md bg-white/10 text-amber-300 font-mono text-xs font-bold">
                    {family.familyId}
                  </span>
                )}
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                  family.status === 'suspended'
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                    : family.status === 'inactive'
                    ? 'bg-slate-500/20 text-slate-300 border border-slate-500/30'
                    : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                }`}>
                  {family.status || 'active'}
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                Leader: <strong className="text-amber-300">{family.leaderName}</strong> • Category: <span className="text-purple-300">{family.category || 'General'}</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-black px-3 py-1.5 rounded-xl bg-amber-400/20 text-amber-300 border border-amber-400/30">
              Rank #{family.ranking || 1}
            </span>
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/15 text-slate-300 hover:text-white transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* METRICS BAR */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 p-4 bg-black/40 border-b border-white/5 text-xs">
          <div className="p-2.5 rounded-xl bg-white/5 border border-white/5">
            <span className="text-slate-400 block text-[10px]">Clan Members</span>
            <strong className="text-white text-sm font-black">{family.memberCount} / {family.maxMembers}</strong>
          </div>
          <div className="p-2.5 rounded-xl bg-white/5 border border-white/5">
            <span className="text-slate-400 block text-[10px]">Total Contribution</span>
            <strong className="text-amber-300 text-sm font-mono font-bold">🪙 {(family.totalContribution || 0).toLocaleString()}</strong>
          </div>
          <div className="p-2.5 rounded-xl bg-white/5 border border-white/5">
            <span className="text-slate-400 block text-[10px]">Guild Level & XP</span>
            <strong className="text-cyan-300 text-sm font-bold">Level {family.level} ({((family.xp || 0) / 1000).toFixed(1)}k XP)</strong>
          </div>
          <div className="p-2.5 rounded-xl bg-white/5 border border-white/5">
            <span className="text-slate-400 block text-[10px]">Region / Visibility</span>
            <strong className="text-purple-300 text-sm font-bold">{family.country || 'Global'} ({family.privacy || 'public'})</strong>
          </div>
        </div>

        {/* SUB TABS */}
        <div className="flex border-b border-white/10 bg-black/20 px-5 pt-2 gap-2 overflow-x-auto">
          {[
            { id: 'overview', label: 'Clan Overview', icon: Info },
            { id: 'members', label: `Members Roster (${members.length || family.memberCount})`, icon: Users },
            { id: 'edit', label: 'Edit Guild Details', icon: Edit3 },
            { id: 'governance', label: 'Governance & Transfer', icon: Shield }
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold rounded-t-xl transition whitespace-nowrap border-b-2 ${
                  isActive
                    ? 'border-amber-400 text-amber-300 bg-white/5'
                    : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-white/5'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-amber-400' : 'text-slate-400'}`} />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* ERROR DISPLAY */}
        {error && (
          <div className="mx-5 mt-4 p-3 rounded-xl bg-rose-500/20 border border-rose-500/40 text-rose-200 text-xs flex items-center gap-2.5">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <p className="font-medium">{error}</p>
          </div>
        )}

        {/* TAB CONTENTS (SCROLLABLE) */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3">
                <h4 className="text-xs font-black text-amber-300 uppercase tracking-wider">Clan Profile & Announcements</h4>
                <div className="space-y-2 text-xs">
                  <div className="flex justify-between border-b border-white/5 pb-2">
                    <span className="text-slate-400">Slogan / Motto:</span>
                    <span className="text-white font-medium text-right">{family.slogan || 'No slogan set.'}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-2">
                    <span className="text-slate-400">Official Announcement:</span>
                    <span className="text-amber-200 font-medium text-right">{family.announcement || 'No announcement.'}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-2">
                    <span className="text-slate-400">Description:</span>
                    <span className="text-slate-200 font-medium text-right">{family.description || 'No description provided.'}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-2">
                    <span className="text-slate-400">Join Policy:</span>
                    <span className="text-cyan-300 capitalize">{family.joinMethod || 'anyone'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Established Date:</span>
                    <span className="text-slate-300 font-mono">{family.createdAt ? new Date(family.createdAt).toLocaleDateString() : 'Active'}</span>
                  </div>
                </div>
              </div>

              {/* Clan Leader Card */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-950/40 to-slate-900 border border-amber-400/30 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <img
                    src={family.leaderAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80'}
                    alt={family.leaderName}
                    className="w-12 h-12 rounded-xl object-cover border-2 border-amber-400"
                  />
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white text-sm">{family.leaderName}</span>
                      <span className="px-2 py-0.5 rounded-md bg-amber-400 text-black text-[10px] font-black uppercase">
                        Clan Leader 👑
                      </span>
                    </div>
                    <p className="text-xs text-slate-300">Leader ID: <span className="font-mono text-amber-300">{family.leaderId}</span></p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveTab('governance')}
                  className="px-3 py-1.5 bg-amber-400/20 hover:bg-amber-400/30 text-amber-300 text-xs font-bold rounded-xl border border-amber-400/30 transition flex items-center gap-1"
                >
                  <ArrowRightLeft className="w-3.5 h-3.5" /> Transfer
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: MEMBERS ROSTER */}
          {activeTab === 'members' && (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                {/* Search */}
                <div className="relative flex-1 min-w-[200px]">
                  <input
                    type="text"
                    placeholder="Search clan members by name, UID, role..."
                    value={memberSearchQuery}
                    onChange={e => setMemberSearchQuery(e.target.value)}
                    className="w-full pl-9 pr-4 py-2 bg-black/50 border border-white/10 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400"
                  />
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={loadFamilyMembers}
                    className="px-3 py-2 bg-white/5 hover:bg-white/15 text-slate-300 text-xs font-bold rounded-xl transition flex items-center gap-1"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isLoadingMembers ? 'animate-spin' : ''}`} /> Refresh
                  </button>
                  <button
                    onClick={() => setShowAddMember(true)}
                    className="px-3.5 py-2 bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-black font-black text-xs rounded-xl shadow-md transition flex items-center gap-1.5"
                  >
                    <UserPlus className="w-3.5 h-3.5" /> Add Member
                  </button>
                </div>
              </div>

              {/* Members Table / List */}
              <div className="space-y-2">
                {isLoadingMembers ? (
                  <div className="p-8 text-center text-xs text-slate-400">Loading roster...</div>
                ) : filteredMembers.length === 0 ? (
                  <div className="p-8 text-center text-xs text-slate-400 bg-white/5 rounded-2xl border border-white/10">
                    No clan members found matching your search.
                  </div>
                ) : (
                  filteredMembers.map(member => {
                    const isLeader = member.role === 'leader' || member.userId === family.leaderId;

                    return (
                      <div
                        key={member.id || member.userId}
                        className="p-3 rounded-2xl bg-white/5 border border-white/10 flex flex-wrap items-center justify-between gap-3 hover:border-white/20 transition"
                      >
                        <div className="flex items-center gap-3">
                          <div className="relative">
                            <img
                              src={member.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80'}
                              alt={member.name}
                              className="w-10 h-10 rounded-xl object-cover border border-white/10"
                            />
                            {member.isOnline && (
                              <span className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-500 rounded-full border-2 border-slate-900" />
                            )}
                          </div>

                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-white text-xs">{member.name}</span>
                              <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                                isLeader
                                  ? 'bg-amber-400 text-black'
                                  : member.role === 'co_leader'
                                  ? 'bg-purple-500 text-white'
                                  : member.role === 'elder'
                                  ? 'bg-cyan-500 text-black'
                                  : 'bg-white/10 text-slate-300'
                              }`}>
                                {isLeader ? 'Leader 👑' : member.role === 'co_leader' ? 'Co-Leader 🛡️' : member.role === 'elder' ? 'Elder ⚔️' : 'Member'}
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-400 font-mono">
                              UID: {member.userUid || member.userId} • Total Contribution: <strong className="text-amber-300">🪙 {(member.contributionTotal || 0).toLocaleString()}</strong>
                            </p>
                          </div>
                        </div>

                        {/* Member Actions */}
                        <div className="flex items-center gap-2">
                          {!isLeader && (
                            <>
                              {/* Role Selector */}
                              <select
                                value={member.role}
                                onChange={e => handleUpdateRole(member.userId, e.target.value)}
                                className="px-2.5 py-1.5 bg-black/50 border border-white/10 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400"
                              >
                                <option value="co_leader" className="bg-slate-900">Co-Leader 🛡️</option>
                                <option value="elder" className="bg-slate-900">Elder ⚔️</option>
                                <option value="member" className="bg-slate-900">Member</option>
                              </select>

                              {/* Remove Button */}
                              <button
                                type="button"
                                onClick={() => handleRemoveMember(member.userId, member.name)}
                                className="p-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 text-xs transition"
                                title="Remove from Clan"
                              >
                                <UserX className="w-4 h-4" />
                              </button>
                            </>
                          )}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* POPUP: ADD MEMBER TO CLAN */}
              {showAddMember && (
                <div className="p-4 rounded-2xl bg-slate-950 border border-amber-400/40 space-y-3 shadow-2xl animate-fadeIn">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-black text-amber-300 uppercase flex items-center gap-1.5">
                      <UserPlus className="w-4 h-4" /> Add Registered User To Family
                    </h4>
                    <button
                      onClick={() => setShowAddMember(false)}
                      className="text-slate-400 hover:text-white"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[11px] font-bold text-slate-300 block mb-1">Search Platform User</label>
                      <input
                        type="text"
                        placeholder="Search by name, UID, email..."
                        value={userSearchQuery}
                        onChange={e => setUserSearchQuery(e.target.value)}
                        className="w-full px-3 py-2 bg-black/50 border border-white/15 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400"
                      />
                    </div>

                    <div>
                      <label className="text-[11px] font-bold text-slate-300 block mb-1">Assign Initial Role</label>
                      <select
                        value={newMemberRole}
                        onChange={e => setNewMemberRole(e.target.value as any)}
                        className="w-full px-3 py-2 bg-black/50 border border-white/15 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400"
                      >
                        <option value="member" className="bg-slate-900">Member</option>
                        <option value="elder" className="bg-slate-900">Elder ⚔️</option>
                        <option value="co_leader" className="bg-slate-900">Co-Leader 🛡️</option>
                      </select>
                    </div>
                  </div>

                  {/* Search Results */}
                  <div className="max-h-36 overflow-y-auto space-y-1.5 pr-1 custom-scrollbar">
                    {availableUsersToAdd.slice(0, 10).map((u, idx) => (
                      <div
                        key={`add-user-${u.id}-${idx}`}
                        onClick={() => setSelectedUserToAdd(u)}
                        className={`p-2 rounded-xl border cursor-pointer transition flex items-center justify-between ${
                          selectedUserToAdd?.id === u.id
                            ? 'bg-amber-400/20 border-amber-400'
                            : 'bg-white/5 border-white/10 hover:border-white/20'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <img
                            src={u.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80'}
                            alt={u.name}
                            className="w-7 h-7 rounded-lg object-cover"
                          />
                          <span className="text-xs font-bold text-white">{u.name}</span>
                          <span className="text-[10px] text-slate-400 font-mono">UID: {u.uid}</span>
                        </div>
                        {selectedUserToAdd?.id === u.id && (
                          <span className="text-xs font-bold text-amber-400">Selected ✓</span>
                        )}
                      </div>
                    ))}
                  </div>

                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setShowAddMember(false)}
                      className="px-3 py-1.5 bg-white/10 text-white text-xs rounded-xl"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      disabled={!selectedUserToAdd || isAddingMember}
                      onClick={handleAddMember}
                      className="px-4 py-1.5 bg-amber-400 text-black font-black text-xs rounded-xl hover:bg-amber-300 disabled:opacity-50 transition"
                    >
                      {isAddingMember ? 'Adding...' : 'Confirm Add Member'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: EDIT GUILD DETAILS */}
          {activeTab === 'edit' && (
            <form onSubmit={handleSaveEdit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-200">Family Name</label>
                  <input
                    type="text"
                    required
                    value={editName}
                    onChange={e => setEditName(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-black/50 border border-white/15 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-200">Badge Symbol</label>
                  <input
                    type="text"
                    value={editBadge}
                    onChange={e => setEditBadge(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-black/50 border border-white/15 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-200">Category</label>
                  <input
                    type="text"
                    value={editCategory}
                    onChange={e => setEditCategory(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-black/50 border border-white/15 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-200">Country / Region</label>
                  <input
                    type="text"
                    value={editCountry}
                    onChange={e => setEditCountry(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-black/50 border border-white/15 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-200">Slogan</label>
                <input
                  type="text"
                  value={editSlogan}
                  onChange={e => setEditSlogan(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-black/50 border border-white/15 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-200">Official Announcement</label>
                <textarea
                  rows={2}
                  value={editAnnouncement}
                  onChange={e => setEditAnnouncement(e.target.value)}
                  className="w-full px-3.5 py-2 bg-black/50 border border-white/15 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400 resize-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-200">Max Member Capacity</label>
                  <input
                    type="number"
                    min={10}
                    max={1000}
                    value={editMaxMembers}
                    onChange={e => setEditMaxMembers(Number(e.target.value))}
                    className="w-full px-3.5 py-2 bg-black/50 border border-white/15 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-200">Clan Level (1-10)</label>
                  <input
                    type="number"
                    min={1}
                    max={10}
                    value={editLevel}
                    onChange={e => setEditLevel(Number(e.target.value))}
                    className="w-full px-3.5 py-2 bg-black/50 border border-white/15 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-200">Status</label>
                  <select
                    value={editStatus}
                    onChange={e => setEditStatus(e.target.value as any)}
                    className="w-full px-3.5 py-2 bg-black/50 border border-white/15 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400"
                  >
                    <option value="active" className="bg-slate-900">Active 🟢</option>
                    <option value="inactive" className="bg-slate-900">Inactive ⚪</option>
                    <option value="suspended" className="bg-slate-900">Suspended 🔴</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 border-t border-white/10 flex justify-end">
                <button
                  type="submit"
                  disabled={isSavingEdit}
                  className="px-6 py-2.5 bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-black font-black text-xs rounded-xl shadow-lg transition flex items-center gap-2 disabled:opacity-50"
                >
                  {isSavingEdit ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                  Save Clan Details
                </button>
              </div>
            </form>
          )}

          {/* TAB 4: GOVERNANCE & TRANSFER */}
          {activeTab === 'governance' && (
            <div className="space-y-5">
              
              {/* Transfer Leadership Section */}
              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3">
                <h4 className="text-xs font-black text-amber-300 uppercase flex items-center gap-2">
                  <Crown className="w-4 h-4 text-amber-400" /> Transfer Family Clan Leadership
                </h4>
                <p className="text-xs text-slate-300">
                  Select another registered user on the platform to become the supreme Clan Leader. The previous leader will be assigned as Elder.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-bold text-slate-300 block mb-1">Target New Leader</label>
                    <select
                      value={transferTargetUser?.id || ''}
                      onChange={e => {
                        const target = allUsers.find(u => u.id === e.target.value);
                        setTransferTargetUser(target || null);
                      }}
                      className="w-full px-3 py-2 bg-black/50 border border-white/15 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400"
                    >
                      <option value="">-- Choose New Leader --</option>
                      {allUsers.filter(u => u.id !== family.leaderId).map((u, idx) => (
                        <option key={`opt-leader-${u.id}-${idx}`} value={u.id} className="bg-slate-900">
                          {u.name} (UID: {u.uid})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="flex items-end">
                    <button
                      type="button"
                      disabled={!transferTargetUser || isTransferring}
                      onClick={handleTransferLeadership}
                      className="w-full py-2 bg-amber-400 hover:bg-amber-300 text-black font-black text-xs rounded-xl shadow transition flex items-center justify-center gap-1.5 disabled:opacity-50"
                    >
                      {isTransferring ? 'Transferring...' : 'Execute Leadership Transfer'}
                    </button>
                  </div>
                </div>
              </div>

              {/* Disband Family (Danger Zone) */}
              <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 space-y-3">
                <h4 className="text-xs font-black text-rose-300 uppercase flex items-center gap-2">
                  <Trash2 className="w-4 h-4 text-rose-400" /> Danger Zone: Disband Family Guild
                </h4>
                <p className="text-xs text-slate-300">
                  Disbanding will permanently remove this Family from the directory, unlink all clan members, and archive all clan stats.
                </p>

                {confirmDisband ? (
                  <div className="p-3 bg-rose-950/60 border border-rose-500/50 rounded-xl space-y-3">
                    <p className="text-xs font-bold text-rose-200">
                      ⚠️ Are you absolutely certain you want to disband "{family.name}"? This action cannot be undone.
                    </p>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setConfirmDisband(false)}
                        className="px-3 py-1.5 bg-white/10 text-white text-xs font-bold rounded-xl"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        disabled={isDeleting}
                        onClick={handleDeleteFamily}
                        className="px-4 py-1.5 bg-rose-600 hover:bg-rose-500 text-white font-black text-xs rounded-xl shadow transition flex items-center gap-1.5 disabled:opacity-50"
                      >
                        {isDeleting ? 'Disbanding...' : 'Yes, Disband Guild Now'}
                      </button>
                    </div>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => setConfirmDisband(true)}
                    className="px-4 py-2 bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 text-xs font-bold rounded-xl border border-rose-500/30 transition flex items-center gap-1.5"
                  >
                    <Trash2 className="w-3.5 h-3.5" /> Disband Family Guild
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
