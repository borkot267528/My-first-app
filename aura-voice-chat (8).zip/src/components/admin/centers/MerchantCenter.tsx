import React, { useState, useEffect } from 'react';
import { 
  Building2, Search, Plus, RefreshCw, CheckCircle2, XCircle, 
  CreditCard, DollarSign, Edit3, ShieldAlert, FileSpreadsheet,
  Key, Globe, Percent, Copy, Check, ChevronRight, Lock
} from 'lucide-react';
import { Merchant } from '../../../types';
import { ApiClient } from '../../../lib/api';
import { exportToExcel, exportToPDF } from '../../../lib/exportUtils';

interface MerchantCenterProps {
  showNotification: (msg: string) => void;
}

export const MerchantCenter: React.FC<MerchantCenterProps> = ({ showNotification }) => {
  const [merchants, setMerchants] = useState<Merchant[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'pending' | 'suspended'>('all');

  // Add Merchant Modal
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [ownerUid, setOwnerUid] = useState('');
  const [feePercentage, setFeePercentage] = useState('2.9');
  const [currency, setCurrency] = useState('USD');
  const [webhookUrl, setWebhookUrl] = useState('');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Edit Merchant Modal
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [selectedMerchant, setSelectedMerchant] = useState<Merchant | null>(null);
  const [editFeePercentage, setEditFeePercentage] = useState('2.9');
  const [editWebhookUrl, setEditWebhookUrl] = useState('');
  const [editNotes, setEditNotes] = useState('');

  // Key Copy State
  const [copiedKeyId, setCopiedKeyId] = useState<string | null>(null);

  const loadMerchants = async () => {
    setLoading(true);
    try {
      const data = await ApiClient.getMerchants();
      setMerchants(data);
    } catch (err: any) {
      showNotification(err.message || 'Failed to load payment merchants');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadMerchants();
  }, []);

  const handleCreateMerchant = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      showNotification('Merchant name is required');
      return;
    }

    setIsSubmitting(true);
    try {
      const created = await ApiClient.createMerchant({
        name: name.trim(),
        code: code.trim() || undefined,
        ownerUid: ownerUid.trim() || undefined,
        feePercentage: Number(feePercentage) || 2.5,
        currency,
        webhookUrl: webhookUrl.trim() || undefined,
        notes: notes.trim() || undefined
      });
      showNotification(`Merchant ${created.name} registered successfully`);
      setAddModalOpen(false);
      setName('');
      setCode('');
      setOwnerUid('');
      setWebhookUrl('');
      setNotes('');
      loadMerchants();
    } catch (err: any) {
      showNotification(err.message || 'Failed to create merchant');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEditMerchant = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMerchant) return;

    setIsSubmitting(true);
    try {
      await ApiClient.updateMerchant(selectedMerchant.id, {
        feePercentage: Number(editFeePercentage),
        webhookUrl: editWebhookUrl.trim(),
        notes: editNotes.trim()
      });
      showNotification('Merchant configuration updated');
      setEditModalOpen(false);
      loadMerchants();
    } catch (err: any) {
      showNotification(err.message || 'Failed to update merchant');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleStatusToggle = async (merchant: Merchant, newStatus: 'active' | 'suspended' | 'inactive') => {
    try {
      await ApiClient.updateMerchantStatus(merchant.id, newStatus, `Status changed to ${newStatus}`);
      showNotification(`Merchant ${merchant.name} status updated to ${newStatus}`);
      loadMerchants();
    } catch (err: any) {
      showNotification(err.message || 'Failed to change merchant status');
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKeyId(id);
    showNotification('Copied to clipboard');
    setTimeout(() => setCopiedKeyId(null), 2000);
  };

  const filteredMerchants = merchants.filter(m => {
    const matchesSearch = searchQuery === '' || 
      m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.ownerName.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || m.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const totalProcessed = merchants.reduce((acc, m) => acc + (m.totalProcessedUsd || 0), 0);
  const totalBalance = merchants.reduce((acc, m) => acc + (m.availableBalanceUsd || 0), 0);
  const totalPendingSettlement = merchants.reduce((acc, m) => acc + (m.pendingSettlementUsd || 0), 0);

  const handleExportExcel = () => {
    exportToExcel('Merchants_Directory_Export', filteredMerchants.map(m => ({
      ID: m.id,
      Name: m.name,
      Code: m.code,
      Owner: m.ownerName,
      FeePercentage: `${m.feePercentage}%`,
      TotalProcessedUsd: `$${m.totalProcessedUsd}`,
      AvailableBalanceUsd: `$${m.availableBalanceUsd}`,
      Currency: m.currency,
      Status: m.status,
      CreatedDate: m.createdAt
    })));
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* HEADER */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
        <div>
          <h3 className="text-base font-black text-white flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-indigo-400" /> Payment Merchants & Gateways
          </h3>
          <p className="text-xs text-slate-300">
            Configure payment gateways, transaction fee rates, webhooks, and merchant settlements
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={loadMerchants}
            disabled={loading}
            className="p-2 bg-white/10 hover:bg-white/20 text-white rounded-xl transition-all"
            title="Refresh"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
          <button 
            onClick={handleExportExcel}
            className="px-3 py-1.5 bg-emerald-600/80 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition-all"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" /> Excel
          </button>
          <button 
            onClick={() => setAddModalOpen(true)}
            className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition-all shadow-lg shadow-indigo-600/20"
          >
            <Plus className="w-4 h-4" /> Add Merchant
          </button>
        </div>
      </div>

      {/* METRIC OVERVIEW */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-1">
          <span className="text-[10px] text-indigo-300 font-bold uppercase tracking-wider">Total Processed Vol.</span>
          <p className="text-xl font-black text-indigo-400 font-mono">${totalProcessed.toLocaleString()} USD</p>
          <span className="text-[10px] text-slate-400">Platform-wide card/wallet volume</span>
        </div>

        <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-1">
          <span className="text-[10px] text-emerald-300 font-bold uppercase tracking-wider">Available Balances</span>
          <p className="text-xl font-black text-emerald-400 font-mono">${totalBalance.toLocaleString()} USD</p>
          <span className="text-[10px] text-slate-400">Ready for payout sweep</span>
        </div>

        <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-1">
          <span className="text-[10px] text-amber-300 font-bold uppercase tracking-wider">Pending Settlements</span>
          <p className="text-xl font-black text-amber-400 font-mono">${totalPendingSettlement.toLocaleString()} USD</p>
          <span className="text-[10px] text-slate-400">In bank clearance pipeline</span>
        </div>

        <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-1">
          <span className="text-[10px] text-cyan-300 font-bold uppercase tracking-wider">Active Gateways</span>
          <p className="text-xl font-black text-cyan-400 font-mono">
            {merchants.filter(m => m.status === 'active').length} of {merchants.length}
          </p>
          <span className="text-[10px] text-slate-400">Operational endpoints</span>
        </div>
      </div>

      {/* SEARCH AND FILTERS */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by name, code, or owner..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-black/40 border border-white/10 rounded-xl text-white text-xs focus:outline-none focus:border-indigo-400"
          />
        </div>

        <div className="flex items-center gap-2">
          {['all', 'active', 'suspended'].map(s => (
            <button
              key={s}
              onClick={() => setStatusFilter(s as any)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all capitalize ${
                statusFilter === s
                  ? 'bg-indigo-600 text-white font-black'
                  : 'bg-white/5 text-slate-300 hover:bg-white/10'
              }`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* MERCHANTS GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredMerchants.map(m => (
          <div key={m.id} className="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-4 hover:border-white/20 transition-all">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[10px] font-mono text-indigo-400 uppercase tracking-wider font-bold">
                  {m.code}
                </span>
                <h4 className="text-base font-bold text-white flex items-center gap-2">
                  {m.name}
                </h4>
                <span className="text-xs text-slate-400">Managed by {m.ownerName} ({m.ownerUid})</span>
              </div>
              <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase ${
                m.status === 'active' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' :
                m.status === 'pending' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' :
                'bg-rose-500/20 text-rose-300 border border-rose-500/30'
              }`}>
                {m.status}
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2 p-3 rounded-xl bg-black/30 text-center font-mono">
              <div>
                <span className="text-[10px] text-slate-400 block font-sans">Fee Rate</span>
                <span className="text-xs font-bold text-indigo-300">{m.feePercentage}%</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block font-sans">Processed</span>
                <span className="text-xs font-bold text-white">${m.totalProcessedUsd.toLocaleString()}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block font-sans">Available</span>
                <span className="text-xs font-bold text-emerald-400">${m.availableBalanceUsd.toLocaleString()}</span>
              </div>
            </div>

            {/* API KEY & WEBHOOK INFO */}
            <div className="space-y-1 text-xs">
              <div className="flex items-center justify-between p-2 rounded-lg bg-black/40 font-mono text-[11px]">
                <span className="text-slate-400 flex items-center gap-1">
                  <Key className="w-3 h-3 text-amber-400" /> {m.apiKey}
                </span>
                <button
                  onClick={() => copyToClipboard(m.apiKey, m.id + '-key')}
                  className="text-slate-400 hover:text-white"
                  title="Copy API Key"
                >
                  {copiedKeyId === m.id + '-key' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>

              {m.webhookUrl && (
                <div className="flex items-center justify-between p-2 rounded-lg bg-black/40 text-[11px]">
                  <span className="text-slate-400 flex items-center gap-1 truncate max-w-[280px]">
                    <Globe className="w-3 h-3 text-cyan-400 shrink-0" /> {m.webhookUrl}
                  </span>
                </div>
              )}
            </div>

            {/* ACTIONS */}
            <div className="flex items-center justify-between pt-2 border-t border-white/5">
              <div className="flex gap-2">
                <button
                  onClick={() => {
                    setSelectedMerchant(m);
                    setEditFeePercentage(String(m.feePercentage));
                    setEditWebhookUrl(m.webhookUrl || '');
                    setEditNotes(m.notes || '');
                    setEditModalOpen(true);
                  }}
                  className="px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white font-bold text-xs rounded-xl flex items-center gap-1 transition-all"
                >
                  <Edit3 className="w-3 h-3" /> Configure
                </button>
              </div>

              <div className="flex gap-2">
                {m.status === 'active' ? (
                  <button
                    onClick={() => handleStatusToggle(m, 'suspended')}
                    className="px-3 py-1.5 bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 font-bold text-xs rounded-xl transition-all"
                  >
                    Suspend
                  </button>
                ) : (
                  <button
                    onClick={() => handleStatusToggle(m, 'active')}
                    className="px-3 py-1.5 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 font-bold text-xs rounded-xl transition-all"
                  >
                    Activate
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* ADD MERCHANT MODAL */}
      {addModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-md p-6 rounded-2xl bg-slate-900 border border-white/10 space-y-4">
            <h4 className="text-base font-bold text-white flex items-center gap-2">
              <Plus className="w-5 h-5 text-indigo-400" /> Register Payment Gateway / Merchant
            </h4>

            <form onSubmit={handleCreateMerchant} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Merchant Name *</label>
                <input
                  type="text"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="e.g. Stripe Checkout Gateway"
                  required
                  className="w-full px-3.5 py-2 bg-black/40 border border-white/10 rounded-xl text-white text-xs focus:outline-none focus:border-indigo-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Merchant Code</label>
                  <input
                    type="text"
                    value={code}
                    onChange={e => setCode(e.target.value)}
                    placeholder="e.g. MCH_STRIPE_01"
                    className="w-full px-3.5 py-2 bg-black/40 border border-white/10 rounded-xl text-white text-xs focus:outline-none focus:border-indigo-400 uppercase font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Fee Percentage (%)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={feePercentage}
                    onChange={e => setFeePercentage(e.target.value)}
                    className="w-full px-3.5 py-2 bg-black/40 border border-white/10 rounded-xl text-white text-xs focus:outline-none focus:border-indigo-400 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Owner User UID</label>
                <input
                  type="text"
                  value={ownerUid}
                  onChange={e => setOwnerUid(e.target.value)}
                  placeholder="Leave blank for CEO or enter UID"
                  className="w-full px-3.5 py-2 bg-black/40 border border-white/10 rounded-xl text-white text-xs focus:outline-none focus:border-indigo-400 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Webhook URL</label>
                <input
                  type="url"
                  value={webhookUrl}
                  onChange={e => setWebhookUrl(e.target.value)}
                  placeholder="https://api.domain.com/webhooks/payment"
                  className="w-full px-3.5 py-2 bg-black/40 border border-white/10 rounded-xl text-white text-xs focus:outline-none focus:border-indigo-400 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Notes</label>
                <input
                  type="text"
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  placeholder="e.g. Primary US Credit Card processor"
                  className="w-full px-3.5 py-2 bg-black/40 border border-white/10 rounded-xl text-white text-xs focus:outline-none focus:border-indigo-400"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setAddModalOpen(false)}
                  className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white font-bold text-xs rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl transition-all shadow-lg shadow-indigo-600/20"
                >
                  {isSubmitting ? 'Registering...' : 'Register Merchant'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* EDIT MERCHANT MODAL */}
      {editModalOpen && selectedMerchant && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-md p-6 rounded-2xl bg-slate-900 border border-white/10 space-y-4">
            <h4 className="text-base font-bold text-white flex items-center gap-2">
              <Edit3 className="w-5 h-5 text-indigo-400" /> Edit {selectedMerchant.name}
            </h4>

            <form onSubmit={handleEditMerchant} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Fee Percentage (%)</label>
                <input
                  type="number"
                  step="0.1"
                  value={editFeePercentage}
                  onChange={e => setEditFeePercentage(e.target.value)}
                  className="w-full px-3.5 py-2 bg-black/40 border border-white/10 rounded-xl text-white text-xs focus:outline-none focus:border-indigo-400 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Webhook URL</label>
                <input
                  type="url"
                  value={editWebhookUrl}
                  onChange={e => setEditWebhookUrl(e.target.value)}
                  placeholder="https://api.domain.com/webhooks/payment"
                  className="w-full px-3.5 py-2 bg-black/40 border border-white/10 rounded-xl text-white text-xs focus:outline-none focus:border-indigo-400 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Notes</label>
                <input
                  type="text"
                  value={editNotes}
                  onChange={e => setEditNotes(e.target.value)}
                  className="w-full px-3.5 py-2 bg-black/40 border border-white/10 rounded-xl text-white text-xs focus:outline-none focus:border-indigo-400"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setEditModalOpen(false)}
                  className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white font-bold text-xs rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl transition-all shadow-lg shadow-indigo-600/20"
                >
                  {isSubmitting ? 'Saving...' : 'Save Configuration'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
