import React, { useState, useEffect, useRef } from 'react';
import { 
  Megaphone, Plus, Edit2, Trash2, ArrowUp, ArrowDown, Search, Filter, 
  Calendar, Link as LinkIcon, Image as ImageIcon, CheckCircle2, XCircle, 
  Clock, AlertCircle, RefreshCw, Eye, Sparkles, Upload, FileImage
} from 'lucide-react';
import { Banner, BannerType, BannerTargetAction, BannerStatus, User } from '../../../types';
import { ApiClient } from '../../../lib/api';
import { exportToExcel } from '../../../lib/exportUtils';

interface BannerCenterProps {
  showNotification: (msg: string) => void;
  currentUser?: User | null;
  onRefresh?: () => void;
}

export const BannerCenter: React.FC<BannerCenterProps> = ({
  showNotification,
  currentUser,
  onRefresh
}) => {
  const [banners, setBanners] = useState<Banner[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Filters
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState<boolean>(false);
  const [editingBanner, setEditingBanner] = useState<Banner | null>(null);
  const [deletingBanner, setDeletingBanner] = useState<Banner | null>(null);
  const [previewingBanner, setPreviewingBanner] = useState<Banner | null>(null);

  // Form State
  const [formTitle, setFormTitle] = useState<string>('');
  const [formSubtitle, setFormSubtitle] = useState<string>('');
  const [formDescription, setFormDescription] = useState<string>('');
  const [formType, setFormType] = useState<BannerType>('event');
  const [formTargetAction, setFormTargetAction] = useState<BannerTargetAction>('none');
  const [formTargetRoomId, setFormTargetRoomId] = useState<string>('');
  const [formTargetUrl, setFormTargetUrl] = useState<string>('');
  const [formStartDate, setFormStartDate] = useState<string>('');
  const [formEndDate, setFormEndDate] = useState<string>('');
  const [formIsActive, setFormIsActive] = useState<boolean>(true);
  const [formSortOrder, setFormSortOrder] = useState<number>(1);
  const [formImageUrl, setFormImageUrl] = useState<string>('');
  const [formSubmitting, setFormSubmitting] = useState<boolean>(false);

  // Image Upload State
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [selectedFileName, setSelectedFileName] = useState<string>('');
  const [selectedFileSize, setSelectedFileSize] = useState<string>('');
  const [imagePreviewUrl, setImagePreviewUrl] = useState<string>('');
  const [isUploadingImage, setIsUploadingImage] = useState<boolean>(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [isDragOver, setIsDragOver] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  const handleProcessFile = async (file: File) => {
    setUploadError(null);
    
    // Validate format
    const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    if (!validTypes.includes(file.type.toLowerCase())) {
      const err = '⚠️ Invalid file type. Please upload a JPG, JPEG, PNG, or WEBP image.';
      setUploadError(err);
      showNotification(err);
      return;
    }

    // Validate size (max 10MB)
    const MAX_SIZE = 10 * 1024 * 1024;
    if (file.size > MAX_SIZE) {
      const err = `⚠️ File size (${formatFileSize(file.size)}) exceeds maximum limit of 10 MB.`;
      setUploadError(err);
      showNotification(err);
      return;
    }

    setSelectedFile(file);
    setSelectedFileName(file.name);
    setSelectedFileSize(formatFileSize(file.size));

    // Local immediate preview
    const localPreview = URL.createObjectURL(file);
    setImagePreviewUrl(localPreview);

    // Upload to server storage backend
    setIsUploadingImage(true);
    try {
      const uploadResult = await ApiClient.uploadImage(file, 'banner');
      setFormImageUrl(uploadResult.url);
      setImagePreviewUrl(uploadResult.url);
      showNotification(`✅ Banner image "${file.name}" uploaded successfully!`);
    } catch (err: any) {
      console.error('Image upload failed:', err);
      const errMsg = err.message || 'Failed to upload image to server storage';
      setUploadError(errMsg);
      showNotification(`❌ Upload Failed: ${errMsg}`);
    } finally {
      setIsUploadingImage(false);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleProcessFile(e.target.files[0]);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleProcessFile(e.dataTransfer.files[0]);
    }
  };

  const handleRemoveImage = () => {
    setSelectedFile(null);
    setSelectedFileName('');
    setSelectedFileSize('');
    setImagePreviewUrl('');
    setFormImageUrl('');
    setUploadError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const fetchBanners = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await ApiClient.getAdminBanners();
      setBanners(data);
    } catch (err: any) {
      console.error('Failed to load admin banners:', err);
      setError(err.message || 'Failed to fetch banners.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBanners();
  }, []);

  const resetForm = () => {
    setFormTitle('');
    setFormSubtitle('');
    setFormDescription('');
    setFormType('event');
    setFormTargetAction('none');
    setFormTargetRoomId('');
    setFormTargetUrl('');
    const now = new Date();
    const nextMonth = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
    setFormStartDate(now.toISOString().slice(0, 16));
    setFormEndDate(nextMonth.toISOString().slice(0, 16));
    setFormIsActive(true);
    setFormSortOrder(banners.length + 1);
    setFormImageUrl('');
    setSelectedFile(null);
    setSelectedFileName('');
    setSelectedFileSize('');
    setImagePreviewUrl('');
    setUploadError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const openAddModal = () => {
    resetForm();
    setIsAddModalOpen(true);
  };

  const openEditModal = (banner: Banner) => {
    setEditingBanner(banner);
    setFormTitle(banner.title);
    setFormSubtitle(banner.subtitle || '');
    setFormDescription(banner.description || '');
    setFormType(banner.type);
    setFormTargetAction(banner.targetAction);
    setFormTargetRoomId(banner.targetRoomId || '');
    setFormTargetUrl(banner.targetUrl || '');
    setFormStartDate(banner.startDate ? banner.startDate.slice(0, 16) : '');
    setFormEndDate(banner.endDate ? banner.endDate.slice(0, 16) : '');
    setFormIsActive(banner.isActive);
    setFormSortOrder(banner.sortOrder);
    setFormImageUrl(banner.imageUrl);
    setImagePreviewUrl(banner.imageUrl);
    setSelectedFileName(banner.imageUrl.split('/').pop() || 'Current Banner Graphic');
    setSelectedFileSize('');
    setSelectedFile(null);
    setUploadError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim()) {
      showNotification('⚠️ Banner title is required.');
      return;
    }
    if (!formImageUrl.trim()) {
      showNotification('⚠️ Please upload a banner image before creating the banner.');
      return;
    }
    if (!formStartDate || !formEndDate) {
      showNotification('⚠️ Start date and End date are required.');
      return;
    }

    setFormSubmitting(true);
    try {
      const payload: Partial<Banner> = {
        title: formTitle,
        subtitle: formSubtitle,
        description: formDescription,
        type: formType,
        targetAction: formTargetAction,
        targetRoomId: formTargetRoomId,
        targetUrl: formTargetUrl,
        startDate: new Date(formStartDate).toISOString(),
        endDate: new Date(formEndDate).toISOString(),
        isActive: formIsActive,
        sortOrder: formSortOrder,
        imageUrl: formImageUrl
      };

      await ApiClient.createBanner(payload);
      showNotification(`✅ Promotional banner "${formTitle}" created successfully!`);
      setIsAddModalOpen(false);
      resetForm();
      fetchBanners();
      if (onRefresh) onRefresh();
    } catch (err: any) {
      showNotification(`❌ Error: ${err.message || 'Failed to create banner'}`);
    } finally {
      setFormSubmitting(false);
    }
  };

  const handleUpdateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingBanner) return;

    if (!formTitle.trim()) {
      showNotification('⚠️ Banner title is required.');
      return;
    }
    if (!formImageUrl.trim()) {
      showNotification('⚠️ Banner image is required. Please upload an image.');
      return;
    }

    setFormSubmitting(true);
    try {
      const payload: Partial<Banner> = {
        title: formTitle,
        subtitle: formSubtitle,
        description: formDescription,
        type: formType,
        targetAction: formTargetAction,
        targetRoomId: formTargetRoomId,
        targetUrl: formTargetUrl,
        startDate: new Date(formStartDate).toISOString(),
        endDate: new Date(formEndDate).toISOString(),
        isActive: formIsActive,
        sortOrder: formSortOrder,
        imageUrl: formImageUrl
      };

      await ApiClient.updateBanner(editingBanner.id, payload);
      showNotification(`✅ Banner "${formTitle}" updated successfully!`);
      setEditingBanner(null);
      fetchBanners();
      if (onRefresh) onRefresh();
    } catch (err: any) {
      showNotification(`❌ Error: ${err.message || 'Failed to update banner'}`);
    } finally {
      setFormSubmitting(false);
    }
  };

  const handleDeleteConfirm = async () => {
    if (!deletingBanner) return;
    setFormSubmitting(true);
    try {
      await ApiClient.deleteBanner(deletingBanner.id);
      showNotification(`🗑️ Banner "${deletingBanner.title}" deleted.`);
      setDeletingBanner(null);
      fetchBanners();
      if (onRefresh) onRefresh();
    } catch (err: any) {
      showNotification(`❌ Error: ${err.message || 'Failed to delete banner'}`);
    } finally {
      setFormSubmitting(false);
    }
  };

  const handleMoveOrder = async (index: number, direction: 'up' | 'down') => {
    const newBanners = [...banners];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= newBanners.length) return;

    const temp = newBanners[index];
    newBanners[index] = newBanners[targetIndex];
    newBanners[targetIndex] = temp;

    const orderedIds = newBanners.map(b => b.id);
    setBanners(newBanners);

    try {
      await ApiClient.reorderBanners(orderedIds);
      showNotification('⚡ Banner display order updated.');
      fetchBanners();
      if (onRefresh) onRefresh();
    } catch (err: any) {
      showNotification(`❌ Error: ${err.message || 'Failed to reorder banners'}`);
      fetchBanners();
    }
  };

  const handleToggleActive = async (banner: Banner) => {
    try {
      await ApiClient.updateBanner(banner.id, { isActive: !banner.isActive });
      showNotification(`Status updated: Banner "${banner.title}" is now ${!banner.isActive ? 'ACTIVE' : 'INACTIVE'}`);
      fetchBanners();
      if (onRefresh) onRefresh();
    } catch (err: any) {
      showNotification(`❌ ${err.message}`);
    }
  };

  // Filter calculation
  const filteredBanners = banners.filter(b => {
    const matchesSearch = searchQuery === '' || 
      b.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (b.subtitle && b.subtitle.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesStatus = statusFilter === 'all' || (b.status || 'inactive') === statusFilter;
    const matchesType = typeFilter === 'all' || b.type === typeFilter;

    return matchesSearch && matchesStatus && matchesType;
  });

  const getStatusBadge = (status?: BannerStatus) => {
    switch (status) {
      case 'active':
        return <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-bold"><CheckCircle2 className="w-3 h-3" /> Active</span>;
      case 'scheduled':
        return <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 text-[10px] font-bold"><Clock className="w-3 h-3" /> Scheduled</span>;
      case 'expired':
        return <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 text-[10px] font-bold"><AlertCircle className="w-3 h-3" /> Expired</span>;
      default:
        return <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-slate-500/20 text-slate-400 border border-slate-500/40 text-[10px] font-bold"><XCircle className="w-3 h-3" /> Inactive</span>;
    }
  };

  const getTypeBadge = (type: BannerType) => {
    const map: Record<BannerType, { color: string; label: string }> = {
      event: { color: 'bg-purple-500/20 text-purple-300 border-purple-500/30', label: '🎉 Event' },
      pk: { color: 'bg-rose-500/20 text-rose-300 border-rose-500/30', label: '⚔️ PK Championship' },
      recharge: { color: 'bg-amber-500/20 text-amber-300 border-amber-500/30', label: '🪙 Recharge' },
      vip: { color: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30', label: '👑 VIP / SVIP' },
      gift: { color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30', label: '🎁 Gift / Drop' },
      custom: { color: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30', label: '🚀 Custom Promo' }
    };
    const item = map[type] || map.custom;
    return <span className={`px-2 py-0.5 rounded text-[10px] font-extrabold uppercase border ${item.color}`}>{item.label}</span>;
  };

  const handleExport = () => {
    exportToExcel('Home_Promotional_Banners', banners);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* HEADER BAR */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
        <div>
          <h3 className="text-base font-black text-white flex items-center gap-2">
            <Megaphone className="w-5 h-5 text-amber-400" /> Mobile Home Slider & Banner Management Center
          </h3>
          <p className="text-xs text-slate-300">Create, schedule, reorder, and configure promotional banners displayed on mobile app Home Page</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={handleExport} className="px-3.5 py-1.5 bg-emerald-600/80 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl transition-all">
            Export Banners
          </button>
          <button onClick={openAddModal} className="px-4 py-2 bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-black font-black text-xs rounded-xl shadow-lg flex items-center gap-1.5 transition-all">
            <Plus className="w-4 h-4" /> Add New Banner
          </button>
        </div>
      </div>

      {/* SEARCH AND FILTER BAR */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 bg-white/5 p-3 rounded-2xl border border-white/10">
        <div className="relative sm:col-span-2">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search by Title, Subtitle, or Banner ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-black/40 border border-white/10 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-amber-400"
          />
        </div>

        <div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-400"
          >
            <option value="all">All Statuses</option>
            <option value="active">Active Only</option>
            <option value="scheduled">Scheduled</option>
            <option value="expired">Expired</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>

        <div>
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-400"
          >
            <option value="all">All Banner Types</option>
            <option value="pk">⚔️ PK Championship</option>
            <option value="vip">👑 VIP / SVIP</option>
            <option value="recharge">🪙 Recharge</option>
            <option value="event">🎉 Event</option>
            <option value="gift">🎁 Gift / Drop</option>
            <option value="custom">🚀 Custom</option>
          </select>
        </div>
      </div>

      {/* TABLE CONTAINER */}
      <div className="bg-white/5 backdrop-blur-xl rounded-3xl border border-white/10 overflow-hidden shadow-2xl">
        {loading ? (
          <div className="p-12 text-center text-slate-400 space-y-3">
            <RefreshCw className="w-8 h-8 animate-spin mx-auto text-amber-400" />
            <p className="text-xs font-bold">Loading promotional banners from database...</p>
          </div>
        ) : error ? (
          <div className="p-8 text-center text-rose-400 space-y-2">
            <AlertCircle className="w-8 h-8 mx-auto" />
            <p className="text-xs font-bold">{error}</p>
            <button onClick={fetchBanners} className="px-3 py-1 bg-white/10 rounded-lg text-xs hover:bg-white/20">Retry</button>
          </div>
        ) : filteredBanners.length === 0 ? (
          <div className="p-12 text-center text-slate-400 space-y-3">
            <Megaphone className="w-10 h-10 mx-auto text-slate-600" />
            <p className="text-sm font-bold text-slate-300">No promotional banners found</p>
            <p className="text-xs text-slate-400">Click "Add New Banner" to create the first promotional slider for mobile users.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-black/50 text-slate-300 font-black border-b border-white/10 uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="p-3.5 text-center">Order</th>
                  <th className="p-3.5">Banner Preview</th>
                  <th className="p-3.5">Title & Subtitle</th>
                  <th className="p-3.5">Type & Target</th>
                  <th className="p-3.5">Schedule</th>
                  <th className="p-3.5">Status</th>
                  <th className="p-3.5">Created By</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/10 text-slate-200">
                {filteredBanners.map((banner, index) => (
                  <tr key={banner.id} className="hover:bg-white/10 transition-colors">
                    {/* SORT ORDER & REORDER BUTTONS */}
                    <td className="p-3 text-center">
                      <div className="flex items-center justify-center gap-1 font-mono font-bold">
                        <span className="w-5 text-amber-400 text-xs">#{banner.sortOrder}</span>
                        <div className="flex flex-col gap-0.5">
                          <button
                            disabled={index === 0}
                            onClick={() => handleMoveOrder(index, 'up')}
                            className="p-1 hover:bg-white/20 rounded disabled:opacity-20 text-slate-300"
                            title="Move Up"
                          >
                            <ArrowUp className="w-3 h-3" />
                          </button>
                          <button
                            disabled={index === filteredBanners.length - 1}
                            onClick={() => handleMoveOrder(index, 'down')}
                            className="p-1 hover:bg-white/20 rounded disabled:opacity-20 text-slate-300"
                            title="Move Down"
                          >
                            <ArrowDown className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    </td>

                    {/* IMAGE PREVIEW */}
                    <td className="p-3">
                      <div className="relative w-24 h-12 rounded-xl overflow-hidden border border-white/20 bg-black/60 group cursor-pointer" onClick={() => setPreviewingBanner(banner)}>
                        <img src={banner.imageUrl} alt={banner.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                          <Eye className="w-4 h-4 text-white" />
                        </div>
                      </div>
                    </td>

                    {/* TITLE & SUBTITLE */}
                    <td className="p-3 max-w-xs">
                      <div className="font-extrabold text-white text-xs truncate">{banner.title}</div>
                      <div className="text-[11px] text-slate-300 truncate">{banner.subtitle || 'No subtitle'}</div>
                      <div className="text-[10px] font-mono text-slate-400 mt-0.5">ID: {banner.id}</div>
                    </td>

                    {/* TYPE & TARGET */}
                    <td className="p-3 space-y-1">
                      <div>{getTypeBadge(banner.type)}</div>
                      <div className="text-[10px] text-slate-300 flex items-center gap-1 font-mono">
                        <LinkIcon className="w-3 h-3 text-cyan-400" /> Action: {banner.targetAction}
                        {banner.targetRoomId && <span className="text-amber-300">({banner.targetRoomId})</span>}
                      </div>
                    </td>

                    {/* SCHEDULE DATES */}
                    <td className="p-3 text-[11px] font-mono text-slate-300 space-y-0.5">
                      <div className="flex items-center gap-1 text-slate-300">
                        <Calendar className="w-3 h-3 text-emerald-400" /> {new Date(banner.startDate).toLocaleDateString()}
                      </div>
                      <div className="flex items-center gap-1 text-slate-400">
                        <Clock className="w-3 h-3 text-rose-400" /> {new Date(banner.endDate).toLocaleDateString()}
                      </div>
                    </td>

                    {/* STATUS */}
                    <td className="p-3">
                      <div className="space-y-1">
                        {getStatusBadge(banner.status)}
                        <div>
                          <button
                            onClick={() => handleToggleActive(banner)}
                            className={`text-[10px] px-2 py-0.5 rounded border ${banner.isActive ? 'bg-amber-500/20 text-amber-300 border-amber-500/30 hover:bg-amber-500/40' : 'bg-slate-700/50 text-slate-400 border-slate-600 hover:bg-slate-700'}`}
                          >
                            {banner.isActive ? 'Switch Inactive' : 'Activate'}
                          </button>
                        </div>
                      </div>
                    </td>

                    {/* CREATED BY */}
                    <td className="p-3 text-[11px] text-slate-300">
                      <div className="font-bold text-white">{banner.createdBy}</div>
                      <div className="text-[10px] text-slate-400">{new Date(banner.createdAt).toLocaleDateString()}</div>
                    </td>

                    {/* ACTIONS */}
                    <td className="p-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => openEditModal(banner)}
                          className="p-1.5 bg-blue-500/20 text-blue-300 hover:bg-blue-500/40 border border-blue-500/30 rounded-xl transition-all"
                          title="Edit Banner"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setDeletingBanner(banner)}
                          className="p-1.5 bg-rose-500/20 text-rose-300 hover:bg-rose-500/40 border border-rose-500/30 rounded-xl transition-all"
                          title="Delete Banner"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ADD / EDIT BANNER MODAL */}
      {(isAddModalOpen || editingBanner) && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#1a0b2e]/95 border border-amber-400/40 rounded-3xl p-6 w-full max-w-2xl space-y-5 shadow-2xl my-8">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="text-base font-black text-amber-300 flex items-center gap-2">
                <Megaphone className="w-5 h-5 text-amber-400" />
                {editingBanner ? `Edit Banner: ${editingBanner.title}` : 'Create New Promotional Banner'}
              </h3>
              <button
                onClick={() => { setIsAddModalOpen(false); setEditingBanner(null); }}
                className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300"
              >
                ✕
              </button>
            </div>

            <form onSubmit={editingBanner ? handleUpdateSubmit : handleCreateSubmit} className="space-y-4">
              {/* BANNER IMAGE UPLOAD FIELD */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-extrabold text-slate-300 flex items-center gap-1.5">
                    <ImageIcon className="w-4 h-4 text-amber-400" /> Banner Image *
                  </label>
                  <span className="text-[10px] text-amber-300 font-semibold bg-amber-400/10 px-2 py-0.5 rounded-full border border-amber-400/20">
                    Recommended: 16:9 • JPG, PNG, WEBP (Max 10MB)
                  </span>
                </div>

                {/* Hidden native file input for mobile and desktop selection */}
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileInputChange}
                  accept="image/jpeg,image/png,image/webp,image/jpg"
                  className="hidden"
                  id="banner-image-file-input"
                />

                {/* Upload zone when no image is chosen */}
                {!imagePreviewUrl && !formImageUrl ? (
                  <div
                    onDragOver={(e) => { e.preventDefault(); setIsDragOver(true); }}
                    onDragLeave={() => setIsDragOver(false)}
                    onDrop={handleDrop}
                    onClick={() => fileInputRef.current?.click()}
                    className={`cursor-pointer rounded-2xl border-2 border-dashed p-6 flex flex-col items-center justify-center text-center transition-all bg-black/40 hover:bg-black/60 group ${
                      isDragOver 
                        ? 'border-amber-400 bg-amber-400/10 scale-[1.01]' 
                        : 'border-white/20 hover:border-amber-400/60'
                    }`}
                  >
                    <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500/20 to-yellow-500/10 border border-amber-400/30 flex items-center justify-center mb-3 group-hover:scale-110 group-hover:border-amber-400 transition-all text-amber-400">
                      <Upload className="w-7 h-7" />
                    </div>
                    <button
                      type="button"
                      onClick={(e) => { e.stopPropagation(); fileInputRef.current?.click(); }}
                      className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 text-black text-xs font-black hover:from-amber-300 hover:to-yellow-400 transition-all shadow-md flex items-center gap-2 mb-2"
                    >
                      <Upload className="w-4 h-4 stroke-[2.5]" /> Upload Image
                    </button>
                    <p className="text-xs text-slate-300 font-medium">
                      Tap to select photo from phone or browse files
                    </p>
                    <p className="text-[11px] text-slate-500 mt-1">
                      Supports JPG, JPEG, PNG, WEBP up to 10MB
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {/* 16:9 Banner Image Preview Box */}
                    <div className="relative w-full aspect-[16/9] max-h-56 rounded-2xl overflow-hidden border-2 border-amber-400/40 bg-black/80 shadow-xl group">
                      <img
                        src={imagePreviewUrl || formImageUrl}
                        alt="Banner preview"
                        className="w-full h-full object-cover"
                        onError={() => showNotification('⚠️ Unable to load image preview')}
                      />
                      
                      {/* Loading overlay during upload */}
                      {isUploadingImage && (
                        <div className="absolute inset-0 bg-black/75 backdrop-blur-sm flex flex-col items-center justify-center gap-2 z-20">
                          <RefreshCw className="w-8 h-8 text-amber-400 animate-spin" />
                          <span className="text-xs font-bold text-amber-300">Uploading to server storage...</span>
                        </div>
                      )}

                      {/* Live Preview Badge */}
                      <div className="absolute top-2 left-2 z-10 flex items-center gap-1.5">
                        <span className="bg-black/70 backdrop-blur-md text-amber-300 text-[10px] font-black px-2.5 py-1 rounded-lg border border-amber-400/30 flex items-center gap-1">
                          <Eye className="w-3 h-3 text-amber-400" /> Live 16:9 Banner Preview
                        </span>
                      </div>

                      {/* Action Overlay */}
                      <div className="absolute bottom-2 right-2 z-10 flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => fileInputRef.current?.click()}
                          className="px-3 py-1.5 rounded-xl bg-black/80 hover:bg-black text-amber-300 hover:text-amber-200 text-xs font-bold border border-amber-400/40 backdrop-blur-md transition-all shadow flex items-center gap-1"
                        >
                          <RefreshCw className="w-3.5 h-3.5" /> Change Image
                        </button>
                        <button
                          type="button"
                          onClick={handleRemoveImage}
                          className="px-3 py-1.5 rounded-xl bg-rose-950/80 hover:bg-rose-900 text-rose-300 text-xs font-bold border border-rose-500/40 backdrop-blur-md transition-all shadow flex items-center gap-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" /> Remove Image
                        </button>
                      </div>
                    </div>

                    {/* Selected File Details Bar */}
                    <div className="flex items-center justify-between p-2.5 rounded-xl bg-black/40 border border-white/10 text-xs">
                      <div className="flex items-center gap-2 min-w-0">
                        <div className="p-1.5 rounded-lg bg-amber-400/10 text-amber-400 flex-shrink-0">
                          <FileImage className="w-4 h-4" />
                        </div>
                        <div className="truncate">
                          <div className="text-white font-semibold truncate text-[11px]">
                            {selectedFileName || (formImageUrl.startsWith('/api/uploads/') ? formImageUrl.split('/').pop() : 'Uploaded Banner Graphic')}
                          </div>
                          {selectedFileSize && (
                            <div className="text-[10px] text-slate-400">{selectedFileSize}</div>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-2 flex-shrink-0">
                        {formImageUrl && !isUploadingImage && (
                          <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded-md flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3 text-emerald-400" /> Stored in System
                          </span>
                        )}
                        <button
                          type="button"
                          onClick={() => fileInputRef.current?.click()}
                          className="text-[11px] text-amber-400 hover:text-amber-300 font-bold underline ml-1"
                        >
                          Change
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {uploadError && (
                  <div className="p-2.5 rounded-xl bg-rose-950/50 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 flex-shrink-0 text-rose-400" />
                    <span>{uploadError}</span>
                  </div>
                )}
              </div>

              {/* TITLE & SUBTITLE */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">Banner Title *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 🎉 Summer PK Championship"
                    value={formTitle}
                    onChange={(e) => setFormTitle(e.target.value)}
                    className="w-full bg-black/50 border border-white/20 rounded-xl p-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">Subtitle / Tagline</label>
                  <input
                    type="text"
                    placeholder="e.g. Win 1,000,000 Diamonds & Royal Dragon Frame!"
                    value={formSubtitle}
                    onChange={(e) => setFormSubtitle(e.target.value)}
                    className="w-full bg-black/50 border border-white/20 rounded-xl p-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              {/* DESCRIPTION */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-300">Detailed Description (Optional)</label>
                <textarea
                  rows={2}
                  placeholder="Additional event details displayed when banner is opened..."
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  className="w-full bg-black/50 border border-white/20 rounded-xl p-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* TYPE & TARGET ACTION */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">Banner Type *</label>
                  <select
                    value={formType}
                    onChange={(e) => setFormType(e.target.value as BannerType)}
                    className="w-full bg-black/50 border border-white/20 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="event">🎉 Event</option>
                    <option value="pk">⚔️ PK Championship</option>
                    <option value="recharge">🪙 Recharge Promo</option>
                    <option value="vip">👑 VIP / SVIP Club</option>
                    <option value="gift">🎁 Gift / Lucky Drop</option>
                    <option value="custom">🚀 Custom Campaign</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">Target Action on Tap *</label>
                  <select
                    value={formTargetAction}
                    onChange={(e) => setFormTargetAction(e.target.value as BannerTargetAction)}
                    className="w-full bg-black/50 border border-white/20 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="none">None (Display Only)</option>
                    <option value="open_room">Open Specific Voice Room</option>
                    <option value="open_vip">Open VIP Privileges Shop</option>
                    <option value="open_recharge">Open Coin Recharge Portal</option>
                    <option value="open_event">Open Event Center Modal</option>
                    <option value="open_custom">Custom URL / External Link</option>
                  </select>
                </div>
              </div>

              {/* CONDITIONAL TARGET INPUTS */}
              {formTargetAction === 'open_room' && (
                <div className="space-y-1 bg-purple-500/10 p-3 rounded-2xl border border-purple-500/30 animate-fadeIn">
                  <label className="text-xs font-extrabold text-purple-300">Target Voice Room ID</label>
                  <input
                    type="text"
                    placeholder="e.g. room-101"
                    value={formTargetRoomId}
                    onChange={(e) => setFormTargetRoomId(e.target.value)}
                    className="w-full bg-black/50 border border-purple-500/40 rounded-xl p-2 text-xs text-white focus:outline-none focus:border-purple-300"
                  />
                </div>
              )}

              {(formTargetAction === 'open_custom' || formTargetAction === 'open_event') && (
                <div className="space-y-1 bg-cyan-500/10 p-3 rounded-2xl border border-cyan-500/30 animate-fadeIn">
                  <label className="text-xs font-extrabold text-cyan-300">Target Route or External URL</label>
                  <input
                    type="text"
                    placeholder="e.g. /events/summer-pk-2026 or https://..."
                    value={formTargetUrl}
                    onChange={(e) => setFormTargetUrl(e.target.value)}
                    className="w-full bg-black/50 border border-cyan-500/40 rounded-xl p-2 text-xs text-white focus:outline-none focus:border-cyan-300"
                  />
                </div>
              )}

              {/* SCHEDULE DATES & ORDER */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">Start Date & Time *</label>
                  <input
                    type="datetime-local"
                    required
                    value={formStartDate}
                    onChange={(e) => setFormStartDate(e.target.value)}
                    className="w-full bg-black/50 border border-white/20 rounded-xl p-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">End Date & Time *</label>
                  <input
                    type="datetime-local"
                    required
                    value={formEndDate}
                    onChange={(e) => setFormEndDate(e.target.value)}
                    className="w-full bg-black/50 border border-white/20 rounded-xl p-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">Sort Order #</label>
                  <input
                    type="number"
                    min={1}
                    max={99}
                    value={formSortOrder}
                    onChange={(e) => setFormSortOrder(parseInt(e.target.value) || 1)}
                    className="w-full bg-black/50 border border-white/20 rounded-xl p-2 text-xs text-white focus:outline-none focus:border-amber-400 font-mono"
                  />
                </div>
              </div>

              {/* ACTIVE TOGGLE */}
              <div className="flex items-center justify-between p-3 rounded-2xl bg-white/5 border border-white/10">
                <div>
                  <div className="text-xs font-bold text-white">Enable Banner Immediately</div>
                  <div className="text-[10px] text-slate-400">If checked, banner will display during scheduled date window</div>
                </div>
                <input
                  type="checkbox"
                  checked={formIsActive}
                  onChange={(e) => setFormIsActive(e.target.checked)}
                  className="w-5 h-5 accent-amber-400 cursor-pointer rounded"
                />
              </div>

              {/* SUBMIT BUTTONS */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => { setIsAddModalOpen(false); setEditingBanner(null); }}
                  className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 text-xs font-bold transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={formSubmitting}
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 text-black text-xs font-black hover:from-amber-300 hover:to-yellow-400 transition-all shadow-lg flex items-center gap-1.5 disabled:opacity-50"
                >
                  {formSubmitting && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
                  {editingBanner ? 'Save Changes' : 'Create Banner'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION MODAL */}
      {deletingBanner && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#1a0b2e] border border-rose-500/40 rounded-3xl p-6 w-full max-w-md space-y-4 text-center shadow-2xl">
            <div className="w-12 h-12 bg-rose-500/20 text-rose-400 border border-rose-500/30 rounded-2xl flex items-center justify-center mx-auto text-2xl">
              🗑️
            </div>
            <h3 className="text-base font-black text-white">Delete Promotional Banner?</h3>
            <p className="text-xs text-slate-300">
              Are you sure you want to delete <span className="font-bold text-amber-300">"{deletingBanner.title}"</span>? This action cannot be undone and will remove it from the mobile app slider.
            </p>
            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                onClick={() => setDeletingBanner(null)}
                className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 text-xs font-bold"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteConfirm}
                disabled={formSubmitting}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center gap-1.5 disabled:opacity-50"
              >
                {formSubmitting && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* BANNER PREVIEW MODAL */}
      {previewingBanner && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4" onClick={() => setPreviewingBanner(null)}>
          <div className="bg-slate-900 border border-amber-400/40 rounded-3xl p-5 w-full max-w-lg space-y-4 relative shadow-2xl" onClick={e => e.stopPropagation()}>
            <button
              onClick={() => setPreviewingBanner(null)}
              className="absolute top-3 right-3 p-1.5 rounded-full bg-white/10 text-white hover:bg-white/20"
            >
              ✕
            </button>
            <div className="text-xs font-black text-amber-400 flex items-center gap-2">
              <Sparkles className="w-4 h-4" /> Mobile App Home Banner Preview
            </div>
            <div className="rounded-2xl overflow-hidden border border-white/20 relative aspect-[16/9] shadow-inner">
              <img src={previewingBanner.imageUrl} alt={previewingBanner.title} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent p-4 flex flex-col justify-end">
                <span className="text-[10px] font-extrabold uppercase text-amber-300 bg-amber-500/20 px-2 py-0.5 rounded w-fit border border-amber-500/30 mb-1">
                  {previewingBanner.type}
                </span>
                <h4 className="text-base font-black text-white">{previewingBanner.title}</h4>
                <p className="text-xs text-slate-200">{previewingBanner.subtitle}</p>
              </div>
            </div>
            {previewingBanner.description && (
              <p className="text-xs text-slate-300 bg-white/5 p-3 rounded-xl border border-white/10">
                {previewingBanner.description}
              </p>
            )}
            <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 pt-1 border-t border-white/10">
              <span>Target: {previewingBanner.targetAction}</span>
              <span>Sort Order: #{previewingBanner.sortOrder}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
