import React, { useState } from 'react';
import { MessageSquare, Search, Trash2, Shield, Eye, Send, Copy, Forward } from 'lucide-react';

interface MessagingCenterProps {
  showNotification: (msg: string) => void;
}

export const MessagingCenter: React.FC<MessagingCenterProps> = ({ showNotification }) => {
  const [searchQuery, setSearchQuery] = useState('');

  const messages = [
    { id: 'msg-01', sender: 'Elena Vance', receiver: 'John Doe', type: 'text', content: 'Hello! Welcome to the official platform room.', status: 'seen', timestamp: '10:45 AM' },
    { id: 'msg-02', sender: 'Alex Beats', receiver: 'Sophia VIP', type: 'image', content: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4', status: 'seen', timestamp: '11:12 AM' },
    { id: 'msg-03', sender: 'User 8829', receiver: 'Admin Support', type: 'voice', content: 'Voice Note (0:12s)', status: 'delivered', timestamp: '11:30 AM' }
  ];

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* HEADER BAR */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
        <div>
          <h3 className="text-base font-black text-white flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-cyan-400" /> Private Messaging & Safety Inspection Center
          </h3>
          <p className="text-xs text-slate-300">Live Chat Moderation, Spam Filter, Voice & Image Inspections, Audit Trail</p>
        </div>
      </div>

      <div className="rounded-2xl bg-white/5 border border-white/10 overflow-hidden shadow-xl p-4 space-y-3">
        <div className="flex items-center gap-2 bg-black/40 px-3 py-2 rounded-xl border border-white/10 text-xs">
          <Search className="w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search keywords or users..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-transparent text-white placeholder:text-slate-500 focus:outline-none"
          />
        </div>

        <div className="space-y-2">
          {messages.map(m => (
            <div key={m.id} className="p-3.5 rounded-xl bg-black/40 border border-white/10 flex items-center justify-between text-xs">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-amber-300">{m.sender}</span>
                  <span className="text-slate-500">➜</span>
                  <span className="font-bold text-cyan-300">{m.receiver}</span>
                  <span className="text-[10px] uppercase font-black px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300">
                    {m.type}
                  </span>
                </div>
                <p className="text-slate-200">{m.content}</p>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] text-slate-400 font-mono">{m.timestamp}</span>
                <button
                  onClick={() => showNotification(`Deleted message ${m.id}`)}
                  className="p-1.5 bg-red-500/20 text-red-300 hover:bg-red-500 hover:text-white rounded-lg transition-all"
                  title="Delete Message"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
