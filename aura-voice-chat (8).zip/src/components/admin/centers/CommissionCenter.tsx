import React, { useState } from 'react';
import { Award, Percent, DollarSign, Save, FileSpreadsheet, FileText, CheckCircle2 } from 'lucide-react';
import { exportToExcel, exportToPDF } from '../../../lib/exportUtils';

interface CommissionCenterProps {
  showNotification: (msg: string) => void;
}

export const CommissionCenter: React.FC<CommissionCenterProps> = ({ showNotification }) => {
  const [rates, setRates] = useState({
    ceo: 100,
    gm: 25,
    manager: 20,
    super_admin: 18,
    admin: 15,
    bd: 12,
    agency: 15,
    host: 70,
    recharge_agent: 10,
    coin_merchant: 8
  });

  const handleSaveRates = () => {
    showNotification('✅ Commission hierarchy rates updated successfully.');
  };

  const handleExportExcel = () => {
    const data = Object.entries(rates).map(([role, rate]) => ({ Role: role.toUpperCase(), CommissionPercentage: `${rate}%` }));
    exportToExcel('Commission_Rates_Config', data);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* HEADER BAR */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
        <div>
          <h3 className="text-base font-black text-white flex items-center gap-2">
            <Percent className="w-5 h-5 text-amber-400" /> Platform Commission & Revenue Split Center
          </h3>
          <p className="text-xs text-slate-300">Configurable Hierarchy Revenue Share (%) for Staff, Agencies, Merchants & Hosts</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={handleExportExcel} className="px-3 py-1.5 bg-emerald-600/80 text-white font-bold text-xs rounded-xl flex items-center gap-1.5">
            <FileSpreadsheet className="w-3.5 h-3.5" /> Export Config
          </button>
          <button onClick={handleSaveRates} className="px-4 py-1.5 bg-amber-400 text-black font-black text-xs rounded-xl flex items-center gap-1.5 shadow">
            <Save className="w-3.5 h-3.5" /> Save Changes
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {[
          { key: 'ceo', label: 'CEO Override Share', desc: 'Global platform equity share' },
          { key: 'gm', label: 'General Manager (GM)', desc: 'Regional operations cut' },
          { key: 'manager', label: 'Operations Manager', desc: 'Guild supervision cut' },
          { key: 'super_admin', label: 'Super Admin', desc: 'Administrative commission' },
          { key: 'admin', label: 'Admin Officer', desc: 'Moderation shift bonus cut' },
          { key: 'bd', label: 'BD (Business Dev)', desc: 'Onboarded agency incentive' },
          { key: 'agency', label: 'Talent Agency', desc: 'Agency commission rate' },
          { key: 'host', label: 'Host Streamer', desc: 'Diamond conversion cut' },
          { key: 'recharge_agent', label: 'Recharge Agent', desc: 'Payment gateway reseller cut' },
          { key: 'coin_merchant', label: 'Coin Merchant', desc: 'P2P coin trader commission' }
        ].map((item) => (
          <div key={item.key} className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-extrabold text-white text-xs">{item.label}</span>
              <span className="text-[10px] text-amber-300 font-mono font-bold">{(rates as any)[item.key]}%</span>
            </div>
            <p className="text-[10px] text-slate-400">{item.desc}</p>
            <div className="flex items-center gap-2 bg-black/40 px-3 py-1.5 rounded-xl border border-white/10">
              <input
                type="number"
                min="0"
                max="100"
                value={(rates as any)[item.key]}
                onChange={(e) => setRates({ ...rates, [item.key]: Number(e.target.value) })}
                className="w-full bg-transparent text-white font-mono font-bold text-xs focus:outline-none"
              />
              <span className="text-slate-400 font-bold text-xs">%</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
