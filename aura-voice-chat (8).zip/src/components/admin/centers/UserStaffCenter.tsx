import React, { useState } from 'react';
import { 
  Users, UserCheck, Shield, Search, Filter, Edit2, Key, Download, 
  FileSpreadsheet, FileText, CheckCircle2, Clock, Globe, Smartphone, 
  Wallet, Gift, RefreshCw, AlertCircle, ArrowUpRight, ArrowDownRight,
  ChevronLeft, ChevronRight, Ban, Crown, Award, Eye, Sparkles, Trash2, 
  History, UserPlus, ShieldAlert, Check, Building2, Calendar, Activity, Lock, ShieldCheck,
  X, CheckSquare, Square, Plus, Tag
} from 'lucide-react';
import { User, StaffMember, UserRole, AuditLog, StaffActivityLog, StaffIdentity } from '../../../types';
import { ApiClient } from '../../../lib/api';
import { exportToExcel, exportToPDF } from '../../../lib/exportUtils';
import { STAFF_IDENTITY_CONFIG, getEffectiveStaffIdentity, AVAILABLE_STAFF_POSITIONS, getStaffIdentitiesList } from '../../../lib/staffIdentity';
import { StaffIdentityBadgeCard } from '../../profile/StaffIdentityBadgeCard';
import { ProfileIdBadge } from '../../common/ProfileIdBadge';
import { getProfileIdColor } from '../../../lib/profileIdColor';
import { runProfileIdColorTests } from '../../../lib/profileIdColor.test';
import { UsersStaffDirectory } from '../directory/UsersStaffDirectory';
import { DynamicPermissionManager } from '../rbac/DynamicPermissionManager';

interface UserStaffCenterProps {
  users: User[];
  staff: StaffMember[];
  currentUser: User | null;
  auditLogs: AuditLog[];
  onRefresh: () => void;
  showNotification: (msg: string) => void;
  initialSubTab?: 'users' | 'staff_identity' | 'staff' | 'permissions' | 'activity';
}

export const UserStaffCenter: React.FC<UserStaffCenterProps> = ({
  users,
  currentUser,
  auditLogs,
  onRefresh,
  showNotification,
  initialSubTab
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'users' | 'staff_identity' | 'staff' | 'permissions' | 'activity'>(initialSubTab || 'staff_identity');

  React.useEffect(() => {
    if (initialSubTab) {
      setActiveSubTab(initialSubTab);
    }
  }, [initialSubTab]);
  const [searchField, setSearchField] = useState<'all' | 'id' | 'uid' | 'name' | 'email' | 'phone' | 'referral'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Filters
  const [vipFilter, setVipFilter] = useState<'all' | 'none' | 'vip' | 'svip'>('all');
  const [onlineFilter, setOnlineFilter] = useState<'all' | 'online' | 'offline'>('all');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [countryFilter, setCountryFilter] = useState<string>('all');
  
  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  // Drawer / Modal States
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [drawerTab, setDrawerTab] = useState<'profile' | 'uid' | 'profile_history' | 'uid_history' | 'login' | 'device' | 'wallet' | 'recharge' | 'withdraw' | 'gift' | 'referral'>('profile');
  
  // Edit UID state
  const [editUidModalUser, setEditUidModalUser] = useState<User | null>(null);
  const [newUidInput, setNewUidInput] = useState('');
  const [confirmUidInput, setConfirmUidInput] = useState('');
  const [uidReasonInput, setUidReasonInput] = useState('');
  const [showUidConfirmStep, setShowUidConfirmStep] = useState(false);
  const [isUpdatingUid, setIsUpdatingUid] = useState(false);

  const openEditUidModal = (u: User) => {
    setEditUidModalUser(u);
    setNewUidInput(u.uid);
    setConfirmUidInput(u.uid);
    setUidReasonInput('');
    setShowUidConfirmStep(false);
  };

  // Edit User Account state
  const [editModalUser, setEditModalUser] = useState<User | null>(null);
  const [editFormData, setEditFormData] = useState<Partial<User>>({});

  // Staff Identity Management state
  const [assignModalUser, setAssignModalUser] = useState<User | null>(null);
  const [assignFormData, setAssignFormData] = useState({
    roles: ['official_staff'] as UserRole[],
    title: 'Official Staff',
    staffId: '',
    staffLevel: 5,
    isVerified: true,
    department: 'Platform Operations',
    activeStatus: 'Active',
    notes: ''
  });
  const [positionSearchQuery, setPositionSearchQuery] = useState('');
  const [historyModalUser, setHistoryModalUser] = useState<User | null>(null);
  const [identityFilterRole, setIdentityFilterRole] = useState<string>('all');
  const [identitySearch, setIdentitySearch] = useState<string>('');
  const [isEditPermissionsOpen, setIsEditPermissionsOpen] = useState<boolean>(false);

  const isCeo = currentUser?.role === 'ceo';
  const isCeoOrGm = currentUser?.role === 'ceo' || currentUser?.role === 'gm';
  const canAssign = isCeo || ((currentUser?.role === 'gm' || currentUser?.role === 'manager') && currentUser?.canAssignIdentity === true);

  // Filtered users
  const filteredUsers = users.filter(u => {
    // Search query check
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      if (searchField === 'id' && !u.id.toLowerCase().includes(q)) return false;
      if (searchField === 'uid' && !u.uid.toLowerCase().includes(q)) return false;
      if (searchField === 'name' && !u.name.toLowerCase().includes(q)) return false;
      if (searchField === 'email' && !u.email.toLowerCase().includes(q)) return false;
      if (searchField === 'all') {
        const matches = u.id.toLowerCase().includes(q) ||
                        u.uid.toLowerCase().includes(q) ||
                        u.name.toLowerCase().includes(q) ||
                        u.email.toLowerCase().includes(q);
        if (!matches) return false;
      }
    }

    if (vipFilter !== 'all' && u.vipLevel !== vipFilter) return false;
    if (onlineFilter === 'online' && !u.isOnline) return false;
    if (onlineFilter === 'offline' && u.isOnline) return false;
    if (roleFilter !== 'all' && u.role !== roleFilter) return false;
    if (countryFilter !== 'all' && u.country !== countryFilter) return false;

    return true;
  });

  // Pagination logic
  const totalPages = Math.ceil(filteredUsers.length / itemsPerPage) || 1;
  const paginatedUsers = filteredUsers.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const handleUpdateUid = async () => {
    const target = editUidModalUser || selectedUser;
    if (!target) return;

    if (!isCeoOrGm) {
      showNotification('⛔ PERMISSION DENIED: Only CEO and General Manager (GM) roles are authorized to edit User UIDs.');
      return;
    }

    const trimmedNew = newUidInput.trim();
    const trimmedConfirm = confirmUidInput.trim();

    if (!trimmedNew) {
      showNotification('⚠️ User UID cannot be empty.');
      return;
    }

    if (trimmedNew !== trimmedConfirm) {
      showNotification('⚠️ New User UID and Confirm User UID do not match.');
      return;
    }

    // Format validation (1-20 chars alphanumeric, underscores, hyphens)
    const uidRegex = /^[a-zA-Z0-9_-]{1,20}$/;
    if (!uidRegex.test(trimmedNew)) {
      showNotification('⚠️ Invalid User UID format. User UID must be 1 to 20 alphanumeric characters, underscores, or hyphens.');
      return;
    }

    // Check uniqueness
    const duplicate = users.find(u => u.uid === trimmedNew && u.id !== target.id);
    if (duplicate) {
      showNotification(`⚠️ User UID [${trimmedNew}] is already assigned to user "${duplicate.name}" (ID: ${duplicate.id}). Update rejected.`);
      return;
    }

    // Confirmation step (Requirement 7)
    if (!showUidConfirmStep) {
      setShowUidConfirmStep(true);
      return;
    }

    setIsUpdatingUid(true);
    try {
      const updated = await ApiClient.updateUserId(target.id, trimmedNew, trimmedConfirm, uidReasonInput.trim());
      if (selectedUser && selectedUser.id === target.id) {
        setSelectedUser(updated);
      }
      window.dispatchEvent(new CustomEvent('user_profile_updated', { detail: updated }));
      window.dispatchEvent(new CustomEvent('users_updated', { detail: updated }));
      showNotification(`✅ User UID successfully changed from [${target.uid}] to [${updated.uid}] for ${updated.name}`);
      setEditUidModalUser(null);
      setShowUidConfirmStep(false);
      onRefresh();
    } catch (err: any) {
      showNotification(`⛔ ${err.message || 'Failed to update User UID'}`);
      setShowUidConfirmStep(false);
    } finally {
      setIsUpdatingUid(false);
    }
  };

  const handleSaveAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editModalUser) return;
    try {
      await ApiClient.updateUserAccount(editModalUser.id, editFormData);
      showNotification(`✅ Updated user ${editModalUser.name}`);
      setEditModalUser(null);
      onRefresh();
    } catch (err: any) {
      showNotification(err.message || 'Failed to save account');
    }
  };

  const handleExportExcel = () => {
    const data = filteredUsers.map(u => ({
      ID: u.id,
      UID: u.uid,
      Name: u.name,
      Email: u.email,
      Role: u.role,
      VIP: u.vipLevel,
      Coins: u.coins,
      Diamonds: u.diamonds,
      Country: u.country,
      Online: u.isOnline ? 'YES' : 'NO',
      CreatedAt: u.createdAt
    }));
    exportToExcel('Staff_User_Management', data);
  };

  const handleExportPDF = () => {
    const headers = ['UID', 'Name', 'Email', 'Role', 'VIP', 'Coins', 'Diamonds', 'Country'];
    const rows = filteredUsers.map(u => [
      u.uid, u.name, u.email, u.role.toUpperCase(), u.vipLevel.toUpperCase(), u.coins, u.diamonds, u.country
    ]);
    exportToPDF('Staff & User Management Directory', headers, rows);
  };

  const handleOpenAssignModal = (u: User) => {
    const existingIdentity = getEffectiveStaffIdentity(u);
    let initialRoles: UserRole[] = [];

    if (u.staffIdentity?.roles && u.staffIdentity.roles.length > 0) {
      initialRoles = [...(u.staffIdentity.roles as UserRole[])];
    } else if (u.staffIdentity?.role) {
      initialRoles = [u.staffIdentity.role as UserRole];
    } else if (u.role !== 'user' && STAFF_IDENTITY_CONFIG[u.role]) {
      initialRoles = [u.role as UserRole];
    } else {
      initialRoles = ['manager'];
    }

    const primaryRole = initialRoles[0] || 'manager';
    const primaryCfg = STAFF_IDENTITY_CONFIG[primaryRole] || STAFF_IDENTITY_CONFIG['official_staff'];
    const titles = initialRoles.map(r => (STAFF_IDENTITY_CONFIG[r]?.name || r));

    setAssignFormData({
      roles: initialRoles,
      title: existingIdentity?.title || titles.join(' • '),
      staffId: existingIdentity?.staffId || `${primaryCfg.defaultStaffIdPrefix}${u.uid || u.id}`,
      staffLevel: existingIdentity?.staffLevel || (primaryRole === 'ceo' ? 10 : primaryRole === 'gm' ? 8 : primaryRole === 'super_admin' ? 7 : 5),
      isVerified: existingIdentity?.isVerified !== undefined ? existingIdentity.isVerified : true,
      department: existingIdentity?.department || primaryCfg.department,
      activeStatus: existingIdentity?.activeStatus || 'Active',
      notes: ''
    });
    setPositionSearchQuery('');
    setAssignModalUser(u);
  };

  const handleTogglePosition = (posId: UserRole) => {
    setAssignFormData(prev => {
      const exists = prev.roles.includes(posId);
      let updatedRoles: UserRole[];
      if (exists) {
        if (prev.roles.length === 1) {
          showNotification('⚠️ At least one position must remain selected.');
          return prev;
        }
        updatedRoles = prev.roles.filter(r => r !== posId);
      } else {
        updatedRoles = [...prev.roles, posId];
      }

      const primaryRole = updatedRoles[0] || 'official_staff';
      const primaryCfg = STAFF_IDENTITY_CONFIG[primaryRole] || STAFF_IDENTITY_CONFIG['official_staff'];
      const titles = updatedRoles.map(r => (STAFF_IDENTITY_CONFIG[r]?.name || r));

      return {
        ...prev,
        roles: updatedRoles,
        title: titles.join(' • '),
        department: prev.department || primaryCfg.department,
        staffId: prev.staffId || `${primaryCfg.defaultStaffIdPrefix}${assignModalUser?.uid || assignModalUser?.id || '000'}`
      };
    });
  };

  const handleSelectAllPositions = () => {
    const allRoles = AVAILABLE_STAFF_POSITIONS.map(p => p.id);
    const titles = allRoles.map(r => (STAFF_IDENTITY_CONFIG[r]?.name || r));
    setAssignFormData(prev => ({
      ...prev,
      roles: allRoles,
      title: titles.join(' • ')
    }));
  };

  const handleClearNonPrimaryPositions = () => {
    if (assignFormData.roles.length <= 1) return;
    const primary = assignFormData.roles[0];
    const cfg = STAFF_IDENTITY_CONFIG[primary] || STAFF_IDENTITY_CONFIG['official_staff'];
    setAssignFormData(prev => ({
      ...prev,
      roles: [primary],
      title: cfg.name || cfg.title
    }));
  };

  const handleAssignSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!assignModalUser) return;
    if (!canAssign) {
      showNotification('⛔ PERMISSION DENIED: Only the CEO (or authorized General Manager / Manager) can assign staff identities.');
      return;
    }
    if (assignFormData.roles.length === 0) {
      showNotification('⚠️ Please select at least one identity role/position.');
      return;
    }
    try {
      const updated = await ApiClient.assignStaffIdentity(assignModalUser.id, {
        roles: assignFormData.roles,
        role: assignFormData.roles[0],
        title: assignFormData.title,
        staffId: assignFormData.staffId,
        staffLevel: assignFormData.staffLevel,
        isVerified: assignFormData.isVerified,
        department: assignFormData.department,
        activeStatus: assignFormData.activeStatus,
        notes: assignFormData.notes
      });
      showNotification(`✅ Successfully assigned ${assignFormData.roles.length} positions [${assignFormData.title}] to ${updated.name}`);
      setAssignModalUser(null);
      onRefresh();
    } catch (err: any) {
      showNotification(err.message || 'Failed to assign staff identity');
    }
  };

  const handleRemoveIdentity = async (userToRemove: User) => {
    if (!canAssign) {
      showNotification('⛔ PERMISSION DENIED: Only the CEO (or authorized GM / Manager) can remove staff identities.');
      return;
    }
    if (!window.confirm(`Are you sure you want to revoke staff identity from ${userToRemove.name}?`)) return;
    try {
      const updated = await ApiClient.removeStaffIdentity(userToRemove.id, 'Revoked by administrator');
      showNotification(`✅ Revoked staff identity from ${updated.name}`);
      onRefresh();
    } catch (err: any) {
      showNotification(err.message || 'Failed to remove staff identity');
    }
  };

  const handleToggleGrantPermission = async (targetUser: User) => {
    if (!isCeo) {
      showNotification('⛔ PERMISSION DENIED: Only the CEO can grant identity assignment permissions.');
      return;
    }
    const nextVal = !targetUser.canAssignIdentity;
    try {
      await ApiClient.grantIdentityPermission(targetUser.id, nextVal);
      showNotification(`✅ ${nextVal ? 'Granted' : 'Revoked'} identity assignment permission for ${targetUser.name}`);
      onRefresh();
    } catch (err: any) {
      showNotification(err.message || 'Failed to update permission');
    }
  };

  const staffIdentityUsers = users.filter(u => {
    const eff = getEffectiveStaffIdentity(u);
    if (!eff) return false;
    if (identityFilterRole !== 'all') {
      const userRoles = eff.roles && eff.roles.length > 0 ? eff.roles : [eff.role];
      if (!userRoles.includes(identityFilterRole as UserRole)) return false;
    }
    if (identitySearch.trim()) {
      const q = identitySearch.toLowerCase();
      const matchName = u.name.toLowerCase().includes(q);
      const matchUid = (u.uid || '').toLowerCase().includes(q);
      const matchStaffId = (eff.staffId || '').toLowerCase().includes(q);
      const matchTitle = (eff.title || '').toLowerCase().includes(q);
      const matchDept = (eff.department || '').toLowerCase().includes(q);
      const matchPositions = (eff.roles || []).some(r => r.toLowerCase().includes(q));
      return matchName || matchUid || matchStaffId || matchTitle || matchDept || matchPositions;
    }
    return true;
  });

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* HEADER BAR */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
        <div>
          <h3 className="text-base font-black text-white flex items-center gap-2">
            <Users className="w-5 h-5 text-amber-400" /> Staff & User Management Center
          </h3>
          <p className="text-xs text-slate-300">RBAC Permissions, User Auditing, UID Governance & Account Management</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleExportExcel}
            className="px-3 py-1.5 bg-emerald-600/80 hover:bg-emerald-500 text-white rounded-xl font-bold text-xs border border-emerald-400/40 flex items-center gap-1.5 transition-all shadow"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" /> Export Excel
          </button>
          <button
            onClick={handleExportPDF}
            className="px-3 py-1.5 bg-rose-600/80 hover:bg-rose-500 text-white rounded-xl font-bold text-xs border border-rose-400/40 flex items-center gap-1.5 transition-all shadow"
          >
            <FileText className="w-3.5 h-3.5" /> Export PDF
          </button>
        </div>
      </div>

      {/* SUB-TAB NAVIGATOR */}
      <div className="flex flex-wrap gap-2 border-b border-white/10 pb-2">
        {[
          { id: 'staff_identity', label: 'Staff Identity System', icon: <Sparkles className="w-3.5 h-3.5 text-amber-300" /> },
          { id: 'users', label: 'User Directory', icon: <Users className="w-3.5 h-3.5" /> },
          { id: 'staff', label: 'Staff Roster', icon: <UserCheck className="w-3.5 h-3.5" /> },
          { id: 'permissions', label: 'Permission Matrix & Roles', icon: <Shield className="w-3.5 h-3.5" /> },
          { id: 'activity', label: 'Staff Audit Log', icon: <Clock className="w-3.5 h-3.5" /> }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveSubTab(tab.id as any)}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeSubTab === tab.id
                ? 'bg-amber-400 text-black shadow-md font-black'
                : 'bg-white/5 text-slate-300 hover:bg-white/10 hover:text-white'
            }`}
          >
            {tab.icon} {tab.label}
          </button>
        ))}
      </div>

      {/* TAB 0: STAFF IDENTITY SYSTEM */}
      {activeSubTab === 'staff_identity' && (
        <div className="space-y-6">
          {/* CEO DELEGATION & SECURITY BANNER */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-purple-900/60 via-indigo-900/40 to-slate-900/60 border border-amber-400/30 backdrop-blur-md shadow-xl flex flex-wrap items-center justify-between gap-4">
            <div className="space-y-1 max-w-xl">
              <div className="flex items-center gap-2">
                <Crown className="w-5 h-5 text-amber-400 animate-bounce" />
                <h4 className="text-sm font-black text-white">Staff Identity & Governance Policy</h4>
                {isCeo && (
                  <span className="bg-amber-400 text-black text-[10px] font-black px-2 py-0.5 rounded-full shadow">
                    CEO FULL ACCESS
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                <strong className="text-amber-300">Security Requirement:</strong> Only the CEO can assign or remove staff identities. General Managers and Managers can assign identities only if explicitly granted permission by the CEO. Every modification creates a permanent Audit Log.
              </p>
            </div>

            {/* CEO DELEGATION CONTROLS */}
            {isCeo && (
              <div className="bg-black/50 p-3 rounded-2xl border border-white/10 space-y-2 text-xs">
                <p className="text-[11px] font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-amber-400" /> Delegate Assignment Permission
                </p>
                <div className="flex flex-wrap gap-2">
                  {users.filter(u => ['gm', 'manager'].includes(u.role)).map(officer => (
                    <button
                      key={officer.id}
                      onClick={() => handleToggleGrantPermission(officer)}
                      className={`px-3 py-1.5 rounded-xl font-bold text-[11px] border transition-all flex items-center gap-1.5 ${
                        officer.canAssignIdentity
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400/40 hover:bg-emerald-500/30'
                          : 'bg-white/5 text-slate-400 border-white/10 hover:bg-white/10 hover:text-white'
                      }`}
                    >
                      <span className={`w-2 h-2 rounded-full ${officer.canAssignIdentity ? 'bg-emerald-400' : 'bg-slate-500'}`} />
                      {officer.name} ({officer.role.toUpperCase()})
                      {officer.canAssignIdentity ? ' [Granted]' : ' [Locked]'}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* SEARCH & FILTERS FOR STAFF IDENTITY */}
          <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-2 flex-1 min-w-[280px]">
                <div className="flex items-center gap-2 bg-black/40 px-3 py-2 rounded-xl border border-white/10 flex-1 min-w-[200px]">
                  <Search className="w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Search by Name, UID, Staff ID, Title, Department..."
                    value={identitySearch}
                    onChange={(e) => setIdentitySearch(e.target.value)}
                    className="w-full bg-transparent text-white text-xs placeholder:text-slate-500 focus:outline-none"
                  />
                </div>

                <div className="flex items-center gap-2 bg-black/40 px-3 py-2 rounded-xl border border-white/10 text-xs">
                  <Filter className="w-3.5 h-3.5 text-amber-400" />
                  <span className="text-slate-400">Identity Role:</span>
                  <select
                    value={identityFilterRole}
                    onChange={(e) => setIdentityFilterRole(e.target.value)}
                    className="bg-transparent text-white font-bold focus:outline-none cursor-pointer"
                  >
                    <option value="all" className="bg-[#1a0b2e]">All 11 Identities</option>
                    <option value="ceo" className="bg-[#1a0b2e]">CEO</option>
                    <option value="gm" className="bg-[#1a0b2e]">General Manager</option>
                    <option value="manager" className="bg-[#1a0b2e]">Manager</option>
                    <option value="super_admin" className="bg-[#1a0b2e]">Super Admin</option>
                    <option value="admin" className="bg-[#1a0b2e]">Admin</option>
                    <option value="bd" className="bg-[#1a0b2e]">BD</option>
                    <option value="agency" className="bg-[#1a0b2e]">Agency</option>
                    <option value="host" className="bg-[#1a0b2e]">Host</option>
                    <option value="recharge_agent" className="bg-[#1a0b2e]">Recharge Agent</option>
                    <option value="coin_merchant" className="bg-[#1a0b2e]">Coin Merchant</option>
                    <option value="official_staff" className="bg-[#1a0b2e]">Official Staff</option>
                  </select>
                </div>
              </div>

              {/* QUICK ASSIGN NEW IDENTITY BUTTON */}
              <button
                onClick={() => {
                  const target = users.find(u => u.role === 'user') || users[0];
                  if (target) handleOpenAssignModal(target);
                }}
                disabled={!canAssign}
                className="px-4 py-2 bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-black font-black text-xs rounded-xl shadow-lg border border-amber-300/40 flex items-center gap-1.5 disabled:opacity-40 transition-all"
              >
                <UserPlus className="w-4 h-4" /> Assign Staff Identity
              </button>
            </div>
          </div>

          {/* STAFF IDENTITY ROSTER GRID */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {staffIdentityUsers.map(stf => {
              const effIdentity = getEffectiveStaffIdentity(stf);
              if (!effIdentity) return null;

              return (
                <div key={stf.id} className="relative overflow-hidden rounded-3xl p-5 bg-white/5 border border-white/10 hover:border-amber-400/40 transition-all space-y-4 group shadow-xl">
                  {/* Avatar & Name Header */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <img src={stf.avatar} alt={stf.name} className="w-12 h-12 rounded-2xl object-cover border-2 border-amber-400 shadow-md" />
                        <span className="absolute -bottom-1 -right-1 bg-emerald-500 w-3.5 h-3.5 rounded-full border-2 border-black" title="Online" />
                      </div>
                      <div>
                        <h5 className="font-extrabold text-white text-sm flex items-center gap-1.5">
                          {stf.name}
                        </h5>
                        <div className="mt-0.5">
                          <ProfileIdBadge uid={stf.uid} size="xs" showGroupTag={true} canCopy={true} />
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => setHistoryModalUser(stf)}
                      className="p-1.5 bg-white/5 hover:bg-white/15 text-slate-300 rounded-xl transition-all border border-white/10"
                      title="View Identity History"
                    >
                      <History className="w-4 h-4" />
                    </button>
                  </div>

                  {/* STAFF IDENTITY BADGE PREVIEW */}
                  <div className="bg-black/40 p-3 rounded-2xl border border-white/10 space-y-2">
                    <StaffIdentityBadgeCard identity={effIdentity} />
                  </div>

                  {/* DETAILS GRID */}
                  <div className="grid grid-cols-2 gap-2 text-[11px] bg-black/20 p-2.5 rounded-xl border border-white/5">
                    <div>
                      <span className="text-slate-400 block text-[10px]">Department:</span>
                      <strong className="text-slate-200">{effIdentity.department}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px]">Staff Level:</span>
                      <strong className="text-amber-300 font-mono">Level {effIdentity.staffLevel}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px]">Assigned By:</span>
                      <strong className="text-slate-300">{effIdentity.assignedBy}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px]">Joined Date:</span>
                      <strong className="text-slate-300 font-mono">{effIdentity.joinedDate}</strong>
                    </div>
                  </div>

                  {/* CARD ACTIONS */}
                  <div className="flex items-center gap-2 pt-1 border-t border-white/10">
                    <button
                      onClick={() => handleOpenAssignModal(stf)}
                      disabled={!canAssign}
                      className="flex-1 py-1.5 bg-amber-400/20 hover:bg-amber-400 text-amber-300 hover:text-black font-bold text-xs rounded-xl border border-amber-400/30 transition-all flex items-center justify-center gap-1.5 disabled:opacity-40"
                    >
                      <Edit2 className="w-3.5 h-3.5" /> Edit Identity
                    </button>
                    <button
                      onClick={() => handleRemoveIdentity(stf)}
                      disabled={!canAssign || stf.role === 'ceo'}
                      className="px-3 py-1.5 bg-rose-500/20 hover:bg-rose-500 text-rose-300 hover:text-white font-bold text-xs rounded-xl border border-rose-500/30 transition-all flex items-center justify-center gap-1 disabled:opacity-30"
                      title="Revoke Identity"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}

            {staffIdentityUsers.length === 0 && (
              <div className="col-span-full p-12 text-center rounded-3xl bg-white/5 border border-white/10 space-y-3">
                <Sparkles className="w-8 h-8 text-amber-400 mx-auto animate-spin" />
                <h4 className="text-sm font-bold text-white">No Staff Identities Match Filter Criteria</h4>
                <p className="text-xs text-slate-400 max-w-md mx-auto">Try selecting a different identity role or assign a new staff identity using the button above.</p>
              </div>
            )}
          </div>

          {/* AUDIT LOG PREVIEW FOR IDENTITY CHANGES */}
          <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3">
            <h4 className="text-xs font-black text-amber-300 uppercase tracking-wider flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-400" /> Staff Identity System Audit Trail
            </h4>
            <div className="space-y-2">
              {auditLogs.filter(l => ['STAFF_IDENTITY_ASSIGNED', 'STAFF_IDENTITY_REMOVED', 'STAFF_PERMISSION_CHANGED', 'STAFF_ROLE_ASSIGNED'].includes(l.action)).slice(0, 10).map(log => (
                <div key={log.id} className="p-3 rounded-xl bg-black/40 border border-white/10 flex items-center justify-between text-xs">
                  <div className="space-y-0.5">
                    <p className="font-bold text-white">
                      <span className="text-amber-300">{log.performedByUserName}</span> ({log.performedByRole.toUpperCase()}): {log.details}
                    </p>
                    <p className="text-[10px] text-slate-400">Target: {log.targetName || log.targetId || 'N/A'} • Action: {log.action}</p>
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono">{new Date(log.timestamp).toLocaleString()}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 1: USER DIRECTORY & SEARCH (FIRESTORE POWERED) */}
      {activeSubTab === 'users' && (
        <UsersStaffDirectory
          users={users}
          currentUser={currentUser}
          auditLogs={auditLogs}
          showNotification={showNotification}
          onRefreshParent={onRefresh}
          onOpenStaffAssign={handleOpenAssignModal}
        />
      )}

      {/* TAB 2: STAFF ROSTER */}
      {activeSubTab === 'staff' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
            <h4 className="text-xs font-black text-amber-300 uppercase">Staff Hierarchy & Management Officers</h4>
            <p className="text-[11px] text-slate-300">Staff members possess administrative permissions governed by RBAC policies.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {users.filter(u => ['ceo', 'gm', 'manager', 'super_admin', 'admin', 'bd'].includes(u.role)).map(staff => (
              <div key={staff.id} className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3 relative group">
                <div className="flex items-center gap-3">
                  <img src={staff.avatar} alt="Avatar" className="w-12 h-12 rounded-full object-cover border-2 border-amber-400" />
                  <div>
                    <h5 className="font-extrabold text-white text-sm flex items-center gap-1.5">
                      {staff.name} {staff.role === 'ceo' && <Crown className="w-4 h-4 text-amber-400" />}
                    </h5>
                    <p className="text-xs text-slate-400">{staff.email}</p>
                    <span className="inline-block mt-1 text-[10px] font-black uppercase px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      {staff.role}
                    </span>
                  </div>
                </div>
                <div className="p-2.5 rounded-xl bg-black/40 text-[11px] space-y-1">
                  <p className="text-slate-400">Assigned UID: <span className="text-amber-300 font-mono font-bold">{staff.uid}</span></p>
                  <p className="text-slate-400">Permissions: <span className="text-emerald-300 font-bold">{staff.role === 'ceo' ? 'ALL ACCESS (Full)' : 'Standard Admin'}</span></p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: PERMISSION SYSTEM & ROLES */}
      {activeSubTab === 'permissions' && (
        <div className="space-y-4">
          {/* TOP CONTROLS & EDIT PERMISSIONS BUTTON */}
          <div className="p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md flex flex-wrap items-center justify-between gap-4">
            <div>
              <h4 className="font-black text-white text-sm flex items-center gap-2">
                <Shield className="w-4 h-4 text-amber-400" /> Dynamic Role-Based Access Control (RBAC) Matrix
              </h4>
              <p className="text-xs text-slate-300">
                Operational authority and administrative scopes synchronized with live Firestore database.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-xl bg-amber-500/20 text-amber-300 text-xs font-black border border-amber-500/30 flex items-center gap-1.5">
                <Crown className="w-3.5 h-3.5 text-amber-400" /> Rule: Only CEO can grant Edit User ID permission
              </span>

              <button
                id="btn-edit-permissions"
                onClick={() => setIsEditPermissionsOpen(prev => !prev)}
                className="px-4 py-2 bg-gradient-to-r from-amber-400 to-amber-500 hover:brightness-110 text-black font-black text-xs rounded-xl shadow-lg transition-all flex items-center gap-2 active:scale-95"
              >
                <Edit2 className="w-3.5 h-3.5" />
                {isEditPermissionsOpen ? 'View Static Matrix' : 'Edit Permissions'}
              </button>
            </div>
          </div>

          {/* DYNAMIC PERMISSION EDITOR PANEL */}
          {isEditPermissionsOpen ? (
            <div className="p-1 rounded-2xl bg-black/40 border border-amber-400/30 shadow-2xl">
              <DynamicPermissionManager
                currentUser={currentUser}
                users={users}
                onClose={() => setIsEditPermissionsOpen(false)}
                showNotification={showNotification}
                onRefreshParent={onRefresh}
              />
            </div>
          ) : (
            <div className="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400">
                  Click <strong>"Edit Permissions"</strong> above to dynamically adjust roles or grant staff-specific overrides in real time.
                </span>
                <button
                  onClick={() => setIsEditPermissionsOpen(true)}
                  className="text-xs text-amber-300 hover:text-amber-200 font-bold flex items-center gap-1 transition-colors"
                >
                  Launch Full RBAC Editor →
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-black/40 text-slate-300 font-bold border-b border-white/10">
                    <tr>
                      <th className="p-3">Role Hierarchy</th>
                      <th className="p-3">Level</th>
                      <th className="p-3">Edit User ID Permission</th>
                      <th className="p-3">Financial Approval</th>
                      <th className="p-3">Room Moderation</th>
                      <th className="p-3">Role Grant Authority</th>
                      <th className="p-3 text-right">Quick Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5 text-slate-200">
                    {[
                      { role: 'CEO', level: 100, roleId: 'ceo', editUid: 'YES (Exclusive Grant)', finance: 'FULL', room: 'FULL', roleGrant: 'ALL ROLES' },
                      { role: 'General Manager (GM)', level: 90, roleId: 'gm', editUid: 'NO (Requires CEO Approval)', finance: 'APPROVAL', room: 'FULL', roleGrant: 'Manager & Below' },
                      { role: 'Manager', level: 80, roleId: 'manager', editUid: 'NO', finance: 'LIMITED', room: 'FULL', roleGrant: 'Admin & Below' },
                      { role: 'Super Admin', level: 70, roleId: 'super_admin', editUid: 'NO', finance: 'NO', room: 'FULL', roleGrant: 'Admin' },
                      { role: 'Admin', level: 60, roleId: 'admin', editUid: 'NO', finance: 'NO', room: 'FULL', roleGrant: 'None' },
                      { role: 'BD (Business Dev)', level: 50, roleId: 'bd', editUid: 'NO', finance: 'NO', room: 'VIEW', roleGrant: 'Agency' },
                      { role: 'Agency', level: 40, roleId: 'agency', editUid: 'NO', finance: 'HOST PAYOUTS', room: 'AGENCY ROOMS', roleGrant: 'Host' },
                      { role: 'Host', level: 30, roleId: 'host', editUid: 'NO', finance: 'NO', room: 'OWN ROOM', roleGrant: 'None' }
                    ].map((item, idx) => (
                      <tr key={idx} className="hover:bg-white/5 transition-colors">
                        <td className="p-3 font-black text-amber-300 flex items-center gap-1.5">
                          {item.roleId === 'ceo' && <Crown className="w-3.5 h-3.5 text-amber-400" />}
                          {item.role}
                        </td>
                        <td className="p-3 font-mono">{item.level}</td>
                        <td className="p-3">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            item.role === 'CEO' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'text-slate-400 bg-white/5'
                          }`}>
                            {item.editUid}
                          </span>
                        </td>
                        <td className="p-3">{item.finance}</td>
                        <td className="p-3">{item.room}</td>
                        <td className="p-3 text-slate-400">{item.roleGrant}</td>
                        <td className="p-3 text-right">
                          <button
                            onClick={() => setIsEditPermissionsOpen(true)}
                            className="px-2.5 py-1 bg-amber-400/10 hover:bg-amber-400 text-amber-300 hover:text-black font-bold text-[10px] rounded-lg border border-amber-400/30 transition-all inline-flex items-center gap-1"
                          >
                            <Edit2 className="w-2.5 h-2.5" /> Configure
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 4: STAFF ACTIVITY LOG */}
      {activeSubTab === 'activity' && (
        <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3">
          <h4 className="text-xs font-black text-amber-300 uppercase">Recent Staff System Operations</h4>
          <div className="space-y-2">
            {auditLogs.slice(0, 15).map(log => (
              <div key={log.id} className="p-3 rounded-xl bg-black/40 border border-white/10 flex items-center justify-between text-xs">
                <div className="space-y-0.5">
                  <p className="font-bold text-white">
                    <span className="text-amber-300">{log.performedByUserName}</span> ({log.performedByRole.toUpperCase()}): {log.details}
                  </p>
                  <p className="text-[10px] text-slate-400">Target: {log.targetName || log.targetId || 'N/A'} • IP: {log.ipAddress}</p>
                </div>
                <span className="text-[10px] text-slate-400 font-mono">{new Date(log.timestamp).toLocaleString()}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* COMPREHENSIVE USER PROFILE DRAWER / MODAL */}
      {selectedUser && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#1a0b2e]/95 border border-amber-400/40 rounded-3xl p-6 w-full max-w-2xl space-y-5 shadow-2xl my-8">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-3">
                <img src={selectedUser.avatar} alt="Avatar" className="w-12 h-12 rounded-full object-cover border-2 border-amber-400" />
                <div>
                  <h3 className="font-black text-white text-base flex items-center gap-2">
                    {selectedUser.name} <span className="text-xs text-amber-300">({selectedUser.countryFlag})</span>
                  </h3>
                  <p className="text-xs text-slate-400">User ID / UID: <span className="font-mono text-amber-300 font-bold">{selectedUser.uid || selectedUser.id}</span></p>
                </div>
              </div>
              <button onClick={() => setSelectedUser(null)} className="text-slate-400 hover:text-white font-bold text-lg p-1">✕</button>
            </div>

            {/* Drawer Sub-Tabs */}
            <div className="flex flex-wrap gap-1.5 border-b border-white/10 pb-2 text-[11px]">
              {[
                { id: 'profile', label: 'Profile' },
                { id: 'uid', label: 'Edit UID (CEO)' },
                { id: 'profile_history', label: 'Profile History' },
                { id: 'uid_history', label: 'UID History' },
                { id: 'login', label: 'Login History' },
                { id: 'device', label: 'Device History' },
                { id: 'wallet', label: 'Wallet History' },
                { id: 'recharge', label: 'Recharge History' },
                { id: 'withdraw', label: 'Withdraw History' },
                { id: 'gift', label: 'Gift History' },
                { id: 'referral', label: 'Referral History' }
              ].map(t => (
                <button
                  key={t.id}
                  onClick={() => setDrawerTab(t.id as any)}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                    drawerTab === t.id ? 'bg-amber-400 text-black font-black' : 'bg-white/5 text-slate-300 hover:bg-white/10'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>

            {/* TAB CONTENT: PROFILE */}
            {drawerTab === 'profile' && (
              <div className="space-y-3">
                {/* Staff Identity Card inside Drawer */}
                {getEffectiveStaffIdentity(selectedUser) && (
                  <div className="bg-black/50 p-3 rounded-2xl border border-white/10 space-y-2">
                    <p className="text-[10px] font-bold text-amber-300 uppercase tracking-wider">Active Staff Identity</p>
                    <StaffIdentityBadgeCard identity={getEffectiveStaffIdentity(selectedUser)!} />
                  </div>
                )}

                <div className="grid grid-cols-2 gap-3 text-xs bg-black/40 p-4 rounded-2xl border border-white/10">
                  <div><span className="text-slate-400">Email:</span> <p className="font-bold text-white">{selectedUser.email}</p></div>
                  <div><span className="text-slate-400">Role:</span> <p className="font-bold text-amber-300 uppercase">{selectedUser.role}</p></div>
                  <div><span className="text-slate-400">Account Status:</span> 
                    <p className={`font-black uppercase ${selectedUser.status === 'banned' ? 'text-rose-400' : 'text-emerald-400'}`}>
                      {selectedUser.status === 'banned' ? `⛔ BANNED (${selectedUser.banType || 'PERM'})` : '● ACTIVE'}
                    </p>
                  </div>
                  <div><span className="text-slate-400">VIP Tier:</span> <p className="font-bold text-cyan-300 uppercase">{selectedUser.vipLevel}</p></div>
                  <div><span className="text-slate-400">Sending ID Level (Wealth):</span> <p className="font-bold text-amber-300 font-mono">📤 Lv. {selectedUser.sendingLevel || selectedUser.level || 1}</p></div>
                  <div><span className="text-slate-400">Receiving ID Level (Charm):</span> <p className="font-bold text-cyan-300 font-mono">📥 Lv. {selectedUser.receivingLevel || Math.max(1, Math.floor((selectedUser.level || 1) * 0.85))}</p></div>
                  <div><span className="text-slate-400">Coins Balance:</span> <p className="font-bold text-amber-300 font-mono">🪙 {selectedUser.coins?.toLocaleString()}</p></div>
                  <div><span className="text-slate-400">Diamonds Balance:</span> <p className="font-bold text-cyan-300 font-mono">💎 {selectedUser.diamonds?.toLocaleString()}</p></div>
                  <div><span className="text-slate-400">Country:</span> <p className="font-bold text-white">{selectedUser.country}</p></div>
                  <div><span className="text-slate-400">Registered:</span> <p className="font-bold text-slate-300">{new Date(selectedUser.createdAt).toLocaleDateString()}</p></div>
                  <div className="col-span-2"><span className="text-slate-400">Bio:</span> <p className="text-slate-200 mt-0.5">{selectedUser.bio || 'No bio provided'}</p></div>
                </div>

                {selectedUser.status === 'banned' && (
                  <div className="p-3.5 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-xs space-y-1.5">
                    <div className="flex items-center justify-between text-rose-400 font-black">
                      <span className="flex items-center gap-1.5">
                        <Ban className="w-4 h-4" /> Active Ban Restriction
                      </span>
                      <span className="text-[10px] uppercase bg-rose-500/20 px-2 py-0.5 rounded border border-rose-500/30">
                        {selectedUser.banType}
                      </span>
                    </div>
                    <p className="text-slate-200 font-medium">Reason: {selectedUser.banReason || 'Policy Violation'}</p>
                    {selectedUser.banExpiresAt && (
                      <p className="text-slate-400 font-mono text-[11px]">Expires: {new Date(selectedUser.banExpiresAt).toLocaleString()}</p>
                    )}
                    {selectedUser.bannedByName && (
                      <p className="text-amber-300 text-[11px]">Enforced By: {selectedUser.bannedByName} ({selectedUser.bannedByRole})</p>
                    )}
                    <button
                      onClick={async () => {
                        try {
                          await ApiClient.unbanUser(selectedUser.id, { reason: 'Unbanned via User Directory drawer' });
                          showNotification(`✅ Successfully unbanned ${selectedUser.name}`);
                          setSelectedUser(null);
                          onRefresh();
                        } catch (e: any) {
                          showNotification(`❌ ${e.message || 'Failed to unban user'}`);
                        }
                      }}
                      className="w-full mt-2 py-2 bg-emerald-500 hover:bg-emerald-400 text-black font-black rounded-xl transition-all shadow"
                    >
                      Unban Account
                    </button>
                  </div>
                )}

                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      const u = selectedUser;
                      setSelectedUser(null);
                      handleOpenAssignModal(u);
                    }}
                    disabled={!canAssign}
                    className="w-full py-2 bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-black font-black text-xs rounded-xl shadow border border-amber-300/40 flex items-center justify-center gap-1.5 disabled:opacity-40 transition-all"
                  >
                    <Sparkles className="w-4 h-4" /> Manage Staff Identity for {selectedUser.name}
                  </button>
                </div>
              </div>
            )}

            {/* TAB CONTENT: EDIT UID (CEO ONLY) */}
            {drawerTab === 'uid' && (
              <div className="space-y-3 bg-black/40 p-4 rounded-2xl border border-white/10 text-xs">
                <div className="flex items-center gap-2 p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300">
                  <Shield className="w-4 h-4 shrink-0" />
                  <span>Rule: Only CEO has permission to edit custom User IDs (UID).</span>
                </div>
                <div>
                  <label className="block text-slate-300 font-bold mb-1">New Custom UID</label>
                  <input
                    type="text"
                    value={newUidInput}
                    onChange={(e) => setNewUidInput(e.target.value)}
                    placeholder="e.g. 7777777"
                    disabled={!isCeo}
                    className="w-full bg-black/60 text-white font-mono font-bold px-3 py-2 rounded-xl border border-white/20 focus:outline-none focus:border-amber-400 disabled:opacity-40"
                  />
                </div>
                <button
                  onClick={handleUpdateUid}
                  disabled={!isCeo || isUpdatingUid}
                  className="w-full py-2.5 bg-gradient-to-r from-amber-400 to-amber-500 text-black font-black rounded-xl shadow hover:from-amber-300 hover:to-amber-400 disabled:opacity-40 flex items-center justify-center gap-2"
                >
                  {isUpdatingUid ? 'Updating UID...' : 'Confirm UID Update'}
                </button>
              </div>
            )}

            {/* TAB CONTENT: HISTORIES */}
            {['profile_history', 'uid_history', 'login', 'device', 'wallet', 'recharge', 'withdraw', 'gift', 'referral'].includes(drawerTab) && (
              <div className="p-4 bg-black/40 rounded-2xl border border-white/10 text-xs space-y-2">
                <p className="text-slate-400 font-bold uppercase tracking-wider text-[10px]">
                  {drawerTab.replace('_', ' ').toUpperCase()} LOGS
                </p>
                <div className="space-y-1.5 font-mono text-[11px]">
                  <div className="p-2 rounded-lg bg-white/5 border border-white/5 flex justify-between">
                    <span className="text-slate-300">RECORD #1 — System Initial Event</span>
                    <span className="text-amber-300">{new Date(selectedUser.createdAt).toLocaleDateString()}</span>
                  </div>
                  <div className="p-2 rounded-lg bg-white/5 border border-white/5 flex justify-between">
                    <span className="text-slate-300">RECORD #2 — Activity Audit Verified</span>
                    <span className="text-emerald-300">STATUS: VERIFIED</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* EDIT USER ACCOUNT MODAL */}
      {editModalUser && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <form onSubmit={handleSaveAccount} className="bg-[#1a0b2e] border border-amber-400/40 rounded-3xl p-6 w-full max-w-lg space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="font-black text-white text-base">Edit User Account Settings</h3>
              <button type="button" onClick={() => setEditModalUser(null)} className="text-slate-400 hover:text-white font-bold">✕</button>
            </div>
            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">Full Name</label>
                <input
                  type="text"
                  value={editFormData.name || ''}
                  onChange={(e) => setEditFormData({ ...editFormData, name: e.target.value })}
                  placeholder="User Name"
                  className="w-full bg-black/40 text-white px-3.5 py-2.5 rounded-xl border border-white/10 font-bold focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1 flex items-center justify-between">
                  <span>User UID</span>
                  {!isCeoOrGm && <span className="text-[10px] text-amber-400 font-normal">🔒 CEO / GM Privilege Only</span>}
                </label>
                <input
                  type="text"
                  disabled={!isCeoOrGm}
                  value={editFormData.uid || ''}
                  onChange={(e) => setEditFormData({ ...editFormData, uid: e.target.value })}
                  placeholder="e.g. 8888888"
                  className="w-full bg-black/40 text-amber-300 px-3.5 py-2.5 rounded-xl border border-white/10 font-mono font-bold focus:outline-none focus:border-amber-400 disabled:opacity-50 disabled:cursor-not-allowed"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Gender</label>
                  <select
                    value={editFormData.gender || 'male'}
                    onChange={(e) => setEditFormData({ ...editFormData, gender: e.target.value as any })}
                    className="w-full bg-black/40 text-white px-3.5 py-2.5 rounded-xl border border-white/10 font-bold focus:outline-none focus:border-amber-400 cursor-pointer"
                  >
                    <option value="male" className="bg-[#1a0b2e]">Male</option>
                    <option value="female" className="bg-[#1a0b2e]">Female</option>
                    <option value="other" className="bg-[#1a0b2e]">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">Phone Number</label>
                  <input
                    type="text"
                    value={editFormData.phone || ''}
                    onChange={(e) => setEditFormData({ ...editFormData, phone: e.target.value })}
                    placeholder="+1 555-0199"
                    className="w-full bg-black/40 text-white px-3.5 py-2.5 rounded-xl border border-white/10 font-mono font-bold focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Gmail / Email Address</label>
                <input
                  type="email"
                  value={editFormData.email || ''}
                  onChange={(e) => setEditFormData({ ...editFormData, email: e.target.value })}
                  placeholder="user@gmail.com"
                  className="w-full bg-black/40 text-white px-3.5 py-2.5 rounded-xl border border-white/10 font-bold focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Coins Balance 🪙</label>
                  <input
                    type="number"
                    value={editFormData.coins ?? 0}
                    onChange={(e) => setEditFormData({ ...editFormData, coins: Number(e.target.value) })}
                    className="w-full bg-black/40 text-amber-300 px-3.5 py-2.5 rounded-xl border border-white/10 font-mono font-bold focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">Diamonds Balance 💎</label>
                  <input
                    type="number"
                    value={editFormData.diamonds ?? 0}
                    onChange={(e) => setEditFormData({ ...editFormData, diamonds: Number(e.target.value) })}
                    className="w-full bg-black/40 text-cyan-300 px-3.5 py-2.5 rounded-xl border border-white/10 font-mono font-bold focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              {/* DUAL LEVEL ID CONTROLS */}
              <div className="grid grid-cols-2 gap-3 p-3 bg-amber-500/5 rounded-2xl border border-amber-400/20">
                <div>
                  <label className="block text-amber-300 font-bold mb-1 flex items-center gap-1">
                    <span>📤 Sending ID Level</span>
                    <span className="text-[10px] text-amber-400 font-normal">(Wealth)</span>
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={200}
                    value={editFormData.sendingLevel ?? editFormData.level ?? 1}
                    onChange={(e) => setEditFormData({ ...editFormData, sendingLevel: Number(e.target.value) })}
                    className="w-full bg-black/50 text-amber-300 px-3.5 py-2.5 rounded-xl border border-amber-400/30 font-mono font-bold focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-cyan-300 font-bold mb-1 flex items-center gap-1">
                    <span>📥 Receiving ID Level</span>
                    <span className="text-[10px] text-cyan-400 font-normal">(Charm)</span>
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={200}
                    value={editFormData.receivingLevel ?? Math.max(1, Math.floor((editFormData.level || 1) * 0.85))}
                    onChange={(e) => setEditFormData({ ...editFormData, receivingLevel: Number(e.target.value) })}
                    className="w-full bg-black/50 text-cyan-300 px-3.5 py-2.5 rounded-xl border border-cyan-400/30 font-mono font-bold focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>
            </div>
            <div className="flex gap-2 pt-2">
              <button type="button" onClick={() => setEditModalUser(null)} className="flex-1 py-2.5 bg-white/10 text-white hover:bg-white/20 rounded-xl font-bold text-xs transition-all">Cancel</button>
              <button type="submit" className="flex-1 py-2.5 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black font-black text-xs rounded-xl shadow-lg transition-all">Save Changes</button>
            </div>
          </form>
        </div>
      )}

      {/* ASSIGN STAFF IDENTITY MODAL (MULTI-SELECT SUPPORTED) */}
      {assignModalUser && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#1a0b2e]/95 border border-amber-400/40 rounded-3xl p-6 w-full max-w-2xl space-y-5 shadow-2xl my-8">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-3">
                <img src={assignModalUser.avatar} alt="Avatar" className="w-12 h-12 rounded-2xl object-cover border-2 border-amber-400 shadow-md" />
                <div>
                  <h3 className="font-black text-white text-base flex items-center gap-2">
                    <span>Assign Staff Identity Positions</span>
                    <span className="bg-amber-400/20 text-amber-300 text-[10px] font-bold px-2 py-0.5 rounded-full border border-amber-400/30">
                      Multi-Position Enabled
                    </span>
                  </h3>
                  <p className="text-xs text-slate-300">{assignModalUser.name} • UID: <span className="font-mono text-amber-300 font-bold">{assignModalUser.uid}</span></p>
                </div>
              </div>
              <button onClick={() => setAssignModalUser(null)} className="text-slate-400 hover:text-white font-bold text-lg p-1 rounded-xl hover:bg-white/10 transition-all">✕</button>
            </div>

            <form onSubmit={handleAssignSubmit} className="space-y-4 text-xs">
              {/* MULTI-SELECT POSITION PICKER */}
              <div className="space-y-2.5 p-3.5 rounded-2xl bg-black/40 border border-white/10">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <label className="text-slate-200 font-black flex items-center gap-1.5 uppercase tracking-wider text-[11px]">
                      <Tag className="w-3.5 h-3.5 text-amber-400" /> Select Identity Roles / Positions
                    </label>
                    <span className="bg-gradient-to-r from-amber-400 to-yellow-500 text-black font-black text-[10px] px-2 py-0.5 rounded-full shadow">
                      {assignFormData.roles.length} Selected
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5 text-[10px]">
                    <button
                      type="button"
                      onClick={handleSelectAllPositions}
                      className="px-2 py-0.5 bg-white/10 hover:bg-white/20 text-slate-200 font-bold rounded-lg transition-all"
                    >
                      Select All (12)
                    </button>
                    <button
                      type="button"
                      onClick={handleClearNonPrimaryPositions}
                      className="px-2 py-0.5 bg-white/10 hover:bg-white/20 text-slate-300 font-bold rounded-lg transition-all"
                      disabled={assignFormData.roles.length <= 1}
                    >
                      Keep Primary Only
                    </button>
                  </div>
                </div>

                {/* ACTIVE SELECTED PILLS / CHIPS */}
                <div className="flex flex-wrap items-center gap-1.5 min-h-[32px] p-2 bg-black/50 rounded-xl border border-white/5">
                  {assignFormData.roles.map(r => {
                    const cfg = STAFF_IDENTITY_CONFIG[r] || STAFF_IDENTITY_CONFIG['official_staff'];
                    return (
                      <span
                        key={r}
                        className={`inline-flex items-center gap-1.5 pl-2.5 pr-1.5 py-1 rounded-xl text-[11px] font-black shadow-md border ${cfg?.badgeStyle || 'bg-white/20 text-white'}`}
                      >
                        <span>{cfg?.badgeIcon || '🌟'}</span>
                        <span>{cfg?.name || r}</span>
                        <button
                          type="button"
                          onClick={() => handleTogglePosition(r)}
                          className="w-4 h-4 rounded-full bg-black/40 hover:bg-black/80 text-white flex items-center justify-center text-[10px] transition-all ml-0.5"
                          title={`Remove ${cfg?.name || r}`}
                        >
                          ✕
                        </button>
                      </span>
                    );
                  })}
                  {assignFormData.roles.length === 0 && (
                    <span className="text-rose-400 text-xs italic">⚠️ Please select at least one role/position below.</span>
                  )}
                </div>

                {/* SEARCH INPUT FOR FILTERING ROLES */}
                <div className="flex items-center gap-2 bg-black/60 px-3 py-1.5 rounded-xl border border-white/10">
                  <Search className="w-3.5 h-3.5 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Search roles (e.g., Manager, Seller, BD, Super Admin)..."
                    value={positionSearchQuery}
                    onChange={(e) => setPositionSearchQuery(e.target.value)}
                    className="w-full bg-transparent text-white text-xs placeholder:text-slate-500 focus:outline-none"
                  />
                  {positionSearchQuery && (
                    <button
                      type="button"
                      onClick={() => setPositionSearchQuery('')}
                      className="text-slate-400 hover:text-white text-xs font-bold"
                    >
                      Clear
                    </button>
                  )}
                </div>

                {/* POSITIONS GRID WITH CHECKBOXES */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-1">
                  {AVAILABLE_STAFF_POSITIONS.filter(p => {
                    if (!positionSearchQuery.trim()) return true;
                    const q = positionSearchQuery.toLowerCase();
                    return p.label.toLowerCase().includes(q) || p.department.toLowerCase().includes(q) || p.description.toLowerCase().includes(q);
                  }).map(pos => {
                    const isSelected = assignFormData.roles.includes(pos.id);
                    const cfg = STAFF_IDENTITY_CONFIG[pos.id];
                    return (
                      <div
                        key={pos.id}
                        onClick={() => handleTogglePosition(pos.id)}
                        className={`p-2.5 rounded-xl border cursor-pointer transition-all flex items-center justify-between gap-2 select-none ${
                          isSelected
                            ? 'bg-amber-400/15 border-amber-400/60 shadow-md text-white'
                            : 'bg-black/30 border-white/5 hover:bg-white/5 hover:border-white/20 text-slate-300'
                        }`}
                      >
                        <div className="flex items-center gap-2 min-w-0">
                          <div className={`w-4 h-4 rounded flex items-center justify-center text-xs transition-all ${
                            isSelected ? 'bg-amber-400 text-black font-black' : 'border border-slate-500 bg-black/40'
                          }`}>
                            {isSelected ? '✓' : ''}
                          </div>
                          <span className="text-base">{pos.icon}</span>
                          <div className="min-w-0">
                            <h5 className="font-black text-xs text-white leading-tight truncate">{pos.label}</h5>
                            <p className="text-[10px] text-slate-400 truncate">{pos.department}</p>
                          </div>
                        </div>

                        {isSelected && (
                          <span className="text-[9px] font-black bg-amber-400/20 text-amber-300 px-1.5 py-0.5 rounded border border-amber-400/40 shrink-0">
                            Active
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* TITLE & STAFF ID */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1 flex items-center justify-between">
                    <span>Staff Composite Title</span>
                    <span className="text-[10px] text-slate-400">(Editable)</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={assignFormData.title}
                    onChange={(e) => setAssignFormData({ ...assignFormData, title: e.target.value })}
                    className="w-full bg-black/40 text-white px-3 py-2 rounded-xl border border-white/10 focus:outline-none focus:border-amber-400 font-bold"
                    placeholder="e.g. Manager • Seller • BD"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">Staff ID</label>
                  <input
                    type="text"
                    required
                    value={assignFormData.staffId}
                    onChange={(e) => setAssignFormData({ ...assignFormData, staffId: e.target.value })}
                    className="w-full bg-black/40 text-amber-300 px-3 py-2 rounded-xl border border-white/10 focus:outline-none focus:border-amber-400 font-mono font-bold"
                  />
                </div>
              </div>

              {/* DEPARTMENT & LEVEL */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Primary Department</label>
                  <input
                    type="text"
                    value={assignFormData.department}
                    onChange={(e) => setAssignFormData({ ...assignFormData, department: e.target.value })}
                    className="w-full bg-black/40 text-white px-3 py-2 rounded-xl border border-white/10 focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">Staff Level</label>
                  <input
                    type="number"
                    min={1}
                    max={100}
                    value={assignFormData.staffLevel}
                    onChange={(e) => setAssignFormData({ ...assignFormData, staffLevel: Number(e.target.value) })}
                    className="w-full bg-black/40 text-white px-3 py-2 rounded-xl border border-white/10 focus:outline-none focus:border-amber-400 font-mono"
                  />
                </div>
              </div>

              {/* ACTIVE STATUS & VERIFICATION */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Active Status</label>
                  <select
                    value={assignFormData.activeStatus}
                    onChange={(e) => setAssignFormData({ ...assignFormData, activeStatus: e.target.value })}
                    className="w-full bg-black/40 text-white px-3 py-2 rounded-xl border border-white/10 focus:outline-none focus:border-amber-400 font-bold"
                  >
                    <option value="Active" className="bg-[#1a0b2e]">● Active</option>
                    <option value="On Shift" className="bg-[#1a0b2e]">● On Shift</option>
                    <option value="Offline" className="bg-[#1a0b2e]">○ Offline</option>
                    <option value="Suspended" className="bg-[#1a0b2e]">⛔ Suspended</option>
                  </select>
                </div>

                <div className="flex items-center pt-5">
                  <label className="flex items-center gap-2 cursor-pointer text-slate-200 font-bold">
                    <input
                      type="checkbox"
                      checked={assignFormData.isVerified}
                      onChange={(e) => setAssignFormData({ ...assignFormData, isVerified: e.target.checked })}
                      className="w-4 h-4 accent-amber-400 rounded"
                    />
                    Display Official Verification Badge (✓)
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Assignment Justification / Notes</label>
                <textarea
                  rows={2}
                  placeholder="Reason for granting/updating multiple positions..."
                  value={assignFormData.notes}
                  onChange={(e) => setAssignFormData({ ...assignFormData, notes: e.target.value })}
                  className="w-full bg-black/40 text-white p-3 rounded-xl border border-white/10 focus:outline-none focus:border-amber-400 text-xs"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button type="button" onClick={() => setAssignModalUser(null)} className="flex-1 py-2.5 bg-white/10 text-white hover:bg-white/20 rounded-xl font-bold text-xs transition-all">Cancel</button>
                <button type="submit" className="flex-1 py-2.5 bg-gradient-to-r from-amber-400 to-amber-500 text-black font-black text-xs rounded-xl shadow-lg hover:brightness-110 transition-all flex items-center justify-center gap-1.5">
                  <Sparkles className="w-4 h-4" /> Save Multi-Position Identity
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* IDENTITY HISTORY MODAL */}
      {historyModalUser && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#1a0b2e]/95 border border-amber-400/40 rounded-3xl p-6 w-full max-w-lg space-y-4 shadow-2xl my-8">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-3">
                <img src={historyModalUser.avatar} alt="Avatar" className="w-10 h-10 rounded-xl object-cover border border-amber-400" />
                <div>
                  <h3 className="font-black text-white text-sm">Identity Audit History</h3>
                  <p className="text-xs text-slate-400">{historyModalUser.name} • UID: <span className="font-mono text-amber-300 font-bold">{historyModalUser.uid}</span></p>
                </div>
              </div>
              <button onClick={() => setHistoryModalUser(null)} className="text-slate-400 hover:text-white font-bold text-lg">✕</button>
            </div>

            <div className="space-y-2 max-h-[350px] overflow-y-auto pr-1">
              {(historyModalUser.identityHistory || []).map(entry => (
                <div key={entry.id} className="p-3 rounded-xl bg-black/40 border border-white/10 space-y-1.5 text-xs">
                  <div className="flex items-center justify-between">
                    <span className={`font-black uppercase px-2 py-0.5 rounded text-[10px] ${
                      entry.action === 'assigned' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                    }`}>
                      {entry.action} • {entry.title}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">{new Date(entry.assignedAt).toLocaleString()}</span>
                  </div>
                  
                  {/* MULTI-IDENTITY TRANSITION RECORD */}
                  {entry.previousIdentities && entry.newIdentities && (
                    <div className="p-2 rounded-lg bg-white/5 border border-white/5 text-[11px] space-y-0.5">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-slate-400 text-[10px]">Previous:</span>
                        <span className="text-slate-300 font-mono font-bold">
                          {entry.previousIdentities.length > 0 ? entry.previousIdentities.join(', ') : 'None'}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-amber-400 text-[10px] font-bold">New:</span>
                        <span className="text-emerald-300 font-mono font-bold">
                          {entry.newIdentities.length > 0 ? entry.newIdentities.join(', ') : 'None'}
                        </span>
                      </div>
                    </div>
                  )}

                  <p className="text-slate-300">By: <strong className="text-amber-300">{entry.assignedBy}</strong></p>
                  {entry.notes && <p className="text-slate-400 text-[11px] italic">"{entry.notes}"</p>}
                </div>
              ))}

              {(!historyModalUser.identityHistory || historyModalUser.identityHistory.length === 0) && (
                <div className="p-6 text-center text-slate-400 text-xs">
                  No historical identity modifications recorded for this user.
                </div>
              )}
            </div>

            <button
              onClick={() => setHistoryModalUser(null)}
              className="w-full py-2 bg-white/10 hover:bg-white/20 text-white font-bold text-xs rounded-xl"
            >
              Close History
            </button>
          </div>
        </div>
      )}
      {/* DEDICATED EDIT USER UID MODAL (CEO / GM CONSOLE) */}
      {editUidModalUser && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#1a0b2e] border border-amber-400/40 rounded-3xl p-6 w-full max-w-md space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-amber-400" />
                <h3 className="font-black text-white text-base">Edit User UID (CEO / GM Console)</h3>
              </div>
              <button onClick={() => { setEditUidModalUser(null); setShowUidConfirmStep(false); }} className="text-slate-400 hover:text-white font-bold text-lg">✕</button>
            </div>

            <div className="p-3 bg-amber-500/10 rounded-xl border border-amber-500/30 text-xs text-amber-200">
              <strong>CEO & GM Governance Notice:</strong> Modifying a user's User UID preserves all account balances, coins, diamonds, VIP/SVIP tier, room permissions, gifts, and transaction records.
            </div>

            {!showUidConfirmStep ? (
              <div className="space-y-3 text-xs">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Target Account</label>
                  <div className="flex items-center justify-between gap-2.5 p-2.5 bg-black/40 rounded-xl border border-white/10">
                    <div className="flex items-center gap-2.5">
                      <img src={editUidModalUser.avatar} alt="Avatar" className="w-9 h-9 rounded-full object-cover border border-amber-400" />
                      <div>
                        <p className="font-bold text-white">{editUidModalUser.name}</p>
                        <p className="text-[10px] text-slate-400">{editUidModalUser.email}</p>
                      </div>
                    </div>
                    <ProfileIdBadge uid={editUidModalUser.uid} size="xs" showGroupTag={true} />
                  </div>
                </div>

                <div>
                  <label className="block text-slate-400 font-bold mb-1">Current User UID (Readonly)</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      disabled
                      value={editUidModalUser.uid}
                      className="w-full bg-black/60 text-slate-400 font-mono font-bold px-3 py-2 rounded-xl border border-white/10 cursor-not-allowed"
                    />
                    <ProfileIdBadge uid={editUidModalUser.uid} size="sm" showGroupTag={true} />
                  </div>
                </div>

                <div>
                  <label className="block text-amber-300 font-bold mb-1">New User UID</label>
                  <input
                    type="text"
                    value={newUidInput}
                    onChange={(e) => setNewUidInput(e.target.value)}
                    placeholder="e.g. 85, 250, 777"
                    className="w-full bg-black/60 text-amber-300 font-mono font-bold px-3 py-2.5 rounded-xl border border-amber-400/40 focus:outline-none focus:border-amber-400"
                  />
                  
                  {/* LIVE PROFILE ID COLOR SYSTEM PREVIEW */}
                  {newUidInput.trim() && (
                    <div className="mt-2 p-2.5 bg-black/50 rounded-xl border border-white/10 flex items-center justify-between">
                      <span className="text-[10px] font-bold text-slate-300">Live Dynamic Color Preview:</span>
                      <ProfileIdBadge uid={newUidInput.trim()} size="sm" showGroupTag={true} />
                    </div>
                  )}
                  <p className="text-[10px] text-slate-400 mt-1">1-20 alphanumeric characters, underscores, or hyphens. Must be unique.</p>
                </div>

                <div>
                  <label className="block text-amber-300 font-bold mb-1">Confirm New User UID</label>
                  <input
                    type="text"
                    value={confirmUidInput}
                    onChange={(e) => setConfirmUidInput(e.target.value)}
                    placeholder="Re-enter new UID"
                    className="w-full bg-black/60 text-amber-300 font-mono font-bold px-3 py-2.5 rounded-xl border border-amber-400/40 focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">Audit Reason / Notes (Optional)</label>
                  <input
                    type="text"
                    value={uidReasonInput}
                    onChange={(e) => setUidReasonInput(e.target.value)}
                    placeholder="e.g. VIP vanity UID assignment"
                    className="w-full bg-black/40 text-white font-mono text-xs px-3 py-2 rounded-xl border border-white/10 focus:outline-none focus:border-amber-400"
                  />
                </div>

                {/* PROFILE ID COLOR RANGE CHEATSHEET / LEGEND */}
                <div className="p-2.5 bg-black/30 rounded-xl border border-white/5 space-y-1.5">
                  <div className="flex items-center justify-between text-[10px]">
                    <span className="font-bold text-amber-300">Profile ID Color Rules:</span>
                    <span className="text-emerald-400 font-mono">Auto-applied on save</span>
                  </div>
                  <div className="grid grid-cols-2 gap-1 text-[9px]">
                    <div className="p-1 rounded bg-amber-500/10 border border-amber-400/30 text-amber-300 font-mono">
                      1–100: Supreme Gold 👑
                    </div>
                    <div className="p-1 rounded bg-emerald-500/10 border border-emerald-400/30 text-emerald-300 font-mono">
                      101–199: Emerald Jade 🌿
                    </div>
                    <div className="p-1 rounded bg-cyan-500/10 border border-cyan-400/30 text-cyan-300 font-mono">
                      200–300: Electric Cyan ⚡
                    </div>
                    <div className="p-1 rounded bg-purple-500/10 border border-purple-400/30 text-purple-300 font-mono">
                      301–399: Cosmic Orchid 🔮
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              /* CONFIRMATION PROMPT UI STEP (Requirement 7) */
              <div className="space-y-4 p-4 bg-amber-500/10 border border-amber-400/50 rounded-2xl text-xs">
                <div className="flex items-center gap-2 text-amber-300 font-black text-sm">
                  <Shield className="w-5 h-5 text-amber-400 animate-pulse" />
                  <span>Confirm User UID Change</span>
                </div>
                <p className="text-white font-semibold text-sm">
                  Are you sure you want to change this user's UID?
                </p>
                <div className="p-3 bg-black/60 rounded-xl border border-white/10 space-y-2 font-mono">
                  <p className="text-slate-400 text-xs">Target User: <strong className="text-white">{editUidModalUser.name}</strong></p>
                  
                  <div className="flex items-center justify-between gap-2 pt-1 border-t border-white/10">
                    <div className="space-y-1">
                      <span className="text-[10px] text-slate-400 block font-sans">Previous UID:</span>
                      <ProfileIdBadge uid={editUidModalUser.uid} size="sm" showGroupTag={true} />
                    </div>
                    <span className="text-amber-400 text-base font-bold">➔</span>
                    <div className="space-y-1 text-right">
                      <span className="text-[10px] text-emerald-400 block font-sans">New Dynamic UID:</span>
                      <ProfileIdBadge uid={newUidInput.trim()} size="sm" showGroupTag={true} />
                    </div>
                  </div>
                </div>
                <p className="text-[11px] text-slate-300">
                  This action will immediately update the user's display UID, transform their profile color range badge, and create an immutable record in the audit log.
                </p>
              </div>
            )}

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  if (showUidConfirmStep) {
                    setShowUidConfirmStep(false);
                  } else {
                    setEditUidModalUser(null);
                  }
                }}
                className="flex-1 py-2.5 bg-white/10 text-white hover:bg-white/20 rounded-xl font-bold text-xs transition-all"
              >
                {showUidConfirmStep ? 'Back / Edit' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={handleUpdateUid}
                disabled={isUpdatingUid}
                className="flex-1 py-2.5 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black font-black text-xs rounded-xl shadow-lg transition-all flex items-center justify-center gap-1.5 disabled:opacity-50"
              >
                <Shield className="w-3.5 h-3.5" />
                {isUpdatingUid ? 'Saving...' : showUidConfirmStep ? 'Confirm & Save UID' : 'Save / Update UID'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
