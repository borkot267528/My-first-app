import React, { useState, useEffect } from 'react';
import { 
  Crown, Sparkles, Shield, Search, Award, Clock, CheckCircle2, 
  AlertCircle, Trash2, RefreshCw, Filter, User, Send, ShieldAlert,
  ChevronRight, Calendar, UserCheck, Key, ShieldCheck, Heart
} from 'lucide-react';
import { User as UserType, BenefitAssignmentRecord } from '../../../types';
import { ApiClient } from '../../../lib/api';

interface VipManagementCenterProps {
  users: UserType[];
  currentUser: UserType | null;
  onRefresh: () => void;
  showNotification: (msg: string) => void;
}

const PROFILE_FRAMES = [
  { id: '👑 Golden Monarch', name: 'Golden Monarch', icon: '👑', color: 'from-amber-400 via-yellow-500 to-amber-600', border: 'border-amber-400 shadow-amber-500/50' },
  { id: '⚡ Cyber Pulse', name: 'Cyber Pulse', icon: '⚡', color: 'from-cyan-400 via-blue-500 to-purple-600', border: 'border-cyan-400 shadow-cyan-500/50' },
  { id: '🐉 Royal Dragon', name: 'Royal Dragon', icon: '🐉', color: 'from-red-500 via-orange-500 to-amber-500', border: 'border-red-500 shadow-red-500/50' },
  { id: '🌌 Nebula Cosmic', name: 'Nebula Cosmic', icon: '🌌', color: 'from-purple-500 via-pink-500 to-indigo-500', border: 'border-purple-400 shadow-purple-500/50' },
  { id: '🔥 Flame Legend', name: 'Flame Legend', icon: '🔥', color: 'from-amber-500 via-red-600 to-yellow-400', border: 'border-orange-500 shadow-orange-500/50' },
  { id: '💎 Diamond Sparkle', name: 'Diamond Sparkle', icon: '💎', color: 'from-sky-300 via-blue-400 to-emerald-300', border: 'border-sky-300 shadow-sky-400/50' },
  { id: '🦅 Phoenix Wings', name: 'Phoenix Wings', icon: '🦅', color: 'from-rose-500 via-amber-500 to-red-600', border: 'border-rose-400 shadow-rose-500/50' },
  { id: '👑 Imperial Crown', name: 'Imperial Crown', icon: '👑', color: 'from-yellow-300 via-amber-400 to-yellow-600', border: 'border-yellow-300 shadow-yellow-400/50' },
  { id: '✨ Starry Aura', name: 'Starry Aura', icon: '✨', color: 'from-emerald-400 via-teal-500 to-cyan-400', border: 'border-teal-400 shadow-teal-500/50' },
];

export const VipManagementCenter: React.FC<VipManagementCenterProps> = ({
  users,
  currentUser,
  onRefresh,
  showNotification
}) => {
  const [activeTab, setActiveTab] = useState<'vip' | 'svip' | 'frame'>('vip');
  
  // User Search
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTargetUser, setSelectedTargetUser] = useState<UserType | null>(null);

  // Configuration
  const [selectedLevel, setSelectedLevel] = useState<string>('VIP 1');
  const [selectedSvipLevel, setSelectedSvipLevel] = useState<string>('SVIP 1');
  const [selectedFrame, setSelectedFrame] = useState<string>('👑 Golden Monarch');
  const [durationDays, setDurationDays] = useState<number | 'permanent'>(30);
  const [assignmentMode, setAssignmentMode] = useState<'free_grant' | 'coin_deduction'>('free_grant');
  const [grantReason, setGrantReason] = useState<string>('');

  // Modals
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [showRevokeModal, setShowRevokeModal] = useState(false);
  const [actionType, setActionType] = useState<'assign' | 'revoke'>('assign');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // History & Filter
  const [historyList, setHistoryList] = useState<BenefitAssignmentRecord[]>([]);
  const [historyFilter, setHistoryFilter] = useState<'all' | 'vip' | 'svip' | 'frame' | 'active' | 'revoked'>('all');
  const [isLoadingHistory, setIsLoadingHistory] = useState(false);

  // Permission Check
  const allowedRoles = ['ceo', 'gm', 'manager', 'super_admin'];
  const hasPermission = currentUser && allowedRoles.includes(currentUser.role);

  useEffect(() => {
    fetchHistory();
  }, []);

  useEffect(() => {
    if (activeTab === 'vip') setSelectedLevel('VIP 1');
    else if (activeTab === 'svip') setSelectedSvipLevel('SVIP 1');
    else if (activeTab === 'frame') setSelectedFrame('👑 Golden Monarch');
  }, [activeTab]);

  const fetchHistory = async () => {
    setIsLoadingHistory(true);
    try {
      const records = await ApiClient.getBenefitAssignments();
      setHistoryList(Array.isArray(records) ? records : []);
    } catch (err: any) {
      console.warn('Failed to load benefit history', err?.message || err);
      setHistoryList([]);
    } finally {
      setIsLoadingHistory(false);
    }
  };

  // Filtered users for search autocomplete
  const searchedUsers = searchQuery.trim()
    ? users.filter(u => 
        u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        u.uid.toLowerCase().includes(searchQuery.toLowerCase()) ||
        u.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (u.email && u.email.toLowerCase().includes(searchQuery.toLowerCase()))
      ).slice(0, 5)
    : [];

  const handleSelectUser = (u: UserType) => {
    setSelectedTargetUser(u);
    setSearchQuery(u.name);
  };

  const getCalculatedExpiry = () => {
    if (durationDays === 'permanent') return 'Permanent (No Expiry)';
    const days = Number(durationDays) || 30;
    const d = new Date();
    d.setDate(d.getDate() + days);
    return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
  };

  const handleSubmitAssignment = async () => {
    if (!selectedTargetUser) {
      showNotification('⚠️ Please search and select a target user first.');
      return;
    }

    setIsSubmitting(true);
    try {
      if (activeTab === 'vip') {
        await ApiClient.assignVip({
          targetUserId: selectedTargetUser.id,
          targetUid: selectedTargetUser.uid,
          level: selectedLevel,
          durationDays: Number(durationDays) || 30,
          assignmentMode,
          reason: grantReason
        });
        showNotification(`✅ Successfully assigned ${selectedLevel} to ${selectedTargetUser.name} (${selectedTargetUser.uid}).`);
      } else if (activeTab === 'svip') {
        await ApiClient.assignSvip({
          targetUserId: selectedTargetUser.id,
          targetUid: selectedTargetUser.uid,
          level: selectedSvipLevel,
          durationDays: Number(durationDays) || 30,
          assignmentMode,
          reason: grantReason
        });
        showNotification(`✅ Successfully assigned ${selectedSvipLevel} to ${selectedTargetUser.name} (${selectedTargetUser.uid}).`);
      } else if (activeTab === 'frame') {
        await ApiClient.assignFrame({
          targetUserId: selectedTargetUser.id,
          targetUid: selectedTargetUser.uid,
          frameId: selectedFrame,
          durationDays: durationDays,
          assignmentMode,
          reason: grantReason
        });
        showNotification(`✅ Successfully assigned Profile Frame [${selectedFrame}] to ${selectedTargetUser.name}.`);
      }

      setShowConfirmModal(false);
      onRefresh();
      fetchHistory();
    } catch (err: any) {
      showNotification(`❌ Error: ${err.message || 'Failed to complete assignment.'}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRevokeBenefit = async () => {
    if (!selectedTargetUser) return;
    setIsSubmitting(true);
    try {
      if (activeTab === 'vip') {
        await ApiClient.revokeVip({ targetUserId: selectedTargetUser.id, reason: grantReason || 'Admin Revoke' });
        showNotification(`✅ VIP privilege revoked for ${selectedTargetUser.name}.`);
      } else if (activeTab === 'svip') {
        await ApiClient.revokeSvip({ targetUserId: selectedTargetUser.id, reason: grantReason || 'Admin Revoke' });
        showNotification(`✅ SVIP privilege revoked for ${selectedTargetUser.name}.`);
      } else if (activeTab === 'frame') {
        await ApiClient.revokeFrame({ targetUserId: selectedTargetUser.id, reason: grantReason || 'Admin Revoke' });
        showNotification(`✅ Profile Frame revoked for ${selectedTargetUser.name}.`);
      }

      setShowRevokeModal(false);
      onRefresh();
      fetchHistory();
    } catch (err: any) {
      showNotification(`❌ Revoke failed: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredHistory = historyList.filter(h => {
    if (historyFilter === 'vip') return h.benefitType === 'vip';
    if (historyFilter === 'svip') return h.benefitType === 'svip';
    if (historyFilter === 'frame') return h.benefitType === 'frame';
    if (historyFilter === 'active') return h.status === 'active';
    if (historyFilter === 'revoked') return h.status === 'revoked';
    return true;
  });

  if (!hasPermission) {
    return (
      <div className="p-8 text-center space-y-4 bg-red-950/20 rounded-3xl border border-red-500/20 my-6">
        <ShieldAlert className="w-12 h-12 text-red-500 mx-auto" />
        <h3 className="text-xl font-bold text-white">Access Restricted</h3>
        <p className="text-sm text-slate-300 max-w-md mx-auto">
          The VIP / SVIP / Frame Management System is exclusively reserved for CEO, General Manager (GM), and Manager roles.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* HEADER BANNER */}
      <div className="relative overflow-hidden rounded-3xl p-6 bg-gradient-to-r from-purple-900/40 via-indigo-900/30 to-amber-900/40 backdrop-blur-xl border border-white/10 shadow-2xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-400 via-purple-600 to-indigo-600 flex items-center justify-center text-2xl shadow-xl border border-white/20">
            👑
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-black text-white">VIP / SVIP / Profile Frame Management</h2>
              <span className="bg-amber-500/20 text-amber-300 text-xs font-black px-2.5 py-0.5 rounded-full border border-amber-500/30">
                Official Staff Engine
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-1">
              Directly assign, extend, or revoke VIP privileges, SVIP status, and animated Profile Frames for users with full audit logging.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button 
            onClick={() => { fetchHistory(); onRefresh(); }}
            className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-slate-200 text-xs font-bold transition flex items-center gap-1.5 border border-white/10"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoadingHistory ? 'animate-spin' : ''}`} /> Refresh
          </button>
        </div>
      </div>

      {/* TOP NAVIGATION TABS */}
      <div className="flex gap-2 p-1.5 bg-black/40 backdrop-blur-xl rounded-2xl border border-white/10">
        {[
          { id: 'vip', label: 'VIP Privileges', icon: '👑', color: 'text-amber-400' },
          { id: 'svip', label: 'SVIP Super Status', icon: '⚡', color: 'text-purple-400' },
          { id: 'frame', label: 'Profile Frame Selector', icon: '✨', color: 'text-cyan-400' }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex-1 py-3 px-4 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-2 ${
              activeTab === tab.id
                ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg border border-white/20'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <span className="text-base">{tab.icon}</span>
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* MAIN TWO-COLUMN CONFIGURATION LAYOUT */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* LEFT COLUMN: TARGET USER SEARCH & PROFILE PREVIEW */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white/5 backdrop-blur-xl p-5 rounded-3xl border border-white/10 space-y-4 shadow-2xl">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Search className="w-4 h-4 text-purple-400" /> Step 1: Select Target User
            </h3>

            {/* Search Input */}
            <div className="relative">
              <input
                type="text"
                placeholder="Search user by UID, Name, Email, or User ID..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full bg-black/50 text-xs text-white pl-9 pr-4 py-3 rounded-xl border border-white/10 focus:outline-none focus:border-purple-500"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
            </div>

            {/* Autocomplete Dropdown */}
            {searchedUsers.length > 0 && searchQuery && !selectedTargetUser && (
              <div className="bg-slate-900 border border-white/10 rounded-2xl overflow-hidden divide-y divide-white/5 shadow-2xl">
                {searchedUsers.map((u, idx) => (
                  <button
                    key={`vip-target-${u.id}-${idx}`}
                    onClick={() => handleSelectUser(u)}
                    className="w-full p-3 text-left hover:bg-white/10 transition flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3">
                      <img src={u.avatar} alt={u.name} className="w-8 h-8 rounded-full object-cover border border-white/20" />
                      <div>
                        <p className="text-xs font-bold text-white">{u.name}</p>
                        <p className="text-[10px] text-slate-400">UID: {u.uid} • Role: {u.role}</p>
                      </div>
                    </div>
                    <span className="text-[10px] bg-purple-500/20 text-purple-300 font-bold px-2 py-0.5 rounded-full border border-purple-500/30">
                      Select
                    </span>
                  </button>
                ))}
              </div>
            )}

            {/* Selected User Preview Card */}
            {selectedTargetUser ? (
              <div className="p-4 rounded-2xl bg-gradient-to-br from-purple-900/30 to-indigo-900/30 border border-purple-500/30 space-y-3 relative">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <img 
                        src={selectedTargetUser.avatar} 
                        alt={selectedTargetUser.name} 
                        className="w-14 h-14 rounded-full object-cover border-2 border-amber-400/80 shadow-lg" 
                      />
                      {selectedTargetUser.frame && (
                        <div className="absolute -inset-1 rounded-full border-2 border-amber-400 animate-pulse pointer-events-none" />
                      )}
                    </div>
                    <div>
                      <h4 className="text-sm font-extrabold text-white flex items-center gap-1.5">
                        {selectedTargetUser.name}
                        {selectedTargetUser.vipLevel === 'vip' && <span className="text-amber-400 text-xs">👑 VIP</span>}
                        {selectedTargetUser.vipLevel === 'svip' && <span className="text-purple-400 text-xs">⚡ SVIP</span>}
                      </h4>
                      <p className="text-xs text-amber-300 font-mono font-bold">UID: {selectedTargetUser.uid}</p>
                      <p className="text-[10px] text-slate-300">{selectedTargetUser.email}</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => { setSelectedTargetUser(null); setSearchQuery(''); }}
                    className="text-[10px] font-bold text-red-400 hover:text-red-300 bg-red-500/10 px-2 py-1 rounded-lg border border-red-500/20"
                  >
                    Change
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[10px] pt-2 border-t border-white/10">
                  <div className="p-2 bg-black/30 rounded-xl">
                    <span className="text-slate-400 block">Current VIP Status:</span>
                    <span className="font-bold text-white capitalize">{selectedTargetUser.vipLevel || 'None'}</span>
                  </div>
                  <div className="p-2 bg-black/30 rounded-xl">
                    <span className="text-slate-400 block">Current Frame:</span>
                    <span className="font-bold text-cyan-300 truncate block">{selectedTargetUser.frame || 'None'}</span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-8 text-center bg-black/20 rounded-2xl border border-dashed border-white/10 space-y-2">
                <User className="w-8 h-8 text-slate-500 mx-auto" />
                <p className="text-xs text-slate-400">Search and pick a user to start granting VIP privileges.</p>
              </div>
            )}
          </div>
        </div>

        {/* RIGHT COLUMN: BENEFIT LEVEL, DURATION & ASSIGNMENT CONTROLS */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white/5 backdrop-blur-xl p-5 rounded-3xl border border-white/10 space-y-5 shadow-2xl">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Crown className="w-4 h-4 text-amber-400" /> Step 2: Configure Benefit Details
            </h3>

            {/* TAB 1: VIP SELECTOR */}
            {activeTab === 'vip' && (
              <div className="space-y-3">
                <label className="text-xs font-bold text-slate-300 block">Select VIP Tier Level:</label>
                <div className="grid grid-cols-5 gap-2">
                  {['VIP 1', 'VIP 2', 'VIP 3', 'VIP 4', 'VIP 5', 'VIP 6', 'VIP 7', 'VIP 8', 'VIP 9', 'VIP 10'].map(lvl => (
                    <button
                      key={lvl}
                      onClick={() => setSelectedLevel(lvl)}
                      className={`py-2.5 px-2 rounded-xl text-xs font-black transition border ${
                        selectedLevel === lvl
                          ? 'bg-gradient-to-r from-amber-500 to-yellow-600 text-black border-amber-300 shadow-lg scale-105'
                          : 'bg-black/30 text-slate-300 border-white/10 hover:border-white/25 hover:text-white'
                      }`}
                    >
                      👑 {lvl}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 2: SVIP SELECTOR */}
            {activeTab === 'svip' && (
              <div className="space-y-3">
                <label className="text-xs font-bold text-slate-300 block">Select SVIP Status Level:</label>
                <div className="grid grid-cols-5 gap-2">
                  {['SVIP 1', 'SVIP 2', 'SVIP 3', 'SVIP 4', 'SVIP 5', 'SVIP 6', 'SVIP 7', 'SVIP 8', 'SVIP 9', 'SVIP 10'].map(lvl => (
                    <button
                      key={lvl}
                      onClick={() => setSelectedSvipLevel(lvl)}
                      className={`py-2.5 px-2 rounded-xl text-xs font-black transition border ${
                        selectedSvipLevel === lvl
                          ? 'bg-gradient-to-r from-purple-500 to-indigo-600 text-white border-purple-300 shadow-lg scale-105'
                          : 'bg-black/30 text-slate-300 border-white/10 hover:border-white/25 hover:text-white'
                      }`}
                    >
                      ⚡ {lvl}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 3: FRAME SELECTOR */}
            {activeTab === 'frame' && (
              <div className="space-y-3">
                <label className="text-xs font-bold text-slate-300 block">Choose Profile Avatar Frame:</label>
                <div className="grid grid-cols-3 gap-2.5">
                  {PROFILE_FRAMES.map(f => (
                    <button
                      key={f.id}
                      onClick={() => setSelectedFrame(f.id)}
                      className={`p-3 rounded-2xl border text-left transition relative overflow-hidden flex items-center gap-2.5 ${
                        selectedFrame === f.id
                          ? 'bg-purple-900/40 border-cyan-400 shadow-lg'
                          : 'bg-black/30 border-white/10 hover:border-white/25'
                      }`}
                    >
                      <div className={`w-9 h-9 rounded-full bg-gradient-to-tr ${f.color} flex items-center justify-center text-lg shadow-md`}>
                        {f.icon}
                      </div>
                      <div>
                        <p className="text-xs font-bold text-white">{f.name}</p>
                        <p className="text-[9px] text-slate-400">Animated Frame</p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* DURATION SELECTOR */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-300 block">Validity Duration:</label>
              <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
                {[
                  { days: 1, label: '1 Day' },
                  { days: 7, label: '7 Days' },
                  { days: 30, label: '30 Days' },
                  { days: 90, label: '90 Days' },
                  { days: 180, label: '180 Days' },
                  { days: 365, label: '1 Year' },
                  { days: 'permanent', label: 'Permanent' }
                ].map(d => (
                  <button
                    key={String(d.days)}
                    onClick={() => setDurationDays(d.days as any)}
                    className={`py-2 text-[11px] font-bold rounded-xl border transition ${
                      durationDays === d.days
                        ? 'bg-white text-purple-900 border-white shadow'
                        : 'bg-black/30 text-slate-300 border-white/10 hover:border-white/20'
                    }`}
                  >
                    {d.label}
                  </button>
                ))}
              </div>
              <p className="text-[10px] text-slate-400">
                Calculated Expiry Date: <span className="font-bold text-amber-300">{getCalculatedExpiry()}</span>
              </p>
            </div>

            {/* ASSIGNMENT MODE & REASON */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-300">Grant Assignment Mode:</label>
                <select
                  value={assignmentMode}
                  onChange={e => setAssignmentMode(e.target.value as any)}
                  className="w-full bg-black/50 text-xs text-white p-2.5 rounded-xl border border-white/10 focus:outline-none"
                >
                  <option value="free_grant">FREE ADMIN GRANT (Complimentary)</option>
                  <option value="coin_deduction">COIN-BASED ASSIGNMENT (Internal Record)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-300">Grant / Revoke Reason (Audit):</label>
                <input
                  type="text"
                  placeholder="e.g. VIP Event reward / Official CEO grant"
                  value={grantReason}
                  onChange={e => setGrantReason(e.target.value)}
                  className="w-full bg-black/50 text-xs text-white p-2.5 rounded-xl border border-white/10 focus:outline-none"
                />
              </div>
            </div>

            {/* ACTION BUTTONS */}
            <div className="flex items-center gap-3 pt-3 border-t border-white/10">
              <button
                disabled={!selectedTargetUser}
                onClick={() => { setActionType('assign'); setShowConfirmModal(true); }}
                className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-black text-xs font-black transition shadow-lg disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" /> 
                {activeTab === 'vip' ? 'SEND VIP PRIVILEGE' : activeTab === 'svip' ? 'SEND SVIP STATUS' : 'SEND PROFILE FRAME'}
              </button>

              <button
                disabled={!selectedTargetUser}
                onClick={() => { setActionType('revoke'); setShowRevokeModal(true); }}
                className="py-3 px-4 rounded-xl bg-red-600/30 hover:bg-red-600/50 text-red-200 border border-red-500/30 text-xs font-bold transition disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5"
              >
                <Trash2 className="w-4 h-4" /> Revoke
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ASSIGNMENT HISTORY & AUDIT LOG TABLE */}
      <div className="bg-white/5 backdrop-blur-xl p-5 rounded-3xl border border-white/10 space-y-4 shadow-2xl">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          <div>
            <h3 className="text-base font-extrabold text-white flex items-center gap-2">
              <Award className="w-5 h-5 text-amber-400" /> Benefit Assignment History & Audit Trail
            </h3>
            <p className="text-xs text-slate-400">Complete log of all VIP, SVIP, and Frame grants executed by Staff</p>
          </div>

          {/* Filters */}
          <div className="flex items-center gap-1.5 p-1 bg-black/40 rounded-xl border border-white/10">
            {['all', 'vip', 'svip', 'frame', 'active', 'revoked'].map(f => (
              <button
                key={f}
                onClick={() => setHistoryFilter(f as any)}
                className={`px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase transition ${
                  historyFilter === f
                    ? 'bg-purple-600 text-white shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {f}
              </button>
            ))}
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-white/10 text-slate-400 uppercase text-[10px] tracking-wider">
                <th className="p-3">Target User</th>
                <th className="p-3">Benefit Type</th>
                <th className="p-3">Level / Frame</th>
                <th className="p-3">Duration</th>
                <th className="p-3">Assigned By</th>
                <th className="p-3">Status</th>
                <th className="p-3">Assigned Date</th>
                <th className="p-3">Expiry Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-slate-200">
              {filteredHistory.length > 0 ? (
                filteredHistory.map(rec => (
                  <tr key={rec.id} className="hover:bg-white/5 transition">
                    <td className="p-3">
                      <div className="flex items-center gap-2.5">
                        <img src={rec.targetUserAvatar} alt={rec.targetUserName} className="w-7 h-7 rounded-full object-cover border border-white/20" />
                        <div>
                          <p className="font-bold text-white">{rec.targetUserName}</p>
                          <p className="text-[10px] text-amber-300 font-mono">UID: {rec.targetUserUid}</p>
                        </div>
                      </div>
                    </td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded-md font-extrabold text-[10px] uppercase border ${
                        rec.benefitType === 'vip' ? 'bg-amber-500/20 text-amber-300 border-amber-500/30' :
                        rec.benefitType === 'svip' ? 'bg-purple-500/20 text-purple-300 border-purple-500/30' :
                        'bg-cyan-500/20 text-cyan-300 border-cyan-500/30'
                      }`}>
                        {rec.benefitType}
                      </span>
                    </td>
                    <td className="p-3 font-bold text-white">{rec.levelOrFrameId}</td>
                    <td className="p-3 font-semibold text-slate-300">
                      {rec.durationDays === 'permanent' ? 'Permanent' : `${rec.durationDays} Days`}
                    </td>
                    <td className="p-3">
                      <div>
                        <p className="font-semibold text-white">{rec.assignedByUserName}</p>
                        <span className="text-[9px] bg-white/10 text-slate-300 px-1.5 py-0.2 rounded uppercase">
                          {rec.assignedByRole}
                        </span>
                      </div>
                    </td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        rec.status === 'active' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' :
                        rec.status === 'revoked' ? 'bg-red-500/20 text-red-300 border border-red-500/30' :
                        'bg-slate-500/20 text-slate-400'
                      }`}>
                        {rec.status}
                      </span>
                    </td>
                    <td className="p-3 text-[10px] text-slate-400">
                      {new Date(rec.createdAt).toLocaleDateString()}
                    </td>
                    <td className="p-3 text-[10px] text-slate-400">
                      {rec.expiresAt === 'permanent' ? 'Permanent' : new Date(rec.expiresAt).toLocaleDateString()}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-400">
                    No benefit assignment records found matching filter.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* CONFIRMATION MODAL FOR ASSIGNMENT */}
      {showConfirmModal && selectedTargetUser && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-purple-500/30 rounded-3xl p-6 max-w-md w-full space-y-4 shadow-2xl animate-scaleUp">
            <div className="flex items-center gap-3 text-amber-400">
              <ShieldCheck className="w-8 h-8" />
              <div>
                <h3 className="text-lg font-black text-white">Confirm Benefit Grant</h3>
                <p className="text-xs text-slate-400">Review benefit details before executing</p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-2 text-xs">
              <p className="flex justify-between"><span className="text-slate-400">Target User:</span> <strong className="text-white">{selectedTargetUser.name}</strong></p>
              <p className="flex justify-between"><span className="text-slate-400">Target User UID:</span> <strong className="text-amber-300 font-mono">{selectedTargetUser.uid}</strong></p>
              <p className="flex justify-between"><span className="text-slate-400">Benefit Type:</span> <strong className="text-purple-300 uppercase">{activeTab}</strong></p>
              <p className="flex justify-between"><span className="text-slate-400">Selected Level / Frame:</span> <strong className="text-amber-400">{activeTab === 'vip' ? selectedLevel : activeTab === 'svip' ? selectedSvipLevel : selectedFrame}</strong></p>
              <p className="flex justify-between"><span className="text-slate-400">Duration:</span> <strong className="text-white">{durationDays === 'permanent' ? 'Permanent' : `${durationDays} Days`}</strong></p>
              <p className="flex justify-between"><span className="text-slate-400">Calculated Expiry:</span> <strong className="text-emerald-400">{getCalculatedExpiry()}</strong></p>
              <p className="flex justify-between"><span className="text-slate-400">Authorized Staff:</span> <strong className="text-white">{currentUser?.name} ({currentUser?.role.toUpperCase()})</strong></p>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={() => setShowConfirmModal(false)}
                className="flex-1 py-3 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 text-xs font-bold transition"
              >
                Cancel
              </button>
              <button
                onClick={handleSubmitAssignment}
                disabled={isSubmitting}
                className="flex-1 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-black text-xs font-black transition shadow-lg flex items-center justify-center gap-1.5"
              >
                {isSubmitting ? <RefreshCw className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
                Confirm & Send
              </button>
            </div>
          </div>
        </div>
      )}

      {/* REVOKE CONFIRMATION MODAL */}
      {showRevokeModal && selectedTargetUser && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-red-500/30 rounded-3xl p-6 max-w-md w-full space-y-4 shadow-2xl animate-scaleUp">
            <div className="flex items-center gap-3 text-red-400">
              <ShieldAlert className="w-8 h-8" />
              <div>
                <h3 className="text-lg font-black text-white">Revoke Benefit</h3>
                <p className="text-xs text-slate-400">Confirm revoking active benefit status</p>
              </div>
            </div>

            <p className="text-xs text-slate-300">
              Are you sure you want to revoke <strong className="text-white">{activeTab.toUpperCase()}</strong> status from <strong className="text-amber-300">{selectedTargetUser.name} ({selectedTargetUser.uid})</strong>?
            </p>

            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={() => setShowRevokeModal(false)}
                className="flex-1 py-3 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 text-xs font-bold transition"
              >
                Cancel
              </button>
              <button
                onClick={handleRevokeBenefit}
                disabled={isSubmitting}
                className="flex-1 py-3 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold transition shadow-lg flex items-center justify-center gap-1.5"
              >
                {isSubmitting ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                Confirm Revoke
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
