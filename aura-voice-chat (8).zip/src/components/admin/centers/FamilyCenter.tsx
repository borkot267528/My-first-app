import React, { useState, useEffect } from 'react';
import { 
  Users, Award, Trophy, Search, FileSpreadsheet, Plus, Shield, 
  Globe, Crown, RefreshCw, Filter, LayoutGrid, List, ChevronRight,
  Sparkles, CheckCircle2, AlertTriangle, ArrowUpDown, Eye, Settings
} from 'lucide-react';
import { Family } from '../../../types';
import { ApiClient } from '../../../lib/api';
import { exportToExcel } from '../../../lib/exportUtils';
import { useApp } from '../../../context/AppContext';
import { CreateFamilyModal } from './family/CreateFamilyModal';
import { FamilyDetailsModal } from './family/FamilyDetailsModal';

interface FamilyCenterProps {
  showNotification: (msg: string) => void;
}

export const FamilyCenter: React.FC<FamilyCenterProps> = ({ showNotification }) => {
  const { families, refreshUser } = useApp();
  
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'ranking' | 'members' | 'contribution' | 'level' | 'name'>('ranking');
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');

  // Modals state
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedFamilyForDetails, setSelectedFamilyForDetails] = useState<Family | null>(null);

  // Local families state to allow optimistic or direct updates
  const [localFamilies, setLocalFamilies] = useState<Family[]>(families);

  useEffect(() => {
    setLocalFamilies(families);
  }, [families]);

  // Load fresh families on mount
  useEffect(() => {
    loadFreshFamilies();
  }, []);

  const loadFreshFamilies = async () => {
    try {
      const data = await ApiClient.getFamilies();
      if (data && Array.isArray(data)) {
        setLocalFamilies(data);
      }
    } catch (e) {
      console.warn('Could not fetch families:', e);
    }
  };

  const handleRefresh = async () => {
    await refreshUser();
    await loadFreshFamilies();
    showNotification('Family Guilds directory refreshed!');
  };

  // Filter & Sort Logic
  const filteredFamilies = localFamilies.filter(f => {
    const q = searchQuery.toLowerCase().trim();
    const matchesSearch = !q || (
      f.name.toLowerCase().includes(q) ||
      (f.familyId && f.familyId.toLowerCase().includes(q)) ||
      f.leaderName.toLowerCase().includes(q) ||
      (f.category && f.category.toLowerCase().includes(q)) ||
      (f.country && f.country.toLowerCase().includes(q))
    );

    const matchesCategory = selectedCategory === 'all' || f.category === selectedCategory;
    const matchesStatus = selectedStatus === 'all' || (f.status || 'active') === selectedStatus;

    return matchesSearch && matchesCategory && matchesStatus;
  }).sort((a, b) => {
    if (sortBy === 'ranking') return (a.ranking || 999) - (b.ranking || 999);
    if (sortBy === 'members') return (b.memberCount || 0) - (a.memberCount || 0);
    if (sortBy === 'contribution') return (b.totalContribution || 0) - (a.totalContribution || 0);
    if (sortBy === 'level') return (b.level || 1) - (a.level || 1);
    if (sortBy === 'name') return a.name.localeCompare(b.name);
    return 0;
  });

  // Calculate Statistics
  const totalGuilds = localFamilies.length;
  const activeGuilds = localFamilies.filter(f => (f.status || 'active') === 'active').length;
  const totalClanMembers = localFamilies.reduce((acc, f) => acc + (f.memberCount || 0), 0);
  const topGuild = [...localFamilies].sort((a, b) => (b.totalContribution || 0) - (a.totalContribution || 0))[0];

  const handleExport = () => exportToExcel('Family_Guilds_Report', filteredFamilies);

  const handleFamilyCreated = (newFamily: Family) => {
    setLocalFamilies(prev => [newFamily, ...prev.filter(f => f.id !== newFamily.id)]);
    refreshUser();
  };

  const handleFamilyUpdated = (updatedFamily: Family) => {
    setLocalFamilies(prev => prev.map(f => f.id === updatedFamily.id ? updatedFamily : f));
    if (selectedFamilyForDetails?.id === updatedFamily.id) {
      setSelectedFamilyForDetails(updatedFamily);
    }
    refreshUser();
  };

  const handleFamilyDeleted = (familyId: string) => {
    setLocalFamilies(prev => prev.filter(f => f.id !== familyId));
    if (selectedFamilyForDetails?.id === familyId) {
      setSelectedFamilyForDetails(null);
    }
    refreshUser();
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      
      {/* 1. HEADER BAR & PRIMARY ACTION */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-3xl bg-gradient-to-r from-amber-950/40 via-slate-900/60 to-purple-950/40 border border-white/10 backdrop-blur-md shadow-xl">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-2xl bg-amber-400 text-black shadow-lg shadow-amber-500/20 font-black">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-black text-white flex items-center gap-2">
                Family Guilds & Communities Directory
              </h3>
              <p className="text-xs text-slate-300">
                Admin Overview, Clan Rosters, Member Limits, Guild Creation & Governance
              </p>
            </div>
          </div>
        </div>

        {/* ACTIONS */}
        <div className="flex flex-wrap items-center gap-2.5 w-full sm:w-auto">
          {/* Create New Family Button (Mandatory & Prominent) */}
          <button
            id="btn-create-family"
            onClick={() => setShowCreateModal(true)}
            className="flex-1 sm:flex-none px-4 py-2.5 bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-black font-black text-xs rounded-2xl shadow-lg shadow-amber-500/25 hover:scale-105 active:scale-95 transition flex items-center justify-center gap-2"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>Create New Family</span>
          </button>

          <button
            onClick={handleRefresh}
            className="px-3.5 py-2.5 bg-white/10 hover:bg-white/20 text-white font-bold text-xs rounded-2xl transition flex items-center gap-1.5"
            title="Refresh Directory"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Refresh</span>
          </button>

          <button
            onClick={handleExport}
            className="px-3.5 py-2.5 bg-white/10 hover:bg-white/20 text-white font-bold text-xs rounded-2xl transition flex items-center gap-1.5"
            title="Export Excel Report"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden md:inline">Export</span>
          </button>
        </div>
      </div>

      {/* 2. SUMMARY METRICS BAR */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
        <div className="p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-bold">Total Guilds</span>
            <Users className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-2xl font-black text-white">{totalGuilds}</p>
          <span className="text-[11px] text-emerald-400 font-medium">Registered Clans</span>
        </div>

        <div className="p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-bold">Active Clans</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-2xl font-black text-emerald-300">{activeGuilds}</p>
          <span className="text-[11px] text-slate-400 font-medium">Operational Status</span>
        </div>

        <div className="p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-bold">Clan Members</span>
            <Crown className="w-4 h-4 text-cyan-400" />
          </div>
          <p className="text-2xl font-black text-cyan-300">{totalClanMembers.toLocaleString()}</p>
          <span className="text-[11px] text-slate-400 font-medium">Across all Guilds</span>
        </div>

        <div className="p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-bold">Top Guild #1</span>
            <Trophy className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-base font-black text-amber-300 truncate">{topGuild?.name || 'N/A'}</p>
          <span className="text-[11px] text-amber-400/90 font-mono font-bold">
            🪙 {(topGuild?.totalContribution || 0).toLocaleString()} coins
          </span>
        </div>
      </div>

      {/* 3. FILTERS & SEARCH CONTROL BAR */}
      <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3">
        <div className="flex flex-col md:flex-row items-stretch md:items-center gap-3">
          
          {/* Search Input */}
          <div className="relative flex-1">
            <input
              type="text"
              placeholder="Search families by Name, Unique ID (FAM-xxx), Leader Name, or Region..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-black/40 text-xs text-white pl-9 pr-4 py-2.5 rounded-xl border border-white/10 focus:outline-none focus:border-amber-400 transition"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          </div>

          {/* Category Filter */}
          <select
            value={selectedCategory}
            onChange={e => setSelectedCategory(e.target.value)}
            className="px-3 py-2.5 bg-black/40 text-xs text-white rounded-xl border border-white/10 focus:outline-none focus:border-amber-400"
          >
            <option value="all">All Categories</option>
            <option value="VIP & Elite">VIP & Elite</option>
            <option value="Gaming & Social">Gaming & Social</option>
            <option value="Music & Acoustic">Music & Acoustic</option>
            <option value="PK Warriors">PK Warriors</option>
            <option value="Global Community">Global Community</option>
          </select>

          {/* Status Filter */}
          <select
            value={selectedStatus}
            onChange={e => setSelectedStatus(e.target.value)}
            className="px-3 py-2.5 bg-black/40 text-xs text-white rounded-xl border border-white/10 focus:outline-none focus:border-amber-400"
          >
            <option value="all">All Statuses</option>
            <option value="active">Active 🟢</option>
            <option value="inactive">Inactive ⚪</option>
            <option value="suspended">Suspended 🔴</option>
          </select>

          {/* Sort By */}
          <select
            value={sortBy}
            onChange={e => setSortBy(e.target.value as any)}
            className="px-3 py-2.5 bg-black/40 text-xs text-white rounded-xl border border-white/10 focus:outline-none focus:border-amber-400"
          >
            <option value="ranking">Sort: Clan Rank 🏆</option>
            <option value="members">Sort: Most Members 👥</option>
            <option value="contribution">Sort: Contribution 🪙</option>
            <option value="level">Sort: Level ⚡</option>
            <option value="name">Sort: Name (A-Z)</option>
          </select>

          {/* View Mode Toggle */}
          <div className="flex items-center p-1 bg-black/40 rounded-xl border border-white/10 shrink-0">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-lg text-xs transition ${
                viewMode === 'grid' ? 'bg-amber-400 text-black shadow' : 'text-slate-400 hover:text-white'
              }`}
              title="Grid View"
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded-lg text-xs transition ${
                viewMode === 'table' ? 'bg-amber-400 text-black shadow' : 'text-slate-400 hover:text-white'
              }`}
              title="Table View"
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* 4. RESULTS DISPLAY */}
      {filteredFamilies.length === 0 ? (
        <div className="p-12 text-center rounded-3xl bg-white/5 border border-white/10 space-y-4">
          <div className="w-16 h-16 rounded-3xl bg-amber-400/10 border border-amber-400/20 flex items-center justify-center text-3xl mx-auto">
            👑
          </div>
          <div>
            <h4 className="text-base font-black text-white">No Family Guilds Found</h4>
            <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
              No families match your current filter criteria. You can clear the search filters or create a new Family Guild.
            </p>
          </div>
          <button
            onClick={() => setShowCreateModal(true)}
            className="px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-black font-black text-xs rounded-xl shadow transition inline-flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" /> Create First Family
          </button>
        </div>
      ) : viewMode === 'grid' ? (
        
        /* GRID CARDS VIEW */
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredFamilies.map(f => {
            const isSuspended = f.status === 'suspended';
            const isInactive = f.status === 'inactive';

            return (
              <div
                key={f.id}
                onClick={() => setSelectedFamilyForDetails(f)}
                className="group relative p-5 rounded-3xl bg-slate-900/80 border border-white/10 hover:border-amber-400/50 space-y-4 shadow-xl hover:shadow-2xl transition cursor-pointer overflow-hidden flex flex-col justify-between"
              >
                {/* Status Indicator Stripe */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3.5">
                    {f.logo ? (
                      <img
                        src={f.logo}
                        alt={f.name}
                        className="w-14 h-14 rounded-2xl object-cover border-2 border-amber-400/80 shadow-lg group-hover:scale-105 transition"
                      />
                    ) : (
                      <span className="text-3xl p-3 rounded-2xl bg-gradient-to-tr from-amber-400 to-yellow-600 border border-white/20 shadow-md flex items-center justify-center">
                        {f.badge || '👑'}
                      </span>
                    )}

                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-black text-white text-base group-hover:text-amber-300 transition">
                          {f.name}
                        </h4>
                        {f.familyId && (
                          <span className="text-xs text-amber-300 font-mono font-bold bg-amber-400/10 px-2 py-0.5 rounded-lg border border-amber-400/20">
                            {f.familyId}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-300 mt-0.5">
                        Leader: <strong className="text-amber-300">{f.leaderName}</strong> • <span className="text-cyan-300">Level {f.level}</span>
                      </p>
                      <p className="text-[11px] text-slate-400">
                        Members: <strong className="text-white font-bold">{f.memberCount}/{f.maxMembers}</strong> • Category: <span className="text-purple-300">{f.category || 'General'}</span>
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-col items-end gap-1.5">
                    <span className="text-xs font-black px-2.5 py-1 rounded-xl bg-amber-400/20 text-amber-300 border border-amber-400/30">
                      Rank #{f.ranking || 'Clan'}
                    </span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md uppercase ${
                      isSuspended
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                        : isInactive
                        ? 'bg-slate-500/20 text-slate-300 border border-slate-500/30'
                        : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    }`}>
                      {f.status || 'active'}
                    </span>
                  </div>
                </div>

                {/* Slogan & Details Box */}
                <div className="p-3.5 rounded-2xl bg-black/40 text-xs space-y-2 border border-white/5">
                  <div className="flex justify-between items-center text-slate-300">
                    <span className="text-slate-400">Total Contribution:</span>
                    <strong className="text-amber-300 font-mono font-bold">🪙 {(f.totalContribution || 0).toLocaleString()}</strong>
                  </div>
                  {f.slogan && (
                    <p className="text-slate-300 text-[11px] line-clamp-1">
                      <span className="text-slate-500">Motto:</span> "{f.slogan}"
                    </p>
                  )}
                  {f.announcement && (
                    <p className="text-amber-200/80 text-[11px] line-clamp-1">
                      <span className="text-amber-400">Notice:</span> {f.announcement}
                    </p>
                  )}
                </div>

                {/* Card Action Footer */}
                <div className="pt-2 border-t border-white/5 flex items-center justify-between text-xs">
                  <span className="text-[11px] text-slate-400 flex items-center gap-1">
                    <Globe className="w-3 h-3" /> {f.country || 'Global'} ({f.privacy || 'public'})
                  </span>
                  <span className="text-amber-400 font-bold group-hover:underline flex items-center gap-1 text-[11px]">
                    Manage Guild <ChevronRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        
        /* TABLE VIEW */
        <div className="rounded-3xl bg-slate-900/80 border border-white/10 overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-black/50 text-slate-400 uppercase text-[10px] font-black border-b border-white/10">
                <tr>
                  <th className="p-4">Rank & Guild</th>
                  <th className="p-4">Leader</th>
                  <th className="p-4">Category</th>
                  <th className="p-4">Members</th>
                  <th className="p-4">Level</th>
                  <th className="p-4">Total Contribution</th>
                  <th className="p-4">Status</th>
                  <th className="p-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {filteredFamilies.map(f => (
                  <tr
                    key={f.id}
                    onClick={() => setSelectedFamilyForDetails(f)}
                    className="hover:bg-white/5 transition cursor-pointer"
                  >
                    <td className="p-4">
                      <div className="flex items-center gap-3">
                        <span className="font-mono font-bold text-amber-400 text-xs">#{f.ranking || '-'}</span>
                        {f.logo ? (
                          <img src={f.logo} alt={f.name} className="w-8 h-8 rounded-lg object-cover" />
                        ) : (
                          <span className="text-lg">{f.badge || '👑'}</span>
                        )}
                        <div>
                          <strong className="text-white text-xs block">{f.name}</strong>
                          <span className="text-[10px] text-slate-400 font-mono">{f.familyId || f.id}</span>
                        </div>
                      </div>
                    </td>
                    <td className="p-4">
                      <strong className="text-amber-300 text-xs">{f.leaderName}</strong>
                    </td>
                    <td className="p-4">
                      <span className="px-2 py-0.5 rounded bg-white/5 text-[10px] text-purple-300">
                        {f.category || 'General'}
                      </span>
                    </td>
                    <td className="p-4 font-bold text-white">
                      {f.memberCount} / {f.maxMembers}
                    </td>
                    <td className="p-4">
                      <span className="px-2 py-0.5 rounded bg-cyan-400/10 text-cyan-300 font-bold text-[10px]">
                        Lvl {f.level}
                      </span>
                    </td>
                    <td className="p-4 font-mono font-bold text-amber-300">
                      🪙 {(f.totalContribution || 0).toLocaleString()}
                    </td>
                    <td className="p-4">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                        f.status === 'suspended'
                          ? 'bg-rose-500/20 text-rose-300'
                          : f.status === 'inactive'
                          ? 'bg-slate-500/20 text-slate-300'
                          : 'bg-emerald-500/20 text-emerald-300'
                      }`}>
                        {f.status || 'active'}
                      </span>
                    </td>
                    <td className="p-4 text-right">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedFamilyForDetails(f);
                        }}
                        className="px-3 py-1.5 bg-white/10 hover:bg-amber-400 hover:text-black text-white font-bold text-xs rounded-xl transition"
                      >
                        Manage
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 5. CREATE FAMILY MODAL */}
      <CreateFamilyModal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        onSuccess={handleFamilyCreated}
        showNotification={showNotification}
      />

      {/* 6. FAMILY DETAILS & MANAGEMENT MODAL */}
      <FamilyDetailsModal
        family={selectedFamilyForDetails}
        isOpen={!!selectedFamilyForDetails}
        onClose={() => setSelectedFamilyForDetails(null)}
        onUpdated={handleFamilyUpdated}
        onDeleted={handleFamilyDeleted}
        showNotification={showNotification}
      />
    </div>
  );
};
