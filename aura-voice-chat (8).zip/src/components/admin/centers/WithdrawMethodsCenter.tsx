/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  CreditCard, Plus, Edit3, Trash2, CheckCircle2, XCircle, 
  RefreshCw, Search, Filter, ArrowUpDown, ShieldAlert,
  Smartphone, Building2, Coins, Wallet, Globe, Check, AlertCircle,
  HelpCircle, Eye, EyeOff, Save, X, Layers, Clock, Sparkles
} from 'lucide-react';
import { WithdrawPaymentMethod, WithdrawPaymentMethodType } from '../../../types';
import { ApiClient } from '../../../lib/api';

interface WithdrawMethodsCenterProps {
  showNotification: (msg: string) => void;
}

export const WithdrawMethodsCenter: React.FC<WithdrawMethodsCenterProps> = ({ showNotification }) => {
  const [methods, setMethods] = useState<WithdrawPaymentMethod[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'inactive'>('all');

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingMethod, setEditingMethod] = useState<WithdrawPaymentMethod | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  // Form State
  const [formData, setFormData] = useState<Partial<WithdrawPaymentMethod>>({
    name: '',
    type: 'mobile_wallet',
    currency: 'USD',
    accountFieldLabel: '',
    placeholder: '',
    minWithdraw: 100,
    maxWithdraw: 50000,
    processingFee: 0,
    isActive: true,
    sortOrder: 1
  });

  const loadMethods = async () => {
    setLoading(true);
    try {
      const data = await ApiClient.getAdminWithdrawPaymentMethods();
      setMethods(data);
    } catch (err: any) {
      showNotification(err.message || 'Failed to load withdrawal payment methods');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadMethods();

    const handleUpdateEvent = (e: any) => {
      if (e.detail && Array.isArray(e.detail)) {
        setMethods(e.detail);
      } else {
        ApiClient.getAdminWithdrawPaymentMethods().then(res => setMethods(res)).catch(() => {});
      }
    };

    window.addEventListener('withdraw_methods_updated', handleUpdateEvent);
    return () => {
      window.removeEventListener('withdraw_methods_updated', handleUpdateEvent);
    };
  }, []);

  const openCreateModal = () => {
    setEditingMethod(null);
    setFormData({
      name: '',
      type: 'mobile_wallet',
      currency: 'USD',
      accountFieldLabel: 'Account Number',
      placeholder: 'Enter your account details',
      minWithdraw: 100,
      maxWithdraw: 50000,
      processingFee: 0,
      isActive: true,
      sortOrder: methods.length + 1
    });
    setIsModalOpen(true);
  };

  const openEditModal = (method: WithdrawPaymentMethod) => {
    setEditingMethod(method);
    setFormData({
      id: method.id,
      name: method.name,
      type: method.type,
      currency: method.currency,
      accountFieldLabel: method.accountFieldLabel,
      placeholder: method.placeholder || '',
      minWithdraw: method.minWithdraw || 100,
      maxWithdraw: method.maxWithdraw || 50000,
      processingFee: method.processingFee || 0,
      isActive: method.isActive !== false,
      sortOrder: method.sortOrder || 1
    });
    setIsModalOpen(true);
  };

  const handleSaveSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name?.trim()) {
      showNotification('Payment method name is required');
      return;
    }
    if (!formData.accountFieldLabel?.trim()) {
      showNotification('Required account field label is required');
      return;
    }

    setIsSaving(true);
    try {
      let updatedList: WithdrawPaymentMethod[];
      if (editingMethod) {
        updatedList = await ApiClient.updateWithdrawPaymentMethod(editingMethod.id, formData);
        showNotification(`✅ Successfully updated payment method "${formData.name}". User Withdraw screen updated instantly!`);
      } else {
        updatedList = await ApiClient.createWithdrawPaymentMethod(formData);
        showNotification(`✅ Created new payment method "${formData.name}". Available for user withdrawals immediately!`);
      }
      setMethods(updatedList);
      setIsModalOpen(false);
    } catch (err: any) {
      showNotification(err.message || 'Failed to save payment method');
    } finally {
      setIsSaving(false);
    }
  };

  const handleToggleStatus = async (method: WithdrawPaymentMethod) => {
    try {
      const nextStatus = !method.isActive;
      const updatedList = await ApiClient.toggleWithdrawPaymentMethodStatus(method.id, nextStatus);
      setMethods(updatedList);
      showNotification(`Payment method "${method.name}" is now ${nextStatus ? 'ACTIVE' : 'INACTIVE'}`);
    } catch (err: any) {
      showNotification(err.message || 'Failed to toggle status');
    }
  };

  const handleDelete = async (method: WithdrawPaymentMethod) => {
    if (!window.confirm(`Are you sure you want to delete payment method "${method.name}"? This action cannot be undone.`)) {
      return;
    }
    try {
      const updatedList = await ApiClient.deleteWithdrawPaymentMethod(method.id);
      setMethods(updatedList);
      showNotification(`✅ Deleted payment method "${method.name}"`);
    } catch (err: any) {
      showNotification(`⚠️ ${err.message || 'Failed to delete payment method'}`);
    }
  };

  const getTypeIcon = (type: WithdrawPaymentMethodType) => {
    switch (type) {
      case 'mobile_wallet':
        return <Smartphone className="w-4 h-4 text-emerald-400" />;
      case 'bank':
        return <Building2 className="w-4 h-4 text-blue-400" />;
      case 'crypto':
        return <Coins className="w-4 h-4 text-amber-400" />;
      case 'paypal':
        return <Wallet className="w-4 h-4 text-indigo-400" />;
      default:
        return <CreditCard className="w-4 h-4 text-purple-400" />;
    }
  };

  const getTypeLabel = (type: WithdrawPaymentMethodType) => {
    switch (type) {
      case 'mobile_wallet': return 'Mobile Wallet';
      case 'bank': return 'Bank Transfer';
      case 'crypto': return 'Cryptocurrency';
      case 'paypal': return 'PayPal';
      default: return 'Other Gateway';
    }
  };

  // Filtered Methods
  const filteredMethods = methods.filter(m => {
    const matchesSearch = 
      m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.currency.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.accountFieldLabel.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesType = filterType === 'all' || m.type === filterType;
    const matchesStatus = 
      filterStatus === 'all' || 
      (filterStatus === 'active' && m.isActive) || 
      (filterStatus === 'inactive' && !m.isActive);

    return matchesSearch && matchesType && matchesStatus;
  });

  const activeCount = methods.filter(m => m.isActive).length;
  const inactiveCount = methods.filter(m => !m.isActive).length;
  const uniqueCurrencies = Array.from(new Set(methods.map(m => m.currency))).length;

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* HEADER SECTION */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 shadow-xl">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-lg shadow-emerald-500/20 text-black">
            <CreditCard className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-black text-white tracking-wide">
                Withdraw Payment Methods
              </h2>
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold">
                Live Dynamic Sync
              </span>
            </div>
            <p className="text-xs text-slate-300">
              Configure and dynamically manage payout gateways, required account input fields, limits, and fees for user withdrawals.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={loadMethods}
            disabled={loading}
            className="p-2.5 rounded-2xl bg-white/10 hover:bg-white/20 text-slate-300 transition-all border border-white/10 hover:text-white"
            title="Refresh list"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
          <button
            onClick={openCreateModal}
            className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-black font-black text-xs shadow-lg shadow-emerald-500/20 transition-all flex items-center gap-2"
          >
            <Plus className="w-4 h-4" /> Add Payment Method
          </button>
        </div>
      </div>

      {/* METRICS SUMMARY CARDS */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
        <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 space-y-1 shadow-md">
          <span className="text-[10px] text-slate-300 font-bold block truncate">Total Methods</span>
          <p className="text-2xl font-black text-white">{methods.length}</p>
          <span className="text-[9px] text-slate-400">Configured in Database</span>
        </div>

        <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-emerald-500/30 space-y-1 shadow-md">
          <span className="text-[10px] text-emerald-300 font-bold block truncate">Active in User App</span>
          <p className="text-2xl font-black text-emerald-400">{activeCount}</p>
          <span className="text-[9px] text-emerald-300/80">Available for Payout</span>
        </div>

        <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-amber-500/30 space-y-1 shadow-md">
          <span className="text-[10px] text-amber-300 font-bold block truncate">Inactive / Suspended</span>
          <p className="text-2xl font-black text-amber-400">{inactiveCount}</p>
          <span className="text-[9px] text-amber-300/80">Hidden from Users</span>
        </div>

        <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-cyan-500/30 space-y-1 shadow-md">
          <span className="text-[10px] text-cyan-300 font-bold block truncate">Currencies Supported</span>
          <p className="text-2xl font-black text-cyan-400">{uniqueCurrencies}</p>
          <span className="text-[9px] text-cyan-300/80">BDT, USD, USDT, etc.</span>
        </div>
      </div>

      {/* SEARCH AND FILTERS BAR */}
      <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 flex flex-col md:flex-row items-center justify-between gap-3 shadow-md">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search method name, currency, or field..."
            className="w-full bg-black/40 text-white text-xs pl-9 pr-3.5 py-2 rounded-xl border border-white/10 focus:outline-none focus:border-emerald-400 font-medium placeholder:text-slate-500"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          {/* Filter by Type */}
          <div className="flex items-center gap-1.5 text-xs">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="bg-black/40 text-white text-xs px-3 py-2 rounded-xl border border-white/10 focus:outline-none focus:border-emerald-400 font-bold capitalize"
            >
              <option value="all">All Method Types</option>
              <option value="mobile_wallet">Mobile Wallet</option>
              <option value="bank">Bank Transfer</option>
              <option value="crypto">Cryptocurrency</option>
              <option value="paypal">PayPal</option>
              <option value="other">Other</option>
            </select>
          </div>

          {/* Filter by Status */}
          <div className="flex items-center gap-1 bg-black/40 p-1 rounded-xl border border-white/10">
            <button
              onClick={() => setFilterStatus('all')}
              className={`px-3 py-1 text-[11px] font-bold rounded-lg transition-all ${
                filterStatus === 'all' ? 'bg-emerald-500 text-black shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setFilterStatus('active')}
              className={`px-3 py-1 text-[11px] font-bold rounded-lg transition-all ${
                filterStatus === 'active' ? 'bg-emerald-500 text-black shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              Active
            </button>
            <button
              onClick={() => setFilterStatus('inactive')}
              className={`px-3 py-1 text-[11px] font-bold rounded-lg transition-all ${
                filterStatus === 'inactive' ? 'bg-emerald-500 text-black shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              Inactive
            </button>
          </div>
        </div>
      </div>

      {/* TABLE / LIST */}
      <div className="bg-white/5 backdrop-blur-xl rounded-3xl border border-white/10 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-black/40 text-slate-300 font-extrabold border-b border-white/10">
              <tr>
                <th className="p-3.5 w-16 text-center">Order</th>
                <th className="p-3.5">Method Name</th>
                <th className="p-3.5">Method Type</th>
                <th className="p-3.5">Currency</th>
                <th className="p-3.5">Dynamic Account Label</th>
                <th className="p-3.5">Limits & Fee</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5">Created / Updated</th>
                <th className="p-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/10">
              {loading && methods.length === 0 ? (
                <tr>
                  <td colSpan={9} className="p-8 text-center text-slate-400">
                    <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2 text-emerald-400" />
                    Loading withdrawal payment methods...
                  </td>
                </tr>
              ) : filteredMethods.length === 0 ? (
                <tr>
                  <td colSpan={9} className="p-8 text-center text-slate-400">
                    <AlertCircle className="w-6 h-6 mx-auto mb-2 text-amber-400" />
                    No withdrawal payment methods match your criteria.
                  </td>
                </tr>
              ) : (
                filteredMethods.map((method) => (
                  <tr key={method.id} className="hover:bg-white/5 transition-colors group">
                    {/* Sort Order */}
                    <td className="p-3.5 text-center">
                      <span className="px-2 py-0.5 rounded-lg bg-black/40 border border-white/10 font-mono font-bold text-slate-300 text-[11px]">
                        #{method.sortOrder}
                      </span>
                    </td>

                    {/* Method Name */}
                    <td className="p-3.5">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-xl bg-white/10 border border-white/10 flex items-center justify-center shrink-0">
                          {getTypeIcon(method.type)}
                        </div>
                        <div>
                          <p className="font-extrabold text-white text-sm">{method.name}</p>
                          <p className="text-[10px] text-slate-400 font-mono">ID: {method.id}</p>
                        </div>
                      </div>
                    </td>

                    {/* Method Type */}
                    <td className="p-3.5">
                      <span className="px-2.5 py-1 rounded-full bg-white/10 border border-white/10 text-[11px] font-bold text-slate-200 inline-flex items-center gap-1.5">
                        {getTypeIcon(method.type)}
                        {getTypeLabel(method.type)}
                      </span>
                    </td>

                    {/* Currency */}
                    <td className="p-3.5">
                      <span className="px-2.5 py-0.5 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-mono font-black text-xs">
                        {method.currency}
                      </span>
                    </td>

                    {/* Account Field Label & Placeholder */}
                    <td className="p-3.5">
                      <div className="space-y-0.5 max-w-[200px]">
                        <p className="font-bold text-slate-200 text-xs truncate">
                          {method.accountFieldLabel}
                        </p>
                        {method.placeholder && (
                          <p className="text-[10px] text-slate-400 italic truncate" title={method.placeholder}>
                            "{method.placeholder}"
                          </p>
                        )}
                      </div>
                    </td>

                    {/* Limits & Fee */}
                    <td className="p-3.5">
                      <div className="space-y-0.5 font-mono text-[11px]">
                        <p className="text-slate-300">
                          Min: <strong className="text-white">{method.minWithdraw?.toLocaleString() || 100}</strong> {method.currency}
                        </p>
                        <p className="text-slate-300">
                          Max: <strong className="text-white">{method.maxWithdraw?.toLocaleString() || '50,000'}</strong> {method.currency}
                        </p>
                        {method.processingFee !== undefined && method.processingFee > 0 ? (
                          <p className="text-amber-400 text-[10px]">
                            Fee: {method.processingFee}%
                          </p>
                        ) : (
                          <p className="text-emerald-400 text-[10px]">
                            Fee: Free (0%)
                          </p>
                        )}
                      </div>
                    </td>

                    {/* Status Toggle / Badge */}
                    <td className="p-3.5">
                      <button
                        onClick={() => handleToggleStatus(method)}
                        className={`px-2.5 py-1 rounded-full text-[10px] font-black border transition-all flex items-center gap-1.5 ${
                          method.isActive
                            ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/30'
                            : 'bg-red-500/20 text-red-300 border-red-500/40 hover:bg-red-500/30'
                        }`}
                        title="Click to toggle status"
                      >
                        {method.isActive ? (
                          <>
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                            ACTIVE
                          </>
                        ) : (
                          <>
                            <span className="w-1.5 h-1.5 rounded-full bg-red-400" />
                            INACTIVE
                          </>
                        )}
                      </button>
                    </td>

                    {/* Dates */}
                    <td className="p-3.5">
                      <div className="text-[10px] text-slate-400 font-mono space-y-0.5">
                        <p title={`Created: ${method.createdAt}`}>
                          Created: {new Date(method.createdAt).toLocaleDateString()}
                        </p>
                        <p title={`Updated: ${method.updatedAt}`}>
                          Updated: {new Date(method.updatedAt).toLocaleDateString()}
                        </p>
                      </div>
                    </td>

                    {/* Actions */}
                    <td className="p-3.5 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => openEditModal(method)}
                          className="p-1.5 rounded-xl bg-white/10 hover:bg-amber-400/20 text-slate-300 hover:text-amber-300 border border-white/10 transition-all"
                          title="Edit Payment Method"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDelete(method)}
                          className="p-1.5 rounded-xl bg-white/10 hover:bg-red-500/20 text-slate-300 hover:text-red-400 border border-white/10 transition-all"
                          title="Delete Payment Method"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ADD / EDIT PAYMENT METHOD MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <form 
            onSubmit={handleSaveSubmit}
            className="bg-[#1a0b2e]/95 backdrop-blur-2xl border border-emerald-500/40 rounded-3xl p-6 w-full max-w-xl space-y-4 shadow-2xl my-8 animate-fadeIn"
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center">
                  <CreditCard className="w-5 h-5 text-emerald-300" />
                </div>
                <div>
                  <h3 className="font-black text-white text-base">
                    {editingMethod ? 'Edit Withdraw Payment Method' : 'Add New Withdraw Payment Method'}
                  </h3>
                  <p className="text-[10px] text-emerald-300 font-mono">
                    {editingMethod ? `ID: ${editingMethod.id}` : 'Instantly available to user withdrawal forms'}
                  </p>
                </div>
              </div>
              <button 
                type="button" 
                onClick={() => setIsModalOpen(false)} 
                className="text-slate-400 hover:text-white font-bold text-lg p-1"
              >
                ✕
              </button>
            </div>

            {/* Main Form Fields */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {/* Payment Method Name */}
              <div className="col-span-1 md:col-span-2">
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  Payment Method Name <span className="text-emerald-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formData.name || ''}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g. bKash, Nagad, Binance USDT, PayPal, Chase Bank"
                  className="w-full bg-black/40 text-white text-xs px-3.5 py-2.5 rounded-xl border border-white/10 font-bold focus:outline-none focus:border-emerald-400"
                />
              </div>

              {/* Method Type */}
              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  Method Type <span className="text-emerald-400">*</span>
                </label>
                <select
                  value={formData.type || 'mobile_wallet'}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value as any })}
                  className="w-full bg-black/40 text-white text-xs px-3.5 py-2.5 rounded-xl border border-white/10 font-bold focus:outline-none focus:border-emerald-400 capitalize"
                >
                  <option value="mobile_wallet" className="bg-[#1a0b2e]">Mobile Wallet (bKash, Nagad, Rocket)</option>
                  <option value="bank" className="bg-[#1a0b2e]">Bank Transfer / Wire</option>
                  <option value="crypto" className="bg-[#1a0b2e]">Cryptocurrency (USDT TRC20/BEP20)</option>
                  <option value="paypal" className="bg-[#1a0b2e]">PayPal Global</option>
                  <option value="other" className="bg-[#1a0b2e]">Other Custom Gateway</option>
                </select>
              </div>

              {/* Currency */}
              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  Currency <span className="text-emerald-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formData.currency || 'USD'}
                  onChange={(e) => setFormData({ ...formData, currency: e.target.value.toUpperCase() })}
                  placeholder="e.g. BDT, USD, USDT, EUR, SAR, INR"
                  className="w-full bg-black/40 text-white text-xs px-3.5 py-2.5 rounded-xl border border-white/10 font-mono font-bold uppercase focus:outline-none focus:border-emerald-400"
                />
              </div>

              {/* Dynamic Account Field Label */}
              <div className="col-span-1 md:col-span-2">
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  Required Account Field Label <span className="text-emerald-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formData.accountFieldLabel || ''}
                  onChange={(e) => setFormData({ ...formData, accountFieldLabel: e.target.value })}
                  placeholder="e.g. bKash Number, PayPal Email, USDT Wallet Address, Account Number"
                  className="w-full bg-black/40 text-white text-xs px-3.5 py-2.5 rounded-xl border border-white/10 font-bold focus:outline-none focus:border-emerald-400"
                />
                <p className="text-[10px] text-slate-400 mt-1">
                  This label will dynamically display above the input box on the user's Withdraw screen.
                </p>
              </div>

              {/* Placeholder */}
              <div className="col-span-1 md:col-span-2">
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  Account Field Placeholder
                </label>
                <input
                  type="text"
                  value={formData.placeholder || ''}
                  onChange={(e) => setFormData({ ...formData, placeholder: e.target.value })}
                  placeholder="e.g. Enter your personal 11-digit bKash number"
                  className="w-full bg-black/40 text-white text-xs px-3.5 py-2.5 rounded-xl border border-white/10 focus:outline-none focus:border-emerald-400"
                />
              </div>

              {/* Minimum Withdrawal Amount */}
              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  Minimum Withdrawal
                </label>
                <input
                  type="number"
                  min="1"
                  value={formData.minWithdraw || 100}
                  onChange={(e) => setFormData({ ...formData, minWithdraw: Number(e.target.value) })}
                  className="w-full bg-black/40 text-white text-xs px-3.5 py-2.5 rounded-xl border border-white/10 font-mono font-bold focus:outline-none focus:border-emerald-400"
                />
              </div>

              {/* Maximum Withdrawal Amount */}
              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  Maximum Withdrawal
                </label>
                <input
                  type="number"
                  min="1"
                  value={formData.maxWithdraw || 50000}
                  onChange={(e) => setFormData({ ...formData, maxWithdraw: Number(e.target.value) })}
                  className="w-full bg-black/40 text-white text-xs px-3.5 py-2.5 rounded-xl border border-white/10 font-mono font-bold focus:outline-none focus:border-emerald-400"
                />
              </div>

              {/* Processing Fee */}
              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  Processing Fee (%)
                </label>
                <input
                  type="number"
                  step="0.1"
                  min="0"
                  max="50"
                  value={formData.processingFee || 0}
                  onChange={(e) => setFormData({ ...formData, processingFee: Number(e.target.value) })}
                  className="w-full bg-black/40 text-white text-xs px-3.5 py-2.5 rounded-xl border border-white/10 font-mono font-bold focus:outline-none focus:border-emerald-400"
                />
              </div>

              {/* Sort Order */}
              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  Display Sort Order
                </label>
                <input
                  type="number"
                  min="1"
                  value={formData.sortOrder || 1}
                  onChange={(e) => setFormData({ ...formData, sortOrder: Number(e.target.value) })}
                  className="w-full bg-black/40 text-white text-xs px-3.5 py-2.5 rounded-xl border border-white/10 font-mono font-bold focus:outline-none focus:border-emerald-400"
                />
              </div>

              {/* Status Switch */}
              <div className="col-span-1 md:col-span-2 pt-1 flex items-center justify-between p-3 rounded-2xl bg-black/40 border border-white/10">
                <div>
                  <p className="text-xs font-bold text-white">Payment Method Status</p>
                  <p className="text-[10px] text-slate-400">
                    {formData.isActive ? 'Active and visible on the user withdrawal page' : 'Inactive / hidden from users'}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, isActive: !formData.isActive })}
                  className={`px-4 py-2 rounded-xl text-xs font-black border transition-all ${
                    formData.isActive 
                      ? 'bg-emerald-500 text-black border-emerald-400 shadow-lg shadow-emerald-500/20' 
                      : 'bg-white/10 text-slate-400 border-white/10'
                  }`}
                >
                  {formData.isActive ? 'ACTIVE' : 'INACTIVE'}
                </button>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="flex gap-2 pt-3 border-t border-white/10">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="flex-1 py-2.5 bg-white/10 text-slate-300 rounded-xl font-bold text-xs border border-white/10 hover:bg-white/20 transition-all"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSaving}
                className="flex-1 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-500 text-black font-black text-xs rounded-xl shadow-lg hover:from-emerald-400 hover:to-teal-400 transition-all disabled:opacity-50 flex items-center justify-center gap-1.5"
              >
                {isSaving ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Saving...
                  </>
                ) : (
                  <>
                    <Check className="w-3.5 h-3.5" /> Save Payment Method
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
