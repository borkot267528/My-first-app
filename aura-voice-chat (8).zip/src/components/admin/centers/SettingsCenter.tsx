import React, { useState } from 'react';
import { Settings, Save, Shield, Key, CreditCard, Bell, Cpu, RefreshCw, CheckCircle2, Palette } from 'lucide-react';

interface SettingsCenterProps {
  showNotification: (msg: string) => void;
  onNavigateToAppearance?: () => void;
}

export const SettingsCenter: React.FC<SettingsCenterProps> = ({ showNotification, onNavigateToAppearance }) => {
  const [activeTab, setActiveTab] = useState<'payments' | 'firebase' | 'agora' | 'referral' | 'maintenance' | 'app'>('payments');

  const [settings, setSettings] = useState({
    stripeEnabled: true,
    stripeLiveKey: 'pk_live_************************',
    firebaseProjectId: 'aura-voice-production',
    agoraAppId: 'a1b2c3d4e5f6g7h8i9j0',
    maintenanceMode: false,
    referralBonusCoins: 500,
    minWithdrawalAmount: 20
  });

  const handleSave = () => {
    showNotification('✅ System configuration settings saved successfully.');
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* HEADER BAR */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
        <div>
          <h3 className="text-base font-black text-white flex items-center gap-2">
            <Settings className="w-5 h-5 text-amber-400" /> Platform Infrastructure & App Settings Center
          </h3>
          <p className="text-xs text-slate-300">Payment Gateways, Firebase Config, Agora Realtime Audio, Maintenance Mode & API Keys</p>
        </div>
        <button onClick={handleSave} className="px-4 py-1.5 bg-amber-400 text-black font-black text-xs rounded-xl shadow flex items-center gap-1.5">
          <Save className="w-3.5 h-3.5" /> Save Configuration
        </button>
      </div>

      {/* TABS */}
      <div className="flex flex-wrap gap-2 border-b border-white/10 pb-2 text-xs">
        {[
          { id: 'payments', label: 'Stripe & Payments' },
          { id: 'firebase', label: 'Firebase Cloud' },
          { id: 'agora', label: 'Agora Voice RTC' },
          { id: 'referral', label: 'Referral & Bonus' },
          { id: 'maintenance', label: 'Maintenance Mode' },
          { id: 'app', label: 'General App Config' }
        ].map(t => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id as any)}
            className={`px-3.5 py-1.5 rounded-xl font-bold transition-all ${
              activeTab === t.id ? 'bg-amber-400 text-black font-black shadow-md' : 'bg-white/5 text-slate-300 hover:bg-white/10'
            }`}
          >
            {t.label}
          </button>
        ))}
        {onNavigateToAppearance && (
          <button
            type="button"
            onClick={onNavigateToAppearance}
            className="px-3.5 py-1.5 rounded-xl font-bold bg-purple-500/20 text-purple-300 hover:bg-purple-500/30 border border-purple-500/30 transition-all flex items-center gap-1.5"
          >
            <Palette className="w-3.5 h-3.5" /> Appearance Settings →
          </button>
        )}
      </div>

      <div className="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-4 max-w-2xl">
        {activeTab === 'payments' && (
          <div className="space-y-3 text-xs">
            <h4 className="font-extrabold text-white text-sm">Stripe Payment Gateway Credentials</h4>
            <div>
              <label className="block text-slate-300 font-bold mb-1">Stripe Publishable Key</label>
              <input
                type="text"
                value={settings.stripeLiveKey}
                onChange={(e) => setSettings({ ...settings, stripeLiveKey: e.target.value })}
                className="w-full bg-black/40 text-white font-mono px-3.5 py-2.5 rounded-xl border border-white/10 focus:outline-none focus:border-amber-400"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-bold mb-1">Minimum Withdrawal Limit ($ USD)</label>
              <input
                type="number"
                value={settings.minWithdrawalAmount}
                onChange={(e) => setSettings({ ...settings, minWithdrawalAmount: Number(e.target.value) })}
                className="w-full bg-black/40 text-white font-mono px-3.5 py-2.5 rounded-xl border border-white/10 focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>
        )}

        {activeTab === 'firebase' && (
          <div className="space-y-3 text-xs">
            <h4 className="font-extrabold text-white text-sm">Firebase Cloud Project</h4>
            <div>
              <label className="block text-slate-300 font-bold mb-1">Firebase Project ID</label>
              <input
                type="text"
                value={settings.firebaseProjectId}
                onChange={(e) => setSettings({ ...settings, firebaseProjectId: e.target.value })}
                className="w-full bg-black/40 text-white font-mono px-3.5 py-2.5 rounded-xl border border-white/10"
              />
            </div>
          </div>
        )}

        {activeTab === 'agora' && (
          <div className="space-y-3 text-xs">
            <h4 className="font-extrabold text-white text-sm">Agora RTC Voice Engine</h4>
            <div>
              <label className="block text-slate-300 font-bold mb-1">Agora App ID</label>
              <input
                type="text"
                value={settings.agoraAppId}
                onChange={(e) => setSettings({ ...settings, agoraAppId: e.target.value })}
                className="w-full bg-black/40 text-white font-mono px-3.5 py-2.5 rounded-xl border border-white/10"
              />
            </div>
          </div>
        )}

        {activeTab === 'maintenance' && (
          <div className="space-y-3 text-xs">
            <h4 className="font-extrabold text-white text-sm">System Maintenance Mode</h4>
            <div className="flex items-center gap-3 p-4 rounded-xl bg-black/40 border border-white/10">
              <input
                type="checkbox"
                checked={settings.maintenanceMode}
                onChange={(e) => setSettings({ ...settings, maintenanceMode: e.target.checked })}
                className="w-4 h-4 accent-amber-400 cursor-pointer"
              />
              <div>
                <p className="font-bold text-white">Enable Maintenance Overlay</p>
                <p className="text-slate-400 text-[11px]">Blocks regular user access while staff conduct system upgrades.</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
