import React, { useState, useEffect } from 'react';
import { 
  Wallet, DollarSign, ArrowUpRight, ArrowDownRight, RefreshCw, 
  Search, CheckCircle2, XCircle, Clock, ShieldAlert, FileSpreadsheet,
  FileText, Sparkles, Filter, CreditCard, ChevronRight, User, AlertCircle,
  Gift, Plus, Trash2, Edit3, Check, Zap, Layers, Tag, Save
} from 'lucide-react';
import { WalletTransaction, RechargePackage } from '../../../types';
import { ApiClient } from '../../../lib/api';
import { exportToExcel, exportToPDF } from '../../../lib/exportUtils';

interface WalletCenterProps {
  showNotification: (msg: string) => void;
}

export const WalletCenter: React.FC<WalletCenterProps> = ({ showNotification }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'packages' | 'adjust' | 'withdrawals' | 'transactions'>('overview');
  const [loading, setLoading] = useState(false);
  const [summary, setSummary] = useState<any>({
    totalCoinsCirculation: 0,
    totalDiamondsCirculation: 0,
    pendingWithdrawalsCount: 0,
    totalPendingWithdrawalAmount: 0,
    todayRechargeVolume: 0,
    activeUsersCount: 0
  });

  const [transactions, setTransactions] = useState<WalletTransaction[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [filterCurrency, setFilterCurrency] = useState<string>('all');

  // Wallet Packages State
  const [packages, setPackages] = useState<RechargePackage[]>([]);
  const [packageFilter, setPackageFilter] = useState<'all' | 'coin' | 'diamond'>('all');
  const [packageSearchQuery, setPackageSearchQuery] = useState('');
  const [editingPackage, setEditingPackage] = useState<RechargePackage | null>(null);
  const [packageFormData, setPackageFormData] = useState<Partial<RechargePackage>>({
    name: '',
    currencyType: 'coin',
    coins: 1000,
    bonusCoins: 100,
    diamonds: 500,
    priceUsd: 9.99,
    badge: '',
    popular: false,
    bestValue: false,
    isActive: true
  });
  const [isSavingPackage, setIsSavingPackage] = useState(false);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // Manual Adjustment Form State
  const [targetUid, setTargetUid] = useState('');
  const [currency, setCurrency] = useState<'coin' | 'diamond'>('coin');
  const [adjustAction, setAdjustAction] = useState<'add' | 'deduct'>('add');
  const [adjustAmount, setAdjustAmount] = useState('');
  const [adjustReason, setAdjustReason] = useState('');
  const [adjusting, setAdjusting] = useState(false);

  // Moderate Withdrawal Modal / State
  const [selectedWithdrawal, setSelectedWithdrawal] = useState<WalletTransaction | null>(null);
  const [moderateReason, setModerateReason] = useState('');
  const [moderating, setModerating] = useState(false);

  const loadData = async () => {
    setLoading(true);
    try {
      const [sum, txs, pkgs] = await Promise.all([
        ApiClient.getWalletSummary(),
        ApiClient.getWalletTransactions(),
        ApiClient.getRechargePackages().catch(() => [])
      ]);
      setSummary(sum);
      setTransactions(txs);
      if (Array.isArray(pkgs)) {
        setPackages(pkgs);
      }
    } catch (err: any) {
      showNotification(err.message || 'Failed to load wallet data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();

    const handlePackagesUpdated = (e: any) => {
      if (e.detail && Array.isArray(e.detail)) {
        setPackages(e.detail);
      } else {
        ApiClient.getRechargePackages().then(res => setPackages(res)).catch(() => {});
      }
    };

    window.addEventListener('wallet_packages_updated', handlePackagesUpdated);
    return () => {
      window.removeEventListener('wallet_packages_updated', handlePackagesUpdated);
    };
  }, []);

  const openEditPackageModal = (pkg: RechargePackage) => {
    setEditingPackage(pkg);
    setPackageFormData({
      id: pkg.id,
      name: pkg.name,
      currencyType: pkg.currencyType || (pkg.diamonds && pkg.diamonds > 0 ? 'diamond' : 'coin'),
      coins: pkg.coins || 0,
      bonusCoins: pkg.bonusCoins || 0,
      diamonds: pkg.diamonds || 0,
      priceUsd: pkg.priceUsd,
      badge: pkg.badge || '',
      popular: !!pkg.popular,
      bestValue: !!pkg.bestValue,
      isActive: pkg.isActive !== false
    });
  };

  const handleSavePackageSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!packageFormData.name?.trim()) {
      showNotification('Please provide a package name');
      return;
    }
    const price = Number(packageFormData.priceUsd);
    if (isNaN(price) || price <= 0) {
      showNotification('Please provide a valid positive price (USD)');
      return;
    }

    setIsSavingPackage(true);
    try {
      let updatedList: RechargePackage[];
      if (editingPackage) {
        // Update existing package
        updatedList = await ApiClient.updateRechargePackage(editingPackage.id, packageFormData);
        showNotification(`✅ Successfully updated package "${packageFormData.name}"! User Wallet reflects changes immediately.`);
        setEditingPackage(null);
      } else {
        // Create new package
        updatedList = await ApiClient.createRechargePackage(packageFormData);
        showNotification(`✅ Created new package "${packageFormData.name}"! User Wallet updated instantly.`);
        setIsAddModalOpen(false);
      }
      setPackages(updatedList);
    } catch (err: any) {
      showNotification(err.message || 'Failed to save package');
    } finally {
      setIsSavingPackage(false);
    }
  };

  const handleDeletePackage = async (pkg: RechargePackage) => {
    if (!window.confirm(`Are you sure you want to delete package "${pkg.name}" ($${pkg.priceUsd})?`)) {
      return;
    }
    try {
      const updatedList = await ApiClient.deleteRechargePackage(pkg.id);
      setPackages(updatedList);
      showNotification(`🗑️ Deleted package "${pkg.name}". Changes propagated live.`);
    } catch (err: any) {
      showNotification(err.message || 'Failed to delete package');
    }
  };

  const handleTogglePackageStatus = async (pkg: RechargePackage) => {
    try {
      const updatedList = await ApiClient.updateRechargePackage(pkg.id, {
        isActive: !pkg.isActive
      });
      setPackages(updatedList);
      showNotification(`Status updated for "${pkg.name}" (${!pkg.isActive ? 'Active' : 'Disabled'})`);
    } catch (err: any) {
      showNotification(err.message || 'Failed to toggle status');
    }
  };

  const handleAdjustSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetUid.trim() || !adjustAmount || Number(adjustAmount) <= 0) {
      showNotification('Please enter a valid User UID and positive amount');
      return;
    }

    setAdjusting(true);
    try {
      const res = await ApiClient.adjustUserWallet({
        targetUid: targetUid.trim(),
        currency,
        amount: Number(adjustAmount),
        action: adjustAction,
        reason: adjustReason.trim() || 'Admin manual balance adjustment'
      });
      showNotification(`Successfully ${adjustAction === 'add' ? 'added' : 'deducted'} ${adjustAmount} ${currency}s for UID ${targetUid}`);
      setTargetUid('');
      setAdjustAmount('');
      setAdjustReason('');
      loadData();
    } catch (err: any) {
      showNotification(err.message || 'Failed to adjust balance');
    } finally {
      setAdjusting(false);
    }
  };

  const handleModerateWithdrawal = async (action: 'completed' | 'rejected') => {
    if (!selectedWithdrawal) return;
    setModerating(true);
    try {
      await ApiClient.moderateWithdrawal(selectedWithdrawal.id, action, moderateReason.trim());
      showNotification(`Withdrawal request ${action === 'completed' ? 'approved' : 'rejected'}`);
      setSelectedWithdrawal(null);
      setModerateReason('');
      loadData();
    } catch (err: any) {
      showNotification(err.message || 'Failed to process withdrawal');
    } finally {
      setModerating(false);
    }
  };

  const pendingWithdrawals = transactions.filter(t => t.type === 'withdraw' && t.status === 'pending');

  const filteredTransactions = transactions.filter(t => {
    const matchesSearch = searchQuery === '' || 
      t.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.userId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = filterType === 'all' || t.type === filterType;
    const matchesCurrency = filterCurrency === 'all' || t.currency === filterCurrency;
    return matchesSearch && matchesType && matchesCurrency;
  });

  const filteredPackages = packages.filter(pkg => {
    const isCoin = pkg.currencyType === 'coin' || (!pkg.currencyType && pkg.coins > 0);
    const isDia = pkg.currencyType === 'diamond' || (!pkg.currencyType && (pkg.diamonds || 0) > 0);
    
    if (packageFilter === 'coin' && !isCoin) return false;
    if (packageFilter === 'diamond' && !isDia) return false;

    if (packageSearchQuery.trim()) {
      const q = packageSearchQuery.toLowerCase();
      const matchName = pkg.name.toLowerCase().includes(q);
      const matchBadge = pkg.badge?.toLowerCase().includes(q);
      const matchPrice = pkg.priceUsd.toString().includes(q);
      const matchAmount = pkg.coins?.toString().includes(q) || pkg.diamonds?.toString().includes(q);
      return matchName || matchBadge || matchPrice || matchAmount;
    }
    return true;
  });

  const handleExportExcel = () => {
    exportToExcel('Wallet_Transactions_Export', filteredTransactions.map(t => ({
      ID: t.id,
      UserID: t.userId,
      Type: t.type,
      Currency: t.currency,
      Amount: t.amount,
      BalanceAfter: t.balanceAfter,
      Status: t.status,
      Description: t.description,
      Timestamp: t.timestamp || t.createdAt
    })));
  };

  const handleExportPDF = () => {
    const headers = ['TX ID', 'User ID', 'Type', 'Currency', 'Amount', 'Status', 'Date'];
    const rows = filteredTransactions.map(t => [
      t.id,
      t.userId,
      t.type,
      t.currency.toUpperCase(),
      t.amount.toLocaleString(),
      t.status.toUpperCase(),
      new Date(t.timestamp || t.createdAt || '').toLocaleDateString()
    ]);
    exportToPDF('Wallet Transactions Audit Report', headers, rows);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* HEADER */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
        <div>
          <h3 className="text-base font-black text-white flex items-center gap-2">
            <Wallet className="w-5 h-5 text-amber-400" /> Platform Wallet & Vault Operations
          </h3>
          <p className="text-xs text-slate-300">
            Real-time coin & diamond circulation, dynamic package pricing, balance manual overrides, and cashouts
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={loadData}
            disabled={loading}
            className="p-2 bg-white/10 hover:bg-white/20 text-white rounded-xl transition-all"
            title="Refresh Data"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
          <button 
            onClick={handleExportExcel}
            className="px-3 py-1.5 bg-emerald-600/80 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition-all"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" /> Excel
          </button>
          <button 
            onClick={handleExportPDF}
            className="px-3 py-1.5 bg-rose-600/80 hover:bg-rose-600 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition-all"
          >
            <FileText className="w-3.5 h-3.5" /> PDF
          </button>
        </div>
      </div>

      {/* METRIC CARDS */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-1">
          <span className="text-[10px] text-amber-300 font-bold uppercase tracking-wider">Total Coins Circulation</span>
          <p className="text-xl font-black text-amber-400 font-mono">
            🪙 {(summary.totalCoinsCirculation || 0).toLocaleString()}
          </p>
          <span className="text-[10px] text-slate-400">Available across user balances</span>
        </div>

        <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-1">
          <span className="text-[10px] text-cyan-300 font-bold uppercase tracking-wider">Total Diamonds Pool</span>
          <p className="text-xl font-black text-cyan-400 font-mono">
            💎 {(summary.totalDiamondsCirculation || 0).toLocaleString()}
          </p>
          <span className="text-[10px] text-slate-400">Host and agency earnings</span>
        </div>

        <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-1">
          <span className="text-[10px] text-rose-300 font-bold uppercase tracking-wider">Pending Withdrawals</span>
          <p className="text-xl font-black text-rose-400 font-mono">
            {summary.pendingWithdrawalsCount || 0} requests
          </p>
          <span className="text-[10px] text-rose-300/80">
            💎 {(summary.totalPendingWithdrawalAmount || 0).toLocaleString()} awaiting approval
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-1">
          <span className="text-[10px] text-emerald-300 font-bold uppercase tracking-wider">Today's Recharge Vol.</span>
          <p className="text-xl font-black text-emerald-400 font-mono">
            🪙 {(summary.todayRechargeVolume || 0).toLocaleString()}
          </p>
          <span className="text-[10px] text-slate-400">24-hour liquidity inflow</span>
        </div>
      </div>

      {/* NAVIGATION TABS */}
      <div className="flex flex-wrap gap-2 border-b border-white/10 pb-2">
        {[
          { id: 'overview', label: 'Vault Overview', icon: Wallet },
          { id: 'packages', label: `Wallet Packages (${packages.length})`, icon: Gift },
          { id: 'adjust', label: 'Manual Balance Adjust', icon: Sparkles },
          { id: 'withdrawals', label: `Withdrawal Queue (${pendingWithdrawals.length})`, icon: Clock },
          { id: 'transactions', label: 'All Transactions Ledger', icon: FileText }
        ].map(t => {
          const Icon = t.icon;
          return (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id as any)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeTab === t.id 
                  ? 'bg-amber-500 text-black font-black shadow-lg shadow-amber-500/20' 
                  : 'bg-white/5 text-slate-300 hover:bg-white/10'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              {t.label}
            </button>
          );
        })}
      </div>

      {/* TAB 1: OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-4">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-400" /> Platform Financial Security Policy
            </h4>
            <div className="space-y-2 text-xs text-slate-300 leading-relaxed">
              <p>• Coins are standard platform credits purchased via Payment Merchants or Authorized Recharge Agents.</p>
              <p>• Diamonds represent host gifts received and can be converted into cash withdrawals or exchanged for coins.</p>
              <p>• All manual balance adjustments trigger an immutable entry in the administrative audit log.</p>
              <p>• <strong>Instant Wallet Updates:</strong> Edits to Coin/Diamond packages instantly sync with the production database and propagate to active User Wallet pages with zero server restart or APK update required.</p>
              <p>• Withdrawal requests above $500 USD require two-factor review before final processing.</p>
            </div>
            <div className="pt-2 flex flex-wrap gap-3">
              <button 
                onClick={() => setActiveTab('packages')}
                className="px-4 py-2 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-black font-black text-xs rounded-xl transition-all shadow"
              >
                Manage Wallet Packages
              </button>
              <button 
                onClick={() => setActiveTab('adjust')}
                className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white font-bold text-xs rounded-xl transition-all"
              >
                Perform Balance Adjustment
              </button>
              <button 
                onClick={() => setActiveTab('withdrawals')}
                className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white font-bold text-xs rounded-xl transition-all"
              >
                Review Pending Withdrawals
              </button>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-4">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <Clock className="w-4 h-4 text-cyan-400" /> Recent High-Value Transactions
            </h4>
            <div className="space-y-2">
              {transactions.slice(0, 4).map(tx => (
                <div key={tx.id} className="p-3 rounded-xl bg-black/20 border border-white/5 flex items-center justify-between">
                  <div className="space-y-0.5">
                    <span className="text-xs font-bold text-white flex items-center gap-1.5">
                      {tx.currency === 'coin' ? '🪙' : '💎'} {Math.abs(tx.amount).toLocaleString()} {tx.currency}
                      <span className={`text-[10px] px-1.5 py-0.5 rounded font-mono ${
                        tx.status === 'completed' ? 'bg-emerald-500/20 text-emerald-300' :
                        tx.status === 'pending' ? 'bg-amber-500/20 text-amber-300' : 'bg-rose-500/20 text-rose-300'
                      }`}>
                        {tx.status}
                      </span>
                    </span>
                    <p className="text-[11px] text-slate-400 truncate max-w-xs">{tx.description}</p>
                  </div>
                  <span className="text-[10px] text-slate-500 font-mono">
                    {new Date(tx.timestamp || tx.createdAt || '').toLocaleTimeString()}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB: WALLET PACKAGES CONFIGURATION (CRITICAL INSTANT UPDATE SUITE) */}
      {activeTab === 'packages' && (
        <div className="space-y-6 animate-fadeIn">
          {/* Instant Sync Banner */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-950/40 via-purple-950/40 to-slate-900 border border-amber-400/30 flex flex-wrap items-center justify-between gap-3 shadow-lg">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-black uppercase border border-emerald-500/30">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" /> Instant Production Sync Active
                </span>
                <h4 className="text-sm font-black text-white">Live Wallet Package Registry</h4>
              </div>
              <p className="text-xs text-slate-300">
                Modifying Coin or Diamond package amounts & prices instantly updates the database, invalidates API caches, and refreshes open user wallets in real-time.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  setEditingPackage(null);
                  setPackageFormData({
                    name: 'New Coin Package',
                    currencyType: 'coin',
                    coins: 2000,
                    bonusCoins: 200,
                    diamonds: 0,
                    priceUsd: 14.99,
                    badge: 'HOT',
                    popular: false,
                    bestValue: false,
                    isActive: true
                  });
                  setIsAddModalOpen(true);
                }}
                className="px-3.5 py-2 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-black font-black text-xs rounded-xl flex items-center gap-1.5 transition-all shadow"
              >
                <Plus className="w-4 h-4" /> Add Coin Package
              </button>
              <button
                onClick={() => {
                  setEditingPackage(null);
                  setPackageFormData({
                    name: 'New Diamond Package',
                    currencyType: 'diamond',
                    coins: 0,
                    bonusCoins: 0,
                    diamonds: 1000,
                    priceUsd: 19.99,
                    badge: 'POPULAR',
                    popular: true,
                    bestValue: false,
                    isActive: true
                  });
                  setIsAddModalOpen(true);
                }}
                className="px-3.5 py-2 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-400 hover:to-blue-400 text-black font-black text-xs rounded-xl flex items-center gap-1.5 transition-all shadow"
              >
                <Plus className="w-4 h-4" /> Add Diamond Package
              </button>
            </div>
          </div>

          {/* Filters & Search */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-1 bg-black/40 p-1 rounded-xl border border-white/10">
              {[
                { id: 'all', label: `All Packages (${packages.length})` },
                { id: 'coin', label: `🪙 Coin Packages (${packages.filter(p => p.currencyType === 'coin' || (!p.currencyType && p.coins > 0)).length})` },
                { id: 'diamond', label: `💎 Diamond Packages (${packages.filter(p => p.currencyType === 'diamond' || (!p.currencyType && (p.diamonds || 0) > 0)).length})` }
              ].map(f => (
                <button
                  key={f.id}
                  onClick={() => setPackageFilter(f.id as any)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                    packageFilter === f.id ? 'bg-amber-500 text-black font-black' : 'text-slate-300 hover:text-white'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>

            <div className="relative min-w-[240px]">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search packages by name, coins, price..."
                value={packageSearchQuery}
                onChange={e => setPackageSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-black/40 border border-white/10 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>

          {/* Package Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredPackages.map(pkg => {
              const isDiamond = pkg.currencyType === 'diamond' || (!pkg.currencyType && (pkg.diamonds || 0) > 0);
              return (
                <div 
                  key={pkg.id} 
                  className={`relative p-5 rounded-2xl border transition-all space-y-4 ${
                    isDiamond 
                      ? 'bg-gradient-to-br from-cyan-950/30 to-black/60 border-cyan-500/30 hover:border-cyan-400' 
                      : 'bg-gradient-to-br from-amber-950/30 to-black/60 border-amber-500/30 hover:border-amber-400'
                  } ${!pkg.isActive ? 'opacity-50 grayscale' : ''}`}
                >
                  {/* Top Badges */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                        isDiamond ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      }`}>
                        {isDiamond ? '💎 Diamond' : '🪙 Coin'}
                      </span>
                      {pkg.badge && (
                        <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase bg-purple-500/20 text-purple-300 border border-purple-500/40">
                          {pkg.badge}
                        </span>
                      )}
                      {pkg.popular && (
                        <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase bg-amber-400 text-black">
                          Popular
                        </span>
                      )}
                      {pkg.bestValue && (
                        <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase bg-gradient-to-r from-red-500 to-pink-500 text-white">
                          Best Value
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] font-mono text-slate-400">{pkg.id}</span>
                  </div>

                  {/* Title & Amount */}
                  <div className="space-y-1">
                    <h4 className="text-sm font-black text-white truncate">{pkg.name}</h4>
                    <div className="flex items-baseline justify-between">
                      <div className="text-2xl font-black font-mono">
                        {isDiamond ? (
                          <span className="text-cyan-300">💎 {(pkg.diamonds || 0).toLocaleString()} <span className="text-xs font-normal text-slate-300">Diamonds</span></span>
                        ) : (
                          <span className="text-amber-300">🪙 {(pkg.coins || 0).toLocaleString()} <span className="text-xs font-normal text-slate-300">Coins</span></span>
                        )}
                      </div>
                      <div className="text-lg font-black text-emerald-400 font-mono">
                        ${pkg.priceUsd.toFixed(2)} <span className="text-[10px] text-slate-400">USD</span>
                      </div>
                    </div>
                    {!isDiamond && pkg.bonusCoins > 0 && (
                      <p className="text-xs text-emerald-300 font-bold bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20 inline-block">
                        +{pkg.bonusCoins.toLocaleString()} Free Bonus Coins
                      </p>
                    )}
                  </div>

                  {/* Status and Action Buttons */}
                  <div className="pt-2 border-t border-white/10 flex items-center justify-between gap-2">
                    <button
                      onClick={() => handleTogglePackageStatus(pkg)}
                      className={`text-[11px] font-bold px-2 py-1 rounded-lg transition-colors ${
                        pkg.isActive 
                          ? 'bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30' 
                          : 'bg-rose-500/20 text-rose-300 hover:bg-rose-500/30'
                      }`}
                    >
                      {pkg.isActive ? 'Active' : 'Disabled'}
                    </button>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => openEditPackageModal(pkg)}
                        className="px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white font-bold text-xs rounded-xl flex items-center gap-1 transition-all"
                      >
                        <Edit3 className="w-3.5 h-3.5 text-amber-400" /> Edit Package
                      </button>
                      <button
                        onClick={() => handleDeletePackage(pkg)}
                        className="p-1.5 bg-rose-500/20 hover:bg-rose-500/40 text-rose-300 rounded-xl transition-all"
                        title="Delete Package"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 2: MANUAL BALANCE ADJUST */}
      {activeTab === 'adjust' && (
        <div className="max-w-2xl mx-auto p-6 rounded-2xl bg-white/5 border border-white/10 space-y-6">
          <div>
            <h4 className="text-base font-black text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-400" /> Manual Balance Override & Grant
            </h4>
            <p className="text-xs text-slate-400">
              Directly credit or debit a specific user's Coin or Diamond balance. All actions are audited.
            </p>
          </div>

          <form onSubmit={handleAdjustSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Target User UID *</label>
              <input
                type="text"
                value={targetUid}
                onChange={e => setTargetUid(e.target.value)}
                placeholder="e.g. 8829101"
                required
                className="w-full px-3.5 py-2.5 bg-black/40 border border-white/10 rounded-xl text-white text-sm focus:outline-none focus:border-amber-400 font-mono"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Currency Type</label>
                <select
                  value={currency}
                  onChange={e => setCurrency(e.target.value as any)}
                  className="w-full px-3.5 py-2.5 bg-black/40 border border-white/10 rounded-xl text-white text-sm focus:outline-none focus:border-amber-400"
                >
                  <option value="coin">🪙 Coins (Purchased / Spendable)</option>
                  <option value="diamond">💎 Diamonds (Host Earnings)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Action</label>
                <select
                  value={adjustAction}
                  onChange={e => setAdjustAction(e.target.value as any)}
                  className="w-full px-3.5 py-2.5 bg-black/40 border border-white/10 rounded-xl text-white text-sm focus:outline-none focus:border-amber-400"
                >
                  <option value="add">➕ Credit / Add to Balance</option>
                  <option value="deduct">➖ Debit / Deduct from Balance</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Amount *</label>
              <input
                type="number"
                min="1"
                value={adjustAmount}
                onChange={e => setAdjustAmount(e.target.value)}
                placeholder="e.g. 5000"
                required
                className="w-full px-3.5 py-2.5 bg-black/40 border border-white/10 rounded-xl text-white text-sm focus:outline-none focus:border-amber-400 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Reason / Reference Notes</label>
              <textarea
                value={adjustReason}
                onChange={e => setAdjustReason(e.target.value)}
                placeholder="e.g. Compensation for PK battle technical glitch or official reward grant"
                rows={3}
                className="w-full px-3.5 py-2.5 bg-black/40 border border-white/10 rounded-xl text-white text-sm focus:outline-none focus:border-amber-400 resize-none"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={adjusting}
                className="w-full py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black text-sm rounded-xl transition-all shadow-lg shadow-amber-500/20 disabled:opacity-50"
              >
                {adjusting ? 'Processing Adjustment...' : `${adjustAction === 'add' ? 'Credit' : 'Deduct'} Balance`}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* TAB 3: WITHDRAWALS QUEUE */}
      {activeTab === 'withdrawals' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-400" /> Host & Agency Withdrawal Requests
            </h4>
            <span className="text-xs text-slate-400">{pendingWithdrawals.length} pending moderation</span>
          </div>

          {pendingWithdrawals.length === 0 ? (
            <div className="p-8 text-center rounded-2xl bg-white/5 border border-white/10">
              <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto mb-2 opacity-80" />
              <p className="text-sm font-bold text-white">All Clear!</p>
              <p className="text-xs text-slate-400">No pending withdrawal requests in the moderation queue.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {pendingWithdrawals.map(req => (
                <div key={req.id} className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-xs font-mono text-slate-400">{req.id}</span>
                      <p className="text-base font-black text-cyan-400 font-mono flex items-center gap-1">
                        💎 {req.amount.toLocaleString()} Diamonds
                      </p>
                      <span className="text-xs text-slate-300 font-semibold">
                        ≈ ${(req.amount / 100).toFixed(2)} USD
                      </span>
                    </div>
                    <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      Pending
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 bg-black/30 p-2.5 rounded-xl">{req.description}</p>

                  <div className="flex items-center justify-between pt-1">
                    <span className="text-[10px] text-slate-500">
                      {new Date(req.timestamp || req.createdAt || '').toLocaleString()}
                    </span>
                    <div className="flex gap-2">
                      <button
                        onClick={() => setSelectedWithdrawal(req)}
                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl transition-all"
                      >
                        Moderate Request
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 4: ALL TRANSACTIONS LEDGER */}
      {activeTab === 'transactions' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="relative flex-1 min-w-[200px] max-w-md">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search by TX ID, User ID, Description..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-black/40 border border-white/10 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400"
              />
            </div>

            <div className="flex items-center gap-2">
              <select
                value={filterType}
                onChange={e => setFilterType(e.target.value)}
                className="px-3 py-2 bg-black/40 border border-white/10 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400"
              >
                <option value="all">All Types</option>
                <option value="recharge">Recharge</option>
                <option value="withdraw">Withdraw</option>
                <option value="gift_sent">Gift Sent</option>
                <option value="admin_adjustment">Admin Adjustment</option>
                <option value="lucky_bag">Lucky Bag</option>
              </select>

              <select
                value={filterCurrency}
                onChange={e => setFilterCurrency(e.target.value)}
                className="px-3 py-2 bg-black/40 border border-white/10 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400"
              >
                <option value="all">All Currencies</option>
                <option value="coin">Coins (🪙)</option>
                <option value="diamond">Diamonds (💎)</option>
              </select>
            </div>
          </div>

          {/* TABLE */}
          <div className="overflow-x-auto rounded-2xl border border-white/10 bg-white/5">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-white/5 uppercase text-[10px] font-bold text-slate-400 border-b border-white/10">
                <tr>
                  <th className="px-4 py-3">TX ID</th>
                  <th className="px-4 py-3">User ID</th>
                  <th className="px-4 py-3">Type</th>
                  <th className="px-4 py-3">Amount</th>
                  <th className="px-4 py-3">Balance After</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 font-mono">
                {filteredTransactions.map(tx => (
                  <tr key={tx.id} className="hover:bg-white/5 transition-colors">
                    <td className="px-4 py-3 text-slate-400 font-bold">{tx.id}</td>
                    <td className="px-4 py-3 text-white">{tx.userId}</td>
                    <td className="px-4 py-3">
                      <span className="px-2 py-0.5 rounded text-[10px] uppercase font-sans font-bold bg-white/10 text-white">
                        {tx.type.replace('_', ' ')}
                      </span>
                    </td>
                    <td className={`px-4 py-3 font-black ${
                      tx.amount > 0 ? 'text-emerald-400' : 'text-rose-400'
                    }`}>
                      {tx.currency === 'coin' ? '🪙' : '💎'} {tx.amount > 0 ? `+${tx.amount.toLocaleString()}` : tx.amount.toLocaleString()}
                    </td>
                    <td className="px-4 py-3 text-slate-300">
                      {tx.balanceAfter !== undefined ? tx.balanceAfter.toLocaleString() : '-'}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] uppercase font-sans font-bold ${
                        tx.status === 'completed' ? 'bg-emerald-500/20 text-emerald-300' :
                        tx.status === 'pending' ? 'bg-amber-500/20 text-amber-300' : 'bg-rose-500/20 text-rose-300'
                      }`}>
                        {tx.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-[11px] text-slate-400 font-sans">
                      {new Date(tx.timestamp || tx.createdAt || '').toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* EDIT / CREATE PACKAGE MODAL */}
      {(editingPackage || isAddModalOpen) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
          <div className="w-full max-w-lg p-6 rounded-3xl bg-slate-900 border border-amber-400/40 space-y-5 shadow-2xl overflow-y-auto max-h-[90vh]">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-amber-400/20 border border-amber-400/40 flex items-center justify-center">
                  <Gift className="w-5 h-5 text-amber-300" />
                </div>
                <div>
                  <h4 className="text-base font-black text-white">
                    {editingPackage ? `Edit Package: ${editingPackage.name}` : 'Create New Wallet Package'}
                  </h4>
                  <p className="text-[11px] text-slate-300">
                    Saves directly to production database with zero server restart or APK rebuild required
                  </p>
                </div>
              </div>
              <button 
                onClick={() => { setEditingPackage(null); setIsAddModalOpen(false); }}
                className="text-slate-400 hover:text-white font-bold text-lg p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSavePackageSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Package Display Name *</label>
                <input
                  type="text"
                  required
                  value={packageFormData.name || ''}
                  onChange={e => setPackageFormData({ ...packageFormData, name: e.target.value })}
                  placeholder="e.g. Starter Pack, Monarch Treasure, 2,000 Diamonds"
                  className="w-full px-3.5 py-2.5 bg-black/40 border border-white/10 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400 font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Currency Type</label>
                  <select
                    value={packageFormData.currencyType || 'coin'}
                    onChange={e => setPackageFormData({ ...packageFormData, currencyType: e.target.value as any })}
                    className="w-full px-3.5 py-2.5 bg-black/40 border border-white/10 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400"
                  >
                    <option value="coin">🪙 Coins (User Gifting)</option>
                    <option value="diamond">💎 Diamonds (Host / Agency)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Price (USD $) *</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0.01"
                    required
                    value={packageFormData.priceUsd !== undefined ? packageFormData.priceUsd : ''}
                    onChange={e => setPackageFormData({ ...packageFormData, priceUsd: parseFloat(e.target.value) })}
                    placeholder="e.g. 9.99"
                    className="w-full px-3.5 py-2.5 bg-black/40 border border-white/10 rounded-xl text-emerald-400 text-xs font-bold focus:outline-none focus:border-amber-400 font-mono"
                  />
                </div>
              </div>

              {packageFormData.currencyType === 'coin' ? (
                <div className="grid grid-cols-2 gap-3 p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/20">
                  <div>
                    <label className="block text-xs font-bold text-amber-300 mb-1">Base Coins Amount *</label>
                    <input
                      type="number"
                      min="1"
                      required
                      value={packageFormData.coins !== undefined ? packageFormData.coins : ''}
                      onChange={e => setPackageFormData({ ...packageFormData, coins: parseInt(e.target.value, 10) || 0 })}
                      placeholder="e.g. 2000"
                      className="w-full px-3 py-2 bg-black/50 border border-amber-500/30 rounded-xl text-white text-xs font-bold focus:outline-none focus:border-amber-400 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-emerald-300 mb-1">Bonus Coins (Free Gift)</label>
                    <input
                      type="number"
                      min="0"
                      value={packageFormData.bonusCoins !== undefined ? packageFormData.bonusCoins : 0}
                      onChange={e => setPackageFormData({ ...packageFormData, bonusCoins: parseInt(e.target.value, 10) || 0 })}
                      placeholder="e.g. 200"
                      className="w-full px-3 py-2 bg-black/50 border border-emerald-500/30 rounded-xl text-white text-xs font-bold focus:outline-none focus:border-emerald-400 font-mono"
                    />
                  </div>
                </div>
              ) : (
                <div className="p-3.5 rounded-2xl bg-cyan-500/10 border border-cyan-500/20">
                  <label className="block text-xs font-bold text-cyan-300 mb-1">Diamonds Amount *</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={packageFormData.diamonds !== undefined ? packageFormData.diamonds : ''}
                    onChange={e => setPackageFormData({ ...packageFormData, diamonds: parseInt(e.target.value, 10) || 0 })}
                    placeholder="e.g. 2000"
                    className="w-full px-3 py-2 bg-black/50 border border-cyan-500/30 rounded-xl text-white text-xs font-bold focus:outline-none focus:border-cyan-400 font-mono"
                  />
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Badge Tag / Label</label>
                  <input
                    type="text"
                    value={packageFormData.badge || ''}
                    onChange={e => setPackageFormData({ ...packageFormData, badge: e.target.value })}
                    placeholder="e.g. POPULAR, BEST VALUE, SVIP ONLY"
                    className="w-full px-3.5 py-2.5 bg-black/40 border border-white/10 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div className="flex items-center gap-4 pt-5">
                  <label className="flex items-center gap-1.5 cursor-pointer text-xs font-bold text-white">
                    <input
                      type="checkbox"
                      checked={!!packageFormData.popular}
                      onChange={e => setPackageFormData({ ...packageFormData, popular: e.target.checked })}
                      className="rounded accent-amber-500"
                    />
                    Popular
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer text-xs font-bold text-white">
                    <input
                      type="checkbox"
                      checked={!!packageFormData.bestValue}
                      onChange={e => setPackageFormData({ ...packageFormData, bestValue: e.target.checked })}
                      className="rounded accent-rose-500"
                    />
                    Best Value
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer text-xs font-bold text-white">
                    <input
                      type="checkbox"
                      checked={packageFormData.isActive !== false}
                      onChange={e => setPackageFormData({ ...packageFormData, isActive: e.target.checked })}
                      className="rounded accent-emerald-500"
                    />
                    Active
                  </label>
                </div>
              </div>

              {/* Instant Sync Notice */}
              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-[11px] text-amber-200 flex items-start gap-2">
                <Zap className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>
                  <strong>Instant Propagation:</strong> Clicking "Save Changes" will immediately update the package in the database and cause any open User Wallet page to refetch and show the new {packageFormData.currencyType === 'diamond' ? `${(packageFormData.diamonds || 0).toLocaleString()} Diamonds` : `${(packageFormData.coins || 0).toLocaleString()} Coins`} for ${packageFormData.priceUsd || 0}.
                </span>
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => { setEditingPackage(null); setIsAddModalOpen(false); }}
                  className="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white font-bold text-xs rounded-xl transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSavingPackage}
                  className="px-6 py-2.5 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-black font-black text-xs rounded-xl shadow-lg shadow-amber-500/20 flex items-center gap-1.5 transition-all disabled:opacity-50"
                >
                  <Save className="w-4 h-4" />
                  {isSavingPackage ? 'Saving to Database...' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* WITHDRAWAL MODERATION MODAL */}
      {selectedWithdrawal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-md p-6 rounded-2xl bg-slate-900 border border-white/10 space-y-4">
            <h4 className="text-base font-bold text-white flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-amber-400" /> Moderate Withdrawal Request
            </h4>

            <div className="p-4 rounded-xl bg-black/40 border border-white/5 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400">Transaction ID:</span>
                <span className="font-mono text-white">{selectedWithdrawal.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">User ID:</span>
                <span className="font-mono text-white">{selectedWithdrawal.userId}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Amount:</span>
                <span className="font-bold text-cyan-400 font-mono">💎 {selectedWithdrawal.amount.toLocaleString()} Diamonds</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Estimated Cash:</span>
                <span className="font-bold text-emerald-400 font-mono">${(selectedWithdrawal.amount / 100).toFixed(2)} USD</span>
              </div>
              <div className="pt-1 text-slate-300">
                <span className="text-slate-400 block mb-0.5">Details:</span>
                {selectedWithdrawal.description}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Staff Decision Notes / Reason</label>
              <input
                type="text"
                value={moderateReason}
                onChange={e => setModerateReason(e.target.value)}
                placeholder="e.g. Bank payout confirmed or insufficient host verification"
                className="w-full px-3.5 py-2 bg-black/40 border border-white/10 rounded-xl text-white text-xs focus:outline-none focus:border-amber-400"
              />
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setSelectedWithdrawal(null)}
                className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white font-bold text-xs rounded-xl"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={moderating}
                onClick={() => handleModerateWithdrawal('rejected')}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded-xl"
              >
                Reject & Refund
              </button>
              <button
                type="button"
                disabled={moderating}
                onClick={() => handleModerateWithdrawal('completed')}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl"
              >
                Approve Payout
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
