/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Ban, ShieldCheck, ShieldAlert, ShieldOff, Search, Filter, Calendar, 
  Clock, UserCheck, UserX, AlertTriangle, CheckCircle2, RefreshCw, 
  Download, History, User as UserIcon, Sparkles, Lock, Unlock, 
  Info, ChevronRight, X, ExternalLink, Award, FileSpreadsheet
} from 'lucide-react';
import { User, BanRecord, UserRole } from '../../../types';
import { ApiClient } from '../../../lib/api';
import { subscribeToFirestoreUsers, banUserInFirestore, unbanUserInFirestore, syncServerUsersToFirestore } from '../../../lib/firestoreUsers';

interface UserBanCenterProps {
  currentUser?: User | null;
  onOpenUserDetails?: (user: User) => void;
}

export const UserBanCenter: React.FC<UserBanCenterProps> = ({ currentUser, onOpenUserDetails }) => {
  const [activeSubTab, setActiveSubTab] = useState<'manager' | 'history'>('manager');
  const [users, setUsers] = useState<User[]>([]);
  const [banHistory, setBanHistory] = useState<BanRecord[]>([]);
  const [stats, setStats] = useState({
    totalUsers: 0,
    activeBans: 0,
    permanentBans: 0,
    temporaryBans: 0,
    totalHistoricalBanEvents: 0,
    unbannedCount: 0,
    expiredCount: 0,
    recent24hEvents: 0
  });

  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Filters for User Manager
  const [userSearchQuery, setUserSearchQuery] = useState('');
  const [userRoleFilter, setUserRoleFilter] = useState<string>('all');
  const [userStatusFilter, setUserStatusFilter] = useState<string>('all');

  // Filters for Ban History
  const [historySearchQuery, setHistorySearchQuery] = useState('');
  const [historyStatusFilter, setHistoryStatusFilter] = useState<string>('all');

  // Ban Modal State
  const [selectedUserForBan, setSelectedUserForBan] = useState<User | null>(null);
  const [banType, setBanType] = useState<'temporary' | 'permanent'>('temporary');
  const [banDurationHours, setBanDurationHours] = useState<number>(24);
  const [customDurationInput, setCustomDurationInput] = useState<string>('24');
  const [banReasonPreset, setBanReasonPreset] = useState<string>('Violation of Community Guidelines');
  const [banCustomReason, setBanCustomReason] = useState<string>('');
  const [banAdminNote, setBanAdminNote] = useState<string>('');
  const [isSubmittingBan, setIsSubmittingBan] = useState(false);

  // Unban Modal State
  const [selectedUserForUnban, setSelectedUserForUnban] = useState<User | null>(null);
  const [unbanReason, setUnbanReason] = useState<string>('Appeal approved by administrative staff');
  const [isSubmittingUnban, setIsSubmittingUnban] = useState(false);

  // Toast / Status message
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const showNotification = (text: string, type: 'success' | 'error' = 'success') => {
    setStatusMessage({ type, text });
    setTimeout(() => {
      setStatusMessage(null);
    }, 4000);
  };

  const calculateDynamicStats = (userList: User[], historyList: BanRecord[]) => {
    const activeBannedUsers = userList.filter(u => u.status === 'banned');
    const permBans = activeBannedUsers.filter(u => u.banType === 'permanent' || !u.banExpiresAt).length;
    const tempBans = activeBannedUsers.filter(u => u.banType === 'temporary' || (u.banExpiresAt && u.banType !== 'permanent')).length;
    const unbanned = historyList.filter(h => h.status === 'unbanned').length;
    const expired = historyList.filter(h => h.status === 'expired').length;

    return {
      totalUsers: userList.length,
      activeBans: activeBannedUsers.length,
      permanentBans: permBans,
      temporaryBans: tempBans,
      totalHistoricalBanEvents: Math.max(historyList.length, activeBannedUsers.length),
      unbannedCount: unbanned,
      expiredCount: expired,
      recent24hEvents: historyList.filter(h => {
        const t = new Date(h.bannedAt).getTime();
        return !isNaN(t) && (Date.now() - t) < 24 * 3600 * 1000;
      }).length
    };
  };

  const fetchData = async () => {
    try {
      setIsRefreshing(true);
      const results = await Promise.allSettled([
        ApiClient.getUsers(),
        ApiClient.getBanHistory(),
        ApiClient.getBanStats()
      ]);

      const usersRes = results[0].status === 'fulfilled' ? results[0].value : [];
      const historyRes = results[1].status === 'fulfilled' ? results[1].value : [];
      const statsRes = results[2].status === 'fulfilled' ? results[2].value : null;

      if (usersRes && usersRes.length > 0) {
        setUsers(prev => (prev.length > 0 ? prev : usersRes));
        syncServerUsersToFirestore(usersRes).catch(() => {});
      }

      if (historyRes && Array.isArray(historyRes)) {
        setBanHistory(historyRes);
      }

      // Compute stats with fallback
      setUsers(currentUsers => {
        const combinedUsers = currentUsers.length > 0 ? currentUsers : (usersRes || []);
        const computed = calculateDynamicStats(combinedUsers, historyRes || []);
        setStats({
          ...computed,
          ...(statsRes || {})
        });
        return currentUsers;
      });
    } catch (err: any) {
      console.warn('Notice: Background sync completed with local Firestore backup.');
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    let unsubscribe: (() => void) | undefined;

    try {
      unsubscribe = subscribeToFirestoreUsers(
        (firestoreUsers) => {
          if (firestoreUsers && firestoreUsers.length > 0) {
            setUsers(firestoreUsers);
            setStats(prev => {
              const dyn = calculateDynamicStats(firestoreUsers, banHistory);
              return { ...prev, ...dyn };
            });
            setIsLoading(false);
          }
        },
        (error) => {
          console.warn('Firestore subscription fallback mode:', error?.message);
        }
      );
    } catch (err) {
      console.warn('Firestore live listener error:', err);
    }

    fetchData();

    // Listen for cross-component ban updates
    const handleUpdate = () => {
      fetchData();
    };
    window.addEventListener('user_ban_status_updated', handleUpdate);
    return () => {
      if (unsubscribe) unsubscribe();
      window.removeEventListener('user_ban_status_updated', handleUpdate);
    };
  }, []);

  // Handle Ban Submit
  const handleConfirmBan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUserForBan) return;

    const finalReason = banReasonPreset === 'Custom' 
      ? banCustomReason.trim() 
      : (banCustomReason.trim() ? `${banReasonPreset}: ${banCustomReason.trim()}` : banReasonPreset);

    if (!finalReason) {
      showNotification('Please provide a valid ban reason.', 'error');
      return;
    }

    try {
      setIsSubmittingBan(true);
      const duration = banType === 'temporary' ? Number(customDurationInput) || banDurationHours : undefined;
      
      const adminName = currentUser?.name || 'Administrator';
      const adminRole = currentUser?.role || 'super_admin';

      // 1. Update directly in Firestore
      await banUserInFirestore(selectedUserForBan.id, {
        reason: finalReason,
        banType,
        durationHours: duration,
        bannedByName: adminName,
        bannedByRole: adminRole
      }).catch(err => console.warn('Firestore ban error:', err));

      // 2. Also execute server-side ban API
      try {
        await ApiClient.banUser(selectedUserForBan.id, {
          banType,
          durationHours: duration,
          reason: finalReason,
          adminNote: banAdminNote.trim() || undefined
        });
      } catch (apiErr) {
        console.warn('ApiClient.banUser notice (Firestore updated successfully):', apiErr);
      }

      // 3. Optimistically update local users & ban history
      const nowIso = new Date().toISOString();
      const expiresAtIso = banType === 'temporary' && duration
        ? new Date(Date.now() + duration * 3600 * 1000).toISOString()
        : undefined;

      const newRecord: BanRecord = {
        id: `ban-${Date.now()}`,
        userId: selectedUserForBan.id,
        userUid: selectedUserForBan.uid,
        userName: selectedUserForBan.name,
        userAvatar: selectedUserForBan.avatar,
        banType,
        durationHours: duration,
        reason: finalReason,
        adminNote: banAdminNote.trim() || undefined,
        bannedBy: currentUser?.id || '2383452',
        bannedByName: adminName,
        bannedByRole: adminRole,
        bannedAt: nowIso,
        expiresAt: expiresAtIso,
        status: 'active'
      };

      setBanHistory(prev => [newRecord, ...prev.filter(r => r.userId !== selectedUserForBan.id || r.status !== 'active')]);
      setUsers(prev => prev.map(u => u.id === selectedUserForBan.id ? {
        ...u,
        status: 'banned',
        banReason: finalReason,
        banType,
        banExpiresAt: expiresAtIso,
        bannedByName: adminName,
        bannedByRole: adminRole
      } : u));

      showNotification(`Account [${selectedUserForBan.name}] has been successfully ${banType === 'permanent' ? 'permanently suspended' : `banned for ${duration} hours`}.`);
      setSelectedUserForBan(null);
      setBanCustomReason('');
      setBanAdminNote('');
      await fetchData();
    } catch (err: any) {
      console.error('Failed to ban user:', err);
      showNotification(err.message || 'Failed to execute ban.', 'error');
    } finally {
      setIsSubmittingBan(false);
    }
  };

  // Handle Unban Submit
  const handleConfirmUnban = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUserForUnban) return;

    try {
      setIsSubmittingUnban(true);
      const adminName = currentUser?.name || 'Administrator';

      // 1. Update directly in Firestore
      await unbanUserInFirestore(selectedUserForUnban.id, {
        reason: unbanReason.trim() || 'Manual unban by administrative staff',
        unbannedByName: adminName
      }).catch(err => console.warn('Firestore unban error:', err));

      // 2. Also execute server-side unban API
      try {
        await ApiClient.unbanUser(selectedUserForUnban.id, {
          reason: unbanReason.trim() || 'Manual unban by administrative staff'
        });
      } catch (apiErr) {
        console.warn('ApiClient.unbanUser notice (Firestore updated successfully):', apiErr);
      }

      // 3. Optimistically update local users & ban history
      const nowIso = new Date().toISOString();
      setBanHistory(prev => prev.map(r => r.userId === selectedUserForUnban.id && r.status === 'active' ? {
        ...r,
        status: 'unbanned',
        unbannedByName: adminName,
        unbannedAt: nowIso,
        unbanReason: unbanReason.trim()
      } : r));

      setUsers(prev => prev.map(u => u.id === selectedUserForUnban.id ? {
        ...u,
        status: 'active',
        banReason: undefined,
        banType: undefined,
        banExpiresAt: undefined,
        bannedByName: undefined,
        bannedByRole: undefined
      } : u));

      showNotification(`User [${selectedUserForUnban.name}] account restored to ACTIVE status.`);
      setSelectedUserForUnban(null);
      setUnbanReason('Appeal approved by administrative staff');
      await fetchData();
    } catch (err: any) {
      console.error('Failed to unban user:', err);
      showNotification(err.message || 'Failed to execute unban.', 'error');
    } finally {
      setIsSubmittingUnban(false);
    }
  };

  // Pre-calculated expiry preview for modal
  const calculateExpiryPreview = () => {
    if (banType === 'permanent') return 'Never (Permanent Account Suspension)';
    const hours = Number(customDurationInput) || banDurationHours || 24;
    const exp = new Date(Date.now() + hours * 3600 * 1000);
    return `${exp.toLocaleDateString()} at ${exp.toLocaleTimeString()} (${hours} hours)`;
  };

  // Filtered Users
  const filteredUsers = users.filter(u => {
    const q = userSearchQuery.toLowerCase().trim();
    const matchesSearch = !q || (
      u.name.toLowerCase().includes(q) ||
      u.uid.toLowerCase().includes(q) ||
      u.id.toLowerCase().includes(q) ||
      (u.email && u.email.toLowerCase().includes(q))
    );

    const matchesRole = userRoleFilter === 'all' || u.role === userRoleFilter;
    const matchesStatus = userStatusFilter === 'all' || 
      (userStatusFilter === 'banned' && u.status === 'banned') ||
      (userStatusFilter === 'active' && u.status !== 'banned');

    return matchesSearch && matchesRole && matchesStatus;
  });

  // Filtered Ban History
  const filteredHistory = banHistory.filter(record => {
    const q = historySearchQuery.toLowerCase().trim();
    const matchesSearch = !q || (
      record.userName.toLowerCase().includes(q) ||
      record.userUid.toLowerCase().includes(q) ||
      record.userId.toLowerCase().includes(q) ||
      record.reason.toLowerCase().includes(q) ||
      (record.adminNote && record.adminNote.toLowerCase().includes(q)) ||
      record.bannedByName.toLowerCase().includes(q) ||
      (record.unbannedByName && record.unbannedByName.toLowerCase().includes(q))
    );

    const matchesStatus = historyStatusFilter === 'all' || 
      (historyStatusFilter === 'permanent' && record.banType === 'permanent' && record.status === 'active') ||
      record.status === historyStatusFilter;

    return matchesSearch && matchesStatus;
  });

  // Export Ban History as CSV
  const handleExportCSV = () => {
    if (filteredHistory.length === 0) {
      showNotification('No ban history records to export.', 'error');
      return;
    }

    const headers = ['Record ID', 'Target User', 'Target UID', 'Target ID', 'Ban Type', 'Duration (Hours)', 'Status', 'Violation Reason', 'Staff Note', 'Banned By', 'Banned By Role', 'Banned At', 'Expires At', 'Unbanned By', 'Unbanned At', 'Unban Reason'];
    
    const rows = filteredHistory.map(r => [
      `"${r.id}"`,
      `"${r.userName}"`,
      `"${r.userUid}"`,
      `"${r.userId}"`,
      `"${r.banType}"`,
      `"${r.durationHours || 'N/A'}"`,
      `"${r.status}"`,
      `"${(r.reason || '').replace(/"/g, '""')}"`,
      `"${(r.adminNote || '').replace(/"/g, '""')}"`,
      `"${r.bannedByName}"`,
      `"${r.bannedByRole}"`,
      `"${r.bannedAt}"`,
      `"${r.expiresAt || 'Permanent'}"`,
      `"${r.unbannedByName || ''}"`,
      `"${r.unbannedAt || ''}"`,
      `"${(r.unbanReason || '').replace(/"/g, '""')}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `aura_ban_history_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showNotification('Ban history successfully exported to CSV file.');
  };

  const PRESET_REASONS = [
    'Violation of Community Guidelines',
    'Severe Harassment, Hate Speech & Abusive Behavior',
    'Inappropriate Adult / Underage / Explicit Content',
    'Payment Fraud, Chargeback or Unauthorized Recharge',
    'Spamming, Phishing & Unauthorized Commercial Ads',
    'Impersonation of Official Staff or Executive Role',
    'Mic Abuse, Noise Raiding & Room Disruption',
    'Custom'
  ];

  const PRESET_DURATIONS = [
    { label: '1 Hour', hours: 1 },
    { label: '6 Hours', hours: 6 },
    { label: '12 Hours', hours: 12 },
    { label: '24 Hours (1 Day)', hours: 24 },
    { label: '3 Days', hours: 72 },
    { label: '7 Days (1 Week)', hours: 168 },
    { label: '30 Days (1 Month)', hours: 720 }
  ];

  return (
    <div id="user-ban-center" className="space-y-6">
      {/* TOAST ALERT */}
      {statusMessage && (
        <div 
          className={`p-4 rounded-2xl flex items-center justify-between shadow-2xl animate-fadeIn ${
            statusMessage.type === 'success' 
              ? 'bg-emerald-500/20 border border-emerald-500/40 text-emerald-300' 
              : 'bg-rose-500/20 border border-rose-500/40 text-rose-300'
          }`}
        >
          <div className="flex items-center gap-3 text-xs font-bold">
            {statusMessage.type === 'success' ? <CheckCircle2 className="w-5 h-5 text-emerald-400" /> : <AlertTriangle className="w-5 h-5 text-rose-400" />}
            <span>{statusMessage.text}</span>
          </div>
          <button onClick={() => setStatusMessage(null)} className="text-white/60 hover:text-white">✕</button>
        </div>
      )}

      {/* HEADER BAR */}
      <div className="rounded-3xl bg-gradient-to-r from-rose-950/40 via-purple-950/30 to-slate-900/60 border border-rose-500/20 p-5 md:p-6 shadow-2xl relative overflow-hidden backdrop-blur-xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-rose-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-rose-500/20 text-rose-300 border border-rose-500/40 flex items-center gap-1">
                <ShieldAlert className="w-3 h-3 text-rose-400" /> Security & Trust Module
              </span>
              <span className="text-slate-400 text-xs font-medium">| Audited Governance Layer</span>
            </div>
            <h1 className="text-xl md:text-2xl font-black text-white flex items-center gap-2.5 tracking-tight">
              <Ban className="w-6 h-6 text-rose-400" />
              User Ban & Unban Management
            </h1>
            <p className="text-xs text-slate-300 mt-1 max-w-2xl">
              Centralized platform moderation console to immediately enforce temporary or permanent user bans, restore cleared accounts, and audit all security enforcement events across all rooms, chat, and sessions.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={fetchData}
              disabled={isRefreshing}
              className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold flex items-center gap-2 border border-white/10 transition-all shadow-md active:scale-95 disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-amber-400' : ''}`} />
              <span>{isRefreshing ? 'Refreshing...' : 'Refresh Logs'}</span>
            </button>
            <button
              onClick={handleExportCSV}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-rose-500 to-amber-500 text-black text-xs font-extrabold flex items-center gap-1.5 shadow-lg shadow-rose-500/20 hover:brightness-110 active:scale-95 transition-all"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Audit</span>
            </button>
          </div>
        </div>

        {/* METRIC KPI TILES */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-5 border-t border-white/10">
          <div className="p-3.5 rounded-2xl bg-black/40 border border-rose-500/20">
            <div className="flex items-center justify-between text-slate-400 text-[11px] font-bold">
              <span>Active Bans</span>
              <Ban className="w-4 h-4 text-rose-400" />
            </div>
            <div className="text-xl font-black text-rose-400 font-mono mt-1">
              {stats.activeBans}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {stats.permanentBans} Permanent • {stats.temporaryBans} Temp
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-black/40 border border-amber-500/20">
            <div className="flex items-center justify-between text-slate-400 text-[11px] font-bold">
              <span>24h Enforcement</span>
              <Clock className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-xl font-black text-amber-300 font-mono mt-1">
              {stats.recent24hEvents}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              Actions in last 24 hours
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-black/40 border border-emerald-500/20">
            <div className="flex items-center justify-between text-slate-400 text-[11px] font-bold">
              <span>Accounts Restored</span>
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-xl font-black text-emerald-400 font-mono mt-1">
              {stats.unbannedCount + stats.expiredCount}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {stats.unbannedCount} Unbanned • {stats.expiredCount} Expired
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-black/40 border border-blue-500/20">
            <div className="flex items-center justify-between text-slate-400 text-[11px] font-bold">
              <span>Total Audit Records</span>
              <History className="w-4 h-4 text-blue-400" />
            </div>
            <div className="text-xl font-black text-blue-300 font-mono mt-1">
              {stats.totalHistoricalBanEvents}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              Lifetime tracked events
            </div>
          </div>
        </div>
      </div>

      {/* VIEW SUBTABS */}
      <div className="flex items-center justify-between border-b border-white/10 pb-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveSubTab('manager')}
            className={`px-4 py-2 rounded-xl text-xs font-extrabold flex items-center gap-2 transition-all ${
              activeSubTab === 'manager'
                ? 'bg-rose-500 text-black shadow-lg shadow-rose-500/20'
                : 'bg-white/5 text-slate-300 hover:bg-white/10'
            }`}
          >
            <UserX className="w-4 h-4" />
            <span>User Ban & Unban Manager</span>
            <span className="px-1.5 py-0.2 rounded-md text-[10px] bg-black/30 font-mono">
              {users.length}
            </span>
          </button>

          <button
            onClick={() => setActiveSubTab('history')}
            className={`px-4 py-2 rounded-xl text-xs font-extrabold flex items-center gap-2 transition-all ${
              activeSubTab === 'history'
                ? 'bg-amber-400 text-black shadow-lg shadow-amber-400/20'
                : 'bg-white/5 text-slate-300 hover:bg-white/10'
            }`}
          >
            <History className="w-4 h-4" />
            <span>Ban History & Audit Log</span>
            <span className="px-1.5 py-0.2 rounded-md text-[10px] bg-black/30 font-mono">
              {banHistory.length}
            </span>
          </button>
        </div>
      </div>

      {/* TAB 1: USER BAN & UNBAN MANAGER */}
      {activeSubTab === 'manager' && (
        <div className="space-y-4">
          {/* SEARCH & FILTERS */}
          <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex flex-col md:flex-row items-center justify-between gap-3 shadow-xl backdrop-blur-md">
            <div className="relative w-full md:w-80">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search user by UID, Name, Email, ID..."
                value={userSearchQuery}
                onChange={(e) => setUserSearchQuery(e.target.value)}
                className="w-full bg-black/40 text-xs text-white pl-9 pr-4 py-2.5 rounded-xl border border-white/15 focus:outline-none focus:border-rose-400"
              />
              {userSearchQuery && (
                <button onClick={() => setUserSearchQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white">✕</button>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
              <div className="flex items-center gap-1 bg-black/40 px-3 py-1.5 rounded-xl border border-white/10 text-xs">
                <Filter className="w-3.5 h-3.5 text-slate-400" />
                <span className="text-slate-400 text-[11px]">Status:</span>
                <select
                  value={userStatusFilter}
                  onChange={(e) => setUserStatusFilter(e.target.value)}
                  className="bg-transparent text-white font-bold focus:outline-none cursor-pointer text-xs"
                >
                  <option value="all" className="bg-slate-900 text-white">All Users ({users.length})</option>
                  <option value="banned" className="bg-slate-900 text-rose-400">Banned Accounts ({stats.activeBans})</option>
                  <option value="active" className="bg-slate-900 text-emerald-400">Active Accounts ({users.length - stats.activeBans})</option>
                </select>
              </div>

              <div className="flex items-center gap-1 bg-black/40 px-3 py-1.5 rounded-xl border border-white/10 text-xs">
                <UserIcon className="w-3.5 h-3.5 text-slate-400" />
                <span className="text-slate-400 text-[11px]">Role:</span>
                <select
                  value={userRoleFilter}
                  onChange={(e) => setUserRoleFilter(e.target.value)}
                  className="bg-transparent text-white font-bold focus:outline-none cursor-pointer text-xs uppercase"
                >
                  <option value="all" className="bg-slate-900 text-white">All Roles</option>
                  <option value="user" className="bg-slate-900 text-white">Regular User</option>
                  <option value="host" className="bg-slate-900 text-amber-300">Host</option>
                  <option value="agency" className="bg-slate-900 text-purple-300">Agency</option>
                  <option value="recharge_agent" className="bg-slate-900 text-teal-300">Recharge Agent</option>
                  <option value="coin_merchant" className="bg-slate-900 text-indigo-300">Merchant</option>
                  <option value="admin" className="bg-slate-900 text-rose-300">Admin</option>
                  <option value="super_admin" className="bg-slate-900 text-cyan-300">Super Admin</option>
                  <option value="manager" className="bg-slate-900 text-amber-400">Manager</option>
                  <option value="gm" className="bg-slate-900 text-emerald-300">General Manager</option>
                  <option value="ceo" className="bg-slate-900 text-amber-400 font-bold">CEO</option>
                </select>
              </div>
            </div>
          </div>

          {/* USERS DIRECTORY TABLE */}
          <div className="rounded-2xl bg-white/5 border border-white/10 overflow-hidden shadow-2xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-black/50 text-slate-300 font-bold uppercase border-b border-white/10">
                  <tr>
                    <th className="p-3.5">User Identity</th>
                    <th className="p-3.5">Profile UID</th>
                    <th className="p-3.5">Role & Privilege</th>
                    <th className="p-3.5">Account Status</th>
                    <th className="p-3.5">Enforcement / Restriction</th>
                    <th className="p-3.5 text-right">Moderation Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 text-slate-200">
                  {isLoading ? (
                    <tr>
                      <td colSpan={6} className="p-8 text-center text-slate-400">
                        <RefreshCw className="w-6 h-6 animate-spin mx-auto text-amber-400 mb-2" />
                        Loading user accounts and ban states...
                      </td>
                    </tr>
                  ) : filteredUsers.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="p-8 text-center text-slate-400">
                        No user accounts matched your search and filter criteria.
                      </td>
                    </tr>
                  ) : (
                    filteredUsers.map((u, uIdx) => {
                      const isBanned = u.status === 'banned';
                      const isCeo = u.role === 'ceo';

                      return (
                        <tr key={`ban-user-${u.id}-${uIdx}`} className={`hover:bg-white/5 transition-colors ${isBanned ? 'bg-rose-950/20' : ''}`}>
                          {/* USER IDENTITY */}
                          <td className="p-3.5">
                            <div className="flex items-center gap-2.5">
                              <img
                                src={u.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80'}
                                alt={u.name}
                                className={`w-9 h-9 rounded-xl object-cover border ${isBanned ? 'border-rose-500/60 ring-2 ring-rose-500/20' : 'border-white/10'}`}
                              />
                              <div>
                                <div className="font-extrabold text-white flex items-center gap-1.5">
                                  <span>{u.name}</span>
                                  {isCeo && <span className="text-amber-400 text-xs">👑</span>}
                                  {u.vipLevel === 'svip' && <span className="text-[10px] bg-amber-400 text-black px-1 rounded font-black">SVIP</span>}
                                  {u.vipLevel === 'vip' && <span className="text-[10px] bg-cyan-400 text-black px-1 rounded font-black">VIP</span>}
                                </div>
                                <div className="text-[11px] text-slate-400 font-mono">{u.email || u.id}</div>
                              </div>
                            </div>
                          </td>

                          {/* PROFILE UID */}
                          <td className="p-3.5">
                            <span className="px-2 py-0.5 rounded-lg bg-amber-400/10 text-amber-300 border border-amber-400/20 font-mono font-extrabold text-xs">
                              {u.uid}
                            </span>
                          </td>

                          {/* ROLE & PRIVILEGE */}
                          <td className="p-3.5">
                            <div className="space-y-0.5">
                              <span className={`px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider ${
                                isCeo ? 'bg-amber-400 text-black' :
                                u.role === 'gm' ? 'bg-emerald-400 text-black' :
                                u.role === 'super_admin' ? 'bg-cyan-400 text-black' :
                                u.role === 'admin' ? 'bg-rose-400 text-black' :
                                u.role === 'host' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' :
                                u.role === 'agency' ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30' :
                                'bg-slate-700/50 text-slate-300'
                              }`}>
                                {u.role.replace('_', ' ')}
                              </span>
                              <div className="text-[10px] text-slate-400">
                                Lv.{u.level || 1} • {u.countryFlag || '🌐'} {u.country || 'Global'}
                              </div>
                            </div>
                          </td>

                          {/* ACCOUNT STATUS */}
                          <td className="p-3.5">
                            {isBanned ? (
                              <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-rose-500/20 border border-rose-500/40 text-rose-300 font-black text-[11px] animate-pulse">
                                <Ban className="w-3.5 h-3.5 text-rose-400" />
                                <span>BANNED ({u.banType ? u.banType.toUpperCase() : 'PERM'})</span>
                              </div>
                            ) : (
                              <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-black text-[11px]">
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                                <span>ACTIVE</span>
                              </div>
                            )}
                          </td>

                          {/* ENFORCEMENT DETAILS */}
                          <td className="p-3.5">
                            {isBanned ? (
                              <div className="space-y-0.5 text-xs max-w-xs">
                                <div className="text-rose-300 font-bold truncate">
                                  {u.banReason || 'Policy violation'}
                                </div>
                                <div className="text-[10px] text-slate-400 font-mono">
                                  {u.banType === 'temporary' && u.banExpiresAt 
                                    ? `Expires: ${new Date(u.banExpiresAt).toLocaleString()}` 
                                    : 'Permanent restriction'}
                                </div>
                                {u.bannedByName && (
                                  <div className="text-[10px] text-amber-300">
                                    By: {u.bannedByName} ({u.bannedByRole?.toUpperCase()})
                                  </div>
                                )}
                              </div>
                            ) : (
                              <span className="text-slate-500 text-[11px]">No active restrictions</span>
                            )}
                          </td>

                          {/* ACTIONS */}
                          <td className="p-3.5 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              {isBanned ? (
                                <button
                                  onClick={() => setSelectedUserForUnban(u)}
                                  className="px-3 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-xs flex items-center gap-1.5 shadow-md shadow-emerald-500/20 active:scale-95 transition-all"
                                >
                                  <Unlock className="w-3.5 h-3.5" />
                                  <span>Unban User</span>
                                </button>
                              ) : (
                                <button
                                  onClick={() => {
                                    setSelectedUserForBan(u);
                                    setBanType('temporary');
                                    setBanDurationHours(24);
                                    setCustomDurationInput('24');
                                  }}
                                  disabled={isCeo && currentUser?.role !== 'ceo'}
                                  title={isCeo ? 'CEO accounts cannot be banned' : 'Ban this user'}
                                  className="px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500 text-rose-300 hover:text-black font-bold text-xs border border-rose-500/40 hover:border-rose-500 flex items-center gap-1.5 transition-all active:scale-95 disabled:opacity-30 disabled:pointer-events-none"
                                >
                                  <Ban className="w-3.5 h-3.5" />
                                  <span>Ban User</span>
                                </button>
                              )}

                              {onOpenUserDetails && (
                                <button
                                  onClick={() => onOpenUserDetails(u)}
                                  title="View User Profile Details"
                                  className="p-1.5 rounded-xl bg-white/5 hover:bg-white/15 text-slate-300 transition-colors"
                                >
                                  <ChevronRight className="w-4 h-4" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: BAN HISTORY & AUDIT LOG */}
      {activeSubTab === 'history' && (
        <div className="space-y-4">
          {/* SEARCH & FILTERS */}
          <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex flex-col md:flex-row items-center justify-between gap-3 shadow-xl backdrop-blur-md">
            <div className="relative w-full md:w-96">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search history by User, UID, Reason, Staff..."
                value={historySearchQuery}
                onChange={(e) => setHistorySearchQuery(e.target.value)}
                className="w-full bg-black/40 text-xs text-white pl-9 pr-4 py-2.5 rounded-xl border border-white/15 focus:outline-none focus:border-amber-400"
              />
              {historySearchQuery && (
                <button onClick={() => setHistorySearchQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white">✕</button>
              )}
            </div>

            <div className="flex items-center gap-2 w-full md:w-auto">
              <div className="flex items-center gap-1 bg-black/40 px-3 py-1.5 rounded-xl border border-white/10 text-xs w-full md:w-auto">
                <Filter className="w-3.5 h-3.5 text-slate-400" />
                <span className="text-slate-400 text-[11px]">Event Status:</span>
                <select
                  value={historyStatusFilter}
                  onChange={(e) => setHistoryStatusFilter(e.target.value)}
                  className="bg-transparent text-white font-bold focus:outline-none cursor-pointer text-xs"
                >
                  <option value="all" className="bg-slate-900 text-white">All Events ({banHistory.length})</option>
                  <option value="active" className="bg-slate-900 text-rose-400">Active Bans ({stats.activeBans})</option>
                  <option value="expired" className="bg-slate-900 text-blue-400">Auto-Expired ({stats.expiredCount})</option>
                  <option value="unbanned" className="bg-slate-900 text-emerald-400">Staff Unbanned ({stats.unbannedCount})</option>
                  <option value="permanent" className="bg-slate-900 text-purple-400">Permanent Active ({stats.permanentBans})</option>
                </select>
              </div>

              <button
                onClick={handleExportCSV}
                className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-slate-200 text-xs font-bold flex items-center gap-1.5 border border-white/10"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
                <span>Export CSV</span>
              </button>
            </div>
          </div>

          {/* BAN HISTORY TABLE */}
          <div className="rounded-2xl bg-white/5 border border-white/10 overflow-hidden shadow-2xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-black/50 text-slate-300 font-bold uppercase border-b border-white/10">
                  <tr>
                    <th className="p-3.5">Target User</th>
                    <th className="p-3.5">Ban Type & Duration</th>
                    <th className="p-3.5">Violation Reason & Notes</th>
                    <th className="p-3.5">Staff Moderator</th>
                    <th className="p-3.5">Timeline & Status</th>
                    <th className="p-3.5 text-right">Quick Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 text-slate-200">
                  {isLoading ? (
                    <tr>
                      <td colSpan={6} className="p-8 text-center text-slate-400">
                        <RefreshCw className="w-6 h-6 animate-spin mx-auto text-amber-400 mb-2" />
                        Loading audited ban history...
                      </td>
                    </tr>
                  ) : filteredHistory.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="p-8 text-center text-slate-400">
                        No ban events found matching your filter criteria.
                      </td>
                    </tr>
                  ) : (
                    filteredHistory.map((rec) => {
                      const isActive = rec.status === 'active';
                      const isExpired = rec.status === 'expired';
                      const isUnbanned = rec.status === 'unbanned';

                      return (
                        <tr key={rec.id} className="hover:bg-white/5 transition-colors">
                          {/* TARGET USER */}
                          <td className="p-3.5">
                            <div className="flex items-center gap-2.5">
                              <img
                                src={rec.userAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80'}
                                alt={rec.userName}
                                className="w-8 h-8 rounded-xl object-cover border border-white/10"
                              />
                              <div>
                                <div className="font-extrabold text-white">{rec.userName}</div>
                                <div className="flex items-center gap-1.5 text-[11px] text-slate-400 font-mono">
                                  <span className="text-amber-400 font-bold">UID: {rec.userUid}</span>
                                  <span>•</span>
                                  <span className="text-slate-500">{rec.userId}</span>
                                </div>
                              </div>
                            </div>
                          </td>

                          {/* BAN TYPE & DURATION */}
                          <td className="p-3.5">
                            <div className="space-y-1">
                              <span className={`px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider ${
                                rec.banType === 'permanent' ? 'bg-rose-500/30 text-rose-300 border border-rose-500/40' : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                              }`}>
                                {rec.banType === 'permanent' ? 'PERMANENT' : `TEMPORARY (${rec.durationHours}h)`}
                              </span>
                              <div className="text-[10px] text-slate-400">
                                {rec.durationHours ? `${rec.durationHours} hours` : 'Indefinite duration'}
                              </div>
                            </div>
                          </td>

                          {/* VIOLATION REASON & NOTES */}
                          <td className="p-3.5">
                            <div className="space-y-1 max-w-sm">
                              <div className="text-white font-bold">{rec.reason}</div>
                              {rec.adminNote && (
                                <div className="text-[11px] text-slate-400 italic">
                                  Note: "{rec.adminNote}"
                                </div>
                              )}
                              {rec.unbanReason && (
                                <div className="text-[10px] text-emerald-400 bg-emerald-500/10 p-1.5 rounded-lg border border-emerald-500/20">
                                  Unban note: {rec.unbanReason}
                                </div>
                              )}
                            </div>
                          </td>

                          {/* STAFF ACTOR */}
                          <td className="p-3.5">
                            <div className="space-y-0.5">
                              <div className="font-extrabold text-amber-300">{rec.bannedByName}</div>
                              <span className="px-1.5 py-0.2 rounded text-[10px] font-black bg-white/10 text-slate-300 uppercase">
                                {rec.bannedByRole}
                              </span>
                              {rec.unbannedByName && (
                                <div className="text-[10px] text-emerald-400 mt-1">
                                  Unbanned by: {rec.unbannedByName}
                                </div>
                              )}
                            </div>
                          </td>

                          {/* TIMELINE & STATUS */}
                          <td className="p-3.5">
                            <div className="space-y-1">
                              {isActive && (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black bg-rose-500/20 text-rose-300 border border-rose-500/40 animate-pulse">
                                  <Ban className="w-3 h-3 text-rose-400" /> ACTIVE
                                </span>
                              )}
                              {isExpired && (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black bg-blue-500/20 text-blue-300 border border-blue-500/40">
                                  <Clock className="w-3 h-3 text-blue-400" /> EXPIRED
                                </span>
                              )}
                              {isUnbanned && (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                                  <CheckCircle2 className="w-3 h-3 text-emerald-400" /> UNBANNED
                                </span>
                              )}

                              <div className="text-[10px] text-slate-400 font-mono">
                                Banned: {new Date(rec.bannedAt).toLocaleString()}
                              </div>
                              {rec.expiresAt && (
                                <div className="text-[10px] text-slate-500 font-mono">
                                  Exp: {new Date(rec.expiresAt).toLocaleString()}
                                </div>
                              )}
                              {rec.unbannedAt && (
                                <div className="text-[10px] text-emerald-400 font-mono">
                                  Restored: {new Date(rec.unbannedAt).toLocaleString()}
                                </div>
                              )}
                            </div>
                          </td>

                          {/* QUICK ACTION */}
                          <td className="p-3.5 text-right">
                            {isActive && (
                              <button
                                onClick={() => {
                                  const targetU = users.find(u => u.id === rec.userId) || {
                                    id: rec.userId,
                                    uid: rec.userUid,
                                    name: rec.userName,
                                    avatar: rec.userAvatar || ''
                                  } as User;
                                  setSelectedUserForUnban(targetU);
                                }}
                                className="px-2.5 py-1 rounded-xl bg-emerald-500/20 hover:bg-emerald-500 text-emerald-300 hover:text-black font-extrabold text-[11px] border border-emerald-500/40 transition-all"
                              >
                                Unban
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* BAN CONFIRMATION MODAL */}
      {selectedUserForBan && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-[#1a0b2e]/95 backdrop-blur-2xl border border-rose-500/30 rounded-3xl p-6 w-full max-w-lg space-y-5 shadow-2xl animate-scaleUp">
            {/* MODAL HEADER */}
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400">
                  <Ban className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-white text-base">Enforce User Ban</h3>
                  <p className="text-[11px] text-slate-400">Restrict access to rooms, chat, and live streaming</p>
                </div>
              </div>
              <button onClick={() => setSelectedUserForBan(null)} className="text-slate-400 hover:text-white p-1">✕</button>
            </div>

            {/* TARGET USER PREVIEW */}
            <div className="p-3.5 rounded-2xl bg-black/40 border border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img
                  src={selectedUserForBan.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80'}
                  alt={selectedUserForBan.name}
                  className="w-10 h-10 rounded-xl object-cover border border-white/10"
                />
                <div>
                  <div className="font-extrabold text-white text-sm">{selectedUserForBan.name}</div>
                  <div className="text-xs text-amber-300 font-mono font-bold">UID: {selectedUserForBan.uid}</div>
                </div>
              </div>
              <span className="px-2.5 py-1 rounded-lg bg-white/10 text-slate-300 text-[10px] font-black uppercase">
                {selectedUserForBan.role}
              </span>
            </div>

            <form onSubmit={handleConfirmBan} className="space-y-4 text-xs">
              {/* BAN TYPE SELECTOR */}
              <div>
                <label className="font-bold text-slate-200 block mb-1.5">Ban Enforcement Type</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setBanType('temporary')}
                    className={`py-2.5 px-3 rounded-xl font-bold border transition-all flex items-center justify-center gap-2 ${
                      banType === 'temporary'
                        ? 'bg-amber-400 text-black border-amber-400 font-black shadow-md'
                        : 'bg-white/5 text-slate-300 border-white/10 hover:bg-white/10'
                    }`}
                  >
                    <Clock className="w-4 h-4" />
                    <span>Temporary Suspension</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setBanType('permanent')}
                    className={`py-2.5 px-3 rounded-xl font-bold border transition-all flex items-center justify-center gap-2 ${
                      banType === 'permanent'
                        ? 'bg-rose-500 text-black border-rose-500 font-black shadow-md'
                        : 'bg-white/5 text-slate-300 border-white/10 hover:bg-white/10'
                    }`}
                  >
                    <Lock className="w-4 h-4" />
                    <span>Permanent Ban</span>
                  </button>
                </div>
              </div>

              {/* TEMPORARY DURATION OPTIONS */}
              {banType === 'temporary' && (
                <div className="space-y-2 p-3 rounded-2xl bg-white/5 border border-white/10">
                  <label className="font-bold text-slate-200 block">Select Suspension Duration</label>
                  <div className="grid grid-cols-3 gap-1.5">
                    {PRESET_DURATIONS.map(d => (
                      <button
                        key={d.hours}
                        type="button"
                        onClick={() => {
                          setBanDurationHours(d.hours);
                          setCustomDurationInput(String(d.hours));
                        }}
                        className={`py-1.5 px-2 rounded-lg font-bold text-[11px] border transition-all ${
                          Number(customDurationInput) === d.hours
                            ? 'bg-amber-400 text-black border-amber-400 font-black'
                            : 'bg-black/30 text-slate-300 border-white/10 hover:bg-white/10'
                        }`}
                      >
                        {d.label}
                      </button>
                    ))}
                  </div>

                  <div className="flex items-center gap-2 pt-2">
                    <span className="text-[11px] text-slate-400">Custom Hours:</span>
                    <input
                      type="number"
                      min={1}
                      max={8760}
                      value={customDurationInput}
                      onChange={(e) => setCustomDurationInput(e.target.value)}
                      className="w-24 bg-black/40 text-xs text-white px-2.5 py-1.5 rounded-lg border border-white/15 focus:outline-none focus:border-amber-400 font-mono"
                    />
                    <span className="text-[11px] text-slate-400">hours</span>
                  </div>

                  <div className="text-[11px] text-amber-300 font-mono pt-1">
                    🗓️ Expiry Time: {calculateExpiryPreview()}
                  </div>
                </div>
              )}

              {/* REASON PRESETS */}
              <div>
                <label className="font-bold text-slate-200 block mb-1">Violation Category / Preset Reason</label>
                <select
                  value={banReasonPreset}
                  onChange={(e) => setBanReasonPreset(e.target.value)}
                  className="w-full bg-black/40 text-xs text-white p-2.5 rounded-xl border border-white/15 focus:outline-none focus:border-rose-400 cursor-pointer"
                >
                  {PRESET_REASONS.map(r => (
                    <option key={r} value={r} className="bg-slate-900 text-white">{r}</option>
                  ))}
                </select>
              </div>

              {/* CUSTOM DETAILS / NOTES */}
              <div>
                <label className="font-bold text-slate-200 block mb-1">
                  Specific Reason Details <span className="text-rose-400">*</span>
                </label>
                <textarea
                  value={banCustomReason}
                  onChange={(e) => setBanCustomReason(e.target.value)}
                  placeholder="Provide precise details for this violation (e.g. Broadcast room raid, abusive comments on seat #2, chargeback dispute)..."
                  rows={2}
                  required={banReasonPreset === 'Custom'}
                  className="w-full bg-black/40 text-xs text-white p-3 rounded-xl border border-white/15 focus:outline-none focus:border-rose-400 resize-none"
                />
              </div>

              {/* INTERNAL ADMIN NOTE */}
              <div>
                <label className="font-bold text-slate-200 block mb-1">Internal Staff Note (Optional)</label>
                <input
                  type="text"
                  value={banAdminNote}
                  onChange={(e) => setBanAdminNote(e.target.value)}
                  placeholder="e.g. Approved by Head of Moderation. Linked to ticket #882."
                  className="w-full bg-black/40 text-xs text-white p-2.5 rounded-xl border border-white/15 focus:outline-none focus:border-rose-400"
                />
              </div>

              {/* WARNING BOX */}
              <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-[11px] text-rose-300 flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>
                  <strong>Governance Impact:</strong> This action will immediately terminate the user's active session, revoke room microphone privileges, and block access to platform rooms, messages, and wallet operations.
                </span>
              </div>

              {/* ACTIONS */}
              <div className="flex items-center gap-2 pt-2 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setSelectedUserForBan(null)}
                  className="flex-1 py-2.5 bg-white/10 hover:bg-white/20 text-slate-300 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingBan}
                  className="flex-1 py-2.5 bg-rose-500 hover:bg-rose-400 text-black font-extrabold rounded-xl shadow-lg shadow-rose-500/20 disabled:opacity-50 flex items-center justify-center gap-1.5"
                >
                  {isSubmittingBan ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Ban className="w-4 h-4" />}
                  <span>{isSubmittingBan ? 'Enforcing...' : 'Confirm & Apply Ban'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* UNBAN CONFIRMATION MODAL */}
      {selectedUserForUnban && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-[#1a0b2e]/95 backdrop-blur-2xl border border-emerald-500/30 rounded-3xl p-6 w-full max-w-md space-y-5 shadow-2xl animate-scaleUp">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                  <Unlock className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-white text-base">Unban User Account</h3>
                  <p className="text-[11px] text-slate-400">Restore full access to platform rooms and services</p>
                </div>
              </div>
              <button onClick={() => setSelectedUserForUnban(null)} className="text-slate-400 hover:text-white p-1">✕</button>
            </div>

            {/* TARGET USER PREVIEW */}
            <div className="p-3.5 rounded-2xl bg-black/40 border border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img
                  src={selectedUserForUnban.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80'}
                  alt={selectedUserForUnban.name}
                  className="w-10 h-10 rounded-xl object-cover border border-white/10"
                />
                <div>
                  <div className="font-extrabold text-white text-sm">{selectedUserForUnban.name}</div>
                  <div className="text-xs text-amber-300 font-mono font-bold">UID: {selectedUserForUnban.uid}</div>
                </div>
              </div>
              <span className="px-2.5 py-1 rounded-lg bg-rose-500/20 text-rose-300 border border-rose-500/30 text-[10px] font-black uppercase">
                BANNED
              </span>
            </div>

            <form onSubmit={handleConfirmUnban} className="space-y-4 text-xs">
              <div>
                <label className="font-bold text-slate-200 block mb-1">Reason for Unban / Appeal Resolution</label>
                <textarea
                  value={unbanReason}
                  onChange={(e) => setUnbanReason(e.target.value)}
                  placeholder="e.g. Investigation completed, appeal approved by supervisor, payment cleared..."
                  rows={3}
                  required
                  className="w-full bg-black/40 text-xs text-white p-3 rounded-xl border border-white/15 focus:outline-none focus:border-emerald-400 resize-none"
                />
              </div>

              <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-[11px] text-emerald-300 flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>
                  Confirming this action will immediately restore the user's account to <strong>ACTIVE</strong> status and clear all security restrictions.
                </span>
              </div>

              <div className="flex items-center gap-2 pt-2 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setSelectedUserForUnban(null)}
                  className="flex-1 py-2.5 bg-white/10 hover:bg-white/20 text-slate-300 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingUnban}
                  className="flex-1 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold rounded-xl shadow-lg shadow-emerald-500/20 disabled:opacity-50 flex items-center justify-center gap-1.5"
                >
                  {isSubmittingUnban ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Unlock className="w-4 h-4" />}
                  <span>{isSubmittingUnban ? 'Restoring...' : 'Confirm Unban'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
