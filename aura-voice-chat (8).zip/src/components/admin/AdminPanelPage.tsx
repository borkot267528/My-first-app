/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Shield, Users, Radio, DollarSign, Activity, FileText, 
  Search, Edit2, ChevronLeft, RefreshCw, Terminal, AlertTriangle, Key,
  TrendingUp, Award, Zap, BarChart3, PieChart, LineChart, Gift as GiftIcon,
  ArrowUpRight, ArrowDownRight, Layers, CheckCircle2, Clock, Ban,
  Bell, Cpu, HardDrive, Server, Crown, UserCheck, UserX, UserMinus,
  ShieldAlert, Heart, Mic, Headphones, Building, Wallet, Sparkles, Check, XCircle, CreditCard,
  Percent, Settings, MessageSquare, Megaphone, Swords, Flag, Gift, ChevronDown, ChevronRight, Menu, History, Building2, Sliders
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ApiClient } from '../../lib/api';
import { User, VoiceRoom, AuditLog, StaffMember } from '../../types';

import { UserStaffCenter } from './centers/UserStaffCenter';
import { LiveRoomCenter } from './centers/LiveRoomCenter';
import { FinancialCenter } from './centers/FinancialCenter';
import { AgencyCenter } from './centers/AgencyCenter';
import { HostCenter } from './centers/HostCenter';
import { CommissionCenter } from './centers/CommissionCenter';
import { VipCenter } from './centers/VipCenter';
import { VipManagementCenter } from './centers/VipManagementCenter';
import { GiftCenter } from './centers/GiftCenter';
import { MessagingCenter } from './centers/MessagingCenter';
import { FamilyCenter } from './centers/FamilyCenter';
import { ReportsCenter } from './centers/ReportsCenter';
import { SettingsCenter } from './centers/SettingsCenter';
import { OpenApiCenter } from './centers/OpenApiCenter';
import { BannerCenter } from './centers/BannerCenter';
import { WalletCenter } from './centers/WalletCenter';
import { WithdrawMethodsCenter } from './centers/WithdrawMethodsCenter';
import { MerchantCenter } from './centers/MerchantCenter';
import { RechargeAgentCenter } from './centers/RechargeAgentCenter';
import { HostAgencyCreateCenter } from './centers/HostAgencyCreateCenter';
import { UserBanCenter } from './centers/UserBanCenter';
import { ConnectionsManagementCenter } from './centers/ConnectionsManagementCenter';
import { CountryManagementCenter } from './centers/CountryManagementCenter';
import { AppearanceCenter, DEFAULT_ADMIN_BACKGROUND } from './centers/AppearanceCenter';
import { AdminSidebar } from '../layout/AdminSidebar';

export const AdminPanelPage: React.FC = () => {
  const { setActiveModal, showNotification, currentUser } = useApp();
  const [activeTab, setActiveTab] = useState<
    | 'dashboard'
    | 'users'
    | 'user_bans'
    | 'connections'
    | 'rooms'
    | 'financials'
    | 'agency'
    | 'host'
    | 'commission'
    | 'vip'
    | 'vip_management'
    | 'gifts'
    | 'banners'
    | 'messaging'
    | 'family'
    | 'reports'
    | 'settings'
    | 'appearance'
    | 'audit'
    | 'api_docs'
    | 'wallet'
    | 'withdraw_methods'
    | 'merchants'
    | 'recharge_agents'
    | 'host_agency_create'
    | 'countries'
  >('dashboard');
  
  const [stats, setStats] = useState<any>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [rooms, setRooms] = useState<VoiceRoom[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [lastRefreshed, setLastRefreshed] = useState<string>('');
  const [selectedRoomSubTab, setSelectedRoomSubTab] = useState<any>('room_list');
  const [selectedStaffSubTab, setSelectedStaffSubTab] = useState<'users' | 'staff_identity' | 'staff' | 'permissions' | 'activity'>('staff_identity');
  const [isLiveRoomOpsExpanded, setIsLiveRoomOpsExpanded] = useState<boolean>(true);
  const [isStaffGovExpanded, setIsStaffGovExpanded] = useState<boolean>(true);
  const [isFinOpsExpanded, setIsFinOpsExpanded] = useState<boolean>(true);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState<boolean>(false);
  const [adminBgColor, setAdminBgColor] = useState<string>(DEFAULT_ADMIN_BACKGROUND);
  const [previewBgColor, setPreviewBgColor] = useState<string>(DEFAULT_ADMIN_BACKGROUND);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const path = window.location.pathname;
      if (path === '/admin/wallet') setActiveTab('wallet');
      else if (path === '/admin/wallet/withdraw-methods') setActiveTab('withdraw_methods');
      else if (path === '/admin/merchants') setActiveTab('merchants');
      else if (path === '/admin/recharge-agents') setActiveTab('recharge_agents');
      else if (path === '/admin/host-agencies/create') setActiveTab('host_agency_create');
      else if (path === '/admin/user-bans' || path === '/admin/bans') setActiveTab('user_bans');
      else if (path === '/admin/connections' || path === '/admin/cp') setActiveTab('connections');
      else if (path === '/admin/countries') setActiveTab('countries');
      else if (path === '/admin/appearance') setActiveTab('appearance');
    }

    // Immediately fetch persisted appearance settings from database
    ApiClient.getAdminAppearance()
      .then((data) => {
        if (data && data.backgroundColor) {
          setAdminBgColor(data.backgroundColor);
          setPreviewBgColor(data.backgroundColor);
        }
      })
      .catch((err) => {
        console.warn('Could not fetch admin appearance on init:', err);
      });
  }, []);

  // Sync users state when a user profile or UID is updated anywhere in the admin dashboard
  useEffect(() => {
    const handleUserUpdated = (e: any) => {
      const detail = e.detail;
      if (detail && detail.id) {
        setUsers(prev => prev.map(u => u.id === detail.id ? { ...u, ...detail } : u));
      }
    };
    window.addEventListener('user_profile_updated', handleUserUpdated);
    window.addEventListener('users_updated', handleUserUpdated);
    return () => {
      window.removeEventListener('user_profile_updated', handleUserUpdated);
      window.removeEventListener('users_updated', handleUserUpdated);
    };
  }, []);

  // User Account Edit Modal
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [editFormData, setEditFormData] = useState({
    name: '',
    email: '',
    role: 'user' as any,
    vipLevel: 'none' as 'none' | 'vip' | 'svip',
    coins: 0,
    diamonds: 0,
    avatar: '',
    bio: '',
    country: ''
  });
  const [isSubmittingUser, setIsSubmittingUser] = useState(false);

  const loadData = async (isBackground = false) => {
    if (!isBackground) setLoading(true);
    try {
      const results = await Promise.allSettled([
        ApiClient.getAdminStats(),
        ApiClient.getAdminUsers(),
        ApiClient.getAdminRooms(),
        ApiClient.getAuditLogs(),
        ApiClient.getAdminAppearance()
      ]);

      const statsRes = results[0];
      const usersRes = results[1];
      const roomsRes = results[2];
      const logsRes = results[3];
      const appRes = results[4];

      let loadedAny = false;
      if (statsRes.status === 'fulfilled' && statsRes.value) {
        setStats(statsRes.value);
        loadedAny = true;
      }
      if (usersRes.status === 'fulfilled' && Array.isArray(usersRes.value) && usersRes.value.length > 0) {
        setUsers(usersRes.value);
        loadedAny = true;
      }
      if (roomsRes.status === 'fulfilled' && Array.isArray(roomsRes.value)) {
        setRooms(roomsRes.value);
        loadedAny = true;
      }
      if (logsRes.status === 'fulfilled' && Array.isArray(logsRes.value)) {
        setAuditLogs(logsRes.value);
        loadedAny = true;
      }
      if (appRes.status === 'fulfilled' && appRes.value?.backgroundColor) {
        const savedColor = appRes.value.backgroundColor;
        setAdminBgColor(savedColor);
        // Only update preview if user isn't currently tweaking live preview
        setPreviewBgColor(prev => (prev === adminBgColor ? savedColor : prev));
      }

      setLastRefreshed(new Date().toLocaleTimeString());

      const allFailed = results.every(r => r.status === 'rejected');
      if (allFailed && !loadedAny) {
        if (!isBackground) {
          const firstErr = (results[0] as PromiseRejectedResult).reason;
          const msg = firstErr?.message || 'Unable to sync live admin APIs. Showing latest cached console metrics.';
          setErrorMsg(msg);
        }
      } else {
        setErrorMsg(null);
      }
    } catch (err: any) {
      console.warn('Admin API Load Notice:', err);
      if (!isBackground) {
        const msg = err.message || 'Connecting to Admin production backend APIs...';
        setErrorMsg(msg);
      }
    } finally {
      if (!isBackground) setLoading(false);
    }
  };

  useEffect(() => {
    loadData();

    // Requirement 10: Refresh dashboard automatically every 10 seconds
    const timer = setInterval(() => {
      loadData(true);
    }, 10000);

    return () => clearInterval(timer);
  }, []);

  const openEditUserModal = (u: User) => {
    setEditingUser(u);
    setEditFormData({
      name: u.name || '',
      email: u.email || '',
      role: u.role || 'user',
      vipLevel: u.vipLevel || 'none',
      coins: u.coins ?? 0,
      diamonds: u.diamonds ?? 0,
      avatar: u.avatar || '',
      bio: u.bio || '',
      country: u.country || ''
    });
  };

  const handleUpdateUserAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    setIsSubmittingUser(true);
    try {
      const updated = await ApiClient.updateUserAccount(editingUser.id, editFormData);
      setUsers(prev => prev.map(u => u.id === updated.id ? updated : u));
      showNotification(`✅ User account for ${updated.name} updated successfully!`);
      setEditingUser(null);
      loadData(true);
    } catch (err: any) {
      showNotification(err.message || 'Failed to update user account');
    } finally {
      setIsSubmittingUser(false);
    }
  };

  const roles = ['ceo', 'gm', 'manager', 'super_admin', 'admin', 'bd', 'agency', 'host', 'user'];

  return (
    <div 
      className="fixed inset-0 z-50 backdrop-blur-2xl overflow-y-auto p-3 sm:p-6 text-white animate-fadeIn transition-colors duration-200"
      style={{ backgroundColor: previewBgColor || adminBgColor || DEFAULT_ADMIN_BACKGROUND }}
    >
      <div className="max-w-[1700px] mx-auto space-y-5 pb-24">
        {/* TOP HEADER BAR */}
        <div className="flex flex-wrap items-center justify-between gap-3 bg-white/5 border border-white/10 p-4 rounded-3xl backdrop-blur-md shadow-xl">
          <div className="flex items-center gap-3">
            <button onClick={() => setActiveModal('none')} className="p-2 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/10 text-white transition" title="Close Portal">
              <ChevronLeft className="w-5 h-5" />
            </button>
            <div>
              <h2 className="text-lg font-black flex items-center gap-2 text-white">
                <Shield className="w-5 h-5 text-amber-400" /> Aura Voice Staff Admin & CEO Portal
              </h2>
              <p className="text-xs text-slate-300 flex items-center gap-2">
                <span>RBAC Security • Live Room Governance • Financial Ledger • Family Guilds</span>
                {lastRefreshed && (
                  <span className="bg-emerald-500/20 text-emerald-300 text-[10px] px-2 py-0.5 rounded-full border border-emerald-500/30 font-mono">
                    Synced: {lastRefreshed}
                  </span>
                )}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
              className="lg:hidden px-3.5 py-2 rounded-xl bg-purple-600 text-white font-black text-xs flex items-center gap-1.5 shadow"
            >
              <Menu className="w-4 h-4" /> Menu Navigation
            </button>
            <span className="bg-gradient-to-r from-amber-500 to-yellow-600 text-black font-black text-xs px-3.5 py-1.5 rounded-xl shadow">
              🛡️ ROLE: {currentUser?.role?.toUpperCase() || 'CEO'}
            </span>
            <button onClick={() => loadData(false)} className="p-2 bg-white/10 rounded-xl hover:bg-white/20 border border-white/10 transition-colors" title="Manual Refresh">
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>

        {/* SIDEBAR & MAIN CONTENT GRID */}
        <div className="flex flex-col lg:flex-row gap-5 items-start">
          {/* PERSISTENT ADMIN/CEO SIDEBAR */}
          <AdminSidebar
            activeTab={activeTab}
            onSelectTab={(tabId, subTab) => {
              setActiveTab(tabId as any);
              if (tabId === 'rooms' && subTab) setSelectedRoomSubTab(subTab);
              if (tabId === 'users' && subTab) setSelectedStaffSubTab(subTab as any);
              if (tabId === 'staff_identity') {
                setActiveTab('users');
                setSelectedStaffSubTab('staff_identity');
              }
              setIsMobileSidebarOpen(false);
            }}
            currentUser={currentUser}
            isOpenMobile={isMobileSidebarOpen}
            onCloseMobile={() => setIsMobileSidebarOpen(false)}
            onExitAdmin={() => setActiveModal('none')}
          />

          {/* MAIN CONTENT AREA */}
          <main className="flex-1 min-w-0 space-y-6">

      {/* ERROR STATE WITH RETRY BUTTON */}
      {errorMsg && !stats && (
        <div className="p-8 rounded-3xl bg-red-950/60 backdrop-blur-xl border border-red-500/40 text-center space-y-4 shadow-2xl animate-fadeIn my-8">
          <AlertTriangle className="w-12 h-12 text-red-400 mx-auto animate-bounce" />
          <div className="space-y-1">
            <h3 className="text-lg font-black text-white">Backend Connection Error</h3>
            <p className="text-xs text-red-200 max-w-lg mx-auto">{errorMsg}</p>
          </div>
          <button
            onClick={() => loadData(false)}
            className="px-6 py-2.5 bg-red-600 hover:bg-red-500 text-white font-black text-xs rounded-2xl shadow-lg border border-red-400 transition-all flex items-center gap-2 mx-auto"
          >
            <RefreshCw className="w-4 h-4" /> Retry Connection
          </button>
        </div>
      )}

      {/* LOADING SKELETON */}
      {loading && !stats && (
        <div className="space-y-6 animate-pulse py-8">
          <div className="grid grid-cols-4 gap-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-28 bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-5" />
            ))}
          </div>
          <div className="grid grid-cols-3 gap-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-44 bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-5" />
            ))}
          </div>
          <div className="h-64 bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-5" />
          <p className="text-center text-xs text-slate-300">Loading secure admin data from database store...</p>
        </div>
      )}

      {!loading && stats && (
        <>
          {/* TAB 1: DASHBOARD STATS — READ ONLY CEO DASHBOARD OVERVIEW */}
          {activeTab === 'dashboard' && (
            <div className="space-y-8 animate-fadeIn pb-12">

              {/* TOP READ-ONLY BANNER */}
              <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-900/40 via-purple-900/40 to-amber-900/40 border border-emerald-500/30 flex flex-wrap items-center justify-between text-xs backdrop-blur-md shadow-lg gap-2">
                <div className="flex items-center gap-3">
                  <span className="flex h-3 w-3 relative">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
                  </span>
                  <span className="font-extrabold text-emerald-300 flex items-center gap-1.5">
                    <Crown className="w-4 h-4 text-amber-400" /> Executive CEO Analytics Hub — Read Only Platform Overview
                  </span>
                </div>
                <div className="flex items-center gap-4 text-slate-300 font-semibold text-[11px]">
                  <span>Live Sync: <strong className="text-amber-300">Auto 10s</strong></span>
                  <span>Database Engine: <strong className="text-cyan-300">PostgreSQL 16</strong></span>
                  <span className="bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded-full text-[10px]">Analytics Only</span>
                </div>
              </div>

              {/* ================================================
                  SECTION 1 — USER OVERVIEW
                 ================================================ */}
              <div className="space-y-3">
                <h3 className="text-xs font-black text-amber-300 uppercase tracking-widest flex items-center gap-2 border-b border-white/10 pb-2">
                  <Users className="w-4 h-4 text-amber-400" /> Section 1 — User Overview
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
                  <div className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 space-y-1 shadow-md">
                    <span className="text-[10px] text-slate-300 font-bold block truncate">Total Users</span>
                    <p className="text-xl font-black text-white">{stats.totalUsers?.toLocaleString() || 0}</p>
                    <span className="text-[9px] text-emerald-400 font-bold">100% Registered</span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-emerald-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-emerald-300 font-bold block truncate">Online Users</span>
                    <p className="text-xl font-black text-emerald-400">{stats.onlineUsers?.toLocaleString() || 0}</p>
                    <span className="text-[9px] text-emerald-300/80">Active Connections</span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 space-y-1 shadow-md">
                    <span className="text-[10px] text-slate-300 font-bold block truncate">Offline Users</span>
                    <p className="text-xl font-black text-slate-300">{stats.offlineUsers?.toLocaleString() || 0}</p>
                    <span className="text-[9px] text-slate-400">In-active</span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-purple-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-purple-300 font-bold block truncate">Today's New Users</span>
                    <p className="text-xl font-black text-purple-300">+{stats.todaysNewUsers?.toLocaleString() || 0}</p>
                    <span className="text-[9px] text-purple-200">24h Signups</span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-cyan-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-cyan-300 font-bold block truncate">Active Users (24h)</span>
                    <p className="text-xl font-black text-cyan-300">{stats.activeUsers24h?.toLocaleString() || 0}</p>
                    <span className="text-[9px] text-cyan-200">Daily Engagement</span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-blue-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-blue-300 font-bold block truncate">Verified Users</span>
                    <p className="text-xl font-black text-blue-300">{stats.verifiedUsers?.toLocaleString() || 0}</p>
                    <span className="text-[9px] text-blue-200">Identity Badge</span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 space-y-1 shadow-md">
                    <span className="text-[10px] text-slate-300 font-bold block truncate">Guest Users</span>
                    <p className="text-xl font-black text-amber-200">{stats.guestUsers?.toLocaleString() || 0}</p>
                    <span className="text-[9px] text-slate-400">Quick Preview</span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-red-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-red-300 font-bold block truncate">Banned Users</span>
                    <p className="text-xl font-black text-red-400">{stats.bannedUsers || 0}</p>
                    <span className="text-[9px] text-red-300/80">Safety Enforced</span>
                  </div>
                </div>
              </div>

              {/* ================================================
                  SECTION 2 — STAFF OVERVIEW
                 ================================================ */}
              <div className="space-y-3">
                <h3 className="text-xs font-black text-purple-300 uppercase tracking-widest flex items-center gap-2 border-b border-white/10 pb-2">
                  <Shield className="w-4 h-4 text-purple-400" /> Section 2 — Staff Overview
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
                  <div className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-purple-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-purple-300 font-bold block truncate">Total Staff</span>
                    <p className="text-xl font-black text-purple-300">{stats.totalStaff || 0}</p>
                    <span className="text-[9px] text-slate-400">RBAC Personnel</span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-amber-500/40 space-y-1 shadow-md">
                    <span className="text-[10px] text-amber-300 font-bold block truncate">CEO</span>
                    <p className="text-xl font-black text-amber-400">{stats.ceo || 1}</p>
                    <span className="text-[9px] text-amber-200">Owner Level</span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-cyan-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-cyan-300 font-bold block truncate">General Manager</span>
                    <p className="text-xl font-black text-cyan-300">{stats.generalManagers || 0}</p>
                    <span className="text-[9px] text-cyan-200">Executive</span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-blue-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-blue-300 font-bold block truncate">Manager</span>
                    <p className="text-xl font-black text-blue-300">{stats.managers || 0}</p>
                    <span className="text-[9px] text-blue-200">Operations</span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-indigo-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-indigo-300 font-bold block truncate">Super Admin</span>
                    <p className="text-xl font-black text-indigo-300">{stats.superAdmins || 0}</p>
                    <span className="text-[9px] text-indigo-200">System Governance</span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-pink-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-pink-300 font-bold block truncate">Admin</span>
                    <p className="text-xl font-black text-pink-300">{stats.admins || 0}</p>
                    <span className="text-[9px] text-pink-200">Moderation</span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-teal-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-teal-300 font-bold block truncate">BD</span>
                    <p className="text-xl font-black text-teal-300">{stats.bd || 0}</p>
                    <span className="text-[9px] text-teal-200">Business Dev</span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-yellow-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-yellow-300 font-bold block truncate">Agency</span>
                    <p className="text-xl font-black text-yellow-300">{stats.agencies || 0}</p>
                    <span className="text-[9px] text-yellow-200">Guild Partner</span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-rose-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-rose-300 font-bold block truncate">Host</span>
                    <p className="text-xl font-black text-rose-300">{stats.hosts || 0}</p>
                    <span className="text-[9px] text-rose-200">Broadcaster</span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-emerald-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-emerald-300 font-bold block truncate">Recharge Agent</span>
                    <p className="text-xl font-black text-emerald-300">{stats.rechargeAgents || 0}</p>
                    <span className="text-[9px] text-emerald-200">Top-Up Partner</span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-orange-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-orange-300 font-bold block truncate">Coin Merchant</span>
                    <p className="text-xl font-black text-orange-300">{stats.coinMerchants || 0}</p>
                    <span className="text-[9px] text-orange-200">Liquidity Desk</span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-emerald-400/40 space-y-1 shadow-md">
                    <span className="text-[10px] text-emerald-300 font-bold block truncate">Online Staff</span>
                    <p className="text-xl font-black text-emerald-400">{stats.onlineStaff || 0}</p>
                    <span className="text-[9px] text-emerald-200">Active Shift</span>
                  </div>
                </div>
              </div>

              {/* ================================================
                  SECTION 3 — REVENUE
                 ================================================ */}
              <div className="space-y-3">
                <h3 className="text-xs font-black text-emerald-300 uppercase tracking-widest flex items-center gap-2 border-b border-white/10 pb-2">
                  <DollarSign className="w-4 h-4 text-emerald-400" /> Section 3 — Revenue Metrics
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-3.5">
                  <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-900/30 to-teal-900/30 border border-emerald-500/40 space-y-1 shadow-lg">
                    <span className="text-[10px] text-emerald-300 font-extrabold block truncate">Today's Revenue</span>
                    <p className="text-2xl font-black text-emerald-400">${(stats.todaysRevenue || 1840.50).toLocaleString('en-US', { minimumFractionDigits: 2 })}</p>
                    <span className="text-[9px] text-emerald-300/80 font-semibold">24 Hours Volume</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-gradient-to-br from-cyan-900/30 to-blue-900/30 border border-cyan-500/40 space-y-1 shadow-lg">
                    <span className="text-[10px] text-cyan-300 font-extrabold block truncate">Weekly Revenue</span>
                    <p className="text-2xl font-black text-cyan-300">${(stats.weeklyRevenue || 12850.00).toLocaleString('en-US', { minimumFractionDigits: 2 })}</p>
                    <span className="text-[9px] text-cyan-200 font-semibold">Trailing 7 Days</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-gradient-to-br from-purple-900/30 to-indigo-900/30 border border-purple-500/40 space-y-1 shadow-lg">
                    <span className="text-[10px] text-purple-300 font-extrabold block truncate">Monthly Revenue</span>
                    <p className="text-2xl font-black text-purple-300">${(stats.monthlyRevenue || 48920.00).toLocaleString('en-US', { minimumFractionDigits: 2 })}</p>
                    <span className="text-[9px] text-purple-200 font-semibold">Month-to-Date</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-gradient-to-br from-amber-900/30 to-yellow-900/30 border border-amber-500/40 space-y-1 shadow-lg">
                    <span className="text-[10px] text-amber-300 font-extrabold block truncate">Yearly Revenue</span>
                    <p className="text-2xl font-black text-amber-400">${(stats.yearlyRevenue || 586400.00).toLocaleString('en-US', { minimumFractionDigits: 2 })}</p>
                    <span className="text-[9px] text-amber-200 font-semibold">Annual Trajectory</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-gradient-to-br from-yellow-900/40 to-amber-800/40 border border-yellow-400/50 space-y-1 shadow-lg">
                    <span className="text-[10px] text-yellow-300 font-extrabold block truncate">Total Lifetime Revenue</span>
                    <p className="text-2xl font-black text-yellow-300">${(stats.totalRevenue || 648900.00).toLocaleString('en-US', { minimumFractionDigits: 2 })}</p>
                    <span className="text-[9px] text-yellow-200 font-semibold">All Time Platform Volume</span>
                  </div>
                </div>
              </div>

              {/* ================================================
                  SECTION 4 — WALLET
                 ================================================ */}
              <div className="space-y-3">
                <div className="flex items-center justify-between border-b border-white/10 pb-2">
                  <h3 className="text-xs font-black text-amber-300 uppercase tracking-widest flex items-center gap-2">
                    <Wallet className="w-4 h-4 text-amber-400" /> Section 4 — Wallet & Coin Ledger
                  </h3>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setActiveModal('wallet')}
                      className="px-2.5 py-1 rounded-xl bg-amber-400/20 hover:bg-amber-400 text-amber-300 hover:text-black font-black text-[11px] flex items-center gap-1.5 border border-amber-400/40 transition-all shadow"
                    >
                      <Sparkles className="w-3.5 h-3.5" /> Edit My Coins & Diamonds 🪙
                    </button>
                    <button
                      onClick={() => setActiveTab('wallet')}
                      className="px-2.5 py-1 rounded-xl bg-emerald-400/20 hover:bg-emerald-400 text-emerald-300 hover:text-black font-black text-[11px] flex items-center gap-1.5 border border-emerald-400/40 transition-all shadow"
                    >
                      <Sliders className="w-3.5 h-3.5" /> Platform Wallet Center ⚙️
                    </button>
                  </div>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-3.5">
                  <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-amber-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-amber-300 font-bold block truncate">Total Coins</span>
                    <p className="text-xl font-black text-amber-400">🪙 {(stats.totalCoins || 1850000).toLocaleString()}</p>
                    <span className="text-[9px] text-amber-200/80">User Balances</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-emerald-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-emerald-300 font-bold block truncate">Coins Purchased</span>
                    <p className="text-xl font-black text-emerald-400">🪙 {(stats.coinsPurchased || 3850000).toLocaleString()}</p>
                    <span className="text-[9px] text-emerald-200/80">Recharged Mint</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-rose-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-rose-300 font-bold block truncate">Coins Spent</span>
                    <p className="text-xl font-black text-rose-400">🪙 {(stats.coinsSpent || 2920000).toLocaleString()}</p>
                    <span className="text-[9px] text-rose-200/80">Gifts & Games</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-pink-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-pink-300 font-bold block truncate">Coins Gifted</span>
                    <p className="text-xl font-black text-pink-300">🪙 {(stats.coinsGifted || 1850000).toLocaleString()}</p>
                    <span className="text-[9px] text-pink-200/80">Broadcast Support</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-cyan-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-cyan-300 font-bold block truncate">Total Diamonds</span>
                    <p className="text-xl font-black text-cyan-300">💎 {(stats.totalDiamonds || 845000).toLocaleString()}</p>
                    <span className="text-[9px] text-cyan-200/80">Host Earnings</span>
                  </div>
                </div>
              </div>

              {/* ================================================
                  SECTION 5 — RECHARGE
                 ================================================ */}
              <div className="space-y-3">
                <h3 className="text-xs font-black text-indigo-300 uppercase tracking-widest flex items-center gap-2 border-b border-white/10 pb-2">
                  <CreditCard className="w-4 h-4 text-indigo-400" /> Section 5 — Recharge Operations
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
                  <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-indigo-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-indigo-300 font-bold block truncate">Total Recharge</span>
                    <p className="text-xl font-black text-indigo-300">${(stats.totalRechargeAmount || 142500.00).toLocaleString('en-US', { minimumFractionDigits: 2 })}</p>
                    <span className="text-[9px] text-slate-400">{stats.totalRechargeCount || 1240} Orders</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-yellow-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-yellow-300 font-bold block truncate">Pending Recharge</span>
                    <p className="text-xl font-black text-yellow-400">{stats.pendingRechargeCount || 0}</p>
                    <span className="text-[9px] text-yellow-200/80">Awaiting Verification</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-emerald-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-emerald-300 font-bold block truncate">Approved Recharge</span>
                    <p className="text-xl font-black text-emerald-400">{stats.approvedRechargeCount || 1235}</p>
                    <span className="text-[9px] text-emerald-200/80">Settled & Credited</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-red-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-red-300 font-bold block truncate">Rejected Recharge</span>
                    <p className="text-xl font-black text-red-400">{stats.rejectedRechargeCount || 5}</p>
                    <span className="text-[9px] text-red-200/80">Failed Payment</span>
                  </div>
                </div>
              </div>

              {/* ================================================
                  SECTION 6 — WITHDRAW
                 ================================================ */}
              <div className="space-y-3">
                <h3 className="text-xs font-black text-rose-300 uppercase tracking-widest flex items-center gap-2 border-b border-white/10 pb-2">
                  <ArrowDownRight className="w-4 h-4 text-rose-400" /> Section 6 — Withdraw & Cashout Operations
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
                  <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-rose-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-rose-300 font-bold block truncate">Total Withdrawals</span>
                    <p className="text-xl font-black text-rose-300">${(stats.totalWithdrawalAmount || 48200.00).toLocaleString('en-US', { minimumFractionDigits: 2 })}</p>
                    <span className="text-[9px] text-slate-400">{stats.totalWithdrawalCount || 320} Cashouts</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-orange-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-orange-300 font-bold block truncate">Pending Withdrawals</span>
                    <p className="text-xl font-black text-orange-400">{stats.pendingWithdrawalCount || 0}</p>
                    <span className="text-[9px] text-orange-200/80">Queue Approval</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-emerald-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-emerald-300 font-bold block truncate">Approved Withdrawals</span>
                    <p className="text-xl font-black text-emerald-400">{stats.approvedWithdrawalCount || 318}</p>
                    <span className="text-[9px] text-emerald-200/80">USDT Transferred</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-red-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-red-300 font-bold block truncate">Rejected Withdrawals</span>
                    <p className="text-xl font-black text-red-400">{stats.rejectedWithdrawalCount || 2}</p>
                    <span className="text-[9px] text-red-200/80">Compliance Return</span>
                  </div>
                </div>
              </div>

              {/* ================================================
                  SECTION 7 — GIFT
                 ================================================ */}
              <div className="space-y-3">
                <h3 className="text-xs font-black text-pink-300 uppercase tracking-widest flex items-center gap-2 border-b border-white/10 pb-2">
                  <GiftIcon className="w-4 h-4 text-pink-400" /> Section 7 — Gift Metrics & Top Honor Roll
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-3.5">
                  <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-pink-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-pink-300 font-bold block truncate">Gifts Sent Today</span>
                    <p className="text-xl font-black text-pink-300">{stats.giftsSentToday || 142}</p>
                    <span className="text-[9px] text-pink-200/80">24h Gift Animations</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-purple-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-purple-300 font-bold block truncate">Gifts Received Today</span>
                    <p className="text-xl font-black text-purple-300">{stats.giftsReceivedToday || 142}</p>
                    <span className="text-[9px] text-purple-200/80">Host Diamond Conversions</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-amber-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-amber-300 font-bold block truncate">Total Lifetime Gifts</span>
                    <p className="text-xl font-black text-amber-400">{(stats.totalGifts || 8920).toLocaleString()}</p>
                    <span className="text-[9px] text-amber-200/80">3D Luxury Catalog</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-amber-400/40 space-y-2 shadow-md col-span-2 md:col-span-1">
                    <span className="text-[10px] text-amber-300 font-bold block truncate">Top Gift Sender</span>
                    <div className="flex items-center gap-2">
                      <img src={stats.topGiftSender?.avatar} alt="Sender" className="w-8 h-8 rounded-full border border-amber-400/50 object-cover" />
                      <div className="truncate">
                        <p className="text-xs font-black text-white truncate">{stats.topGiftSender?.name || 'Lord Alex (CEO)'}</p>
                        <span className="text-[9px] text-amber-300 font-mono">{stats.topGiftSender?.count || 420} Gifts Sent</span>
                      </div>
                    </div>
                  </div>

                  <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-pink-400/40 space-y-2 shadow-md col-span-2 md:col-span-1">
                    <span className="text-[10px] text-pink-300 font-bold block truncate">Top Gift Receiver</span>
                    <div className="flex items-center gap-2">
                      <img src={stats.topGiftReceiver?.avatar} alt="Receiver" className="w-8 h-8 rounded-full border border-pink-400/50 object-cover" />
                      <div className="truncate">
                        <p className="text-xs font-black text-white truncate">{stats.topGiftReceiver?.name || 'Sophia Taylor (Host)'}</p>
                        <span className="text-[9px] text-pink-300 font-mono">{stats.topGiftReceiver?.count || 380} Gifts Received</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* ================================================
                  SECTION 8 — VOICE ROOM
                 ================================================ */}
              <div className="space-y-3">
                <h3 className="text-xs font-black text-cyan-300 uppercase tracking-widest flex items-center gap-2 border-b border-white/10 pb-2">
                  <Radio className="w-4 h-4 text-cyan-400" /> Section 8 — Voice Room Status
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-3.5">
                  <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-pink-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-pink-300 font-bold block truncate">Live Rooms</span>
                    <p className="text-xl font-black text-pink-300">{stats.liveRooms || stats.activeVoiceRooms || 4}</p>
                    <span className="text-[9px] text-pink-200/80">Live Microphones</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-cyan-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-cyan-300 font-bold block truncate">Active Rooms</span>
                    <p className="text-xl font-black text-cyan-300">{stats.activeRooms || stats.activeVoiceRooms || 4}</p>
                    <span className="text-[9px] text-cyan-200/80">Public & Private</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-yellow-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-yellow-300 font-bold block truncate">Locked Rooms</span>
                    <p className="text-xl font-black text-yellow-400">{stats.lockedRooms || 0}</p>
                    <span className="text-[9px] text-yellow-200/80">PIN Protected</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-purple-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-purple-300 font-bold block truncate">Total Hosts</span>
                    <p className="text-xl font-black text-purple-300">{stats.totalRoomHosts || stats.hosts || 5}</p>
                    <span className="text-[9px] text-purple-200/80">Broadcasters</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-emerald-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-emerald-300 font-bold block truncate">Total Audience</span>
                    <p className="text-xl font-black text-emerald-400">{stats.totalAudience || 48}</p>
                    <span className="text-[9px] text-emerald-200/80">Room Listeners</span>
                  </div>
                </div>
              </div>

              {/* ================================================
                  SECTION 9 — FAMILY
                 ================================================ */}
              <div className="space-y-3">
                <h3 className="text-xs font-black text-yellow-300 uppercase tracking-widest flex items-center gap-2 border-b border-white/10 pb-2">
                  <Building className="w-4 h-4 text-yellow-400" /> Section 9 — Family & Guild Clans
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
                  <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-yellow-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-yellow-300 font-bold block truncate">Total Families</span>
                    <p className="text-xl font-black text-yellow-300">{stats.totalFamilies || 5}</p>
                    <span className="text-[9px] text-yellow-200/80">Registered Guilds</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-emerald-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-emerald-300 font-bold block truncate">Active Families</span>
                    <p className="text-xl font-black text-emerald-400">{stats.activeFamilies || 5}</p>
                    <span className="text-[9px] text-emerald-200/80">Participating in Battles</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-amber-400/40 space-y-1 shadow-md">
                    <span className="text-[10px] text-amber-300 font-bold block truncate">Top Family</span>
                    <p className="text-base font-black text-white">{stats.topFamily?.name || 'Royal Crown Guild 👑'}</p>
                    <span className="text-[9px] text-amber-300 font-mono">Level {stats.topFamily?.level || 8} • {stats.topFamily?.members || 42} Active Members</span>
                  </div>
                </div>
              </div>

              {/* ================================================
                  SECTION 10 — VIP
                 ================================================ */}
              <div className="space-y-3">
                <h3 className="text-xs font-black text-amber-300 uppercase tracking-widest flex items-center gap-2 border-b border-white/10 pb-2">
                  <Crown className="w-4 h-4 text-amber-400" /> Section 10 — VIP & SVIP Status
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
                  <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-amber-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-amber-300 font-bold block truncate">VIP Users</span>
                    <p className="text-xl font-black text-amber-400">{stats.vipUsers || 0}</p>
                    <span className="text-[9px] text-amber-200/80">Gold Tier Subscribers</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-purple-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-purple-300 font-bold block truncate">SVIP Users</span>
                    <p className="text-xl font-black text-purple-300">{stats.svipUsers || 0}</p>
                    <span className="text-[9px] text-purple-200/80">Royal Crown Tier</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-emerald-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-emerald-300 font-bold block truncate">VIP Sales Today</span>
                    <p className="text-xl font-black text-emerald-400">${(stats.vipSalesToday || 1450.00).toLocaleString('en-US', { minimumFractionDigits: 2 })}</p>
                    <span className="text-[9px] text-emerald-200/80">Subscription Renewals</span>
                  </div>
                </div>
              </div>

              {/* ================================================
                  SECTION 11 — AGENCY
                 ================================================ */}
              <div className="space-y-3">
                <h3 className="text-xs font-black text-teal-300 uppercase tracking-widest flex items-center gap-2 border-b border-white/10 pb-2">
                  <Layers className="w-4 h-4 text-teal-400" /> Section 11 — Agency Network
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
                  <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-teal-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-teal-300 font-bold block truncate">Total Agencies</span>
                    <p className="text-xl font-black text-teal-300">{stats.totalAgencies || stats.agencies || 2}</p>
                    <span className="text-[9px] text-teal-200/80">Partner Networks</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-rose-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-rose-300 font-bold block truncate">Total Agency Hosts</span>
                    <p className="text-xl font-black text-rose-300">{stats.totalAgencyHosts || stats.hosts || 5}</p>
                    <span className="text-[9px] text-rose-200/80">Contracted Broadcasters</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-emerald-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-emerald-300 font-bold block truncate">Active Hosts</span>
                    <p className="text-xl font-black text-emerald-400">{stats.activeAgencyHosts || 3}</p>
                    <span className="text-[9px] text-emerald-200/80">Currently On Air</span>
                  </div>
                </div>
              </div>

              {/* ================================================
                  SECTION 12 — CHARTS
                 ================================================ */}
              <div className="space-y-4">
                <h3 className="text-xs font-black text-cyan-300 uppercase tracking-widest flex items-center gap-2 border-b border-white/10 pb-2">
                  <PieChart className="w-4 h-4 text-cyan-400" /> Section 12 — Analytical Charts & Visual Trends (6 Visualizations)
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {/* Chart 1: Revenue (Daily Trend & Monthly Trajectory) */}
                  <div className="p-5 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 space-y-3 shadow-xl">
                    <div className="flex items-center justify-between border-b border-white/10 pb-2">
                      <span className="text-xs font-black text-emerald-400 flex items-center gap-1.5">
                        <LineChart className="w-4 h-4" /> 1. Daily & Monthly Revenue Chart
                      </span>
                      <span className="text-[10px] text-slate-400">USD</span>
                    </div>
                    <div className="h-32 flex items-end gap-2 pt-2 border-b border-white/10 pb-2">
                      {stats.dailyRevenueChart?.map((item: any, idx: number) => (
                        <div key={idx} className="flex-1 flex flex-col items-center gap-1 h-full justify-end group">
                          <div 
                            className="w-full bg-gradient-to-t from-emerald-600 to-teal-400 rounded-t-md transition-all group-hover:brightness-125" 
                            style={{ height: `${Math.max(15, (item.amountUsd / 2000) * 100)}%` }}
                          />
                          <span className="text-[9px] text-slate-400 font-mono truncate">{item.date.slice(5)}</span>
                        </div>
                      ))}
                    </div>
                    <p className="text-[10px] text-slate-300">Revenue driven by coin pack top-ups & PK battle gifting.</p>
                  </div>

                  {/* Chart 2: User Growth */}
                  <div className="p-5 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 space-y-3 shadow-xl">
                    <div className="flex items-center justify-between border-b border-white/10 pb-2">
                      <span className="text-xs font-black text-purple-300 flex items-center gap-1.5">
                        <TrendingUp className="w-4 h-4" /> 2. User Growth Trajectory
                      </span>
                      <span className="text-[10px] text-slate-400">New Signups</span>
                    </div>
                    <div className="h-32 flex items-end gap-2 pt-2 border-b border-white/10 pb-2">
                      {stats.userGrowthChart?.map((item: any, idx: number) => (
                        <div key={idx} className="flex-1 flex flex-col items-center gap-1 h-full justify-end group">
                          <div 
                            className="w-full bg-gradient-to-t from-purple-600 to-pink-400 rounded-t-md transition-all group-hover:brightness-125" 
                            style={{ height: `${Math.max(20, (item.newUsers / 40) * 100)}%` }}
                          />
                          <span className="text-[9px] text-slate-400 font-mono">{item.date.slice(5)}</span>
                        </div>
                      ))}
                    </div>
                    <p className="text-[10px] text-slate-300">Viral growth attributed to family clan recruitment.</p>
                  </div>

                  {/* Chart 3: Recharge */}
                  <div className="p-5 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 space-y-3 shadow-xl">
                    <div className="flex items-center justify-between border-b border-white/10 pb-2">
                      <span className="text-xs font-black text-indigo-300 flex items-center gap-1.5">
                        <Layers className="w-4 h-4" /> 3. Recharge Package Breakdown
                      </span>
                      <span className="text-[10px] text-slate-400">USD</span>
                    </div>
                    <div className="space-y-2 pt-1">
                      {stats.rechargeStatsChart?.map((pkg: any, idx: number) => (
                        <div key={idx} className="space-y-0.5">
                          <div className="flex justify-between text-[10px]">
                            <span className="font-bold text-white truncate">{pkg.name}</span>
                            <span className="text-emerald-400 font-mono">${pkg.revenueUsd.toLocaleString()}</span>
                          </div>
                          <div className="w-full h-1.5 bg-black/40 rounded-full overflow-hidden">
                            <div className="h-full bg-gradient-to-r from-indigo-500 to-cyan-400 rounded-full" style={{ width: `${Math.min(100, (pkg.count / 100) * 100)}%` }} />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Chart 4: Withdraw */}
                  <div className="p-5 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 space-y-3 shadow-xl">
                    <div className="flex items-center justify-between border-b border-white/10 pb-2">
                      <span className="text-xs font-black text-rose-300 flex items-center gap-1.5">
                        <DollarSign className="w-4 h-4 text-rose-400" /> 4. Withdraw Volume Log
                      </span>
                      <span className="text-[10px] text-slate-400">Diamonds</span>
                    </div>
                    <div className="space-y-2 pt-1">
                      {stats.withdrawalStatsChart?.map((w: any, idx: number) => (
                        <div key={idx} className="space-y-0.5">
                          <div className="flex justify-between text-[10px]">
                            <span className="font-bold text-white font-mono">{w.date}</span>
                            <span className="text-rose-300 font-mono">{w.amountDiamonds.toLocaleString()} 💎</span>
                          </div>
                          <div className="w-full h-1.5 bg-black/40 rounded-full overflow-hidden">
                            <div className="h-full bg-gradient-to-r from-rose-500 to-orange-400 rounded-full" style={{ width: `${Math.min(100, (w.amountDiamonds / 40000) * 100)}%` }} />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Chart 5: Coin Flow */}
                  <div className="p-5 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 space-y-3 shadow-xl">
                    <div className="flex items-center justify-between border-b border-white/10 pb-2">
                      <span className="text-xs font-black text-amber-300 flex items-center gap-1.5">
                        <Zap className="w-4 h-4" /> 5. Coin Flow (Minted vs Spent)
                      </span>
                      <span className="text-[10px] text-slate-400">Coins</span>
                    </div>
                    <div className="h-32 flex items-end gap-2 pt-2 border-b border-white/10 pb-2">
                      {stats.coinFlowChart?.map((item: any, idx: number) => (
                        <div key={idx} className="flex-1 flex items-end gap-0.5 h-full justify-center">
                          <div className="w-1/2 bg-amber-400 rounded-t-xs" style={{ height: `${Math.max(15, (item.minted / 500000) * 100)}%` }} title={`Minted: ${item.minted}`} />
                          <div className="w-1/2 bg-rose-500 rounded-t-xs" style={{ height: `${Math.max(15, (item.spent / 500000) * 100)}%` }} title={`Spent: ${item.spent}`} />
                        </div>
                      ))}
                    </div>
                    <div className="flex items-center justify-between text-[10px] text-slate-300">
                      <span className="flex items-center gap-1"><span className="w-2 h-2 rounded bg-amber-400" /> Minted</span>
                      <span className="flex items-center gap-1"><span className="w-2 h-2 rounded bg-rose-500" /> Spent</span>
                    </div>
                  </div>

                  {/* Chart 6: Gift Statistics */}
                  <div className="p-5 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 space-y-3 shadow-xl">
                    <div className="flex items-center justify-between border-b border-white/10 pb-2">
                      <span className="text-xs font-black text-pink-300 flex items-center gap-1.5">
                        <GiftIcon className="w-4 h-4" /> 6. Gift Volume & Popularity
                      </span>
                      <span className="text-[10px] text-slate-400">Catalog</span>
                    </div>
                    <div className="space-y-2 pt-1">
                      {stats.giftStatsChart?.map((g: any, idx: number) => (
                        <div key={idx} className="space-y-0.5">
                          <div className="flex justify-between text-[10px]">
                            <span className="font-bold text-white flex items-center gap-1">{g.icon} {g.name}</span>
                            <span className="text-amber-300 font-mono">{g.totalCoins.toLocaleString()} 🪙</span>
                          </div>
                          <div className="w-full h-1.5 bg-black/40 rounded-full overflow-hidden">
                            <div className="h-full bg-gradient-to-r from-pink-500 to-amber-400 rounded-full" style={{ width: `${Math.min(100, (g.count / 150) * 100)}%` }} />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* ================================================
                  SECTION 13 — RECENT ACTIVITY
                 ================================================ */}
              <div className="space-y-4">
                <h3 className="text-xs font-black text-purple-300 uppercase tracking-widest flex items-center gap-2 border-b border-white/10 pb-2">
                  <Clock className="w-4 h-4 text-purple-400" /> Section 13 — Recent Activity Feeds (5 Core Logs)
                </h3>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  {/* Feed 1: New Users */}
                  <div className="p-5 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 space-y-3 shadow-xl">
                    <h4 className="text-xs font-extrabold text-white flex items-center gap-2 border-b border-white/10 pb-2">
                      <Users className="w-4 h-4 text-purple-400" /> 1. Latest New Users
                    </h4>
                    <div className="space-y-2">
                      {stats.latestUsers?.map((u: any, idx: number) => (
                        <div key={`latest-user-${u.id}-${idx}`} className="flex items-center justify-between p-2 rounded-xl bg-black/30 border border-white/5 text-xs">
                          <div className="flex items-center gap-2.5">
                            <img src={u.avatar} alt={u.name} className="w-7 h-7 rounded-full object-cover border border-white/20" />
                            <div>
                              <span className="font-bold text-white block">{u.name}</span>
                              <span className="text-[10px] text-slate-400">{u.email}</span>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                              {u.role}
                            </span>
                            <button
                              onClick={() => openEditUserModal(u)}
                              className="p-1.5 bg-white/10 hover:bg-amber-400 text-slate-200 hover:text-black rounded-lg transition-all"
                              title="Edit User Account"
                            >
                              <Edit2 className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Feed 2: Recharge Requests */}
                  <div className="p-5 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 space-y-3 shadow-xl">
                    <h4 className="text-xs font-extrabold text-white flex items-center gap-2 border-b border-white/10 pb-2">
                      <CreditCard className="w-4 h-4 text-emerald-400" /> 2. Latest Recharge Requests
                    </h4>
                    <div className="space-y-2">
                      {stats.latestRecharges?.map((tx: any) => (
                        <div key={tx.id} className="flex items-center justify-between p-2 rounded-xl bg-black/30 border border-white/5 text-xs">
                          <div>
                            <span className="font-bold text-emerald-300 block">{tx.description}</span>
                            <span className="text-[10px] text-slate-400">{new Date(tx.createdAt || tx.timestamp || Date.now()).toLocaleTimeString()}</span>
                          </div>
                          <span className="font-mono font-bold text-amber-400">+{tx.amount.toLocaleString()} 🪙</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Feed 3: Withdraw Requests */}
                  <div className="p-5 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 space-y-3 shadow-xl">
                    <h4 className="text-xs font-extrabold text-white flex items-center gap-2 border-b border-white/10 pb-2">
                      <ArrowDownRight className="w-4 h-4 text-rose-400" /> 3. Latest Withdraw Requests
                    </h4>
                    <div className="space-y-2">
                      {stats.latestWithdrawals?.map((tx: any) => (
                        <div key={tx.id} className="flex items-center justify-between p-2 rounded-xl bg-black/30 border border-white/5 text-xs">
                          <div>
                            <span className="font-bold text-rose-300 block">{tx.description}</span>
                            <span className="text-[10px] text-slate-400">{new Date(tx.createdAt || tx.timestamp || Date.now()).toLocaleTimeString()}</span>
                          </div>
                          <span className="font-mono font-bold text-cyan-300">-{tx.amount.toLocaleString()} 💎</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Feed 4: Gifts */}
                  <div className="p-5 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 space-y-3 shadow-xl">
                    <h4 className="text-xs font-extrabold text-white flex items-center gap-2 border-b border-white/10 pb-2">
                      <GiftIcon className="w-4 h-4 text-pink-400" /> 4. Latest Gifts Sent
                    </h4>
                    <div className="space-y-2">
                      {stats.latestGifts?.map((tx: any) => (
                        <div key={tx.id} className="flex items-center justify-between p-2 rounded-xl bg-black/30 border border-white/5 text-xs">
                          <div>
                            <span className="font-bold text-pink-300 block">{tx.description}</span>
                            <span className="text-[10px] text-slate-400">{new Date(tx.createdAt || tx.timestamp || Date.now()).toLocaleTimeString()}</span>
                          </div>
                          <span className="font-mono font-bold text-amber-300">{tx.amount.toLocaleString()} 🪙</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Feed 5: Staff Activity */}
                <div className="p-5 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 space-y-3 shadow-xl">
                  <h4 className="text-xs font-extrabold text-white flex items-center gap-2 border-b border-white/10 pb-2">
                    <Shield className="w-4 h-4 text-amber-400" /> 5. Latest Staff Activity Logs
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    {stats.latestStaffActions?.map((act: any) => (
                      <div key={act.id} className="p-3 rounded-2xl bg-black/40 border border-white/10 space-y-1 text-xs">
                        <div className="flex items-center justify-between">
                          <span className="font-extrabold text-amber-300">{act.staffName} ({act.staffRole?.toUpperCase()})</span>
                          <span className="text-[9px] text-slate-400 font-mono">{new Date(act.timestamp).toLocaleTimeString()}</span>
                        </div>
                        <p className="text-white font-bold">{act.actionType}: {act.targetResource}</p>
                        <p className="text-[10px] text-slate-300 truncate">{act.details}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* ================================================
                  SECTION 14 — SYSTEM STATUS
                 ================================================ */}
              <div className="space-y-3">
                <h3 className="text-xs font-black text-cyan-300 uppercase tracking-widest flex items-center gap-2 border-b border-white/10 pb-2">
                  <Server className="w-4 h-4 text-cyan-400" /> Section 14 — System Infrastructure & Resource Utilization
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
                  <div className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-emerald-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-emerald-300 font-bold block truncate">Server Status</span>
                    <p className="text-xs font-black text-emerald-400 truncate">{stats.serverStatus || 'Online 200'}</p>
                    <span className="text-[9px] text-emerald-200">Express Node.js</span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-cyan-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-cyan-300 font-bold block truncate">Database Status</span>
                    <p className="text-xs font-black text-cyan-300 truncate">{stats.databaseStatus || 'PostgreSQL'}</p>
                    <span className="text-[9px] text-cyan-200">Memory Sync</span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-purple-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-purple-300 font-bold block truncate">API Status</span>
                    <p className="text-xs font-black text-purple-300 truncate">{stats.apiStatus || 'Operational'}</p>
                    <span className="text-[9px] text-purple-200">REST Endpoints</span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-blue-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-blue-300 font-bold block truncate">WebSocket Status</span>
                    <p className="text-xs font-black text-blue-300 truncate">{stats.websocketStatus || 'Connected'}</p>
                    <span className="text-[9px] text-blue-200">Live Channels</span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-amber-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-amber-300 font-bold block truncate">CPU Usage</span>
                    <p className="text-sm font-black text-amber-400">{stats.cpuUsage || '12.4%'}</p>
                    <span className="text-[9px] text-amber-200">Container VCPU</span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-teal-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-teal-300 font-bold block truncate">RAM Usage</span>
                    <p className="text-xs font-black text-teal-300 truncate">{stats.ramUsage || '284 MB'}</p>
                    <span className="text-[9px] text-teal-200">Memory Heap</span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-indigo-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-indigo-300 font-bold block truncate">Storage Usage</span>
                    <p className="text-xs font-black text-indigo-300 truncate">{stats.storageUsage || '1.2 GB'}</p>
                    <span className="text-[9px] text-indigo-200">Asset Cache</span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-emerald-500/30 space-y-1 shadow-md">
                    <span className="text-[10px] text-emerald-300 font-bold block truncate">Active Sessions</span>
                    <p className="text-sm font-black text-emerald-400">{stats.activeSessions || 18}</p>
                    <span className="text-[9px] text-emerald-200">Auth Tokens</span>
                  </div>
                </div>
              </div>

              {/* ================================================
                  SECTION 15 — LIVE NOTIFICATIONS
                 ================================================ */}
              <div className="space-y-3">
                <h3 className="text-xs font-black text-amber-300 uppercase tracking-widest flex items-center gap-2 border-b border-white/10 pb-2">
                  <Bell className="w-4 h-4 text-amber-400" /> Section 15 — Real-Time Live Event Notifications
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {stats.liveNotifications?.map((notif: any) => (
                    <div key={notif.id} className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 flex items-center justify-between text-xs shadow-md">
                      <div className="flex items-center gap-3">
                        <span className="text-lg">{notif.icon}</span>
                        <div>
                          <p className="font-extrabold text-white text-xs">{notif.text}</p>
                          <span className="text-[10px] text-slate-400 font-mono">{notif.time}</span>
                        </div>
                      </div>
                      <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                        LIVE
                      </span>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          )}

          {/* TAB 2: STAFF / USERS CENTER */}
          {activeTab === 'users' && (
            <UserStaffCenter
              users={users}
              staff={[]}
              currentUser={currentUser}
              auditLogs={auditLogs}
              onRefresh={() => loadData(false)}
              showNotification={showNotification}
              initialSubTab={selectedStaffSubTab}
            />
          )}

          {/* TAB: USER BAN & UNBAN MANAGEMENT & BAN HISTORY (SECURITY MODULE) */}
          {activeTab === 'user_bans' && (
            <UserBanCenter
              currentUser={currentUser}
              onOpenUserDetails={(u) => {
                setEditingUser(u);
                setEditFormData({
                  name: u.name,
                  email: u.email || '',
                  role: u.role,
                  vipLevel: (u.vipLevel as any) || 'none',
                  coins: u.coins || 0,
                  diamonds: u.diamonds || 0,
                  avatar: u.avatar || '',
                  bio: u.bio || '',
                  country: u.country || ''
                });
              }}
            />
          )}

          {/* TAB: CP & FRIENDSHIP MANAGEMENT CENTER */}
          {activeTab === 'connections' && (
            <ConnectionsManagementCenter
              currentUser={currentUser}
              showNotification={showNotification}
            />
          )}

          {/* TAB 3: LIVE ROOM CENTER */}
          {activeTab === 'rooms' && (
            <LiveRoomCenter
              rooms={rooms}
              showNotification={showNotification}
              onRefresh={() => loadData(false)}
              selectedSubTab={selectedRoomSubTab}
              onSubTabChange={(sub) => setSelectedRoomSubTab(sub)}
            />
          )}

          {/* TAB 4: FINANCIAL CENTER */}
          {activeTab === 'financials' && (
            <FinancialCenter showNotification={showNotification} />
          )}

          {/* TAB 5: AGENCY CENTER */}
          {activeTab === 'agency' && (
            <AgencyCenter 
              showNotification={showNotification} 
              onNavigateToCreateAgency={() => {
                setActiveTab('host_agency_create');
                if (typeof window !== 'undefined' && window.history) {
                  window.history.pushState({}, '', '/admin/host-agencies/create');
                }
              }} 
            />
          )}

          {/* TAB: WALLET CENTER */}
          {activeTab === 'wallet' && (
            <WalletCenter showNotification={showNotification} />
          )}

          {/* TAB: WITHDRAW PAYMENT METHODS CENTER */}
          {activeTab === 'withdraw_methods' && (
            <WithdrawMethodsCenter showNotification={showNotification} />
          )}

          {/* TAB: MERCHANT CENTER */}
          {activeTab === 'merchants' && (
            <MerchantCenter showNotification={showNotification} />
          )}

          {/* TAB: RECHARGE AGENT CENTER */}
          {activeTab === 'recharge_agents' && (
            <RechargeAgentCenter showNotification={showNotification} />
          )}

          {/* TAB: HOST AGENCY CREATE CENTER */}
          {activeTab === 'host_agency_create' && (
            <HostAgencyCreateCenter 
              showNotification={showNotification} 
              onNavigateToAgencies={() => {
                setActiveTab('agency');
                if (typeof window !== 'undefined' && window.history) {
                  window.history.pushState({}, '', '/admin/agencies');
                }
              }} 
            />
          )}

          {/* TAB 6: HOST CENTER */}
          {activeTab === 'host' && (
            <HostCenter showNotification={showNotification} />
          )}

          {/* TAB 7: COMMISSION CENTER */}
          {activeTab === 'commission' && (
            <CommissionCenter showNotification={showNotification} />
          )}

          {/* TAB 8: VIP CENTER */}
          {activeTab === 'vip' && (
            <VipCenter showNotification={showNotification} />
          )}

          {/* VIP / SVIP / FRAME MANAGEMENT CENTER */}
          {activeTab === 'vip_management' && (
            <VipManagementCenter
              users={users}
              currentUser={currentUser}
              onRefresh={() => loadData(true)}
              showNotification={showNotification}
            />
          )}

          {/* TAB 9: GIFT CENTER */}
          {activeTab === 'gifts' && (
            <GiftCenter showNotification={showNotification} />
          )}

          {/* TAB 9B: BANNER MANAGEMENT CENTER */}
          {activeTab === 'banners' && (
            <BannerCenter
              showNotification={showNotification}
              currentUser={currentUser}
              onRefresh={() => loadData(false)}
            />
          )}

          {/* TAB 10: MESSAGING CENTER */}
          {activeTab === 'messaging' && (
            <MessagingCenter showNotification={showNotification} />
          )}

          {/* TAB 11: FAMILY CENTER */}
          {activeTab === 'family' && (
            <FamilyCenter showNotification={showNotification} />
          )}

          {/* TAB 12: REPORTS CENTER */}
          {activeTab === 'reports' && (
            <ReportsCenter showNotification={showNotification} />
          )}

          {/* TAB 13: SETTINGS CENTER */}
          {activeTab === 'settings' && (
            <SettingsCenter 
              showNotification={showNotification} 
              onNavigateToAppearance={() => {
                setActiveTab('appearance');
                if (typeof window !== 'undefined' && window.history) {
                  window.history.pushState({}, '', '/admin/appearance');
                }
              }} 
            />
          )}

          {/* TAB: APPEARANCE SETTINGS */}
          {activeTab === 'appearance' && (
            <AppearanceCenter
              currentBackgroundColor={adminBgColor}
              previewBackgroundColor={previewBgColor}
              onPreviewChange={(color) => setPreviewBgColor(color)}
              onApplySuccess={(newColor) => {
                setAdminBgColor(newColor);
                setPreviewBgColor(newColor);
                loadData(true);
              }}
              showNotification={showNotification}
              currentUser={currentUser}
            />
          )}

          {/* TAB 14: AUDIT LOGS */}
          {activeTab === 'audit' && (
            <div className="space-y-3 animate-fadeIn">
              <h4 className="font-bold text-white text-xs">Immutable Security & Governance Ledger</h4>
              <div className="bg-white/5 backdrop-blur-xl rounded-3xl border border-white/10 overflow-hidden shadow-xl">
                <table className="w-full text-left text-xs">
                  <thead className="bg-black/40 text-slate-300 font-extrabold border-b border-white/10">
                    <tr>
                      <th className="p-3.5">Timestamp</th>
                      <th className="p-3.5">Admin ID</th>
                      <th className="p-3.5">Action Executed</th>
                      <th className="p-3.5">Target</th>
                      <th className="p-3.5">Details</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/10 font-mono text-[11px]">
                    {auditLogs.map((log) => (
                      <tr key={log.id} className="hover:bg-white/10">
                        <td className="p-3.5 text-slate-400">{new Date(log.timestamp).toLocaleTimeString()}</td>
                        <td className="p-3.5 font-bold text-amber-400">{log.performedByUserId}</td>
                        <td className="p-3.5 text-white font-sans font-bold">{log.action}</td>
                        <td className="p-3.5 text-cyan-300">{log.targetId || 'SYSTEM'}</td>
                        <td className="p-3.5 text-slate-200 font-sans">{log.details}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 15: OPENAPI CENTER */}
          {activeTab === 'api_docs' && (
            <OpenApiCenter showNotification={showNotification} />
          )}

          {/* TAB 16: COUNTRY MANAGEMENT CENTER */}
          {activeTab === 'countries' && (
            <CountryManagementCenter />
          )}
        </>
      )}
      </main>
    </div>

      {/* USER ACCOUNT EDIT MODAL */}
      {editingUser && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <form onSubmit={handleUpdateUserAccount} className="bg-[#1a0b2e]/95 backdrop-blur-2xl border border-amber-400/40 rounded-3xl p-6 w-full max-w-lg space-y-4 shadow-2xl my-8">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-amber-400/20 border border-amber-400/40 flex items-center justify-center">
                  <UserCheck className="w-5 h-5 text-amber-300" />
                </div>
                <div>
                  <h3 className="font-black text-white text-base">Edit Dashboard User Account</h3>
                  <p className="text-[10px] text-slate-400 font-mono">UID: {editingUser.uid || editingUser.id}</p>
                </div>
              </div>
              <button type="button" onClick={() => setEditingUser(null)} className="text-slate-400 hover:text-white font-bold text-lg p-1">✕</button>
            </div>

            {/* Avatar Preview & Name Header */}
            <div className="flex items-center gap-3 p-3 rounded-2xl bg-black/40 border border-white/10">
              <img src={editFormData.avatar || editingUser.avatar} alt="Avatar" className="w-12 h-12 rounded-full object-cover border-2 border-amber-400/50" />
              <div className="flex-1 min-w-0">
                <p className="text-xs font-black text-white truncate">{editFormData.name || editingUser.name}</p>
                <p className="text-[10px] text-slate-400 truncate">{editFormData.email || editingUser.email}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {/* Name */}
              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={editFormData.name}
                  onChange={(e) => setEditFormData({ ...editFormData, name: e.target.value })}
                  className="w-full bg-black/40 text-white text-xs px-3.5 py-2.5 rounded-xl border border-white/10 font-bold focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* Email */}
              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  value={editFormData.email}
                  onChange={(e) => setEditFormData({ ...editFormData, email: e.target.value })}
                  className="w-full bg-black/40 text-white text-xs px-3.5 py-2.5 rounded-xl border border-white/10 font-bold focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* System Role */}
              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">Hierarchy Role</label>
                <select
                  value={editFormData.role}
                  onChange={(e) => setEditFormData({ ...editFormData, role: e.target.value as any })}
                  className="w-full bg-black/40 text-white text-xs px-3.5 py-2.5 rounded-xl border border-white/10 font-bold capitalize focus:outline-none focus:border-amber-400"
                >
                  {roles.map(r => (
                    <option key={r} value={r} className="bg-[#1a0b2e] text-white capitalize">{r.replace('_', ' ').toUpperCase()}</option>
                  ))}
                </select>
              </div>

              {/* VIP Level */}
              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">VIP Tier</label>
                <select
                  value={editFormData.vipLevel}
                  onChange={(e) => setEditFormData({ ...editFormData, vipLevel: e.target.value as any })}
                  className="w-full bg-black/40 text-white text-xs px-3.5 py-2.5 rounded-xl border border-white/10 font-bold uppercase focus:outline-none focus:border-amber-400"
                >
                  <option value="none" className="bg-[#1a0b2e] text-white">NONE</option>
                  <option value="vip" className="bg-[#1a0b2e] text-amber-300">VIP TIER</option>
                  <option value="svip" className="bg-[#1a0b2e] text-purple-300">SUPER VIP (SVIP)</option>
                </select>
              </div>

              {/* Coins Balance */}
              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">Coins Balance 🪙</label>
                <input
                  type="number"
                  min="0"
                  value={editFormData.coins}
                  onChange={(e) => setEditFormData({ ...editFormData, coins: parseInt(e.target.value) || 0 })}
                  className="w-full bg-black/40 text-white text-xs px-3.5 py-2.5 rounded-xl border border-white/10 font-mono font-bold focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* Diamonds Balance */}
              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">Diamonds Balance 💎</label>
                <input
                  type="number"
                  min="0"
                  value={editFormData.diamonds}
                  onChange={(e) => setEditFormData({ ...editFormData, diamonds: parseInt(e.target.value) || 0 })}
                  className="w-full bg-black/40 text-white text-xs px-3.5 py-2.5 rounded-xl border border-white/10 font-mono font-bold focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>

            {/* Country */}
            <div>
              <label className="block text-[11px] font-bold text-slate-300 mb-1">Country / Region</label>
              <input
                type="text"
                value={editFormData.country}
                onChange={(e) => setEditFormData({ ...editFormData, country: e.target.value })}
                placeholder="e.g. United States, UAE, Egypt"
                className="w-full bg-black/40 text-white text-xs px-3.5 py-2.5 rounded-xl border border-white/10 font-bold focus:outline-none focus:border-amber-400"
              />
            </div>

            {/* Avatar URL */}
            <div>
              <label className="block text-[11px] font-bold text-slate-300 mb-1">Avatar Image URL</label>
              <input
                type="text"
                value={editFormData.avatar}
                onChange={(e) => setEditFormData({ ...editFormData, avatar: e.target.value })}
                placeholder="https://images.unsplash.com/..."
                className="w-full bg-black/40 text-white text-xs px-3.5 py-2.5 rounded-xl border border-white/10 font-mono text-[11px] focus:outline-none focus:border-amber-400"
              />
            </div>

            {/* Bio */}
            <div>
              <label className="block text-[11px] font-bold text-slate-300 mb-1">Bio / Staff Notes</label>
              <textarea
                rows={2}
                value={editFormData.bio}
                onChange={(e) => setEditFormData({ ...editFormData, bio: e.target.value })}
                placeholder="User bio or administrative notes..."
                className="w-full bg-black/40 text-white text-xs px-3.5 py-2.5 rounded-xl border border-white/10 focus:outline-none focus:border-amber-400 resize-none"
              />
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setEditingUser(null)}
                className="flex-1 py-2.5 bg-white/10 text-slate-300 rounded-xl font-bold text-xs border border-white/10 hover:bg-white/20 transition-all"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmittingUser}
                className="flex-1 py-2.5 bg-gradient-to-r from-amber-400 to-amber-500 text-black font-black text-xs rounded-xl shadow-lg hover:from-amber-300 hover:to-amber-400 transition-all disabled:opacity-50 flex items-center justify-center gap-1.5"
              >
                {isSubmittingUser ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Saving...
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-3.5 h-3.5" /> Save User Account
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  </div>
);
};
