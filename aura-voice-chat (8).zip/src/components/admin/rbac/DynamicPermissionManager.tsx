import React, { useState, useEffect, useMemo } from 'react';
import {
  Shield, Lock, Key, Check, CheckSquare, Square, RefreshCw, Sparkles,
  AlertTriangle, AlertCircle, Save, RotateCcw, Plus, Search, Layers,
  UserCheck, Crown, ChevronDown, ChevronRight, X, Info, Sliders,
  ShieldCheck, Eye, Edit3, Users, Settings, Tag, ShieldAlert
} from 'lucide-react';
import {
  User, UserRole, PermissionModule, SystemPermission,
  RolePermissionConfig, StaffPermissionOverride, PermissionLevel
} from '../../../types';
import { ApiClient } from '../../../lib/api';
import { ROLE_HIERARCHY } from '../../../lib/rbacDefaults';
import { ProfileIdBadge } from '../../common/ProfileIdBadge';

interface DynamicPermissionManagerProps {
  currentUser: User | null;
  users: User[];
  onClose?: () => void;
  showNotification: (msg: string) => void;
  onRefreshParent?: () => void;
}

const LEVEL_COLORS: Record<PermissionLevel, { bg: string; text: string; border: string }> = {
  NONE: { bg: 'bg-slate-800/60', text: 'text-slate-400', border: 'border-slate-700' },
  VIEW: { bg: 'bg-blue-500/15', text: 'text-blue-300', border: 'border-blue-500/30' },
  OPERATE: { bg: 'bg-emerald-500/15', text: 'text-emerald-300', border: 'border-emerald-500/30' },
  MANAGE: { bg: 'bg-amber-500/15', text: 'text-amber-300', border: 'border-amber-500/30' },
  FULL: { bg: 'bg-purple-500/20', text: 'text-purple-300', border: 'border-purple-500/40' }
};

const LEVEL_OPTIONS: PermissionLevel[] = ['NONE', 'VIEW', 'OPERATE', 'MANAGE', 'FULL'];

const ALL_ROLES: { id: UserRole; name: string; rank: number }[] = [
  { id: 'ceo', name: 'CEO (Chief Executive Officer)', rank: 100 },
  { id: 'gm', name: 'General Manager (GM)', rank: 90 },
  { id: 'manager', name: 'Operations Manager', rank: 80 },
  { id: 'super_admin', name: 'Super Admin', rank: 70 },
  { id: 'admin', name: 'Admin', rank: 60 },
  { id: 'bd', name: 'BD (Business Development)', rank: 50 },
  { id: 'agency', name: 'Agency Partner', rank: 40 },
  { id: 'host', name: 'Host / Broadcaster', rank: 30 },
  { id: 'official_staff', name: 'Official Staff', rank: 25 },
  { id: 'user', name: 'Standard User', rank: 10 }
];

export const DynamicPermissionManager: React.FC<DynamicPermissionManagerProps> = ({
  currentUser,
  users,
  onClose,
  showNotification,
  onRefreshParent
}) => {
  const isCeo = currentUser?.role === 'ceo';
  const execRank = currentUser ? (ROLE_HIERARCHY[currentUser.role] || 0) : 0;

  // Mode: edit role baseline OR edit user overrides
  const [editTargetType, setEditTargetType] = useState<'role' | 'staff'>('role');
  const [selectedRoleId, setSelectedRoleId] = useState<UserRole>('super_admin');
  const [selectedStaffUserId, setSelectedStaffUserId] = useState<string>('');

  // Loaded metadata from backend
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isResetting, setIsResetting] = useState(false);

  const [modules, setModules] = useState<PermissionModule[]>([]);
  const [permissions, setPermissions] = useState<SystemPermission[]>([]);
  const [rolesConfig, setRolesConfig] = useState<Record<string, RolePermissionConfig>>({});
  const [staffOverrides, setStaffOverrides] = useState<Record<string, StaffPermissionOverride>>({});

  // Active state being edited
  const [currentPermissions, setCurrentPermissions] = useState<Record<string, PermissionLevel>>({});
  const [currentCanGrantRoles, setCurrentCanGrantRoles] = useState<string[]>([]);
  const [activeModuleKey, setActiveModuleKey] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [staffSearchQuery, setStaffSearchQuery] = useState('');

  // Modal for creating custom permission
  const [showCreatePermModal, setShowCreatePermModal] = useState(false);
  const [newPermData, setNewPermData] = useState({
    key: '',
    name: '',
    module: 'system',
    description: '',
    defaultLevel: 'VIEW' as PermissionLevel,
    isCeoProtected: false
  });

  // Modal for creating custom module
  const [showCreateModModal, setShowCreateModModal] = useState(false);
  const [newModData, setNewModData] = useState({
    key: '',
    name: '',
    description: '',
    icon: 'Layers'
  });

  // Track if changes have been made
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  // Load RBAC metadata from server
  const loadRbacMetadata = async () => {
    try {
      setIsLoading(true);
      const res = await ApiClient.getRbacMetadata();
      setModules(res.modules || []);
      setPermissions(res.permissions || []);

      const rolesMap: Record<string, RolePermissionConfig> = {};
      (res.roles || []).forEach(r => {
        rolesMap[r.roleId] = r;
      });
      setRolesConfig(rolesMap);

      const overridesMap: Record<string, StaffPermissionOverride> = {};
      (res.overrides || []).forEach(o => {
        overridesMap[o.userId] = o;
      });
      setStaffOverrides(overridesMap);
    } catch (err: any) {
      console.error('Failed to fetch RBAC metadata:', err);
      showNotification(`⚠️ Failed to load RBAC data: ${err.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadRbacMetadata();
  }, []);

  // Update working state when target role changes
  useEffect(() => {
    if (editTargetType === 'role') {
      const cfg = rolesConfig[selectedRoleId];
      if (cfg) {
        setCurrentPermissions({ ...cfg.permissions });
        setCurrentCanGrantRoles([...(cfg.canGrantRoles || [])]);
      } else {
        setCurrentPermissions({});
        setCurrentCanGrantRoles([]);
      }
      setHasUnsavedChanges(false);
    }
  }, [selectedRoleId, rolesConfig, editTargetType]);

  // Update working state when target staff changes
  useEffect(() => {
    if (editTargetType === 'staff' && selectedStaffUserId) {
      const targetUser = users.find(u => u.id === selectedStaffUserId);
      if (targetUser) {
        const staffRole = (targetUser.staffIdentity?.role || targetUser.role) as UserRole;
        const roleBaseline = rolesConfig[staffRole]?.permissions || {};
        const staffOvr = staffOverrides[selectedStaffUserId]?.overrides || {};
        
        // Combined effective permissions for the staff
        const combined: Record<string, PermissionLevel> = { ...roleBaseline, ...staffOvr };
        setCurrentPermissions(combined);
        setHasUnsavedChanges(false);
      }
    }
  }, [selectedStaffUserId, staffOverrides, rolesConfig, editTargetType, users]);

  // Check if current user can edit the selected role
  const canEditSelectedRole = useMemo(() => {
    if (isCeo) return true;
    if (editTargetType === 'role') {
      const targetRank = ROLE_HIERARCHY[selectedRoleId] || 0;
      return execRank > targetRank;
    }
    if (editTargetType === 'staff' && selectedStaffUserId) {
      const targetUser = users.find(u => u.id === selectedStaffUserId);
      if (!targetUser) return false;
      const targetRole = (targetUser.staffIdentity?.role || targetUser.role) as UserRole;
      if (targetRole === 'ceo') return false;
      const targetRank = ROLE_HIERARCHY[targetRole] || 0;
      return execRank > targetRank;
    }
    return false;
  }, [isCeo, editTargetType, selectedRoleId, selectedStaffUserId, execRank, users]);

  // Filtered staff list for the staff selector
  const staffUsersList = useMemo(() => {
    return users.filter(u => {
      const isStaffMember = ['ceo', 'gm', 'manager', 'super_admin', 'admin', 'bd', 'agency', 'host', 'official_staff'].includes(u.role) ||
        Boolean(u.staffIdentity);
      if (!isStaffMember) return false;
      if (staffSearchQuery.trim()) {
        const q = staffSearchQuery.toLowerCase();
        return u.name.toLowerCase().includes(q) ||
          u.uid.toLowerCase().includes(q) ||
          (u.staffIdentity?.staffId || '').toLowerCase().includes(q) ||
          u.role.toLowerCase().includes(q);
      }
      return true;
    });
  }, [users, staffSearchQuery]);

  // Set default staff when switching to staff mode
  useEffect(() => {
    if (editTargetType === 'staff' && !selectedStaffUserId && staffUsersList.length > 0) {
      // Pick first non-CEO staff
      const nonCeo = staffUsersList.find(u => u.role !== 'ceo') || staffUsersList[0];
      if (nonCeo) setSelectedStaffUserId(nonCeo.id);
    }
  }, [editTargetType, selectedStaffUserId, staffUsersList]);

  // Filter permissions by module and search query
  const filteredPermissions = useMemo(() => {
    return permissions.filter(p => {
      if (activeModuleKey !== 'all' && p.module !== activeModuleKey) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return p.key.toLowerCase().includes(q) ||
          p.name.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.module.toLowerCase().includes(q);
      }
      return true;
    });
  }, [permissions, activeModuleKey, searchQuery]);

  // Handle setting a single permission level
  const handleSetPermissionLevel = (permKey: string, level: PermissionLevel) => {
    if (!canEditSelectedRole) {
      showNotification('⛔ You do not have permission to modify this role.');
      return;
    }

    // CEO safeguard
    if (editTargetType === 'role' && selectedRoleId === 'ceo') {
      if (permKey === '*' || permKey === 'users:edit_uid') {
        showNotification('🛡️ CEO Safeguard: CEO must retain full access and exclusive User ID authority.');
        return;
      }
    }

    // Protected permissions safeguard for non-CEO
    if (!isCeo && permKey === 'users:edit_uid') {
      showNotification('🔒 Exclusive Security Rule: Only the CEO can grant Edit User UID authority.');
      return;
    }

    setCurrentPermissions(prev => ({
      ...prev,
      [permKey]: level
    }));
    setHasUnsavedChanges(true);
  };

  // Bulk actions for visible permissions
  const handleBulkSetLevel = (level: PermissionLevel) => {
    if (!canEditSelectedRole) return;
    setCurrentPermissions(prev => {
      const next = { ...prev };
      filteredPermissions.forEach(p => {
        // CEO protection
        if (!isCeo && p.key === 'users:edit_uid') return;
        if (selectedRoleId === 'ceo' && (p.key === '*' || p.key === 'users:edit_uid')) return;
        next[p.key] = level;
      });
      return next;
    });
    setHasUnsavedChanges(true);
  };

  // Toggle role grant authority
  const handleToggleCanGrant = (roleToToggle: UserRole) => {
    if (!canEditSelectedRole) return;
    if (selectedRoleId === 'ceo') {
      showNotification('🛡️ CEO has authority over all roles.');
      return;
    }

    setCurrentCanGrantRoles(prev => {
      const exists = prev.includes(roleToToggle);
      const next = exists ? prev.filter(r => r !== roleToToggle) : [...prev, roleToToggle];
      return next;
    });
    setHasUnsavedChanges(true);
  };

  // Save changes to backend
  const handleSavePermissions = async () => {
    if (!canEditSelectedRole) {
      showNotification('⛔ You do not have permission to save changes for this target.');
      return;
    }

    try {
      setIsSaving(true);
      if (editTargetType === 'role') {
        const updated = await ApiClient.updateRbacRolePermissions(selectedRoleId, {
          permissions: currentPermissions,
          canGrantRoles: currentCanGrantRoles,
          description: rolesConfig[selectedRoleId]?.description
        });

        setRolesConfig(prev => ({
          ...prev,
          [selectedRoleId]: updated
        }));

        showNotification(`✅ Successfully saved and synchronized permissions for role: ${updated.roleName}`);
      } else {
        // Saving Staff Overrides
        const targetUser = users.find(u => u.id === selectedStaffUserId);
        if (!targetUser) throw new Error('Selected staff user not found');
        const targetRole = (targetUser.staffIdentity?.role || targetUser.role) as UserRole;
        const roleBaseline = rolesConfig[targetRole]?.permissions || {};

        // Calculate only the delta overrides
        const deltaOverrides: Record<string, PermissionLevel> = {};
        (Object.entries(currentPermissions) as [string, PermissionLevel][]).forEach(([key, lvl]) => {
          if (lvl !== roleBaseline[key]) {
            deltaOverrides[key] = lvl;
          }
        });

        const res = await ApiClient.updateStaffRbacOverrides(selectedStaffUserId, {
          overrides: deltaOverrides,
          notes: `Custom permissions adjusted by ${currentUser?.name || 'Administrator'}`
        });

        setStaffOverrides(prev => ({
          ...prev,
          [selectedStaffUserId]: res.override
        }));

        showNotification(`✅ Staff permission overrides saved for ${targetUser.name} (${targetUser.uid})`);
      }

      setHasUnsavedChanges(false);
      if (onRefreshParent) onRefreshParent();
    } catch (err: any) {
      showNotification(`❌ Error saving permissions: ${err.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  // Reset to default
  const handleResetToDefaults = async () => {
    if (editTargetType === 'role') {
      if (!isCeo) {
        showNotification('⛔ Only the CEO can reset role configurations to factory defaults.');
        return;
      }
      if (!window.confirm(`Are you sure you want to reset role "${selectedRoleId.toUpperCase()}" to platform factory defaults?`)) {
        return;
      }

      try {
        setIsResetting(true);
        const resetConfig = await ApiClient.resetRbacRoleToDefault(selectedRoleId);
        setRolesConfig(prev => ({
          ...prev,
          [selectedRoleId]: resetConfig
        }));
        setCurrentPermissions({ ...resetConfig.permissions });
        setCurrentCanGrantRoles([...(resetConfig.canGrantRoles || [])]);
        setHasUnsavedChanges(false);
        showNotification(`✅ Role "${resetConfig.roleName}" reset to factory defaults.`);
        if (onRefreshParent) onRefreshParent();
      } catch (err: any) {
        showNotification(`❌ Reset failed: ${err.message}`);
      } finally {
        setIsResetting(false);
      }
    } else {
      // Clear staff overrides
      if (!window.confirm(`Revert this staff member to standard role baseline permissions?`)) return;
      try {
        setIsResetting(true);
        await ApiClient.clearStaffRbacOverrides(selectedStaffUserId);
        setStaffOverrides(prev => {
          const next = { ...prev };
          delete next[selectedStaffUserId];
          return next;
        });

        const targetUser = users.find(u => u.id === selectedStaffUserId);
        const targetRole = (targetUser?.staffIdentity?.role || targetUser?.role) as UserRole;
        const baseline = rolesConfig[targetRole]?.permissions || {};
        setCurrentPermissions({ ...baseline });
        setHasUnsavedChanges(false);
        showNotification(`✅ Reverted staff member to default role permissions.`);
        if (onRefreshParent) onRefreshParent();
      } catch (err: any) {
        showNotification(`❌ Clear overrides failed: ${err.message}`);
      } finally {
        setIsResetting(false);
      }
    }
  };

  // Handle creating custom permission
  const handleCreatePermissionSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPermData.key.trim() || !newPermData.name.trim()) {
      showNotification('⚠️ Permission key and name are required.');
      return;
    }
    try {
      const created = await ApiClient.createRbacPermission(newPermData);
      setPermissions(prev => [...prev, created]);
      setShowCreatePermModal(false);
      setNewPermData({
        key: '',
        name: '',
        module: 'system',
        description: '',
        defaultLevel: 'VIEW',
        isCeoProtected: false
      });
      showNotification(`✅ Custom permission "${created.name}" created and synced with Firestore!`);
    } catch (err: any) {
      showNotification(`❌ Failed to create permission: ${err.message}`);
    }
  };

  // Handle creating custom module
  const handleCreateModuleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newModData.key.trim() || !newModData.name.trim()) {
      showNotification('⚠️ Module key and name are required.');
      return;
    }
    try {
      const created = await ApiClient.createRbacModule(newModData);
      setModules(prev => [...prev, created]);
      setShowCreateModModal(false);
      setNewModData({
        key: '',
        name: '',
        description: '',
        icon: 'Layers'
      });
      showNotification(`✅ Custom module "${created.name}" created successfully!`);
    } catch (err: any) {
      showNotification(`❌ Failed to create module: ${err.message}`);
    }
  };

  const selectedTargetUser = useMemo(() => {
    return users.find(u => u.id === selectedStaffUserId);
  }, [users, selectedStaffUserId]);

  const activeRoleConfig = rolesConfig[selectedRoleId];

  return (
    <div className="space-y-5 animate-fadeIn">
      {/* TOP NOTIFICATION & CEO SAFEGUARD BANNER */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-purple-950/80 via-slate-900/90 to-amber-950/70 border border-amber-400/40 backdrop-blur-md shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Crown className="w-5 h-5 text-amber-400 animate-pulse" />
            <h3 className="text-sm font-black text-white tracking-wide uppercase">
              Dynamic RBAC Permission Management System
            </h3>
            <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/30 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" /> Real-Time Database Sync
            </span>
          </div>
          <p className="text-xs text-slate-300 max-w-2xl">
            Live database-backed permission editor. Any changes saved here immediately grant or revoke real operational capabilities across all Admin Panel centers and API endpoints.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {isCeo && (
            <button
              onClick={() => setShowCreatePermModal(true)}
              className="px-3 py-1.5 bg-purple-600/80 hover:bg-purple-500 text-white rounded-xl font-bold text-xs border border-purple-400/40 flex items-center gap-1.5 transition-all shadow"
            >
              <Plus className="w-3.5 h-3.5" /> Add Permission
            </button>
          )}
          {isCeo && (
            <button
              onClick={() => setShowCreateModModal(true)}
              className="px-3 py-1.5 bg-indigo-600/80 hover:bg-indigo-500 text-white rounded-xl font-bold text-xs border border-indigo-400/40 flex items-center gap-1.5 transition-all shadow"
            >
              <Layers className="w-3.5 h-3.5" /> Add Module
            </button>
          )}
          {onClose && (
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-all"
              title="Close Panel"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* TARGET SELECTION CONTROLS (ROLE BASELINE vs INDIVIDUAL STAFF OVERRIDE) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* EDIT TARGET TYPE TOGGLE & ROLE SELECTOR */}
        <div className="lg:col-span-2 p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md space-y-3">
          <div className="flex items-center justify-between border-b border-white/10 pb-2.5">
            <div className="flex items-center gap-2">
              <Sliders className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-black text-white uppercase tracking-wider">Select Permission Target</span>
            </div>
            
            {/* TOGGLE MODE: ROLE BASELINE vs STAFF MEMBER OVERRIDE */}
            <div className="flex bg-black/40 p-1 rounded-xl border border-white/10 text-xs">
              <button
                onClick={() => setEditTargetType('role')}
                className={`px-3 py-1 rounded-lg font-bold transition-all flex items-center gap-1.5 ${
                  editTargetType === 'role' ? 'bg-amber-400 text-black font-black shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Shield className="w-3 h-3" /> Role Baseline
              </button>
              <button
                onClick={() => setEditTargetType('staff')}
                className={`px-3 py-1 rounded-lg font-bold transition-all flex items-center gap-1.5 ${
                  editTargetType === 'staff' ? 'bg-amber-400 text-black font-black shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Users className="w-3 h-3" /> Specific Staff Member
              </button>
            </div>
          </div>

          {/* TARGET SELECTION BODY */}
          {editTargetType === 'role' ? (
            <div className="space-y-3">
              <div className="flex flex-wrap gap-1.5">
                {ALL_ROLES.map(r => {
                  const isSelected = selectedRoleId === r.id;
                  const rank = ROLE_HIERARCHY[r.id] || 0;
                  const isLocked = !isCeo && rank >= execRank;
                  return (
                    <button
                      key={r.id}
                      onClick={() => setSelectedRoleId(r.id)}
                      disabled={isLocked}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                        isSelected
                          ? 'bg-amber-400 text-black font-black shadow-lg scale-105'
                          : isLocked
                          ? 'bg-white/5 text-slate-500 opacity-50 cursor-not-allowed'
                          : 'bg-black/40 text-slate-300 hover:bg-white/10 hover:text-white border border-white/5'
                      }`}
                    >
                      {r.id === 'ceo' && <Crown className="w-3 h-3 text-amber-500" />}
                      {r.name.split(' ')[0]}
                      <span className="text-[10px] opacity-70">({rank})</span>
                      {isLocked && <Lock className="w-2.5 h-2.5 text-slate-500" />}
                    </button>
                  );
                })}
              </div>

              {activeRoleConfig && (
                <div className="p-3 bg-black/40 rounded-xl border border-white/10 flex items-center justify-between text-xs">
                  <div>
                    <h4 className="font-bold text-white flex items-center gap-2">
                      Editing Role: <span className="text-amber-300 font-black">{activeRoleConfig.roleName}</span>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-white/10 text-slate-300 font-mono">Rank {activeRoleConfig.rank}</span>
                    </h4>
                    <p className="text-[11px] text-slate-400 mt-0.5">{activeRoleConfig.description}</p>
                  </div>
                  {activeRoleConfig.updatedAt && (
                    <span className="text-[10px] text-slate-400 font-mono">
                      Last Updated: {new Date(activeRoleConfig.updatedAt).toLocaleDateString()} by {activeRoleConfig.updatedBy || 'System'}
                    </span>
                  )}
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-3">
              {/* STAFF SEARCH & SELECTOR */}
              <div className="flex items-center gap-2">
                <div className="relative flex-1">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={staffSearchQuery}
                    onChange={(e) => setStaffSearchQuery(e.target.value)}
                    placeholder="Search staff by Name, UID, Staff ID, or Role..."
                    className="w-full bg-black/50 text-white text-xs pl-8 pr-3 py-2 rounded-xl border border-white/10 focus:outline-none focus:border-amber-400"
                  />
                </div>
                <span className="text-[11px] text-slate-400">
                  {staffUsersList.length} staff found
                </span>
              </div>

              {/* STAFF SCROLLABLE HORIZONTAL OR GRID LIST */}
              <div className="flex gap-2 overflow-x-auto pb-2 pt-1 max-h-28">
                {staffUsersList.map(stf => {
                  const isSelected = selectedStaffUserId === stf.id;
                  const stfRole = (stf.staffIdentity?.role || stf.role) as UserRole;
                  const hasOvr = Boolean(staffOverrides[stf.id]);
                  return (
                    <button
                      key={stf.id}
                      onClick={() => setSelectedStaffUserId(stf.id)}
                      className={`px-3 py-2 rounded-xl text-left border shrink-0 transition-all flex items-center gap-2.5 ${
                        isSelected
                          ? 'bg-amber-400/20 border-amber-400 text-white shadow-md'
                          : 'bg-black/40 border-white/10 text-slate-300 hover:bg-white/5'
                      }`}
                    >
                      <img src={stf.avatar} alt="Avatar" className="w-7 h-7 rounded-full object-cover border border-amber-400" />
                      <div className="text-xs leading-tight">
                        <p className="font-bold text-white flex items-center gap-1">
                          {stf.name}
                          {hasOvr && <span className="w-1.5 h-1.5 rounded-full bg-amber-400" title="Has custom overrides" />}
                        </p>
                        <p className="text-[10px] text-slate-400 font-mono">UID: {stf.uid}</p>
                        <span className="text-[9px] uppercase px-1.5 py-0.2 rounded bg-white/10 text-amber-300 font-black">
                          {stfRole}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>

              {selectedTargetUser && (
                <div className="p-3 bg-black/40 rounded-xl border border-white/10 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-3">
                    <img src={selectedTargetUser.avatar} alt="Avatar" className="w-9 h-9 rounded-xl object-cover border border-amber-400" />
                    <div>
                      <h4 className="font-bold text-white flex items-center gap-1.5">
                        Selected: <span className="text-amber-300 font-black">{selectedTargetUser.name}</span>
                        <ProfileIdBadge uid={selectedTargetUser.uid} size="xs" />
                      </h4>
                      <p className="text-[11px] text-slate-400">
                        Baseline Role: <strong className="text-white uppercase">{selectedTargetUser.staffIdentity?.role || selectedTargetUser.role}</strong>
                        {staffOverrides[selectedStaffUserId] && (
                          <span className="ml-2 text-amber-300 font-bold">
                            ({Object.keys(staffOverrides[selectedStaffUserId].overrides).length} custom overrides active)
                          </span>
                        )}
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* ROLE GRANT AUTHORITY CONFIGURATION */}
        <div className="p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md space-y-2.5">
          <div className="flex items-center justify-between border-b border-white/10 pb-2">
            <span className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-1.5">
              <UserCheck className="w-3.5 h-3.5 text-amber-400" /> Role Grant Authority
            </span>
            <span className="text-[10px] text-slate-400">Roles this level can assign</span>
          </div>

          <p className="text-[11px] text-slate-300">
            Define which lower roles can be granted or assigned by users holding this permission level:
          </p>

          <div className="flex flex-wrap gap-1.5 pt-1">
            {ALL_ROLES.filter(r => r.id !== 'ceo').map(r => {
              const isGranted = currentCanGrantRoles.includes(r.id) || currentCanGrantRoles.includes('*');
              const targetRank = ROLE_HIERARCHY[selectedRoleId] || 0;
              const subRank = ROLE_HIERARCHY[r.id] || 0;
              const isDisallowed = !isCeo && subRank >= targetRank;

              return (
                <button
                  key={r.id}
                  onClick={() => handleToggleCanGrant(r.id)}
                  disabled={isDisallowed || selectedRoleId === 'ceo'}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1 ${
                    isGranted
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'bg-black/40 text-slate-400 border border-white/10 hover:text-white'
                  } ${isDisallowed ? 'opacity-30 cursor-not-allowed' : ''}`}
                >
                  {isGranted ? <Check className="w-3 h-3 text-emerald-400" /> : <Plus className="w-3 h-3" />}
                  {r.name.split(' ')[0]}
                </button>
              );
            })}
          </div>

          {selectedRoleId === 'ceo' && (
            <p className="text-[10px] text-amber-300 italic pt-1">
              * The CEO inherently possesses universal role granting authority across all positions.
            </p>
          )}
        </div>
      </div>

      {/* SEARCH, MODULE FILTERS & BULK ACTIONS TOOLBAR */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 rounded-2xl bg-white/5 border border-white/10">
        {/* MODULE TABS */}
        <div className="flex flex-wrap gap-1.5">
          <button
            onClick={() => setActiveModuleKey('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeModuleKey === 'all'
                ? 'bg-amber-400 text-black font-black shadow'
                : 'bg-black/40 text-slate-300 hover:bg-white/10 hover:text-white'
            }`}
          >
            All Modules ({permissions.length})
          </button>
          {modules.map(mod => {
            const count = permissions.filter(p => p.module === mod.key).length;
            const isSelected = activeModuleKey === mod.key;
            return (
              <button
                key={mod.id}
                onClick={() => setActiveModuleKey(mod.key)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-amber-400 text-black font-black shadow'
                    : 'bg-black/40 text-slate-300 hover:bg-white/10 hover:text-white'
                }`}
              >
                {mod.name}
                <span className="text-[10px] opacity-70">({count})</span>
              </button>
            );
          })}
        </div>

        {/* SEARCH & QUICK PRESET ACTIONS */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search permissions..."
              className="bg-black/50 text-white text-xs pl-8 pr-3 py-1.5 rounded-xl border border-white/10 focus:outline-none focus:border-amber-400 w-44"
            />
          </div>

          {/* BULK SHORTCUTS */}
          <div className="flex items-center gap-1 bg-black/40 p-1 rounded-xl border border-white/10 text-xs">
            <button
              onClick={() => handleBulkSetLevel('VIEW')}
              disabled={!canEditSelectedRole}
              className="px-2 py-1 bg-blue-500/10 hover:bg-blue-500/20 text-blue-300 rounded font-bold text-[10px] transition-all disabled:opacity-40"
              title="Set all visible to VIEW"
            >
              All View
            </button>
            <button
              onClick={() => handleBulkSetLevel('OPERATE')}
              disabled={!canEditSelectedRole}
              className="px-2 py-1 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 rounded font-bold text-[10px] transition-all disabled:opacity-40"
              title="Set all visible to OPERATE"
            >
              All Operate
            </button>
            <button
              onClick={() => handleBulkSetLevel('FULL')}
              disabled={!canEditSelectedRole}
              className="px-2 py-1 bg-purple-500/10 hover:bg-purple-500/20 text-purple-300 rounded font-bold text-[10px] transition-all disabled:opacity-40"
              title="Set all visible to FULL"
            >
              All Full
            </button>
            <button
              onClick={() => handleBulkSetLevel('NONE')}
              disabled={!canEditSelectedRole}
              className="px-2 py-1 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 rounded font-bold text-[10px] transition-all disabled:opacity-40"
              title="Revoke all visible"
            >
              Revoke All
            </button>
          </div>
        </div>
      </div>

      {/* PERMISSION CHECKLIST & LEVEL SELECTOR MATRIX */}
      <div className="p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md space-y-3">
        <div className="flex items-center justify-between text-xs text-slate-400 border-b border-white/10 pb-2">
          <span>System Permission Capability & Scope</span>
          <span>Permission Level Assignment</span>
        </div>

        <div className="space-y-2.5 max-h-[480px] overflow-y-auto pr-1">
          {filteredPermissions.map(perm => {
            const currentLevel = currentPermissions[perm.key] || 'NONE';
            const isProtected = perm.isCeoProtected || perm.key === 'users:edit_uid';
            const isCeoRow = selectedRoleId === 'ceo';
            const isLocked = (!isCeo && isProtected) || !canEditSelectedRole || (isCeoRow && (perm.key === '*' || perm.key === 'users:edit_uid'));

            return (
              <div
                key={perm.id}
                className={`p-3 rounded-xl border transition-all flex flex-wrap items-center justify-between gap-3 ${
                  currentLevel !== 'NONE'
                    ? 'bg-black/50 border-white/15'
                    : 'bg-black/30 border-white/5 opacity-75'
                }`}
              >
                {/* LEFT: PERMISSION INFO */}
                <div className="space-y-1 max-w-lg">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white text-xs flex items-center gap-1.5">
                      {perm.name}
                      {isProtected && (
                        <span className="px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 text-[9px] font-black border border-amber-500/40 flex items-center gap-1">
                          <Crown className="w-2.5 h-2.5" /> CEO Exclusive
                        </span>
                      )}
                      {perm.isCustom && (
                        <span className="px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300 text-[9px] font-bold border border-purple-500/40">
                          Custom
                        </span>
                      )}
                    </span>
                    <span className="text-[10px] font-mono text-slate-400 bg-white/5 px-2 py-0.5 rounded">
                      {perm.key}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-300">{perm.description}</p>
                </div>

                {/* RIGHT: LEVEL SELECTOR BUTTONS */}
                <div className="flex items-center gap-1">
                  {LEVEL_OPTIONS.map(lvl => {
                    const isSelected = currentLevel === lvl;
                    const style = LEVEL_COLORS[lvl];
                    return (
                      <button
                        key={lvl}
                        onClick={() => handleSetPermissionLevel(perm.key, lvl)}
                        disabled={isLocked}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold border transition-all ${
                          isSelected
                            ? `${style.bg} ${style.text} ${style.border} shadow-md scale-105`
                            : 'bg-black/40 text-slate-400 border-white/5 hover:bg-white/10 hover:text-slate-200'
                        } ${isLocked ? 'opacity-40 cursor-not-allowed' : ''}`}
                      >
                        {lvl}
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })}

          {filteredPermissions.length === 0 && (
            <div className="p-8 text-center text-slate-400 text-xs space-y-2">
              <ShieldAlert className="w-8 h-8 text-amber-400 mx-auto opacity-60" />
              <p>No permissions match your search or filter criteria.</p>
            </div>
          )}
        </div>
      </div>

      {/* FOOTER ACTIONS BAR: SAVE & RESET */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
        <div className="flex items-center gap-2 text-xs">
          {hasUnsavedChanges ? (
            <span className="flex items-center gap-1.5 text-amber-300 font-bold">
              <AlertCircle className="w-4 h-4 text-amber-400 animate-bounce" />
              Unsaved changes detected. Click "Save Permissions" to persist to database.
            </span>
          ) : (
            <span className="flex items-center gap-1.5 text-slate-400">
              <Check className="w-4 h-4 text-emerald-400" />
              All permission matrices synchronized with server and database.
            </span>
          )}
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleResetToDefaults}
            disabled={isResetting || !canEditSelectedRole}
            className="px-4 py-2 bg-white/10 hover:bg-white/20 text-slate-200 hover:text-white rounded-xl font-bold text-xs transition-all flex items-center gap-1.5 disabled:opacity-40"
          >
            <RotateCcw className={`w-3.5 h-3.5 ${isResetting ? 'animate-spin' : ''}`} />
            {editTargetType === 'role' ? 'Reset to Factory Defaults' : 'Revert to Role Baseline'}
          </button>

          <button
            onClick={handleSavePermissions}
            disabled={isSaving || !canEditSelectedRole}
            className="px-6 py-2 bg-gradient-to-r from-amber-400 to-amber-500 hover:brightness-110 text-black font-black text-xs rounded-xl shadow-lg transition-all flex items-center gap-1.5 disabled:opacity-50"
          >
            <Save className={`w-4 h-4 ${isSaving ? 'animate-spin' : ''}`} />
            {isSaving ? 'Saving to Database...' : 'Save Permissions'}
          </button>
        </div>
      </div>

      {/* MODAL: CREATE CUSTOM SYSTEM PERMISSION */}
      {showCreatePermModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#1a0b2e] border border-purple-400/40 rounded-3xl p-6 w-full max-w-md space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-purple-400" />
                <h3 className="font-black text-white text-base">Create Custom System Permission</h3>
              </div>
              <button onClick={() => setShowCreatePermModal(false)} className="text-slate-400 hover:text-white font-bold text-lg">✕</button>
            </div>

            <form onSubmit={handleCreatePermissionSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">Permission Key (Unique Identifier)</label>
                <input
                  type="text"
                  value={newPermData.key}
                  onChange={(e) => setNewPermData({ ...newPermData, key: e.target.value })}
                  placeholder="e.g. events:manage or radio:broadcast"
                  required
                  className="w-full bg-black/50 text-amber-300 font-mono font-bold px-3 py-2 rounded-xl border border-white/15 focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Display Name</label>
                <input
                  type="text"
                  value={newPermData.name}
                  onChange={(e) => setNewPermData({ ...newPermData, name: e.target.value })}
                  placeholder="e.g. Broadcast Official Radio Station"
                  required
                  className="w-full bg-black/50 text-white font-bold px-3 py-2 rounded-xl border border-white/15 focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Target Module</label>
                <select
                  value={newPermData.module}
                  onChange={(e) => setNewPermData({ ...newPermData, module: e.target.value })}
                  className="w-full bg-black/50 text-white px-3 py-2 rounded-xl border border-white/15 focus:outline-none focus:border-amber-400"
                >
                  {modules.map(m => (
                    <option key={m.key} value={m.key}>{m.name} ({m.key})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Description</label>
                <textarea
                  value={newPermData.description}
                  onChange={(e) => setNewPermData({ ...newPermData, description: e.target.value })}
                  placeholder="Describe operational capability granted by this permission..."
                  rows={2}
                  className="w-full bg-black/50 text-white px-3 py-2 rounded-xl border border-white/15 focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="isCeoProt"
                  checked={newPermData.isCeoProtected}
                  onChange={(e) => setNewPermData({ ...newPermData, isCeoProtected: e.target.checked })}
                  className="rounded bg-black border-white/20 text-amber-400"
                />
                <label htmlFor="isCeoProt" className="text-slate-300 font-bold cursor-pointer">
                  Mark as CEO Exclusive Protected Permission
                </label>
              </div>

              <div className="flex gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setShowCreatePermModal(false)}
                  className="flex-1 py-2 bg-white/10 hover:bg-white/20 text-white font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-gradient-to-r from-purple-500 to-indigo-600 hover:brightness-110 text-white font-bold rounded-xl shadow-lg"
                >
                  Create Permission
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: CREATE CUSTOM MODULE */}
      {showCreateModModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#1a0b2e] border border-indigo-400/40 rounded-3xl p-6 w-full max-w-md space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <Layers className="w-5 h-5 text-indigo-400" />
                <h3 className="font-black text-white text-base">Create Custom Permission Module</h3>
              </div>
              <button onClick={() => setShowCreateModModal(false)} className="text-slate-400 hover:text-white font-bold text-lg">✕</button>
            </div>

            <form onSubmit={handleCreateModuleSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">Module Key (lowercase, underscores)</label>
                <input
                  type="text"
                  value={newModData.key}
                  onChange={(e) => setNewModData({ ...newModData, key: e.target.value })}
                  placeholder="e.g. live_tournaments"
                  required
                  className="w-full bg-black/50 text-indigo-300 font-mono font-bold px-3 py-2 rounded-xl border border-white/15 focus:outline-none focus:border-indigo-400"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Display Name</label>
                <input
                  type="text"
                  value={newModData.name}
                  onChange={(e) => setNewModData({ ...newModData, name: e.target.value })}
                  placeholder="e.g. Live Tournaments & Esports"
                  required
                  className="w-full bg-black/50 text-white font-bold px-3 py-2 rounded-xl border border-white/15 focus:outline-none focus:border-indigo-400"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Description</label>
                <textarea
                  value={newModData.description}
                  onChange={(e) => setNewModData({ ...newModData, description: e.target.value })}
                  placeholder="Module purpose and administrative boundaries..."
                  rows={2}
                  className="w-full bg-black/50 text-white px-3 py-2 rounded-xl border border-white/15 focus:outline-none focus:border-indigo-400"
                />
              </div>

              <div className="flex gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setShowCreateModModal(false)}
                  className="flex-1 py-2 bg-white/10 hover:bg-white/20 text-white font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-gradient-to-r from-indigo-500 to-purple-600 hover:brightness-110 text-white font-bold rounded-xl shadow-lg"
                >
                  Create Module
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
