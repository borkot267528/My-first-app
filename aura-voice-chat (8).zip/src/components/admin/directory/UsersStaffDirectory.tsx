/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  Users, UserCheck, Shield, Search, Filter, Edit2, Key, Download, 
  FileSpreadsheet, FileText, CheckCircle2, Clock, Globe, Smartphone, 
  Wallet, Gift, RefreshCw, AlertCircle, ArrowUpRight, ArrowDownRight,
  ChevronLeft, ChevronRight, Ban, Crown, Award, Eye, Sparkles, Trash2, 
  History, UserPlus, ShieldAlert, Check, Building2, Calendar, Activity, 
  Lock, ShieldCheck, X, CheckSquare, Square, Plus, Tag, Coins, Gem,
  Database, Wifi, WifiOff, AlertTriangle, ArrowUpDown, Layers, SlidersHorizontal,
  Camera, Upload, RotateCw, ZoomIn, ZoomOut, Image as ImageIcon, Mail, Phone, Unlock, HelpCircle
} from 'lucide-react';
import { User, StaffMember, UserRole, AuditLog, StaffIdentity } from '../../../types';
import { ApiClient } from '../../../lib/api';
import { exportToExcel, exportToPDF } from '../../../lib/exportUtils';
import { 
  STAFF_IDENTITY_CONFIG, 
  getEffectiveStaffIdentity, 
  AVAILABLE_STAFF_POSITIONS 
} from '../../../lib/staffIdentity';
import { StaffIdentityBadgeCard } from '../../profile/StaffIdentityBadgeCard';
import { ProfileIdBadge } from '../../common/ProfileIdBadge';
import { 
  subscribeToFirestoreUsers, 
  fetchUsersFromFirestore, 
  saveUserToFirestore,
  banUserInFirestore,
  unbanUserInFirestore,
  syncServerUsersToFirestore,
  OperationType,
  handleFirestoreError
} from '../../../lib/firestoreUsers';
import { useApp } from '../../../context/AppContext';

// Constants for Edit User Profile Modal
const PRESET_AVATARS = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
  'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80',
  'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=300&q=80'
];

const COUNTRY_OPTIONS = [
  { name: 'United States', code: 'US', flag: '🇺🇸' },
  { name: 'United Kingdom', code: 'GB', flag: '🇬🇧' },
  { name: 'Canada', code: 'CA', flag: '🇨🇦' },
  { name: 'Australia', code: 'AU', flag: '🇦🇺' },
  { name: 'Germany', code: 'DE', flag: '🇩🇪' },
  { name: 'France', code: 'FR', flag: '🇫🇷' },
  { name: 'Saudi Arabia', code: 'SA', flag: '🇸🇦' },
  { name: 'United Arab Emirates', code: 'AE', flag: '🇦🇪' },
  { name: 'Qatar', code: 'QA', flag: '🇶🇦' },
  { name: 'Kuwait', code: 'KW', flag: '🇰🇼' },
  { name: 'Bahrain', code: 'BH', flag: '🇧🇭' },
  { name: 'Oman', code: 'OM', flag: '🇴🇲' },
  { name: 'Egypt', code: 'EG', flag: '🇪🇬' },
  { name: 'Morocco', code: 'MA', flag: '🇲🇦' },
  { name: 'Bangladesh', code: 'BD', flag: '🇧🇩' },
  { name: 'India', code: 'IN', flag: '🇮🇳' },
  { name: 'Pakistan', code: 'PK', flag: '🇵🇰' },
  { name: 'Indonesia', code: 'ID', flag: '🇮🇩' },
  { name: 'Malaysia', code: 'MY', flag: '🇲🇾' },
  { name: 'Philippines', code: 'PH', flag: '🇵🇭' },
  { name: 'Singapore', code: 'SG', flag: '🇸🇬' },
  { name: 'Thailand', code: 'TH', flag: '🇹🇭' },
  { name: 'Vietnam', code: 'VN', flag: '🇻🇳' },
  { name: 'Turkey', code: 'TR', flag: '🇹🇷' },
  { name: 'Japan', code: 'JP', flag: '🇯🇵' },
  { name: 'South Korea', code: 'KR', flag: '🇰🇷' },
  { name: 'China', code: 'CN', flag: '🇨🇳' },
  { name: 'Brazil', code: 'BR', flag: '🇧🇷' },
  { name: 'Mexico', code: 'MX', flag: '🇲🇽' },
  { name: 'Global / International', code: 'GL', flag: '🌐' }
];

const VIP_TIER_OPTIONS = [
  { value: 'none', label: 'No VIP (None)', badge: 'None' },
  { value: 'VIP 1', label: '👑 VIP 1', badge: 'VIP' },
  { value: 'VIP 2', label: '👑 VIP 2', badge: 'VIP' },
  { value: 'VIP 3', label: '👑 VIP 3', badge: 'VIP' },
  { value: 'VIP 4', label: '👑 VIP 4', badge: 'VIP' },
  { value: 'VIP 5', label: '👑 VIP 5', badge: 'VIP' },
  { value: 'VIP 6', label: '👑 VIP 6', badge: 'VIP' },
  { value: 'VIP 7', label: '👑 VIP 7', badge: 'VIP' },
  { value: 'VIP 8', label: '👑 VIP 8', badge: 'VIP' },
  { value: 'VIP 9', label: '👑 VIP 9', badge: 'VIP' },
  { value: 'VIP 10', label: '👑 VIP 10', badge: 'VIP' },
  { value: 'SVIP 1', label: '⚡ SVIP 1', badge: 'SVIP' },
  { value: 'SVIP 2', label: '⚡ SVIP 2', badge: 'SVIP' },
  { value: 'SVIP 3', label: '⚡ SVIP 3', badge: 'SVIP' },
  { value: 'SVIP 4', label: '⚡ SVIP 4', badge: 'SVIP' },
  { value: 'SVIP 5', label: '⚡ SVIP 5', badge: 'SVIP' },
  { value: 'SVIP 6', label: '⚡ SVIP 6', badge: 'SVIP' },
  { value: 'SVIP 7', label: '⚡ SVIP 7', badge: 'SVIP' },
  { value: 'SVIP 8', label: '⚡ SVIP 8', badge: 'SVIP' },
  { value: 'SVIP 9', label: '⚡ SVIP 9', badge: 'SVIP' },
  { value: 'SVIP 10', label: '⚡ SVIP 10', badge: 'SVIP' },
];

interface UsersStaffDirectoryProps {
  users?: User[];
  currentUser: User | null;
  auditLogs?: AuditLog[];
  showNotification: (msg: string) => void;
  onRefreshParent?: () => void;
  onOpenStaffAssign?: (user: User) => void;
}

export const UsersStaffDirectory: React.FC<UsersStaffDirectoryProps> = ({
  users: parentUsers = [],
  currentUser: propCurrentUser,
  auditLogs = [],
  showNotification,
  onRefreshParent,
  onOpenStaffAssign
}) => {
  const { currentUser: appCurrentUser, setCurrentUser, refreshUser } = useApp();
  const currentUser = propCurrentUser || appCurrentUser;

  // State for Firestore users (initialized with parent users if available)
  const [firestoreUsers, setFirestoreUsers] = useState<User[]>(parentUsers);
  const [isFirestoreLoading, setIsFirestoreLoading] = useState<boolean>(parentUsers.length === 0);
  const [firestoreConnected, setFirestoreConnected] = useState<boolean>(false);
  const [firestoreError, setFirestoreError] = useState<string | null>(null);
  const [isSyncingWithDb, setIsSyncingWithDb] = useState<boolean>(false);

  // Sync with parent users whenever parentUsers updates
  useEffect(() => {
    if (parentUsers && parentUsers.length > 0) {
      setFirestoreUsers(prev => {
        if (prev.length === 0) return parentUsers;
        const map = new Map<string, User>();
        prev.forEach(u => map.set(u.id, u));
        parentUsers.forEach(u => {
          const existing = map.get(u.id);
          map.set(u.id, existing ? { ...existing, ...u } : u);
        });
        return Array.from(map.values());
      });
      setIsFirestoreLoading(false);
    }
  }, [parentUsers]);

  // View & Filter States
  const [viewMode, setViewMode] = useState<'table' | 'grid'>('table');
  const [searchField, setSearchField] = useState<'all' | 'id' | 'uid' | 'name' | 'email' | 'phone'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'banned' | 'online' | 'offline'>('all');
  const [vipFilter, setVipFilter] = useState<'all' | 'none' | 'vip' | 'svip'>('all');
  const [countryFilter, setCountryFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'level' | 'coins' | 'diamonds' | 'createdAt' | 'name'>('createdAt');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  // Pagination
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [itemsPerPage, setItemsPerPage] = useState<number>(10);

  // Selected User Drawer / Modal
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [drawerTab, setDrawerTab] = useState<'profile' | 'ban_governance' | 'wallet' | 'uid' | 'staff'>('profile');

  // Listen to profile updates across the admin portal and app
  useEffect(() => {
    const handleProfileUpdate = (e: any) => {
      const detail = e.detail;
      if (detail && detail.id) {
        setFirestoreUsers(prev => prev.map(u => u.id === detail.id ? { ...u, ...detail } : u));
        if (selectedUser?.id === detail.id) {
          setSelectedUser(prev => prev ? { ...prev, ...detail } : null);
        }
      }
    };
    window.addEventListener('user_profile_updated', handleProfileUpdate);
    return () => window.removeEventListener('user_profile_updated', handleProfileUpdate);
  }, [selectedUser?.id]);

  // Ban Modal State
  const [banModalUser, setBanModalUser] = useState<User | null>(null);
  const [banReason, setBanReason] = useState<string>('');
  const [banCategory, setBanCategory] = useState<string>('Harassment & Toxicity');
  const [banType, setBanType] = useState<'temporary' | 'permanent'>('temporary');
  const [banDurationHours, setBanDurationHours] = useState<number>(24);
  const [isSubmittingBan, setIsSubmittingBan] = useState<boolean>(false);

  // Unban Modal State
  const [unbanModalUser, setUnbanModalUser] = useState<User | null>(null);
  const [unbanReason, setUnbanReason] = useState<string>('Account appeal accepted after compliance review');
  const [isSubmittingUnban, setIsSubmittingUnban] = useState<boolean>(false);

  // Edit UID Modal State (CEO/GM Exclusive)
  const [editUidUser, setEditUidUser] = useState<User | null>(null);
  const [newUidInput, setNewUidInput] = useState<string>('');
  const [confirmUidInput, setConfirmUidInput] = useState<string>('');
  const [uidReasonInput, setUidReasonInput] = useState<string>('');
  const [showUidConfirmStep, setShowUidConfirmStep] = useState<boolean>(false);
  const [isUpdatingUid, setIsUpdatingUid] = useState<boolean>(false);

  // Edit User Details State
  const [editProfileUser, setEditProfileUser] = useState<User | null>(null);
  const [editProfileForm, setEditProfileForm] = useState<Partial<User>>({});
  const [isSavingProfile, setIsSavingProfile] = useState<boolean>(false);
  const [avatarUploadLoading, setAvatarUploadLoading] = useState<boolean>(false);
  const [avatarZoom, setAvatarZoom] = useState<number>(1);
  const [avatarRotation, setAvatarRotation] = useState<number>(0);
  const [avatarError, setAvatarError] = useState<string | null>(null);
  const [formValidationError, setFormValidationError] = useState<string | null>(null);
  const avatarFileInputRef = useRef<HTMLInputElement>(null);

  // Wallet Adjust Modal State
  const [walletModalUser, setWalletModalUser] = useState<User | null>(null);
  const [walletAdjustType, setWalletAdjustType] = useState<'coins' | 'diamonds'>('coins');
  const [walletAdjustAmount, setWalletAdjustAmount] = useState<number>(1000);
  const [walletAdjustAction, setWalletAdjustAction] = useState<'credit' | 'debit'>('credit');
  const [walletAdjustReason, setWalletAdjustReason] = useState<string>('Administrative adjustment');
  const [isSubmittingWallet, setIsSubmittingWallet] = useState<boolean>(false);

  // Staff Identity Quick Assign Modal
  const [assignIdentityUser, setAssignIdentityUser] = useState<User | null>(null);
  const [assignRoles, setAssignRoles] = useState<UserRole[]>(['official_staff']);
  const [assignTitle, setAssignTitle] = useState<string>('Official Staff');
  const [assignDepartment, setAssignDepartment] = useState<string>('Platform Operations');
  const [assignStaffId, setAssignStaffId] = useState<string>('');
  const [assignStaffLevel, setAssignStaffLevel] = useState<number>(5);
  const [assignNotes, setAssignNotes] = useState<string>('');

  // Privileges
  const isCeo = currentUser?.role === 'ceo';
  const isCeoOrGm = currentUser?.role === 'ceo' || currentUser?.role === 'gm';
  const isStaffOrAdmin = ['ceo', 'gm', 'manager', 'super_admin', 'admin', 'bd'].includes(currentUser?.role || '');

  // 1. Initial Firestore Subscription & Sync Bridge
  useEffect(() => {
    let isMounted = true;
    let unsubscribe: (() => void) | undefined;

    const initDirectory = async () => {
      try {
        // Step A: Fetch server users as authoritative reference
        let serverList: User[] = parentUsers.length > 0 ? parentUsers : [];
        try {
          const apiRes = await ApiClient.getAdminUsers();
          if (Array.isArray(apiRes) && apiRes.length > 0) {
            serverList = apiRes;
            if (isMounted) {
              setFirestoreUsers(prev => prev.length === 0 ? serverList : prev);
              setIsFirestoreLoading(false);
            }
          }
        } catch (e) {
          console.warn('Backend users fetch fallback, listening to Firestore directly');
        }

        if (serverList.length > 0 && isMounted) {
          setFirestoreUsers(serverList);
          setIsFirestoreLoading(false);
        }

        // Step B: Subscribe to live Firestore stream
        unsubscribe = subscribeToFirestoreUsers(
          (usersFromDb) => {
            if (!isMounted) return;
            setFirestoreConnected(true);
            setIsFirestoreLoading(false);

            if (usersFromDb.length === 0 && serverList.length > 0) {
              // Initial sync: populate Firestore with default user base
              syncServerUsersToFirestore(serverList).then(() => {
                console.log('Seeded initial Firestore user collection.');
              });
              setFirestoreUsers(serverList);
            } else if (usersFromDb.length > 0) {
              setFirestoreUsers(usersFromDb);
            } else if (serverList.length > 0) {
              setFirestoreUsers(serverList);
            }
          },
          (err) => {
            if (!isMounted) return;
            console.warn('Firestore subscription notice:', err?.message || err);
            setFirestoreConnected(false);
            setIsFirestoreLoading(false);
            // Fallback to server list if offline
            if (serverList.length > 0) {
              setFirestoreUsers(serverList);
            }
          }
        );
      } catch (err: any) {
        if (!isMounted) return;
        console.warn('Error starting Firestore user directory listener:', err);
        setFirestoreError(err?.message || 'Failed to initialize Firestore listener');
        setIsFirestoreLoading(false);
        if (parentUsers.length > 0) {
          setFirestoreUsers(parentUsers);
        }
      }
    };

    initDirectory();

    return () => {
      isMounted = false;
      if (unsubscribe) unsubscribe();
    };
  }, []);

  // Manual Trigger to re-sync Firestore & Server
  const handleForceSyncFirestore = async () => {
    setIsSyncingWithDb(true);
    try {
      const serverUsers = await ApiClient.getAdminUsers();
      await syncServerUsersToFirestore(serverUsers);
      const latestDb = await fetchUsersFromFirestore();
      setFirestoreUsers(latestDb);
      setFirestoreConnected(true);
      showNotification(`✅ Real-time Firestore synchronized: ${latestDb.length} user records live in Cloud Firestore.`);
      if (onRefreshParent) onRefreshParent();
    } catch (err: any) {
      showNotification(`⚠️ Sync notice: ${err.message || 'Refreshed active user records'}`);
    } finally {
      setIsSyncingWithDb(false);
    }
  };

  // 2. Multi-Layer Filter & Search Logic
  const filteredUsers = useMemo(() => {
    // Ensure input user list contains only unique users by id
    const uniqueMap = new Map<string, User>();
    firestoreUsers.forEach(u => {
      if (u && u.id) uniqueMap.set(u.id, u);
    });
    const uniqueList = Array.from(uniqueMap.values());

    return uniqueList.filter(u => {
      // Search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        if (searchField === 'id' && !u.id.toLowerCase().includes(q)) return false;
        if (searchField === 'uid' && !u.uid.toLowerCase().includes(q)) return false;
        if (searchField === 'name' && !u.name.toLowerCase().includes(q)) return false;
        if (searchField === 'email' && !u.email.toLowerCase().includes(q)) return false;
        if (searchField === 'phone' && !(u.phone || '').toLowerCase().includes(q)) return false;
        if (searchField === 'all') {
          const match = u.id.toLowerCase().includes(q) ||
                        u.uid.toLowerCase().includes(q) ||
                        u.name.toLowerCase().includes(q) ||
                        u.email.toLowerCase().includes(q) ||
                        (u.phone && u.phone.toLowerCase().includes(q)) ||
                        (u.bio && u.bio.toLowerCase().includes(q));
          if (!match) return false;
        }
      }

      // Role Filter
      if (roleFilter !== 'all') {
        if (roleFilter === 'staff') {
          const isStaff = ['ceo', 'gm', 'manager', 'super_admin', 'admin', 'bd', 'official_staff', 'customer_service', 'finance_auditor', 'room_monitor', 'community_mod'].includes(u.role) || Boolean(u.staffIdentity);
          if (!isStaff) return false;
        } else if (u.role !== roleFilter) {
          return false;
        }
      }

      // Status Filter
      if (statusFilter === 'active' && u.status === 'banned') return false;
      if (statusFilter === 'banned' && u.status !== 'banned') return false;
      if (statusFilter === 'online' && !u.isOnline) return false;
      if (statusFilter === 'offline' && u.isOnline) return false;

      // VIP Filter
      if (vipFilter !== 'all' && u.vipLevel !== vipFilter) return false;

      // Country Filter
      if (countryFilter !== 'all' && u.country !== countryFilter) return false;

      return true;
    }).sort((a, b) => {
      let valA: any = a[sortBy];
      let valB: any = b[sortBy];

      if (sortBy === 'level') {
        valA = a.level || 1;
        valB = b.level || 1;
      } else if (sortBy === 'coins') {
        valA = a.coins || 0;
        valB = b.coins || 0;
      } else if (sortBy === 'diamonds') {
        valA = a.diamonds || 0;
        valB = b.diamonds || 0;
      } else if (sortBy === 'createdAt') {
        valA = new Date(a.createdAt || 0).getTime();
        valB = new Date(b.createdAt || 0).getTime();
      } else if (sortBy === 'name') {
        valA = a.name.toLowerCase();
        valB = b.name.toLowerCase();
      }

      if (sortOrder === 'asc') {
        return valA > valB ? 1 : -1;
      } else {
        return valA < valB ? 1 : -1;
      }
    });
  }, [firestoreUsers, searchQuery, searchField, roleFilter, statusFilter, vipFilter, countryFilter, sortBy, sortOrder]);

  // Statistics Summary
  const stats = useMemo(() => {
    const total = firestoreUsers.length;
    const online = firestoreUsers.filter(u => u.isOnline).length;
    const banned = firestoreUsers.filter(u => u.status === 'banned').length;
    const staff = firestoreUsers.filter(u => ['ceo', 'gm', 'manager', 'super_admin', 'admin', 'bd', 'official_staff'].includes(u.role) || Boolean(u.staffIdentity)).length;
    const totalCoins = firestoreUsers.reduce((acc, u) => acc + (u.coins || 0), 0);
    const totalDiamonds = firestoreUsers.reduce((acc, u) => acc + (u.diamonds || 0), 0);
    return { total, online, banned, staff, totalCoins, totalDiamonds };
  }, [firestoreUsers]);

  // Available Countries in dataset
  const uniqueCountries = useMemo(() => {
    const set = new Set<string>();
    firestoreUsers.forEach(u => {
      if (u.country) set.add(u.country);
    });
    return Array.from(set).sort();
  }, [firestoreUsers]);

  // Pagination Math
  const totalPages = Math.ceil(filteredUsers.length / itemsPerPage) || 1;
  const paginatedUsers = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredUsers.slice(start, start + itemsPerPage);
  }, [filteredUsers, currentPage, itemsPerPage]);

  // 3. ACTION HANDLERS

  // --- A. BAN USER ACTION ---
  const handleExecuteBan = async () => {
    if (!banModalUser) return;
    if (!banReason.trim()) {
      showNotification('⚠️ Please enter a specific ban reason or policy violation description.');
      return;
    }

    // Role safety check: Protect CEO and higher ranking staff
    if (banModalUser.role === 'ceo') {
      showNotification('⛔ PERMISSION DENIED: The CEO cannot be banned.');
      return;
    }

    setIsSubmittingBan(true);
    try {
      const fullReason = `[${banCategory}] ${banReason.trim()}`;
      
      // 1. Execute via Backend API for Audit logs & Sessions termination
      try {
        await ApiClient.banUser(banModalUser.id, {
          reason: fullReason,
          banType,
          durationHours: banType === 'permanent' ? undefined : banDurationHours
        });
      } catch (apiErr: any) {
        console.warn('Backend API ban note:', apiErr);
      }

      // 2. Write to Firestore
      try {
        await banUserInFirestore(banModalUser.id, {
          reason: fullReason,
          banType,
          durationHours: banType === 'permanent' ? undefined : banDurationHours,
          bannedByName: currentUser?.name || 'Administrator',
          bannedByRole: currentUser?.role || 'super_admin'
        });
      } catch (fsErr) {
        console.warn('Firestore ban sync notice:', fsErr);
      }

      // 3. Local optimistic state update
      setFirestoreUsers(prev => prev.map(u => {
        if (u.id === banModalUser.id) {
          return {
            ...u,
            status: 'banned',
            banReason: fullReason,
            banType,
            banExpiresAt: banType === 'permanent' ? undefined : new Date(Date.now() + banDurationHours * 3600000).toISOString(),
            bannedByName: currentUser?.name || 'Administrator',
            bannedByRole: currentUser?.role || 'super_admin',
            bannedAt: new Date().toISOString()
          };
        }
        return u;
      }));

      showNotification(`⛔ BANNED ${banModalUser.name} (${banType.toUpperCase()}) — Updated in Cloud Firestore.`);
      setBanModalUser(null);
      setBanReason('');
      if (selectedUser?.id === banModalUser.id) {
        setSelectedUser(prev => prev ? { ...prev, status: 'banned', banReason: fullReason, banType } : null);
      }
      if (onRefreshParent) onRefreshParent();
    } catch (err: any) {
      showNotification(`❌ Ban error: ${err.message || 'Failed to ban user'}`);
    } finally {
      setIsSubmittingBan(false);
    }
  };

  // --- B. UNBAN USER ACTION ---
  const handleExecuteUnban = async () => {
    if (!unbanModalUser) return;
    setIsSubmittingUnban(true);
    try {
      // 1. Sync to Backend API
      try {
        await ApiClient.unbanUser(unbanModalUser.id, {
          reason: unbanReason.trim()
        });
      } catch (apiErr: any) {
        console.warn('Backend API unban notice:', apiErr);
      }

      // 2. Write to Firestore
      try {
        await unbanUserInFirestore(unbanModalUser.id, {
          reason: unbanReason.trim(),
          unbannedByName: currentUser?.name || 'Administrator'
        });
      } catch (fsErr) {
        console.warn('Firestore unban sync notice:', fsErr);
      }

      // 3. Update state
      setFirestoreUsers(prev => prev.map(u => {
        if (u.id === unbanModalUser.id) {
          return {
            ...u,
            status: 'active',
            banReason: undefined,
            banType: undefined,
            banExpiresAt: undefined,
            bannedByName: undefined,
            bannedByRole: undefined,
            bannedAt: undefined
          };
        }
        return u;
      }));

      showNotification(`✅ Account restored: ${unbanModalUser.name} is now ACTIVE.`);
      setUnbanModalUser(null);
      if (selectedUser?.id === unbanModalUser.id) {
        setSelectedUser(prev => prev ? { ...prev, status: 'active', banReason: undefined, banType: undefined } : null);
      }
      if (onRefreshParent) onRefreshParent();
    } catch (err: any) {
      showNotification(`❌ Unban error: ${err.message || 'Failed to unban user'}`);
    } finally {
      setIsSubmittingUnban(false);
    }
  };

  // --- C. EDIT USER UID ACTION (CEO/GM Exclusive) ---
  const handleUpdateUid = async () => {
    if (!editUidUser) return;

    if (!isCeoOrGm) {
      showNotification('⛔ PERMISSION DENIED: Only CEO and General Manager (GM) roles can edit User UIDs.');
      return;
    }

    const trimmedNew = newUidInput.trim();
    const trimmedConfirm = confirmUidInput.trim();

    if (!trimmedNew) {
      showNotification('⚠️ User UID cannot be empty.');
      return;
    }

    if (trimmedNew !== trimmedConfirm) {
      showNotification('⚠️ New UID and confirmation do not match.');
      return;
    }

    const uidRegex = /^[a-zA-Z0-9_-]{1,20}$/;
    if (!uidRegex.test(trimmedNew)) {
      showNotification('⚠️ Invalid UID format. Must be 1 to 20 alphanumeric characters, underscores, or hyphens.');
      return;
    }

    // Uniqueness validation
    const duplicate = firestoreUsers.find(u => u.uid === trimmedNew && u.id !== editUidUser.id);
    if (duplicate) {
      showNotification(`⚠️ UID [${trimmedNew}] is already assigned to "${duplicate.name}" (ID: ${duplicate.id}).`);
      return;
    }

    // Step 2 confirmation check
    if (!showUidConfirmStep) {
      setShowUidConfirmStep(true);
      return;
    }

    setIsUpdatingUid(true);
    try {
      // 1. Write to backend API for authoritative validation and update
      try {
        await ApiClient.updateUserId(editUidUser.id, trimmedNew, trimmedConfirm, uidReasonInput.trim());
      } catch (e: any) {
        console.warn('API update user ID notice:', e);
      }

      // 2. Sync to Firestore
      try {
        await saveUserToFirestore({
          id: editUidUser.id,
          uid: trimmedNew
        });
      } catch (fsErr) {
        console.warn('Firestore UID sync notice:', fsErr);
      }

      // 3. Update local state
      setFirestoreUsers(prev => prev.map(u => (u.id === editUidUser.id ? { ...u, uid: trimmedNew } : u)));
      if (selectedUser?.id === editUidUser.id) {
        setSelectedUser(prev => prev ? { ...prev, uid: trimmedNew } : null);
      }

      // Propagate UID change to global current user if applicable
      const isCurrentActive = 
        !currentUser || 
        currentUser.id === editUidUser.id || 
        currentUser.uid === editUidUser.uid ||
        editUidUser.id === '2383452';

      if (isCurrentActive) {
        setCurrentUser(prev => prev ? { ...prev, uid: trimmedNew } : null);
        try {
          const cached = localStorage.getItem('aura_cached_user');
          if (cached) {
            const parsed = JSON.parse(cached);
            localStorage.setItem('aura_cached_user', JSON.stringify({ ...parsed, uid: trimmedNew }));
          }
        } catch (e) {}
      }

      window.dispatchEvent(new CustomEvent('user_profile_updated', { 
        detail: { id: editUidUser.id, uid: trimmedNew } 
      }));
      refreshUser();

      showNotification(`✅ UID changed from [${editUidUser.uid}] to [${trimmedNew}] for ${editUidUser.name}`);
      setEditUidUser(null);
      setShowUidConfirmStep(false);
      if (onRefreshParent) onRefreshParent();
    } catch (err: any) {
      showNotification(`❌ ${err.message || 'Failed to update UID'}`);
      setShowUidConfirmStep(false);
    } finally {
      setIsUpdatingUid(false);
    }
  };

  // --- D. EDIT USER PROFILE MODAL HANDLERS ---
  const openEditProfileModal = (u: User) => {
    setEditProfileUser(u);
    setEditProfileForm({ ...u });
    setAvatarZoom(1);
    setAvatarRotation(0);
    setAvatarError(null);
    setFormValidationError(null);
  };

  const handleAvatarFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setAvatarError(null);
    setFormValidationError(null);

    // Validate file format: JPG, JPEG, PNG, WEBP
    const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    if (!validTypes.includes(file.type.toLowerCase())) {
      setAvatarError('Invalid file format. Please choose a JPG, JPEG, PNG, or WEBP image.');
      return;
    }

    // Validate file size: Max 6MB
    const MAX_SIZE = 6 * 1024 * 1024;
    if (file.size > MAX_SIZE) {
      setAvatarError(`Image size too large (${(file.size / (1024 * 1024)).toFixed(1)}MB). Maximum allowed is 6MB.`);
      return;
    }

    setAvatarUploadLoading(true);
    try {
      const reader = new FileReader();
      reader.onload = async (event) => {
        const base64Data = event.target?.result as string;
        if (!base64Data) {
          setAvatarError('Failed to read image file.');
          setAvatarUploadLoading(false);
          return;
        }

        try {
          // Upload to server storage system
          const uploadRes = await ApiClient.uploadImage(
            base64Data,
            file.name,
            file.type,
            'avatar'
          );

          if (uploadRes && uploadRes.url) {
            setEditProfileForm(prev => ({ ...prev, avatar: uploadRes.url }));
            setAvatarZoom(1);
            setAvatarRotation(0);
            showNotification('Photo uploaded to storage!');
          } else {
            setEditProfileForm(prev => ({ ...prev, avatar: base64Data }));
          }
        } catch (uploadErr: any) {
          console.warn('Direct upload fallback to base64 preview:', uploadErr);
          setEditProfileForm(prev => ({ ...prev, avatar: base64Data }));
        } finally {
          setAvatarUploadLoading(false);
        }
      };

      reader.onerror = () => {
        setAvatarError('Error reading file from device.');
        setAvatarUploadLoading(false);
      };

      reader.readAsDataURL(file);
    } catch (err: any) {
      setAvatarError(err?.message || 'Failed to process image');
      setAvatarUploadLoading(false);
    }
  };

  const handleRemoveAvatar = () => {
    const defaultAvatar = 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80';
    setEditProfileForm(prev => ({ ...prev, avatar: defaultAvatar }));
    setAvatarZoom(1);
    setAvatarRotation(0);
    setAvatarError(null);
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editProfileUser) return;
    setFormValidationError(null);

    // 1. Full Name Validation
    const trimmedName = (editProfileForm.name || '').trim();
    if (!trimmedName || trimmedName.length < 2) {
      setFormValidationError('Full Name must be at least 2 characters.');
      return;
    }
    if (trimmedName.length > 50) {
      setFormValidationError('Full Name cannot exceed 50 characters.');
      return;
    }

    // 2. User ID / Profile ID Validation (CEO/GM Privilege)
    const currentUid = editProfileUser.uid;
    const requestedUid = (editProfileForm.uid || '').trim();
    let finalUid = currentUid;

    if (isCeoOrGm && requestedUid && requestedUid !== currentUid) {
      const uidRegex = /^[a-zA-Z0-9_-]{1,20}$/;
      if (!uidRegex.test(requestedUid)) {
        setFormValidationError('User ID / Profile ID must be 1 to 20 alphanumeric characters, underscores, or hyphens.');
        return;
      }
      const existingUser = firestoreUsers.find(
        u => u.uid?.toLowerCase() === requestedUid.toLowerCase() && u.id !== editProfileUser.id
      );
      if (existingUser) {
        setFormValidationError(`User ID [${requestedUid}] is already assigned to "${existingUser.name}". Please choose a different ID.`);
        return;
      }
      finalUid = requestedUid;
    }

    // 3. Email Validation
    const trimmedEmail = (editProfileForm.email || '').trim();
    if (!trimmedEmail) {
      setFormValidationError('Email address is required.');
      return;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(trimmedEmail)) {
      setFormValidationError('Please enter a valid email address (e.g. user@gmail.com).');
      return;
    }

    // 4. Wealth / Sending Level Validation (1-200)
    const sendingLevel = Number(editProfileForm.sendingLevel ?? editProfileForm.level ?? 1);
    if (isNaN(sendingLevel) || sendingLevel < 1 || sendingLevel > 200) {
      setFormValidationError('Wealth / Sending Level must be an integer between 1 and 200.');
      return;
    }

    // 5. Charm / Receiving Level Validation (1-200)
    const receivingLevel = Number(editProfileForm.receivingLevel ?? 1);
    if (isNaN(receivingLevel) || receivingLevel < 1 || receivingLevel > 200) {
      setFormValidationError('Charm / Receiving Level must be an integer between 1 and 200.');
      return;
    }

    // 6. Bio Length Validation
    const bioText = editProfileForm.bio || '';
    if (bioText.length > 500) {
      setFormValidationError('Bio cannot exceed 500 characters.');
      return;
    }

    // 7. VIP / SVIP Level Normalization
    let normalizedVip: 'none' | 'vip' | 'svip' = 'none';
    const rawVip = String(editProfileForm.vipLevel || 'none');
    if (rawVip.toLowerCase().includes('svip')) {
      normalizedVip = 'svip';
    } else if (rawVip.toLowerCase().includes('vip')) {
      normalizedVip = 'vip';
    }

    // 8. Country & Flag Sync
    const countryName = editProfileForm.country || 'United States';
    const matchedCountry = COUNTRY_OPTIONS.find(c => c.name.toLowerCase() === countryName.toLowerCase());
    const countryFlag = matchedCountry?.flag || editProfileForm.countryFlag || '🇺🇸';

    setIsSavingProfile(true);
    try {
      const updatePayload: Partial<User> & { id: string } = {
        id: editProfileUser.id,
        name: trimmedName,
        uid: finalUid,
        email: trimmedEmail,
        phone: editProfileForm.phone || '',
        country: countryName,
        countryFlag: countryFlag,
        gender: (editProfileForm.gender as any) || 'other',
        vipLevel: normalizedVip,
        sendingLevel: sendingLevel,
        receivingLevel: receivingLevel,
        level: sendingLevel,
        bio: bioText,
        avatar: editProfileForm.avatar || editProfileUser.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80'
      };

      // 1. Sync to Backend API first for authority
      try {
        await ApiClient.updateUserAccount(editProfileUser.id, updatePayload);
      } catch (e: any) {
        console.warn('Backend API update sync note:', e);
      }

      // 2. Save to Cloud Firestore
      try {
        await saveUserToFirestore(updatePayload);
      } catch (fsErr) {
        console.warn('Firestore profile sync notice:', fsErr);
      }

      // 3. Update local state
      setFirestoreUsers(prev => prev.map(u => (u.id === editProfileUser.id ? { ...u, ...updatePayload } : u)));
      if (selectedUser?.id === editProfileUser.id) {
        setSelectedUser(prev => prev ? { ...prev, ...updatePayload } : null);
      }

      // Propagate profile details to global current user if applicable
      const isCurrentActive = 
        !currentUser ||
        currentUser.id === editProfileUser.id || 
        currentUser.uid === editProfileUser.uid ||
        editProfileUser.id === '2383452' ||
        (currentUser.email && editProfileUser.email && currentUser.email.toLowerCase() === editProfileUser.email.toLowerCase());

      const fullMergedUser = { ...editProfileUser, ...updatePayload } as User;

      if (isCurrentActive) {
        setCurrentUser(fullMergedUser);
        try {
          localStorage.setItem('aura_cached_user', JSON.stringify(fullMergedUser));
        } catch (e) {}
      }

      window.dispatchEvent(new CustomEvent('user_profile_updated', { 
        detail: fullMergedUser 
      }));
      refreshUser();

      showNotification(`✅ Profile details updated in Cloud Firestore for ${trimmedName}`);
      setEditProfileUser(null);
      if (onRefreshParent) onRefreshParent();
    } catch (err: any) {
      showNotification(`❌ ${err.message || 'Failed to save profile changes'}`);
    } finally {
      setIsSavingProfile(false);
    }
  };

  // --- E. WALLET ADJUSTMENT ---
  const handleExecuteWalletAdjust = async () => {
    if (!walletModalUser) return;
    if (walletAdjustAmount <= 0) {
      showNotification('⚠️ Adjust amount must be greater than 0.');
      return;
    }

    setIsSubmittingWallet(true);
    try {
      const isCoins = walletAdjustType === 'coins';
      const currentVal = isCoins ? (walletModalUser.coins || 0) : (walletModalUser.diamonds || 0);
      const delta = walletAdjustAction === 'credit' ? walletAdjustAmount : -walletAdjustAmount;
      const newVal = Math.max(0, currentVal + delta);

      const updatePayload: Partial<User> & { id: string } = {
        id: walletModalUser.id,
        [isCoins ? 'coins' : 'diamonds']: newVal
      };

      // 1. Write to Backend API
      try {
        await ApiClient.adjustUserBalance(
          walletModalUser.id, 
          isCoins ? 'coins' : 'diamonds', 
          delta, 
          `[Admin Adjust] ${walletAdjustReason}`
        );
      } catch (e: any) {
        console.warn('Backend balance adjust note:', e);
      }

      // 2. Write to Firestore
      try {
        await saveUserToFirestore(updatePayload);
      } catch (fsErr) {
        console.warn('Firestore wallet sync notice:', fsErr);
      }

      // Update state
      setFirestoreUsers(prev => prev.map(u => {
        if (u.id === walletModalUser.id) {
          return {
            ...u,
            [isCoins ? 'coins' : 'diamonds']: newVal
          };
        }
        return u;
      }));

      if (selectedUser?.id === walletModalUser.id) {
        setSelectedUser(prev => prev ? { ...prev, [isCoins ? 'coins' : 'diamonds']: newVal } : null);
      }

      showNotification(`✅ Wallet Adjusted: ${walletAdjustAction === 'credit' ? '+' : '-'}${walletAdjustAmount.toLocaleString()} ${isCoins ? 'Coins' : 'Diamonds'} for ${walletModalUser.name}`);
      setWalletModalUser(null);
      if (onRefreshParent) onRefreshParent();
    } catch (err: any) {
      showNotification(`❌ Wallet adjust error: ${err.message || 'Failed to adjust balance'}`);
    } finally {
      setIsSubmittingWallet(false);
    }
  };

  // --- F. QUICK EXPORT (Excel / PDF) ---
  const handleExportExcel = () => {
    const exportData = filteredUsers.map(u => ({
      ID: u.id,
      UID: u.uid,
      Name: u.name,
      Email: u.email,
      Phone: u.phone || 'N/A',
      Role: u.role.toUpperCase(),
      Status: u.status === 'banned' ? 'BANNED' : 'ACTIVE',
      Ban_Reason: u.banReason || 'N/A',
      VIP: u.vipLevel.toUpperCase(),
      Wealth_Lv: u.sendingLevel || u.level || 1,
      Charm_Lv: u.receivingLevel || 1,
      Coins: u.coins || 0,
      Diamonds: u.diamonds || 0,
      Country: u.country || 'N/A',
      Online: u.isOnline ? 'YES' : 'NO',
      Created_At: u.createdAt
    }));
    exportToExcel('Aura_Users_Staff_Directory', exportData);
    showNotification('📊 Exported Users & Staff Directory to Excel format.');
  };

  const handleExportPDF = () => {
    const headers = ['UID', 'Name', 'Email', 'Role', 'Status', 'VIP', 'Coins', 'Diamonds', 'Country'];
    const rows = filteredUsers.map(u => [
      u.uid,
      u.name,
      u.email,
      u.role.toUpperCase(),
      u.status === 'banned' ? 'BANNED' : 'ACTIVE',
      u.vipLevel.toUpperCase(),
      (u.coins || 0).toLocaleString(),
      (u.diamonds || 0).toLocaleString(),
      u.country || 'US'
    ]);
    exportToPDF('Users & Staff Management Directory (Firestore Connected)', headers, rows);
    showNotification('📄 Generated formatted PDF report for User Directory.');
  };

  return (
    <div className="space-y-5 animate-fadeIn">
      {/* 1. FIRESTORE REAL-TIME CONNECTION BAR */}
      <div className="p-4 rounded-3xl bg-gradient-to-r from-slate-900/90 via-purple-950/40 to-slate-900/90 border border-white/10 backdrop-blur-xl shadow-2xl flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="p-3 rounded-2xl bg-amber-400/10 border border-amber-400/30 shadow-inner">
            <Database className="w-6 h-6 text-amber-400 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-black text-white tracking-wide">
                Users & Staff Directory
              </h3>
              <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-black border ${
                firestoreConnected 
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-sm'
                  : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
              }`}>
                <span className={`w-1.5 h-1.5 rounded-full ${firestoreConnected ? 'bg-emerald-400 animate-ping' : 'bg-amber-400'}`} />
                {firestoreConnected ? 'Firestore Live Sync: Active' : 'Firestore: Connecting'}
              </span>
            </div>
            <p className="text-xs text-slate-300">
              Cloud Database Collection: <code className="font-mono text-amber-300">/users</code> • Real-time Snapshot Listener • RBAC Moderation
            </p>
          </div>
        </div>

        {/* TOP CONTROLS & EXPORTS */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleForceSyncFirestore}
            disabled={isSyncingWithDb}
            className="px-3.5 py-2 bg-white/5 hover:bg-white/10 text-slate-200 hover:text-white rounded-xl font-bold text-xs border border-white/10 flex items-center gap-2 transition-all shadow-sm active:scale-95 disabled:opacity-50"
            title="Force refresh Firestore snapshot and sync"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-amber-400 ${isSyncingWithDb ? 'animate-spin' : ''}`} />
            <span>{isSyncingWithDb ? 'Syncing...' : 'Sync Firestore'}</span>
          </button>

          <button
            onClick={handleExportExcel}
            className="px-3.5 py-2 bg-emerald-600/80 hover:bg-emerald-500 text-white rounded-xl font-bold text-xs border border-emerald-400/40 flex items-center gap-1.5 transition-all shadow-md active:scale-95"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Excel</span>
          </button>

          <button
            onClick={handleExportPDF}
            className="px-3.5 py-2 bg-rose-600/80 hover:bg-rose-500 text-white rounded-xl font-bold text-xs border border-rose-400/40 flex items-center gap-1.5 transition-all shadow-md active:scale-95"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>PDF</span>
          </button>
        </div>
      </div>

      {/* 2. STATS CARDS OVERVIEW */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Total Users</span>
            <Users className="w-4 h-4 text-purple-400" />
          </div>
          <p className="text-xl font-black text-white font-mono">{stats.total}</p>
          <span className="text-[10px] text-slate-400">Synced in Firestore</span>
        </div>

        <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Live Online</span>
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
          </div>
          <p className="text-xl font-black text-emerald-400 font-mono">{stats.online}</p>
          <span className="text-[10px] text-emerald-300/80">Active now</span>
        </div>

        <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Staff & Admins</span>
            <ShieldCheck className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-xl font-black text-amber-300 font-mono">{stats.staff}</p>
          <span className="text-[10px] text-amber-400/80">Officers & Staff</span>
        </div>

        <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Banned Accounts</span>
            <Ban className="w-4 h-4 text-rose-400" />
          </div>
          <p className="text-xl font-black text-rose-400 font-mono">{stats.banned}</p>
          <span className="text-[10px] text-rose-300/80">Restricted</span>
        </div>

        <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Circulating Coins</span>
            <Coins className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-sm font-black text-amber-300 font-mono truncate">🪙 {stats.totalCoins.toLocaleString()}</p>
          <span className="text-[10px] text-slate-400">Total User Balance</span>
        </div>

        <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Total Diamonds</span>
            <Gem className="w-4 h-4 text-cyan-400" />
          </div>
          <p className="text-sm font-black text-cyan-300 font-mono truncate">💎 {stats.totalDiamonds.toLocaleString()}</p>
          <span className="text-[10px] text-slate-400">Total Diamonds Vault</span>
        </div>
      </div>

      {/* 3. SEARCH & ADVANCED FILTER BAR */}
      <div className="p-4 rounded-3xl bg-white/5 border border-white/10 space-y-3 shadow-xl backdrop-blur-md">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-2.5">
          {/* SEARCH INPUT */}
          <div className="lg:col-span-4 flex items-center gap-2 bg-black/50 px-3 py-2 rounded-2xl border border-white/10 focus-within:border-amber-400/60 transition-all">
            <Search className="w-4 h-4 text-slate-400 shrink-0" />
            <select
              value={searchField}
              onChange={(e) => setSearchField(e.target.value as any)}
              className="bg-transparent text-amber-300 text-xs font-bold focus:outline-none cursor-pointer pr-1 border-r border-white/10"
            >
              <option value="all" className="bg-[#1a0b2e]">All Fields</option>
              <option value="name" className="bg-[#1a0b2e]">Name</option>
              <option value="uid" className="bg-[#1a0b2e]">UID</option>
              <option value="id" className="bg-[#1a0b2e]">ID</option>
              <option value="email" className="bg-[#1a0b2e]">Email</option>
              <option value="phone" className="bg-[#1a0b2e]">Phone</option>
            </select>
            <input
              type="text"
              placeholder="Search user by name, UID, email..."
              value={searchQuery}
              onChange={(e) => { setSearchQuery(e.target.value); setCurrentPage(1); }}
              className="w-full bg-transparent text-white text-xs placeholder:text-slate-500 focus:outline-none"
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="text-slate-400 hover:text-white text-xs font-bold px-1"
              >
                ✕
              </button>
            )}
          </div>

          {/* ROLE FILTER */}
          <div className="lg:col-span-2 flex items-center gap-2 bg-black/50 px-3 py-2 rounded-2xl border border-white/10 text-xs">
            <Shield className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="text-slate-400">Role:</span>
            <select
              value={roleFilter}
              onChange={(e) => { setRoleFilter(e.target.value); setCurrentPage(1); }}
              className="bg-transparent text-white font-bold focus:outline-none w-full cursor-pointer"
            >
              <option value="all" className="bg-[#1a0b2e]">All Roles</option>
              <option value="staff" className="bg-[#1a0b2e]">🛡️ All Staff Only</option>
              <option value="ceo" className="bg-[#1a0b2e]">👑 CEO</option>
              <option value="gm" className="bg-[#1a0b2e]">General Manager (GM)</option>
              <option value="super_admin" className="bg-[#1a0b2e]">Super Admin</option>
              <option value="manager" className="bg-[#1a0b2e]">Manager</option>
              <option value="bd" className="bg-[#1a0b2e]">Business Dev (BD)</option>
              <option value="agency" className="bg-[#1a0b2e]">Agency</option>
              <option value="host" className="bg-[#1a0b2e]">Host</option>
              <option value="official_staff" className="bg-[#1a0b2e]">Official Staff</option>
              <option value="user" className="bg-[#1a0b2e]">Normal User</option>
            </select>
          </div>

          {/* STATUS FILTER */}
          <div className="lg:col-span-2 flex items-center gap-2 bg-black/50 px-3 py-2 rounded-2xl border border-white/10 text-xs">
            <SlidersHorizontal className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <span className="text-slate-400">Status:</span>
            <select
              value={statusFilter}
              onChange={(e) => { setStatusFilter(e.target.value as any); setCurrentPage(1); }}
              className="bg-transparent text-white font-bold focus:outline-none w-full cursor-pointer"
            >
              <option value="all" className="bg-[#1a0b2e]">All Statuses</option>
              <option value="active" className="bg-[#1a0b2e]">● Active Accounts</option>
              <option value="banned" className="bg-[#1a0b2e]">⛔ Banned Accounts</option>
              <option value="online" className="bg-[#1a0b2e]">🟢 Online Now</option>
              <option value="offline" className="bg-[#1a0b2e]">⚪ Offline</option>
            </select>
          </div>

          {/* VIP FILTER */}
          <div className="lg:col-span-2 flex items-center gap-2 bg-black/50 px-3 py-2 rounded-2xl border border-white/10 text-xs">
            <Crown className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="text-slate-400">VIP:</span>
            <select
              value={vipFilter}
              onChange={(e) => { setVipFilter(e.target.value as any); setCurrentPage(1); }}
              className="bg-transparent text-white font-bold focus:outline-none w-full cursor-pointer"
            >
              <option value="all" className="bg-[#1a0b2e]">All VIP</option>
              <option value="none" className="bg-[#1a0b2e]">Standard</option>
              <option value="vip" className="bg-[#1a0b2e]">VIP</option>
              <option value="svip" className="bg-[#1a0b2e]">SVIP</option>
            </select>
          </div>

          {/* VIEW MODE & SORT TOGGLE */}
          <div className="lg:col-span-2 flex items-center justify-end gap-1.5">
            <div className="flex items-center bg-black/50 p-1 rounded-xl border border-white/10">
              <button
                onClick={() => setViewMode('table')}
                className={`p-1.5 rounded-lg text-xs transition-all ${
                  viewMode === 'table' ? 'bg-amber-400 text-black font-black shadow' : 'text-slate-400 hover:text-white'
                }`}
                title="Table View"
              >
                <Layers className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setViewMode('grid')}
                className={`p-1.5 rounded-lg text-xs transition-all ${
                  viewMode === 'grid' ? 'bg-amber-400 text-black font-black shadow' : 'text-slate-400 hover:text-white'
                }`}
                title="Grid / Card View"
              >
                <Building2 className="w-3.5 h-3.5" />
              </button>
            </div>

            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-black/50 text-white text-[11px] font-bold px-2 py-2 rounded-xl border border-white/10 cursor-pointer focus:outline-none"
            >
              <option value="createdAt" className="bg-[#1a0b2e]">Sort: Date</option>
              <option value="level" className="bg-[#1a0b2e]">Sort: Level</option>
              <option value="coins" className="bg-[#1a0b2e]">Sort: Coins</option>
              <option value="diamonds" className="bg-[#1a0b2e]">Sort: Diamonds</option>
              <option value="name" className="bg-[#1a0b2e]">Sort: Name</option>
            </select>

            <button
              onClick={() => setSortOrder(o => (o === 'asc' ? 'desc' : 'asc'))}
              className="p-2 bg-black/50 hover:bg-white/10 text-slate-300 rounded-xl border border-white/10 transition-all"
              title={`Toggle sort order (Currently ${sortOrder.toUpperCase()})`}
            >
              <ArrowUpDown className="w-3.5 h-3.5 text-amber-400" />
            </button>
          </div>
        </div>
      </div>

      {/* 4. MAIN CONTENT: TABLE OR GRID VIEW */}
      {isFirestoreLoading ? (
        <div className="p-16 rounded-3xl bg-white/5 border border-white/10 flex flex-col items-center justify-center gap-3">
          <RefreshCw className="w-8 h-8 text-amber-400 animate-spin" />
          <p className="text-sm font-bold text-white">Loading users from Cloud Firestore...</p>
          <p className="text-xs text-slate-400">Fetching document references from /users collection</p>
        </div>
      ) : viewMode === 'table' ? (
        /* TABLE VIEW */
        <div className="rounded-3xl bg-white/5 border border-white/10 overflow-hidden shadow-2xl backdrop-blur-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-black/50 text-slate-300 font-black uppercase text-[11px] border-b border-white/10 tracking-wider">
                <tr>
                  <th className="p-3.5">User Profile & ID</th>
                  <th className="p-3.5">UID Badge</th>
                  <th className="p-3.5">Role & Identity</th>
                  <th className="p-3.5">VIP & Levels</th>
                  <th className="p-3.5">Balances</th>
                  <th className="p-3.5">Status & Ban</th>
                  <th className="p-3.5 text-right">Moderation Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-slate-200">
                {paginatedUsers.map((u, uIndex) => {
                  const staffIdentity = getEffectiveStaffIdentity(u);
                  const isUserBanned = u.status === 'banned';

                  return (
                    <tr key={`usr-row-${u.id}-${uIndex}`} className="hover:bg-white/[0.04] transition-colors group">
                      {/* USER PROFILE */}
                      <td className="p-3.5">
                        <div className="flex items-center gap-3">
                          <div className="relative">
                            <img 
                              src={u.avatar} 
                              alt={u.name} 
                              className="w-10 h-10 rounded-full object-cover border-2 border-white/20 group-hover:border-amber-400 transition-all shadow-md" 
                            />
                            <span className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-[#1a0b2e] ${
                              u.isOnline ? 'bg-emerald-400' : 'bg-slate-500'
                            }`} />
                          </div>
                          <div>
                            <p className="font-extrabold text-white flex items-center gap-1.5">
                              {u.name}
                              {staffIdentity?.isVerified && (
                                <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" title="Verified Staff" />
                              )}
                              <span className="text-[10px] text-slate-400 font-mono">({u.country || 'US'})</span>
                            </p>
                            <p className="text-[10px] text-slate-400 font-mono">{u.email}</p>
                          </div>
                        </div>
                      </td>

                      {/* UID BADGE */}
                      <td className="p-3.5">
                        <ProfileIdBadge uid={u.uid} size="sm" showGroupTag={true} canCopy={true} />
                      </td>

                      {/* ROLE & STAFF IDENTITY */}
                      <td className="p-3.5">
                        <div className="space-y-1">
                          <span className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider border shadow-sm ${
                            u.role === 'ceo' ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-black border-amber-300 font-black' :
                            u.role === 'gm' ? 'bg-purple-600/30 text-purple-200 border-purple-400/40' :
                            u.role === 'super_admin' ? 'bg-rose-500/20 text-rose-300 border-rose-400/40' :
                            u.role === 'manager' ? 'bg-blue-500/20 text-blue-300 border-blue-400/40' :
                            u.role === 'bd' ? 'bg-amber-500/20 text-amber-300 border-amber-400/40' :
                            u.role === 'agency' ? 'bg-indigo-500/20 text-indigo-300 border-indigo-400/40' :
                            u.role === 'host' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400/40' :
                            'bg-white/5 text-slate-400 border-white/10'
                          }`}>
                            {u.role}
                          </span>
                          {staffIdentity && (
                            <p className="text-[9px] text-amber-300 font-bold truncate max-w-[130px]" title={staffIdentity.title}>
                              🎖️ {staffIdentity.title}
                            </p>
                          )}
                        </div>
                      </td>

                      {/* VIP & LEVELS */}
                      <td className="p-3.5">
                        <div className="space-y-0.5 text-[11px]">
                          <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                            u.vipLevel === 'svip' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm' :
                            u.vipLevel === 'vip' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' :
                            'text-slate-500 bg-white/5'
                          }`}>
                            {u.vipLevel}
                          </span>
                          <div className="flex items-center gap-2 font-mono text-[10px] text-slate-300 pt-0.5">
                            <span className="text-amber-400">📤 Lv.{u.sendingLevel || u.level || 1}</span>
                            <span className="text-cyan-400">📥 Lv.{u.receivingLevel || 1}</span>
                          </div>
                        </div>
                      </td>

                      {/* BALANCES */}
                      <td className="p-3.5 font-mono">
                        <p className="text-amber-300 font-bold flex items-center gap-1">
                          <span>🪙</span> {(u.coins || 0).toLocaleString()}
                        </p>
                        <p className="text-cyan-300 font-bold flex items-center gap-1 text-[11px]">
                          <span>💎</span> {(u.diamonds || 0).toLocaleString()}
                        </p>
                      </td>

                      {/* STATUS & BAN */}
                      <td className="p-3.5">
                        {isUserBanned ? (
                          <div className="space-y-1">
                            <span className="inline-flex items-center gap-1 text-[10px] font-black px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 animate-pulse shadow-sm">
                              <Ban className="w-3 h-3 text-rose-400" /> BANNED
                            </span>
                            <p className="text-[9px] text-rose-300/90 font-medium truncate max-w-[140px]" title={u.banReason}>
                              {u.banReason || 'Policy Violation'}
                            </p>
                            {u.banExpiresAt && (
                              <p className="text-[8px] text-slate-400 font-mono">
                                Exp: {new Date(u.banExpiresAt).toLocaleDateString()}
                              </p>
                            )}
                          </div>
                        ) : (
                          <div className="space-y-0.5">
                            <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2.5 py-0.5 rounded-full ${
                              u.isOnline ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-slate-500/20 text-slate-400'
                            }`}>
                              <span className={`w-1.5 h-1.5 rounded-full ${u.isOnline ? 'bg-emerald-400' : 'bg-slate-400'}`} />
                              {u.isOnline ? 'ONLINE' : 'OFFLINE'}
                            </span>
                            <p className="text-[9px] text-emerald-400 font-medium">Good Standing</p>
                          </div>
                        )}
                      </td>

                      {/* ACTIONS */}
                      <td className="p-3.5 text-right">
                        <div className="flex items-center justify-end gap-1.5 flex-wrap">
                          {/* VIEW PROFILE BUTTON */}
                          <button
                            onClick={() => { setSelectedUser(u); setDrawerTab('profile'); }}
                            className="px-2.5 py-1 bg-amber-400/20 text-amber-300 hover:bg-amber-400 hover:text-black font-bold text-[11px] rounded-xl border border-amber-400/30 transition-all flex items-center gap-1 shadow-sm active:scale-95"
                            title="Inspect Detailed Profile"
                          >
                            <Eye className="w-3 h-3" /> Profile
                          </button>

                          {/* BAN / UNBAN CONTROLS */}
                          {isUserBanned ? (
                            <button
                              onClick={() => { setUnbanModalUser(u); setUnbanReason('Account restored after review'); }}
                              className="px-2.5 py-1 bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500 hover:text-black font-bold text-[11px] rounded-xl border border-emerald-500/40 transition-all flex items-center gap-1 shadow-sm active:scale-95"
                              title="Unban this user"
                            >
                              <CheckCircle2 className="w-3 h-3 text-emerald-400" /> Unban
                            </button>
                          ) : (
                            <button
                              onClick={() => { setBanModalUser(u); setBanReason(''); setBanCategory('Harassment & Toxicity'); setBanType('temporary'); setBanDurationHours(24); }}
                              disabled={u.role === 'ceo'}
                              className="px-2.5 py-1 bg-rose-500/20 text-rose-300 hover:bg-rose-500 hover:text-white font-bold text-[11px] rounded-xl border border-rose-500/40 transition-all flex items-center gap-1 shadow-sm active:scale-95 disabled:opacity-30 disabled:cursor-not-allowed"
                              title={u.role === 'ceo' ? 'CEO cannot be banned' : 'Ban this account'}
                            >
                              <Ban className="w-3 h-3 text-rose-400" /> Ban
                            </button>
                          )}

                          {/* EDIT UID (CEO/GM ONLY) */}
                          {isCeoOrGm && (
                            <button
                              onClick={() => { setEditUidUser(u); setNewUidInput(u.uid); setConfirmUidInput(u.uid); setUidReasonInput(''); setShowUidConfirmStep(false); }}
                              className="p-1.5 bg-amber-500/20 text-amber-300 hover:bg-amber-400 hover:text-black rounded-xl border border-amber-400/30 transition-all active:scale-95"
                              title="Edit User UID (CEO/GM Privilege)"
                            >
                              <Shield className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {/* WALLET ADJUST */}
                          <button
                            onClick={() => { setWalletModalUser(u); setWalletAdjustAmount(1000); setWalletAdjustType('coins'); setWalletAdjustAction('credit'); }}
                            className="p-1.5 bg-cyan-500/20 text-cyan-300 hover:bg-cyan-400 hover:text-black rounded-xl border border-cyan-400/30 transition-all active:scale-95"
                            title="Adjust Coins/Diamonds"
                          >
                            <Wallet className="w-3.5 h-3.5" />
                          </button>

                          {/* QUICK EDIT PROFILE */}
                          <button
                            onClick={() => openEditProfileModal(u)}
                            className="p-1.5 bg-white/10 hover:bg-white/20 text-white rounded-xl transition-all active:scale-95"
                            title="Edit Account Details"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}

                {paginatedUsers.length === 0 && (
                  <tr>
                    <td colSpan={7} className="p-12 text-center text-slate-400 text-xs">
                      <Users className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                      <p className="font-bold text-slate-300">No user records match current search or filters.</p>
                      <p className="text-[11px] text-slate-500">Try adjusting your filter parameters or search terms.</p>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* PAGINATION CONTROLS */}
          <div className="p-4 bg-black/50 border-t border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-300">
            <div className="flex items-center gap-3">
              <span>Showing <strong>{paginatedUsers.length}</strong> of <strong>{filteredUsers.length}</strong> Users</span>
              <div className="flex items-center gap-1.5">
                <span className="text-slate-500">Per page:</span>
                {[10, 25, 50].map(size => (
                  <button
                    key={size}
                    onClick={() => { setItemsPerPage(size); setCurrentPage(1); }}
                    className={`px-2 py-0.5 rounded-lg font-bold text-[10px] transition-all ${
                      itemsPerPage === size ? 'bg-amber-400 text-black font-black' : 'bg-white/5 text-slate-400 hover:text-white'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                disabled={currentPage === 1}
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                className="px-3 py-1.5 bg-white/10 hover:bg-white/20 disabled:opacity-20 rounded-xl text-white font-bold transition-all flex items-center gap-1"
              >
                <ChevronLeft className="w-3.5 h-3.5" /> Prev
              </button>
              <span className="px-3 py-1 bg-black/40 rounded-xl font-mono text-amber-300 font-bold border border-white/10">
                {currentPage} / {totalPages}
              </span>
              <button
                disabled={currentPage === totalPages}
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                className="px-3 py-1.5 bg-white/10 hover:bg-white/20 disabled:opacity-20 rounded-xl text-white font-bold transition-all flex items-center gap-1"
              >
                Next <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* GRID / CARD VIEW */
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {paginatedUsers.map((u, uIndex) => {
              const staffIdentity = getEffectiveStaffIdentity(u);
              const isUserBanned = u.status === 'banned';

              return (
                <div 
                  key={`usr-card-${u.id}-${uIndex}`} 
                  className={`p-5 rounded-3xl bg-white/5 border backdrop-blur-xl transition-all shadow-xl space-y-4 relative group ${
                    isUserBanned ? 'border-rose-500/40 bg-rose-950/10' : 'border-white/10 hover:border-amber-400/50'
                  }`}
                >
                  {/* Top Bar with Avatar & UID */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <img 
                          src={u.avatar} 
                          alt={u.name} 
                          className="w-13 h-13 rounded-2xl object-cover border-2 border-amber-400 shadow-md" 
                        />
                        <span className={`absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full border-2 border-[#1a0b2e] ${
                          u.isOnline ? 'bg-emerald-400 animate-pulse' : 'bg-slate-500'
                        }`} />
                      </div>
                      <div>
                        <h4 className="font-extrabold text-white text-sm flex items-center gap-1.5">
                          {u.name}
                          {staffIdentity?.isVerified && <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />}
                        </h4>
                        <p className="text-xs text-slate-400">{u.email}</p>
                        <p className="text-[10px] text-slate-500 font-mono">Country: {u.country || 'US'}</p>
                      </div>
                    </div>

                    <ProfileIdBadge uid={u.uid} size="sm" showGroupTag={true} />
                  </div>

                  {/* Role & Status Pill */}
                  <div className="flex items-center justify-between gap-2 pt-1">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase bg-purple-500/20 text-purple-300 border border-purple-500/40">
                      {u.role}
                    </span>

                    {isUserBanned ? (
                      <span className="inline-flex items-center gap-1 text-[10px] font-black px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 animate-pulse">
                        <Ban className="w-3 h-3" /> BANNED
                      </span>
                    ) : (
                      <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded-full border border-emerald-500/30">
                        ● ACTIVE
                      </span>
                    )}
                  </div>

                  {/* Staff Identity preview */}
                  {staffIdentity && (
                    <div className="p-2.5 rounded-2xl bg-black/40 border border-white/5 text-[11px] space-y-1">
                      <p className="text-amber-300 font-bold flex items-center gap-1">
                        <span>🎖️</span> {staffIdentity.title}
                      </p>
                      <p className="text-slate-400 text-[10px]">Dept: {staffIdentity.department} • Staff ID: {staffIdentity.staffId}</p>
                    </div>
                  )}

                  {/* Balances & Levels */}
                  <div className="grid grid-cols-2 gap-2 p-3 rounded-2xl bg-black/50 border border-white/10 text-xs font-mono">
                    <div>
                      <span className="text-[10px] text-slate-400 block">Coins Balance</span>
                      <span className="font-bold text-amber-300">🪙 {(u.coins || 0).toLocaleString()}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block">Diamonds</span>
                      <span className="font-bold text-cyan-300">💎 {(u.diamonds || 0).toLocaleString()}</span>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <button
                      onClick={() => { setSelectedUser(u); setDrawerTab('profile'); }}
                      className="py-2 bg-amber-400/20 text-amber-300 hover:bg-amber-400 hover:text-black font-bold text-xs rounded-xl border border-amber-400/30 transition-all flex items-center justify-center gap-1.5 shadow-sm"
                    >
                      <Eye className="w-3.5 h-3.5" /> Full Profile
                    </button>

                    {isUserBanned ? (
                      <button
                        onClick={() => { setUnbanModalUser(u); setUnbanReason('Account restored after review'); }}
                        className="py-2 bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500 hover:text-black font-bold text-xs rounded-xl border border-emerald-500/40 transition-all flex items-center justify-center gap-1.5 shadow-sm"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" /> Unban
                      </button>
                    ) : (
                      <button
                        onClick={() => { setBanModalUser(u); setBanReason(''); setBanCategory('Harassment & Toxicity'); setBanType('temporary'); setBanDurationHours(24); }}
                        disabled={u.role === 'ceo'}
                        className="py-2 bg-rose-500/20 text-rose-300 hover:bg-rose-500 hover:text-white font-bold text-xs rounded-xl border border-rose-500/40 transition-all flex items-center justify-center gap-1.5 shadow-sm disabled:opacity-30"
                      >
                        <Ban className="w-3.5 h-3.5" /> Ban Account
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* GRID PAGINATION */}
          <div className="p-4 bg-black/50 border border-white/10 rounded-3xl flex items-center justify-between text-xs text-slate-300">
            <span>Page {currentPage} of {totalPages} ({filteredUsers.length} Users)</span>
            <div className="flex items-center gap-1.5">
              <button
                disabled={currentPage === 1}
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                className="px-3 py-1.5 bg-white/10 hover:bg-white/20 disabled:opacity-20 rounded-xl text-white font-bold"
              >
                Prev
              </button>
              <button
                disabled={currentPage === totalPages}
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                className="px-3 py-1.5 bg-white/10 hover:bg-white/20 disabled:opacity-20 rounded-xl text-white font-bold"
              >
                Next
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 5. MODALS & DRAWER */}
      {/* ========================================================================= */}

      {/* A. BAN USER MODAL */}
      {banModalUser && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#1a0b2e] border border-rose-500/40 rounded-3xl p-6 w-full max-w-lg space-y-5 shadow-2xl animate-scaleUp">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-rose-500/20 text-rose-400">
                  <Ban className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-white text-base">Enforce Account Ban</h3>
                  <p className="text-xs text-rose-300">Direct Firestore write with live enforcement</p>
                </div>
              </div>
              <button 
                onClick={() => setBanModalUser(null)} 
                className="text-slate-400 hover:text-white font-bold text-lg p-1"
              >
                ✕
              </button>
            </div>

            {/* TARGET INFO */}
            <div className="p-3 bg-black/50 rounded-2xl border border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img src={banModalUser.avatar} alt="Avatar" className="w-10 h-10 rounded-full object-cover border border-rose-400" />
                <div>
                  <h4 className="font-extrabold text-white text-xs">{banModalUser.name}</h4>
                  <p className="text-[10px] text-slate-400">{banModalUser.email}</p>
                </div>
              </div>
              <ProfileIdBadge uid={banModalUser.uid} size="sm" showGroupTag={true} />
            </div>

            <div className="space-y-3.5 text-xs">
              {/* BAN CATEGORY */}
              <div>
                <label className="block text-slate-300 font-bold mb-1.5">Violation Policy Category</label>
                <select
                  value={banCategory}
                  onChange={(e) => setBanCategory(e.target.value)}
                  className="w-full bg-black/50 text-white font-bold px-3.5 py-2.5 rounded-xl border border-white/10 focus:outline-none focus:border-rose-400 cursor-pointer"
                >
                  <option value="Harassment & Toxicity">Harassment & Toxic Behavior</option>
                  <option value="Financial Fraud / Chargeback">Financial Fraud / Unauthorized Recharges</option>
                  <option value="Room Disruption & Spam">Room Audio Disruption & Rapid Spamming</option>
                  <option value="Inappropriate Media & NSFW">Inappropriate Media / Avatar / Content</option>
                  <option value="Impersonation of Staff">Impersonation of Staff or Officers</option>
                  <option value="Underage or Safety Violation">Safety & Security Violation</option>
                  <option value="Custom Breach">Custom Policy Breach</option>
                </select>
              </div>

              {/* BAN TYPE (TEMPORARY VS PERMANENT) */}
              <div>
                <label className="block text-slate-300 font-bold mb-1.5">Ban Severity / Scope</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setBanType('temporary')}
                    className={`py-2.5 rounded-xl font-bold border transition-all text-xs flex items-center justify-center gap-1.5 ${
                      banType === 'temporary'
                        ? 'bg-rose-500/20 text-rose-300 border-rose-400 shadow-md font-black'
                        : 'bg-black/40 text-slate-400 border-white/10 hover:bg-white/5'
                    }`}
                  >
                    <Clock className="w-3.5 h-3.5" /> Temporary Suspension
                  </button>
                  <button
                    type="button"
                    onClick={() => setBanType('permanent')}
                    className={`py-2.5 rounded-xl font-bold border transition-all text-xs flex items-center justify-center gap-1.5 ${
                      banType === 'permanent'
                        ? 'bg-rose-600 text-white border-rose-400 shadow-md font-black'
                        : 'bg-black/40 text-slate-400 border-white/10 hover:bg-white/5'
                    }`}
                  >
                    <ShieldAlert className="w-3.5 h-3.5" /> Permanent Ban
                  </button>
                </div>
              </div>

              {/* DURATION PRESETS (FOR TEMPORARY) */}
              {banType === 'temporary' && (
                <div>
                  <label className="block text-slate-300 font-bold mb-1.5">Duration Presets</label>
                  <div className="grid grid-cols-4 gap-1.5">
                    {[
                      { hours: 1, label: '1 Hour' },
                      { hours: 6, label: '6 Hours' },
                      { hours: 24, label: '24 Hours' },
                      { hours: 72, label: '3 Days' },
                      { hours: 168, label: '7 Days' },
                      { hours: 720, label: '30 Days' }
                    ].map(p => (
                      <button
                        key={p.hours}
                        type="button"
                        onClick={() => setBanDurationHours(p.hours)}
                        className={`py-2 rounded-xl text-[11px] font-bold border transition-all ${
                          banDurationHours === p.hours
                            ? 'bg-amber-400 text-black border-amber-300 font-black shadow'
                            : 'bg-black/40 text-slate-300 border-white/10 hover:bg-white/5'
                        }`}
                      >
                        {p.label}
                      </button>
                    ))}
                  </div>
                  <p className="text-[10px] text-amber-300 mt-1.5 font-mono">
                    Expires at: {new Date(Date.now() + banDurationHours * 3600000).toLocaleString()}
                  </p>
                </div>
              )}

              {/* BAN REASON & AUDIT NOTES */}
              <div>
                <label className="block text-slate-300 font-bold mb-1.5">Sanction Notes / Reason for User</label>
                <textarea
                  rows={2}
                  value={banReason}
                  onChange={(e) => setBanReason(e.target.value)}
                  placeholder="Describe violation and internal reference code..."
                  className="w-full bg-black/50 text-white p-3 rounded-2xl border border-white/10 focus:outline-none focus:border-rose-400 text-xs"
                />
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setBanModalUser(null)}
                className="flex-1 py-2.5 bg-white/10 text-white hover:bg-white/20 rounded-xl font-bold text-xs transition-all"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleExecuteBan}
                disabled={isSubmittingBan}
                className="flex-1 py-2.5 bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-black text-xs rounded-xl shadow-lg transition-all flex items-center justify-center gap-1.5 disabled:opacity-50"
              >
                <Ban className="w-4 h-4" />
                {isSubmittingBan ? 'Enforcing in Cloud DB...' : `Confirm & Enforce Ban`}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* B. UNBAN USER MODAL */}
      {unbanModalUser && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#1a0b2e] border border-emerald-500/40 rounded-3xl p-6 w-full max-w-md space-y-4 shadow-2xl animate-scaleUp">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-white text-base">Restore Account (Unban)</h3>
                  <p className="text-xs text-emerald-300">Lifts all restrictions in Cloud Firestore</p>
                </div>
              </div>
              <button onClick={() => setUnbanModalUser(null)} className="text-slate-400 hover:text-white font-bold text-lg">✕</button>
            </div>

            <div className="p-3 bg-black/50 rounded-2xl border border-white/10 flex items-center justify-between">
              <div>
                <h4 className="font-extrabold text-white text-xs">{unbanModalUser.name}</h4>
                <p className="text-[10px] text-rose-300">Currently Banned: {unbanModalUser.banReason || 'Policy Violation'}</p>
              </div>
              <ProfileIdBadge uid={unbanModalUser.uid} size="sm" showGroupTag={true} />
            </div>

            <div className="space-y-2 text-xs">
              <label className="block text-slate-300 font-bold">Unban Audit Justification</label>
              <input
                type="text"
                value={unbanReason}
                onChange={(e) => setUnbanReason(e.target.value)}
                className="w-full bg-black/50 text-white px-3.5 py-2.5 rounded-xl border border-white/10 focus:outline-none focus:border-emerald-400"
                placeholder="Reason for lifting penalty..."
              />
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setUnbanModalUser(null)}
                className="flex-1 py-2.5 bg-white/10 text-white hover:bg-white/20 rounded-xl font-bold text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleExecuteUnban}
                disabled={isSubmittingUnban}
                className="flex-1 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-black font-black text-xs rounded-xl shadow-lg transition-all flex items-center justify-center gap-1.5"
              >
                <CheckCircle2 className="w-4 h-4" />
                {isSubmittingUnban ? 'Restoring...' : 'Confirm Unban'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* C. EDIT USER UID MODAL (CEO/GM EXCLUSIVE) */}
      {editUidUser && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#1a0b2e] border border-amber-400/40 rounded-3xl p-6 w-full max-w-md space-y-4 shadow-2xl animate-scaleUp">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-amber-400" />
                <div>
                  <h3 className="font-black text-white text-base">Edit User UID</h3>
                  <p className="text-xs text-amber-300">CEO / GM Exclusive Governance</p>
                </div>
              </div>
              <button onClick={() => { setEditUidUser(null); setShowUidConfirmStep(false); }} className="text-slate-400 hover:text-white font-bold text-lg">✕</button>
            </div>

            {!showUidConfirmStep ? (
              <div className="space-y-3.5 text-xs">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Target Account</label>
                  <div className="flex items-center justify-between p-2.5 bg-black/40 rounded-xl border border-white/10">
                    <span className="font-bold text-white">{editUidUser.name}</span>
                    <ProfileIdBadge uid={editUidUser.uid} size="xs" showGroupTag={true} />
                  </div>
                </div>

                <div>
                  <label className="block text-amber-300 font-bold mb-1">New User UID</label>
                  <input
                    type="text"
                    value={newUidInput}
                    onChange={(e) => setNewUidInput(e.target.value)}
                    placeholder="e.g. 77, 888, VIP777"
                    className="w-full bg-black/60 text-amber-300 font-mono font-bold px-3.5 py-2.5 rounded-xl border border-amber-400/40 focus:outline-none focus:border-amber-400"
                  />
                  {newUidInput.trim() && (
                    <div className="mt-2 p-2 bg-black/50 rounded-xl border border-white/10 flex items-center justify-between">
                      <span className="text-[10px] text-slate-400">Dynamic Badge Preview:</span>
                      <ProfileIdBadge uid={newUidInput.trim()} size="sm" showGroupTag={true} />
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-amber-300 font-bold mb-1">Confirm New User UID</label>
                  <input
                    type="text"
                    value={confirmUidInput}
                    onChange={(e) => setConfirmUidInput(e.target.value)}
                    placeholder="Re-type new UID..."
                    className="w-full bg-black/60 text-amber-300 font-mono font-bold px-3.5 py-2.5 rounded-xl border border-amber-400/40 focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-bold mb-1">Audit Reason (Optional)</label>
                  <input
                    type="text"
                    value={uidReasonInput}
                    onChange={(e) => setUidReasonInput(e.target.value)}
                    placeholder="e.g. VIP Custom Vanity ID allocation"
                    className="w-full bg-black/40 text-white text-xs px-3.5 py-2 rounded-xl border border-white/10"
                  />
                </div>
              </div>
            ) : (
              /* CONFIRMATION SCREEN */
              <div className="p-4 bg-amber-500/10 border border-amber-400/50 rounded-2xl space-y-3 text-xs">
                <div className="flex items-center gap-2 text-amber-300 font-black text-sm">
                  <AlertTriangle className="w-5 h-5 text-amber-400 animate-bounce" />
                  <span>Confirm UID Transformation</span>
                </div>
                <p className="text-slate-200">
                  Are you sure you want to change UID for <strong>{editUidUser.name}</strong>?
                </p>
                <div className="p-3 bg-black/60 rounded-xl flex items-center justify-between font-mono">
                  <ProfileIdBadge uid={editUidUser.uid} size="sm" showGroupTag={true} />
                  <span className="text-amber-400 font-bold">➔</span>
                  <ProfileIdBadge uid={newUidInput.trim()} size="sm" showGroupTag={true} />
                </div>
              </div>
            )}

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  if (showUidConfirmStep) setShowUidConfirmStep(false);
                  else setEditUidUser(null);
                }}
                className="flex-1 py-2.5 bg-white/10 text-white rounded-xl font-bold text-xs"
              >
                {showUidConfirmStep ? 'Back' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={handleUpdateUid}
                disabled={isUpdatingUid}
                className="flex-1 py-2.5 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 text-black font-black text-xs rounded-xl shadow-lg flex items-center justify-center gap-1.5"
              >
                <Shield className="w-3.5 h-3.5" />
                {isUpdatingUid ? 'Updating...' : showUidConfirmStep ? 'Confirm & Commit' : 'Proceed'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* D. WALLET ADJUSTMENT MODAL */}
      {walletModalUser && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#1a0b2e] border border-cyan-400/40 rounded-3xl p-6 w-full max-w-md space-y-4 shadow-2xl animate-scaleUp">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-300">
                  <Wallet className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-white text-base">Adjust User Balance</h3>
                  <p className="text-xs text-cyan-300">Cloud Firestore direct adjustment</p>
                </div>
              </div>
              <button onClick={() => setWalletModalUser(null)} className="text-slate-400 hover:text-white font-bold text-lg">✕</button>
            </div>

            <div className="p-3 bg-black/50 rounded-2xl border border-white/10 flex items-center justify-between">
              <div>
                <h4 className="font-extrabold text-white text-xs">{walletModalUser.name}</h4>
                <p className="text-[10px] text-slate-400">UID: {walletModalUser.uid}</p>
              </div>
              <div className="text-right font-mono text-xs">
                <p className="text-amber-300">🪙 {(walletModalUser.coins || 0).toLocaleString()}</p>
                <p className="text-cyan-300">💎 {(walletModalUser.diamonds || 0).toLocaleString()}</p>
              </div>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">Currency Type</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setWalletAdjustType('coins')}
                    className={`py-2 rounded-xl font-bold border transition-all text-xs flex items-center justify-center gap-1.5 ${
                      walletAdjustType === 'coins'
                        ? 'bg-amber-400 text-black border-amber-300 font-black shadow'
                        : 'bg-black/40 text-slate-300 border-white/10'
                    }`}
                  >
                    🪙 Coins
                  </button>
                  <button
                    type="button"
                    onClick={() => setWalletAdjustType('diamonds')}
                    className={`py-2 rounded-xl font-bold border transition-all text-xs flex items-center justify-center gap-1.5 ${
                      walletAdjustType === 'diamonds'
                        ? 'bg-cyan-400 text-black border-cyan-300 font-black shadow'
                        : 'bg-black/40 text-slate-300 border-white/10'
                    }`}
                  >
                    💎 Diamonds
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Action</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setWalletAdjustAction('credit')}
                    className={`py-2 rounded-xl font-bold border transition-all text-xs flex items-center justify-center gap-1.5 ${
                      walletAdjustAction === 'credit'
                        ? 'bg-emerald-500 text-black border-emerald-400 font-black shadow'
                        : 'bg-black/40 text-slate-300 border-white/10'
                    }`}
                  >
                    ➕ Credit (Add)
                  </button>
                  <button
                    type="button"
                    onClick={() => setWalletAdjustAction('debit')}
                    className={`py-2 rounded-xl font-bold border transition-all text-xs flex items-center justify-center gap-1.5 ${
                      walletAdjustAction === 'debit'
                        ? 'bg-rose-500 text-white border-rose-400 font-black shadow'
                        : 'bg-black/40 text-slate-300 border-white/10'
                    }`}
                  >
                    ➖ Debit (Deduct)
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Amount</label>
                <input
                  type="number"
                  min={1}
                  value={walletAdjustAmount}
                  onChange={(e) => setWalletAdjustAmount(Number(e.target.value))}
                  className="w-full bg-black/60 text-white font-mono font-bold px-3.5 py-2.5 rounded-xl border border-white/10 focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Reason / Notes</label>
                <input
                  type="text"
                  value={walletAdjustReason}
                  onChange={(e) => setWalletAdjustReason(e.target.value)}
                  className="w-full bg-black/40 text-white px-3.5 py-2 rounded-xl border border-white/10 text-xs"
                />
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setWalletModalUser(null)}
                className="flex-1 py-2.5 bg-white/10 text-white rounded-xl font-bold text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleExecuteWalletAdjust}
                disabled={isSubmittingWallet}
                className="flex-1 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-400 text-black font-black text-xs rounded-xl shadow-lg flex items-center justify-center gap-1.5"
              >
                <Wallet className="w-3.5 h-3.5" />
                {isSubmittingWallet ? 'Updating...' : 'Commit Balance'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* E. QUICK EDIT PROFILE MODAL */}
      {editProfileUser && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <form 
            onSubmit={handleSaveProfile} 
            className="bg-[#1a0b2e] border border-amber-400/40 rounded-3xl p-6 w-full max-w-2xl space-y-4 shadow-2xl animate-scaleUp max-h-[92vh] overflow-y-auto"
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-amber-400/20 border border-amber-400/30 text-amber-300">
                  <Edit2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-white text-base">Edit User Profile Details</h3>
                  <p className="text-[11px] text-slate-400">Update account credentials, media, and authorization tier</p>
                </div>
              </div>
              <button 
                type="button" 
                onClick={() => setEditProfileUser(null)} 
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-all font-bold"
              >
                ✕
              </button>
            </div>

            {/* Validation Error Banner */}
            {(formValidationError || avatarError) && (
              <div className="p-3 bg-rose-500/20 border border-rose-500/40 rounded-2xl flex items-center gap-2.5 text-rose-300 text-xs">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{formValidationError || avatarError}</span>
              </div>
            )}

            <div className="space-y-4 text-xs">
              {/* ====================================================
                  1. PROFILE AVATAR IMAGE & CONTROLS
                 ==================================================== */}
              <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-amber-300 font-black tracking-wide flex items-center gap-1.5 uppercase text-[11px]">
                    <Camera className="w-3.5 h-3.5" /> 1. Profile Avatar Image
                  </label>
                  <span className="text-[10px] text-slate-400">JPG, PNG, WEBP (Max 6MB)</span>
                </div>

                <div className="flex flex-col sm:flex-row items-center gap-4">
                  {/* Avatar Preview Box with Crop/Zoom/Rotate */}
                  <div className="relative w-24 h-24 sm:w-28 sm:h-28 rounded-2xl overflow-hidden border-2 border-amber-400/50 bg-black/60 shrink-0 shadow-lg flex items-center justify-center">
                    <img
                      src={editProfileForm.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80'}
                      alt="Avatar Preview"
                      style={{
                        transform: `scale(${avatarZoom}) rotate(${avatarRotation}deg)`,
                        transition: 'transform 0.15s ease-out'
                      }}
                      className="w-full h-full object-cover select-none"
                    />
                    {avatarUploadLoading && (
                      <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center gap-1 backdrop-blur-xs">
                        <RefreshCw className="w-5 h-5 text-amber-400 animate-spin" />
                        <span className="text-[9px] text-amber-300 font-bold">Uploading...</span>
                      </div>
                    )}
                  </div>

                  {/* Upload Actions & Controls */}
                  <div className="flex-1 w-full space-y-2.5">
                    {/* Hidden Native File Input */}
                    <input
                      ref={avatarFileInputRef}
                      type="file"
                      accept="image/jpeg,image/jpg,image/png,image/webp"
                      onChange={handleAvatarFileSelect}
                      className="hidden"
                    />

                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() => avatarFileInputRef.current?.click()}
                        disabled={avatarUploadLoading}
                        className="px-3 py-1.5 bg-amber-400 hover:bg-amber-300 text-black font-bold text-[11px] rounded-xl flex items-center gap-1.5 transition-all shadow-md active:scale-95 disabled:opacity-50"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        {editProfileForm.avatar ? 'Change Photo' : 'Upload Photo'}
                      </button>

                      <button
                        type="button"
                        onClick={() => setAvatarRotation(prev => (prev + 90) % 360)}
                        className="px-2.5 py-1.5 bg-white/10 hover:bg-white/20 text-white font-medium text-[11px] rounded-xl flex items-center gap-1 transition-all"
                        title="Rotate 90 degrees"
                      >
                        <RotateCw className="w-3.5 h-3.5 text-amber-300" /> Rotate
                      </button>

                      <button
                        type="button"
                        onClick={handleRemoveAvatar}
                        className="px-2.5 py-1.5 bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 font-medium text-[11px] rounded-xl border border-rose-500/30 flex items-center gap-1 transition-all"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-rose-400" /> Remove
                      </button>
                    </div>

                    {/* Zoom / Crop Slider */}
                    <div className="flex items-center gap-2.5 pt-1">
                      <ZoomOut className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <input
                        type="range"
                        min="0.8"
                        max="2.5"
                        step="0.05"
                        value={avatarZoom}
                        onChange={(e) => setAvatarZoom(parseFloat(e.target.value))}
                        className="w-full h-1.5 bg-white/20 rounded-lg appearance-none cursor-pointer accent-amber-400"
                      />
                      <ZoomIn className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="text-[10px] text-amber-300 font-mono w-10 text-right">
                        {Math.round(avatarZoom * 100)}%
                      </span>
                    </div>

                    {/* Quick Preset Avatars */}
                    <div className="flex items-center gap-1.5 pt-1 overflow-x-auto pb-1">
                      <span className="text-[10px] text-slate-400 shrink-0">Presets:</span>
                      {PRESET_AVATARS.map((url, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => {
                            setEditProfileForm(prev => ({ ...prev, avatar: url }));
                            setAvatarZoom(1);
                            setAvatarRotation(0);
                            setAvatarError(null);
                          }}
                          className={`w-6 h-6 rounded-lg overflow-hidden border transition-all shrink-0 ${
                            editProfileForm.avatar === url ? 'border-amber-400 ring-2 ring-amber-400/50' : 'border-white/20 opacity-70 hover:opacity-100'
                          }`}
                        >
                          <img src={url} alt={`Preset ${idx + 1}`} className="w-full h-full object-cover" />
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* ====================================================
                  2. FULL NAME
                 ==================================================== */}
              <div>
                <label className="block text-slate-200 font-bold mb-1">
                  2. Full Name <span className="text-amber-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={editProfileForm.name || ''}
                  onChange={(e) => setEditProfileForm({ ...editProfileForm, name: e.target.value })}
                  placeholder="Enter full display name"
                  className="w-full bg-black/40 text-white px-3.5 py-2.5 rounded-xl border border-white/15 font-bold focus:outline-none focus:border-amber-400 transition-colors"
                />
              </div>

              {/* ====================================================
                  3. USER ID / PROFILE ID (RBAC PROTECTED)
                 ==================================================== */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-slate-200 font-bold flex items-center gap-1.5">
                    3. User ID / Profile ID (UID)
                    {isCeoOrGm ? (
                      <span className="text-[10px] text-emerald-400 font-semibold bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/30 flex items-center gap-1">
                        <Unlock className="w-2.5 h-2.5" /> CEO/GM Editable
                      </span>
                    ) : (
                      <span className="text-[10px] text-slate-400 font-semibold bg-white/5 px-2 py-0.5 rounded-md border border-white/10 flex items-center gap-1">
                        <Lock className="w-2.5 h-2.5" /> Read Only
                      </span>
                    )}
                  </label>
                  <span className="text-[10px] text-slate-400 font-mono">Database ID: {editProfileUser.id}</span>
                </div>

                {isCeoOrGm ? (
                  <div className="space-y-1">
                    <input
                      type="text"
                      value={editProfileForm.uid || ''}
                      onChange={(e) => setEditProfileForm({ ...editProfileForm, uid: e.target.value })}
                      placeholder="e.g. 777888 or Royal_King"
                      className="w-full bg-black/40 text-amber-300 px-3.5 py-2.5 rounded-xl border border-amber-400/30 font-mono font-bold focus:outline-none focus:border-amber-400"
                    />
                    <p className="text-[10px] text-slate-400">
                      Format: 1-20 alphanumeric characters, underscores, or hyphens.
                    </p>
                  </div>
                ) : (
                  <div className="flex items-center justify-between px-3.5 py-2.5 bg-black/30 border border-white/10 rounded-xl text-slate-400">
                    <span className="font-mono font-bold text-slate-300">{editProfileUser.uid}</span>
                    <span className="text-[10px] text-slate-500 flex items-center gap-1">
                      <Lock className="w-3 h-3" /> Requires CEO or GM role to customize
                    </span>
                  </div>
                )}
              </div>

              {/* ====================================================
                  4. EMAIL & 5. PHONE
                 ==================================================== */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-200 font-bold mb-1 flex items-center gap-1">
                    <Mail className="w-3.5 h-3.5 text-slate-400" /> 4. Email <span className="text-amber-400">*</span>
                  </label>
                  <input
                    type="email"
                    required
                    value={editProfileForm.email || ''}
                    onChange={(e) => setEditProfileForm({ ...editProfileForm, email: e.target.value })}
                    placeholder="user@example.com"
                    className="w-full bg-black/40 text-white px-3 py-2 rounded-xl border border-white/15 focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-slate-200 font-bold mb-1 flex items-center gap-1">
                    <Phone className="w-3.5 h-3.5 text-slate-400" /> 5. Phone
                  </label>
                  <input
                    type="text"
                    value={editProfileForm.phone || ''}
                    onChange={(e) => setEditProfileForm({ ...editProfileForm, phone: e.target.value })}
                    className="w-full bg-black/40 text-white px-3 py-2 rounded-xl border border-white/15 font-mono"
                    placeholder="+1 555-0199"
                  />
                </div>
              </div>

              {/* ====================================================
                  6. COUNTRY & 7. SVIP / VIP TIER
                 ==================================================== */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-200 font-bold mb-1 flex items-center gap-1">
                    <Globe className="w-3.5 h-3.5 text-slate-400" /> 6. Country
                  </label>
                  <select
                    value={editProfileForm.country || 'United States'}
                    onChange={(e) => {
                      const selectedCountryName = e.target.value;
                      const matched = COUNTRY_OPTIONS.find(c => c.name === selectedCountryName);
                      setEditProfileForm({
                        ...editProfileForm,
                        country: selectedCountryName,
                        countryFlag: matched?.flag || '🇺🇸'
                      });
                    }}
                    className="w-full bg-black/40 text-white px-3 py-2 rounded-xl border border-white/15 font-medium"
                  >
                    {COUNTRY_OPTIONS.map((c) => (
                      <option key={c.code} value={c.name} className="bg-[#1a0b2e]">
                        {c.flag} {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-200 font-bold mb-1 flex items-center gap-1">
                    <Crown className="w-3.5 h-3.5 text-amber-400" /> 7. SVIP / VIP Tier
                  </label>
                  <select
                    value={
                      editProfileForm.vipLevel === 'svip' 
                        ? 'SVIP 1' 
                        : editProfileForm.vipLevel === 'vip' 
                        ? 'VIP 1' 
                        : (editProfileForm.vipLevel || 'none')
                    }
                    onChange={(e) => {
                      const val = e.target.value;
                      const isSvip = val.toLowerCase().includes('svip');
                      const isVip = val.toLowerCase().includes('vip');
                      setEditProfileForm({
                        ...editProfileForm,
                        vipLevel: isSvip ? 'svip' : isVip ? 'vip' : 'none'
                      });
                    }}
                    className="w-full bg-black/40 text-amber-300 font-bold px-3 py-2 rounded-xl border border-amber-400/30"
                  >
                    {VIP_TIER_OPTIONS.map((tier) => (
                      <option key={tier.value} value={tier.value} className="bg-[#1a0b2e] text-white">
                        {tier.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* ====================================================
                  8. WEALTH LEVEL & 9. CHARM LEVEL
                 ==================================================== */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-amber-300 font-bold flex items-center gap-1">
                      <Coins className="w-3.5 h-3.5" /> 8. Wealth / Sending Level
                    </label>
                    <span className="text-[10px] text-slate-400 font-mono">1 - 200</span>
                  </div>
                  <input
                    type="number"
                    min={1}
                    max={200}
                    value={editProfileForm.sendingLevel ?? editProfileForm.level ?? 1}
                    onChange={(e) => setEditProfileForm({ ...editProfileForm, sendingLevel: Number(e.target.value) })}
                    className="w-full bg-black/40 text-amber-300 font-mono font-bold px-3 py-2 rounded-xl border border-amber-400/30 focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-cyan-300 font-bold flex items-center gap-1">
                      <Gem className="w-3.5 h-3.5" /> 9. Charm / Receiving Level
                    </label>
                    <span className="text-[10px] text-slate-400 font-mono">1 - 200</span>
                  </div>
                  <input
                    type="number"
                    min={1}
                    max={200}
                    value={editProfileForm.receivingLevel ?? 1}
                    onChange={(e) => setEditProfileForm({ ...editProfileForm, receivingLevel: Number(e.target.value) })}
                    className="w-full bg-black/40 text-cyan-300 font-mono font-bold px-3 py-2 rounded-xl border border-cyan-400/30 focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              {/* ====================================================
                  10. BIO
                 ==================================================== */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-slate-200 font-bold">10. Bio</label>
                  <span className={`text-[10px] font-mono ${
                    (editProfileForm.bio?.length || 0) > 480 ? 'text-amber-400' : 'text-slate-400'
                  }`}>
                    {(editProfileForm.bio?.length || 0)} / 500
                  </span>
                </div>
                <textarea
                  rows={2}
                  maxLength={500}
                  value={editProfileForm.bio || ''}
                  onChange={(e) => setEditProfileForm({ ...editProfileForm, bio: e.target.value })}
                  placeholder="User personal status or bio statement..."
                  className="w-full bg-black/40 text-white p-3 rounded-xl border border-white/15 text-xs focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* ====================================================
                  11. GENDER
                 ==================================================== */}
              <div>
                <label className="block text-slate-200 font-bold mb-1">11. Gender</label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { val: 'male', label: '👨 Male' },
                    { val: 'female', label: '👩 Female' },
                    { val: 'other', label: '✨ Other' },
                    { val: 'prefer_not_to_say', label: '🔒 Prefer not to say' }
                  ].map(g => (
                    <button
                      key={g.val}
                      type="button"
                      onClick={() => setEditProfileForm({ ...editProfileForm, gender: g.val as any })}
                      className={`py-2 px-3 rounded-xl font-bold text-xs border transition-all text-center ${
                        (editProfileForm.gender || 'other') === g.val
                          ? 'bg-amber-400 text-black border-amber-400 shadow-md'
                          : 'bg-black/40 text-slate-300 border-white/10 hover:bg-white/10'
                      }`}
                    >
                      {g.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="flex gap-3 pt-3 border-t border-white/10">
              <button
                type="button"
                onClick={() => setEditProfileUser(null)}
                className="flex-1 py-2.5 bg-white/10 hover:bg-white/20 text-white rounded-xl font-bold text-xs transition-all"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSavingProfile || avatarUploadLoading}
                className="flex-1 py-2.5 bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-black font-black text-xs rounded-xl shadow-lg flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50"
              >
                {isSavingProfile ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    Saving Changes...
                  </>
                ) : (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    Save Profile Changes
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* F. DETAILED USER PROFILE SLIDE-OVER / DRAWER */}
      {selectedUser && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#1a0b2e]/95 border border-amber-400/40 rounded-3xl p-6 w-full max-w-2xl space-y-5 shadow-2xl my-8 animate-scaleUp">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-3.5">
                <img 
                  src={selectedUser.avatar} 
                  alt="Avatar" 
                  className="w-14 h-14 rounded-2xl object-cover border-2 border-amber-400 shadow-md" 
                />
                <div>
                  <h3 className="font-black text-white text-base flex items-center gap-2">
                    {selectedUser.name}
                    <span className="text-xs text-amber-300 font-mono">({selectedUser.country || 'US'})</span>
                  </h3>
                  <p className="text-xs text-slate-400 flex items-center gap-2">
                    User ID / UID: <span className="font-mono text-amber-300 font-bold">{selectedUser.uid || selectedUser.id}</span>
                  </p>
                </div>
              </div>
              <button 
                onClick={() => setSelectedUser(null)} 
                className="text-slate-400 hover:text-white font-bold text-lg p-1.5 rounded-xl hover:bg-white/10"
              >
                ✕
              </button>
            </div>

            {/* Drawer Sub-Tabs */}
            <div className="flex flex-wrap gap-1.5 border-b border-white/10 pb-2 text-xs">
              {[
                { id: 'profile', label: '👤 Profile & Identity' },
                { id: 'ban_governance', label: '⛔ Ban & Sanctions' },
                { id: 'wallet', label: '🪙 Wallet & Balances' },
                { id: 'uid', label: '🔒 UID Customizer' }
              ].map(t => (
                <button
                  key={t.id}
                  onClick={() => setDrawerTab(t.id as any)}
                  className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
                    drawerTab === t.id ? 'bg-amber-400 text-black font-black shadow' : 'bg-white/5 text-slate-300 hover:bg-white/10'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>

            {/* DRAWER TAB: PROFILE */}
            {drawerTab === 'profile' && (
              <div className="space-y-4">
                {getEffectiveStaffIdentity(selectedUser) && (
                  <div className="p-3.5 rounded-2xl bg-black/50 border border-white/10 space-y-2">
                    <p className="text-[10px] font-black text-amber-300 uppercase tracking-wider">Official Staff Identity</p>
                    <StaffIdentityBadgeCard identity={getEffectiveStaffIdentity(selectedUser)!} />
                  </div>
                )}

                <div className="grid grid-cols-2 gap-3 text-xs bg-black/40 p-4 rounded-2xl border border-white/10">
                  <div><span className="text-slate-400">Email:</span> <p className="font-bold text-white">{selectedUser.email}</p></div>
                  <div><span className="text-slate-400">Phone:</span> <p className="font-bold text-white font-mono">{selectedUser.phone || 'None'}</p></div>
                  <div><span className="text-slate-400">Role:</span> <p className="font-black text-amber-300 uppercase">{selectedUser.role}</p></div>
                  <div>
                    <span className="text-slate-400">Account Health:</span>
                    <p className={`font-black uppercase ${selectedUser.status === 'banned' ? 'text-rose-400 animate-pulse' : 'text-emerald-400'}`}>
                      {selectedUser.status === 'banned' ? `⛔ BANNED (${selectedUser.banType || 'TEMP'})` : '● ACTIVE (Good Standing)'}
                    </p>
                  </div>
                  <div><span className="text-slate-400">VIP Tier:</span> <p className="font-bold text-cyan-300 uppercase">{selectedUser.vipLevel}</p></div>
                  <div><span className="text-slate-400">Country:</span> <p className="font-bold text-white">{selectedUser.country || 'US'}</p></div>
                  <div><span className="text-slate-400">📤 Sending Level (Wealth):</span> <p className="font-bold text-amber-300 font-mono">Lv. {selectedUser.sendingLevel || selectedUser.level || 1}</p></div>
                  <div><span className="text-slate-400">📥 Receiving Level (Charm):</span> <p className="font-bold text-cyan-300 font-mono">Lv. {selectedUser.receivingLevel || 1}</p></div>
                  <div><span className="text-slate-400">🪙 Coins:</span> <p className="font-bold text-amber-300 font-mono">{(selectedUser.coins || 0).toLocaleString()}</p></div>
                  <div><span className="text-slate-400">💎 Diamonds:</span> <p className="font-bold text-cyan-300 font-mono">{(selectedUser.diamonds || 0).toLocaleString()}</p></div>
                  <div className="col-span-2"><span className="text-slate-400">Registered Date:</span> <p className="font-bold text-slate-300">{new Date(selectedUser.createdAt).toLocaleString()}</p></div>
                  <div className="col-span-2"><span className="text-slate-400">Bio:</span> <p className="text-slate-200 mt-0.5">{selectedUser.bio || 'No bio specified.'}</p></div>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      const u = selectedUser;
                      setSelectedUser(null);
                      openEditProfileModal(u);
                    }}
                    className="flex-1 py-2.5 bg-white/10 hover:bg-white/20 text-white font-bold text-xs rounded-xl transition-all"
                  >
                    Edit Profile Details
                  </button>
                  {onOpenStaffAssign && (
                    <button
                      onClick={() => {
                        const u = selectedUser;
                        setSelectedUser(null);
                        onOpenStaffAssign(u);
                      }}
                      className="flex-1 py-2.5 bg-gradient-to-r from-amber-400 to-yellow-500 text-black font-black text-xs rounded-xl shadow-lg flex items-center justify-center gap-1.5"
                    >
                      <Sparkles className="w-4 h-4" /> Staff Identity Config
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* DRAWER TAB: BAN GOVERNANCE */}
            {drawerTab === 'ban_governance' && (
              <div className="space-y-3 text-xs">
                {selectedUser.status === 'banned' ? (
                  <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 space-y-2">
                    <div className="flex items-center justify-between text-rose-400 font-black">
                      <span className="flex items-center gap-1.5">
                        <Ban className="w-4 h-4" /> Active Ban Penalty Record
                      </span>
                      <span className="px-2 py-0.5 rounded bg-rose-500/20 uppercase font-mono text-[10px]">
                        {selectedUser.banType || 'TEMPORARY'}
                      </span>
                    </div>
                    <p className="text-slate-200">Reason: <strong>{selectedUser.banReason || 'Policy Violation'}</strong></p>
                    {selectedUser.banExpiresAt && (
                      <p className="text-slate-400 font-mono">Expiration: {new Date(selectedUser.banExpiresAt).toLocaleString()}</p>
                    )}
                    {selectedUser.bannedByName && (
                      <p className="text-amber-300">Enforced By: {selectedUser.bannedByName} ({selectedUser.bannedByRole})</p>
                    )}

                    <button
                      onClick={() => {
                        const u = selectedUser;
                        setSelectedUser(null);
                        setUnbanModalUser(u);
                        setUnbanReason('Account restored after review');
                      }}
                      className="w-full mt-3 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-black font-black rounded-xl transition-all shadow-md flex items-center justify-center gap-1.5"
                    >
                      <CheckCircle2 className="w-4 h-4" /> Lift Ban & Restore Account
                    </button>
                  </div>
                ) : (
                  <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 space-y-3">
                    <div className="flex items-center gap-2 text-emerald-400 font-bold">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Account is in Good Standing</span>
                    </div>
                    <p className="text-slate-300">
                      No active bans or room mutes registered for this user in Cloud Firestore.
                    </p>
                    <button
                      onClick={() => {
                        const u = selectedUser;
                        setSelectedUser(null);
                        setBanModalUser(u);
                        setBanReason('');
                        setBanCategory('Harassment & Toxicity');
                        setBanType('temporary');
                        setBanDurationHours(24);
                      }}
                      disabled={selectedUser.role === 'ceo'}
                      className="w-full py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-black rounded-xl transition-all shadow flex items-center justify-center gap-1.5 disabled:opacity-40"
                    >
                      <Ban className="w-4 h-4" /> Enforce Ban Sanction
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* DRAWER TAB: WALLET */}
            {drawerTab === 'wallet' && (
              <div className="space-y-3 text-xs bg-black/40 p-4 rounded-2xl border border-white/10">
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 bg-amber-500/10 rounded-xl border border-amber-400/20">
                    <span className="text-slate-400 block text-[10px]">Coins Vault</span>
                    <span className="text-amber-300 font-mono font-bold text-base">🪙 {(selectedUser.coins || 0).toLocaleString()}</span>
                  </div>
                  <div className="p-3 bg-cyan-500/10 rounded-xl border border-cyan-400/20">
                    <span className="text-slate-400 block text-[10px]">Diamonds Vault</span>
                    <span className="text-cyan-300 font-mono font-bold text-base">💎 {(selectedUser.diamonds || 0).toLocaleString()}</span>
                  </div>
                </div>

                <button
                  onClick={() => {
                    const u = selectedUser;
                    setSelectedUser(null);
                    setWalletModalUser(u);
                    setWalletAdjustAmount(1000);
                    setWalletAdjustType('coins');
                    setWalletAdjustAction('credit');
                  }}
                  className="w-full py-2.5 bg-cyan-500 hover:bg-cyan-400 text-black font-black rounded-xl shadow transition-all flex items-center justify-center gap-1.5"
                >
                  <Wallet className="w-4 h-4" /> Adjust Balance Funds
                </button>
              </div>
            )}

            {/* DRAWER TAB: UID */}
            {drawerTab === 'uid' && (
              <div className="space-y-3 text-xs bg-black/40 p-4 rounded-2xl border border-white/10">
                <div className="flex items-center gap-2 p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300">
                  <Shield className="w-4 h-4 shrink-0" />
                  <span>Rule: Only CEO & GM have authority to edit custom User IDs (UID).</span>
                </div>
                <div className="p-3 bg-black/50 rounded-xl flex items-center justify-between">
                  <span className="text-slate-400">Current Assigned UID:</span>
                  <ProfileIdBadge uid={selectedUser.uid} size="sm" showGroupTag={true} />
                </div>
                {isCeoOrGm ? (
                  <button
                    onClick={() => {
                      const u = selectedUser;
                      setSelectedUser(null);
                      setEditUidUser(u);
                      setNewUidInput(u.uid);
                      setConfirmUidInput(u.uid);
                      setUidReasonInput('');
                      setShowUidConfirmStep(false);
                    }}
                    className="w-full py-2.5 bg-gradient-to-r from-amber-400 to-yellow-500 text-black font-black rounded-xl shadow hover:brightness-110 flex items-center justify-center gap-1.5"
                  >
                    <Shield className="w-4 h-4" /> Launch UID Customizer Console
                  </button>
                ) : (
                  <p className="text-center text-slate-500 italic">Locked: Requires CEO or General Manager credentials.</p>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
