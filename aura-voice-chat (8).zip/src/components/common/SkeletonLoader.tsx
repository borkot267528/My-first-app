/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

export const RoomCardSkeleton: React.FC = () => {
  return (
    <div className="p-4 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 flex flex-col gap-3 animate-pulse shadow-xl">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          {/* Avatar Skeleton */}
          <div className="w-14 h-14 rounded-2xl bg-white/10 border border-white/10 flex-shrink-0" />
          <div className="space-y-2">
            {/* Title Skeleton */}
            <div className="h-4 w-36 bg-white/10 rounded-md" />
            {/* Topic Skeleton */}
            <div className="h-3 w-48 bg-white/10 rounded-md" />
          </div>
        </div>
        {/* Join/Enter Button Skeleton */}
        <div className="h-8 w-20 bg-white/15 rounded-2xl flex-shrink-0" />
      </div>

      {/* Bottom Tag Skeleton */}
      <div className="flex items-center justify-between pt-2 border-t border-white/10">
        <div className="flex items-center gap-2">
          <div className="h-3.5 w-16 bg-white/10 rounded-md" />
          <div className="h-3.5 w-20 bg-white/10 rounded-md" />
        </div>
        <div className="h-3.5 w-12 bg-white/10 rounded-md" />
      </div>
    </div>
  );
};

export const HomeRoomSkeleton: React.FC = () => {
  return (
    <div className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-md border border-white/10 flex items-center justify-between animate-pulse shadow-xl">
      <div className="flex items-center gap-3.5">
        <div className="w-14 h-14 rounded-2xl bg-white/10 border border-white/10 flex-shrink-0" />
        <div className="space-y-2">
          <div className="h-4 w-32 bg-white/10 rounded-md" />
          <div className="h-3 w-40 bg-white/10 rounded-md" />
          <div className="flex items-center gap-2 pt-1">
            <div className="h-3 w-14 bg-white/10 rounded-md" />
            <div className="h-3 w-16 bg-white/10 rounded-md" />
          </div>
        </div>
      </div>
      <div className="h-8 w-16 bg-white/15 rounded-xl flex-shrink-0" />
    </div>
  );
};

export const LeaderboardItemSkeleton: React.FC = () => {
  return (
    <div className="flex flex-col items-center p-2.5 rounded-2xl bg-white/5 backdrop-blur-md border border-white/10 text-center shadow animate-pulse">
      <div className="w-12 h-12 rounded-full bg-white/10 border border-white/10" />
      <div className="h-3 w-16 bg-white/10 rounded-md mt-2" />
      <div className="h-2.5 w-10 bg-white/10 rounded-md mt-1" />
    </div>
  );
};
