/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Copy, Check, Sparkles } from 'lucide-react';
import { getProfileIdColor, formatProfileId } from '../../lib/profileIdColor';

export interface ProfileIdBadgeProps {
  uid?: string | number | null;
  size?: 'xs' | 'sm' | 'md' | 'lg';
  showLabel?: boolean;
  showIcon?: boolean;
  showGroupTag?: boolean;
  canCopy?: boolean;
  className?: string;
  onCopy?: (uid: string) => void;
}

export const ProfileIdBadge: React.FC<ProfileIdBadgeProps> = ({
  uid,
  size = 'sm',
  showLabel = true,
  showIcon = true,
  showGroupTag = false,
  canCopy = false,
  className = '',
  onCopy
}) => {
  const [copied, setCopied] = useState(false);
  const colorInfo = getProfileIdColor(uid);
  const formattedUid = formatProfileId(uid);

  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!uid) return;
    navigator.clipboard.writeText(formattedUid);
    setCopied(true);
    if (onCopy) onCopy(formattedUid);
    setTimeout(() => setCopied(false), 2000);
  };

  const sizeClasses = {
    xs: 'text-[9px] px-1.5 py-0.2 rounded-md gap-1 font-mono',
    sm: 'text-[11px] px-2 py-0.5 rounded-lg gap-1.5 font-mono',
    md: 'text-xs px-2.5 py-1 rounded-xl gap-2 font-mono',
    lg: 'text-sm px-3 py-1.5 rounded-2xl gap-2.5 font-mono'
  };

  const iconSizes = {
    xs: 'text-[9px]',
    sm: 'text-[10px]',
    md: 'text-xs',
    lg: 'text-sm'
  };

  return (
    <div
      className={`inline-flex items-center backdrop-blur-md border transition-all duration-300 ${colorInfo.badgeClass} ${sizeClasses[size]} ${className}`}
      title={`${colorInfo.groupName} (Range: ${colorInfo.range})`}
    >
      {showIcon && (
        <span className={iconSizes[size]}>
          {colorInfo.icon}
        </span>
      )}

      {showLabel && (
        <span className="opacity-75 font-sans font-semibold uppercase tracking-wider text-[80%]">
          UID:
        </span>
      )}

      <span className={`font-black tracking-wide ${colorInfo.textClass}`}>
        {formattedUid}
      </span>

      {showGroupTag && (
        <span className="text-[8px] uppercase tracking-wider px-1.5 py-0.2 bg-black/40 rounded border border-white/10 font-sans font-bold opacity-90">
          {colorInfo.range}
        </span>
      )}

      {canCopy && (
        <button
          onClick={handleCopy}
          className="ml-0.5 p-0.5 text-white/60 hover:text-white transition-colors rounded hover:bg-white/10"
          title="Copy UID"
          type="button"
        >
          {copied ? (
            <Check className="w-3 h-3 text-emerald-400 stroke-[3]" />
          ) : (
            <Copy className="w-3 h-3 stroke-[2]" />
          )}
        </button>
      )}
    </div>
  );
};
