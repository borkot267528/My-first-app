/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Palette, Sparkles, Check, X, Eye, 
  Crown, Image, RefreshCw, Wand2, Shield,
  Layers, ChevronRight, AlertCircle, Info, Heart
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ApiClient } from '../../lib/api';
import { ROOM_THEMES, RoomThemeConfig, getThemeById } from './roomThemes';

export interface RoomThemeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onThemeApplied?: (theme: RoomThemeConfig, backgroundUrl?: string) => void;
}

export const RoomThemeModal: React.FC<RoomThemeModalProps> = ({
  isOpen,
  onClose,
  onThemeApplied
}) => {
  const { activeRoom, setActiveRoom, currentUser, showNotification, setRoomMessages } = useApp();

  const currentTheme = getThemeById(activeRoom?.theme);
  const [selectedThemeId, setSelectedThemeId] = useState<string>(activeRoom?.theme || 'night');
  const [customBgUrl, setCustomBgUrl] = useState<string>(activeRoom?.backgroundUrl || '');
  const [useCustomWallpaper, setUseCustomWallpaper] = useState<boolean>(Boolean(activeRoom?.backgroundUrl));
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [isApplying, setIsApplying] = useState<boolean>(false);

  // Sync state when activeRoom changes or modal opens
  useEffect(() => {
    if (isOpen && activeRoom) {
      setSelectedThemeId(activeRoom.theme || 'night');
      setCustomBgUrl(activeRoom.backgroundUrl || '');
      setUseCustomWallpaper(Boolean(activeRoom.backgroundUrl));
    }
  }, [isOpen, activeRoom]);

  if (!isOpen || !activeRoom) return null;

  // Check if current user is the host or staff
  const isHost = Boolean(
    currentUser && (
      activeRoom.hostId === currentUser.id ||
      activeRoom.hostName === currentUser.name ||
      (activeRoom as any).hostUid === currentUser.uid ||
      ['admin', 'superadmin', 'manager', 'head_admin'].includes(currentUser.role)
    )
  );

  const selectedThemeConfig = getThemeById(selectedThemeId);

  const categories = [
    { id: 'all', label: 'All Themes' },
    { id: 'Night Mode', label: '🌙 Night Mode' },
    { id: 'Party', label: '🪩 Party' },
    { id: 'Chill', label: '☕ Chill' },
    { id: 'Cyberpunk', label: '⚡ Cyberpunk' },
    { id: 'Romantic', label: '💖 Romantic' },
    { id: 'Aurora', label: '✨ Aurora' },
    { id: 'Luxury', label: '👑 Luxury' }
  ];

  const filteredThemes = filterCategory === 'all'
    ? ROOM_THEMES
    : ROOM_THEMES.filter(t => t.category === filterCategory);

  const handleApplyTheme = async () => {
    if (!isHost) {
      showNotification('Only the room host or staff can change the room background theme.');
      return;
    }

    setIsApplying(true);
    try {
      const finalBgUrl = useCustomWallpaper && customBgUrl.trim() ? customBgUrl.trim() : (selectedThemeConfig.bgImage || undefined);
      
      // Update backend
      const updated = await ApiClient.updateRoomTheme(activeRoom.id, selectedThemeId, finalBgUrl);
      
      // Update local state
      setActiveRoom({
        ...activeRoom,
        theme: selectedThemeId,
        backgroundUrl: finalBgUrl
      });

      // Announce in room chat
      if (currentUser) {
        setRoomMessages(prev => [
          ...prev,
          {
            id: `theme-${Date.now()}`,
            roomId: activeRoom.id,
            userId: currentUser.id,
            userName: currentUser.name,
            userAvatar: currentUser.avatar,
            type: 'system',
            content: `🎨 Host changed the room visual theme to "${selectedThemeConfig.name}"! ✨ Enjoy the new atmosphere!`,
            timestamp: new Date().toISOString()
          }
        ]);
      }

      showNotification(`Room theme set to "${selectedThemeConfig.name}"!`);
      if (onThemeApplied) {
        onThemeApplied(selectedThemeConfig, finalBgUrl);
      }
      onClose();
    } catch (err: any) {
      showNotification(err.message || 'Failed to update room theme');
    } finally {
      setIsApplying(false);
    }
  };

  const handleResetDefault = async () => {
    if (!isHost) return;
    setIsApplying(true);
    try {
      await ApiClient.updateRoomTheme(activeRoom.id, 'night', '');
      setActiveRoom({
        ...activeRoom,
        theme: 'night',
        backgroundUrl: ''
      });
      setSelectedThemeId('night');
      setCustomBgUrl('');
      setUseCustomWallpaper(false);
      showNotification('Room theme reset to Night Mode default.');
      onClose();
    } catch (err: any) {
      showNotification(err.message || 'Failed to reset theme');
    } finally {
      setIsApplying(false);
    }
  };

  return (
    <div 
      className="fixed inset-0 z-[85] bg-black/80 backdrop-blur-xl flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fadeIn"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div 
        className="w-full max-w-xl bg-[#140a28]/95 backdrop-blur-2xl border-t sm:border border-white/15 rounded-t-[32px] sm:rounded-[32px] shadow-[0_20px_70px_rgba(0,0,0,0.85)] text-white overflow-hidden flex flex-col max-h-[92vh] sm:max-h-[85vh] animate-scaleUp"
      >
        {/* MOBILE PULL HANDLE */}
        <div className="pt-3 pb-1 sm:hidden">
          <div className="w-12 h-1.5 bg-white/20 rounded-full mx-auto" />
        </div>

        {/* MODAL HEADER */}
        <div className="px-5 py-4 border-b border-white/10 flex items-center justify-between bg-white/[0.03]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-400 via-pink-500 to-purple-600 p-[1.5px] flex items-center justify-center shadow-lg">
              <div className="w-full h-full bg-[#160a2c] rounded-[14px] flex items-center justify-center">
                <Palette className="w-5 h-5 text-amber-300" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-white text-base tracking-wide flex items-center gap-1.5">
                  Room Visual Themes & Customization
                </h3>
                {isHost ? (
                  <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                    <Crown className="w-3 h-3" /> HOST CONTROL
                  </span>
                ) : (
                  <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-slate-500/20 text-slate-300 border border-white/10">
                    PREVIEW MODE
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-300">
                Transform your voice room stage with dynamic ambient lighting & wallpapers
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white flex items-center justify-center transition-all active:scale-90 cursor-pointer"
            title="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* HOST NOTICE IF NOT HOST */}
        {!isHost && (
          <div className="px-4 py-2 bg-amber-500/10 border-b border-amber-500/20 flex items-center gap-2 text-xs text-amber-200">
            <Info className="w-4 h-4 shrink-0 text-amber-400" />
            <span>You are viewing theme previews. Only the room host can apply themes room-wide.</span>
          </div>
        )}

        {/* LIVE THEME PREVIEW BANNER */}
        <div className="p-4 sm:p-5 border-b border-white/10 bg-black/40">
          <div className="text-[11px] uppercase tracking-wider font-extrabold text-slate-400 mb-2 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Eye className="w-3.5 h-3.5 text-amber-400" /> Live Stage Backdrop Preview
            </span>
            <span className="text-amber-300 font-bold">
              {selectedThemeConfig.name} {selectedThemeConfig.icon}
            </span>
          </div>

          <div 
            className={`relative rounded-2xl overflow-hidden p-4 border border-white/20 shadow-2xl transition-all duration-300 min-h-[105px] flex flex-col justify-between`}
            style={{
              background: selectedThemeConfig.radialEffect,
              boxShadow: `0 0 35px ${selectedThemeConfig.glowColor}`
            }}
          >
            {/* Background image overlay */}
            {(useCustomWallpaper && customBgUrl.trim() ? customBgUrl.trim() : selectedThemeConfig.bgImage) && (
              <img 
                src={useCustomWallpaper && customBgUrl.trim() ? customBgUrl.trim() : selectedThemeConfig.bgImage} 
                alt="Theme Preview" 
                className="absolute inset-0 w-full h-full object-cover opacity-35 filter blur-[1px] pointer-events-none scale-105"
              />
            )}
            
            {/* Gradient Backdrop */}
            <div className={`absolute inset-0 bg-gradient-to-r ${selectedThemeConfig.gradientClass} opacity-85 pointer-events-none`} />

            {/* Content overlay */}
            <div className="relative z-10 flex items-start justify-between">
              <div className="flex items-center gap-2.5">
                <span className="text-3xl">{selectedThemeConfig.icon}</span>
                <div>
                  <h4 className="font-black text-white text-base drop-shadow-md flex items-center gap-2">
                    {selectedThemeConfig.name}
                    <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full border ${selectedThemeConfig.badgeClass}`}>
                      {selectedThemeConfig.category}
                    </span>
                  </h4>
                  <p className="text-xs text-slate-200 drop-shadow line-clamp-1">
                    {selectedThemeConfig.subtitle}
                  </p>
                </div>
              </div>

              {activeRoom.theme === selectedThemeId && !useCustomWallpaper && (
                <span className="px-2.5 py-1 rounded-xl bg-emerald-500/25 border border-emerald-400/50 text-emerald-300 font-extrabold text-[11px] flex items-center gap-1 shadow">
                  <Check className="w-3.5 h-3.5 stroke-[3]" /> CURRENT
                </span>
              )}
            </div>

            {/* Simulated Mini Seats Stage */}
            <div className="relative z-10 pt-3 flex items-center gap-2 overflow-x-auto no-scrollbar">
              <div className="px-2.5 py-1 rounded-xl bg-black/60 backdrop-blur-md border border-white/20 flex items-center gap-2 text-[11px]">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="font-bold text-white">Stage Lighting:</span>
                <span className="font-semibold text-slate-300">{selectedThemeConfig.category} Mood</span>
              </div>
              <div className="px-2.5 py-1 rounded-xl bg-black/60 backdrop-blur-md border border-white/20 text-[11px] text-slate-300 font-medium">
                {selectedThemeConfig.hasParticles ? `✨ Animated ${selectedThemeConfig.particleType} particles` : '🌌 Smooth atmosphere'}
              </div>
            </div>
          </div>
        </div>

        {/* CATEGORY FILTER TABS */}
        <div className="flex items-center gap-1.5 px-4 py-2.5 bg-black/30 border-b border-white/10 overflow-x-auto no-scrollbar">
          {categories.map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => setFilterCategory(cat.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
                filterCategory === cat.id
                  ? 'bg-gradient-to-r from-amber-500 to-pink-500 text-black font-extrabold shadow-md'
                  : 'bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* SCROLLABLE THEMES LIST */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-3.5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {filteredThemes.map((theme) => {
              const isSelected = selectedThemeId === theme.id && !useCustomWallpaper;
              const isCurrent = activeRoom.theme === theme.id;

              return (
                <button
                  key={theme.id}
                  type="button"
                  onClick={() => {
                    setSelectedThemeId(theme.id);
                    setUseCustomWallpaper(false);
                  }}
                  className={`group text-left p-3.5 rounded-2xl border transition-all duration-200 relative overflow-hidden flex flex-col justify-between min-h-[120px] shadow-lg cursor-pointer ${
                    isSelected
                      ? 'bg-white/15 border-amber-400 ring-2 ring-amber-400/50 scale-[1.02]'
                      : 'bg-white/5 hover:bg-white/10 border-white/10 hover:border-white/25 hover:scale-[1.01]'
                  }`}
                  style={{
                    boxShadow: isSelected ? `0 0 25px ${theme.glowColor}` : undefined
                  }}
                >
                  {/* Subtle Background Wallpaper Preview */}
                  {theme.bgImage && (
                    <img 
                      src={theme.bgImage} 
                      alt="" 
                      className="absolute inset-0 w-full h-full object-cover opacity-20 pointer-events-none group-hover:scale-110 transition-transform duration-500" 
                    />
                  )}
                  <div className={`absolute inset-0 bg-gradient-to-br ${theme.gradientClass} opacity-75 pointer-events-none`} />

                  <div className="relative z-10 flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <div className="w-10 h-10 rounded-2xl bg-black/50 border border-white/15 flex items-center justify-center text-xl shadow-inner group-hover:scale-110 transition-transform">
                        {theme.icon}
                      </div>
                      <div>
                        <h4 className="font-extrabold text-white text-sm flex items-center gap-1.5">
                          {theme.name}
                        </h4>
                        <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-full border ${theme.badgeClass}`}>
                          {theme.category}
                        </span>
                      </div>
                    </div>

                    {isSelected ? (
                      <div className="w-6 h-6 rounded-full bg-amber-400 text-black flex items-center justify-center font-black shadow">
                        <Check className="w-4 h-4 stroke-[3]" />
                      </div>
                    ) : isCurrent ? (
                      <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/20 px-2 py-0.5 rounded-full border border-emerald-500/30">
                        ACTIVE
                      </span>
                    ) : null}
                  </div>

                  <div className="relative z-10 mt-2">
                    <p className="text-[11px] text-slate-300 line-clamp-2 leading-relaxed">
                      {theme.description}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>

          {/* CUSTOM WALLPAPER OPTION */}
          <div className="p-4 rounded-2xl bg-white/[0.04] border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-white flex items-center gap-1.5 cursor-pointer">
                <Image className="w-4 h-4 text-purple-400" /> Custom Wallpaper Image URL
              </label>
              <button
                type="button"
                onClick={() => setUseCustomWallpaper(!useCustomWallpaper)}
                className={`px-2.5 py-1 rounded-xl text-xs font-bold border transition-colors cursor-pointer ${
                  useCustomWallpaper
                    ? 'bg-purple-500 text-white border-purple-400'
                    : 'bg-white/10 text-slate-300 border-white/15 hover:bg-white/20'
                }`}
              >
                {useCustomWallpaper ? 'Enabled' : 'Enable Custom'}
              </button>
            </div>

            {useCustomWallpaper && (
              <div className="space-y-2 animate-fadeIn">
                <input
                  type="text"
                  placeholder="https://images.unsplash.com/... or paste image URL"
                  value={customBgUrl}
                  onChange={(e) => setCustomBgUrl(e.target.value)}
                  className="w-full bg-black/40 text-xs text-white px-3.5 py-2.5 rounded-xl border border-white/15 focus:outline-none focus:border-amber-400"
                />
                
                {/* Wallpaper presets */}
                <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pt-1">
                  <span className="text-[10px] text-slate-400 font-bold shrink-0">Quick Wallpapers:</span>
                  {[
                    { label: '🌌 Cyber Stars', url: 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?auto=format&fit=crop&w=1200&q=80' },
                    { label: '🪩 Neon Disco', url: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?auto=format&fit=crop&w=1200&q=80' },
                    { label: '🌇 Sunset Gold', url: 'https://images.unsplash.com/photo-1518495973542-4542c06a5843?auto=format&fit=crop&w=1200&q=80' },
                    { label: '✨ Aurora Sky', url: 'https://images.unsplash.com/photo-1531366936337-7c912a4589a7?auto=format&fit=crop&w=1200&q=80' }
                  ].map((p, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setCustomBgUrl(p.url)}
                      className="px-2.5 py-1 rounded-lg bg-black/40 hover:bg-white/10 border border-white/10 text-[10px] text-slate-300 font-medium shrink-0 cursor-pointer"
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* MODAL FOOTER */}
        <div className="p-4 border-t border-white/10 bg-black/60 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={handleResetDefault}
            disabled={!isHost || isApplying}
            className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-slate-300 hover:text-white text-xs font-bold transition-all disabled:opacity-40 cursor-pointer"
          >
            Reset Default
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-slate-300 hover:text-white text-xs font-bold transition-all cursor-pointer"
            >
              Cancel
            </button>

            <button
              type="button"
              onClick={handleApplyTheme}
              disabled={!isHost || isApplying}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-pink-500 to-purple-600 hover:from-amber-400 hover:to-purple-500 text-black font-black text-xs shadow-lg transition-all active:scale-95 disabled:opacity-50 flex items-center gap-2 cursor-pointer"
            >
              {isApplying ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Applying Theme...</span>
                </>
              ) : (
                <>
                  <Wand2 className="w-3.5 h-3.5" />
                  <span>{isHost ? 'Apply Theme to Room' : 'Host Permission Required'}</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
