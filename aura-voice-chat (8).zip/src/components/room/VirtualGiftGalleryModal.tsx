/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Gift, VoiceRoom, MicSeat } from '../../types';
import { VirtualGifts, SpeakerRecipient } from './VirtualGifts';

export interface VirtualGiftGalleryModalProps {
  isOpen: boolean;
  onClose: () => void;
  room: VoiceRoom;
  selectedSeat?: MicSeat | null;
  onGiftSent?: (gift: Gift, count: number, recipientName: string) => void;
}

export const VirtualGiftGalleryModal: React.FC<VirtualGiftGalleryModalProps> = ({
  isOpen,
  onClose,
  room,
  selectedSeat,
  onGiftSent
}) => {
  return (
    <VirtualGifts
      isOpen={isOpen}
      onClose={onClose}
      room={room}
      selectedSpeakerId={selectedSeat?.userId}
      onGiftSent={onGiftSent}
    />
  );
};

export { VirtualGifts };
export default VirtualGiftGalleryModal;
