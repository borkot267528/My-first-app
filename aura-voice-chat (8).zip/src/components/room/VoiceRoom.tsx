/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  Radio, 
  Users, 
  Mic, 
  MicOff, 
  Crown, 
  Sparkles, 
  Flame, 
  Music, 
  Gamepad2, 
  Globe, 
  Send, 
  AlertCircle, 
  RefreshCw, 
  LogOut, 
  Share2, 
  Info,
  ChevronDown,
  Plus,
  Heart,
  Smile,
  Shield,
  Search,
  Wand2,
  Swords,
  Youtube,
  HeartHandshake,
  Headphones,
  ArrowRight,
  Lock,
  Gift as GiftIcon
} from 'lucide-react';
import { useApp, useAppOptional } from '../../context/AppContext';
import { VoiceRoom as VoiceRoomType, MicSeat, RoomMessage, User, LuckyBag as LuckyBagType, Gift as GiftType } from '../../types';
import { ApiClient } from '../../lib/api';
import { ProfileIdBadge } from '../common/ProfileIdBadge';
import { ToolsModal, ToolTabType } from './ToolsModal';
import { PKBattle } from '../pk/PKBattle';
import { LuckyBag } from '../luckybag/LuckyBag';
import { VirtualGifts } from './VirtualGifts';

export interface ParticipantAvatarItem {
  id: string;
  name: string;
  avatar: string;
  isHost?: boolean;
  isMuted?: boolean;
  isSpeaking?: boolean;
  seatIndex: number;
  role?: 'host' | 'speaker' | 'vip' | 'listener';
  contributionCoin?: number;
  vipLevel?: string;
  nigoId?: string;
}

export interface VoiceRoomProps {
  /** Voice room data object. If omitted, falls back to activeRoom in AppContext */
  room?: VoiceRoomType | null;
  /** Custom list of participant avatars to override default room seats */
  participants?: ParticipantAvatarItem[];
  /** Controlled initial mute state */
  isMuted?: boolean;
  /** Callback fired when mute state changes */
  onMuteToggle?: (isMuted: boolean) => void;
  /** Callback fired when a participant avatar or seat is clicked */
  onParticipantClick?: (participant: ParticipantAvatarItem | MicSeat) => void;
  /** Callback fired when user posts a message */
  onSendMessage?: (content: string) => void;
  /** Callback when user clicks leave */
  onLeaveRoom?: () => void;
  /** Callback when user switches rooms */
  onSelectRoom?: (room: VoiceRoomType) => void;
  /** Optional custom CSS classes */
  className?: string;
  /** Force standalone single-room interface even if rooms array is present */
  standalone?: boolean;
  /** Whether to show the room switcher bar */
  showRoomSwitcher?: boolean;

  // Grid compatibility props for HomePage & existing callers
  rooms?: VoiceRoomType[];
  category?: string;
  searchQuery?: string;
  activeOnly?: boolean;
  onRoomClick?: (room: VoiceRoomType) => void;
  title?: string;
  subtitle?: string;
  gridColsClassName?: string;
  showCategoryFilter?: boolean;
  showSearch?: boolean;
  emptyMessage?: string;
  isLoading?: boolean;
  slots?: any[];
}

export type VoiceRoomGridProps = VoiceRoomProps;

/**
 * VoiceRoom: Complete voice room component featuring:
 * 1. A grid of participant avatars with live speaking halo ripples & mute indicators
 * 2. A mute/unmute control button using the Web Audio & Microphone API with live volume meter
 * 3. A real-time chat display area with reactions, avatars, timestamps, and message input
 * 4. Room header & quick room switcher making it ideal as the primary interface for the app
 */
export const VoiceRoom: React.FC<VoiceRoomProps> = (props) => {
  // If `rooms` is passed without an explicit `room` or `standalone`, and user is in rooms listing mode,
  // we check if they want the full VoiceRoom primary interface with the first room featured, or the grid.
  // For HomePage compatibility (where rooms list is small and compact), render the grid if specified.
  if (props.rooms && !props.room && !props.standalone && props.gridColsClassName) {
    return <VoiceRoomsGridComponent {...props} />;
  }

  return <VoiceRoomMainComponent {...props} />;
};

export default VoiceRoom;

/**
 * VoiceRoomMainComponent: The core interactive Voice Room experience
 */
const VoiceRoomMainComponent: React.FC<VoiceRoomProps> = ({
  room: propRoom,
  participants: propParticipants,
  isMuted: controlledIsMuted,
  onMuteToggle,
  onParticipantClick,
  onSendMessage,
  onLeaveRoom,
  onSelectRoom,
  showRoomSwitcher = true,
  className = ''
}) => {
  const { 
    activeRoom, 
    setActiveRoom, 
    currentUser, 
    roomMessages, 
    setRoomMessages, 
    showNotification 
  } = useApp();

  // All available rooms for quick switching
  const [availableRooms, setAvailableRooms] = useState<VoiceRoomType[]>([]);
  const [isSwitchMenuOpen, setIsSwitchMenuOpen] = useState(false);
  const [selectedParticipantModal, setSelectedParticipantModal] = useState<ParticipantAvatarItem | null>(null);
  const [showGiftModal, setShowGiftModal] = useState<boolean>(false);
  const [selectedGiftSpeakerId, setSelectedGiftSpeakerId] = useState<string | null>(null);

  // Tools Modal (Frosted-Glass Bottom Sheet) State
  const [isToolsOpen, setIsToolsOpen] = useState<boolean>(false);
  const [activeToolTab, setActiveToolTab] = useState<ToolTabType>('menu');
  const [activeBags, setActiveBags] = useState<LuckyBagType[]>([]);
  const [roomToolsStatus, setRoomToolsStatus] = useState<{
    isMusicPlaying?: boolean;
    isYoutubePlaying?: boolean;
    isCpAuraActive?: boolean;
    isGameActive?: boolean;
    isPkActive?: boolean;
  }>({});

  const handleOpenTool = (tab: ToolTabType = 'menu') => {
    setActiveToolTab(tab);
    setIsToolsOpen(true);
  };

  // Determine current active room (prefer prop, then context, then first available room)
  const currentRoom: VoiceRoomType | null = useMemo(() => {
    if (propRoom) return propRoom;
    if (activeRoom) return activeRoom;
    if (availableRooms.length > 0) return availableRooms[0];
    return null;
  }, [propRoom, activeRoom, availableRooms]);

  // Sync per-room tools status & active lucky bags for UI badges
  useEffect(() => {
    if (!currentRoom?.id) return;
    ApiClient.getRoomTools(currentRoom.id).then((tools) => {
      if (tools) {
        setRoomToolsStatus({
          isMusicPlaying: tools.music?.isPlaying,
          isYoutubePlaying: tools.youtube?.isPlaying,
          isCpAuraActive: tools.cp?.active,
          isGameActive: tools.game?.status === 'in_progress',
          isPkActive: currentRoom.pkState?.active
        });
      }
    }).catch(() => {});

    ApiClient.getActiveLuckyBags(currentRoom.id).then((bags) => {
      if (Array.isArray(bags)) {
        setActiveBags(bags);
      }
    }).catch(() => {});
  }, [currentRoom?.id, currentRoom?.pkState?.active, isToolsOpen]);

  // Load available rooms for room switcher
  useEffect(() => {
    ApiClient.getRooms().then((rooms) => {
      if (Array.isArray(rooms) && rooms.length > 0) {
        setAvailableRooms(rooms);
      }
    }).catch(() => {});
  }, []);

  // -------------------------------------------------------------
  // 1. MICROPHONE PERMISSIONS & BROWSER WEBAUDIO API INTEGRATION
  // -------------------------------------------------------------
  const [micPermission, setMicPermission] = useState<
    'idle' | 'prompt' | 'requesting' | 'granted' | 'denied' | 'unsupported'
  >('idle');
  const [isMuted, setIsMuted] = useState<boolean>(
    controlledIsMuted !== undefined ? controlledIsMuted : true
  );
  const [audioLevel, setAudioLevel] = useState<number>(0);
  const [showPermissionAlert, setShowPermissionAlert] = useState<boolean>(false);

  const mediaStreamRef = useRef<MediaStream | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  // Sync external controlled mute state
  useEffect(() => {
    if (controlledIsMuted !== undefined) {
      setIsMuted(controlledIsMuted);
    }
  }, [controlledIsMuted]);

  // Check initial browser permissions query if supported
  useEffect(() => {
    if (typeof navigator !== 'undefined' && navigator.permissions?.query) {
      navigator.permissions.query({ name: 'microphone' as PermissionName })
        .then((permissionStatus) => {
          if (permissionStatus.state === 'granted') {
            setMicPermission('granted');
          } else if (permissionStatus.state === 'denied') {
            setMicPermission('denied');
          } else {
            setMicPermission('prompt');
          }

          permissionStatus.onchange = () => {
            if (permissionStatus.state === 'granted') {
              setMicPermission('granted');
            } else if (permissionStatus.state === 'denied') {
              setMicPermission('denied');
              setIsMuted(true);
            }
          };
        })
        .catch(() => {
          setMicPermission('prompt');
        });
    } else {
      setMicPermission('prompt');
    }
  }, []);

  // Request browser microphone access using navigator.mediaDevices.getUserMedia
  const requestMicrophoneAccess = async (): Promise<boolean> => {
    if (!navigator?.mediaDevices?.getUserMedia) {
      setMicPermission('unsupported');
      showNotification('Microphone is not supported on this browser or environment.');
      return false;
    }

    setMicPermission('requesting');
    setShowPermissionAlert(false);

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        } 
      });

      mediaStreamRef.current = stream;
      setMicPermission('granted');
      setIsMuted(false);
      if (onMuteToggle) onMuteToggle(false);

      // Set up Web Audio Analyser for live speech wave visualizer
      try {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioCtx) {
          const audioCtx = new AudioCtx();
          audioContextRef.current = audioCtx;
          const source = audioCtx.createMediaStreamSource(stream);
          const analyser = audioCtx.createAnalyser();
          analyser.fftSize = 64;
          source.connect(analyser);
          analyserRef.current = analyser;

          const dataArray = new Uint8Array(analyser.frequencyBinCount);
          const detectAudioLevel = () => {
            if (!analyserRef.current || !mediaStreamRef.current) return;
            analyserRef.current.getByteFrequencyData(dataArray);
            const sum = dataArray.reduce((acc, v) => acc + v, 0);
            const avg = sum / dataArray.length;
            setAudioLevel(avg);
            animationFrameRef.current = requestAnimationFrame(detectAudioLevel);
          };
          detectAudioLevel();
        }
      } catch (err) {
        console.warn('AudioContext level visualization note:', err);
      }

      showNotification('🎙️ Microphone access granted! You are now live on stage.');
      return true;
    } catch (err: any) {
      console.error('Microphone permission request error:', err);
      setMicPermission('denied');
      setIsMuted(true);
      setShowPermissionAlert(true);
      showNotification('Microphone access denied. Please click the site icon in your address bar to enable microphone permissions.');
      return false;
    }
  };

  // Toggle Mute / Unmute handler
  const handleToggleMicrophone = async () => {
    if (micPermission !== 'granted' || !mediaStreamRef.current) {
      await requestMicrophoneAccess();
      return;
    }

    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    if (onMuteToggle) onMuteToggle(nextMuted);

    // Mute/unmute all local audio tracks
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getAudioTracks().forEach((track) => {
        track.enabled = !nextMuted;
      });
    }

    if (nextMuted) {
      setAudioLevel(0);
      showNotification('Microphone muted 🔇');
    } else {
      showNotification('Microphone unmuted 🎙️');
    }
  };

  // Clean up media tracks and audio context on unmount
  useEffect(() => {
    return () => {
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
      if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
        audioContextRef.current.close().catch(() => {});
      }
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      }
    };
  }, []);

  // -------------------------------------------------------------
  // 2. PARTICIPANT AVATARS COMPILATION & STAGE SEATS
  // -------------------------------------------------------------
  const fallbackSeats: MicSeat[] = [
    { index: 0, userId: '2383452', userName: 'Elena Vance (CEO)', userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200', isMuted: false, isSpeaking: true, isLocked: false, contributionCoin: 45000 },
    { index: 1, userId: 'usr-002', userName: 'Marcus Aurelius', userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200', isMuted: false, isSpeaking: false, isLocked: false, contributionCoin: 18200 },
    { index: 2, userId: 'usr-003', userName: 'Sophia Taylor', userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200', isMuted: true, isSpeaking: false, isLocked: false, contributionCoin: 12400 },
    { index: 3, userId: 'usr-004', userName: 'Kenji Sato', userAvatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=200', isMuted: false, isSpeaking: false, isLocked: false, contributionCoin: 8500 },
    { index: 4, isMuted: false, isSpeaking: false, isLocked: false, contributionCoin: 0 },
    { index: 5, isMuted: false, isSpeaking: false, isLocked: false, contributionCoin: 0 },
    { index: 6, isMuted: false, isSpeaking: false, isLocked: false, contributionCoin: 0 },
    { index: 7, isMuted: false, isSpeaking: false, isLocked: false, contributionCoin: 0 }
  ];

  const roomSeats = currentRoom?.seats || fallbackSeats;

  // Map to unified participant list (exactly 8 stage seats)
  const participantsList: ParticipantAvatarItem[] = useMemo(() => {
    if (propParticipants && propParticipants.length > 0) {
      return propParticipants;
    }

    return roomSeats.map((seat) => {
      const isCurrentUserSeat = currentUser && (seat.userId === currentUser.id || seat.userId === currentUser.uid);
      const isHost = seat.index === 0 || seat.userId === currentRoom?.hostId;
      
      return {
        id: seat.userId || `seat-${seat.index}`,
        name: seat.userName || `Seat #${seat.index + 1}`,
        avatar: seat.userAvatar || '',
        isHost,
        isMuted: isCurrentUserSeat ? isMuted : Boolean(seat.isMuted),
        // Live speech detection for local user, or simulated/server speaking state for remote
        isSpeaking: isCurrentUserSeat ? (!isMuted && audioLevel > 18) : Boolean(seat.isSpeaking),
        seatIndex: seat.index,
        role: isHost ? 'host' : seat.userId ? 'speaker' : 'listener',
        contributionCoin: seat.contributionCoin || 0,
        vipLevel: isHost ? 'svip' : seat.userId ? 'vip' : undefined,
        nigoId: seat.userId === '2383452' ? '2383452' : undefined
      };
    });
  }, [propParticipants, roomSeats, currentUser, currentRoom, isMuted, audioLevel]);

  // Handle participant / seat tap
  const handleSeatClick = async (participant: ParticipantAvatarItem) => {
    if (onParticipantClick) {
      onParticipantClick(participant);
      return;
    }

    // If seat is open, take the seat
    if (!participant.avatar && currentRoom && currentUser) {
      try {
        const updated = await ApiClient.joinSeat(currentRoom.id, participant.seatIndex);
        if (setActiveRoom) setActiveRoom(updated);
        showNotification(`You took mic seat #${participant.seatIndex + 1}! 🎙️`);
        if (isMuted && micPermission !== 'granted') {
          requestMicrophoneAccess();
        }
      } catch (err: any) {
        showNotification(err.message || 'Seat unavailable');
      }
      return;
    }

    // Otherwise show participant popover
    setSelectedParticipantModal(participant);
  };

  // Leave active mic seat
  const handleLeaveMySeat = async () => {
    if (!currentRoom || !currentUser) return;
    const mySeat = participantsList.find(p => p.id === currentUser.id || p.id === currentUser.uid);
    if (mySeat) {
      try {
        const updated = await ApiClient.leaveSeat(currentRoom.id, mySeat.seatIndex);
        if (setActiveRoom) setActiveRoom(updated);
        showNotification('You stepped down from the mic stage.');
        setIsMuted(true);
      } catch (err: any) {
        showNotification(err.message || 'Could not leave seat');
      }
    }
    setSelectedParticipantModal(null);
  };

  // -------------------------------------------------------------
  // 3. REAL-TIME CHAT DISPLAY AREA & MESSAGING
  // -------------------------------------------------------------
  const [chatText, setChatText] = useState('');
  const chatScrollRef = useRef<HTMLDivElement>(null);

  // Auto-scroll chat on incoming messages
  useEffect(() => {
    chatScrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [roomMessages]);

  const handleSendChat = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const content = chatText.trim();
    if (!content) return;

    if (onSendMessage) {
      onSendMessage(content);
    } else if (currentUser && setRoomMessages) {
      const newMsg: RoomMessage = {
        id: `msg-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        roomId: currentRoom?.id || 'room-live',
        userId: currentUser.id,
        userName: currentUser.name,
        userAvatar: currentUser.avatar,
        vipLevel: currentUser.vipLevel,
        type: 'text',
        content,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setRoomMessages(prev => [...prev, newMsg]);
    }

    setChatText('');
  };

  const handleQuickReaction = (emoji: string) => {
    if (currentUser && setRoomMessages) {
      const reactionMsg: RoomMessage = {
        id: `reaction-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        roomId: currentRoom?.id || 'room-live',
        userId: currentUser.id,
        userName: currentUser.name,
        userAvatar: currentUser.avatar,
        type: 'emoji',
        content: emoji,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setRoomMessages(prev => [...prev, reactionMsg]);
    }
    showNotification(`Sent ${emoji}`);
  };

  // Switch to another voice room
  const handleSelectRoom = (r: VoiceRoomType) => {
    setIsSwitchMenuOpen(false);
    if (onSelectRoom) {
      onSelectRoom(r);
    } else if (setActiveRoom) {
      setActiveRoom(r);
      showNotification(`Switched to: ${r.title}`);
    }
  };

  return (
    <div className={`w-full max-w-4xl mx-auto rounded-3xl overflow-hidden bg-gradient-to-b from-[#180d32] via-[#0e071e] to-[#080313] border border-purple-500/25 shadow-2xl text-white flex flex-col relative ${className}`}>
      
      {/* ========================================================= */}
      {/* 1. ROOM HEADER & SWITCHER                                 */}
      {/* ========================================================= */}
      <div className="px-4 sm:px-6 py-3.5 border-b border-white/10 bg-white/[0.04] backdrop-blur-xl flex items-center justify-between gap-3 relative z-20">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-pink-500 via-purple-600 to-indigo-500 p-0.5 shrink-0 shadow-lg shadow-purple-900/40">
            <div className="w-full h-full bg-[#120726] rounded-[14px] flex items-center justify-center">
              <Radio className="w-5 h-5 text-pink-400 animate-pulse" />
            </div>
          </div>
          
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h2 className="font-black text-white text-base sm:text-lg truncate">
                {currentRoom?.title || 'Aura Live Voice Stage'}
              </h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-pink-500/20 text-pink-300 border border-pink-500/30 shrink-0">
                LIVE
              </span>
            </div>
            
            <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
              <span className="truncate">Host: <b className="text-amber-300 font-bold">{currentRoom?.hostName || 'Aura Host'}</b></span>
              <span className="text-slate-600">•</span>
              <span className="flex items-center gap-1 font-mono text-cyan-300">
                <Users className="w-3.5 h-3.5 text-cyan-400" />
                {currentRoom?.onlineCount || participantsList.filter(p => p.avatar).length || 18} Live
              </span>
            </div>
          </div>
        </div>

        {/* Room Navigation & Actions */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Room Tools Button (Frosted-Glass Bottom Sheet) */}
          <button
            type="button"
            id="btn-voice-room-tools-header"
            onClick={() => handleOpenTool('menu')}
            className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-gradient-to-r from-purple-600/35 via-pink-600/25 to-amber-600/25 hover:from-purple-600/50 hover:to-pink-600/40 text-pink-200 border border-purple-500/40 text-xs font-black flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer shadow-md"
            title="Open Room Tools (Game, Music, YouTube, CP, PK Battle)"
          >
            <Wand2 className="w-3.5 h-3.5 text-amber-300" />
            <span>Tools</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          </button>

          {/* Quick Room Switcher Dropdown Button */}
          {showRoomSwitcher && availableRooms.length > 1 && (
            <div className="relative">
              <button
                type="button"
                onClick={() => setIsSwitchMenuOpen(!isSwitchMenuOpen)}
                className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-slate-200 border border-white/10 text-xs font-bold flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer"
                title="Switch Room"
              >
                <span className="hidden sm:inline">Rooms</span>
                <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${isSwitchMenuOpen ? 'rotate-180' : ''}`} />
              </button>

              {/* Room Switcher Menu */}
              {isSwitchMenuOpen && (
                <div className="absolute right-0 top-full mt-2 w-64 rounded-2xl bg-[#160a2b]/95 backdrop-blur-2xl border border-purple-500/30 shadow-2xl p-2 z-50 space-y-1 animate-fadeIn">
                  <p className="px-2.5 py-1 text-[10px] font-black uppercase tracking-wider text-slate-400 border-b border-white/10 mb-1">
                    Select Voice Room
                  </p>
                  <div className="max-h-56 overflow-y-auto space-y-1 no-scrollbar">
                    {availableRooms.map((r) => (
                      <button
                        key={r.id}
                        type="button"
                        onClick={() => handleSelectRoom(r)}
                        className={`w-full text-left p-2 rounded-xl flex items-center gap-2.5 transition-all text-xs cursor-pointer ${
                          r.id === currentRoom?.id 
                            ? 'bg-pink-500/20 text-pink-300 font-bold border border-pink-500/30' 
                            : 'hover:bg-white/10 text-slate-300'
                        }`}
                      >
                        <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
                        <div className="min-w-0 flex-1">
                          <p className="truncate font-semibold">{r.title}</p>
                          <p className="text-[10px] text-slate-400 truncate">{r.hostName}</p>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Leave Button */}
          {onLeaveRoom && (
            <button
              type="button"
              onClick={onLeaveRoom}
              className="px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 text-xs font-bold flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer"
              title="Leave Room"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Leave</span>
            </button>
          )}
        </div>
      </div>

      {/* PERMISSION DENIED BANNER */}
      {showPermissionAlert && micPermission === 'denied' && (
        <div className="mx-4 mt-3 p-3 rounded-2xl bg-rose-950/80 border border-rose-500/50 flex items-center justify-between text-xs text-rose-200 animate-fadeIn shadow-lg">
          <div className="flex items-center gap-2.5">
            <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
            <div>
              <p className="font-bold">Microphone Permission Blocked</p>
              <p className="text-[11px] text-rose-300/80">Please enable microphone access in your browser site permissions to speak.</p>
            </div>
          </div>
          <button
            type="button"
            onClick={requestMicrophoneAccess}
            className="px-3 py-1 bg-rose-500 text-white font-extrabold text-xs rounded-xl shadow hover:bg-rose-400 transition-all shrink-0 cursor-pointer"
          >
            Retry Access
          </button>
        </div>
      )}

      {/* REAL-TIME SPLIT-SCREEN PK BATTLE PROGRESS STRIP */}
      {currentRoom?.pkState?.active && (
        <div className="mx-4 sm:mx-6 mt-3 animate-fadeIn cursor-pointer" onClick={() => handleOpenTool('pk')}>
          <PKBattle
            variant="compact"
            roomA={{
              id: currentRoom.id,
              name: currentRoom.title,
              hostName: currentRoom.hostName,
              hostAvatar: currentRoom.hostAvatar,
              score: currentRoom.pkState.myScore
            }}
            roomB={{
              id: currentRoom.pkState.opponentRoomId || 'opp-room',
              name: currentRoom.pkState.opponentName || 'Challenger Room',
              hostName: currentRoom.pkState.opponentName || 'Challenger',
              hostAvatar: currentRoom.pkState.opponentAvatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100',
              score: currentRoom.pkState.opponentScore
            }}
            scoreA={currentRoom.pkState.myScore}
            scoreB={currentRoom.pkState.opponentScore}
            timeLeft={currentRoom.pkState.timeLeft}
            onCheer={(side, points) => {
              ApiClient.updateRoomPK(currentRoom.id, {
                action: 'score',
                points,
                side
              }).catch(() => {});
            }}
          />
        </div>
      )}

      {/* ACTIVE LUCKY BAG BANNER FOR ROOM PARTICIPANTS */}
      {activeBags.length > 0 && (
        <div className="mx-4 sm:mx-6 mt-3 animate-fadeIn">
          <LuckyBag
            variant="banner"
            bag={activeBags[0]}
            roomId={currentRoom?.id}
            cooldownSeconds={30}
            onClaimReward={(amt) => {
              showNotification(`🎉 Claimed +${amt} Coins from Lucky Bag!`);
              if (currentRoom?.id) {
                ApiClient.getActiveLuckyBags(currentRoom.id).then(bags => setActiveBags(bags)).catch(() => {});
              }
            }}
          />
        </div>
      )}

      {/* ========================================================= */}
      {/* 2. GRID OF PARTICIPANT AVATARS (THE VOICE STAGE)           */}
      {/* ========================================================= */}
      <div className="p-4 sm:p-6 bg-gradient-to-b from-transparent to-black/30">
        <div className="flex items-center justify-between mb-3 px-1">
          <h3 className="text-xs font-black uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Voice Stage Avatars ({participantsList.filter(p => p.avatar).length}/8)</span>
          </h3>
          <span className="text-[11px] text-purple-300/80 font-medium">
            Tap an empty seat to join mic stage
          </span>
        </div>

        {/* 8-Seat Participant Avatars Grid */}
        <div className="grid grid-cols-4 gap-3 sm:gap-4 lg:grid-cols-8">
          {participantsList.map((participant) => {
            const hasUser = Boolean(participant.avatar);
            const isSpeaking = participant.isSpeaking;
            const isUserHost = participant.isHost;

            return (
              <div
                key={participant.id}
                onClick={() => handleSeatClick(participant)}
                className="flex flex-col items-center group cursor-pointer"
              >
                {/* Avatar Outer Container */}
                <div className="relative">
                  {/* Real-time Pulsing Speaking Wave Ring */}
                  {isSpeaking && (
                    <div 
                      className="absolute -inset-1.5 rounded-full bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400 opacity-80 blur-sm animate-pulse" 
                    />
                  )}

                  {hasUser ? (
                    <div className={`relative w-14 h-14 sm:w-16 sm:h-16 rounded-full p-[2px] transition-transform duration-200 group-hover:scale-105 shadow-md ${
                      isSpeaking
                        ? 'bg-gradient-to-tr from-emerald-400 to-cyan-400 shadow-[0_0_20px_rgba(16,185,129,0.6)]'
                        : isUserHost
                        ? 'bg-gradient-to-tr from-amber-400 to-yellow-500 shadow-amber-500/20'
                        : 'bg-white/20 border border-white/10'
                    }`}>
                      <img
                        src={participant.avatar}
                        alt={participant.name}
                        className="w-full h-full rounded-full object-cover"
                      />

                      {/* Host Crown Badge */}
                      {isUserHost && (
                        <div className="absolute -top-2 -right-1 w-5 h-5 rounded-full bg-amber-400 text-black flex items-center justify-center text-[11px] shadow-md font-bold">
                          👑
                        </div>
                      )}

                      {/* Mute Overlay Icon Badge */}
                      {participant.isMuted && (
                        <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-rose-600 text-white flex items-center justify-center shadow-md border border-white/30">
                          <MicOff className="w-3 h-3" />
                        </div>
                      )}

                      {/* Speaking Equalizer Badge */}
                      {isSpeaking && (
                        <div className="absolute -bottom-1 -left-1 w-5 h-5 rounded-full bg-emerald-500 text-black flex items-center justify-center shadow-md border border-white/30">
                          <span className="flex items-end gap-0.5 h-2.5">
                            <span className="w-0.5 h-1.5 bg-black animate-bounce" />
                            <span className="w-0.5 h-2.5 bg-black animate-bounce [animation-delay:0.15s]" />
                            <span className="w-0.5 h-1.5 bg-black animate-bounce [animation-delay:0.3s]" />
                          </span>
                        </div>
                      )}
                    </div>
                  ) : (
                    /* Open Seat Placeholder */
                    <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full border-2 border-dashed border-white/25 hover:border-emerald-400/70 bg-white/[0.03] hover:bg-emerald-500/10 flex flex-col items-center justify-center transition-all group-hover:scale-105 shadow-inner">
                      <span className="text-xl text-slate-400 group-hover:text-emerald-300 font-light">+</span>
                      <span className="text-[9px] font-mono text-slate-400 uppercase tracking-tight">Sit</span>
                    </div>
                  )}
                </div>

                {/* Participant Label & Seat Tag */}
                <div className="mt-2 text-center w-full px-1">
                  <p className={`text-xs font-bold truncate max-w-[76px] ${
                    isUserHost ? 'text-amber-300' : hasUser ? 'text-slate-200' : 'text-slate-500'
                  }`}>
                    {participant.name}
                  </p>
                  <p className="text-[10px] text-slate-400 font-mono">
                    {hasUser ? (
                      isSpeaking ? (
                        <span className="text-emerald-400 font-bold">Speaking...</span>
                      ) : participant.isMuted ? (
                        <span className="text-slate-400">Muted</span>
                      ) : (
                        <span>Seat #{participant.seatIndex + 1}</span>
                      )
                    ) : (
                      <span>Open</span>
                    )}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ========================================================= */}
      {/* 3. MUTE/UNMUTE CONTROL BUTTON & AUDIO METER TOOLBAR       */}
      {/* ========================================================= */}
      <div className="px-4 sm:px-6 py-3.5 bg-white/[0.04] border-y border-white/10 backdrop-blur-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 flex-wrap">
          {/* MUTE / UNMUTE CONTROL BUTTON (PRIMARY ACTION) */}
          <button
            type="button"
            id="btn-voice-room-mute-toggle"
            onClick={handleToggleMicrophone}
            disabled={micPermission === 'requesting'}
            className={`px-4 sm:px-5 py-2.5 rounded-2xl font-black text-xs sm:text-sm flex items-center gap-2.5 transition-all duration-200 active:scale-95 shadow-lg cursor-pointer ${
              !isMuted && micPermission === 'granted'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-400 text-black shadow-[0_0_25px_rgba(16,185,129,0.5)] hover:brightness-110'
                : isMuted
                ? 'bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40'
                : 'bg-gradient-to-r from-amber-400 to-pink-500 text-black'
            }`}
            title={!isMuted ? 'Mute Microphone' : 'Unmute Microphone (Starts Browser Audio)'}
          >
            {micPermission === 'requesting' ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin text-amber-300" />
                <span>Connecting Mic...</span>
              </>
            ) : !isMuted && micPermission === 'granted' ? (
              <>
                <div className="relative">
                  <Mic className="w-4 h-4 text-black" />
                  <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-emerald-800 animate-ping" />
                </div>
                <span>Microphone Unmuted</span>
              </>
            ) : (
              <>
                <MicOff className="w-4 h-4" />
                <span>Unmute Microphone</span>
              </>
            )}
          </button>

          {/* Browser Permission Status Chip */}
          <div className="hidden sm:flex items-center gap-1.5 text-xs text-slate-300 bg-black/40 px-3 py-1.5 rounded-xl border border-white/10">
            <span className={`w-2 h-2 rounded-full ${
              micPermission === 'granted' ? 'bg-emerald-400 animate-pulse' : micPermission === 'denied' ? 'bg-rose-500' : 'bg-amber-400'
            }`} />
            <span className="font-mono text-[11px]">
              {micPermission === 'granted' 
                ? (isMuted ? 'Mic Muted' : 'Live Speaking')
                : micPermission === 'denied'
                ? 'Mic Blocked'
                : 'Mic Ready'}
            </span>
          </div>

          {/* Real-time Microphone Wave Level Equalizer */}
          {!isMuted && micPermission === 'granted' && (
            <div className="flex items-center gap-2 bg-black/50 px-3 py-1.5 rounded-xl border border-emerald-500/40 shadow-inner">
              <span className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider">Volume</span>
              <div className="flex items-end gap-0.5 h-4 w-14">
                {[25, 60, 95, 45, 100, 70, 30].map((h, i) => (
                  <div
                    key={i}
                    style={{ height: `${Math.max(15, (audioLevel / 255) * h * 2.8)}%` }}
                    className="flex-1 bg-gradient-to-t from-teal-400 to-emerald-300 rounded-t-sm transition-all duration-75"
                  />
                ))}
              </div>
            </div>
          )}
        </div>

        {/* ROOM TOOLS & VIRTUAL GIFTS SHORTCUTS */}
        <div className="flex items-center gap-1.5 flex-wrap">
          {/* Virtual Gifts Launcher Button */}
          <button
            type="button"
            id="btn-voice-room-gifts-main"
            onClick={() => {
              setSelectedGiftSpeakerId(null);
              setShowGiftModal(true);
            }}
            className="px-3.5 py-2 rounded-2xl bg-gradient-to-r from-amber-500/40 via-pink-600/30 to-purple-600/30 hover:from-amber-500/60 hover:to-pink-600/50 border border-amber-400/40 hover:border-pink-400 text-white font-black text-xs flex items-center gap-1.5 shadow-lg transition-all duration-200 active:scale-95 cursor-pointer shrink-0"
            title="Send Animated Virtual Gifts to Stage Speakers"
          >
            <div className="w-4 h-4 rounded-md bg-gradient-to-tr from-amber-400 to-pink-500 flex items-center justify-center text-black font-extrabold text-[10px] shadow">
              <GiftIcon className="w-2.5 h-2.5 text-black" />
            </div>
            <span>Gifts</span>
            <span className="hidden sm:inline-block px-1.5 py-0.2 rounded bg-amber-400/30 border border-amber-400/40 text-[9px] text-amber-200 font-mono">
              🎁
            </span>
          </button>

          {/* Main Frosted Tools Menu Button */}
          <button
            type="button"
            id="btn-voice-room-tools-main"
            onClick={() => handleOpenTool('menu')}
            className="px-3.5 py-2 rounded-2xl bg-gradient-to-r from-purple-600/40 via-pink-600/30 to-amber-600/30 hover:from-purple-600/60 hover:to-pink-600/50 border border-purple-500/40 hover:border-pink-400 text-white font-black text-xs flex items-center gap-1.5 shadow-lg transition-all duration-200 active:scale-95 cursor-pointer shrink-0"
            title="Open Room Tools Menu (Game, Music, YouTube, CP, PK Battle)"
          >
            <div className="w-4 h-4 rounded-md bg-gradient-to-tr from-amber-400 to-pink-500 flex items-center justify-center text-black font-extrabold text-[10px] shadow">
              <Wand2 className="w-2.5 h-2.5 text-black" />
            </div>
            <span>Tools</span>
            <span className="hidden sm:inline-block px-1.5 py-0.2 rounded bg-pink-500/30 border border-pink-400/40 text-[9px] text-pink-200 font-mono">
              5
            </span>
          </button>

          {/* 5 Quick Tool Tabs */}
          <div className="flex items-center gap-1 overflow-x-auto no-scrollbar py-0.5">
            <button
              type="button"
              onClick={() => handleOpenTool('game')}
              className="px-2 py-1.5 rounded-xl bg-white/[0.06] hover:bg-emerald-500/20 hover:border-emerald-500/40 border border-white/10 text-slate-200 hover:text-emerald-300 text-[11px] font-bold flex items-center gap-1 transition-all active:scale-95 cursor-pointer shrink-0"
              title="Game Center (Dice, Wheel, Quiz)"
            >
              <Gamepad2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Game</span>
              {roomToolsStatus.isGameActive && (
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
              )}
            </button>

            <button
              type="button"
              onClick={() => handleOpenTool('music')}
              className="px-2 py-1.5 rounded-xl bg-white/[0.06] hover:bg-cyan-500/20 hover:border-cyan-500/40 border border-white/10 text-slate-200 hover:text-cyan-300 text-[11px] font-bold flex items-center gap-1 transition-all active:scale-95 cursor-pointer shrink-0"
              title="Room Music & Sound Effects"
            >
              <Music className="w-3.5 h-3.5 text-cyan-400" />
              <span>Music</span>
              {roomToolsStatus.isMusicPlaying && (
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
              )}
            </button>

            <button
              type="button"
              onClick={() => handleOpenTool('youtube')}
              className="px-2 py-1.5 rounded-xl bg-white/[0.06] hover:bg-rose-500/20 hover:border-rose-500/40 border border-white/10 text-slate-200 hover:text-rose-300 text-[11px] font-bold flex items-center gap-1 transition-all active:scale-95 cursor-pointer shrink-0"
              title="YouTube Watch Party & Karaoke"
            >
              <Youtube className="w-3.5 h-3.5 text-rose-400" />
              <span>YouTube</span>
              {roomToolsStatus.isYoutubePlaying && (
                <span className="w-1.5 h-1.5 rounded-full bg-rose-400 animate-pulse" />
              )}
            </button>

            <button
              type="button"
              onClick={() => handleOpenTool('cp')}
              className="px-2 py-1.5 rounded-xl bg-white/[0.06] hover:bg-pink-500/20 hover:border-pink-500/40 border border-white/10 text-slate-200 hover:text-pink-300 text-[11px] font-bold flex items-center gap-1 transition-all active:scale-95 cursor-pointer shrink-0"
              title="CP Romance Space & Love Pairing"
            >
              <HeartHandshake className="w-3.5 h-3.5 text-pink-400" />
              <span>CP</span>
              {roomToolsStatus.isCpAuraActive && (
                <span className="w-1.5 h-1.5 rounded-full bg-pink-400 animate-ping" />
              )}
            </button>

            <button
              type="button"
              onClick={() => handleOpenTool('pk')}
              className="px-2 py-1.5 rounded-xl bg-white/[0.06] hover:bg-amber-500/20 hover:border-amber-500/40 border border-white/10 text-slate-200 hover:text-amber-300 text-[11px] font-bold flex items-center gap-1 transition-all active:scale-95 cursor-pointer shrink-0"
              title="PK Battle Warfare"
            >
              <Swords className="w-3.5 h-3.5 text-amber-400" />
              <span>PK Battle</span>
              {roomToolsStatus.isPkActive && (
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* ========================================================= */}
      {/* 4. REAL-TIME CHAT DISPLAY AREA                            */}
      {/* ========================================================= */}
      <div className="flex-1 flex flex-col min-h-[240px] max-h-[320px] bg-black/50 backdrop-blur-md">
        
        {/* Live Chat Message Feed */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5 no-scrollbar">
          {(!roomMessages || roomMessages.length === 0) ? (
            <div className="py-8 text-center text-slate-500 text-xs space-y-1">
              <Smile className="w-8 h-8 text-purple-400/50 mx-auto" />
              <p className="font-bold text-slate-400">Welcome to the Live Voice Room!</p>
              <p className="text-[11px]">Send a message or tap an emoji below to join the discussion.</p>
            </div>
          ) : (
            roomMessages.map((msg) => (
              <div 
                key={msg.id} 
                className="flex items-start gap-2.5 text-xs animate-fadeIn"
              >
                {/* Sender Avatar */}
                <img
                  src={msg.userAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100'}
                  alt=""
                  className="w-7 h-7 rounded-full object-cover shrink-0 border border-white/10 mt-0.5"
                />

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="font-extrabold text-slate-200 text-xs">
                      {msg.userName}
                    </span>
                    {msg.vipLevel && (
                      <span className="text-[9px] font-black px-1.5 py-0.2 rounded bg-amber-400/20 text-amber-300 uppercase">
                        {msg.vipLevel}
                      </span>
                    )}
                    <span className="text-[10px] text-slate-500 font-mono ml-auto">
                      {msg.timestamp || 'Just now'}
                    </span>
                  </div>

                  <div className="mt-0.5 p-2 rounded-2xl bg-white/[0.06] border border-white/10 text-slate-100 text-xs break-words inline-block max-w-full">
                    {msg.content}
                  </div>
                </div>
              </div>
            ))
          )}
          <div ref={chatScrollRef} />
        </div>

        {/* Quick Reaction Emoji Bar */}
        <div className="px-4 py-1.5 bg-black/40 border-t border-white/5 flex items-center gap-2 overflow-x-auto no-scrollbar">
          <span className="text-[10px] text-slate-400 uppercase font-black tracking-wider shrink-0">Quick React:</span>
          {['❤️', '🔥', '👏', '🎉', '💎', '🌟', '🎙️', '🌹'].map((emoji) => (
            <button
              key={emoji}
              type="button"
              onClick={() => handleQuickReaction(emoji)}
              className="px-2.5 py-1 rounded-xl bg-white/5 hover:bg-white/15 text-sm transition-transform active:scale-125 cursor-pointer shrink-0"
            >
              {emoji}
            </button>
          ))}

          {/* Quick Gifts Button in Chat Bar */}
          <button
            type="button"
            onClick={() => {
              setSelectedGiftSpeakerId(null);
              setShowGiftModal(true);
            }}
            className="px-2.5 py-1 rounded-xl bg-pink-500/20 hover:bg-pink-500/30 text-pink-300 border border-pink-500/30 text-[11px] font-black flex items-center gap-1 transition-all active:scale-95 cursor-pointer shrink-0 ml-auto"
            title="Send Virtual Gifts to Speakers"
          >
            <GiftIcon className="w-3 h-3 text-pink-400" />
            <span>Gifts</span>
          </button>

          {/* Quick Tools Button in Chat Bar */}
          <button
            type="button"
            onClick={() => handleOpenTool('menu')}
            className="px-2.5 py-1 rounded-xl bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/30 text-[11px] font-black flex items-center gap-1 transition-all active:scale-95 cursor-pointer shrink-0"
            title="Open Room Tools"
          >
            <Wand2 className="w-3 h-3 text-amber-300" />
            <span>Tools</span>
          </button>
        </div>

        {/* Real-Time Chat Input Bar */}
        <form 
          onSubmit={handleSendChat}
          className="p-3 bg-black/70 border-t border-white/10 flex items-center gap-2"
        >
          <input
            type="text"
            placeholder="Type a message to room participants..."
            value={chatText}
            onChange={(e) => setChatText(e.target.value)}
            className="flex-1 bg-white/[0.08] text-white text-xs px-3.5 py-2.5 rounded-xl border border-white/15 focus:outline-none focus:border-pink-400 placeholder:text-slate-500"
          />
          <button
            type="submit"
            disabled={!chatText.trim()}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-pink-500 via-purple-600 to-indigo-600 hover:from-pink-400 text-white font-extrabold text-xs shadow-md transition-all active:scale-95 disabled:opacity-40 flex items-center gap-1.5 cursor-pointer shrink-0"
          >
            <Send className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Send</span>
          </button>
        </form>
      </div>

      {/* PARTICIPANT DETAILS MODAL */}
      {selectedParticipantModal && (
        <div className="absolute inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-[#190c2f] border border-purple-500/30 rounded-3xl p-5 max-w-xs w-full text-center space-y-3 shadow-2xl">
            <div className="relative inline-block">
              <img
                src={selectedParticipantModal.avatar}
                alt={selectedParticipantModal.name}
                className="w-16 h-16 rounded-full object-cover mx-auto border-2 border-amber-400"
              />
              {selectedParticipantModal.isHost && (
                <span className="absolute -top-1 -right-1 text-sm">👑</span>
              )}
            </div>

            <div>
              <h4 className="font-extrabold text-white text-sm">{selectedParticipantModal.name}</h4>
              <p className="text-xs text-purple-300 font-mono">
                {selectedParticipantModal.isHost ? 'Room Host / Streamer' : `Mic Seat #${selectedParticipantModal.seatIndex + 1}`}
              </p>
              {selectedParticipantModal.nigoId && (
                <div className="mt-1 flex justify-center">
                  <ProfileIdBadge uid={selectedParticipantModal.nigoId} size="xs" canCopy={true} />
                </div>
              )}
            </div>

            <div className="pt-2 border-t border-white/10 flex gap-2">
              {currentUser && (selectedParticipantModal.id === currentUser.id || selectedParticipantModal.id === currentUser.uid) ? (
                <button
                  type="button"
                  onClick={handleLeaveMySeat}
                  className="flex-1 py-2 rounded-xl bg-rose-500/20 text-rose-300 border border-rose-500/40 text-xs font-bold hover:bg-rose-500/30 cursor-pointer"
                >
                  Leave Mic Seat
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    setSelectedGiftSpeakerId(selectedParticipantModal.id);
                    setShowGiftModal(true);
                    setSelectedParticipantModal(null);
                  }}
                  className="flex-1 py-2 rounded-xl bg-gradient-to-r from-amber-400 via-pink-500 to-purple-600 text-white text-xs font-bold hover:brightness-110 cursor-pointer shadow-md flex items-center justify-center gap-1"
                >
                  <span>Send Gift</span>
                  <span>🎁</span>
                </button>
              )}
              <button
                type="button"
                onClick={() => setSelectedParticipantModal(null)}
                className="px-3 py-2 rounded-xl bg-white/10 text-slate-300 text-xs font-bold hover:bg-white/20 cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* VIRTUAL GIFTS MODAL (ANIMATED ASSETS & SPEAKER TARGETING) */}
      <VirtualGifts
        isOpen={showGiftModal}
        onClose={() => setShowGiftModal(false)}
        room={currentRoom}
        selectedSpeakerId={selectedGiftSpeakerId}
        onGiftSent={(gift, count, recipientName) => {
          showNotification(`🎁 Sent ${count}x ${gift.name} to ${recipientName}!`);
          setRoomMessages(prev => [
            ...prev,
            {
              id: `gift-${Date.now()}`,
              userId: currentUser?.id || 'sys',
              userName: currentUser?.name || 'You',
              userAvatar: currentUser?.avatar || '',
              content: `🎁 Sent ${count}x ${gift.name} to ${recipientName}!`,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              isSpecial: true
            }
          ]);
        }}
      />

      {/* ========================================================= */}
      {/* 5. FROSTED-GLASS BOTTOM SHEET TOOLS MODAL (PER-ROOM STATE) */}
      {/* ========================================================= */}
      <ToolsModal
        isOpen={isToolsOpen}
        onClose={() => setIsToolsOpen(false)}
        initialTab={activeToolTab}
        room={currentRoom}
        onOpenCpScreen={() => {
          setIsToolsOpen(false);
          showNotification('Opening CP Romance Center ❤️');
        }}
        onOpenPkScreen={() => {
          setIsToolsOpen(false);
          showNotification('Opening PK Battle Arena ⚔️');
        }}
      />

    </div>
  );
};

// =========================================================================
// BACKWARDS-COMPATIBILITY: VOICE ROOMS GRID COMPONENT
// =========================================================================
const CATEGORIES = [
  { id: 'all', label: 'All Rooms', icon: Sparkles },
  { id: 'popular', label: 'Popular', icon: Flame },
  { id: 'music', label: 'Music', icon: Music },
  { id: 'game', label: 'Gaming', icon: Gamepad2 },
  { id: 'country', label: 'Global', icon: Globe },
  { id: 'family', label: 'Community', icon: Users }
];

export const VoiceRoomsGridComponent: React.FC<VoiceRoomGridProps> = ({
  rooms: propRooms,
  category: initialCategory = 'all',
  searchQuery: propSearchQuery = '',
  activeOnly = true,
  onSelectRoom,
  onRoomClick,
  title,
  subtitle,
  className = '',
  gridColsClassName = 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3',
  showCategoryFilter = false,
  showSearch = false,
  emptyMessage = 'No active voice rooms found right now.',
  isLoading: propLoading
}) => {
  const contextData = useAppOptional();

  const setActiveRoomContext = contextData?.setActiveRoom;
  const showNotification = contextData?.showNotification || ((msg: string) => console.log(msg));

  const [internalRooms, setInternalRooms] = useState<VoiceRoomType[]>([]);
  const [internalLoading, setInternalLoading] = useState<boolean>(!propRooms);
  const [selectedCategory, setSelectedCategory] = useState<string>(initialCategory);
  const [searchKeyword, setSearchKeyword] = useState<string>(propSearchQuery);

  const fetchActiveRooms = async () => {
    if (propRooms) return;
    setInternalLoading(true);
    try {
      const data = await ApiClient.getRooms(
        selectedCategory === 'all' ? undefined : selectedCategory,
        searchKeyword.trim() || undefined
      );
      const unique = Array.isArray(data)
        ? Array.from(new Map(data.map(r => [r.id, r])).values())
        : [];
      setInternalRooms(unique);
    } catch (err) {
      console.error('Failed to load active voice rooms:', err);
    } finally {
      setInternalLoading(false);
    }
  };

  useEffect(() => {
    if (!propRooms) {
      fetchActiveRooms();
    }
  }, [propRooms, selectedCategory, searchKeyword]);

  const sourceRooms = propRooms || internalRooms;
  const loading = propLoading !== undefined ? propLoading : internalLoading;

  const activeRooms = useMemo(() => {
    return sourceRooms.filter((room) => {
      if (activeOnly && room.status && room.status !== 'active') {
        return false;
      }
      if (selectedCategory !== 'all' && room.category !== selectedCategory) {
        return false;
      }
      if (searchKeyword.trim()) {
        const query = searchKeyword.toLowerCase();
        const matchesTitle = room.title?.toLowerCase().includes(query);
        const matchesHost = room.hostName?.toLowerCase().includes(query);
        const matchesTopic = room.topic?.toLowerCase().includes(query);
        if (!matchesTitle && !matchesHost && !matchesTopic) return false;
      }
      return true;
    });
  }, [sourceRooms, activeOnly, selectedCategory, searchKeyword]);

  const handleRoomClick = (room: VoiceRoomType) => {
    if (onSelectRoom) {
      onSelectRoom(room);
      return;
    }
    if (onRoomClick) {
      onRoomClick(room);
      return;
    }
    if (setActiveRoomContext) {
      setActiveRoomContext(room);
      showNotification(`Joined room: ${room.title}`);
    }
  };

  return (
    <div className={`space-y-4 ${className}`}>
      {(title || subtitle) && (
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            {title && <h2 className="text-xl font-black text-white tracking-tight flex items-center gap-2">
              <span>{title}</span>
              <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-pink-500/20 text-pink-300 border border-pink-500/30">
                {activeRooms.length}
              </span>
            </h2>}
            {subtitle && <p className="text-xs text-slate-400 mt-0.5">{subtitle}</p>}
          </div>

          <button
            type="button"
            onClick={fetchActiveRooms}
            className="self-start sm:self-auto p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-colors flex items-center gap-1.5 text-xs font-bold cursor-pointer"
            title="Refresh Rooms"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
        </div>
      )}

      {showCategoryFilter && (
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
          {CATEGORIES.map((cat) => {
            const Icon = cat.icon;
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 cursor-pointer ${
                  isSelected
                    ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-md'
                    : 'bg-white/5 hover:bg-white/10 text-slate-300 border border-white/5'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>
      )}

      {showSearch && (
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchKeyword}
            onChange={(e) => setSearchKeyword(e.target.value)}
            placeholder="Search voice rooms by title or host..."
            className="w-full bg-white/5 border border-white/10 rounded-2xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-pink-500 transition-colors"
          />
        </div>
      )}

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map((n) => (
            <div key={n} className="h-44 rounded-3xl bg-white/[0.03] animate-pulse border border-white/5" />
          ))}
        </div>
      ) : activeRooms.length === 0 ? (
        <div className="p-8 text-center rounded-3xl bg-white/[0.02] border border-white/5 space-y-2">
          <Radio className="w-10 h-10 text-slate-600 mx-auto" />
          <h4 className="font-bold text-white text-sm">{emptyMessage}</h4>
        </div>
      ) : (
        <div className={`grid ${gridColsClassName} gap-4`}>
          {activeRooms.map((room) => {
            const occupiedSeats = room.seats?.filter(s => s.userId || s.userAvatar) || [];
            const occupiedMicsCount = occupiedSeats.length;

            return (
              <div
                key={room.id}
                onClick={() => handleRoomClick(room)}
                className="group relative rounded-3xl overflow-hidden border border-white/10 bg-white/[0.03] hover:border-pink-500/50 hover:bg-white/[0.06] transition-all duration-300 cursor-pointer shadow-lg hover:shadow-pink-500/10 hover:-translate-y-1 flex flex-col justify-between"
              >
                <div className="p-4 space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                      <span className="text-[10px] font-black uppercase tracking-wider text-pink-400">
                        {room.category || 'VOICE'}
                      </span>
                      {room.countryFlag && (
                        <span className="text-xs" title={room.country}>{room.countryFlag}</span>
                      )}
                    </div>
                    {/* Participants count badge */}
                    <div className="flex items-center gap-1 text-[11px] font-bold text-cyan-300 bg-black/50 px-2.5 py-0.5 rounded-full border border-white/10">
                      <Users className="w-3 h-3 text-cyan-400" />
                      <span>{room.onlineCount || occupiedMicsCount || 1}</span>
                      <span className="text-[10px] text-slate-400">live</span>
                    </div>
                  </div>

                  <div>
                    <h3 className="font-black text-white text-base group-hover:text-pink-300 transition-colors line-clamp-1 flex items-center gap-1.5">
                      {room.isLocked && <Lock className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
                      <span>{room.title}</span>
                    </h3>
                    <p className="text-xs text-slate-400 line-clamp-1 mt-0.5">
                      {room.topic || 'Welcome to the audio room!'}
                    </p>
                  </div>

                  <div className="flex items-center justify-between gap-2 pt-2 border-t border-white/5">
                    <div className="flex items-center gap-2 min-w-0">
                      <img
                        src={room.hostAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=80'}
                        alt={room.hostName}
                        className="w-7 h-7 rounded-full object-cover border border-amber-400/40 shrink-0"
                      />
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-slate-200 truncate flex items-center gap-1">
                          <Crown className="w-3 h-3 text-amber-400 shrink-0" />
                          <span>{room.hostName}</span>
                        </p>
                        <p className="text-[10px] text-purple-300/80">
                          {occupiedMicsCount}/8 mics
                        </p>
                      </div>
                    </div>

                    {/* Join Button */}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleRoomClick(room);
                      }}
                      className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-pink-500 to-purple-600 hover:brightness-110 active:scale-95 text-white font-black text-xs shadow-md shadow-pink-500/20 flex items-center gap-1 transition-all cursor-pointer shrink-0"
                    >
                      <Headphones className="w-3 h-3" />
                      <span>Join</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
