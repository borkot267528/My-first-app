/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Mic, MicOff, Lock, Unlock, Gift as GiftIcon, Share2, 
  Settings, Music, Youtube, Smile, ShieldAlert, Swords, 
  Send, Sparkles, ChevronDown, Volume2, VolumeX, Headphones, HeadphoneOff, Crown, Trophy, 
  CheckCircle2, DollarSign, X, Radio, Disc, Power, Upload,
  Flag, AlertTriangle, RefreshCw, Check, MessageSquare, Mail, Clapperboard, Wand2, Palette
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ApiClient } from '../../lib/api';
import { MicSeat, Gift, LuckyBag } from '../../types';
import { VirtualGiftGalleryModal } from './VirtualGiftGalleryModal';
import { ProfileIdBadge } from '../common/ProfileIdBadge';
import { VoiceRoomStage } from './VoiceRoomStage';
import { PKBattleBoard } from './PKBattleBoard';
import { ToolsModal, ToolTabType } from './ToolsModal';
import { RoomThemeModal } from './RoomThemeModal';
import { getThemeById } from './roomThemes';
import { TopContributorsLeaderboard } from '../leaderboard/TopContributorsLeaderboard';

const REPORT_REASONS = [
  'Harassment or Bullying',
  'Abusive or Offensive Language',
  'Sexual or Inappropriate Content',
  'Spam or Advertising',
  'Scam or Fraud',
  'Fake / Impersonation',
  'Illegal or Prohibited Content',
  'Other'
];

export const VoiceRoomView: React.FC = () => {
  const { 
    activeRoom, setActiveRoom, roomMessages, setRoomMessages, 
    currentUser, gifts, showNotification, isSpeakingSimulator, setIsSpeakingSimulator,
    refreshUser, setActiveModal
  } = useApp();

  const [chatInput, setChatInput] = useState('');
  const [showChatBar, setShowChatBar] = useState(false);
  const [isSpeakerMuted, setIsSpeakerMuted] = useState(false);
  const [isDeafened, setIsDeafened] = useState(false);
  const [isMyMicMuted, setIsMyMicMuted] = useState(false);
  const [showMessageModal, setShowMessageModal] = useState(false);

  const [showGiftPanel, setShowGiftPanel] = useState(false);
  const [selectedSeatForGift, setSelectedSeatForGift] = useState<MicSeat | null>(null);
  const [selectedGift, setSelectedGift] = useState<Gift | null>(null);
  const [giftCount, setGiftCount] = useState<number>(1);
  const [activeGiftAnimation, setActiveGiftAnimation] = useState<{ gift: Gift; sender: string; receiver: string } | null>(null);
  
  const [showLuckyBagModal, setShowLuckyBagModal] = useState(false);
  const [activeLuckyBags, setActiveLuckyBags] = useState<LuckyBag[]>([]);
  const [showMusicModal, setShowMusicModal] = useState(false);
  const [showYoutubeModal, setShowYoutubeModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [showEmojiModal, setShowEmojiModal] = useState(false);
  const [showPkModal, setShowPkModal] = useState(false);
  const [showToolsModal, setShowToolsModal] = useState(false);
  const [toolsModalInitialTab, setToolsModalInitialTab] = useState<ToolTabType>('menu');
  const [showThemeModal, setShowThemeModal] = useState(false);
  const [showContributorsModal, setShowContributorsModal] = useState(false);

  const currentThemeConfig = getThemeById(activeRoom?.theme);

  const handleOpenTools = (tab: ToolTabType = 'menu') => {
    setToolsModalInitialTab(tab);
    setShowToolsModal(true);
  };

  // Exit / Keep Menu & Report states
  const [showExitMenu, setShowExitMenu] = useState(false);
  const [isExiting, setIsExiting] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [selectedReportReason, setSelectedReportReason] = useState<string>('');
  const [reportDetails, setReportDetails] = useState('');
  const [isSubmittingReport, setIsSubmittingReport] = useState(false);

  const chatEndRef = useRef<HTMLDivElement>(null);
  const chatInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [roomMessages]);

  useEffect(() => {
    if (activeRoom) {
      ApiClient.getActiveLuckyBags(activeRoom.id).then(bags => setActiveLuckyBags(bags)).catch(() => {});
    }
  }, [activeRoom?.id]);

  if (!activeRoom) return null;

  const handleConfirmExitRoom = async () => {
    setIsExiting(true);
    try {
      if (currentUser && activeRoom) {
        const mySeat = activeRoom.seats.find(s => s.userId === currentUser.id);
        if (mySeat && mySeat.index !== 0) {
          await ApiClient.leaveSeat(activeRoom.id, mySeat.index).catch(() => {});
        }
        await ApiClient.leaveRoom(activeRoom.id).catch(() => {});
      }
      showNotification('Left voice room');
    } catch (err: any) {
      console.error('Error leaving room:', err);
    } finally {
      setIsExiting(false);
      setShowExitMenu(false);
      setActiveRoom(null);
    }
  };

  const handleSubmitReport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedReportReason) {
      showNotification('Please select a report reason');
      return;
    }
    setIsSubmittingReport(true);
    try {
      await ApiClient.submitReport({
        targetType: 'room',
        targetId: activeRoom.id,
        targetTitle: activeRoom.title,
        targetUserName: activeRoom.hostName,
        reason: selectedReportReason,
        details: reportDetails.trim() || undefined
      });
      showNotification('✅ Report submitted successfully. Our safety team will review it.');
      setShowReportModal(false);
      setSelectedReportReason('');
      setReportDetails('');
    } catch (err: any) {
      showNotification(err.message || 'Failed to submit report. Please try again.');
    } finally {
      setIsSubmittingReport(false);
    }
  };

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || !currentUser) return;

    const newMsg = {
      id: `msg-${Date.now()}`,
      roomId: activeRoom.id,
      userId: currentUser.id,
      userName: currentUser.name,
      userAvatar: currentUser.avatar,
      vipLevel: currentUser.vipLevel,
      type: 'text' as const,
      content: chatInput.trim(),
      timestamp: new Date().toISOString()
    };

    setRoomMessages(prev => [...prev, newMsg]);
    setChatInput('');
    setShowChatBar(false);
  };

  const handleToggleSpeaker = () => {
    setIsSpeakerMuted(prev => {
      const next = !prev;
      showNotification(next ? 'Room audio muted 🔇' : 'Room audio on 🔊');
      return next;
    });
  };

  const handleToggleMic = () => {
    if (isDeafened) {
      showNotification('Cannot unmute while deafened. Please undeafen first 🎧');
      return;
    }

    const isHost = activeRoom.hostId === currentUser?.id;
    const mySeat = activeRoom.seats.find(s => s.userId === currentUser?.id);
    const isSeated = Boolean(isHost || mySeat);

    if (!isSeated) {
      showNotification('Tap any open mic seat (1-8) to speak on microphone');
      return;
    }

    setIsMyMicMuted(prev => {
      const next = !prev;
      showNotification(next ? 'Microphone muted 🔇' : 'Microphone unmuted 🎙️');
      return next;
    });
  };

  const handleSeatClick = async (seat: MicSeat) => {
    if (!currentUser) return;
    
    // If empty seat and not locked, let user join!
    if (!seat.userId && !seat.isLocked) {
      try {
        const updated = await ApiClient.joinSeat(activeRoom.id, seat.index);
        setActiveRoom(updated);
        showNotification(`You joined seat #${seat.index}!`);
      } catch (err: any) {
        showNotification(err.message || 'Failed to join seat');
      }
      return;
    }

    // If occupied by someone else, open gift sender for them!
    if (seat.userId && seat.userId !== currentUser.id) {
      setSelectedSeatForGift(seat);
      setShowGiftPanel(true);
      return;
    }

    // If occupied by me, toggle mute or leave
    if (seat.userId === currentUser.id && seat.index !== 0) {
      const wantToLeave = window.confirm(`Leave seat #${seat.index}?`);
      if (wantToLeave) {
        try {
          const updated = await ApiClient.leaveSeat(activeRoom.id, seat.index);
          setActiveRoom(updated);
          showNotification('You left the seat.');
        } catch (err: any) {
          showNotification(err.message || 'Failed to leave seat');
        }
      }
    }
  };

  const handleSendGift = async () => {
    if (!selectedGift || !currentUser || !selectedSeatForGift?.userId) {
      showNotification('Please select a gift and a recipient!');
      return;
    }

    const totalCost = selectedGift.priceCoins * giftCount;
    if (currentUser.coins < totalCost) {
      showNotification(`Insufficient coins! You need ${totalCost} coins.`);
      return;
    }

    try {
      await ApiClient.sendGift(selectedSeatForGift.userId, selectedGift.id, giftCount, activeRoom.id);
      await refreshUser();
      
      // Trigger screen animation!
      setActiveGiftAnimation({
        gift: selectedGift,
        sender: currentUser.name,
        receiver: selectedSeatForGift.userName || 'Host'
      });

      setTimeout(() => setActiveGiftAnimation(null), 3500);
      setShowGiftPanel(false);
      showNotification(`Sent ${giftCount}x ${selectedGift.name} to ${selectedSeatForGift.userName}!`);
    } catch (err: any) {
      showNotification(err.message || 'Failed to send gift');
    }
  };

  const handleClaimBag = async (bag: LuckyBag) => {
    try {
      const res = await ApiClient.claimLuckyBag(bag.id);
      await refreshUser();
      showNotification(`🎉 Congratulations! You claimed ${res.reward} coins from Lucky Bag!`);
      // refresh bags
      const updatedBags = await ApiClient.getActiveLuckyBags(activeRoom.id);
      setActiveLuckyBags(updatedBags);
    } catch (err: any) {
      showNotification(err.message || 'Failed to claim lucky bag');
    }
  };

  return (
    <div className={`fixed inset-0 z-[70] flex flex-col justify-between overflow-hidden animate-fadeIn text-white bg-gradient-to-b ${currentThemeConfig.gradientClass}`}>
      {/* IMMERSIVE ROOM THEME BACKGROUND LAYER */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        {/* Background Wallpaper (Theme preset or custom URL) */}
        {(activeRoom.backgroundUrl || currentThemeConfig.bgImage) && (
          <img 
            src={activeRoom.backgroundUrl || currentThemeConfig.bgImage} 
            alt="Room Background" 
            className="w-full h-full object-cover opacity-35 scale-105 filter blur-[2px] transition-all duration-700"
          />
        )}
        {/* Radial Ambient Lighting */}
        <div 
          className="absolute inset-0 transition-all duration-700" 
          style={{ background: currentThemeConfig.radialEffect }} 
        />
        {/* Dark Vignette Overlay for Crisp Readability */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/45 to-black/75" />
        
        {/* Atmospheric Floating Orbs / Particle Atmosphere */}
        {currentThemeConfig.hasParticles && (
          <div className="absolute inset-0 opacity-40">
            {currentThemeConfig.particleType === 'stars' && (
              <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-indigo-400/20 via-transparent to-transparent animate-pulse" />
            )}
            {currentThemeConfig.particleType === 'pulse' && (
              <div className="absolute -top-32 -left-32 w-96 h-96 rounded-full bg-pink-500/20 filter blur-3xl animate-pulse" />
            )}
            {currentThemeConfig.particleType === 'ember' && (
              <div className="absolute -bottom-32 -right-32 w-96 h-96 rounded-full bg-amber-500/20 filter blur-3xl animate-pulse" />
            )}
            {currentThemeConfig.particleType === 'aurora' && (
              <div className="absolute top-0 inset-x-0 h-96 bg-gradient-to-b from-emerald-500/20 via-teal-500/10 to-transparent filter blur-2xl animate-pulse" />
            )}
            {currentThemeConfig.particleType === 'gold_dust' && (
              <div className="absolute -top-20 inset-x-0 h-64 bg-gradient-to-b from-yellow-500/20 to-transparent filter blur-3xl" />
            )}
          </div>
        )}
      </div>

      {/* 1. TOP HEADER BAR */}
      <div className="px-4 py-3 bg-gradient-to-b from-black/80 to-transparent flex items-center justify-between z-20">
        <div className="flex items-center gap-2.5">
          <button 
            onClick={() => setActiveRoom(null)}
            className="w-9 h-9 rounded-2xl bg-white/10 hover:bg-white/20 flex items-center justify-center transition-transform active:scale-90 shadow border border-white/10"
          >
            <ChevronDown className="w-5 h-5 text-white" />
          </button>
          <div className="flex items-center gap-2">
            <img src={activeRoom.hostAvatar} alt={activeRoom.hostName} className="w-10 h-10 rounded-2xl object-cover border border-white/20 shadow" />
            <div>
              <div className="flex items-center gap-1.5 flex-wrap">
                <h3 className="font-extrabold text-sm max-w-[140px] truncate">{activeRoom.title}</h3>
                <ProfileIdBadge 
                  uid={activeRoom.hostUid || (currentUser && (activeRoom.hostId === currentUser.id || activeRoom.hostName === currentUser.name) ? currentUser.uid : activeRoom.id.replace('room-', ''))} 
                  size="xs" 
                  canCopy={true}
                  onCopy={(id) => showNotification(`Room ID ${id} copied to clipboard!`)}
                />
              </div>
              <p className="text-[10px] text-slate-300 flex items-center gap-1">
                🎙️ Host: {activeRoom.hostName} • {activeRoom.onlineCount} online
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          {/* ROOM & GLOBAL TOP CONTRIBUTORS LEADERBOARD BUTTON */}
          <button 
            type="button"
            onClick={() => setShowContributorsModal(true)}
            className="px-2.5 py-1.5 rounded-2xl bg-gradient-to-r from-amber-500/25 via-yellow-500/20 to-orange-500/25 hover:from-amber-500/35 hover:to-orange-500/35 transition-all border border-amber-400/40 flex items-center gap-1.5 text-xs font-black text-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.25)] active:scale-95 cursor-pointer"
            title="Top Contributors Leaderboard (Real-time virtual gift earnings & top patrons)"
          >
            <Trophy className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
            <span className="hidden sm:inline">Rankings</span>
          </button>

          {/* ROOM THEME CUSTOMIZATION BUTTON */}
          <button 
            type="button"
            onClick={() => setShowThemeModal(true)}
            className="px-2.5 py-1.5 rounded-2xl bg-gradient-to-r from-indigo-500/25 via-purple-500/20 to-pink-500/25 hover:from-indigo-500/35 hover:to-pink-500/35 transition-all border border-purple-400/40 flex items-center gap-1.5 text-xs font-black text-purple-300 shadow-[0_0_12px_rgba(168,85,247,0.25)] active:scale-95 cursor-pointer"
            title="Customize Room Theme: Night Mode, Party, Chill, Cyberpunk, Aurora & Wallpapers"
          >
            <Palette className="w-3.5 h-3.5 text-purple-400" />
            <span className="hidden sm:inline">Theme</span>
          </button>

          {/* ROOM TOOLS SHORTCUT (GAME, MUSIC, YOUTUBE, CP, PK, LUCKY BAG) */}
          <button 
            type="button"
            onClick={() => handleOpenTools('menu')}
            className="px-2.5 py-1.5 rounded-2xl bg-gradient-to-r from-amber-500/25 via-pink-500/20 to-purple-500/25 hover:from-amber-500/35 hover:to-purple-500/35 transition-all border border-amber-400/40 flex items-center gap-1.5 text-xs font-black text-amber-300 shadow-[0_0_12px_rgba(251,191,36,0.25)] active:scale-95 cursor-pointer"
            title="Room Tools: Game, Music, YouTube, CP/Couple, PK Battle, Lucky Bag"
          >
            <Wand2 className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
            <span className="hidden sm:inline">Tools</span>
          </button>
          <button 
            onClick={() => setShowReportModal(true)}
            className="px-2.5 py-1.5 rounded-2xl bg-white/10 hover:bg-white/20 transition-colors border border-white/10 flex items-center gap-1 text-xs font-bold text-amber-300 shadow"
            title="Report Room / User"
          >
            <Flag className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Report</span>
          </button>
          <button 
            onClick={() => setShowSettingsModal(true)}
            className="p-2 rounded-2xl bg-white/10 hover:bg-white/20 transition-colors border border-white/10"
            title="Room Settings"
          >
            <Settings className="w-4 h-4 text-slate-300" />
          </button>
          <button 
            onClick={() => {
              navigator.clipboard.writeText(window.location.href);
              showNotification('Room link copied to clipboard!');
            }}
            className="p-2 rounded-2xl bg-white/10 hover:bg-white/20 transition-colors border border-white/10"
            title="Share Room"
          >
            <Share2 className="w-4 h-4 text-slate-300" />
          </button>
          <button 
            onClick={() => setShowExitMenu(true)}
            className="p-2 rounded-2xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/30 text-rose-300 hover:text-rose-200 transition-colors shadow"
            title="Exit Room"
          >
            <Power className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 2. ANNOUNCEMENT & ACTIVE LUCKY BAG BAR */}
      <div className="px-4 space-y-2 z-10">
        {activeRoom.announcement && (
          <div className="bg-white/5 border border-white/10 rounded-2xl px-3 py-1.5 text-[11px] text-slate-200 flex items-center gap-2 shadow backdrop-blur-md">
            <span className="bg-amber-500 text-black font-black px-1 rounded text-[9px] shadow">NOTICE</span>
            <p className="truncate flex-1">{activeRoom.announcement}</p>
          </div>
        )}

        {/* Lucky Bag Pill */}
        {activeLuckyBags.length > 0 && (
          <div 
            onClick={() => setShowLuckyBagModal(true)}
            className="cursor-pointer bg-gradient-to-r from-amber-500 via-orange-500 to-pink-600 rounded-2xl p-2 px-3.5 flex items-center justify-between shadow-lg animate-bounce"
          >
            <div className="flex items-center gap-2">
              <span className="text-xl">🎁</span>
              <div>
                <h4 className="font-black text-xs text-white">LUCKY BAG DROPPED!</h4>
                <p className="text-[10px] text-amber-100 font-medium">Tap now to grab random free coins!</p>
              </div>
            </div>
            <span className="bg-white text-black font-extrabold text-xs px-2.5 py-1 rounded-xl shadow">
              Claim
            </span>
          </div>
        )}

        {/* PK Battle Bar */}
        {activeRoom.pkState?.active && (
          <div onClick={() => setShowPkModal(true)} className="cursor-pointer">
            <PKBattleBoard
              variant="compact"
              roomA={{
                id: activeRoom.id,
                name: activeRoom.title,
                hostName: activeRoom.hostName,
                hostAvatar: activeRoom.hostAvatar,
                score: activeRoom.pkState.myScore
              }}
              roomB={{
                id: activeRoom.pkState.opponentRoomId || 'opp-room',
                name: activeRoom.pkState.opponentName || 'Challenger Room',
                hostName: activeRoom.pkState.opponentName || 'Challenger',
                hostAvatar: activeRoom.pkState.opponentAvatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
                score: activeRoom.pkState.opponentScore
              }}
              scoreA={activeRoom.pkState.myScore}
              scoreB={activeRoom.pkState.opponentScore}
              timeLeft={activeRoom.pkState.timeLeft}
            />
          </div>
        )}
      </div>

      {/* 3. MIC SEATS GRID & ACTIVE SPEAKER STAGE */}
      <div className="flex-1 overflow-y-auto min-h-0">
        <VoiceRoomStage 
          room={activeRoom}
          slots={activeRoom.seats}
          isMuted={isMyMicMuted}
          isDeafened={isDeafened}
          onMuteChange={(m) => setIsMyMicMuted(m)}
          onDeafenChange={(d) => {
            setIsDeafened(d);
            if (d) setIsMyMicMuted(true);
          }}
          onSlotClick={handleSeatClick}
          showSpotlight={true}
          showControls={false}
          className="border-none rounded-none bg-transparent shadow-none"
        />
      </div>

      {/* 4. LIVE CHAT STREAM */}
      <div className="h-36 sm:h-44 overflow-y-auto px-4 space-y-2 no-scrollbar border-t border-white/10 pt-2 bg-black/40 backdrop-blur-md">
        {roomMessages.map((msg) => (
          <div key={msg.id} className="text-xs flex items-start gap-2 leading-relaxed animate-fadeIn">
            {msg.type === 'gift' ? (
              <div className="w-full bg-gradient-to-r from-amber-500/20 via-pink-500/20 to-purple-500/20 border border-amber-500/30 rounded-xl p-2 flex items-center justify-between shadow">
                <div className="flex items-center gap-2">
                  <span className="text-xl animate-bounce">{msg.giftIcon || '🎁'}</span>
                  <div>
                    <span className="font-extrabold text-amber-300">{msg.userName}</span>
                    <span className="text-white ml-1">sent <span className="font-bold text-pink-400">{msg.giftCount}x {msg.giftName}</span>!</span>
                  </div>
                </div>
                <span className="text-[10px] bg-amber-500 text-black font-black px-1.5 py-0.5 rounded shadow">GIFT</span>
              </div>
            ) : msg.type === 'lucky_bag' ? (
              <div className="w-full bg-gradient-to-r from-red-500/20 to-amber-500/20 border border-red-500/30 rounded-xl p-2 flex items-center gap-2 shadow">
                <span className="text-xl">🎁</span>
                <span className="font-bold text-amber-300">{msg.userName}: <span className="text-white font-normal">{msg.content}</span></span>
              </div>
            ) : (
              <div className="flex flex-wrap items-center gap-1.5 bg-white/5 px-2.5 py-1.5 rounded-xl border border-white/10 shadow-sm">
                {msg.vipLevel === 'svip' && <span className="bg-amber-500 text-black text-[9px] font-black px-1 rounded shadow">SVIP</span>}
                {msg.vipLevel === 'vip' && <span className="bg-purple-500 text-white text-[9px] font-black px-1 rounded shadow">VIP</span>}
                <span className="font-bold text-slate-300">{msg.userName}:</span>
                <span className="text-white">{msg.content}</span>
              </div>
            )}
          </div>
        ))}
        <div ref={chatEndRef} />
      </div>

      {/* 5. BOTTOM CONTROL TOOLS & ACTION TOOLBAR (ELEVATED UP FOR TOUCH COMFORT) */}
      <div 
        className="w-full bg-gradient-to-t from-black via-black/95 to-black/30 border-t border-white/15 px-3 pt-3.5 z-20 shadow-[0_-16px_35px_rgba(0,0,0,0.85)] backdrop-blur-2xl shrink-0"
        style={{
          paddingBottom: 'calc(env(safe-area-inset-bottom, 0px) + 26px)',
          marginBottom: 'env(safe-area-inset-bottom, 0px)'
        }}
      >
        {/* Expandable Chat Input Bar */}
        {showChatBar && (
          <div className="mb-3 animate-fadeIn">
            <form onSubmit={handleSendChat} className="flex items-center gap-1.5 bg-white/15 backdrop-blur-2xl border border-white/25 rounded-2xl p-1.5 shadow-xl">
              <input
                ref={chatInputRef}
                type="text"
                placeholder="Say something nice in room..."
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                className="flex-1 bg-transparent text-white text-xs px-2.5 py-1.5 focus:outline-none placeholder:text-slate-400"
                autoFocus
              />
              <button 
                type="button" 
                onClick={() => setShowEmojiModal(true)}
                className="p-1.5 text-slate-300 hover:text-amber-300 transition-colors"
                title="Emoji"
              >
                <Smile className="w-4 h-4" />
              </button>
              <button 
                type="submit" 
                disabled={!chatInput.trim()}
                className="px-3 py-1.5 bg-gradient-to-r from-amber-500 to-pink-500 text-black font-extrabold text-xs rounded-xl shadow disabled:opacity-40 flex items-center gap-1"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
              <button 
                type="button" 
                onClick={() => setShowChatBar(false)}
                className="p-1.5 text-slate-400 hover:text-white"
                title="Close chat"
              >
                <X className="w-4 h-4" />
              </button>
            </form>
          </div>
        )}

        {/* 7 Action Controls Toolbar: Speaker, Mic, Chat, Emoji, Message, Gift, More/Video */}
        <div className="flex items-center justify-between gap-1.5 sm:gap-2.5 max-w-lg mx-auto -translate-y-1 sm:-translate-y-1.5">
          {/* 1. 🎧 Deafen / Undeafen */}
          <button
            type="button"
            onClick={() => {
              const next = !isDeafened;
              setIsDeafened(next);
              if (next) setIsMyMicMuted(true);
              showNotification(next ? 'Deafened: Audio output & mic silenced 🎧❌' : 'Undeafened: Room audio restored 🎧');
            }}
            className={`w-10 h-10 sm:w-11 sm:h-11 rounded-2xl border flex items-center justify-center transition-all duration-200 active:scale-90 shadow-md ${
              isDeafened 
                ? 'bg-amber-500/25 border-amber-500/50 text-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.35)]' 
                : 'bg-white/10 hover:bg-white/20 border-white/15 text-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.2)]'
            }`}
            title={isDeafened ? 'Undeafen Audio Output' : 'Deafen (Mute Room Audio & Microphone)'}
          >
            {isDeafened ? <HeadphoneOff className="w-5 h-5" /> : <Headphones className="w-5 h-5" />}
          </button>

          {/* 2. 🎤 Mic (Mute / Unmute) */}
          <button
            type="button"
            disabled={isDeafened}
            onClick={handleToggleMic}
            className={`w-10 h-10 sm:w-11 sm:h-11 rounded-2xl border flex items-center justify-center transition-all duration-200 active:scale-90 shadow-md ${
              isDeafened
                ? 'bg-white/5 border-white/10 text-slate-500 opacity-40 cursor-not-allowed'
                : isMyMicMuted 
                ? 'bg-rose-500/25 border-rose-500/50 text-rose-400 shadow-[0_0_14px_rgba(244,63,94,0.35)]' 
                : 'bg-emerald-500/20 hover:bg-emerald-500/30 border-emerald-500/40 text-emerald-300 shadow-[0_0_14px_rgba(16,185,129,0.3)]'
            }`}
            title={isDeafened ? 'Microphone disabled while deafened' : isMyMicMuted ? 'Unmute Microphone' : 'Mute Microphone'}
          >
            {isMyMicMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          {/* 3. 💬 Chat */}
          <button
            type="button"
            onClick={() => {
              setShowChatBar(prev => !prev);
              setTimeout(() => chatInputRef.current?.focus(), 50);
            }}
            className={`w-10 h-10 sm:w-11 sm:h-11 rounded-2xl border flex items-center justify-center transition-all duration-200 active:scale-90 shadow-md ${
              showChatBar
                ? 'bg-sky-500/35 border-sky-400 text-sky-300 shadow-[0_0_12px_rgba(56,189,248,0.3)]'
                : 'bg-white/10 hover:bg-white/20 border-white/15 text-sky-400'
            }`}
            title="Room Chat"
          >
            <MessageSquare className="w-5 h-5" />
          </button>

          {/* 4. 😀 Emoji */}
          <button
            type="button"
            onClick={() => setShowEmojiModal(true)}
            className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/15 flex items-center justify-center text-amber-300 transition-all duration-200 active:scale-90 shadow-md"
            title="Send Emoji"
          >
            <Smile className="w-5 h-5" />
          </button>

          {/* 5. ✉️ Message */}
          <button
            type="button"
            onClick={() => setShowMessageModal(true)}
            className={`w-10 h-10 sm:w-11 sm:h-11 rounded-2xl border flex items-center justify-center transition-all duration-200 active:scale-90 shadow-md ${
              showMessageModal
                ? 'bg-purple-500/35 border-purple-400 text-purple-200 shadow-[0_0_12px_rgba(192,132,252,0.3)]'
                : 'bg-white/10 hover:bg-white/20 border-white/15 text-purple-300'
            }`}
            title="Room Notices & Rules"
          >
            <Mail className="w-5 h-5" />
          </button>

          {/* 6. 🎁 Gift Center (Elevated & Prominent) */}
          <button
            type="button"
            onClick={() => {
              setSelectedSeatForGift({ index: 0, userId: activeRoom.hostId, userName: activeRoom.hostName, userAvatar: activeRoom.hostAvatar, isMuted: false, isLocked: false, isSpeaking: false, contributionCoin: 0 });
              setShowGiftPanel(true);
            }}
            className="w-12 h-12 sm:w-13 sm:h-13 rounded-2xl bg-gradient-to-tr from-amber-400 via-pink-500 to-purple-600 border-2 border-amber-300/80 flex items-center justify-center text-white shadow-[0_0_24px_rgba(236,72,153,0.6)] transition-all duration-200 active:scale-90 hover:scale-105 animate-pulse cursor-pointer shrink-0 -translate-y-1 sm:-translate-y-2"
            title="Virtual Gift Gallery"
          >
            <GiftIcon className="w-6 h-6 stroke-[2.5]" />
          </button>

          {/* 7. 🎛️ Room Tools (Game, Music, YouTube, CP/Couple, PK Battle, Lucky Bag) */}
          <button
            type="button"
            onClick={() => handleOpenTools('menu')}
            className={`w-10 h-10 sm:w-11 sm:h-11 rounded-2xl border flex items-center justify-center transition-all duration-200 active:scale-90 shadow-md group cursor-pointer ${
              showToolsModal
                ? 'bg-gradient-to-tr from-amber-500/35 via-pink-500/30 to-purple-600/35 border-amber-400 text-amber-300 shadow-[0_0_15px_rgba(251,191,36,0.4)]'
                : 'bg-white/10 hover:bg-white/20 border-white/15 text-amber-300 hover:text-amber-200 hover:border-amber-400/50 shadow-[0_0_10px_rgba(251,191,36,0.2)]'
            }`}
            title="Room Tools: Game, Music, YouTube, CP/Couple, PK Battle, Lucky Bag"
          >
            <Wand2 className="w-5 h-5 group-hover:rotate-12 transition-transform" />
          </button>
        </div>
      </div>

      {/* 6. FULLSCREEN LUXURY GIFT ANIMATION BANNER */}
      {activeGiftAnimation && (
        <div className="absolute inset-0 z-[75] pointer-events-none flex items-center justify-center bg-black/60 backdrop-blur-sm animate-fadeIn">
          <div className="flex flex-col items-center text-center space-y-4 animate-bounce">
            <div className="w-36 h-36 rounded-full bg-gradient-to-tr from-amber-400 via-pink-500 to-purple-600 flex items-center justify-center text-7xl shadow-[0_0_60px_#ec4899] border-4 border-white">
              {activeGiftAnimation.gift.icon}
            </div>
            <div className="bg-gradient-to-r from-purple-900 via-pink-900 to-amber-900 px-6 py-3 rounded-3xl border-2 border-amber-400 shadow-2xl">
              <h2 className="text-2xl font-black text-amber-300 drop-shadow-md">
                {activeGiftAnimation.sender} sent {activeGiftAnimation.gift.name}!
              </h2>
              <p className="text-xs font-bold text-white mt-1">To: {activeGiftAnimation.receiver}</p>
            </div>
          </div>
        </div>
      )}

      {/* 7. VIRTUAL GIFT GALLERY MODAL */}
      <VirtualGiftGalleryModal
        isOpen={showGiftPanel}
        onClose={() => setShowGiftPanel(false)}
        room={activeRoom}
        selectedSeat={selectedSeatForGift}
        onGiftSent={(gift, count, recipientName) => {
          setActiveGiftAnimation({
            gift,
            sender: currentUser?.name || 'You',
            receiver: recipientName
          });
          setTimeout(() => setActiveGiftAnimation(null), 3500);
        }}
      />

      {/* 8. FROSTED-GLASS ROOM TOOLS MODAL (GAME, MUSIC, YOUTUBE, CP, PK, LUCKY BAG) */}
      <ToolsModal
        isOpen={showToolsModal}
        onClose={() => setShowToolsModal(false)}
        initialTab={toolsModalInitialTab}
        onOpenCpScreen={() => {
          setShowToolsModal(false);
          setActiveModal('cp');
        }}
        onOpenPkScreen={() => {
          setShowToolsModal(false);
          setActiveModal('pk');
        }}
        onOpenDailySpin={() => {
          setShowToolsModal(false);
          setActiveModal('spin');
        }}
        onOpenLuckyBagPage={() => {
          setShowToolsModal(false);
          setActiveModal('lucky_bag');
        }}
        onOpenThemeModal={() => {
          setShowToolsModal(false);
          setShowThemeModal(true);
        }}
        onOpenContributorsModal={() => {
          setShowToolsModal(false);
          setShowContributorsModal(true);
        }}
      />

      {/* 8.1 ROOM THEME & CUSTOMIZATION MODAL (NIGHT MODE, PARTY, CHILL, ETC.) */}
      <RoomThemeModal
        isOpen={showThemeModal}
        onClose={() => setShowThemeModal(false)}
      />

      {/* 8.2 TOP CONTRIBUTORS LEADERBOARD MODAL */}
      {showContributorsModal && (
        <div className="fixed inset-0 z-[85] bg-black/80 backdrop-blur-xl flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fadeIn">
          <div className="w-full max-w-2xl h-[90vh] sm:h-[85vh] animate-scaleUp">
            <TopContributorsLeaderboard
              onClose={() => setShowContributorsModal(false)}
              roomId={activeRoom.id}
              onSelectUserForGift={(user) => {
                setShowContributorsModal(false);
                setSelectedSeatForGift({
                  index: 0,
                  userId: user.id,
                  userName: user.name,
                  userAvatar: user.avatar,
                  isMuted: false,
                  isLocked: false,
                  isSpeaking: false,
                  contributionCoin: 0
                });
                setShowGiftPanel(true);
              }}
            />
          </div>
        </div>
      )}

      {/* 8. LUCKY BAG MODAL */}
      {showLuckyBagModal && (
        <div className="fixed inset-0 z-[80] bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#1a0b2e]/95 backdrop-blur-2xl border border-white/20 rounded-3xl p-6 w-full max-w-md space-y-4 shadow-2xl text-center">
            <div className="w-16 h-16 mx-auto rounded-full bg-gradient-to-tr from-amber-400 to-red-500 flex items-center justify-center text-3xl shadow-lg animate-bounce">
              🎁
            </div>
            <h3 className="font-extrabold text-white text-xl">Active Room Lucky Bags</h3>
            <p className="text-xs text-slate-300">Claim your chance to win free coins from the room host & sponsors!</p>
            
            <div className="space-y-2.5 max-h-60 overflow-y-auto">
              {activeLuckyBags.length === 0 ? (
                <p className="text-xs text-slate-400 py-4">No active lucky bags right now. Drop one via the tools!</p>
              ) : (
                activeLuckyBags.map((bag) => (
                  <div key={bag.id} className="p-3.5 rounded-2xl bg-black/40 border border-white/10 flex items-center justify-between shadow">
                    <div className="text-left">
                      <h5 className="font-bold text-white text-xs">By {bag.senderName}</h5>
                      <p className="text-[10px] text-amber-400 font-semibold">{bag.remainingCoins} / {bag.totalCoins} Coins remaining</p>
                      <p className="text-[9px] text-slate-400">{bag.claimedCount} / {bag.totalWinners} winners claimed</p>
                    </div>
                    <button
                      onClick={() => handleClaimBag(bag)}
                      className="px-4 py-2 bg-gradient-to-r from-amber-500 to-red-600 hover:scale-105 text-white font-extrabold text-xs rounded-xl shadow"
                    >
                      Claim Now 🪙
                    </button>
                  </div>
                ))
              )}
            </div>
            <button onClick={() => setShowLuckyBagModal(false)} className="w-full py-2 bg-white/10 hover:bg-white/20 text-slate-300 rounded-xl font-bold text-xs border border-white/10">
              Close
            </button>
          </div>
        </div>
      )}

      {/* 9. MUSIC & YOUTUBE MODAL */}
      {showMusicModal && (
        <div className="fixed inset-0 z-[80] bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#1a0b2e]/95 backdrop-blur-2xl border border-white/20 rounded-3xl p-6 w-full max-w-md space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="font-extrabold text-white text-lg flex items-center gap-2">
                <Music className="w-5 h-5 text-cyan-400" /> Room Music & YouTube Player
              </h3>
              <button onClick={() => setShowMusicModal(false)} className="text-slate-400 hover:text-white font-bold">✕</button>
            </div>
            <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-3 shadow">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-cyan-500/20 flex items-center justify-center text-cyan-400 font-black text-xl animate-pulse">
                  🎵
                </div>
                <div>
                  <h5 className="font-bold text-white text-sm">Midnight Breeze (Lofi Mix)</h5>
                  <p className="text-xs text-cyan-300/80">Aura Beats Studio • Now Playing</p>
                </div>
              </div>
              <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
                <div className="w-2/3 h-full bg-gradient-to-r from-cyan-400 to-purple-500 animate-pulse" />
              </div>
            </div>

            {/* YouTube Embed simulation */}
            <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-2 shadow">
              <h5 className="font-bold text-white text-xs flex items-center gap-1.5">
                <Youtube className="w-4 h-4 text-red-500" /> YouTube Room Karaoke / Video Sync
              </h5>
              <input type="text" placeholder="Paste YouTube Video URL here..." className="w-full bg-black/40 text-xs text-white px-3 py-2 rounded-xl border border-white/10 focus:outline-none focus:border-white/25" />
              <button onClick={() => { showNotification('YouTube video synced to room!'); setShowMusicModal(false); }} className="w-full py-2 bg-red-600 hover:bg-red-500 text-white font-bold text-xs rounded-xl shadow">
                Sync Video for Everyone
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 10. ROOM SETTINGS MODAL */}
      {showSettingsModal && (
        <div className="fixed inset-0 z-[80] bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#1a0b2e]/95 backdrop-blur-2xl border border-white/20 rounded-3xl p-6 w-full max-w-md space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="font-extrabold text-white text-lg flex items-center gap-2">
                <Settings className="w-5 h-5 text-purple-400" /> Room Settings & Controls
              </h3>
              <button onClick={() => setShowSettingsModal(false)} className="text-slate-400 hover:text-white font-bold">✕</button>
            </div>
            <div className="space-y-3">
              {/* Visual Theme Customization Row */}
              <div className="flex items-center justify-between p-3 rounded-2xl bg-black/40 border border-purple-500/20 shadow-sm">
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-white">Visual Theme & Background</span>
                    <span className={`text-[10px] font-black px-2 py-0.5 rounded-full border ${currentThemeConfig.badgeClass} flex items-center gap-1`}>
                      <span>{currentThemeConfig.icon}</span>
                      <span>{currentThemeConfig.name}</span>
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-300 mt-0.5">
                    Night Mode, Party, Chill, Cyberpunk, Aurora & Wallpapers
                  </p>
                </div>
                <button 
                  type="button"
                  onClick={() => {
                    setShowSettingsModal(false);
                    setShowThemeModal(true);
                  }} 
                  className="px-3 py-1.5 bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-400 hover:to-indigo-500 rounded-xl text-xs font-bold text-white shadow flex items-center gap-1.5 cursor-pointer shrink-0 ml-2"
                >
                  <Palette className="w-3.5 h-3.5" />
                  <span>Customize</span>
                </button>
              </div>

              <div className="flex items-center justify-between p-3 rounded-2xl bg-black/40 border border-white/10 shadow-sm">
                <span className="text-xs font-bold text-white">Speaking Simulator (Demo Bot Voices)</span>
                <input 
                  type="checkbox" 
                  checked={isSpeakingSimulator} 
                  onChange={(e) => setIsSpeakingSimulator(e.target.checked)} 
                  className="w-4 h-4 accent-purple-500" 
                />
              </div>
              <div className="flex items-center justify-between p-3 rounded-2xl bg-black/40 border border-white/10 shadow-sm">
                <span className="text-xs font-bold text-white">Lock Mic Seats for Newcomers</span>
                <button onClick={() => showNotification('Mic seat lock policy updated')} className="px-3 py-1 bg-white/10 hover:bg-white/20 border border-white/10 rounded-lg text-xs font-bold text-white">Toggle</button>
              </div>
              <div className="flex items-center justify-between p-3 rounded-2xl bg-black/40 border border-white/10 shadow-sm">
                <span className="text-xs font-bold text-white">Update Room Announcement</span>
                <button onClick={() => showNotification('Announcement editor opened')} className="px-3 py-1 bg-white/10 hover:bg-white/20 border border-white/10 rounded-lg text-xs font-bold text-white">Edit</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 11. EMOJI SELECTOR MODAL */}
      {showEmojiModal && (
        <div className="fixed inset-0 z-[80] bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#1a0b2e]/95 backdrop-blur-2xl border border-white/20 rounded-3xl p-6 w-full max-w-xs space-y-4 shadow-2xl text-center">
            <h4 className="font-bold text-white text-sm">Select Quick Room Emoji</h4>
            <div className="grid grid-cols-4 gap-3 text-2xl">
              {['🔥', '❤️', '👏', '😂', '🎉', '🌟', '🌹', '💎', '👑', '🚀', '🎸', '💯'].map((emo, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    if (currentUser) {
                      setRoomMessages(prev => [...prev, {
                        id: `emo-${Date.now()}`,
                        roomId: activeRoom.id,
                        userId: currentUser.id,
                        userName: currentUser.name,
                        userAvatar: currentUser.avatar,
                        type: 'emoji',
                        content: emo,
                        timestamp: new Date().toISOString()
                      }]);
                    }
                    setShowEmojiModal(false);
                  }}
                  className="p-2 bg-black/40 border border-white/10 rounded-2xl hover:scale-125 transition-transform shadow"
                >
                  {emo}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 12. PK BATTLE DETAILS MODAL */}
      {showPkModal && activeRoom.pkState && (
        <div className="fixed inset-0 z-[80] bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <div className="w-full max-w-2xl space-y-3">
            <div className="flex justify-end">
              <button 
                onClick={() => setShowPkModal(false)} 
                className="text-slate-300 hover:text-white font-bold p-2 bg-white/10 hover:bg-white/20 rounded-full transition-colors flex items-center justify-center w-8 h-8"
              >
                ✕
              </button>
            </div>
            <PKBattleBoard
              variant="board"
              roomA={{
                id: activeRoom.id,
                name: activeRoom.title,
                hostName: activeRoom.hostName,
                hostAvatar: activeRoom.hostAvatar,
                score: activeRoom.pkState.myScore,
                viewersCount: activeRoom.onlineCount
              }}
              roomB={{
                id: activeRoom.pkState.opponentRoomId || 'opp-room',
                name: activeRoom.pkState.opponentName || 'Challenger Room',
                hostName: activeRoom.pkState.opponentName || 'Challenger',
                hostAvatar: activeRoom.pkState.opponentAvatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
                score: activeRoom.pkState.opponentScore,
                viewersCount: 950
              }}
              scoreA={activeRoom.pkState.myScore}
              scoreB={activeRoom.pkState.opponentScore}
              timeLeft={activeRoom.pkState.timeLeft}
              onSendGift={() => {
                setShowPkModal(false);
                setShowGiftPanel(true);
              }}
            />
          </div>
        </div>
      )}

      {/* 13. EXIT / KEEP ROOM OVERLAY */}
      {showExitMenu && (
        <div 
          className="fixed inset-0 z-[85] bg-black/80 backdrop-blur-md flex flex-col items-center justify-center p-6 animate-fadeIn"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              setShowExitMenu(false);
            }
          }}
        >
          <div className="flex flex-col items-center justify-center gap-10 max-w-xs w-full animate-scaleUp">
            {/* Keep Option */}
            <div className="flex flex-col items-center gap-2.5">
              <button
                type="button"
                onClick={() => setShowExitMenu(false)}
                className="w-20 h-20 rounded-full bg-gradient-to-tr from-amber-400 via-amber-300 to-yellow-400 text-black flex items-center justify-center shadow-[0_0_35px_rgba(251,191,36,0.5)] hover:scale-110 active:scale-95 transition-all duration-200 cursor-pointer"
                title="Stay in voice room"
              >
                <Upload className="w-9 h-9 stroke-[2.5]" />
              </button>
              <span className="text-white font-black text-sm tracking-wide drop-shadow">Keep</span>
            </div>

            {/* Exit Option */}
            <div className="flex flex-col items-center gap-2.5">
              <button
                type="button"
                onClick={handleConfirmExitRoom}
                disabled={isExiting}
                className="w-20 h-20 rounded-full bg-gradient-to-tr from-amber-400 via-amber-300 to-yellow-400 text-black flex items-center justify-center shadow-[0_0_35px_rgba(251,191,36,0.5)] hover:scale-110 active:scale-95 transition-all duration-200 disabled:opacity-50 cursor-pointer"
                title="Leave room and disconnect"
              >
                {isExiting ? (
                  <RefreshCw className="w-8 h-8 animate-spin stroke-[2.5]" />
                ) : (
                  <Power className="w-9 h-9 stroke-[2.5]" />
                )}
              </button>
              <span className="text-white font-black text-sm tracking-wide drop-shadow">
                {isExiting ? 'Leaving...' : 'Exit'}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* 14. REPORT MODAL */}
      {showReportModal && (
        <div className="fixed inset-0 z-[80] bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-[#1a0b2e]/95 backdrop-blur-2xl border border-white/20 rounded-3xl p-5 w-full max-w-md space-y-4 shadow-2xl animate-scaleUp">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-400/20 flex items-center justify-center text-amber-400">
                  <Flag className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-extrabold text-white text-base">Report Voice Room</h3>
                  <p className="text-[11px] text-slate-300">Room: {activeRoom.title} (Host: {activeRoom.hostName})</p>
                </div>
              </div>
              <button 
                onClick={() => {
                  setShowReportModal(false);
                  setSelectedReportReason('');
                  setReportDetails('');
                }}
                className="w-7 h-7 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center text-slate-300 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitReport} className="space-y-4">
              {/* Reason Selector */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-200">
                  Reason for report <span className="text-rose-400">*</span>
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-52 overflow-y-auto pr-1">
                  {REPORT_REASONS.map((reason) => {
                    const isSelected = selectedReportReason === reason;
                    return (
                      <button
                        type="button"
                        key={reason}
                        onClick={() => setSelectedReportReason(reason)}
                        className={`text-left px-3 py-2 rounded-xl text-xs font-semibold flex items-center justify-between transition-all border ${
                          isSelected 
                            ? 'bg-amber-400/20 border-amber-400 text-amber-300 shadow-sm' 
                            : 'bg-white/5 hover:bg-white/10 border-white/10 text-slate-300'
                        }`}
                      >
                        <span className="truncate pr-1">{reason}</span>
                        {isSelected && <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Additional Details */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-200">
                  Additional details <span className="text-slate-400 text-[10px] font-normal">(Optional)</span>
                </label>
                <textarea
                  value={reportDetails}
                  onChange={(e) => setReportDetails(e.target.value)}
                  placeholder="Provide any specific context, timestamps, or details for moderators..."
                  rows={3}
                  className="w-full bg-black/40 text-xs text-white p-3 rounded-xl border border-white/15 focus:outline-none focus:border-amber-400 resize-none"
                  maxLength={500}
                />
                <div className="text-right text-[10px] text-slate-400">
                  {reportDetails.length}/500
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 pt-1 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => {
                    setShowReportModal(false);
                    setSelectedReportReason('');
                    setReportDetails('');
                  }}
                  className="flex-1 py-2.5 bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white font-bold text-xs rounded-xl transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!selectedReportReason || isSubmittingReport}
                  className="flex-1 py-2.5 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-black font-extrabold text-xs rounded-xl shadow-lg transition-all disabled:opacity-50 flex items-center justify-center gap-1.5"
                >
                  {isSubmittingReport ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Submitting...</span>
                    </>
                  ) : (
                    <>
                      <Flag className="w-3.5 h-3.5" />
                      <span>Submit Report</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 15. MESSAGES & ROOM NOTICES MODAL */}
      {showMessageModal && (
        <div className="fixed inset-0 z-[80] bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#1a0b2e]/95 backdrop-blur-2xl border border-white/20 rounded-3xl p-5 w-full max-w-sm space-y-4 shadow-2xl animate-scaleUp">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-purple-500/20 flex items-center justify-center text-purple-400">
                  <Mail className="w-4 h-4" />
                </div>
                <h3 className="font-extrabold text-white text-base">Room Messages & Notices</h3>
              </div>
              <button 
                onClick={() => setShowMessageModal(false)}
                className="w-7 h-7 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center text-slate-300 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3">
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 space-y-1">
                <div className="text-[10px] font-bold text-amber-300 uppercase tracking-wider">Host Announcement</div>
                <p className="text-xs text-slate-200">{activeRoom.announcement || 'Welcome to our voice room! Follow room rules and have fun!'}</p>
              </div>

              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 space-y-1">
                <div className="text-[10px] font-bold text-sky-300 uppercase tracking-wider">Room Rules & Safety</div>
                <p className="text-xs text-slate-300">Harassment, hate speech, and spam are strictly prohibited. Respect host and seat guests.</p>
              </div>

              <button
                onClick={() => {
                  setShowMessageModal(false);
                  setShowChatBar(true);
                  setTimeout(() => chatInputRef.current?.focus(), 100);
                }}
                className="w-full py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs rounded-xl shadow transition-colors flex items-center justify-center gap-1.5"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Open Chat Box</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
