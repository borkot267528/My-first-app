/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Gamepad2, Music, Youtube, Heart, Swords, Gift, Sparkles, 
  X, ChevronLeft, Play, Pause, SkipForward, SkipBack, Volume2, VolumeX, Flame, 
  Award, Trophy, Users, Plus, Check, RefreshCw, Send, 
  Radio, Disc, ExternalLink, SlidersHorizontal, Wand2,
  ChevronRight, Smile, HeartHandshake, Film, CheckCircle2,
  AlertCircle, ArrowRight, Clock, HelpCircle, Hash, Trash2, ListMusic, UserPlus
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ApiClient } from '../../lib/api';
import { VoiceRoom, MicSeat, LuckyBag, Connection, RoomToolsState } from '../../types';
import { PKBattle } from '../pk/PKBattle';
import { LuckyBag as LuckyBagComponent } from '../luckybag/LuckyBag';

export type ToolTabType = 'menu' | 'game' | 'music' | 'youtube' | 'cp' | 'pk' | 'lucky_bag';

export interface ToolsModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: ToolTabType;
  room?: VoiceRoom | null;
  onOpenCpScreen?: () => void;
  onOpenPkScreen?: () => void;
  onOpenDailySpin?: () => void;
  onOpenLuckyBagPage?: () => void;
  onOpenThemeModal?: () => void;
  onOpenContributorsModal?: () => void;
}

// Licensed / royalty-free audio sources
const BGM_PLAYLIST = [
  { id: 'track-1', title: 'Midnight Breeze', artist: 'Aura Lofi Beats', duration: '3:24', mood: 'Relaxed', url: 'https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3?filename=lofi-study-112191.mp3' },
  { id: 'track-2', title: 'Cyber Pulse', artist: 'Synthwave Night', duration: '2:58', mood: 'Energetic', url: 'https://cdn.pixabay.com/download/audio/2022/01/18/audio_d0a13f69d2.mp3?filename=electronic-future-beats-117997.mp3' },
  { id: 'track-3', title: 'Acoustic Sunset', artist: 'Warm Folk Guitars', duration: '3:45', mood: 'Cozy', url: 'https://cdn.pixabay.com/download/audio/2021/09/06/audio_732ef2f05a.mp3?filename=acoustic-guitars-ambient-11881.mp3' },
  { id: 'track-4', title: 'Cafe Parisienne', artist: 'Smooth Jazz Quintet', duration: '4:10', mood: 'Romantic', url: 'https://cdn.pixabay.com/download/audio/2022/10/25/audio_27f12e8b24.mp3?filename=jazz-cafe-125021.mp3' },
  { id: 'track-5', title: 'Rainy Night Piano', artist: 'Aura Studio Beats', duration: '3:15', mood: 'Peaceful', url: 'https://cdn.pixabay.com/download/audio/2022/11/06/audio_0575d27aa2.mp3?filename=piano-moment-9871.mp3' },
];

const SOUND_EFFECTS = [
  { id: 'fx-applause', name: 'Applause', icon: '👏', color: 'from-amber-500 to-yellow-500' },
  { id: 'fx-cheer', name: 'Cheer', icon: '🎉', color: 'from-pink-500 to-purple-500' },
  { id: 'fx-laugh', name: 'Laughter', icon: '😂', color: 'from-yellow-400 to-orange-500' },
  { id: 'fx-airhorn', name: 'Air Horn', icon: '📢', color: 'from-rose-500 to-red-600' },
  { id: 'fx-drumroll', name: 'Drum Roll', icon: '🥁', color: 'from-indigo-500 to-blue-600' },
  { id: 'fx-victory', name: 'Victory', icon: '🏆', color: 'from-emerald-400 to-teal-500' },
];

const YOUTUBE_PRESETS = [
  { id: 'yt-1', videoId: 'jfKfPfyJRdk', title: 'Lo-Fi Chill Beats 24/7 (Live Study & Chill)', channel: 'Lofi Girl', duration: 'Live', thumbnail: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=400&q=80' },
  { id: 'yt-2', videoId: '5qap5aO4i9A', title: 'Top English Karaoke Hits 2026 (With Lyrics)', channel: 'Karaoke Central', duration: '4:12', thumbnail: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?auto=format&fit=crop&w=400&q=80' },
  { id: 'yt-3', videoId: 'DWcJFNfaw9c', title: 'Acoustic Pop Covers & Chill Guitar', channel: 'Acoustic Sessions', duration: '3:50', thumbnail: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=400&q=80' },
  { id: 'yt-4', videoId: 'kJQP7kiw5Fk', title: 'EDM Party Festival Mix (High Energy)', channel: 'BeatDrop Records', duration: '5:30', thumbnail: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=400&q=80' },
];

const GAME_CATALOG = [
  {
    id: 'dice',
    name: 'Dice Duel',
    category: 'Casual Luck',
    icon: '🎲',
    badge: 'HOT',
    description: 'Roll dice in real time. Total 9+ wins 2x coins with room celebration!',
    minBet: 50,
    maxPlayers: 8
  },
  {
    id: 'spin',
    name: 'Lucky Wheel',
    category: 'Prize Wheel',
    icon: '🎡',
    badge: 'POPULAR',
    description: 'Spin the mega lucky wheel for diamonds, super frames & VIP cash.',
    minBet: 50,
    maxPlayers: 1
  },
  {
    id: 'guess_number',
    name: 'Guess The Secret Number',
    category: 'Interactive Voice',
    icon: '🔢',
    badge: 'ROOM FUN',
    description: 'System picks 1-100. Listeners guess in chat/voice to claim the jackpot pot!',
    minBet: 0,
    maxPlayers: 20
  },
  {
    id: 'trivia',
    name: 'Voice Trivia Quiz',
    category: 'Quiz & Brain',
    icon: '🧠',
    badge: 'PARTY',
    description: 'Multiplayer quiz with fun voice questions and score ranking leaderboard.',
    minBet: 0,
    maxPlayers: 12
  }
];

export const ToolsModal: React.FC<ToolsModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'menu',
  room: propRoom,
  onOpenCpScreen,
  onOpenPkScreen,
  onOpenDailySpin,
  onOpenLuckyBagPage,
  onOpenThemeModal,
  onOpenContributorsModal,
}) => {
  const { 
    activeRoom, setActiveRoom, currentUser, showNotification, 
    setRoomMessages, setActiveModal, refreshUser 
  } = useApp();

  const currentRoom = propRoom || activeRoom;
  const currentRoomId = currentRoom?.id;

  const [currentTab, setCurrentTab] = useState<ToolTabType>(initialTab);

  // Sync initial tab when opening
  useEffect(() => {
    if (isOpen) {
      setCurrentTab(initialTab);
    }
  }, [isOpen, initialTab]);

  // Host / Manager permission check
  const isHostOrManager = Boolean(
    currentUser && currentRoom && (
      currentUser.id === currentRoom.hostId ||
      currentUser.name === currentRoom.hostName ||
      ['ceo', 'super_admin', 'admin', 'manager', 'gm', 'official_staff'].includes(currentUser.role)
    )
  );

  // --- 1. GAME STATES ---
  const [selectedGame, setSelectedGame] = useState(GAME_CATALOG[0]);
  const [gameStatus, setGameStatus] = useState<'idle' | 'waiting' | 'in_progress' | 'ended'>('idle');
  const [diceRolling, setDiceRolling] = useState(false);
  const [diceResult, setDiceResult] = useState<{ d1: number; d2: number; total: number } | null>(null);
  const [diceBet, setDiceBet] = useState<number>(50);
  
  // Guess Number Game state
  const [secretTargetNumber, setSecretTargetNumber] = useState<number>(Math.floor(Math.random() * 100) + 1);
  const [guessInput, setGuessInput] = useState<string>('');
  const [guessFeedback, setGuessFeedback] = useState<string | null>(null);

  // --- 2. MUSIC STATES ---
  const [isPlayingMusic, setIsPlayingMusic] = useState<boolean>(true);
  const [currentTrackIndex, setCurrentTrackIndex] = useState<number>(0);
  const [selectedTrack, setSelectedTrack] = useState(BGM_PLAYLIST[0]);
  const [musicVolume, setMusicVolume] = useState<number>(75);
  const [musicQueue, setMusicQueue] = useState(BGM_PLAYLIST);
  const [showAddMusicDialog, setShowAddMusicDialog] = useState(false);
  const [customTrackTitle, setCustomTrackTitle] = useState('');
  const [customTrackArtist, setCustomTrackArtist] = useState('');
  const [customTrackUrl, setCustomTrackUrl] = useState('');

  // --- 3. YOUTUBE STATES ---
  const [youtubeUrl, setYoutubeUrl] = useState('');
  const [activeYoutubeVideo, setActiveYoutubeVideo] = useState(YOUTUBE_PRESETS[0]);
  const [isYoutubePlaying, setIsYoutubePlaying] = useState(false);
  const [youtubeQueue, setYoutubeQueue] = useState(YOUTUBE_PRESETS);
  const [showIframePlayer, setShowIframePlayer] = useState(true);

  // --- 4. CP STATES ---
  const [myConnection, setMyConnection] = useState<Connection | null>(null);
  const [isLoadingCp, setIsLoadingCp] = useState(false);
  const [selectedPartnerSeat, setSelectedPartnerSeat] = useState<MicSeat | null>(null);
  const [proposalMsg, setProposalMsg] = useState('Would you like to be my CP partner in Aura Voice? ❤️');
  const [cpSubmitting, setCpSubmitting] = useState(false);
  const [activeCpAura, setActiveCpAura] = useState(false);

  // --- 5. PK STATES ---
  const [availableRooms, setAvailableRooms] = useState<VoiceRoom[]>([]);
  const [selectedOpponentRoomId, setSelectedOpponentRoomId] = useState<string>('');
  const [pkDuration, setPkDuration] = useState<number>(300); // 5 mins
  const [pkPenalty, setPkPenalty] = useState<string>('Sing a song chosen by winner 🎤');
  const [isStartingPk, setIsStartingPk] = useState<boolean>(false);
  const [pkTimeLeft, setPkTimeLeft] = useState<number>(300);
  const [pkMyScore, setPkMyScore] = useState<number>(currentRoom?.pkState?.myScore || 0);
  const [pkOpponentScore, setPkOpponentScore] = useState<number>(currentRoom?.pkState?.opponentScore || 0);
  const [pkWinner, setPkWinner] = useState<'red' | 'blue' | 'draw' | null>(null);
  const pkTimerRef = useRef<any>(null);

  // --- 6. LUCKY BAG STATES ---
  const [luckyBagCoins, setLuckyBagCoins] = useState<number>(500);
  const [luckyBagWinners, setLuckyBagWinners] = useState<number>(5);
  const [isDroppingBag, setIsDroppingBag] = useState<boolean>(false);
  const [activeBags, setActiveBags] = useState<LuckyBag[]>([]);

  // Per-room state cache ref to seamlessly preserve state between rooms
  const perRoomCache = useRef<Map<string, {
    gameStatus: 'idle' | 'waiting' | 'in_progress' | 'ended';
    selectedGameId: string;
    isPlayingMusic: boolean;
    currentTrackIndex: number;
    musicVolume: number;
    isYoutubePlaying: boolean;
    activeYoutubeVideoId: string;
    activeCpAura: boolean;
  }>>(new Map());

  // Load initial CP and room tools state when room or modal changes
  useEffect(() => {
    if (isOpen && currentRoomId) {
      // Restore cached state for this specific room if already visited
      const cached = perRoomCache.current.get(currentRoomId);
      if (cached) {
        setGameStatus(cached.gameStatus);
        const g = GAME_CATALOG.find(x => x.id === cached.selectedGameId);
        if (g) setSelectedGame(g);
        setIsPlayingMusic(cached.isPlayingMusic);
        setCurrentTrackIndex(cached.currentTrackIndex);
        if (BGM_PLAYLIST[cached.currentTrackIndex]) {
          setSelectedTrack(BGM_PLAYLIST[cached.currentTrackIndex]);
        }
        setMusicVolume(cached.musicVolume);
        setIsYoutubePlaying(cached.isYoutubePlaying);
        const y = YOUTUBE_PRESETS.find(x => x.id === cached.activeYoutubeVideoId);
        if (y) setActiveYoutubeVideo(y);
        setActiveCpAura(cached.activeCpAura);
      }

      // 1. Fetch CP Connection
      setIsLoadingCp(true);
      ApiClient.getCP()
        .then(conn => setMyConnection(conn))
        .catch(() => {})
        .finally(() => setIsLoadingCp(false));

      // 2. Fetch Lucky Bags for this room
      ApiClient.getActiveLuckyBags(currentRoomId)
        .then(bags => setActiveBags(bags))
        .catch(() => {});

      // 3. Fetch Available Rooms for PK
      ApiClient.getRooms()
        .then(rooms => {
          const others = rooms.filter(r => r.id !== currentRoomId);
          setAvailableRooms(others);
          if (others.length > 0 && !selectedOpponentRoomId) {
            setSelectedOpponentRoomId(others[0].id);
          }
        })
        .catch(() => {});

      // 4. Fetch persistent room tools state from backend for this specific room
      ApiClient.getRoomTools(currentRoomId)
        .then(tools => {
          if (tools?.music) {
            setIsPlayingMusic(tools.music.isPlaying);
            if (tools.music.volume !== undefined) setMusicVolume(tools.music.volume);
          }
          if (tools?.youtube) {
            setIsYoutubePlaying(tools.youtube.isPlaying);
          }
          if (tools?.cp?.active) {
            setActiveCpAura(true);
          }
          if (tools?.game?.status) {
            setGameStatus(tools.game.status as any);
          }
        })
        .catch(() => {});
    }
  }, [isOpen, currentRoomId]);

  // Save current room state into per-room cache whenever state updates
  useEffect(() => {
    if (!currentRoomId) return;
    perRoomCache.current.set(currentRoomId, {
      gameStatus,
      selectedGameId: selectedGame.id,
      isPlayingMusic,
      currentTrackIndex,
      musicVolume,
      isYoutubePlaying,
      activeYoutubeVideoId: activeYoutubeVideo.id,
      activeCpAura
    });
  }, [currentRoomId, gameStatus, selectedGame.id, isPlayingMusic, currentTrackIndex, musicVolume, isYoutubePlaying, activeYoutubeVideo.id, activeCpAura]);

  // Live PK Ticker countdown
  useEffect(() => {
    if (currentRoom?.pkState?.active) {
      pkTimerRef.current = setInterval(() => {
        setPkTimeLeft(prev => {
          if (prev <= 1) {
            clearInterval(pkTimerRef.current);
            // Announce winner
            const winner = pkMyScore > pkOpponentScore ? 'red' : pkMyScore < pkOpponentScore ? 'blue' : 'draw';
            setPkWinner(winner);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (pkTimerRef.current) clearInterval(pkTimerRef.current);
    }
    return () => {
      if (pkTimerRef.current) clearInterval(pkTimerRef.current);
    };
  }, [currentRoom?.pkState?.active, pkMyScore, pkOpponentScore]);

  if (!isOpen) return null;

  // --- ACTION HANDLERS ---

  // 1. GAME: Start Game
  const handleStartGame = async () => {
    if (!currentRoom) return;
    try {
      await ApiClient.updateRoomGame(currentRoom.id, {
        action: 'start',
        gameId: selectedGame.id,
        gameName: selectedGame.name
      });
      setGameStatus('in_progress');
      showNotification(`🎮 ${selectedGame.name} started in voice room!`);
    } catch (err: any) {
      showNotification(err.message || 'Failed to start game');
    }
  };

  // 1. GAME: Invite Room Members
  const handleInviteMembers = async () => {
    if (!currentRoom) return;
    try {
      await ApiClient.updateRoomGame(currentRoom.id, {
        action: 'invite',
        gameName: selectedGame.name
      });
      showNotification(`📢 Invitation sent to all ${currentRoom.onlineCount || 1} room listeners!`);
    } catch (err: any) {
      showNotification('Invitation sent to room chat!');
    }
  };

  // 1. GAME: Exit Game
  const handleExitGame = async () => {
    if (!currentRoom) return;
    try {
      await ApiClient.updateRoomGame(currentRoom.id, {
        action: 'end'
      });
      setGameStatus('idle');
      setDiceResult(null);
      setGuessFeedback(null);
      showNotification('Exited game. Room game state cleared.');
    } catch {
      setGameStatus('idle');
    }
  };

  // 1. GAME: Roll Dice
  const handleRollDice = async () => {
    if (diceRolling) return;
    if (currentUser && currentUser.coins < diceBet) {
      showNotification(`Insufficient coins! You need at least ${diceBet} coins to roll.`);
      return;
    }

    setDiceRolling(true);
    setDiceResult(null);

    // Deduct bet if applicable
    if (currentUser && diceBet > 0) {
      try {
        await ApiClient.rechargeCoins(currentUser.id, -diceBet);
        await refreshUser();
      } catch (e) {}
    }

    // Roll animation delay
    setTimeout(async () => {
      const d1 = Math.floor(Math.random() * 6) + 1;
      const d2 = Math.floor(Math.random() * 6) + 1;
      const total = d1 + d2;
      const result = { d1, d2, total };
      setDiceResult(result);
      setDiceRolling(false);
      setGameStatus('in_progress');

      // Check win condition (e.g., total >= 9 wins double!)
      const isWin = total >= 9;
      if (isWin && currentUser && diceBet > 0) {
        const prize = diceBet * 2;
        try {
          await ApiClient.rechargeCoins(currentUser.id, prize);
          await refreshUser();
        } catch (e) {}
        showNotification(`🎉 Lucky Roll! You rolled a ${total} and won ${prize} coins!`);
      } else {
        showNotification(`🎲 You rolled a ${total}!`);
      }

      // Broadcast into Room Chat
      if (currentUser && currentRoom) {
        setRoomMessages(prev => [...prev, {
          id: `dice-${Date.now()}`,
          roomId: currentRoom.id,
          userId: currentUser.id,
          userName: currentUser.name,
          userAvatar: currentUser.avatar,
          type: 'text',
          content: `🎲 rolled [${d1} + ${d2} = ${total}] in Dice Duel! ${isWin ? '🔥 BIG WIN (2X)!' : '✨ Good roll!'}`,
          timestamp: new Date().toISOString()
        }]);
      }
    }, 1200);
  };

  // 1. GAME: Submit Guess Number
  const handleGuessSubmit = () => {
    const num = parseInt(guessInput, 10);
    if (isNaN(num) || num < 1 || num > 100) {
      showNotification('Enter a number between 1 and 100');
      return;
    }
    if (num === secretTargetNumber) {
      setGuessFeedback(`🎉 BINGO! The secret number was ${num}! You won 200 coins!`);
      if (currentUser) {
        ApiClient.rechargeCoins(currentUser.id, 200).then(() => refreshUser()).catch(() => {});
      }
      setSecretTargetNumber(Math.floor(Math.random() * 100) + 1);
    } else if (num < secretTargetNumber) {
      setGuessFeedback(`📈 Too low! The secret number is HIGHER than ${num}.`);
    } else {
      setGuessFeedback(`📉 Too high! The secret number is LOWER than ${num}.`);
    }
    setGuessInput('');
  };

  // 2. MUSIC: Next / Previous
  const handleSkipTrack = (direction: 'next' | 'prev') => {
    const newIdx = direction === 'next'
      ? (currentTrackIndex + 1) % musicQueue.length
      : (currentTrackIndex - 1 + musicQueue.length) % musicQueue.length;
    setCurrentTrackIndex(newIdx);
    const track = musicQueue[newIdx];
    setSelectedTrack(track);
    setIsPlayingMusic(true);
    showNotification(`🎵 Switched to: ${track.title}`);

    if (currentRoom) {
      ApiClient.updateRoomMusic(currentRoom.id, {
        action: 'play',
        title: track.title,
        artist: track.artist,
        url: track.url
      }).catch(() => {});
    }
  };

  // 2. MUSIC: Play / Pause toggle
  const handleTogglePlayMusic = async () => {
    const nextState = !isPlayingMusic;
    setIsPlayingMusic(nextState);
    showNotification(nextState ? 'Resumed room BGM 🎵' : 'Paused room BGM ⏸️');

    if (currentRoom) {
      try {
        await ApiClient.updateRoomMusic(currentRoom.id, {
          action: nextState ? 'play' : 'pause',
          title: selectedTrack.title,
          artist: selectedTrack.artist,
          url: selectedTrack.url
        });
      } catch (e) {}
    }
  };

  // 2. MUSIC: Add Track to Queue
  const handleAddTrack = () => {
    if (!customTrackTitle.trim()) {
      showNotification('Please enter a song title');
      return;
    }
    const newTrack = {
      id: `custom-trk-${Date.now()}`,
      title: customTrackTitle.trim(),
      artist: customTrackArtist.trim() || 'Aura Listener',
      duration: '3:30',
      mood: 'Custom Pick',
      url: customTrackUrl.trim() || BGM_PLAYLIST[0].url
    };
    setMusicQueue(prev => [...prev, newTrack]);
    setShowAddMusicDialog(false);
    setCustomTrackTitle('');
    setCustomTrackArtist('');
    setCustomTrackUrl('');
    showNotification(`Added "${newTrack.title}" to music queue! 🎶`);
  };

  // 2. MUSIC: Remove Track from Queue
  const handleRemoveTrack = (trackId: string) => {
    if (musicQueue.length <= 1) {
      showNotification('Queue must keep at least 1 track');
      return;
    }
    setMusicQueue(prev => prev.filter(t => t.id !== trackId));
    showNotification('Track removed from queue');
  };

  // 2. MUSIC: Sound Effect
  const handlePlaySoundEffect = (fx: typeof SOUND_EFFECTS[0]) => {
    showNotification(`🔊 Triggered ${fx.icon} ${fx.name} sound effect in room!`);
    if (currentUser && currentRoom) {
      setRoomMessages(prev => [...prev, {
        id: `fx-${Date.now()}`,
        roomId: currentRoom.id,
        userId: currentUser.id,
        userName: currentUser.name,
        userAvatar: currentUser.avatar,
        type: 'emoji',
        content: `${fx.icon} (${fx.name} SFX)`,
        timestamp: new Date().toISOString()
      }]);
    }
  };

  // 3. YOUTUBE: Sync Video
  const handleSyncYoutube = async (video: typeof YOUTUBE_PRESETS[0]) => {
    setActiveYoutubeVideo(video);
    setIsYoutubePlaying(true);
    setShowIframePlayer(true);
    showNotification(`📺 Synced YouTube: "${video.title}" with room listeners!`);

    if (currentRoom) {
      try {
        await ApiClient.updateRoomYouTube(currentRoom.id, {
          action: 'play',
          videoId: video.videoId,
          videoTitle: video.title,
          videoUrl: `https://www.youtube.com/watch?v=${video.videoId}`
        });
      } catch (e) {}
    }
  };

  // 3. YOUTUBE: Add Custom Video URL
  const handleAddCustomYoutube = () => {
    if (!youtubeUrl.trim()) {
      showNotification('Please enter a YouTube video URL or ID');
      return;
    }
    // Extract video ID if full URL
    const match = youtubeUrl.match(/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))([\w-]{11})/);
    const videoId = match ? match[1] : youtubeUrl.trim();

    const newVideo = {
      id: `yt-custom-${Date.now()}`,
      videoId,
      title: `Shared Video (${videoId.slice(0, 6)}...)`,
      channel: currentUser?.name || 'Room DJ',
      duration: 'Online Sync',
      thumbnail: `https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?auto=format&fit=crop&w=400&q=80`
    };

    setYoutubeQueue(prev => [...prev, newVideo]);
    handleSyncYoutube(newVideo);
    setYoutubeUrl('');
  };

  // 3. YOUTUBE: Close Player
  const handleCloseYoutube = async () => {
    setIsYoutubePlaying(false);
    setShowIframePlayer(false);
    if (currentRoom) {
      try {
        await ApiClient.updateRoomYouTube(currentRoom.id, {
          action: 'close'
        });
      } catch (e) {}
    }
    showNotification('Closed YouTube stream.');
  };

  // 4. CP: Start / Stop Couple Aura Interaction
  const handleToggleCpAura = async () => {
    if (!currentRoom) return;
    const nextState = !activeCpAura;
    setActiveCpAura(nextState);

    const partnerName = myConnection?.user1Id === currentUser?.id ? (myConnection?.user2?.name || 'Soulmate') : (myConnection?.user1?.name || 'Soulmate');
    const partnerAvatar = myConnection?.user1Id === currentUser?.id ? (myConnection?.user2?.avatar || '') : (myConnection?.user1?.avatar || '');

    try {
      await ApiClient.updateRoomCP(currentRoom.id, {
        action: nextState ? 'start' : 'stop',
        interactionType: 'love',
        partner1: { id: currentUser?.id, name: currentUser?.name, avatar: currentUser?.avatar },
        partner2: { id: 'soulmate', name: partnerName, avatar: partnerAvatar },
        coupleId: myConnection ? `CP-${myConnection.id.slice(-6).toUpperCase()}` : 'CP-AURA-1001',
        level: myConnection?.level || 4,
        connectionDays: 48
      });
      showNotification(nextState ? '💖 Romantic Golden Aura activated in the room!' : 'Closed couple interaction.');
    } catch {
      showNotification(nextState ? '💖 Couple Aura started!' : 'Closed interaction.');
    }
  };

  // 4. CP: Send Couple Gift
  const handleSendCoupleGift = () => {
    onClose();
    if (onOpenCpScreen) onOpenCpScreen();
    else setActiveModal('cp');
    showNotification('Opening CP Romance Gift Center...');
  };

  // 4. CP: Propose Connection to Guest
  const handleProposeCP = async () => {
    if (!selectedPartnerSeat?.userId) {
      showNotification('Please select a seat guest to propose CP to!');
      return;
    }
    setCpSubmitting(true);
    try {
      await ApiClient.sendConnectionRequest(selectedPartnerSeat.userId, 'cp', proposalMsg);
      showNotification(`💍 CP Proposal sent to ${selectedPartnerSeat.userName}!`);
      if (currentUser && currentRoom) {
        setRoomMessages(prev => [...prev, {
          id: `cp-${Date.now()}`,
          roomId: currentRoom.id,
          userId: currentUser.id,
          userName: currentUser.name,
          userAvatar: currentUser.avatar,
          type: 'system',
          content: `💍 ${currentUser.name} sent a Romantic CP Proposal to ${selectedPartnerSeat.userName}!`,
          timestamp: new Date().toISOString()
        }]);
      }
      setSelectedPartnerSeat(null);
    } catch (err: any) {
      showNotification(err.message || 'Proposal sent successfully!');
    } finally {
      setCpSubmitting(false);
    }
  };

  // 5. PK: Start PK Match
  const handleStartPk = async () => {
    if (!currentRoom) return;
    setIsStartingPk(true);
    try {
      const oppId = selectedOpponentRoomId || (availableRooms[0]?.id || 'demo-opp');
      await ApiClient.updateRoomPK(currentRoom.id, {
        action: 'start',
        opponentRoomId: oppId,
        durationSeconds: pkDuration
      });

      setPkTimeLeft(pkDuration);
      setPkMyScore(0);
      setPkOpponentScore(0);
      setPkWinner(null);

      // Update room local state
      setActiveRoom({
        ...currentRoom,
        pkState: {
          active: true,
          opponentRoomId: oppId,
          opponentName: availableRooms.find(r => r.id === oppId)?.hostName || 'Opponent Host',
          opponentAvatar: availableRooms.find(r => r.id === oppId)?.hostAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100',
          myScore: 0,
          opponentScore: 0,
          timeLeft: pkDuration
        }
      });

      showNotification('⚔️ PK Battle started! Rally gifts to defeat the opponent!');
    } catch (err: any) {
      showNotification(err.message || 'PK Battle launched!');
    } finally {
      setIsStartingPk(false);
    }
  };

  // 5. PK: Boost Score
  const handleBoostPkScore = async (side: 'roomA' | 'roomB', points: number) => {
    if (!currentRoom) return;
    try {
      await ApiClient.updateRoomPK(currentRoom.id, {
        action: 'score',
        points,
        side
      });
      if (side === 'roomA') {
        setPkMyScore(prev => prev + points);
      } else {
        setPkOpponentScore(prev => prev + points);
      }
      showNotification(`💥 Boosted ${side === 'roomA' ? 'Your Room' : 'Opponent'} by +${points} points!`);
    } catch (e) {}
  };

  // 5. PK: End PK Early
  const handleEndPk = async () => {
    if (!currentRoom) return;
    try {
      await ApiClient.updateRoomPK(currentRoom.id, {
        action: 'end'
      });
      setActiveRoom({
        ...currentRoom,
        pkState: {
          ...currentRoom.pkState,
          active: false
        }
      });
      const winner = pkMyScore > pkOpponentScore ? 'red' : pkMyScore < pkOpponentScore ? 'blue' : 'draw';
      setPkWinner(winner);
      showNotification('PK Battle concluded by host!');
    } catch {
      showNotification('PK Battle finished.');
    }
  };

  // 6. LUCKY BAG: Drop Coins
  const handleDropLuckyBag = async () => {
    if (isDroppingBag) return;
    if (currentUser && currentUser.coins < luckyBagCoins) {
      showNotification(`Insufficient coin balance! You need ${luckyBagCoins} coins.`);
      return;
    }
    setIsDroppingBag(true);
    try {
      if (currentUser && currentRoom) {
        await ApiClient.createLuckyBag(currentRoom.id, luckyBagCoins, luckyBagWinners);
        await refreshUser();
        const updated = await ApiClient.getActiveLuckyBags(currentRoom.id);
        setActiveBags(updated);
        showNotification(`🎉 Lucky Bag of ${luckyBagCoins} coins dropped in room!`);
      }
    } catch (err: any) {
      showNotification(err.message || 'Failed to drop lucky bag');
    } finally {
      setIsDroppingBag(false);
    }
  };

  // 5 Main Menu items as required by user prompt
  const MENU_OPTIONS = [
    {
      id: 'game' as ToolTabType,
      title: 'Game',
      subtitle: 'Dice Duel, Lucky Wheel, Secret Number & Trivia',
      icon: <Gamepad2 className="w-6 h-6 text-emerald-400" />,
      gradient: 'from-emerald-500/25 via-teal-500/15 to-emerald-900/30',
      border: 'border-emerald-500/30 hover:border-emerald-400/60',
      badge: '4 GAMES',
      badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
      glow: 'shadow-[0_0_20px_rgba(16,185,129,0.25)]'
    },
    {
      id: 'music' as ToolTabType,
      title: 'Music',
      subtitle: 'Room BGM, Queue, Volume & Sound FX Pad',
      icon: <Music className="w-6 h-6 text-cyan-400" />,
      gradient: 'from-cyan-500/25 via-blue-500/15 to-indigo-900/30',
      border: 'border-cyan-500/30 hover:border-cyan-400/60',
      badge: isPlayingMusic ? 'PLAYING' : 'READY',
      badgeColor: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40',
      glow: 'shadow-[0_0_20px_rgba(6,182,212,0.25)]'
    },
    {
      id: 'youtube' as ToolTabType,
      title: 'YouTube',
      subtitle: 'Karaoke & Room Watch Party Video Sync',
      icon: <Youtube className="w-6 h-6 text-rose-400" />,
      gradient: 'from-rose-500/25 via-red-500/15 to-pink-900/30',
      border: 'border-rose-500/30 hover:border-rose-400/60',
      badge: 'HD SYNC',
      badgeColor: 'bg-rose-500/20 text-rose-300 border-rose-500/40',
      glow: 'shadow-[0_0_20px_rgba(244,63,94,0.25)]'
    },
    {
      id: 'cp' as ToolTabType,
      title: 'CP / Couple',
      subtitle: 'Couple Space, Romance Ring & Love Pairing',
      icon: <HeartHandshake className="w-6 h-6 text-pink-400" />,
      gradient: 'from-pink-500/25 via-fuchsia-500/15 to-purple-900/30',
      border: 'border-pink-500/30 hover:border-pink-400/60',
      badge: activeCpAura ? 'AURA ACTIVE' : 'SWEET',
      badgeColor: 'bg-pink-500/20 text-pink-300 border-pink-500/40',
      glow: 'shadow-[0_0_20px_rgba(236,72,153,0.25)]'
    },
    {
      id: 'pk' as ToolTabType,
      title: 'PK Battle',
      subtitle: 'Cross-Room 1v1 Gifting War & Challenges',
      icon: <Swords className="w-6 h-6 text-amber-400" />,
      gradient: 'from-amber-500/25 via-orange-500/15 to-red-900/30',
      border: 'border-amber-500/30 hover:border-amber-400/60',
      badge: currentRoom?.pkState?.active ? 'LIVE PK' : 'WAR',
      badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
      glow: 'shadow-[0_0_20px_rgba(245,158,11,0.25)]'
    }
  ];

  return (
    <div 
      className="fixed inset-0 z-[80] bg-black/80 backdrop-blur-xl flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fadeIn"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div 
        className="w-full max-w-lg bg-[#140a28]/95 backdrop-blur-2xl border-t sm:border border-white/15 rounded-t-[32px] sm:rounded-[32px] shadow-[0_16px_60px_rgba(0,0,0,0.8)] text-white overflow-hidden flex flex-col max-h-[92vh] sm:max-h-[85vh] animate-scaleUp"
      >
        {/* MOBILE PULL HANDLE */}
        <div className="pt-3 pb-1 sm:hidden">
          <div className="w-12 h-1.5 bg-white/20 rounded-full mx-auto" />
        </div>

        {/* MODAL HEADER */}
        <div className="px-5 py-3.5 border-b border-white/10 flex items-center justify-between bg-white/[0.03]">
          <div className="flex items-center gap-2.5">
            {currentTab !== 'menu' && (
              <button
                type="button"
                onClick={() => setCurrentTab('menu')}
                className="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center text-slate-300 hover:text-white transition-all active:scale-90 mr-1 cursor-pointer"
                title="Back to All Tools"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
            )}

            <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-amber-400 via-pink-500 to-purple-600 p-[1.5px] flex items-center justify-center shadow-md">
              <div className="w-full h-full bg-[#160a2c] rounded-[14px] flex items-center justify-center">
                <Wand2 className="w-4 h-4 text-amber-300" />
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-white text-base tracking-wide flex items-center gap-1.5">
                  {currentTab === 'menu' && 'Room Tools & Controls'}
                  {currentTab === 'game' && 'Game Center'}
                  {currentTab === 'music' && 'Room Music Player'}
                  {currentTab === 'youtube' && 'YouTube Watch Party'}
                  {currentTab === 'cp' && 'CP / Couple Space'}
                  {currentTab === 'pk' && 'PK Battle Warfare'}
                  {currentTab === 'lucky_bag' && 'Lucky Bag Red Packets'}
                </h3>
                <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-purple-500/25 text-purple-300 border border-purple-500/30">
                  LIVE
                </span>
              </div>
              <p className="text-[11px] text-slate-300">
                {currentTab === 'menu' && 'Choose from the 5 live entertainment options'}
                {currentTab === 'game' && 'Multiplayer in-room games synchronized with guests'}
                {currentTab === 'music' && 'Play background tracks, sound effects & manage queue'}
                {currentTab === 'youtube' && 'Watch videos & sing karaoke with room participants'}
                {currentTab === 'cp' && 'Intimacy space, couple interactions & romance pairing'}
                {currentTab === 'pk' && '1v1 battle warfare against rival voice rooms'}
                {currentTab === 'lucky_bag' && 'Drop coin packets to reward room members'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={onClose}
              className="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white flex items-center justify-center transition-all active:scale-90 cursor-pointer"
              title="Close Tools"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* QUICK TAB NAV PILLS */}
        <div className="px-4 py-2 border-b border-white/5 bg-black/20 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          <button
            type="button"
            onClick={() => setCurrentTab('menu')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 flex items-center gap-1.5 cursor-pointer ${
              currentTab === 'menu'
                ? 'bg-amber-400 text-black font-extrabold shadow-sm'
                : 'bg-white/5 hover:bg-white/10 text-slate-300'
            }`}
          >
            <span>All Tools</span>
          </button>
          {MENU_OPTIONS.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setCurrentTab(item.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 flex items-center gap-1.5 border cursor-pointer ${
                currentTab === item.id
                  ? 'bg-white/20 border-white/40 text-white font-extrabold shadow-sm'
                  : 'bg-white/5 hover:bg-white/10 text-slate-300 border-white/10'
              }`}
            >
              <span className="scale-75 origin-center">{item.icon}</span>
              <span>{item.title}</span>
            </button>
          ))}
        </div>

        {/* MODAL BODY (SCROLLABLE & RESPONSIVE) */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          
          {/* ========================================================= */}
          {/* 1. MAIN MENU GRID (5 TOOLS)                               */}
          {/* ========================================================= */}
          {currentTab === 'menu' && (
            <div className="space-y-4">
              {/* Quick Info Balance Banner */}
              <div className="p-3.5 rounded-2xl bg-gradient-to-r from-purple-900/40 via-indigo-900/30 to-black/40 border border-purple-500/20 backdrop-blur-md flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-amber-400/20 text-amber-300 flex items-center justify-center font-black text-sm">
                    🪙
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-300 font-medium uppercase tracking-wider">Your Balance</span>
                    <h5 className="font-extrabold text-amber-300 text-sm">
                      {currentUser?.coins?.toLocaleString() || 0} Coins
                    </h5>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    setActiveModal('wallet');
                  }}
                  className="px-3 py-1.5 rounded-xl bg-amber-400 text-black font-extrabold text-xs shadow hover:bg-amber-300 transition-colors cursor-pointer"
                >
                  Recharge +
                </button>
              </div>

              {/* 5 Main Frosted Glass Tools Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {MENU_OPTIONS.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setCurrentTab(item.id)}
                    className={`group text-left p-4 rounded-2xl bg-gradient-to-br ${item.gradient} border ${item.border} backdrop-blur-xl transition-all duration-200 hover:scale-[1.02] active:scale-95 cursor-pointer relative overflow-hidden flex flex-col justify-between min-h-[110px] shadow-lg hover:${item.glow}`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="w-11 h-11 rounded-2xl bg-black/40 border border-white/10 flex items-center justify-center shadow-inner group-hover:scale-110 transition-transform">
                        {item.icon}
                      </div>
                      <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-full border ${item.badgeColor}`}>
                        {item.badge}
                      </span>
                    </div>

                    <div className="mt-3">
                      <h4 className="font-black text-white text-sm flex items-center justify-between group-hover:text-amber-300 transition-colors">
                        <span>{item.title}</span>
                        <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-1 transition-transform" />
                      </h4>
                      <p className="text-[11px] text-slate-300 line-clamp-1 mt-0.5">
                        {item.subtitle}
                      </p>
                    </div>
                  </button>
                ))}
              </div>

              {/* Room Visual Theme Banner */}
              <div 
                onClick={() => {
                  onClose();
                  if (onOpenThemeModal) onOpenThemeModal();
                }}
                className="p-3.5 rounded-2xl bg-gradient-to-r from-purple-950/60 via-indigo-950/60 to-pink-950/50 border border-purple-500/30 hover:border-purple-400/60 backdrop-blur-md flex items-center justify-between cursor-pointer group shadow-lg transition-all hover:scale-[1.01]"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-purple-500/20 text-purple-300 border border-purple-400/30 flex items-center justify-center font-black text-lg group-hover:scale-110 transition-transform">
                    🎨
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-extrabold text-white text-xs">
                        Stage Visual Theme: <span className="text-amber-300">{currentRoom?.theme ? currentRoom.theme.toUpperCase() : 'NIGHT MODE'}</span>
                      </h4>
                      <span className="text-[9px] font-black uppercase px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
                        HOST
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-300">
                      Night Mode, Party, Chill, Cyberpunk, Aurora & Wallpapers
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-1 text-purple-300 text-xs font-bold group-hover:translate-x-1 transition-transform">
                  <span className="hidden sm:inline">Customize</span>
                  <ChevronRight className="w-4 h-4" />
                </div>
              </div>

              {/* Top Contributors Leaderboard Quick Banner */}
              <div 
                onClick={() => {
                  onClose();
                  if (onOpenContributorsModal) onOpenContributorsModal();
                  else setActiveModal('contributors');
                }}
                className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-950/60 via-yellow-950/40 to-orange-950/60 border border-amber-500/30 hover:border-amber-400/60 backdrop-blur-md flex items-center justify-between cursor-pointer group shadow-lg transition-all hover:scale-[1.01]"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-300 border border-amber-400/30 flex items-center justify-center font-black text-lg group-hover:scale-110 transition-transform">
                    🏆
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-extrabold text-white text-xs">
                        Top Contributors Leaderboard
                      </h4>
                      <span className="text-[9px] font-black uppercase px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 animate-pulse">
                        LIVE
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-300">
                      Real-time gift earnings, top givers & engagement rankings
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-1 text-amber-400 text-xs font-bold group-hover:translate-x-1 transition-transform">
                  <span className="hidden sm:inline">Rankings</span>
                  <ChevronRight className="w-4 h-4" />
                </div>
              </div>

              {/* Room Host Status */}
              <div className="p-3 rounded-2xl bg-white/[0.04] border border-white/10 flex items-center justify-between text-xs text-slate-300">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  Room: <b className="text-white truncate max-w-[150px]">{currentRoom?.title}</b>
                </span>
                <span className="text-[11px] text-slate-400">
                  Host: <b className="text-slate-200">{currentRoom?.hostName}</b>
                </span>
              </div>
            </div>
          )}

          {/* ========================================================= */}
          {/* 2. GAME PANEL                                             */}
          {/* ========================================================= */}
          {currentTab === 'game' && (
            <div className="space-y-4">
              {/* Game Status Banner */}
              <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-950/60 to-black/60 border border-emerald-500/30 backdrop-blur-xl flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center text-lg">
                    {selectedGame.icon}
                  </div>
                  <div>
                    <h5 className="font-extrabold text-white text-xs flex items-center gap-1.5">
                      <span>{selectedGame.name}</span>
                      <span className={`text-[9px] font-black uppercase px-1.5 py-0.2 rounded-full ${
                        gameStatus === 'in_progress' ? 'bg-emerald-500 text-black' : 'bg-white/10 text-slate-300'
                      }`}>
                        {gameStatus === 'in_progress' ? 'ACTIVE IN ROOM' : 'WAITING'}
                      </span>
                    </h5>
                    <p className="text-[10px] text-slate-300">
                      {currentRoom?.onlineCount || 1} room listeners can join & play
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={handleInviteMembers}
                    className="px-2.5 py-1.5 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-bold flex items-center gap-1 transition-all active:scale-95 cursor-pointer"
                    title="Invite room members to game"
                  >
                    <UserPlus className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Invite</span>
                  </button>

                  {gameStatus === 'in_progress' ? (
                    <button
                      type="button"
                      onClick={handleExitGame}
                      className="px-2.5 py-1.5 bg-rose-600/80 hover:bg-rose-500 text-white rounded-xl text-xs font-bold transition-all active:scale-95 cursor-pointer"
                    >
                      Exit Game
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={handleStartGame}
                      className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-black rounded-xl text-xs font-black shadow transition-all active:scale-95 cursor-pointer"
                    >
                      Start Game
                    </button>
                  )}
                </div>
              </div>

              {/* Game Selector List */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-300 flex items-center gap-1">
                  <span>Choose Game:</span>
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {GAME_CATALOG.map((g) => (
                    <button
                      key={g.id}
                      type="button"
                      onClick={() => {
                        setSelectedGame(g);
                        setDiceResult(null);
                        setGuessFeedback(null);
                      }}
                      className={`p-2.5 rounded-2xl border text-left flex items-start gap-2.5 transition-all cursor-pointer ${
                        selectedGame.id === g.id
                          ? 'bg-emerald-500/20 border-emerald-400 text-white shadow-md'
                          : 'bg-black/40 hover:bg-white/5 border-white/10 text-slate-300'
                      }`}
                    >
                      <span className="text-2xl">{g.icon}</span>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between">
                          <span className="font-extrabold text-xs truncate">{g.name}</span>
                          <span className="text-[9px] font-black px-1.5 py-0.2 rounded bg-emerald-400/20 text-emerald-300">
                            {g.badge}
                          </span>
                        </div>
                        <p className="text-[10px] text-slate-400 line-clamp-1 mt-0.5">{g.category}</p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Interactive Gameplay Container */}
              {selectedGame.id === 'dice' && (
                <div className="p-4 rounded-3xl bg-gradient-to-br from-emerald-950/40 via-black/50 to-teal-950/40 border border-emerald-500/30 backdrop-blur-xl space-y-3.5 shadow-xl text-center">
                  <div className="flex items-center justify-between border-b border-white/10 pb-2">
                    <div className="text-left">
                      <h4 className="font-black text-white text-xs flex items-center gap-1.5">
                        <span>🎲 Dice Duel Arena</span>
                      </h4>
                      <p className="text-[10px] text-slate-300">Roll 9 or higher to double your coins in room!</p>
                    </div>
                    <span className="text-xs font-extrabold text-emerald-400 bg-emerald-500/20 px-2 py-0.5 rounded-full border border-emerald-500/30">
                      2x Multiplier
                    </span>
                  </div>

                  {/* Dice Display */}
                  <div className="py-2 flex items-center justify-center gap-4">
                    <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-700 text-white font-black text-2xl flex items-center justify-center shadow-[0_0_20px_rgba(16,185,129,0.4)] border border-white/30 ${diceRolling ? 'animate-spin' : ''}`}>
                      {diceResult ? diceResult.d1 : '🎲'}
                    </div>
                    <span className="text-lg font-black text-slate-400">+</span>
                    <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br from-teal-500 to-emerald-800 text-white font-black text-2xl flex items-center justify-center shadow-[0_0_20px_rgba(20,184,166,0.4)] border border-white/30 ${diceRolling ? 'animate-spin' : ''}`}>
                      {diceResult ? diceResult.d2 : '🎲'}
                    </div>
                  </div>

                  {diceResult && (
                    <div className="p-2 rounded-xl bg-black/40 border border-white/10 animate-bounce">
                      <p className="text-xs font-extrabold text-white">
                        Total Roll: <span className="text-emerald-300 text-sm font-black">{diceResult.total}</span>
                        {diceResult.total >= 9 ? ' — 🎉 WINNER! (2X Prize)' : ' — Try next roll!'}
                      </p>
                    </div>
                  )}

                  {/* Stake Presets */}
                  <div className="flex items-center justify-center gap-2">
                    {[0, 50, 100, 200].map((amount) => (
                      <button
                        key={amount}
                        type="button"
                        onClick={() => setDiceBet(amount)}
                        className={`px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                          diceBet === amount
                            ? 'bg-emerald-500 text-black font-extrabold shadow-md'
                            : 'bg-white/10 hover:bg-white/15 text-slate-300'
                        }`}
                      >
                        {amount === 0 ? 'Free Fun' : `${amount} 🪙`}
                      </button>
                    ))}
                  </div>

                  <button
                    type="button"
                    onClick={handleRollDice}
                    disabled={diceRolling}
                    className="w-full py-2.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-black font-black text-xs rounded-xl shadow-lg transition-all active:scale-95 disabled:opacity-50 cursor-pointer flex items-center justify-center gap-2"
                  >
                    {diceRolling ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>Rolling the Dice...</span>
                      </>
                    ) : (
                      <>
                        <span>🎲 Roll Dice in Voice Room</span>
                      </>
                    )}
                  </button>
                </div>
              )}

              {selectedGame.id === 'guess_number' && (
                <div className="p-4 rounded-3xl bg-gradient-to-br from-indigo-950/40 via-black/50 to-purple-950/40 border border-indigo-500/30 backdrop-blur-xl space-y-3 text-center">
                  <div className="text-left">
                    <h5 className="font-extrabold text-white text-xs flex items-center gap-1.5">
                      <Hash className="w-4 h-4 text-indigo-400" /> Guess The Secret Number (1-100)
                    </h5>
                    <p className="text-[10px] text-slate-300">Jackpot Reward: 200 Free Coins for whoever guesses right!</p>
                  </div>

                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min="1"
                      max="100"
                      placeholder="Enter 1-100..."
                      value={guessInput}
                      onChange={(e) => setGuessInput(e.target.value)}
                      className="flex-1 bg-black/40 text-xs text-white px-3 py-2 rounded-xl border border-white/15 focus:outline-none focus:border-indigo-400 text-center font-black"
                    />
                    <button
                      type="button"
                      onClick={handleGuessSubmit}
                      className="px-4 py-2 bg-indigo-500 hover:bg-indigo-400 text-white font-extrabold text-xs rounded-xl shadow cursor-pointer active:scale-95"
                    >
                      Submit Guess
                    </button>
                  </div>

                  {guessFeedback && (
                    <div className="p-2.5 rounded-xl bg-black/40 border border-indigo-500/30 text-xs font-bold text-indigo-200">
                      {guessFeedback}
                    </div>
                  )}
                </div>
              )}

              {selectedGame.id === 'spin' && (
                <div className="p-4 rounded-3xl bg-gradient-to-br from-amber-950/40 via-black/50 to-orange-950/40 border border-amber-500/30 backdrop-blur-xl space-y-3 text-center">
                  <div className="w-12 h-12 mx-auto rounded-full bg-amber-500/20 text-2xl flex items-center justify-center animate-spin">
                    🎡
                  </div>
                  <h5 className="font-extrabold text-white text-xs">Aura Wheel of Fortune</h5>
                  <p className="text-[10px] text-slate-300">Spin the big wheel for cars, diamond frames & 5,000 coins</p>
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      if (onOpenDailySpin) onOpenDailySpin();
                      else setActiveModal('spin');
                    }}
                    className="w-full py-2.5 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 text-black font-extrabold text-xs rounded-xl shadow cursor-pointer"
                  >
                    Open Full Spin Wheel 🎡
                  </button>
                </div>
              )}

              {selectedGame.id === 'trivia' && (
                <div className="p-4 rounded-3xl bg-gradient-to-br from-purple-950/40 via-black/50 to-pink-950/40 border border-purple-500/30 backdrop-blur-xl space-y-3">
                  <div className="flex items-center justify-between">
                    <h5 className="font-extrabold text-white text-xs">Trivia Round #1: Aura Voice Trivia</h5>
                    <span className="text-[10px] font-bold text-purple-300">10 Pts</span>
                  </div>
                  <p className="text-xs text-slate-200 font-semibold">Which virtual gift gives the highest diamond conversion rate in room?</p>
                  <div className="grid grid-cols-2 gap-2">
                    {['Royal Dragon', 'Rocket Ship', 'Golden Sports Car', 'Diamond Crown'].map((ans, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => showNotification(ans === 'Royal Dragon' ? '✅ Correct Answer! +10 Points' : '❌ Try again!')}
                        className="p-2 rounded-xl bg-white/5 hover:bg-white/15 border border-white/10 text-xs font-bold text-left transition-all active:scale-95"
                      >
                        {ans}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ========================================================= */}
          {/* 3. MUSIC PANEL                                            */}
          {/* ========================================================= */}
          {currentTab === 'music' && (
            <div className="space-y-4">
              {/* Now Playing Widget */}
              <div className="p-4 rounded-3xl bg-gradient-to-br from-cyan-950/50 via-black/50 to-blue-950/40 border border-cyan-500/30 backdrop-blur-xl space-y-3 shadow-xl">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-300 text-xl font-black shadow-[0_0_15px_rgba(6,182,212,0.3)]">
                      <Disc className={`w-6 h-6 ${isPlayingMusic ? 'animate-spin' : ''}`} />
                    </div>
                    <div>
                      <h4 className="font-black text-white text-sm">{selectedTrack.title}</h4>
                      <p className="text-xs text-cyan-300/80">{selectedTrack.artist} • {selectedTrack.mood}</p>
                    </div>
                  </div>

                  {/* Play / Pause / Skip Controls */}
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => handleSkipTrack('prev')}
                      className="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-all active:scale-90 cursor-pointer"
                      title="Previous Track"
                    >
                      <SkipBack className="w-4 h-4" />
                    </button>

                    <button
                      type="button"
                      onClick={handleTogglePlayMusic}
                      className="w-10 h-10 rounded-2xl bg-cyan-500 hover:bg-cyan-400 text-black flex items-center justify-center shadow-lg transition-transform active:scale-90 cursor-pointer"
                      title={isPlayingMusic ? 'Pause Music' : 'Play Music'}
                    >
                      {isPlayingMusic ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current ml-0.5" />}
                    </button>

                    <button
                      type="button"
                      onClick={() => handleSkipTrack('next')}
                      className="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-all active:scale-90 cursor-pointer"
                      title="Next Track"
                    >
                      <SkipForward className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Animated Equalizer Waveform */}
                <div className="h-6 flex items-end gap-1 px-1">
                  {[40, 75, 55, 90, 65, 30, 85, 100, 70, 45, 80, 95, 60, 40, 85].map((h, i) => (
                    <div
                      key={i}
                      style={{ height: isPlayingMusic ? `${h}%` : '20%' }}
                      className="flex-1 bg-gradient-to-t from-cyan-500 to-indigo-400 rounded-t-sm transition-all duration-300"
                    />
                  ))}
                </div>

                {/* Volume Slider */}
                <div className="flex items-center gap-3 pt-1">
                  {musicVolume === 0 ? <VolumeX className="w-4 h-4 text-slate-400" /> : <Volume2 className="w-4 h-4 text-cyan-400" />}
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={musicVolume}
                    onChange={(e) => setMusicVolume(parseInt(e.target.value, 10))}
                    className="flex-1 accent-cyan-400 h-1.5 bg-white/10 rounded-lg cursor-pointer"
                  />
                  <span className="text-[11px] font-mono font-bold text-slate-300 w-8 text-right">
                    {musicVolume}%
                  </span>
                </div>
              </div>

              {/* Music Queue & Add Music */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h5 className="font-extrabold text-white text-xs uppercase tracking-wider flex items-center gap-1.5">
                    <ListMusic className="w-3.5 h-3.5 text-cyan-400" /> Room Music Queue ({musicQueue.length})
                  </h5>
                  <button
                    type="button"
                    onClick={() => setShowAddMusicDialog(!showAddMusicDialog)}
                    className="px-2 py-1 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 rounded-lg text-[10px] font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3 h-3" />
                    <span>Add Track</span>
                  </button>
                </div>

                {/* Add Custom Track Input Dialog */}
                {showAddMusicDialog && (
                  <div className="p-3 rounded-2xl bg-black/50 border border-cyan-500/30 space-y-2 animate-fadeIn">
                    <h6 className="text-[11px] font-bold text-white">Add Music to Room Queue</h6>
                    <input
                      type="text"
                      placeholder="Track Title (e.g. Moonlight Piano)..."
                      value={customTrackTitle}
                      onChange={(e) => setCustomTrackTitle(e.target.value)}
                      className="w-full bg-black/60 text-xs text-white px-3 py-1.5 rounded-xl border border-white/15 focus:outline-none focus:border-cyan-400"
                    />
                    <input
                      type="text"
                      placeholder="Artist / Creator..."
                      value={customTrackArtist}
                      onChange={(e) => setCustomTrackArtist(e.target.value)}
                      className="w-full bg-black/60 text-xs text-white px-3 py-1.5 rounded-xl border border-white/15 focus:outline-none focus:border-cyan-400"
                    />
                    <input
                      type="text"
                      placeholder="Audio URL (Safe MP3 / Audio Stream)..."
                      value={customTrackUrl}
                      onChange={(e) => setCustomTrackUrl(e.target.value)}
                      className="w-full bg-black/60 text-xs text-white px-3 py-1.5 rounded-xl border border-white/15 focus:outline-none focus:border-cyan-400"
                    />
                    <div className="flex justify-end gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => setShowAddMusicDialog(false)}
                        className="px-3 py-1 text-xs text-slate-300 hover:text-white"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        onClick={handleAddTrack}
                        className="px-3 py-1 bg-cyan-500 text-black font-extrabold text-xs rounded-xl shadow"
                      >
                        Add to Queue
                      </button>
                    </div>
                  </div>
                )}

                {/* Queue Track List */}
                <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
                  {musicQueue.map((track, idx) => (
                    <div
                      key={track.id}
                      className={`w-full p-2.5 rounded-xl border flex items-center justify-between transition-all ${
                        selectedTrack.id === track.id
                          ? 'bg-cyan-500/20 border-cyan-400 text-white shadow-sm'
                          : 'bg-black/30 hover:bg-white/5 border-white/10 text-slate-300'
                      }`}
                    >
                      <div 
                        className="flex items-center gap-2.5 cursor-pointer flex-1 min-w-0"
                        onClick={() => {
                          setCurrentTrackIndex(idx);
                          setSelectedTrack(track);
                          setIsPlayingMusic(true);
                        }}
                      >
                        <span className="text-xs font-mono text-cyan-400 shrink-0">
                          {selectedTrack.id === track.id ? '▶' : `${idx + 1}.`}
                        </span>
                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-bold text-white truncate">{track.title}</p>
                          <p className="text-[10px] text-slate-400 truncate">{track.artist}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <span className="text-[10px] font-mono text-slate-400">{track.duration}</span>
                        {musicQueue.length > 1 && (
                          <button
                            type="button"
                            onClick={() => handleRemoveTrack(track.id)}
                            className="text-slate-500 hover:text-rose-400 p-1 cursor-pointer"
                            title="Remove from queue"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Instant Sound Effects Pad */}
              <div className="space-y-2">
                <h5 className="font-extrabold text-white text-xs uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" /> Instant Sound Reaction Pad
                </h5>
                <div className="grid grid-cols-3 gap-2">
                  {SOUND_EFFECTS.map((fx) => (
                    <button
                      key={fx.id}
                      type="button"
                      onClick={() => handlePlaySoundEffect(fx)}
                      className="p-2 rounded-2xl bg-white/5 hover:bg-white/15 border border-white/10 flex flex-col items-center justify-center gap-1 transition-all active:scale-90 hover:scale-105 cursor-pointer shadow-sm group"
                    >
                      <span className="text-xl group-hover:scale-125 transition-transform">{fx.icon}</span>
                      <span className="text-[10px] font-bold text-slate-200">{fx.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ========================================================= */}
          {/* 4. YOUTUBE PANEL                                          */}
          {/* ========================================================= */}
          {currentTab === 'youtube' && (
            <div className="space-y-4">
              {/* YouTube Synced Player Box */}
              <div className="p-4 rounded-3xl bg-gradient-to-br from-rose-950/50 via-black/50 to-pink-950/40 border border-rose-500/30 backdrop-blur-xl space-y-3 shadow-xl">
                {showIframePlayer ? (
                  <div className="relative rounded-2xl overflow-hidden aspect-video bg-black border border-white/10">
                    <iframe
                      src={`https://www.youtube-nocookie.com/embed/${activeYoutubeVideo.videoId}?autoplay=${isYoutubePlaying ? 1 : 0}&enablejsapi=1`}
                      title={activeYoutubeVideo.title}
                      className="w-full h-full border-0"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    />
                  </div>
                ) : (
                  <div className="relative rounded-2xl overflow-hidden aspect-video bg-black/60 border border-white/10 flex flex-col items-center justify-center text-center p-4">
                    <Youtube className="w-12 h-12 text-rose-500 mb-2" />
                    <h5 className="font-extrabold text-white text-xs">Player Paused / Closed</h5>
                    <button
                      type="button"
                      onClick={() => setShowIframePlayer(true)}
                      className="mt-2 px-3 py-1 bg-rose-600 text-white rounded-xl text-xs font-bold"
                    >
                      Reopen Stream
                    </button>
                  </div>
                )}

                <div className="flex items-center justify-between text-xs">
                  <div>
                    <h4 className="font-extrabold text-white text-xs truncate max-w-[200px] sm:max-w-xs">{activeYoutubeVideo.title}</h4>
                    <p className="text-[10px] text-slate-400">{activeYoutubeVideo.channel} • {activeYoutubeVideo.duration}</p>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => {
                        const next = !isYoutubePlaying;
                        setIsYoutubePlaying(next);
                        showNotification(next ? 'Resumed YouTube sync' : 'Paused YouTube sync');
                      }}
                      className="px-2.5 py-1 bg-white/10 hover:bg-white/20 rounded-lg font-bold text-[11px] text-white cursor-pointer"
                    >
                      {isYoutubePlaying ? 'Pause' : 'Play'}
                    </button>
                    <button
                      type="button"
                      onClick={handleCloseYoutube}
                      className="px-2.5 py-1 bg-rose-600/80 hover:bg-rose-500 rounded-lg font-bold text-[11px] text-white cursor-pointer"
                    >
                      Close
                    </button>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 text-emerald-400 font-bold text-[10px] pt-1 border-t border-white/10">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  Synchronized with all {currentRoom?.onlineCount || 1} room listeners in real time
                </div>
              </div>

              {/* Custom YouTube URL / Search Input */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-200">
                  Search or Paste YouTube Video URL
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="https://youtube.com/watch?v=... or Video ID"
                    value={youtubeUrl}
                    onChange={(e) => setYoutubeUrl(e.target.value)}
                    className="flex-1 bg-black/40 text-xs text-white px-3 py-2 rounded-xl border border-white/15 focus:outline-none focus:border-rose-400"
                  />
                  <button
                    type="button"
                    onClick={handleAddCustomYoutube}
                    className="px-4 bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 text-white font-extrabold text-xs rounded-xl shadow transition-all active:scale-95 cursor-pointer"
                  >
                    Add Video
                  </button>
                </div>
              </div>

              {/* YouTube Queue & Presets */}
              <div className="space-y-2">
                <h5 className="font-extrabold text-white text-xs uppercase tracking-wider flex items-center justify-between">
                  <span>Upcoming Queue ({youtubeQueue.length})</span>
                </h5>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-40 overflow-y-auto pr-1">
                  {youtubeQueue.map((video) => (
                    <button
                      key={video.id}
                      type="button"
                      onClick={() => handleSyncYoutube(video)}
                      className={`text-left p-2 rounded-xl border flex items-center gap-2.5 transition-all cursor-pointer ${
                        activeYoutubeVideo.id === video.id
                          ? 'bg-rose-500/25 border-rose-400 text-white shadow-sm'
                          : 'bg-black/30 hover:bg-white/5 border-white/10 text-slate-300'
                      }`}
                    >
                      <img src={video.thumbnail} alt="" className="w-10 h-10 rounded-lg object-cover" />
                      <div className="min-w-0 flex-1">
                        <h6 className="font-bold text-xs truncate text-white">{video.title}</h6>
                        <span className="text-[10px] text-slate-400">{video.duration}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ========================================================= */}
          {/* 5. CP / COUPLE PANEL                                      */}
          {/* ========================================================= */}
          {currentTab === 'cp' && (
            <div className="space-y-4">
              {/* Couple Romance Status Card */}
              <div className="p-5 rounded-3xl bg-gradient-to-br from-pink-950/50 via-black/50 to-purple-950/40 border border-pink-500/30 backdrop-blur-xl text-center space-y-3 shadow-xl">
                <div className="w-12 h-12 mx-auto rounded-full bg-gradient-to-tr from-pink-500 to-rose-400 flex items-center justify-center text-2xl shadow-[0_0_25px_rgba(236,72,153,0.4)] animate-pulse">
                  💖
                </div>
                <div>
                  <h4 className="font-black text-white text-sm">Aura Voice CP / Couple Space</h4>
                  <p className="text-xs text-pink-200/80">Connect your relationship to the voice room & share intimate moments</p>
                </div>

                {/* Couple Profile Showcase */}
                {myConnection ? (
                  <div className="p-3 rounded-2xl bg-black/40 border border-pink-500/30 space-y-2.5">
                    <div className="flex items-center justify-center gap-4">
                      {/* User 1 */}
                      <div className="text-center">
                        <img
                          src={currentUser?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100'}
                          alt={currentUser?.name}
                          className="w-12 h-12 rounded-full border-2 border-pink-400 object-cover shadow mx-auto"
                        />
                        <span className="text-xs font-bold text-white mt-1 block truncate max-w-[75px]">
                          {currentUser?.name || 'You'}
                        </span>
                      </div>

                      {/* Golden CP Ring */}
                      <div className="flex flex-col items-center">
                        <Heart className="w-5 h-5 text-pink-500 fill-pink-500 animate-bounce" />
                        <span className="text-[9px] font-black text-pink-300">CP RING</span>
                        <span className="text-[10px] font-mono text-amber-300 font-extrabold">
                          Lv. {myConnection.level || 4}
                        </span>
                      </div>

                      {/* Partner */}
                      <div className="text-center">
                        <img
                          src={myConnection.user1Id === currentUser?.id ? (myConnection.user2?.avatar || 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=100') : (myConnection.user1?.avatar || 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=100')}
                          alt=""
                          className="w-12 h-12 rounded-full border-2 border-pink-400 object-cover shadow mx-auto"
                        />
                        <span className="text-xs font-bold text-pink-200 mt-1 block truncate max-w-[75px]">
                          {myConnection.user1Id === currentUser?.id ? (myConnection.user2?.name || 'Soulmate') : (myConnection.user1?.name || 'Soulmate')}
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-center pt-1 border-t border-white/10 text-xs">
                      <div className="p-1.5 rounded-xl bg-white/5">
                        <span className="text-[10px] text-slate-400 block">Couple ID</span>
                        <span className="font-mono font-bold text-amber-300">CP-{myConnection.id.slice(-6).toUpperCase()}</span>
                      </div>
                      <div className="p-1.5 rounded-xl bg-white/5">
                        <span className="text-[10px] text-slate-400 block">Together For</span>
                        <span className="font-bold text-pink-300">48 Days</span>
                      </div>
                    </div>

                    {/* CP Interaction Actions */}
                    <div className="grid grid-cols-2 gap-2 pt-1">
                      <button
                        type="button"
                        onClick={handleToggleCpAura}
                        className={`py-2 px-3 rounded-xl font-bold text-xs shadow transition-all active:scale-95 cursor-pointer ${
                          activeCpAura
                            ? 'bg-rose-600 text-white'
                            : 'bg-gradient-to-r from-pink-500 to-purple-600 text-white'
                        }`}
                      >
                        {activeCpAura ? 'Stop Romantic Aura' : 'Start Romantic Aura'}
                      </button>

                      <button
                        type="button"
                        onClick={handleSendCoupleGift}
                        className="py-2 px-3 rounded-xl bg-gradient-to-r from-amber-500 to-pink-500 text-black font-extrabold text-xs shadow transition-all active:scale-95 cursor-pointer"
                      >
                        Send CP Gift 💍
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="p-3 rounded-2xl bg-black/40 border border-white/10 text-xs text-slate-300">
                    <p>You don't have an active CP paired yet.</p>
                    <p className="text-[10px] text-slate-400 mt-0.5">Select a guest from the active mic seats below to propose!</p>
                  </div>
                )}
              </div>

              {/* Propose CP to Mic Seat Guest */}
              <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-3">
                <h5 className="font-extrabold text-white text-xs uppercase tracking-wider flex items-center gap-1.5">
                  <HeartHandshake className="w-3.5 h-3.5 text-pink-400" /> Propose CP to Mic Seat Guest
                </h5>

                <div className="space-y-1.5">
                  <label className="text-[11px] text-slate-300">Choose person from active seats:</label>
                  <div className="grid grid-cols-2 gap-2 max-h-32 overflow-y-auto">
                    {currentRoom?.seats
                      .filter(s => s.userId && s.userId !== currentUser?.id)
                      .map((seat) => (
                        <button
                          key={seat.index}
                          type="button"
                          onClick={() => setSelectedPartnerSeat(seat)}
                          className={`p-2 rounded-xl border flex items-center gap-2 text-left transition-all cursor-pointer ${
                            selectedPartnerSeat?.userId === seat.userId
                              ? 'bg-pink-500/25 border-pink-400 text-white'
                              : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                          }`}
                        >
                          <img src={seat.userAvatar} alt="" className="w-7 h-7 rounded-full object-cover" />
                          <div className="min-w-0 flex-1">
                            <p className="text-xs font-bold truncate text-white">{seat.userName}</p>
                            <p className="text-[9px] text-slate-400">Seat #{seat.index}</p>
                          </div>
                        </button>
                      ))}
                  </div>
                  {currentRoom?.seats.filter(s => s.userId && s.userId !== currentUser?.id).length === 0 && (
                    <p className="text-[11px] text-slate-400 py-1">No other guests currently on mic seats.</p>
                  )}
                </div>

                <button
                  type="button"
                  onClick={handleProposeCP}
                  disabled={!selectedPartnerSeat || cpSubmitting}
                  className="w-full py-2.5 bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-400 text-white font-extrabold text-xs rounded-xl shadow transition-all active:scale-95 disabled:opacity-40 cursor-pointer"
                >
                  Send Love Proposal 💍
                </button>
              </div>

              {/* Full CP Center Launcher */}
              <button
                type="button"
                onClick={() => {
                  onClose();
                  if (onOpenCpScreen) onOpenCpScreen();
                  else setActiveModal('cp');
                }}
                className="w-full py-3 bg-white/10 hover:bg-white/15 border border-white/15 text-pink-300 font-extrabold text-xs rounded-2xl flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <span>Open Full Couple Profile & Intimacy Space</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* ========================================================= */}
          {/* 6. PK BATTLE PANEL                                        */}
          {/* ========================================================= */}
          {currentTab === 'pk' && (
            <div className="space-y-4">
              {/* PK Warfare Live Status */}
              <div className="p-5 rounded-3xl bg-gradient-to-br from-red-950/50 via-black/50 to-orange-950/40 border border-amber-500/30 backdrop-blur-xl space-y-3.5 shadow-xl text-center">
                <div className="w-12 h-12 mx-auto rounded-full bg-gradient-to-tr from-amber-500 via-orange-500 to-red-600 flex items-center justify-center text-2xl shadow-[0_0_25px_rgba(245,158,11,0.4)] animate-bounce">
                  ⚔️
                </div>
                <div>
                  <h4 className="font-black text-white text-sm">1v1 Voice Room PK Battle Warfare</h4>
                  <p className="text-xs text-slate-300">Live head-to-head gifting competition against rival rooms</p>
                </div>

                {currentRoom?.pkState?.active ? (
                  <div className="space-y-3">
                    <PKBattle
                      variant="split"
                      roomA={{
                        id: currentRoom.id,
                        name: currentRoom.title,
                        hostName: currentRoom.hostName,
                        hostAvatar: currentRoom.hostAvatar,
                        score: pkMyScore
                      }}
                      roomB={{
                        id: currentRoom.pkState.opponentRoomId || selectedOpponentRoomId || 'opp-room',
                        name: currentRoom.pkState.opponentName || availableRooms.find(r => r.id === selectedOpponentRoomId)?.title || 'Challenger Room',
                        hostName: currentRoom.pkState.opponentName || availableRooms.find(r => r.id === selectedOpponentRoomId)?.hostName || 'Opponent Host',
                        hostAvatar: currentRoom.pkState.opponentAvatar || availableRooms.find(r => r.id === selectedOpponentRoomId)?.hostAvatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100',
                        score: pkOpponentScore
                      }}
                      scoreA={pkMyScore}
                      scoreB={pkOpponentScore}
                      timeLeft={pkTimeLeft}
                      onCheer={(side, points) => handleBoostPkScore(side, points)}
                      onBattleEnd={(winner) => {
                        setPkWinner(winner === 'roomA' ? 'red' : winner === 'roomB' ? 'blue' : 'draw');
                      }}
                    />

                    {isHostOrManager && (
                      <button
                        type="button"
                        onClick={handleEndPk}
                        className="w-full py-2.5 bg-rose-600/80 hover:bg-rose-500 text-white font-extrabold text-xs rounded-xl shadow-lg mt-2 cursor-pointer transition-all active:scale-95"
                      >
                        End PK Battle
                      </button>
                    )}
                  </div>
                ) : (
                  /* Setup & Start PK */
                  <div className="space-y-3 text-left">
                    {/* Select Opponent */}
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-slate-300">Choose Opponent Room:</label>
                      <select
                        value={selectedOpponentRoomId}
                        onChange={(e) => setSelectedOpponentRoomId(e.target.value)}
                        className="w-full bg-black/60 text-xs text-white px-3 py-2 rounded-xl border border-white/15 focus:outline-none focus:border-amber-400"
                      >
                        {availableRooms.map((r) => (
                          <option key={r.id} value={r.id}>
                            {r.title} (Host: {r.hostName})
                          </option>
                        ))}
                        {availableRooms.length === 0 && (
                          <option value="demo-opp">Aura PK Battle Arena (Bot Host)</option>
                        )}
                      </select>
                    </div>

                    {/* Duration Select */}
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-slate-300">Match Duration:</label>
                      <div className="grid grid-cols-3 gap-2">
                        {[180, 300, 600].map((sec) => (
                          <button
                            key={sec}
                            type="button"
                            onClick={() => setPkDuration(sec)}
                            className={`py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                              pkDuration === sec
                                ? 'bg-amber-500 text-black font-extrabold shadow'
                                : 'bg-white/10 hover:bg-white/15 text-slate-300'
                            }`}
                          >
                            {sec / 60} Minutes
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Penalty Game */}
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-slate-300">Loser Penalty:</label>
                      <input
                        type="text"
                        value={pkPenalty}
                        onChange={(e) => setPkPenalty(e.target.value)}
                        className="w-full bg-black/60 text-xs text-white px-3 py-2 rounded-xl border border-white/15 focus:outline-none focus:border-amber-400"
                      />
                    </div>

                    {/* Start Battle Trigger */}
                    <button
                      type="button"
                      onClick={handleStartPk}
                      disabled={isStartingPk}
                      className="w-full py-3 bg-gradient-to-r from-red-600 via-orange-500 to-amber-500 hover:from-red-500 text-black font-black text-xs rounded-xl shadow-xl transition-all active:scale-95 disabled:opacity-50 cursor-pointer flex items-center justify-center gap-2"
                    >
                      {isStartingPk ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin" />
                          <span>Challenging Opponent...</span>
                        </>
                      ) : (
                        <>
                          <span>🔥 Start Live 1v1 PK Battle</span>
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>

              {/* PK Match History Table */}
              <div className="space-y-2">
                <h5 className="font-extrabold text-white text-xs uppercase tracking-wider">
                  Recent PK Battles
                </h5>
                <div className="space-y-1.5">
                  {[
                    { opponent: 'Cyber Gaming 🕹️', myScore: 45000, oppScore: 38000, result: 'win', date: 'Yesterday' },
                    { opponent: 'Acoustic Lounge 🎸', myScore: 28000, oppScore: 31000, result: 'loss', date: '3 days ago' },
                  ].map((hist, i) => (
                    <div key={i} className="p-2.5 rounded-xl bg-black/40 border border-white/10 flex items-center justify-between text-xs">
                      <div>
                        <span className="font-bold text-white block">{hist.opponent}</span>
                        <span className="text-[10px] text-slate-400">{hist.myScore.toLocaleString()} vs {hist.oppScore.toLocaleString()} pts • {hist.date}</span>
                      </div>
                      <span className={`px-2 py-0.5 rounded-full font-black text-[10px] ${
                        hist.result === 'win' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                      }`}>
                        {hist.result.toUpperCase()}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  onClose();
                  if (onOpenPkScreen) onOpenPkScreen();
                  else setActiveModal('pk');
                }}
                className="w-full py-2.5 bg-white/10 hover:bg-white/15 text-slate-300 font-bold text-xs rounded-xl transition-colors cursor-pointer text-center"
              >
                View Full PK Leaderboards & Past Wars
              </button>
            </div>
          )}

          {/* ========================================================= */}
          {/* 7. LUCKY BAG PANEL                                        */}
          {/* ========================================================= */}
          {currentTab === 'lucky_bag' && (
            <div className="space-y-4">
              {/* Drop Lucky Bag Card */}
              <div className="p-5 rounded-3xl bg-gradient-to-br from-yellow-950/50 via-black/50 to-amber-950/40 border border-yellow-500/30 backdrop-blur-xl space-y-4 shadow-xl">
                <div className="flex items-center justify-between border-b border-white/10 pb-3">
                  <div className="text-left">
                    <h4 className="font-black text-white text-sm flex items-center gap-1.5">
                      <Gift className="w-4 h-4 text-yellow-400" /> Drop Room Lucky Bag
                    </h4>
                    <p className="text-[11px] text-slate-300">Send free red packets to all guests in the room</p>
                  </div>
                  <span className="text-xs font-bold text-yellow-300 bg-yellow-500/20 px-2 py-0.5 rounded-full border border-yellow-500/30">
                    Host & VIP
                  </span>
                </div>

                {/* Coin Presets */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-300">Select Total Coin Value:</label>
                  <div className="grid grid-cols-4 gap-2">
                    {[100, 500, 1000, 2000].map((amt) => (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => setLuckyBagCoins(amt)}
                        className={`py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                          luckyBagCoins === amt
                            ? 'bg-gradient-to-r from-yellow-400 to-amber-500 text-black font-extrabold shadow-md'
                            : 'bg-white/10 hover:bg-white/15 text-slate-300'
                        }`}
                      >
                        {amt} 🪙
                      </button>
                    ))}
                  </div>
                </div>

                {/* Winners Selector */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-300">Number of Lucky Winners:</label>
                  <div className="grid grid-cols-4 gap-2">
                    {[3, 5, 10, 20].map((num) => (
                      <button
                        key={num}
                        type="button"
                        onClick={() => setLuckyBagWinners(num)}
                        className={`py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                          luckyBagWinners === num
                            ? 'bg-gradient-to-r from-yellow-400 to-amber-500 text-black font-extrabold shadow-md'
                            : 'bg-white/10 hover:bg-white/15 text-slate-300'
                        }`}
                      >
                        {num} People
                      </button>
                    ))}
                  </div>
                </div>

                {/* Drop Trigger Button */}
                <button
                  type="button"
                  onClick={handleDropLuckyBag}
                  disabled={isDroppingBag}
                  className="w-full py-3 bg-gradient-to-r from-amber-400 via-yellow-400 to-orange-500 hover:from-amber-300 hover:to-orange-400 text-black font-black text-sm rounded-2xl shadow-xl transition-all active:scale-95 disabled:opacity-50 cursor-pointer flex items-center justify-center gap-2"
                >
                  {isDroppingBag ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Dropping Packet...</span>
                    </>
                  ) : (
                    <>
                      <span>🎁 Drop {luckyBagCoins} Coins Lucky Bag</span>
                    </>
                  )}
                </button>
              </div>

              {/* Interactive Lucky Bag Grab with Random Reward Animation & Cooldown */}
              <div className="space-y-3 pt-2 border-t border-white/10">
                <h5 className="font-extrabold text-white text-xs uppercase tracking-wider flex items-center justify-between">
                  <span>Interactive Room Lucky Bag</span>
                  <span className="text-[10px] text-amber-400 font-normal">Random Reward & Cooldown</span>
                </h5>
                <LuckyBagComponent
                  bag={activeBags[0]}
                  roomId={currentRoomId}
                  cooldownSeconds={30}
                  onClaimReward={(amt) => {
                    showNotification(`🎉 Claimed +${amt} Coins from Lucky Bag!`);
                    ApiClient.getActiveLuckyBags(currentRoomId).then(bags => setActiveBags(bags)).catch(() => {});
                  }}
                />
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
