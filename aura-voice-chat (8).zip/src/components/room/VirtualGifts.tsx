/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  Gift as GiftIcon, Search, Sparkles, Filter, ArrowUpDown, 
  X, Check, DollarSign, Users, Flame, Crown, Swords, Heart, 
  Shield, Star, Zap, Play, CheckCircle2, ChevronRight, Backpack,
  ShoppingBag, Award, Gem, RefreshCw, Volume2, Mic, Radio
} from 'lucide-react';
import { Gift, VoiceRoom, MicSeat, UserGiftInventoryItem, User } from '../../types';
import { useApp } from '../../context/AppContext';
import { VirtualGiftService } from '../../services/VirtualGiftService';
import { ProfileIdBadge } from '../common/ProfileIdBadge';

export interface SpeakerRecipient {
  id: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  isHost?: boolean;
  seatIndex?: number;
  role?: string;
  uid?: string;
}

export interface VirtualGiftsProps {
  isOpen?: boolean;
  onClose?: () => void;
  room?: VoiceRoom | null;
  speakers?: SpeakerRecipient[];
  selectedSpeakerId?: string | null;
  onGiftSent?: (gift: Gift, count: number, recipientName: string) => void;
  isEmbedded?: boolean;
  className?: string;
}

// Procedural audio chime for celebratory gift sound
const playGiftChime = (rarity: string = 'common') => {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    if (ctx.state === 'suspended') {
      ctx.resume();
    }

    const now = ctx.currentTime;
    const notes = rarity === 'mythic' || rarity === 'legendary' 
      ? [523.25, 659.25, 783.99, 1046.50, 1318.51] // C5, E5, G5, C6, E6
      : rarity === 'epic'
      ? [440, 554.37, 659.25, 880] // A4, C#5, E5, A5
      : [523.25, 659.25, 783.99]; // C5, E5, G5

    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = rarity === 'mythic' ? 'triangle' : 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.08);

      gain.gain.setValueAtTime(0.001, now + idx * 0.08);
      gain.gain.exponentialRampToValueAtTime(0.18, now + idx * 0.08 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.08 + 0.35);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + idx * 0.08);
      osc.stop(now + idx * 0.08 + 0.36);
    });
  } catch {
    // Audio context may not be allowed prior to user interaction
  }
};

export const VirtualGifts: React.FC<VirtualGiftsProps> = ({
  isOpen = true,
  onClose,
  room: propRoom,
  speakers: propSpeakers,
  selectedSpeakerId: propSelectedSpeakerId,
  onGiftSent,
  isEmbedded = false,
  className = ''
}) => {
  const { currentUser, gifts: contextGifts, showNotification, refreshUser, setActiveModal, activeRoom } = useApp();

  const currentRoom = propRoom || activeRoom || null;

  // Catalog store vs Personal Backpack Inventory
  const [activeTab, setActiveTab] = useState<'catalog' | 'backpack'>('catalog');
  const [fetchedGifts, setFetchedGifts] = useState<Gift[]>([]);
  const [isLoadingGifts, setIsLoadingGifts] = useState<boolean>(false);
  const [userBackpack, setUserBackpack] = useState<UserGiftInventoryItem[]>([]);
  const [isLoadingBackpack, setIsLoadingBackpack] = useState<boolean>(false);

  // Search & Filter & Sort state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [sortOrder, setSortOrder] = useState<'popular' | 'price_asc' | 'price_desc' | 'name'>('popular');

  // Selected gift & Multiplier state
  const [selectedGift, setSelectedGift] = useState<Gift | null>(null);
  const [giftCount, setGiftCount] = useState<number>(1);
  const [customCountInput, setCustomCountInput] = useState<string>('');
  const [isSending, setIsSending] = useState<boolean>(false);
  const [sendToAllSpeakers, setSendToAllSpeakers] = useState<boolean>(false);

  // Target speaker recipient state
  const [targetSpeakerId, setTargetSpeakerId] = useState<string>('');

  // Live in-modal preview celebration
  const [previewGift, setPreviewGift] = useState<Gift | null>(null);
  const [celebrationOverlay, setCelebrationOverlay] = useState<{
    gift: Gift;
    count: number;
    recipientName: string;
    senderName: string;
  } | null>(null);

  // Build list of active speakers in the room
  const availableSpeakers: SpeakerRecipient[] = useMemo(() => {
    if (propSpeakers && propSpeakers.length > 0) {
      return propSpeakers;
    }

    const list: SpeakerRecipient[] = [];

    if (currentRoom) {
      // 1. Add Room Host
      if (currentRoom.hostId) {
        list.push({
          id: currentRoom.hostId,
          userId: currentRoom.hostId,
          userName: currentRoom.hostName || 'Room Host',
          userAvatar: (currentRoom as any).hostAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
          isHost: true,
          seatIndex: 0,
          role: 'Host 👑',
          uid: (currentRoom as any).hostUid
        });
      }

      // 2. Add Seated mic speakers
      if (Array.isArray(currentRoom.seats)) {
        currentRoom.seats.forEach((seat) => {
          if (seat.userId && seat.userId !== currentRoom.hostId) {
            list.push({
              id: seat.userId,
              userId: seat.userId,
              userName: seat.userName || `Seat #${seat.index + 1}`,
              userAvatar: seat.userAvatar,
              isHost: false,
              seatIndex: seat.index,
              role: `Mic #${seat.index + 1} 🎙️`,
              uid: (seat as any).userUid
            });
          }
        });
      }
    }

    // Default fallback speaker if room has no seated users yet
    if (list.length === 0) {
      list.push({
        id: 'host-default',
        userId: '2383452',
        userName: currentRoom?.hostName || 'Room Host',
        userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
        isHost: true,
        seatIndex: 0,
        role: 'Host 👑'
      });
    }

    return list;
  }, [propSpeakers, currentRoom]);

  // Synchronize target speaker when speakers or propSelectedSpeakerId changes
  useEffect(() => {
    if (propSelectedSpeakerId) {
      setTargetSpeakerId(propSelectedSpeakerId);
    } else if (availableSpeakers.length > 0 && !targetSpeakerId) {
      setTargetSpeakerId(availableSpeakers[0].userId);
    }
  }, [propSelectedSpeakerId, availableSpeakers]);

  // Fetch gifts catalog from API/Service
  const loadGiftsCatalog = async () => {
    setIsLoadingGifts(true);
    try {
      const data = await VirtualGiftService.getGiftCatalog({
        category: selectedCategory === 'all' ? undefined : selectedCategory,
        sortBy: sortOrder
      });
      if (Array.isArray(data) && data.length > 0) {
        setFetchedGifts(data);
        if (!selectedGift) {
          setSelectedGift(data[0]);
        }
      } else if (contextGifts && contextGifts.length > 0) {
        setFetchedGifts(contextGifts);
        if (!selectedGift) {
          setSelectedGift(contextGifts[0]);
        }
      }
    } catch (err) {
      console.warn('Failed to load gifts catalog from API, falling back to context gifts:', err);
      if (contextGifts && contextGifts.length > 0) {
        setFetchedGifts(contextGifts);
        if (!selectedGift) setSelectedGift(contextGifts[0]);
      }
    } finally {
      setIsLoadingGifts(false);
    }
  };

  // Fetch backpack inventory
  const loadBackpack = async () => {
    setIsLoadingBackpack(true);
    try {
      const items = await VirtualGiftService.getUserBackpack();
      setUserBackpack(items || []);
    } catch (err) {
      console.warn('Failed to load backpack inventory:', err);
    } finally {
      setIsLoadingBackpack(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadGiftsCatalog();
      loadBackpack();
    }
  }, [isOpen, selectedCategory, sortOrder]);

  // Fallback gifts if list is still empty
  const activeGiftsList: Gift[] = useMemo(() => {
    const source = fetchedGifts.length > 0 ? fetchedGifts : (contextGifts && contextGifts.length > 0 ? contextGifts : []);
    if (source.length > 0) return source;

    return [
      { id: 'gft-1', name: 'Rose Romance 🌹', icon: '🌹', priceCoins: 10, category: 'popular', animationType: 'pop', svgColor: '#f43f5e', rarity: 'common' },
      { id: 'gft-2', name: 'Lucky Clover 🍀', icon: '🍀', priceCoins: 50, category: 'popular', animationType: 'pop', svgColor: '#10b981', rarity: 'common' },
      { id: 'gft-3', name: 'Love Diamond Ring 💍', icon: '💍', priceCoins: 520, category: 'luxury', animationType: 'pop', svgColor: '#ec4899', rarity: 'rare' },
      { id: 'gft-4', name: 'Super Sports Car 🏎️', icon: '🏎️', priceCoins: 2000, category: 'luxury', animationType: 'fullscreen', svgColor: '#ef4444', rarity: 'epic' },
      { id: 'gft-5', name: 'Cosmic Rocket 🚀', icon: '🚀', priceCoins: 5000, category: 'special', animationType: 'fullscreen', svgColor: '#3b82f6', rarity: 'legendary' },
      { id: 'gft-6', name: 'Aura Castle 🏰', icon: '🏰', priceCoins: 15000, category: 'special', animationType: 'fullscreen', svgColor: '#a855f7', rarity: 'mythic' },
      { id: 'gft-9', name: 'PK Hammer 🔨', icon: '🔨', priceCoins: 200, category: 'pk', animationType: 'pop', svgColor: '#ef4444', rarity: 'common' },
      { id: 'gft-10', name: 'Victory Trophy 🏆', icon: '🏆', priceCoins: 800, category: 'pk', animationType: 'banner', svgColor: '#f59e0b', rarity: 'rare' },
      { id: 'gft-11', name: 'Family Shield 🛡️', icon: '🛡️', priceCoins: 300, category: 'family', animationType: 'pop', svgColor: '#3b82f6', rarity: 'rare' }
    ];
  }, [fetchedGifts, contextGifts]);

  // Categories list
  const categories = [
    { id: 'all', label: 'All Gifts', icon: '🎁' },
    { id: 'popular', label: 'Popular', icon: '🔥' },
    { id: 'luxury', label: 'Luxury', icon: '💎' },
    { id: 'pk', label: 'PK Battles', icon: '⚔️' },
    { id: 'family', label: 'Family Guild', icon: '🛡️' },
    { id: 'special', label: 'Special & VIP', icon: '👑' }
  ];

  // Multipliers list with cultural meanings
  const multipliers = [
    { count: 1, label: 'x1', desc: 'Single' },
    { count: 5, label: 'x5', desc: 'High 5' },
    { count: 10, label: 'x10', desc: 'Perfect' },
    { count: 52, label: 'x52', desc: 'Love' },
    { count: 99, label: 'x99', desc: 'Forever' },
    { count: 520, label: 'x520', desc: 'Eternal' },
    { count: 1314, label: 'x1314', desc: 'Lifetime' }
  ];

  // Filtered and Sorted Gifts
  const processedGifts = useMemo(() => {
    let result = [...activeGiftsList];

    if (selectedCategory !== 'all') {
      result = result.filter(g => g.category === selectedCategory);
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(g => 
        g.name.toLowerCase().includes(q) || 
        (g.tags && g.tags.some(t => t.toLowerCase().includes(q)))
      );
    }

    if (sortOrder === 'price_asc') {
      result.sort((a, b) => a.priceCoins - b.priceCoins);
    } else if (sortOrder === 'price_desc') {
      result.sort((a, b) => b.priceCoins - a.priceCoins);
    } else if (sortOrder === 'name') {
      result.sort((a, b) => a.name.localeCompare(b.name));
    }

    return result;
  }, [activeGiftsList, selectedCategory, searchQuery, sortOrder]);

  // Computations for Sending
  const currentMultiplier = customCountInput ? parseInt(customCountInput, 10) || 1 : giftCount;
  const numRecipients = sendToAllSpeakers ? Math.max(1, availableSpeakers.length) : 1;
  const totalCoinCost = (selectedGift ? selectedGift.priceCoins : 0) * currentMultiplier * numRecipients;
  const userCoins = currentUser?.coins || 0;
  const hasEnoughCoins = userCoins >= totalCoinCost;

  const isBackpack = activeTab === 'backpack';
  const ownedBackpackItem = isBackpack && selectedGift ? userBackpack.find(b => b.giftId === selectedGift.id) : null;
  const ownedBackpackQty = ownedBackpackItem ? ownedBackpackItem.quantity : 0;
  const neededBackpackQty = currentMultiplier * numRecipients;
  const hasEnoughBackpack = isBackpack ? ownedBackpackQty >= neededBackpackQty : true;
  const canSend = selectedGift && (isBackpack ? hasEnoughBackpack : hasEnoughCoins);

  // Active targeted speaker object
  const activeTargetSpeaker = useMemo(() => {
    return availableSpeakers.find(s => s.userId === targetSpeakerId) || availableSpeakers[0];
  }, [availableSpeakers, targetSpeakerId]);

  // Handle Sending Gift to Speaker(s)
  const handleSendGift = async () => {
    if (!selectedGift || !currentUser) {
      showNotification('⚠️ Please select a virtual gift to send.');
      return;
    }

    if (isBackpack) {
      if (!hasEnoughBackpack) {
        showNotification(`⚠️ Insufficient backpack quantity! Needed: ${neededBackpackQty}, Owned: ${ownedBackpackQty}`);
        return;
      }
    } else {
      if (!hasEnoughCoins) {
        showNotification(`⚠️ Insufficient coins! Required: ${totalCoinCost.toLocaleString()} Coins (Balance: ${userCoins.toLocaleString()})`);
        return;
      }
    }

    setIsSending(true);
    try {
      // Play audio chime
      playGiftChime(selectedGift.rarity);

      if (sendToAllSpeakers) {
        // Broadcast gift to every speaker on stage
        for (const speaker of availableSpeakers) {
          await VirtualGiftService.sendGift({
            senderId: currentUser.id,
            receiverId: speaker.userId,
            giftId: selectedGift.id,
            count: currentMultiplier,
            roomId: currentRoom?.id,
            deductFromInventory: isBackpack
          });
        }

        const totalSent = currentMultiplier * availableSpeakers.length;
        showNotification(`🎉 Sent ${currentMultiplier}x ${selectedGift.name} to all ${availableSpeakers.length} speakers!`);
        
        // Trigger live celebration overlay
        setCelebrationOverlay({
          gift: selectedGift,
          count: totalSent,
          recipientName: 'All Stage Speakers',
          senderName: currentUser.name || 'You'
        });

        if (onGiftSent) {
          onGiftSent(selectedGift, totalSent, 'All Stage Speakers');
        }
      } else {
        const target = activeTargetSpeaker;
        const res = await VirtualGiftService.sendGift({
          senderId: currentUser.id,
          receiverId: target.userId,
          giftId: selectedGift.id,
          count: currentMultiplier,
          roomId: currentRoom?.id,
          deductFromInventory: isBackpack
        });

        const diamondInfo = res.diamondsAwarded ? ` (+${res.diamondsAwarded} 💎 earned by speaker)` : '';
        const pkInfo = res.pkScoreBoosted ? ' ⚔️ PK Battle score boosted!' : '';
        showNotification(`🎁 Sent ${currentMultiplier}x ${selectedGift.name} to ${target.userName}!${diamondInfo}${pkInfo}`);

        // Trigger live celebration overlay
        setCelebrationOverlay({
          gift: selectedGift,
          count: currentMultiplier,
          recipientName: target.userName,
          senderName: currentUser.name || 'You'
        });

        if (onGiftSent) {
          onGiftSent(selectedGift, currentMultiplier, target.userName);
        }
      }

      await refreshUser();
      loadBackpack();

      // Dismiss celebration overlay after 3.2 seconds
      setTimeout(() => {
        setCelebrationOverlay(null);
      }, 3200);

    } catch (err: any) {
      showNotification(`⛔ ${err.message || 'Failed to send gift. Please check your balance.'}`);
    } finally {
      setIsSending(false);
    }
  };

  // Trigger preview animation
  const handlePreviewGift = (g: Gift, e: React.MouseEvent) => {
    e.stopPropagation();
    setPreviewGift(g);
    playGiftChime(g.rarity);
  };

  // If used as modal and closed, return null AFTER all hooks
  if (!isOpen && !isEmbedded) return null;

  return (
    <>
      <div 
        className={isEmbedded ? className : "fixed inset-0 z-[80] bg-black/85 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fadeIn"}
        onClick={isEmbedded ? undefined : (e) => {
          if (e.target === e.currentTarget && onClose) onClose();
        }}
      >
        <div 
          className={`bg-[#120824]/95 backdrop-blur-2xl border-t sm:border border-white/20 rounded-t-3xl sm:rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] sm:max-h-[88vh] animate-slideUp text-slate-100 ${isEmbedded ? className : ''}`}
          onClick={(e) => e.stopPropagation()}
        >
          {/* 1. MODAL HEADER BAR */}
          <div className="p-4 border-b border-white/10 flex items-center justify-between bg-white/[0.04]">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-400 via-pink-500 to-purple-600 flex items-center justify-center text-xl shadow-lg border border-white/20">
                🎁
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-black text-white tracking-wide">Virtual Gifts</h3>
                  <span className="bg-gradient-to-r from-amber-500 to-pink-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full uppercase shadow">
                    Animated
                  </span>
                </div>
                <p className="text-[11px] text-slate-300">
                  Send animated gifts to stage speakers & boost their diamond ranking!
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              {/* COIN WALLET SHORTCUT */}
              <button 
                type="button"
                onClick={() => setActiveModal('wallet')}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gradient-to-r from-amber-500/20 to-yellow-500/20 border border-amber-400/40 text-amber-300 text-xs font-black shadow hover:brightness-110 active:scale-95 transition-all cursor-pointer"
                title="Recharge Coins"
              >
                <span className="text-sm">🪙</span>
                <span>{userCoins.toLocaleString()}</span>
                <span className="text-[10px] bg-amber-400 text-black px-1.5 rounded font-black">+</span>
              </button>

              {onClose && (
                <button
                  type="button"
                  onClick={onClose}
                  className="p-2 rounded-xl bg-white/5 hover:bg-white/15 text-slate-400 hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              )}
            </div>
          </div>

          {/* 2. SPEAKER RECIPIENT SELECTOR BAR (STAGE SPEAKERS) */}
          <div className="p-3 bg-gradient-to-r from-purple-950/60 via-slate-900 to-pink-950/60 border-b border-white/10">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-black uppercase tracking-wider text-purple-300 flex items-center gap-1.5">
                <Mic className="w-3 h-3 text-pink-400" />
                <span>Select Target Speaker:</span>
              </span>

              {/* Toggle "Send to All Speakers" */}
              <button
                type="button"
                onClick={() => setSendToAllSpeakers(!sendToAllSpeakers)}
                className={`text-[10px] font-black px-2.5 py-1 rounded-full border transition-all flex items-center gap-1 cursor-pointer ${
                  sendToAllSpeakers
                    ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white border-pink-400 shadow-md shadow-pink-500/30'
                    : 'bg-white/5 text-slate-300 border-white/10 hover:bg-white/10'
                }`}
              >
                <Users className="w-3 h-3" />
                <span>All Speakers ({availableSpeakers.length})</span>
                {sendToAllSpeakers && <Check className="w-2.5 h-2.5" />}
              </button>
            </div>

            {/* Speaker Avatars Horizontal Carousel */}
            <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
              {availableSpeakers.map((speaker) => {
                const isSelected = !sendToAllSpeakers && targetSpeakerId === speaker.userId;

                return (
                  <button
                    key={speaker.id}
                    type="button"
                    onClick={() => {
                      setSendToAllSpeakers(false);
                      setTargetSpeakerId(speaker.userId);
                    }}
                    className={`flex items-center gap-2 px-2.5 py-1.5 rounded-2xl border transition-all shrink-0 cursor-pointer text-left ${
                      isSelected
                        ? 'bg-gradient-to-r from-purple-600/40 to-pink-600/40 border-pink-400 shadow-[0_0_15px_rgba(236,72,153,0.35)] scale-105'
                        : sendToAllSpeakers
                        ? 'bg-pink-500/10 border-pink-500/30 opacity-90'
                        : 'bg-white/[0.04] border-white/10 hover:bg-white/[0.08] text-slate-300'
                    }`}
                  >
                    <div className="relative">
                      {speaker.userAvatar ? (
                        <img 
                          src={speaker.userAvatar} 
                          alt={speaker.userName} 
                          className={`w-7 h-7 rounded-full object-cover border ${
                            isSelected ? 'border-amber-400' : 'border-white/20'
                          }`} 
                        />
                      ) : (
                        <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-purple-500 to-indigo-600 flex items-center justify-center text-xs font-bold text-white border border-white/20">
                          {speaker.userName.charAt(0)}
                        </div>
                      )}
                      {speaker.isHost && (
                        <span className="absolute -top-1 -right-1 text-[10px]">👑</span>
                      )}
                    </div>

                    <div className="min-w-0 pr-1">
                      <p className="text-[11px] font-black text-white truncate max-w-[85px]">
                        {speaker.userName}
                      </p>
                      <p className="text-[9px] text-pink-300 font-mono">
                        {speaker.role}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 3. TABS BAR: CATALOG VS BACKPACK INVENTORY */}
          <div className="flex items-center justify-between px-4 pt-3 pb-2 border-b border-white/10 bg-white/[0.02]">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setActiveTab('catalog')}
                className={`px-3 py-1.5 rounded-xl font-black text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                  activeTab === 'catalog'
                    ? 'bg-gradient-to-r from-amber-500 to-pink-500 text-white shadow-md'
                    : 'bg-white/5 text-slate-400 hover:text-white'
                }`}
              >
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>Gift Store</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('backpack')}
                className={`px-3 py-1.5 rounded-xl font-black text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                  activeTab === 'backpack'
                    ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md'
                    : 'bg-white/5 text-slate-400 hover:text-white'
                }`}
              >
                <Backpack className="w-3.5 h-3.5" />
                <span>My Backpack</span>
                {userBackpack.length > 0 && (
                  <span className="w-4 h-4 rounded-full bg-pink-500 text-white text-[9px] flex items-center justify-center font-bold">
                    {userBackpack.length}
                  </span>
                )}
              </button>
            </div>

            {/* Refresh catalog button */}
            <button
              type="button"
              onClick={loadGiftsCatalog}
              disabled={isLoadingGifts}
              className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
              title="Refresh gifts"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoadingGifts ? 'animate-spin' : ''}`} />
            </button>
          </div>

          {/* 4. CATEGORIES & SEARCH BAR (FOR CATALOG) */}
          {activeTab === 'catalog' && (
            <div className="p-3 border-b border-white/10 bg-black/20 space-y-2">
              <div className="flex items-center gap-2">
                {/* Search Input */}
                <div className="relative flex-1">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Search animated gifts by name or tags..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-amber-400"
                  />
                  {searchQuery && (
                    <button
                      type="button"
                      onClick={() => setSearchQuery('')}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs"
                    >
                      ×
                    </button>
                  )}
                </div>

                {/* Sort Order Selector */}
                <select
                  value={sortOrder}
                  onChange={(e) => setSortOrder(e.target.value as any)}
                  className="bg-white/5 border border-white/10 rounded-xl px-2.5 py-1.5 text-xs text-slate-300 focus:outline-none focus:border-amber-400 cursor-pointer"
                >
                  <option value="popular" className="bg-slate-900 text-white">Popular 🔥</option>
                  <option value="price_asc" className="bg-slate-900 text-white">Coins: Low to High ⬆️</option>
                  <option value="price_desc" className="bg-slate-900 text-white">Coins: High to Low ⬇️</option>
                  <option value="name" className="bg-slate-900 text-white">Name A-Z 🔤</option>
                </select>
              </div>

              {/* Category Pills */}
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
                {categories.map(cat => (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setSelectedCategory(cat.id)}
                    className={`px-2.5 py-1 rounded-full text-[11px] font-black whitespace-nowrap transition-all flex items-center gap-1 cursor-pointer shrink-0 ${
                      selectedCategory === cat.id
                        ? 'bg-amber-400 text-black shadow-md shadow-amber-400/20'
                        : 'bg-white/5 text-slate-400 hover:bg-white/10 hover:text-slate-200'
                    }`}
                  >
                    <span>{cat.icon}</span>
                    <span>{cat.label}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* 5. GIFTS GRID (ANIMATED GIFT ASSETS) */}
          <div className="flex-1 overflow-y-auto p-3 sm:p-4 min-h-[220px] max-h-[340px]">
            {activeTab === 'catalog' ? (
              processedGifts.length === 0 ? (
                <div className="py-12 text-center text-slate-400 text-xs space-y-2">
                  <span className="text-3xl">🎁</span>
                  <p className="font-bold">No virtual gifts match your search.</p>
                  <button
                    type="button"
                    onClick={() => { setSearchQuery(''); setSelectedCategory('all'); }}
                    className="text-amber-400 underline font-semibold"
                  >
                    Clear filters
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2.5">
                  {processedGifts.map((gift) => {
                    const isSelected = selectedGift?.id === gift.id;
                    const rarityColors: Record<string, string> = {
                      common: 'border-slate-500/30 bg-slate-900/60',
                      rare: 'border-blue-500/40 bg-blue-950/40 shadow-blue-500/20',
                      epic: 'border-purple-500/50 bg-purple-950/40 shadow-purple-500/30',
                      legendary: 'border-amber-500/60 bg-amber-950/40 shadow-amber-500/30',
                      mythic: 'border-rose-500/70 bg-gradient-to-br from-rose-950/50 to-purple-950/50 shadow-rose-500/40'
                    };

                    return (
                      <div
                        key={gift.id}
                        onClick={() => setSelectedGift(gift)}
                        className={`relative rounded-2xl p-2.5 flex flex-col items-center justify-between text-center transition-all duration-200 cursor-pointer border group select-none ${
                          isSelected
                            ? 'ring-2 ring-pink-500 border-transparent bg-gradient-to-b from-purple-900/80 to-pink-900/60 shadow-[0_0_20px_rgba(236,72,153,0.4)] scale-[1.03]'
                            : `${rarityColors[gift.rarity || 'common']} hover:bg-white/10 hover:border-white/20`
                        }`}
                      >
                        {/* Rarity & Animation Badge */}
                        <div className="w-full flex items-center justify-between gap-1 mb-1">
                          <span className={`text-[8px] font-black uppercase px-1.5 py-0.2 rounded-full ${
                            gift.rarity === 'mythic' ? 'bg-rose-500 text-white animate-pulse' :
                            gift.rarity === 'legendary' ? 'bg-amber-400 text-black' :
                            gift.rarity === 'epic' ? 'bg-purple-500 text-white' :
                            gift.rarity === 'rare' ? 'bg-blue-500 text-white' :
                            'bg-slate-700 text-slate-300'
                          }`}>
                            {gift.rarity || 'GIFT'}
                          </span>

                          {/* Animation Type Chip */}
                          <span className="text-[8px] text-pink-300 font-mono">
                            {gift.animationType === 'fullscreen' ? '🌌 3D' : gift.animationType === 'banner' ? '🏆 Live' : '✨ Pop'}
                          </span>
                        </div>

                        {/* Animated Gift Icon Asset */}
                        <div className="relative my-1 py-1">
                          <div 
                            className={`w-14 h-14 rounded-2xl flex items-center justify-center text-3xl transition-transform duration-300 group-hover:scale-115 ${
                              isSelected ? 'animate-bounce' : 'group-hover:rotate-6'
                            }`}
                            style={{ 
                              background: `radial-gradient(circle, ${gift.svgColor || '#f43f5e'}25 0%, transparent 70%)` 
                            }}
                          >
                            {gift.icon}
                          </div>

                          {/* Live Preview Button */}
                          <button
                            type="button"
                            onClick={(e) => handlePreviewGift(gift, e)}
                            className="absolute -bottom-1 -right-1 p-1 rounded-full bg-black/80 hover:bg-pink-500 text-slate-300 hover:text-white border border-white/20 shadow transition-all cursor-pointer opacity-80 group-hover:opacity-100"
                            title="Preview animated effect"
                          >
                            <Play className="w-2.5 h-2.5 fill-current" />
                          </button>
                        </div>

                        {/* Gift Title */}
                        <p className="text-[11px] font-black text-white truncate w-full px-0.5 mt-1">
                          {gift.name}
                        </p>

                        {/* Price Tag */}
                        <div className="flex items-center justify-center gap-1 mt-1 text-[11px] font-bold text-amber-300">
                          <span className="text-xs">🪙</span>
                          <span>{gift.priceCoins.toLocaleString()}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )
            ) : (
              /* MY BACKPACK INVENTORY TAB */
              userBackpack.length === 0 ? (
                <div className="py-12 text-center text-slate-400 text-xs space-y-3">
                  <Backpack className="w-10 h-10 text-purple-400/60 mx-auto" />
                  <p className="font-bold text-white text-sm">Your Backpack is Empty</p>
                  <p className="text-[11px] text-slate-400 max-w-xs mx-auto">
                    Spin the Daily Lucky Wheel, claim Lucky Bags in live rooms, or level up to get free virtual gift items!
                  </p>
                  <button
                    type="button"
                    onClick={() => setActiveTab('catalog')}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-pink-500 text-white font-black text-xs shadow-md cursor-pointer"
                  >
                    Browse Gift Store 🎁
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2.5">
                  {userBackpack.map((item) => {
                    const gift = item.gift || activeGiftsList.find(g => g.id === item.giftId) || {
                      id: item.giftId,
                      name: 'Mystery Gift',
                      icon: '🎁',
                      priceCoins: 0,
                      category: 'special',
                      animationType: 'pop',
                      svgColor: '#a855f7'
                    };
                    const isSelected = selectedGift?.id === gift.id;

                    return (
                      <div
                        key={item.id}
                        onClick={() => setSelectedGift(gift as Gift)}
                        className={`relative rounded-2xl p-2.5 flex flex-col items-center justify-between text-center transition-all duration-200 cursor-pointer border select-none ${
                          isSelected
                            ? 'ring-2 ring-purple-500 border-transparent bg-gradient-to-b from-purple-900/80 to-indigo-900/60 shadow-[0_0_20px_rgba(168,85,247,0.4)] scale-[1.03]'
                            : 'border-white/10 bg-slate-900/60 hover:bg-white/10'
                        }`}
                      >
                        {/* Owned Quantity Badge */}
                        <div className="w-full flex items-center justify-between">
                          <span className="text-[9px] bg-purple-500/80 text-white font-black px-1.5 py-0.2 rounded-full">
                            x{item.quantity} OWNED
                          </span>
                        </div>

                        {/* Gift Icon */}
                        <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-3xl my-1 animate-pulse">
                          {gift.icon}
                        </div>

                        <p className="text-[11px] font-black text-white truncate w-full">
                          {gift.name}
                        </p>

                        <div className="text-[10px] text-emerald-400 font-bold mt-1">
                          FREE (Backpack)
                        </div>
                      </div>
                    );
                  })}
                </div>
              )
            )}
          </div>

          {/* 6. BOTTOM ACTION FOOTER: MULTIPLIERS, TOTAL COINS & SEND BUTTON */}
          <div className="p-3 sm:p-4 border-t border-white/10 bg-slate-950/80 backdrop-blur-xl flex flex-col gap-3">
            {/* Multiplier Presets & Custom Input */}
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
                {multipliers.map((m) => (
                  <button
                    key={m.count}
                    type="button"
                    onClick={() => {
                      setGiftCount(m.count);
                      setCustomCountInput('');
                    }}
                    className={`px-2.5 py-1 rounded-xl text-xs font-black transition-all cursor-pointer ${
                      giftCount === m.count && !customCountInput
                        ? 'bg-gradient-to-r from-amber-400 to-pink-500 text-black shadow-md font-extrabold'
                        : 'bg-white/5 hover:bg-white/15 text-slate-300 border border-white/10'
                    }`}
                    title={m.desc}
                  >
                    <span>{m.label}</span>
                  </button>
                ))}
              </div>

              {/* Custom Count Input */}
              <div className="flex items-center gap-1 bg-white/5 border border-white/10 rounded-xl px-2 py-1">
                <span className="text-[11px] text-slate-400 font-bold">Qty:</span>
                <input
                  type="number"
                  min="1"
                  max="9999"
                  placeholder="Custom"
                  value={customCountInput}
                  onChange={(e) => setCustomCountInput(e.target.value)}
                  className="w-16 bg-transparent text-xs text-white font-bold text-center focus:outline-none"
                />
              </div>
            </div>

            {/* Price Summary & Primary Send Button */}
            <div className="flex items-center justify-between gap-4">
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs text-slate-300">Total:</span>
                  {isBackpack ? (
                    <span className="text-sm font-black text-emerald-400">
                      {neededBackpackQty}x items from Backpack
                    </span>
                  ) : (
                    <div className="flex items-center gap-1">
                      <span className="text-sm">🪙</span>
                      <span className="text-base font-black text-amber-300">
                        {totalCoinCost.toLocaleString()}
                      </span>
                    </div>
                  )}
                </div>

                <p className="text-[10px] text-slate-400 truncate">
                  To:{' '}
                  <span className="text-pink-300 font-bold">
                    {sendToAllSpeakers ? `All ${availableSpeakers.length} Speakers` : activeTargetSpeaker?.userName}
                  </span>
                  {selectedGift && (
                    <>
                      {' '}• <span className="text-amber-400">{selectedGift.name}</span> (x{currentMultiplier})
                    </>
                  )}
                </p>
              </div>

              {/* Primary Action Button */}
              <button
                type="button"
                id="btn-virtual-gifts-send"
                onClick={handleSendGift}
                disabled={!canSend || isSending}
                className={`px-6 sm:px-8 py-3 rounded-2xl font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-xl transition-all duration-200 active:scale-95 cursor-pointer ${
                  canSend
                    ? 'bg-gradient-to-r from-amber-400 via-pink-500 to-purple-600 hover:brightness-110 text-white shadow-pink-500/25'
                    : 'bg-white/10 text-slate-500 cursor-not-allowed border border-white/5'
                }`}
              >
                {isSending ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-white" />
                    <span>Sending...</span>
                  </>
                ) : !hasEnoughCoins && !isBackpack ? (
                  <>
                    <span>Recharge Coins 💰</span>
                  </>
                ) : (
                  <>
                    <span>Send Gift</span>
                    <span>🚀</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 7. LIVE CELEBRATION ANIMATION OVERLAY (TRIGGERED UPON SENDING) */}
      {celebrationOverlay && (
        <div className="fixed inset-0 z-[100] pointer-events-none flex items-center justify-center bg-black/60 backdrop-blur-sm animate-fadeIn">
          <div className="flex flex-col items-center text-center space-y-4 animate-bounce p-4">
            <div className="relative">
              <div 
                className="w-36 h-36 rounded-full flex items-center justify-center text-7xl shadow-[0_0_60px_#ec4899] border-4 border-white animate-spin"
                style={{ 
                  background: 'linear-gradient(135deg, #f59e0b, #ec4899, #8b5cf6)',
                  animationDuration: '6s'
                }}
              >
                {celebrationOverlay.gift.icon}
              </div>
              <span className="absolute -top-2 -right-2 px-3 py-1 rounded-full bg-amber-400 text-black font-black text-sm shadow-xl border border-white">
                x{celebrationOverlay.count}
              </span>
            </div>

            <div className="bg-gradient-to-r from-purple-900/90 via-pink-900/90 to-amber-900/90 px-8 py-4 rounded-3xl border-2 border-amber-400 shadow-2xl backdrop-blur-md">
              <h2 className="text-xl sm:text-2xl font-black text-amber-300 drop-shadow-md">
                {celebrationOverlay.senderName} sent {celebrationOverlay.gift.name}!
              </h2>
              <p className="text-sm font-bold text-white mt-1 flex items-center justify-center gap-1.5">
                <span>🎙️ Speaker:</span>
                <span className="text-pink-300 font-black">{celebrationOverlay.recipientName}</span>
              </p>
              <p className="text-[11px] text-amber-200 mt-1 font-mono">
                💎 Diamonds awarded to speaker • Level up!
              </p>
            </div>
          </div>
        </div>
      )}

      {/* 8. PREVIEW MODAL FOR 3D ANIMATION EFFECTS */}
      {previewGift && (
        <div 
          className="fixed inset-0 z-[110] bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn"
          onClick={() => setPreviewGift(null)}
        >
          <div 
            className="bg-[#170a2f] border border-amber-400/40 rounded-3xl p-6 max-w-sm w-full text-center space-y-4 shadow-2xl animate-scaleUp"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-black uppercase text-amber-400 tracking-wider">
                Animation Preview
              </span>
              <button
                type="button"
                onClick={() => setPreviewGift(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="w-28 h-28 mx-auto rounded-3xl bg-gradient-to-tr from-purple-600 via-pink-500 to-amber-400 flex items-center justify-center text-6xl shadow-[0_0_40px_rgba(244,63,94,0.6)] animate-pulse">
              {previewGift.icon}
            </div>

            <div>
              <h4 className="text-lg font-black text-white">{previewGift.name}</h4>
              <p className="text-xs text-slate-300 mt-1">
                {previewGift.description || 'Stunning animated 3D visual effect broadcasting across the voice room.'}
              </p>
              <div className="flex items-center justify-center gap-2 mt-3 text-xs font-bold text-amber-300">
                <span>Price: 🪙 {previewGift.priceCoins.toLocaleString()}</span>
                <span>•</span>
                <span className="uppercase text-pink-400">{previewGift.rarity || 'RARE'}</span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                setSelectedGift(previewGift);
                setPreviewGift(null);
              }}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-pink-500 text-black font-black text-xs hover:brightness-110 shadow-lg cursor-pointer"
            >
              Select This Gift 🎁
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default VirtualGifts;
