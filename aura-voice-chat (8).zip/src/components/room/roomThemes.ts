/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface RoomThemeConfig {
  id: string;
  name: string;
  category: 'Night Mode' | 'Party' | 'Chill' | 'Cyberpunk' | 'Romantic' | 'Aurora' | 'Luxury' | 'Classic';
  subtitle: string;
  description: string;
  icon: string;
  gradientClass: string;
  radialEffect: string;
  ambientLightColor: string;
  accentColor: string;
  glowColor: string;
  badgeClass: string;
  borderClass: string;
  bgImage: string;
  hasParticles?: boolean;
  particleType?: 'stars' | 'confetti' | 'ember' | 'aurora' | 'gold_dust' | 'pulse';
}

export const ROOM_THEMES: RoomThemeConfig[] = [
  {
    id: 'night',
    name: 'Night Mode',
    category: 'Night Mode',
    subtitle: 'Cosmic midnight sky, starfield glow & cyber nebula',
    description: 'Deep starlight ambience designed for late-night talk shows, deep conversations, and peaceful chill sessions.',
    icon: '🌙',
    gradientClass: 'from-[#070b1a] via-[#0d152f] to-[#050814]',
    radialEffect: 'radial-gradient(circle at 50% 20%, rgba(79, 70, 229, 0.28), transparent 70%), radial-gradient(circle at 85% 65%, rgba(56, 189, 248, 0.15), transparent 60%)',
    ambientLightColor: 'rgba(99, 102, 241, 0.25)',
    accentColor: '#818cf8',
    glowColor: 'rgba(99, 102, 241, 0.35)',
    badgeClass: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40',
    borderClass: 'border-indigo-500/40 hover:border-indigo-400',
    bgImage: 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?auto=format&fit=crop&w=1200&q=80',
    hasParticles: true,
    particleType: 'stars'
  },
  {
    id: 'party',
    name: 'Party Mode',
    category: 'Party',
    subtitle: 'Pulsing neon club lasers, magenta waves & rave disco',
    description: 'Electrifying neon pink and violet vibes with pulsing club lighting, perfect for DJ sets, celebrations, and singing contests.',
    icon: '🪩',
    gradientClass: 'from-[#1c002c] via-[#2c0038] to-[#10001a]',
    radialEffect: 'radial-gradient(circle at 20% 30%, rgba(236, 72, 153, 0.35), transparent 60%), radial-gradient(circle at 80% 70%, rgba(168, 85, 247, 0.35), transparent 60%)',
    ambientLightColor: 'rgba(236, 72, 153, 0.3)',
    accentColor: '#f43f5e',
    glowColor: 'rgba(236, 72, 153, 0.45)',
    badgeClass: 'bg-pink-500/20 text-pink-300 border-pink-500/40',
    borderClass: 'border-pink-500/40 hover:border-pink-400',
    bgImage: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?auto=format&fit=crop&w=1200&q=80',
    hasParticles: true,
    particleType: 'pulse'
  },
  {
    id: 'chill',
    name: 'Chill Lounge',
    category: 'Chill',
    subtitle: 'Warm golden hour sunset, lofi coffee shop & acoustic vibes',
    description: 'Warm amber tones and soothing sunset hues, crafted for relaxed guitar jamming, study groups, and cozy heart-to-hearts.',
    icon: '☕',
    gradientClass: 'from-[#1c0c05] via-[#2d140a] to-[#120603]',
    radialEffect: 'radial-gradient(circle at 50% 25%, rgba(245, 158, 11, 0.28), transparent 65%), radial-gradient(circle at 20% 80%, rgba(239, 68, 68, 0.18), transparent 70%)',
    ambientLightColor: 'rgba(245, 158, 11, 0.25)',
    accentColor: '#fbbf24',
    glowColor: 'rgba(245, 158, 11, 0.35)',
    badgeClass: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
    borderClass: 'border-amber-500/40 hover:border-amber-400',
    bgImage: 'https://images.unsplash.com/photo-1518495973542-4542c06a5843?auto=format&fit=crop&w=1200&q=80',
    hasParticles: true,
    particleType: 'ember'
  },
  {
    id: 'cyberpunk',
    name: 'Cyberpunk Neon',
    category: 'Cyberpunk',
    subtitle: 'Futuristic Neo-Tokyo skyline, holographic grids & high energy',
    description: 'High-tech cyan and futuristic electro radiance built for gaming marathons, tech banter, and futuristic aesthetics.',
    icon: '⚡',
    gradientClass: 'from-[#031321] via-[#062035] to-[#020a12]',
    radialEffect: 'radial-gradient(circle at 30% 20%, rgba(6, 182, 212, 0.32), transparent 60%), radial-gradient(circle at 75% 75%, rgba(16, 185, 129, 0.25), transparent 60%)',
    ambientLightColor: 'rgba(6, 182, 212, 0.28)',
    accentColor: '#22d3ee',
    glowColor: 'rgba(6, 182, 212, 0.4)',
    badgeClass: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40',
    borderClass: 'border-cyan-500/40 hover:border-cyan-400',
    bgImage: 'https://images.unsplash.com/photo-1508739773434-c26b3d09e071?auto=format&fit=crop&w=1200&q=80',
    hasParticles: true,
    particleType: 'pulse'
  },
  {
    id: 'romantic',
    name: 'Sweet Romance',
    category: 'Romantic',
    subtitle: 'Candlelit rose petals, blush pink aura & couple bliss',
    description: 'Enchanting romantic velvet rose ambiance designed for CP couples, love confession events, and sweet acoustic duets.',
    icon: '💖',
    gradientClass: 'from-[#240517] via-[#310724] to-[#14020d]',
    radialEffect: 'radial-gradient(circle at 50% 30%, rgba(244, 63, 94, 0.32), transparent 65%), radial-gradient(circle at 80% 80%, rgba(219, 39, 119, 0.2), transparent 70%)',
    ambientLightColor: 'rgba(244, 63, 94, 0.28)',
    accentColor: '#fb7185',
    glowColor: 'rgba(244, 63, 94, 0.4)',
    badgeClass: 'bg-rose-500/20 text-rose-300 border-rose-500/40',
    borderClass: 'border-rose-500/40 hover:border-rose-400',
    bgImage: 'https://images.unsplash.com/photo-1518895949257-7621c3c786d7?auto=format&fit=crop&w=1200&q=80',
    hasParticles: true,
    particleType: 'ember'
  },
  {
    id: 'aurora',
    name: 'Aurora Borealis',
    category: 'Aurora',
    subtitle: 'Celestial emerald ribbons, mystical green waves & glacial calm',
    description: 'Breathtaking Nordic northern lights glowing with emerald and turquoise ribbons in a mystical starry atmosphere.',
    icon: '✨',
    gradientClass: 'from-[#021b16] via-[#042d25] to-[#01110e]',
    radialEffect: 'radial-gradient(circle at 50% 15%, rgba(16, 185, 129, 0.35), transparent 60%), radial-gradient(circle at 80% 40%, rgba(6, 182, 212, 0.25), transparent 60%)',
    ambientLightColor: 'rgba(16, 185, 129, 0.3)',
    accentColor: '#34d399',
    glowColor: 'rgba(16, 185, 129, 0.4)',
    badgeClass: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
    borderClass: 'border-emerald-500/40 hover:border-emerald-400',
    bgImage: 'https://images.unsplash.com/photo-1531366936337-7c912a4589a7?auto=format&fit=crop&w=1200&q=80',
    hasParticles: true,
    particleType: 'aurora'
  },
  {
    id: 'luxury',
    name: 'Imperial Gold',
    category: 'Luxury',
    subtitle: 'Carbon obsidian richness, royal 24K gold glint & VIP distinction',
    description: 'An elite velvet black & gold palace theme reserved for grand gifting events, VIP galas, and celebratory milestones.',
    icon: '👑',
    gradientClass: 'from-[#14120b] via-[#201c12] to-[#0a0906]',
    radialEffect: 'radial-gradient(circle at 50% 20%, rgba(251, 191, 36, 0.28), transparent 65%), radial-gradient(circle at 80% 80%, rgba(245, 158, 11, 0.2), transparent 70%)',
    ambientLightColor: 'rgba(251, 191, 36, 0.25)',
    accentColor: '#facc15',
    glowColor: 'rgba(251, 191, 36, 0.4)',
    badgeClass: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/40',
    borderClass: 'border-yellow-500/40 hover:border-yellow-400',
    bgImage: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80',
    hasParticles: true,
    particleType: 'gold_dust'
  },
  {
    id: 'classic',
    name: 'Aura Classic',
    category: 'Classic',
    subtitle: 'Deep twilight violet, signature Aura frosted-glass atmosphere',
    description: 'The iconic default Aura voice studio theme with frosted violet glass and radiant royal accents.',
    icon: '🎙️',
    gradientClass: 'from-[#140a28] via-[#1c0d38] to-[#0b0416]',
    radialEffect: 'radial-gradient(circle at 50% 20%, rgba(147, 51, 234, 0.25), transparent 65%), radial-gradient(circle at 80% 80%, rgba(99, 102, 241, 0.15), transparent 70%)',
    ambientLightColor: 'rgba(147, 51, 234, 0.25)',
    accentColor: '#c084fc',
    glowColor: 'rgba(147, 51, 234, 0.35)',
    badgeClass: 'bg-purple-500/20 text-purple-300 border-purple-500/40',
    borderClass: 'border-purple-500/40 hover:border-purple-400',
    bgImage: '',
    hasParticles: false
  }
];

export const getThemeById = (themeId?: string): RoomThemeConfig => {
  if (!themeId) return ROOM_THEMES[0]; // Default to Night Mode or Classic
  const found = ROOM_THEMES.find(t => t.id === themeId.toLowerCase());
  return found || ROOM_THEMES[0];
};
