/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  Mic, 
  MicOff, 
  Headphones, 
  HeadphoneOff, 
  Lock, 
  Crown, 
  Radio, 
  Activity, 
  Volume2, 
  VolumeX, 
  UserMinus, 
  UserPlus, 
  SlidersHorizontal,
  LogOut
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp, useAppOptional } from '../../context/AppContext';
import { MicSeat, VoiceRoom as VoiceRoomType } from '../../types';

export interface AudioSlotItem extends MicSeat {
  role?: 'host' | 'co-host' | 'speaker' | 'vip' | 'listener';
  isDeafened?: boolean;
}

export interface VoiceRoomStageProps {
  room?: VoiceRoomType | null;
  slots?: AudioSlotItem[];
  isMuted?: boolean;
  isDeafened?: boolean;
  onMuteChange?: (isMuted: boolean) => void;
  onDeafenChange?: (isDeafened: boolean) => void;
  onSlotClick?: (slot: MicSeat) => void;
  onJoinSeat?: (slotIndex: number) => void;
  onLeaveSeat?: (slotIndex: number) => void;
  onLeaveRoom?: () => void;
  className?: string;
  showSpotlight?: boolean;
  showControls?: boolean;
  title?: string;
}

const DEFAULT_MOCK_SEATS: MicSeat[] = [
  {
    index: 0,
    userId: 'host-101',
    userName: 'Aura Host',
    userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop&crop=faces',
    isMuted: false,
    isLocked: false,
    isSpeaking: true,
    contributionCoin: 12500,
  },
  {
    index: 1,
    userId: 'user-201',
    userName: 'Jordan Miller',
    userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=faces',
    isMuted: false,
    isLocked: false,
    isSpeaking: false,
    contributionCoin: 4200,
  },
  {
    index: 2,
    userId: 'user-202',
    userName: 'Samantha Lee',
    userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop&crop=faces',
    isMuted: true,
    isLocked: false,
    isSpeaking: false,
    contributionCoin: 8600,
  },
  { index: 3, isMuted: false, isLocked: false, isSpeaking: false, contributionCoin: 0 },
  { index: 4, isMuted: false, isLocked: true, isSpeaking: false, contributionCoin: 0 },
  { index: 5, isMuted: false, isLocked: false, isSpeaking: false, contributionCoin: 0 },
  { index: 6, isMuted: false, isLocked: false, isSpeaking: false, contributionCoin: 0 },
  { index: 7, isMuted: false, isLocked: false, isSpeaking: false, contributionCoin: 0 },
  { index: 8, isMuted: false, isLocked: false, isSpeaking: false, contributionCoin: 0 }
];

const AudioWaveBars: React.FC<{ isSpeaking: boolean; color?: string; count?: number }> = ({ 
  isSpeaking, 
  color = 'bg-emerald-400',
  count = 4 
}) => {
  if (!isSpeaking) return null;

  return (
    <div className="flex items-center justify-center gap-0.5 h-3 px-1">
      {Array.from({ length: count }).map((_, i) => (
        <motion.span
          key={i}
          animate={{
            height: isSpeaking ? ['20%', '100%', '35%', '85%', '20%'] : '20%',
            opacity: isSpeaking ? [0.6, 1, 0.7, 1, 0.6] : 0.3
          }}
          transition={{
            repeat: Infinity,
            duration: 0.55 + i * 0.12,
            ease: 'easeInOut',
            repeatType: 'reverse'
          }}
          className={`w-0.5 rounded-full ${color} shadow-[0_0_6px_currentColor]`}
          style={{ minHeight: '3px', maxHeight: '12px' }}
        />
      ))}
    </div>
  );
};

export const VoiceRoomStage: React.FC<VoiceRoomStageProps> = ({
  room: propRoom,
  slots: propSlots,
  isMuted: controlledMuted,
  isDeafened: controlledDeafened,
  onMuteChange,
  onDeafenChange,
  onSlotClick,
  onJoinSeat,
  onLeaveSeat,
  onLeaveRoom,
  className = '',
  showSpotlight = true,
  showControls = true,
  title
}) => {
  const contextData = useAppOptional();

  const activeRoom = propRoom || contextData?.activeRoom || null;
  const currentUser = contextData?.currentUser || null;
  const showNotification = contextData?.showNotification || ((msg: string) => console.log(msg));

  const [internalMuted, setInternalMuted] = useState(false);
  const [internalDeafened, setInternalDeafened] = useState(false);
  const [masterVolume, setMasterVolume] = useState(85);
  const [showVolumeSlider, setShowVolumeSlider] = useState(false);
  const [isSimulatorRunning, setIsSimulatorRunning] = useState(true);

  const isMuted = controlledMuted !== undefined ? controlledMuted : internalMuted;
  const isDeafened = controlledDeafened !== undefined ? controlledDeafened : internalDeafened;

  const rawSlots: MicSeat[] = useMemo(() => {
    if (propSlots && propSlots.length > 0) return propSlots;
    if (activeRoom?.seats && activeRoom.seats.length > 0) return activeRoom.seats;
    return DEFAULT_MOCK_SEATS;
  }, [propSlots, activeRoom?.seats]);

  const [slotsState, setSlotsState] = useState<MicSeat[]>(rawSlots);

  useEffect(() => {
    setSlotsState(rawSlots);
  }, [rawSlots]);

  useEffect(() => {
    if (!isSimulatorRunning) return;

    const interval = setInterval(() => {
      setSlotsState(prevSlots => {
        const occupied = prevSlots.filter(s => s.userId);
        if (occupied.length === 0) return prevSlots;

        const speakingIndices = new Set<number>();
        if (Math.random() > 0.4 && occupied.length > 0) {
          speakingIndices.add(occupied[0].index);
        }
        if (occupied.length > 1 && Math.random() > 0.5) {
          const randomIndex = Math.floor(Math.random() * (occupied.length - 1)) + 1;
          speakingIndices.add(occupied[randomIndex].index);
        }

        return prevSlots.map(slot => ({
          ...slot,
          isSpeaking: slot.userId ? speakingIndices.has(slot.index) && !slot.isMuted : false
        }));
      });
    }, 2400);

    return () => clearInterval(interval);
  }, [isSimulatorRunning]);

  const activeSpeakers = useMemo(() => {
    return slotsState.filter(s => s.userId && s.isSpeaking && !s.isMuted);
  }, [slotsState]);

  const mySeat = useMemo(() => {
    if (!currentUser) return null;
    return slotsState.find(s => s.userId === currentUser.id);
  }, [slotsState, currentUser?.id]);

  const handleToggleMute = () => {
    if (isDeafened) {
      showNotification('Cannot unmute while deafened. Undeafen first.');
      return;
    }

    const nextMuted = !isMuted;
    if (controlledMuted === undefined) {
      setInternalMuted(nextMuted);
    }
    onMuteChange?.(nextMuted);
    showNotification(nextMuted ? 'Microphone muted 🔇' : 'Microphone active 🎙️');

    if (mySeat) {
      setSlotsState(prev => prev.map(s => {
        if (s.userId === currentUser?.id) {
          return { ...s, isMuted: nextMuted, isSpeaking: nextMuted ? false : s.isSpeaking };
        }
        return s;
      }));
    }
  };

  const handleToggleDeafen = () => {
    const nextDeafened = !isDeafened;
    if (controlledDeafened === undefined) {
      setInternalDeafened(nextDeafened);
      if (nextDeafened && !isMuted) {
        setInternalMuted(true);
        onMuteChange?.(true);
      }
    }
    onDeafenChange?.(nextDeafened);
    showNotification(
      nextDeafened 
        ? 'Deafened: Audio & Microphone disabled 🎧❌' 
        : 'Undeafened: Audio restored 🎧'
    );
  };

  const handleSlotInteraction = (slot: MicSeat) => {
    if (onSlotClick) {
      onSlotClick(slot);
      return;
    }

    if (slot.isLocked) {
      showNotification(`Audio slot #${slot.index} is locked by host.`);
      return;
    }

    if (!slot.userId) {
      if (currentUser) {
        if (onJoinSeat) {
          onJoinSeat(slot.index);
        } else {
          setSlotsState(prev => prev.map(s => {
            if (s.index === slot.index) {
              return {
                ...s,
                userId: currentUser.id,
                userName: currentUser.name,
                userAvatar: currentUser.avatar,
                isMuted: isMuted,
                isSpeaking: false,
                contributionCoin: 0
              };
            }
            if (s.userId === currentUser.id) {
              return { ...s, userId: undefined, userName: undefined, userAvatar: undefined };
            }
            return s;
          }));
          showNotification(`You took mic slot #${slot.index}! 🎙️`);
        }
      } else {
        showNotification('Sign in to take a mic seat on stage.');
      }
      return;
    }

    if (currentUser && slot.userId === currentUser.id && slot.index !== 0) {
      if (onLeaveSeat) {
        onLeaveSeat(slot.index);
      } else {
        setSlotsState(prev => prev.map(s => {
          if (s.index === slot.index) {
            return { ...s, userId: undefined, userName: undefined, userAvatar: undefined, isSpeaking: false };
          }
          return s;
        }));
        showNotification('You stepped down from the mic.');
      }
      return;
    }

    showNotification(`Selected ${slot.userName || 'Speaker'} (Slot #${slot.index})`);
  };

  const hostSeat = slotsState[0] || DEFAULT_MOCK_SEATS[0];
  const guestSeats = slotsState.slice(1);

  return (
    <div 
      id="voice-room-stage" 
      className={`relative w-full rounded-2xl bg-gradient-to-b from-slate-900/95 via-slate-950/90 to-black/95 border border-white/10 text-white shadow-2xl overflow-hidden flex flex-col ${className}`}
    >
      {/* 1. ROOM HEADER & STATUS BAR */}
      <div className="px-4 py-3 border-b border-white/10 bg-white/[0.02] flex items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-500/20 to-teal-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0 shadow-sm">
            <Radio className="w-4 h-4 animate-pulse text-emerald-400" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-white tracking-wide truncate">
                {title || activeRoom?.title || 'Live Voice Stage'}
              </h2>
              <span className="hidden sm:inline-flex items-center gap-1 text-[10px] font-semibold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                Live Audio
              </span>
            </div>
            <p className="text-[11px] text-slate-400 truncate">
              {activeRoom?.topic || 'HD Voice Room • Low Latency RTC'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <div className="text-right hidden xs:block">
            <div className="text-[11px] font-bold text-slate-300 flex items-center justify-end gap-1.5">
              <Activity className="w-3 h-3 text-emerald-400" />
              <span>48ms</span>
            </div>
            <div className="text-[10px] text-slate-400">
              {slotsState.filter(s => s.userId).length} / {slotsState.length} On Stage
            </div>
          </div>

          {onLeaveRoom && (
            <button
              type="button"
              onClick={onLeaveRoom}
              className="p-1.5 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/30 text-rose-400 transition-colors shadow-sm"
              title="Disconnect from Room"
            >
              <LogOut className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* 2. ACTIVE SPEAKER SPOTLIGHT BANNER */}
      {showSpotlight && (
        <div className="px-4 py-2 border-b border-white/5 bg-slate-900/40 backdrop-blur-md">
          {activeSpeakers.length > 0 ? (
            <div className="flex items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-2 overflow-hidden">
                <div className="relative">
                  <img 
                    src={activeSpeakers[0].userAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=50&h=50&fit=crop'} 
                    alt={activeSpeakers[0].userName || 'Speaker'} 
                    className="w-5 h-5 rounded-full object-cover ring-2 ring-emerald-400 shadow-sm"
                  />
                  <span className="absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full bg-emerald-400" />
                </div>
                <div className="flex items-center gap-1.5 truncate">
                  <span className="font-bold text-emerald-300 truncate">
                    {activeSpeakers[0].userName || 'Speaker'}
                  </span>
                  <span className="text-slate-400 text-[11px]">is speaking</span>
                  {activeSpeakers.length > 1 && (
                    <span className="text-[10px] text-slate-400 font-normal">
                      (+{activeSpeakers.length - 1} other{activeSpeakers.length > 2 ? 's' : ''})
                    </span>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-1">
                <AudioWaveBars isSpeaking={true} color="bg-emerald-400" count={5} />
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-slate-500" />
                Stage is quiet • Waiting for active speaker
              </span>
              <button
                type="button"
                onClick={() => setIsSimulatorRunning(prev => !prev)}
                className="text-[10px] text-slate-400 hover:text-emerald-400 underline transition-colors"
                title="Toggle automated speech simulator"
              >
                {isSimulatorRunning ? 'Simulator: On' : 'Simulator: Off'}
              </button>
            </div>
          )}
        </div>
      )}

      {/* 3. DEAFENED NOTIFICATION BANNER */}
      <AnimatePresence>
        {isDeafened && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-amber-500/15 border-b border-amber-500/30 px-4 py-2 flex items-center justify-between text-xs text-amber-300 backdrop-blur-sm"
          >
            <div className="flex items-center gap-2">
              <HeadphoneOff className="w-4 h-4 text-amber-400 shrink-0" />
              <span>
                <strong>Deafened:</strong> Room audio is silenced and microphone is disabled.
              </span>
            </div>
            <button
              type="button"
              onClick={handleToggleDeafen}
              className="px-2.5 py-0.5 rounded-lg bg-amber-500 text-black font-bold text-[11px] hover:bg-amber-400 transition-colors shrink-0"
            >
              Undeafen
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 4. AUDIO SLOTS STAGE (STAGE LEADER + MIC SEATS GRID) */}
      <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-6 flex flex-col justify-center">
        {/* HOST / STAGE LEADER (Slot 0) */}
        <div className="flex flex-col items-center justify-center">
          <div 
            onClick={() => handleSlotInteraction(hostSeat)}
            className="relative cursor-pointer group flex flex-col items-center"
          >
            <div className="relative">
              {hostSeat.isSpeaking && !hostSeat.isMuted && !isDeafened && (
                <motion.div
                  animate={{ scale: [1, 1.15, 1], opacity: [0.8, 0.2, 0.8] }}
                  transition={{ repeat: Infinity, duration: 1.4, ease: 'easeInOut' }}
                  className="absolute -inset-2 rounded-full bg-gradient-to-r from-emerald-500/50 via-teal-400/40 to-cyan-500/50 blur-md pointer-events-none"
                />
              )}

              <div 
                className={`w-20 h-20 sm:w-24 sm:h-24 rounded-full p-1 transition-all duration-300 ${
                  hostSeat.isSpeaking && !hostSeat.isMuted && !isDeafened
                    ? 'ring-4 ring-emerald-400 shadow-[0_0_25px_rgba(52,211,153,0.6)] scale-105' 
                    : 'ring-2 ring-amber-400/80 shadow-md'
                } bg-gradient-to-tr from-amber-500/40 via-purple-600/30 to-indigo-600/40`}
              >
                <img 
                  src={hostSeat.userAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop'} 
                  alt={hostSeat.userName || 'Host'} 
                  className="w-full h-full rounded-full object-cover border-2 border-black/60 shadow"
                />
              </div>

              <span className="absolute -top-2 left-1/2 -translate-x-1/2 bg-gradient-to-r from-amber-400 to-yellow-500 text-black text-[10px] font-black px-2 py-0.5 rounded-full shadow-lg border border-black/30 flex items-center gap-0.5">
                <Crown className="w-3 h-3 text-black fill-black" />
                HOST
              </span>

              {hostSeat.isSpeaking && !hostSeat.isMuted && !isDeafened && (
                <span className="absolute -bottom-2.5 left-1/2 -translate-x-1/2 bg-black/85 backdrop-blur-md text-emerald-400 px-2 py-0.5 rounded-full border border-emerald-500/40 shadow flex items-center gap-1">
                  <AudioWaveBars isSpeaking={true} color="bg-emerald-400" count={4} />
                </span>
              )}

              {hostSeat.isMuted && (
                <span className="absolute bottom-0 right-0 bg-rose-600 p-1.5 rounded-full text-white shadow-lg border border-black/40">
                  <MicOff className="w-3 h-3" />
                </span>
              )}
            </div>

            <div className="mt-3 text-center">
              <div className="flex items-center justify-center gap-1">
                <span className="text-xs sm:text-sm font-bold text-white max-w-[140px] truncate">
                  {hostSeat.userName || 'Room Host'}
                </span>
              </div>
              {hostSeat.contributionCoin > 0 && (
                <span className="text-[10px] text-amber-400 font-semibold tracking-wide block mt-0.5">
                  💎 {hostSeat.contributionCoin.toLocaleString()} Contrib
                </span>
              )}
            </div>
          </div>
        </div>

        {/* GUEST AUDIO SLOTS GRID (Seats 1-8) */}
        <div className="grid grid-cols-4 gap-y-6 gap-x-2 sm:gap-x-4 max-w-xl mx-auto w-full">
          {guestSeats.map((slot) => {
            const isSpeakingNow = Boolean(slot.userId && slot.isSpeaking && !slot.isMuted && !isDeafened);
            const isMe = Boolean(currentUser && slot.userId === currentUser.id);

            return (
              <div
                key={slot.index}
                onClick={() => handleSlotInteraction(slot)}
                className="flex flex-col items-center cursor-pointer group select-none transition-transform active:scale-95"
              >
                <div className="relative">
                  {isSpeakingNow && (
                    <motion.div
                      animate={{ scale: [1, 1.2, 1], opacity: [0.7, 0.2, 0.7] }}
                      transition={{ repeat: Infinity, duration: 1.2, ease: 'easeInOut' }}
                      className="absolute -inset-1.5 rounded-full bg-emerald-400/40 blur-sm pointer-events-none"
                    />
                  )}

                  {slot.userId ? (
                    <div 
                      className={`w-14 h-14 sm:w-16 sm:h-16 rounded-full p-0.5 transition-all duration-300 ${
                        isSpeakingNow 
                          ? 'ring-3 ring-emerald-400 shadow-[0_0_18px_rgba(52,211,153,0.5)] scale-105' 
                          : isMe
                          ? 'ring-2 ring-purple-400/80 bg-purple-500/20'
                          : 'ring-1 ring-white/20 bg-slate-800'
                      }`}
                    >
                      <img 
                        src={slot.userAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&h=120&fit=crop'} 
                        alt={slot.userName || `Slot #${slot.index}`} 
                        className="w-full h-full rounded-full object-cover border-2 border-black/40 shadow"
                      />

                      {isSpeakingNow && (
                        <div className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 bg-black/90 px-1.5 py-0.5 rounded-full border border-emerald-500/40 shadow-sm flex items-center justify-center">
                          <AudioWaveBars isSpeaking={true} color="bg-emerald-400" count={3} />
                        </div>
                      )}

                      {slot.isMuted && (
                        <span className="absolute bottom-0 right-0 bg-rose-600 p-1 rounded-full text-white shadow-md border border-black/40">
                          <MicOff className="w-2.5 h-2.5" />
                        </span>
                      )}
                    </div>
                  ) : (
                    <div 
                      className={`w-14 h-14 sm:w-16 sm:h-16 rounded-full flex items-center justify-center transition-all duration-200 shadow-inner backdrop-blur-sm ${
                        slot.isLocked 
                          ? 'bg-rose-950/20 border-2 border-rose-500/30 text-rose-400' 
                          : 'bg-white/[0.04] border-2 border-dashed border-white/20 hover:border-emerald-400/60 hover:bg-emerald-500/10 text-slate-400 hover:text-emerald-300'
                      }`}
                    >
                      {slot.isLocked ? (
                        <Lock className="w-5 h-5 text-rose-400" />
                      ) : (
                        <div className="flex flex-col items-center">
                          <UserPlus className="w-4 h-4 text-slate-400 group-hover:text-emerald-400 group-hover:scale-110 transition-transform" />
                          <span className="text-[9px] font-bold text-slate-500 group-hover:text-emerald-300 transition-colors mt-0.5">
                            Take
                          </span>
                        </div>
                      )}
                    </div>
                  )}

                  <span className="absolute -top-1 -left-1 bg-black/75 text-slate-300 text-[9px] font-bold px-1.5 py-0.2 rounded-full border border-white/15 shadow">
                    #{slot.index}
                  </span>

                  {isMe && (
                    <span className="absolute -top-1.5 -right-1 bg-gradient-to-r from-purple-500 to-indigo-500 text-white text-[8px] font-black px-1.5 py-0.2 rounded-full shadow">
                      YOU
                    </span>
                  )}
                </div>

                <span className={`text-[11px] font-medium mt-1.5 truncate max-w-[70px] text-center ${
                  isSpeakingNow ? 'text-emerald-300 font-bold' : isMe ? 'text-purple-300 font-semibold' : 'text-slate-200'
                }`}>
                  {slot.userName || (slot.isLocked ? 'Locked' : 'Open')}
                </span>

                {slot.contributionCoin > 0 && (
                  <span className="text-[9px] text-amber-400 font-semibold truncate max-w-[65px]">
                    💎 {slot.contributionCoin}
                  </span>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* 5. VOLUME LEVEL SLIDER POPOVER */}
      <AnimatePresence>
        {showVolumeSlider && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="px-4 py-3 bg-slate-900/95 border-t border-white/10 backdrop-blur-xl flex items-center gap-3 text-xs"
          >
            <div className="flex items-center gap-2 text-slate-300 shrink-0">
              {masterVolume === 0 || isDeafened ? (
                <VolumeX className="w-4 h-4 text-rose-400" />
              ) : (
                <Volume2 className="w-4 h-4 text-emerald-400" />
              )}
              <span className="font-semibold">Room Volume:</span>
            </div>

            <input 
              type="range" 
              min="0" 
              max="100" 
              value={isDeafened ? 0 : masterVolume} 
              disabled={isDeafened}
              onChange={(e) => setMasterVolume(Number(e.target.value))}
              className="flex-1 accent-emerald-400 h-1.5 bg-slate-700 rounded-lg cursor-pointer disabled:opacity-40"
            />

            <span className="text-[11px] font-mono font-bold text-emerald-400 w-8 text-right shrink-0">
              {isDeafened ? '0%' : `${masterVolume}%`}
            </span>

            <button
              type="button"
              onClick={() => setShowVolumeSlider(false)}
              className="text-slate-400 hover:text-white px-2 py-0.5 rounded text-xs"
            >
              Close
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 6. CONTROLS FOR MUTING / DEAFENING & AUDIO TOOLBAR */}
      {showControls && (
        <div className="p-3 sm:p-4 border-t border-white/10 bg-black/60 backdrop-blur-2xl shrink-0">
          <div className="flex items-center justify-between gap-2 max-w-md mx-auto">
            <button
              type="button"
              id="voice-room-mic-btn"
              onClick={handleToggleMute}
              disabled={isDeafened}
              className={`flex-1 flex flex-col items-center justify-center py-2.5 px-3 rounded-xl border transition-all duration-200 active:scale-95 shadow-md ${
                isDeafened
                  ? 'bg-white/5 border-white/10 text-slate-500 cursor-not-allowed opacity-50'
                  : isMuted
                  ? 'bg-rose-500/20 hover:bg-rose-500/30 border-rose-500/40 text-rose-400 shadow-[0_0_15px_rgba(244,63,94,0.25)]'
                  : 'bg-emerald-500/20 hover:bg-emerald-500/30 border-emerald-500/50 text-emerald-300 shadow-[0_0_15px_rgba(16,185,129,0.3)]'
              }`}
            >
              <div className="relative">
                {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                {!isMuted && !isDeafened && (
                  <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                )}
              </div>
              <span className="text-[11px] font-bold mt-1 tracking-wide">
                {isDeafened ? 'Mic Disabled' : isMuted ? 'Unmute Mic' : 'Mic Active'}
              </span>
            </button>

            <button
              type="button"
              id="voice-room-deafen-btn"
              onClick={handleToggleDeafen}
              className={`flex-1 flex flex-col items-center justify-center py-2.5 px-3 rounded-xl border transition-all duration-200 active:scale-95 shadow-md ${
                isDeafened
                  ? 'bg-amber-500/25 hover:bg-amber-500/35 border-amber-500/50 text-amber-300 shadow-[0_0_15px_rgba(245,158,11,0.3)]'
                  : 'bg-white/10 hover:bg-white/15 border-white/15 text-slate-300 hover:text-white'
              }`}
            >
              <div className="relative">
                {isDeafened ? <HeadphoneOff className="w-5 h-5 text-amber-400" /> : <Headphones className="w-5 h-5 text-slate-200" />}
                {isDeafened && (
                  <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                )}
              </div>
              <span className="text-[11px] font-bold mt-1 tracking-wide">
                {isDeafened ? 'Deafened' : 'Deafen'}
              </span>
            </button>

            <button
              type="button"
              id="voice-room-volume-btn"
              onClick={() => setShowVolumeSlider(prev => !prev)}
              className={`p-2.5 sm:px-3 rounded-xl border flex flex-col items-center justify-center transition-all duration-200 active:scale-95 ${
                showVolumeSlider 
                  ? 'bg-purple-500/30 border-purple-500/50 text-purple-300' 
                  : 'bg-white/10 hover:bg-white/15 border-white/15 text-slate-300 hover:text-white'
              }`}
            >
              <SlidersHorizontal className="w-5 h-5" />
              <span className="text-[10px] font-medium mt-1">Audio</span>
            </button>

            {mySeat ? (
              <button
                type="button"
                id="voice-room-step-down-btn"
                onClick={() => handleSlotInteraction(mySeat)}
                className="p-2.5 sm:px-3 rounded-xl border border-rose-500/30 bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 transition-all duration-200 active:scale-95 flex flex-col items-center justify-center"
              >
                <UserMinus className="w-5 h-5" />
                <span className="text-[10px] font-medium mt-1">Step Down</span>
              </button>
            ) : (
              <button
                type="button"
                id="voice-room-take-mic-btn"
                onClick={() => {
                  const firstOpen = guestSeats.find(s => !s.userId && !s.isLocked);
                  if (firstOpen) {
                    handleSlotInteraction(firstOpen);
                  } else {
                    showNotification('All audio slots are currently occupied or locked.');
                  }
                }}
                className="p-2.5 sm:px-3 rounded-xl border border-emerald-500/30 bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 transition-all duration-200 active:scale-95 flex flex-col items-center justify-center"
              >
                <UserPlus className="w-5 h-5" />
                <span className="text-[10px] font-medium mt-1">Take Mic</span>
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default VoiceRoomStage;
