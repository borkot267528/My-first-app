/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export * from '../pk/PKBattleBoard';
export { PKBattleBoard as default } from '../pk/PKBattleBoard';
