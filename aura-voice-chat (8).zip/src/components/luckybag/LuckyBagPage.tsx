/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Gift, Sparkles, ChevronLeft, Award, Trophy, Clock, CheckCircle2, TrendingUp } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ApiClient } from '../../lib/api';
import { LuckyBag } from '../../types';
import { LuckyBag as LuckyBagComponent } from './LuckyBag';

export const LuckyBagPage: React.FC = () => {
  const { setActiveModal, showNotification, currentUser, activeRoom, refreshUser } = useApp();
  const [activeTab, setActiveTab] = useState<'create' | 'history' | 'leaderboard'>('create');
  const [totalCoins, setTotalCoins] = useState('500');
  const [winners, setWinners] = useState('5');
  const [activeBags, setActiveBags] = useState<LuckyBag[]>([]);

  useEffect(() => {
    if (activeRoom) {
      ApiClient.getActiveLuckyBags(activeRoom.id).then(res => setActiveBags(res)).catch(() => {});
    }
  }, [activeRoom?.id]);

  const handleCreateBag = async (e: React.FormEvent) => {
    e.preventDefault();
    const coins = parseInt(totalCoins, 10);
    const winCnt = parseInt(winners, 10);
    if (!coins || !winCnt || !currentUser || !activeRoom) {
      showNotification('Please enter valid coins and ensure you are in a room!');
      return;
    }
    if (currentUser.coins < coins) {
      showNotification('Insufficient coin balance to drop Lucky Bag!');
      return;
    }

    try {
      await ApiClient.createLuckyBag(activeRoom.id, coins, winCnt);
      await refreshUser();
      showNotification(`🎉 Lucky Bag dropped with ${coins} coins for ${winCnt} winners!`);
      setActiveModal('none');
    } catch (err: any) {
      showNotification(err.message || 'Failed to create Lucky Bag');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xl overflow-y-auto p-4 animate-fadeIn text-white space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-white/10 pb-3">
        <div className="flex items-center gap-3">
          <button onClick={() => setActiveModal('none')} className="p-2 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/10">
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-lg font-black flex items-center gap-2">
              <Gift className="w-5 h-5 text-amber-400 animate-bounce" /> Lucky Bag Center
            </h2>
            <p className="text-xs text-slate-300">Drop treasure chests in rooms & view analytics</p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="grid grid-cols-3 gap-2 p-1.5 bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 shadow-lg">
        {[
          { id: 'create', label: 'Drop Bag 🎁' },
          { id: 'history', label: 'Active / History' },
          { id: 'leaderboard', label: 'Top Sponsors 🏆' }
        ].map(t => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id as any)}
            className={`py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === t.id ? 'bg-white text-purple-900 font-black shadow' : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Tab 1: Create */}
      {activeTab === 'create' && (
        <form onSubmit={handleCreateBag} className="bg-white/5 backdrop-blur-xl p-6 rounded-3xl border border-white/10 space-y-4 shadow-xl animate-fadeIn">
          <div className="text-center p-4 rounded-2xl bg-gradient-to-r from-amber-500/20 to-red-500/20 border border-amber-500/30 space-y-1 shadow">
            <span className="text-4xl inline-block animate-bounce">🎁</span>
            <h4 className="font-extrabold text-white text-sm">Room Lucky Treasure Chest</h4>
            <p className="text-[11px] text-amber-200">Dropping a bag notifies all room participants and boosts your room ranking!</p>
          </div>

          {!activeRoom && (
            <div className="p-3 bg-red-900/40 border border-red-500/40 rounded-xl text-xs text-red-200 text-center font-bold">
              ⚠️ You must enter a voice room first to drop a Lucky Bag!
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">Total Coin Reward Amount</label>
            <div className="grid grid-cols-4 gap-2 mb-2">
              {['200', '500', '1000', '5000'].map(val => (
                <button
                  type="button"
                  key={val}
                  onClick={() => setTotalCoins(val)}
                  className={`py-2 rounded-xl text-xs font-bold transition-all ${totalCoins === val ? 'bg-amber-400 text-black font-black shadow' : 'bg-black/40 text-slate-300 hover:text-white border border-white/10'}`}
                >
                  {val} 🪙
                </button>
              ))}
            </div>
            <input
              type="number"
              required
              min="100"
              value={totalCoins}
              onChange={(e) => setTotalCoins(e.target.value)}
              className="w-full bg-black/40 text-white text-xs px-4 py-3 rounded-xl border border-white/10 focus:outline-none focus:border-amber-400"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">Number of Winners (Split Randomly)</label>
            <input
              type="number"
              required
              min="1"
              max="50"
              value={winners}
              onChange={(e) => setWinners(e.target.value)}
              className="w-full bg-black/40 text-white text-xs px-4 py-3 rounded-xl border border-white/10 focus:outline-none focus:border-amber-400"
            />
          </div>

          <button
            type="submit"
            disabled={!activeRoom}
            className="w-full py-4 bg-white text-purple-900 hover:bg-purple-100 hover:scale-105 disabled:opacity-50 font-black text-sm rounded-2xl shadow-xl transition-transform flex items-center justify-center gap-2"
          >
            <Gift className="w-5 h-5" /> Drop Lucky Bag Now
          </button>
        </form>
      )}

      {/* Tab 2: Active / History */}
      {activeTab === 'history' && (
        <div className="space-y-4 animate-fadeIn">
          {/* Interactive Lucky Bag Grab with Cooldown & Rewards */}
          <LuckyBagComponent
            bag={activeBags[0]}
            roomId={activeRoom?.id}
            cooldownSeconds={30}
            onClaimReward={async () => {
              await refreshUser();
              if (activeRoom) {
                ApiClient.getActiveLuckyBags(activeRoom.id).then(res => setActiveBags(res)).catch(() => {});
              }
            }}
          />

          <h4 className="font-bold text-white text-xs pt-2">Active & Recent Lucky Bags</h4>
          {activeBags.length === 0 ? (
            <p className="text-xs text-slate-400 text-center py-4 bg-white/5 rounded-2xl border border-white/5">
              No other lucky bags currently active in this room. Drop one in the first tab!
            </p>
          ) : (
            activeBags.map(bag => (
              <div key={bag.id} className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 flex items-center justify-between shadow-xl">
                <div>
                  <h5 className="font-bold text-white text-xs">Dropped by {bag.senderName}</h5>
                  <p className="text-xs font-black text-amber-400 mt-0.5">🪙 {bag.remainingCoins} / {bag.totalCoins} Coins left</p>
                  <p className="text-[10px] text-slate-400">{bag.claimedCount} / {bag.totalWinners} winners claimed</p>
                </div>
                <span className="bg-emerald-500/20 text-emerald-300 font-bold text-xs px-3 py-1.5 rounded-xl border border-emerald-500/30">
                  Active 🔥
                </span>
              </div>
            ))
          )}
        </div>
      )}

      {/* Tab 3: Leaderboard */}
      {activeTab === 'leaderboard' && (
        <div className="space-y-3 animate-fadeIn">
          <h4 className="font-bold text-white text-xs">Top All-Time Lucky Bag Sponsors</h4>
          {[
            { name: 'Marcus Aurelius', dropped: '25,000 Coins', bags: 14, avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80' },
            { name: 'Elena Vance', dropped: '18,500 Coins', bags: 9, avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80' },
            { name: 'Alex Chen', dropped: '12,000 Coins', bags: 7, avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80' }
          ].map((sp, i) => (
            <div key={i} className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 flex items-center justify-between shadow-xl">
              <div className="flex items-center gap-3">
                <span className={`w-7 h-7 rounded-xl flex items-center justify-center font-black text-xs ${i === 0 ? 'bg-amber-400 text-black shadow' : 'bg-white/10 text-white border border-white/10'}`}>#{i + 1}</span>
                <img src={sp.avatar} alt={sp.name} className="w-10 h-10 rounded-full object-cover border border-white/20" />
                <div>
                  <h5 className="font-bold text-white text-xs">{sp.name}</h5>
                  <p className="text-[10px] text-slate-400">{sp.bags} bags dropped</p>
                </div>
              </div>
              <span className="font-black text-amber-400 text-xs">{sp.dropped}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
