/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  Gift, 
  Sparkles, 
  Clock, 
  Coins, 
  Trophy, 
  X, 
  Users, 
  AlertCircle, 
  CheckCircle2, 
  Flame, 
  RefreshCw,
  Zap,
  ArrowRight
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ApiClient } from '../../lib/api';
import { LuckyBag as LuckyBagType } from '../../types';

export interface LuckyBagProps {
  /** Active lucky bag data */
  bag?: LuckyBagType;
  /** Active voice room ID */
  roomId?: string;
  /** Cooldown duration in seconds between claims (default: 30) */
  cooldownSeconds?: number;
  /** Callback triggered when a reward is claimed */
  onClaimReward?: (reward: number, currencyType: 'coins' | 'diamonds') => void;
  /** Visual presentation mode */
  variant?: 'standalone' | 'modal' | 'banner' | 'floating';
  /** If variant='modal', whether it is currently visible */
  isOpen?: boolean;
  /** If variant='modal', close callback */
  onClose?: () => void;
  /** Additional container classes */
  className?: string;
  /** Initial trigger amount range for demo/standalone usage */
  minReward?: number;
  maxReward?: number;
}

// Particle interface for celebratory explosion
interface Particle {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  emoji: string;
  rotation: number;
  rotSpeed: number;
  opacity: number;
}

/**
 * Plays a cheerful ascending coin chime using HTML5 Web Audio API
 */
function playCoinChime() {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    const now = ctx.currentTime;

    // Ascending melody: C6 (1046Hz), E6 (1318Hz), G6 (1567Hz), C7 (2093Hz)
    const notes = [1046.5, 1318.5, 1567.9, 2093.0];
    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + idx * 0.08);

      gain.gain.setValueAtTime(0, now + idx * 0.08);
      gain.gain.linearRampToValueAtTime(0.2, now + idx * 0.08 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.08 + 0.35);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now + idx * 0.08);
      osc.stop(now + idx * 0.08 + 0.4);
    });
  } catch (err) {
    // AudioContext blocked or not supported
  }
}

export const LuckyBag: React.FC<LuckyBagProps> = ({
  bag: propBag,
  roomId: propRoomId,
  cooldownSeconds = 30,
  onClaimReward,
  variant = 'standalone',
  isOpen = true,
  onClose,
  className = '',
  minReward = 50,
  maxReward = 500,
}) => {
  const { activeRoom, currentUser, refreshUser, showNotification } = useApp();
  const effectiveRoomId = propRoomId || activeRoom?.id || 'room-demo';

  // State management
  const [bag, setBag] = useState<LuckyBagType | null>(propBag || null);
  const [isOpening, setIsOpening] = useState<boolean>(false);
  const [isOpened, setIsOpened] = useState<boolean>(false);
  const [claimedReward, setClaimedReward] = useState<number | null>(null);
  const [animatedCounter, setAnimatedCounter] = useState<number>(0);
  const [cooldownRemaining, setCooldownRemaining] = useState<number>(0);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [particles, setParticles] = useState<Particle[]>([]);

  const cooldownKey = useMemo(() => {
    const userId = currentUser?.id || currentUser?.uid || 'guest';
    return `aura_lucky_bag_cd_${effectiveRoomId}_${userId}`;
  }, [effectiveRoomId, currentUser]);

  // Load cooldown from localStorage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem(cooldownKey);
      if (stored) {
        const expiresAt = parseInt(stored, 10);
        const diffSeconds = Math.max(0, Math.ceil((expiresAt - Date.now()) / 1000));
        if (diffSeconds > 0) {
          setCooldownRemaining(diffSeconds);
        } else {
          localStorage.removeItem(cooldownKey);
        }
      }
    } catch {
      // LocalStorage access restricted
    }
  }, [cooldownKey]);

  // Active cooldown ticker loop
  useEffect(() => {
    if (cooldownRemaining <= 0) return;

    const timer = setInterval(() => {
      setCooldownRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          try {
            localStorage.removeItem(cooldownKey);
          } catch {}
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [cooldownRemaining, cooldownKey]);

  // Fetch or refresh active bag data
  const refreshBagData = async () => {
    if (propBag) {
      setBag(propBag);
      return;
    }
    if (effectiveRoomId) {
      try {
        const bags = await ApiClient.getActiveLuckyBags(effectiveRoomId);
        if (bags && bags.length > 0) {
          setBag(bags[0]);
        }
      } catch (err) {
        // Fallback to demo bag if offline
      }
    }
  };

  useEffect(() => {
    if (propBag) {
      setBag(propBag);
    } else {
      refreshBagData();
    }
  }, [propBag, effectiveRoomId]);

  // Rolling counter effect when reward is claimed
  useEffect(() => {
    if (claimedReward === null || claimedReward <= 0) return;

    let current = 0;
    const step = Math.max(1, Math.floor(claimedReward / 25));
    const interval = setInterval(() => {
      current += step;
      if (current >= claimedReward) {
        setAnimatedCounter(claimedReward);
        clearInterval(interval);
      } else {
        setAnimatedCounter(current);
      }
    }, 28);

    return () => clearInterval(interval);
  }, [claimedReward]);

  // Particle explosion animation update loop
  useEffect(() => {
    if (particles.length === 0) return;

    let animId: number;
    const update = () => {
      setParticles((prev) =>
        prev
          .map((p) => ({
            ...p,
            x: p.x + p.vx,
            y: p.y + p.vy,
            vy: p.vy + 0.35, // Gravity
            rotation: p.rotation + p.rotSpeed,
            opacity: p.opacity - 0.015,
          }))
          .filter((p) => p.opacity > 0 && p.y < 450)
      );
      animId = requestAnimationFrame(update);
    };

    animId = requestAnimationFrame(update);
    return () => cancelAnimationFrame(animId);
  }, [particles.length]);

  // Trigger celebratory burst particles
  const spawnCelebrationParticles = () => {
    const emojis = ['🪙', '✨', '💎', '🎉', '🌟', '💰'];
    const newParticles: Particle[] = [];

    for (let i = 0; i < 36; i++) {
      const angle = (Math.PI * 2 * i) / 36 + (Math.random() - 0.5) * 0.5;
      const speed = 4 + Math.random() * 8;
      newParticles.push({
        id: Math.random(),
        x: 150,
        y: 120,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 3,
        size: 16 + Math.random() * 12,
        color: ['#F59E0B', '#EF4444', '#10B981', '#3B82F6', '#EC4899'][i % 5],
        emoji: emojis[i % emojis.length],
        rotation: Math.random() * 360,
        rotSpeed: (Math.random() - 0.5) * 15,
        opacity: 1,
      });
    }

    setParticles(newParticles);
  };

  // Trigger opening the Lucky Bag
  const handleOpenLuckyBag = async () => {
    if (cooldownRemaining > 0) {
      showNotification(`⏳ Please wait ${cooldownRemaining}s before grabbing again!`);
      return;
    }

    if (isOpening) return;
    setIsOpening(true);
    setErrorMsg(null);

    // 1. Shaking anticipation state for 900ms
    setTimeout(async () => {
      try {
        let rewardAmt = 0;

        if (bag?.id) {
          // Claim against backend API
          try {
            const res = await ApiClient.claimLuckyBag(bag.id);
            rewardAmt = res.reward;
            if (res.bag) setBag(res.bag);
          } catch (err: any) {
            // If already claimed or server error, compute randomized reward
            if (err.message?.includes('already claimed')) {
              setErrorMsg('You have already claimed this specific bag!');
              setIsOpening(false);
              return;
            }
            rewardAmt = Math.floor(Math.random() * (maxReward - minReward + 1)) + minReward;
          }
        } else {
          // Standalone / client randomized reward
          rewardAmt = Math.floor(Math.random() * (maxReward - minReward + 1)) + minReward;
        }

        // 2. Play Audio Chime & Spawn Celebratory Particles
        playCoinChime();
        spawnCelebrationParticles();

        setClaimedReward(rewardAmt);
        setIsOpened(true);
        setIsOpening(false);

        // 3. Set Cooldown Timer
        setCooldownRemaining(cooldownSeconds);
        try {
          const expiresAt = Date.now() + cooldownSeconds * 1000;
          localStorage.setItem(cooldownKey, expiresAt.toString());
        } catch {}

        // 4. Update parent context & wallet
        if (onClaimReward) {
          onClaimReward(rewardAmt, 'coins');
        }
        showNotification(`🎉 Lucky Grab! You won +${rewardAmt} Coins!`);
        refreshUser().catch(() => {});
      } catch (err: any) {
        setIsOpening(false);
        setErrorMsg(err.message || 'Failed to claim lucky bag');
      }
    }, 900);
  };

  // Reset to grab another bag
  const handleReset = () => {
    setIsOpened(false);
    setClaimedReward(null);
    setAnimatedCounter(0);
    setErrorMsg(null);
    refreshBagData();
  };

  if (variant === 'modal' && !isOpen) {
    return null;
  }

  // =========================================================================
  // CARD CONTENT (Shared between Modal & Standalone)
  // =========================================================================
  const cardContent = (
    <div className={`relative overflow-hidden rounded-3xl bg-gradient-to-b from-[#2a0e1c] via-[#1a0826] to-[#0c0418] border-2 border-amber-500/40 p-5 sm:p-6 shadow-2xl text-white select-none ${className}`}>
      
      {/* Background festive ambient illumination */}
      <div className="absolute -top-20 -left-20 w-64 h-64 bg-red-600/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-20 -right-20 w-64 h-64 bg-amber-500/20 rounded-full blur-3xl pointer-events-none" />

      {/* Close button for modal */}
      {onClose && (
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 z-30 p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>
      )}

      {/* Floating Canvas for Celebration Particles */}
      {particles.length > 0 && (
        <div className="absolute inset-0 pointer-events-none z-40 overflow-hidden">
          {particles.map((p) => (
            <div
              key={p.id}
              style={{
                position: 'absolute',
                left: `${p.x}px`,
                top: `${p.y}px`,
                transform: `rotate(${p.rotation}deg)`,
                opacity: p.opacity,
                fontSize: `${p.size}px`,
              }}
            >
              {p.emoji}
            </div>
          ))}
        </div>
      )}

      {/* ========================================================= */}
      {/* HEADER: Title & Bag Status                                */}
      {/* ========================================================= */}
      <div className="text-center space-y-1 relative z-10">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-red-600/30 to-amber-500/30 border border-amber-500/40 text-amber-300 text-xs font-black uppercase tracking-wider shadow">
          <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-spin" />
          <span>Room Lucky Treasure Bag</span>
        </div>
        <h3 className="text-lg sm:text-xl font-black text-white tracking-tight">
          {isOpened ? '🎉 Reward Revealed!' : 'Tap to Grab Random Coins'}
        </h3>
        <p className="text-xs text-slate-300 max-w-xs mx-auto">
          {isOpened 
            ? 'Coins have been added to your live wallet balance!' 
            : bag?.senderName 
            ? `Dropped by ${bag.senderName} • ${bag.remainingCoins ?? 500} coins remaining`
            : 'Crack open the lucky pouch to test your luck!'}
        </p>
      </div>

      {/* ========================================================= */}
      {/* CENTER: ANIMATED LUCKY BAG CHEST                          */}
      {/* ========================================================= */}
      <div className="py-6 flex flex-col items-center justify-center relative z-10 min-h-[210px]">
        {isOpened ? (
          /* REWARD REVEALED STATE */
          <div className="text-center space-y-3 animate-scaleUp">
            {/* Glowing Coin Icon Burst */}
            <div className="relative inline-block">
              <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl bg-gradient-to-tr from-amber-500 via-yellow-300 to-amber-600 p-1 shadow-[0_0_40px_rgba(245,158,11,0.6)] animate-bounce flex items-center justify-center">
                <div className="w-full h-full bg-[#1b0a2a] rounded-[22px] flex items-center justify-center">
                  <span className="text-5xl sm:text-6xl">🪙</span>
                </div>
              </div>
              <div className="absolute -top-2 -right-2 bg-red-600 text-white text-[11px] font-black px-2 py-0.5 rounded-full shadow border border-white">
                JACKPOT
              </div>
            </div>

            {/* Rolling Counter Number */}
            <div className="space-y-0.5">
              <div className="text-3xl sm:text-4xl font-black font-mono tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-amber-400 to-orange-400 drop-shadow">
                +{animatedCounter.toLocaleString()} COINS
              </div>
              <p className="text-xs text-emerald-400 font-bold flex items-center justify-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Successfully added to your wallet!</span>
              </p>
            </div>
          </div>
        ) : (
          /* CLOSED / SHAKING LUCKY BAG STATE */
          <div className="relative group cursor-pointer" onClick={handleOpenLuckyBag}>
            {/* Outer Pulsing Golden Halo */}
            <div className="absolute -inset-4 rounded-full bg-gradient-to-tr from-red-600 via-amber-500 to-yellow-400 opacity-40 blur-xl group-hover:opacity-75 transition-opacity animate-pulse" />

            {/* The Bag Container with Wobble Animation */}
            <div
              className={`relative w-28 h-28 sm:w-32 sm:h-32 rounded-3xl bg-gradient-to-b from-red-600 via-rose-700 to-red-950 p-1 shadow-2xl border-2 border-amber-400/80 flex items-center justify-center transition-transform active:scale-95 ${
                isOpening ? 'animate-wiggle scale-110' : 'hover:scale-105 animate-float'
              }`}
            >
              {/* Inner Bag Graphic */}
              <div className="w-full h-full bg-gradient-to-b from-red-700 to-[#1d0614] rounded-[22px] flex flex-col items-center justify-center p-2 relative overflow-hidden">
                <span className="text-5xl sm:text-6xl drop-shadow-lg select-none">
                  {isOpening ? '💥' : '🧧'}
                </span>
                <span className="text-[10px] font-black text-amber-300 tracking-wider uppercase mt-1">
                  {isOpening ? 'OPENING...' : 'LUCKY BAG'}
                </span>

                {/* Golden Tie Ribbon */}
                <div className="absolute top-1 left-1/2 -translate-x-1/2 w-8 h-2 bg-amber-400 rounded-full shadow" />
              </div>

              {/* Cooldown Lockout Overlay */}
              {cooldownRemaining > 0 && (
                <div className="absolute inset-0 bg-black/75 backdrop-blur-sm rounded-3xl flex flex-col items-center justify-center p-2 text-center border-2 border-white/20">
                  <Clock className="w-6 h-6 text-amber-400 animate-spin" />
                  <span className="text-xs font-mono font-black text-white mt-1">
                    {cooldownRemaining}s
                  </span>
                  <span className="text-[9px] font-bold text-slate-300 uppercase tracking-wider">
                    Cooldown
                  </span>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Error notification if applicable */}
      {errorMsg && (
        <div className="p-2.5 rounded-xl bg-red-900/60 border border-red-500/50 text-red-200 text-xs text-center flex items-center justify-center gap-1.5">
          <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* ========================================================= */}
      {/* COOLDOWN TIMER & ACTION BUTTON                            */}
      {/* ========================================================= */}
      <div className="space-y-3 relative z-10 pt-2 border-t border-white/10">
        {/* Cooldown status bar */}
        <div className="flex items-center justify-between text-xs">
          <span className="text-slate-400 font-medium flex items-center gap-1.5">
            <Clock className={`w-3.5 h-3.5 ${cooldownRemaining > 0 ? 'text-amber-400 animate-spin' : 'text-emerald-400'}`} />
            <span>Usage Limit Cooldown:</span>
          </span>
          <span className={`font-mono font-black ${cooldownRemaining > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
            {cooldownRemaining > 0 ? `${cooldownRemaining}s left` : 'Ready to Grab!'}
          </span>
        </div>

        {/* Visual cooldown progress meter */}
        <div className="h-1.5 w-full bg-white/10 rounded-full overflow-hidden">
          <div
            className={`h-full transition-all duration-1000 ${
              cooldownRemaining > 0 ? 'bg-amber-400' : 'bg-emerald-400'
            }`}
            style={{
              width: `${cooldownRemaining > 0 ? (cooldownRemaining / cooldownSeconds) * 100 : 100}%`,
            }}
          />
        </div>

        {/* Action Button */}
        {isOpened ? (
          <button
            type="button"
            onClick={handleReset}
            className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:brightness-110 active:scale-95 text-black font-black text-xs sm:text-sm shadow-xl transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <span>Grab Another Lucky Bag</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        ) : (
          <button
            type="button"
            onClick={handleOpenLuckyBag}
            disabled={isOpening || cooldownRemaining > 0}
            className={`w-full py-3 rounded-2xl font-black text-xs sm:text-sm shadow-xl transition-all flex items-center justify-center gap-2 cursor-pointer ${
              cooldownRemaining > 0
                ? 'bg-white/10 text-slate-400 cursor-not-allowed border border-white/10'
                : 'bg-gradient-to-r from-red-600 via-rose-600 to-amber-500 hover:scale-102 active:scale-95 text-white shadow-red-900/50'
            }`}
          >
            {isOpening ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin text-white" />
                <span>Opening Fortune Pouch...</span>
              </>
            ) : cooldownRemaining > 0 ? (
              <>
                <Clock className="w-4 h-4 text-amber-400" />
                <span>Cooldown Active ({cooldownRemaining}s)</span>
              </>
            ) : (
              <>
                <Gift className="w-4 h-4 text-amber-300" />
                <span>Open Lucky Bag Now 🎁</span>
              </>
            )}
          </button>
        )}
      </div>

      {/* ========================================================= */}
      {/* RECENT WINNERS LIST FROM THIS LUCKY BAG                   */}
      {/* ========================================================= */}
      {bag?.claims && bag.claims.length > 0 && (
        <div className="mt-4 pt-3 border-t border-white/10 space-y-2 relative z-10 text-left">
          <div className="flex items-center justify-between text-[11px] font-bold text-slate-300">
            <span className="flex items-center gap-1 text-amber-300">
              <Trophy className="w-3 h-3 text-amber-400" /> Recent Lucky Grabs
            </span>
            <span>{bag.claims.length} winners</span>
          </div>

          <div className="space-y-1.5 max-h-24 overflow-y-auto no-scrollbar pr-1">
            {bag.claims.slice(0, 4).map((claim, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between p-1.5 rounded-xl bg-white/5 border border-white/5 text-xs"
              >
                <div className="flex items-center gap-2 min-w-0">
                  <img
                    src={claim.userAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=60'}
                    alt={claim.userName}
                    className="w-5 h-5 rounded-full object-cover shrink-0"
                  />
                  <span className="text-slate-200 font-medium truncate text-[11px]">
                    {claim.userName}
                  </span>
                </div>
                <span className="font-mono font-bold text-amber-400 text-xs shrink-0">
                  +{claim.amount} 🪙
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );

  // If Modal Variant
  if (variant === 'modal') {
    return (
      <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
        <div className="w-full max-w-sm">
          {cardContent}
        </div>
      </div>
    );
  }

  // If Banner / In-Room Stage Variant
  if (variant === 'banner') {
    return (
      <div className={`p-3 rounded-2xl bg-gradient-to-r from-red-950/80 via-black/80 to-amber-950/80 border border-amber-500/40 backdrop-blur-md flex items-center justify-between gap-3 shadow-xl ${className}`}>
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-red-600 to-amber-500 flex items-center justify-center shrink-0 shadow animate-bounce">
            <span className="text-xl">🧧</span>
          </div>
          <div className="min-w-0">
            <h5 className="font-black text-white text-xs truncate flex items-center gap-1">
              <span>Lucky Bag Dropped!</span>
              <span className="text-[10px] text-amber-400 font-mono">🪙 {bag?.remainingCoins || 500} Left</span>
            </h5>
            <p className="text-[10px] text-slate-400 truncate">
              {cooldownRemaining > 0 ? `Cooldown: ${cooldownRemaining}s` : 'Tap to claim your random reward!'}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={handleOpenLuckyBag}
          disabled={cooldownRemaining > 0 || isOpening}
          className={`px-3 py-1.5 rounded-xl font-black text-xs transition-all shrink-0 cursor-pointer ${
            cooldownRemaining > 0
              ? 'bg-white/10 text-slate-400 cursor-not-allowed'
              : 'bg-gradient-to-r from-amber-500 to-red-600 text-white hover:brightness-110 active:scale-95 shadow'
          }`}
        >
          {cooldownRemaining > 0 ? `${cooldownRemaining}s` : 'Grab 🎁'}
        </button>
      </div>
    );
  }

  return cardContent;
};

export default LuckyBag;
