/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  X, Mail, Lock, User as UserIcon, Sparkles, AlertCircle, 
  Check, ArrowRight, ShieldCheck, Crown, Flame, LogIn, UserPlus, Globe, Phone, HelpCircle, ArrowLeft
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ApiClient } from '../../lib/api';
import { Country } from '../../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose }) => {
  const { 
    signInWithEmail, 
    signUpWithEmail, 
    sendResetPassword,
    signInWithGoogle, 
    switchDemoUser,
    showNotification,
    isAuthLoading
  } = useApp();

  const [mode, setMode] = useState<'signin' | 'signup' | 'demo' | 'forgot'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [gender, setGender] = useState<'male' | 'female' | 'other'>('other');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Dynamic country state
  const [countries, setCountries] = useState<Country[]>([]);
  const [selectedCountryCode, setSelectedCountryCode] = useState<string>('US');

  useEffect(() => {
    ApiClient.getCountries(true)
      .then((list) => {
        if (Array.isArray(list) && list.length > 0) {
          setCountries(list);
          const preferred = list.find(c => c.iso2 === 'BD') || list.find(c => c.iso2 === 'US') || list[0];
          if (preferred) setSelectedCountryCode(preferred.iso2);
        }
      })
      .catch(() => {});
  }, []);

  const selectedCountry = countries.find(c => c.iso2 === selectedCountryCode);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    const trimmedEmail = email.trim();
    if (!trimmedEmail) {
      setErrorMessage('Please enter a valid email address.');
      return;
    }

    if (mode === 'forgot') {
      try {
        await sendResetPassword(trimmedEmail);
        setSuccessMessage(`Password reset link sent to ${trimmedEmail}! Please check your email inbox and spam folder.`);
      } catch (err: any) {
        let msg = err.message || 'Could not send password reset email';
        if (msg.includes('auth/user-not-found')) {
          msg = 'No account found with this email address.';
        } else if (msg.includes('auth/invalid-email')) {
          msg = 'Please enter a valid email address.';
        } else if (msg.includes('auth/unauthorized-domain')) {
          const currentHost = typeof window !== 'undefined' ? window.location.hostname : 'current domain';
          msg = `Firebase Auth domain notice: Hostname "${currentHost}" needs to be authorized in Firebase Console (Authentication > Settings > Authorized domains).`;
        }
        setErrorMessage(msg);
      }
      return;
    }

    if (!password || password.length < 6) {
      setErrorMessage('Password must be at least 6 characters.');
      return;
    }

    if (mode === 'signup') {
      const trimmedName = displayName.trim();
      if (!trimmedName) {
        setErrorMessage('Please enter your full name.');
        return;
      }
      if (password !== confirmPassword) {
        setErrorMessage('Passwords do not match. Please re-enter.');
        return;
      }

      if (selectedCountry && selectedCountry.registrationAllowed === false) {
        setErrorMessage(`Registration is temporarily restricted in ${selectedCountry.name}. Please choose an enabled jurisdiction or contact administration.`);
        return;
      }

      try {
        const fullPhone = phone.trim() 
          ? (phone.trim().startsWith('+') ? phone.trim() : `${selectedCountry?.dialCode || ''} ${phone.trim()}`)
          : undefined;

        await signUpWithEmail(trimmedEmail, password, trimmedName, {
          phone: fullPhone,
          country: selectedCountry?.name || 'United States',
          countryFlag: selectedCountry?.flag || '🇺🇸',
          gender
        });

        setSuccessMessage('Account created and registered with Firebase!');
        setTimeout(() => {
          onClose();
        }, 1200);
      } catch (err: any) {
        let msg = err.message || 'Registration failed';
        if (msg.includes('auth/email-already-in-use')) {
          msg = 'This email address is already registered. Please sign in instead.';
        } else if (msg.includes('auth/weak-password')) {
          msg = 'Password is too weak. Please use at least 6 characters.';
        } else if (msg.includes('auth/invalid-email')) {
          msg = 'Invalid email format.';
        } else if (msg.includes('auth/operation-not-allowed')) {
          msg = 'Email/Password authentication provider is not enabled in Firebase Console.';
        } else if (msg.includes('auth/unauthorized-domain')) {
          const currentHost = typeof window !== 'undefined' ? window.location.hostname : 'current domain';
          msg = `Firebase Auth domain notice: Hostname "${currentHost}" needs to be authorized in Firebase Console (Authentication > Settings > Authorized domains).`;
        }
        setErrorMessage(msg);
      }
    } else {
      // Sign In mode
      try {
        await signInWithEmail(trimmedEmail, password);
        setSuccessMessage('Signed in successfully! Welcome back ✨');
        setTimeout(() => {
          onClose();
        }, 1000);
      } catch (err: any) {
        let msg = err.message || 'Sign in failed';
        if (msg.includes('auth/user-not-found') || msg.includes('auth/wrong-password') || msg.includes('auth/invalid-credential')) {
          msg = 'Incorrect email or password. Please check your credentials.';
        } else if (msg.includes('auth/invalid-email')) {
          msg = 'Invalid email format.';
        } else if (msg.includes('auth/unauthorized-domain')) {
          const currentHost = typeof window !== 'undefined' ? window.location.hostname : 'current domain';
          msg = `Firebase Auth domain notice: Hostname "${currentHost}" needs to be authorized in Firebase Console (Authentication > Settings > Authorized domains).`;
        }
        setErrorMessage(msg);
      }
    }
  };

  const handleGoogleSignIn = async () => {
    setErrorMessage(null);
    try {
      await signInWithGoogle();
      setSuccessMessage('Signed in with Google successfully!');
      setTimeout(() => {
        onClose();
      }, 1000);
    } catch (err: any) {
      if (err.message && err.message.includes('popup-closed-by-user')) {
        return;
      }
      let msg = err.message || 'Google sign-in could not be completed.';
      if (msg.includes('auth/unauthorized-domain')) {
        const currentHost = typeof window !== 'undefined' ? window.location.hostname : 'current domain';
        msg = `Firebase Auth domain notice: Hostname "${currentHost}" needs to be authorized in Firebase Console (Authentication > Settings > Authorized domains).`;
      }
      setErrorMessage(msg);
    }
  };

  const handleQuickDemoSelect = async (userId: string, label: string) => {
    try {
      await switchDemoUser(userId);
      showNotification(`Switched to demo role: ${label}`);
      onClose();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to switch demo user');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-md bg-gradient-to-b from-slate-900 via-[#150a2c] to-[#0d041a] border border-white/15 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* HEADER */}
        <div className="p-5 border-b border-white/10 bg-white/5 backdrop-blur-md flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-400 via-pink-500 to-purple-600 flex items-center justify-center shadow-lg">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-base font-black text-white">
                {mode === 'signin' ? 'Sign In to Aura' : mode === 'signup' ? 'Create Aura Account' : mode === 'forgot' ? 'Reset Password' : 'Demo Test Accounts'}
              </h3>
              <p className="text-[11px] text-slate-300">
                {mode === 'signin' ? 'Secure Firebase Authentication' : mode === 'signup' ? 'Join voice rooms & get 10,000 free coins' : mode === 'forgot' ? 'Receive a secure reset link' : 'Quickly test RBAC staff roles'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            disabled={isAuthLoading}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/15 text-slate-300 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* TABS */}
        <div className="grid grid-cols-3 p-1.5 bg-black/40 border-b border-white/10 text-xs font-bold">
          <button
            type="button"
            onClick={() => { setMode('signin'); setErrorMessage(null); setSuccessMessage(null); }}
            className={`py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              mode === 'signin' 
                ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-black font-black shadow' 
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <LogIn className="w-3.5 h-3.5" />
            <span>Sign In</span>
          </button>

          <button
            type="button"
            onClick={() => { setMode('signup'); setErrorMessage(null); setSuccessMessage(null); }}
            className={`py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              mode === 'signup' 
                ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-black font-black shadow' 
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>Sign Up</span>
          </button>

          <button
            type="button"
            onClick={() => { setMode('demo'); setErrorMessage(null); setSuccessMessage(null); }}
            className={`py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              mode === 'demo' 
                ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white font-black shadow' 
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Crown className="w-3.5 h-3.5" />
            <span>Roles</span>
          </button>
        </div>

        {/* CONTENT */}
        <div className="p-5 space-y-4 overflow-y-auto flex-1">
          {errorMessage && (
            <div className="p-3 bg-red-500/15 border border-red-500/40 rounded-2xl flex items-start gap-2.5 text-red-300 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span className="leading-relaxed">{errorMessage}</span>
            </div>
          )}

          {successMessage && (
            <div className="p-3 bg-emerald-500/15 border border-emerald-500/40 rounded-2xl flex items-start gap-2.5 text-emerald-300 text-xs">
              <Check className="w-4 h-4 shrink-0 mt-0.5" />
              <span className="leading-relaxed">{successMessage}</span>
            </div>
          )}

          {mode === 'demo' ? (
            /* QUICK DEMO ROLE SWITCHER FOR REVIEW & STAFF TESTING */
            <div className="space-y-3">
              <div className="p-3 bg-purple-500/10 border border-purple-500/20 rounded-2xl text-[11px] text-purple-200">
                Switch instantly between pre-configured staff and user identities to test permissions, admin panels, and live features.
              </div>

              <div className="space-y-2">
                {[
                  { id: '2383452', name: 'Elena Vance (CEO)', role: 'CEO (UID: 2383452)', desc: 'Full Executive Authority, Staff & System Control', icon: '👑', color: 'from-amber-500 to-yellow-600' },
                  { id: '8829105', name: 'Alex Chen', role: 'Super Admin (UID: 8829105)', desc: 'Finance, Banners, Family, Reports', icon: '🛡️', color: 'from-purple-500 to-indigo-600' },
                  { id: '8829106', name: 'Marcus Aurelius', role: 'GM (UID: 8829106)', desc: 'Senior GM, Moderation, Room Control', icon: '⚡', color: 'from-blue-500 to-cyan-600' },
                  { id: '8829107', name: 'Sophia Taylor', role: 'Agency (UID: 8829107)', desc: 'Agency Manager, Live Music Host, Approvals', icon: '💼', color: 'from-emerald-500 to-teal-600' },
                  { id: '8829108', name: 'Kenji Sato', role: 'Host (UID: 8829108)', desc: 'Room Host, Gift Target, Audio Mic', icon: '🎤', color: 'from-pink-500 to-rose-600' }
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleQuickDemoSelect(item.id, item.name)}
                    className="w-full p-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl flex items-center justify-between text-left transition-all hover:scale-[1.01] active:scale-[0.99] group"
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-xl bg-gradient-to-tr ${item.color} flex items-center justify-center text-lg shadow`}>
                        {item.icon}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-white group-hover:text-amber-400 transition-colors">{item.name}</span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-white/10 text-slate-300 font-mono">{item.role}</span>
                        </div>
                        <span className="text-[10px] text-slate-400 block">{item.desc}</span>
                      </div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-white transition-colors" />
                  </button>
                ))}
              </div>
            </div>
          ) : mode === 'forgot' ? (
            /* FORGOT PASSWORD FORM */
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-2xl text-[11px] text-amber-200 leading-relaxed">
                Enter your registered email address and we will send you a secure Firebase password reset link.
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-amber-400" />
                  Email Address
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full px-3.5 py-2.5 bg-black/50 border border-white/15 focus:border-amber-400 rounded-xl text-white text-xs outline-none transition-all placeholder:text-slate-500"
                />
              </div>

              <button
                type="submit"
                disabled={isAuthLoading}
                className="w-full py-3 px-4 bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-500 hover:from-amber-300 hover:to-yellow-400 text-black font-black text-xs rounded-2xl shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50"
              >
                {isAuthLoading ? (
                  <span>Sending reset link...</span>
                ) : (
                  <>
                    <Mail className="w-4 h-4" />
                    <span>Send Password Reset Email</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => { setMode('signin'); setErrorMessage(null); }}
                className="w-full py-2.5 px-4 bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-all"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back to Sign In</span>
              </button>
            </form>
          ) : (
            /* EMAIL / PASSWORD FORM */
            <form onSubmit={handleSubmit} className="space-y-3.5">
              {mode === 'signup' && (
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                    <UserIcon className="w-3.5 h-3.5 text-amber-400" />
                    Full Name
                  </label>
                  <input
                    type="text"
                    required
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder="Enter your full name or stage handle"
                    className="w-full px-3.5 py-2.5 bg-black/50 border border-white/15 focus:border-amber-400 rounded-xl text-white text-xs outline-none transition-all placeholder:text-slate-500"
                  />
                </div>
              )}

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-amber-400" />
                  {mode === 'signin' ? 'Email Address or Account ID' : 'Email Address'}
                </label>
                <input
                  type={mode === 'signin' ? 'text' : 'email'}
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder={mode === 'signin' ? "name@example.com or Account ID (e.g. 2383452)" : "name@example.com"}
                  className="w-full px-3.5 py-2.5 bg-black/50 border border-white/15 focus:border-amber-400 rounded-xl text-white text-xs outline-none transition-all placeholder:text-slate-500"
                />
              </div>

              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-amber-400" />
                    Password
                  </label>
                  {mode === 'signin' && (
                    <button
                      type="button"
                      onClick={() => { setMode('forgot'); setErrorMessage(null); setSuccessMessage(null); }}
                      className="text-[11px] text-amber-400 hover:text-amber-300 hover:underline transition-colors"
                    >
                      Forgot Password?
                    </button>
                  )}
                </div>
                <input
                  type="password"
                  required
                  minLength={6}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="At least 6 characters"
                  className="w-full px-3.5 py-2.5 bg-black/50 border border-white/15 focus:border-amber-400 rounded-xl text-white text-xs outline-none transition-all placeholder:text-slate-500"
                />
              </div>

              {mode === 'signup' && (
                <>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                      <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                      Confirm Password
                    </label>
                    <input
                      type="password"
                      required
                      minLength={6}
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="Re-enter password"
                      className="w-full px-3.5 py-2.5 bg-black/50 border border-white/15 focus:border-amber-400 rounded-xl text-white text-xs outline-none transition-all placeholder:text-slate-500"
                    />
                  </div>

                  {/* Phone Input with Country Dial Code */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-amber-400" />
                      Phone Number (Optional)
                    </label>
                    <div className="flex gap-2">
                      <div className="px-3 py-2.5 bg-black/50 border border-white/15 rounded-xl text-amber-300 text-xs font-mono shrink-0">
                        {selectedCountry?.dialCode || '+1'}
                      </div>
                      <input
                        type="tel"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="e.g. 555-0199"
                        className="flex-1 px-3.5 py-2.5 bg-black/50 border border-white/15 focus:border-amber-400 rounded-xl text-white text-xs outline-none transition-all placeholder:text-slate-500"
                      />
                    </div>
                  </div>

                  {/* Dynamic Country Selector */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
                      <span className="flex items-center gap-1.5">
                        <Globe className="w-3.5 h-3.5 text-amber-400" />
                        Country / Jurisdiction
                      </span>
                      {selectedCountry && (
                        <span className="text-[10px] text-amber-300/80 font-mono">
                          {selectedCountry.dialCode} • {selectedCountry.currencyCode} ({selectedCountry.currencySymbol})
                        </span>
                      )}
                    </label>
                    <select
                      value={selectedCountryCode}
                      onChange={(e) => setSelectedCountryCode(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-black/50 border border-white/15 focus:border-amber-400 rounded-xl text-white text-xs outline-none transition-all cursor-pointer font-medium"
                    >
                      {countries.map((c) => (
                        <option key={c.id} value={c.iso2} className="bg-slate-900 text-white">
                          {c.flag} {c.name} ({c.iso2}) {c.dialCode}
                        </option>
                      ))}
                    </select>

                    {selectedCountry && selectedCountry.registrationAllowed === false && (
                      <p className="text-[11px] text-rose-400 font-semibold mt-1">
                        ⚠️ New registrations are temporarily restricted in {selectedCountry.name}.
                      </p>
                    )}
                  </div>

                  {/* Gender Selector */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                      <UserIcon className="w-3.5 h-3.5 text-amber-400" />
                      Gender
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {[
                        { val: 'male', label: '♂ Male' },
                        { val: 'female', label: '♀ Female' },
                        { val: 'other', label: '⚲ Other' }
                      ].map(g => (
                        <button
                          key={g.val}
                          type="button"
                          onClick={() => setGender(g.val as any)}
                          className={`py-2 px-3 rounded-xl border text-xs font-bold transition-all ${
                            gender === g.val 
                              ? 'bg-amber-400/20 border-amber-400 text-amber-300 shadow-sm' 
                              : 'bg-black/30 border-white/10 text-slate-400 hover:text-white'
                          }`}
                        >
                          {g.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </>
              )}

              <button
                type="submit"
                disabled={isAuthLoading}
                className="w-full py-3 px-4 bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-500 hover:from-amber-300 hover:to-yellow-400 text-black font-black text-xs rounded-2xl shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50 mt-2"
              >
                {isAuthLoading ? (
                  <span>Authenticating...</span>
                ) : mode === 'signin' ? (
                  <>
                    <LogIn className="w-4 h-4" />
                    <span>Sign In with Email</span>
                  </>
                ) : (
                  <>
                    <UserPlus className="w-4 h-4" />
                    <span>Create Account &amp; Claim 10k Coins</span>
                  </>
                )}
              </button>

              <div className="relative py-2 text-center">
                <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-white/10"></div></div>
                <span className="relative px-2 bg-[#120726] text-[10px] text-slate-400 uppercase tracking-wider font-bold">Or continue with</span>
              </div>

              <button
                type="button"
                onClick={handleGoogleSignIn}
                disabled={isAuthLoading}
                className="w-full py-2.5 px-4 bg-white/10 hover:bg-white/15 border border-white/15 text-white font-bold text-xs rounded-2xl flex items-center justify-center gap-2.5 transition-all active:scale-95 disabled:opacity-50"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                </svg>
                <span>Sign In with Google</span>
              </button>
            </form>
          )}

          {/* FOOTER NOTE */}
          <div className="pt-2 text-center">
            <p className="text-[10px] text-slate-400">
              {mode === 'signin' ? (
                <>Don&apos;t have an account yet? <button type="button" onClick={() => { setMode('signup'); setErrorMessage(null); setSuccessMessage(null); }} className="text-amber-400 font-bold hover:underline">Sign Up</button></>
              ) : mode === 'signup' ? (
                <>Already registered? <button type="button" onClick={() => { setMode('signin'); setErrorMessage(null); setSuccessMessage(null); }} className="text-amber-400 font-bold hover:underline">Sign In</button></>
              ) : mode === 'forgot' ? (
                <button type="button" onClick={() => { setMode('signin'); setErrorMessage(null); setSuccessMessage(null); }} className="text-amber-400 font-bold hover:underline">Remember your password? Sign In</button>
              ) : (
                <>Need to use your own credentials? <button type="button" onClick={() => { setMode('signin'); setErrorMessage(null); setSuccessMessage(null); }} className="text-amber-400 font-bold hover:underline">Sign In</button></>
              )}
            </p>
          </div>
        </div>

      </div>
    </div>
  );
};
