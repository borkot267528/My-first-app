/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Flame, Crown, Gift, Sparkles, Trophy, Users, Radio, 
  ChevronRight, Gift as GiftIcon, DollarSign, Calendar, 
  Share2, CheckCircle2, Star, Shield, Zap, Play, Disc, Swords, Heart, Search
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { VoiceRoom as VoiceRoomType, Banner } from '../../types';
import { ApiClient } from '../../lib/api';
import { VoiceRoom } from '../room/VoiceRoom';
import { LiveRoomsListView } from '../rooms/LiveRoomsListView';
import { LeaderboardItemSkeleton } from '../common/SkeletonLoader';

export const HomePage: React.FC = () => {
  const { setActiveTab, setActiveModal, setActiveRoom, currentUser, showNotification, refreshUser, openUserSearch } = useApp();
  const [activeBannerIdx, setActiveBannerIdx] = useState(0);
  const [showTasksModal, setShowTasksModal] = useState(false);
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [roomsList, setRoomsList] = useState<VoiceRoomType[]>([]);
  const [fetchedBanners, setFetchedBanners] = useState<Banner[]>([]);
  const [topHosts, setTopHosts] = useState<{ name: string; avatar: string; frame: string; score: string }[]>([
    { name: 'Elena Vance', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80', frame: '👑', score: '4.5M' },
    { name: 'Alex Chen', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80', frame: '⚡', score: '2.8M' },
    { name: 'Sophia Taylor', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80', frame: '✨', score: '1.9M' },
    { name: 'Kenji Sato', avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=300&q=80', frame: '🔥', score: '1.2M' }
  ]);
  const [topFamilies, setTopFamilies] = useState<{ name: string; members: number; score: string; leader: string }[]>([
    { name: 'Royal Dynasty 👑', members: 45, score: '4.5M contribution', leader: 'Elena Vance' },
    { name: 'Cyber Wolves 🐺', members: 38, score: '2.8M contribution', leader: 'Alex Chen' },
    { name: 'Aura Stars ✨', members: 29, score: '1.9M contribution', leader: 'Sophia Taylor' }
  ]);
  const [loading, setLoading] = useState(false);

  React.useEffect(() => {
    setLoading(true);
    ApiClient.getRooms().then(res => {
      const unique = Array.isArray(res) ? Array.from(new Map(res.map(r => [r.id, r])).values()) : [];
      setRoomsList(unique);
    }).catch(() => {});
    ApiClient.getActiveBanners().then(res => {
      if (res && res.length > 0) setFetchedBanners(res);
    }).catch(() => {});
    
    ApiClient.getAnalyticsOverview().then(res => {
      if (res && res.topHosts && res.topHosts.length > 0) {
        const frames = ['👑', '⚡', '✨', '🔥'];
        setTopHosts(res.topHosts.map((h, i) => ({
          name: h.name,
          avatar: h.avatar,
          frame: frames[i] || '⭐',
          score: `${(h.diamondsEarned >= 1000 ? (h.diamondsEarned / 1000).toFixed(1) + 'k' : h.diamondsEarned)}`
        })));
      }
    }).catch(() => {});
    ApiClient.getFamilies().then(res => {
      if (res && res.length > 0) {
        setTopFamilies(res.slice(0, 3).map(f => ({
          name: f.name,
          members: f.memberCount,
          score: `${(f.totalContribution >= 1000 ? (f.totalContribution / 1000).toFixed(1) + 'k' : f.totalContribution)} contribution`,
          leader: f.leaderName
        })));
      }
    }).finally(() => setLoading(false));
  }, []);

  const displayBanners = fetchedBanners.length > 0 ? fetchedBanners.map(b => ({
    id: b.id,
    title: b.title,
    subtitle: b.subtitle,
    badge: b.type.toUpperCase(),
    imageUrl: b.imageUrl,
    targetAction: b.targetAction,
    targetRoomId: b.targetRoomId,
    targetUrl: b.targetUrl,
    color: b.type === 'pk' ? 'from-rose-600 via-pink-600 to-purple-800' :
           b.type === 'vip' ? 'from-amber-500 via-yellow-600 to-purple-800' :
           b.type === 'gift' ? 'from-blue-600 via-indigo-600 to-purple-700' :
           'from-purple-600 via-indigo-600 to-blue-700'
  })) : [
    { id: '1', title: '🎉 Summer PK World Championship', subtitle: 'Win 1,000,000 Diamonds & Royal Dragon Frame!', badge: 'MEGA EVENT', imageUrl: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=800&q=80', targetAction: 'open_event', targetRoomId: '', targetUrl: '', color: 'from-purple-600 via-pink-600 to-red-500' },
    { id: '2', title: '👑 SVIP Exclusive Genesis Club', subtitle: 'Unlock customized entrance animations and 10x exp.', badge: 'VIP SHOP', imageUrl: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=800&q=80', targetAction: 'open_vip', targetRoomId: '', targetUrl: '', color: 'from-amber-500 via-yellow-600 to-purple-800' },
    { id: '3', title: '🎁 Daily Lucky Bag Rain', subtitle: 'Join Top Rooms now to grab free coin drops every hour!', badge: 'FREE COINS', imageUrl: 'https://images.unsplash.com/photo-1513151233558-d860c5398176?auto=format&fit=crop&w=800&q=80', targetAction: 'open_recharge', targetRoomId: '', targetUrl: '', color: 'from-blue-600 via-indigo-600 to-purple-700' }
  ];

  const currentBanner = displayBanners[activeBannerIdx % displayBanners.length] || displayBanners[0];

  const handleBannerClick = (banner: any) => {
    if (banner.targetAction === 'open_room' && banner.targetRoomId) {
      const target = roomsList.find(r => r.id === banner.targetRoomId);
      if (target) {
        setActiveRoom(target);
      } else {
        showNotification(`Joining Voice Room ${banner.targetRoomId}...`);
        setActiveTab('rooms');
      }
    } else if (banner.targetAction === 'open_vip') {
      setActiveModal('vip_shop');
    } else if (banner.targetAction === 'open_recharge') {
      setActiveModal('wallet');
    } else if (banner.targetAction === 'open_event') {
      setActiveModal('pk');
    } else if (banner.targetAction === 'open_custom' && banner.targetUrl) {
      showNotification(`Opening: ${banner.targetUrl}`);
    } else {
      showNotification(`📌 ${banner.title}`);
    }
  };

  const quickMenuItems = [
    { label: 'Find Users', icon: <Search className="w-6 h-6 text-amber-400" />, action: () => openUserSearch(), bg: 'bg-gradient-to-r from-amber-500/20 to-purple-500/20 border-amber-400/30 hover:border-amber-400 backdrop-blur-md' },
    { label: 'Top Contributors', icon: <Trophy className="w-6 h-6 text-amber-300 animate-pulse" />, action: () => setActiveModal('contributors'), bg: 'bg-gradient-to-r from-amber-500/20 via-pink-500/20 to-purple-500/20 border-amber-400/40 hover:border-amber-300 backdrop-blur-md' },
    { label: 'Admin Portal', icon: <Shield className="w-6 h-6 text-amber-400" />, action: () => setActiveModal('admin'), bg: 'bg-gradient-to-r from-amber-500/20 to-yellow-500/20 border-amber-400/30 hover:border-amber-400 backdrop-blur-md' },
    { label: '❤️ CP Space', icon: <Heart className="w-6 h-6 text-pink-400 fill-pink-400/30" />, action: () => setActiveModal('cp'), bg: 'bg-gradient-to-r from-pink-500/20 to-rose-500/20 border-pink-400/30 hover:border-pink-400 backdrop-blur-md' },
    { label: '👥 Friends', icon: <Users className="w-6 h-6 text-blue-400" />, action: () => setActiveModal('friends'), bg: 'bg-gradient-to-r from-blue-500/20 to-indigo-500/20 border-blue-400/30 hover:border-blue-400 backdrop-blur-md' },
    { label: 'Lucky Bag', icon: <GiftIcon className="w-6 h-6 text-amber-300" />, action: () => setActiveModal('lucky_bag'), bg: 'bg-white/5 border-white/10 hover:bg-white/10 hover:border-white/20 backdrop-blur-md' },
    { label: 'Daily Spin', icon: <Disc className="w-6 h-6 text-pink-300 animate-spin" />, action: () => setActiveModal('spin'), bg: 'bg-white/5 border-white/10 hover:bg-white/10 hover:border-white/20 backdrop-blur-md' },
    { label: 'PK Battle', icon: <Swords className="w-6 h-6 text-red-300" />, action: () => setActiveModal('pk'), bg: 'bg-white/5 border-white/10 hover:bg-white/10 hover:border-white/20 backdrop-blur-md' },
    { label: 'VIP Shop', icon: <Crown className="w-6 h-6 text-yellow-300" />, action: () => setActiveModal('vip_shop'), bg: 'bg-white/5 border-white/10 hover:bg-white/10 hover:border-white/20 backdrop-blur-md' },
    { label: 'Wallet', icon: <DollarSign className="w-6 h-6 text-emerald-300" />, action: () => setActiveModal('wallet'), bg: 'bg-white/5 border-white/10 hover:bg-white/10 hover:border-white/20 backdrop-blur-md' },
    { label: 'Tasks', icon: <CheckCircle2 className="w-6 h-6 text-purple-300" />, action: () => setShowTasksModal(true), bg: 'bg-white/5 border-white/10 hover:bg-white/10 hover:border-white/20 backdrop-blur-md' },
    { label: 'Invite', icon: <Share2 className="w-6 h-6 text-blue-300" />, action: () => setShowInviteModal(true), bg: 'bg-white/5 border-white/10 hover:bg-white/10 hover:border-white/20 backdrop-blur-md' }
  ];

  return (
    <div className="pb-24 space-y-5 animate-fadeIn">
      {/* 0. USER SEARCH BAR */}
      <div 
        onClick={() => openUserSearch()}
        className="px-4 py-2.5 bg-gradient-to-r from-purple-950/40 via-white/5 to-purple-950/30 hover:bg-white/10 border border-white/10 hover:border-amber-400/50 rounded-2xl flex items-center justify-between cursor-pointer transition-all shadow-md group active:scale-[0.99]"
      >
        <div className="flex items-center gap-3 text-slate-300">
          <div className="w-7 h-7 rounded-xl bg-amber-400/15 border border-amber-400/30 flex items-center justify-center text-amber-400 group-hover:scale-110 transition-transform shadow-inner">
            <Search className="w-3.5 h-3.5" />
          </div>
          <span className="text-xs font-semibold text-slate-300 group-hover:text-white transition-colors">
            Search users by User ID (UID) or name...
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] font-mono font-bold text-amber-300/90 bg-amber-400/10 px-2 py-0.5 rounded-lg border border-amber-400/20">
            UID
          </span>
        </div>
      </div>

      {/* 1. BANNER SLIDER */}
      <div 
        onClick={() => handleBannerClick(currentBanner)}
        className="relative overflow-hidden rounded-3xl p-6 bg-white/5 backdrop-blur-xl shadow-2xl transition-all duration-500 border border-white/10 cursor-pointer group hover:border-amber-400/50"
      >
        {currentBanner.imageUrl ? (
          <>
            <img 
              src={currentBanner.imageUrl} 
              alt={currentBanner.title} 
              className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" 
            />
            <div className={`absolute inset-0 bg-gradient-to-t from-black/95 via-black/50 to-black/30 opacity-90`} />
          </>
        ) : (
          <div className={`absolute inset-0 bg-gradient-to-br ${currentBanner.color} opacity-80`} />
        )}

        <div className="relative z-10 flex flex-col justify-between h-36">
          <div className="flex items-center justify-between">
            <span className="px-3 py-1 text-[11px] font-black tracking-widest text-amber-300 uppercase bg-black/60 backdrop-blur-md rounded-full border border-amber-400/30">
              {currentBanner.badge}
            </span>
            <span className="text-xs font-mono text-white/80 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/10">
              {(activeBannerIdx % displayBanners.length) + 1}/{displayBanners.length}
            </span>
          </div>
          <div>
            <h2 className="text-lg sm:text-xl font-black text-white leading-tight drop-shadow-lg group-hover:text-amber-200 transition-colors">
              {currentBanner.title}
            </h2>
            <p className="text-xs text-slate-200 mt-1 drop-shadow font-medium line-clamp-1">
              {currentBanner.subtitle}
            </p>
          </div>
        </div>
        {/* Dots */}
        <div className="absolute bottom-3 right-6 z-10 flex gap-1.5" onClick={e => e.stopPropagation()}>
          {displayBanners.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setActiveBannerIdx(idx)}
              className={`h-1.5 rounded-full transition-all ${idx === (activeBannerIdx % displayBanners.length) ? 'w-6 bg-amber-400' : 'w-1.5 bg-white/40'}`}
            />
          ))}
        </div>
      </div>

      {/* 2. QUICK MENU */}
      <div>
        <h3 className="text-xs font-bold text-purple-300 uppercase tracking-wider mb-3 px-1 flex items-center gap-1.5">
          <Zap className="w-3.5 h-3.5 text-amber-400" /> Quick Features
        </h3>
        <div className="grid grid-cols-4 gap-2.5">
          {quickMenuItems.map((item, idx) => (
            <button
              key={idx}
              onClick={item.action}
              className={`flex flex-col items-center justify-center p-3 rounded-2xl border ${item.bg} hover:scale-105 active:scale-95 transition-all shadow-md group`}
            >
              <div className="p-2.5 rounded-xl bg-black/30 border border-white/5 shadow-inner group-hover:rotate-6 transition-transform">
                {item.icon}
              </div>
              <span className="text-[11px] font-semibold text-slate-200 mt-2 truncate w-full text-center">
                {item.label}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* 3. VIP BANNER */}
      <div 
        onClick={() => setActiveModal('vip_shop')}
        className="cursor-pointer relative overflow-hidden rounded-2xl p-4 bg-gradient-to-r from-amber-600/20 via-yellow-600/10 to-purple-900/20 backdrop-blur-xl border border-amber-500/30 flex items-center justify-between hover:border-amber-400 transition-all shadow-[0_0_20px_rgba(245,158,11,0.15)]"
      >
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-400 to-yellow-600 flex items-center justify-center shadow-lg text-2xl animate-bounce">
            👑
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-amber-300 text-sm">AURA VIP & SVIP CLUB</span>
              <span className="bg-amber-400 text-black text-[9px] font-black px-1.5 py-0.5 rounded">10X PERKS</span>
            </div>
            <p className="text-xs text-purple-200/80 mt-0.5">Unlock exclusive frames, entrance cars & anti-kick privilege!</p>
          </div>
        </div>
        <ChevronRight className="w-5 h-5 text-amber-400 flex-shrink-0" />
      </div>

      {/* CONNECTIONS & SOCIAL DUAL MENU */}
      <div className="grid grid-cols-2 gap-3">
        <div
          onClick={() => setActiveModal('cp')}
          className="cursor-pointer relative overflow-hidden rounded-2xl p-3.5 bg-gradient-to-br from-pink-950/40 via-purple-950/30 to-black/60 backdrop-blur-xl border border-pink-500/30 hover:border-pink-400 transition-all shadow-lg group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-black text-pink-300 flex items-center gap-1.5">
              <Heart className="w-3.5 h-3.5 text-pink-500 fill-pink-500" /> ❤️ CP Space
            </span>
            <ChevronRight className="w-4 h-4 text-pink-400 group-hover:translate-x-1 transition-transform" />
          </div>
          <p className="text-[11px] text-pink-200/70 mt-1">My CP • Proposals • Levels</p>
        </div>

        <div
          onClick={() => setActiveModal('friends')}
          className="cursor-pointer relative overflow-hidden rounded-2xl p-3.5 bg-gradient-to-br from-blue-950/40 via-indigo-950/30 to-black/60 backdrop-blur-xl border border-blue-500/30 hover:border-blue-400 transition-all shadow-lg group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-black text-blue-300 flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5 text-blue-400" /> 👥 Friends
            </span>
            <ChevronRight className="w-4 h-4 text-blue-400 group-hover:translate-x-1 transition-transform" />
          </div>
          <p className="text-[11px] text-blue-200/70 mt-1">Friends List • Requests</p>
        </div>
      </div>

      {/* 4. TOP ROOMS */}
      <div>
        <div className="flex items-center justify-between mb-3 px-1">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Radio className="w-4 h-4 text-purple-400 animate-pulse" /> Live Voice Rooms
          </h3>
          <button 
            onClick={() => setActiveTab('rooms')} 
            className="text-xs font-semibold text-purple-400 hover:text-purple-300 flex items-center gap-0.5"
          >
            See All <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
        <LiveRoomsListView
          rooms={roomsList.slice(0, 4)}
          isLoading={loading}
          showFilters={false}
          showViewToggle={false}
          onJoinRoom={(room) => {
            setActiveRoom(room);
            setActiveTab('rooms');
          }}
        />
      </div>

      {/* 5. TOP HOSTS */}
      <div>
        <div className="flex items-center justify-between mb-3 px-1">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Trophy className="w-4 h-4 text-amber-400" /> Top Hosts & Contributors
          </h3>
          <button 
            type="button"
            onClick={() => setActiveModal('contributors')} 
            className="text-xs font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1 cursor-pointer bg-amber-400/10 px-2.5 py-1 rounded-xl border border-amber-400/30 transition-all hover:scale-105 shadow"
          >
            <span>Full Leaderboard 🏆</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
        <div className="grid grid-cols-4 gap-2.5">
          {topHosts.map((host, idx) => (
            <div 
              key={idx} 
              onClick={() => setActiveModal('contributors')}
              className="flex flex-col items-center p-2.5 rounded-2xl bg-white/5 backdrop-blur-md border border-white/10 text-center shadow cursor-pointer hover:bg-white/10 hover:border-amber-400/40 transition-all group"
            >
              <div className="relative">
                <img src={host.avatar} alt={host.name} className="w-12 h-12 rounded-full object-cover border border-white/20 group-hover:scale-105 transition-transform" />
                <span className="absolute -top-1 -right-1 text-xs">{host.frame}</span>
                <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 bg-gradient-to-r from-amber-500 to-yellow-600 text-black text-[9px] font-black px-1.5 rounded-full shadow">
                  #{idx + 1}
                </span>
              </div>
              <span className="text-[11px] font-bold text-white mt-2 truncate w-full group-hover:text-amber-300 transition-colors">{host.name}</span>
              <span className="text-[10px] font-semibold text-amber-400 flex items-center justify-center gap-0.5 mt-0.5">
                💎 {host.score}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* 6. TOP FAMILIES & ONLINE USERS */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Top Families */}
        <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-md border border-white/10 space-y-3 shadow-xl">
          <h3 className="text-xs font-bold text-purple-300 uppercase tracking-wider flex items-center gap-1.5">
            <Users className="w-4 h-4 text-blue-400" /> Top Families
          </h3>
          <div className="space-y-2">
            {topFamilies.map((fam, idx) => (
              <div key={idx} onClick={() => setActiveTab('family')} className="cursor-pointer flex items-center justify-between p-2 rounded-xl bg-white/5 border border-white/5 hover:bg-white/10 hover:border-white/15 transition-colors">
                <div className="flex items-center gap-2.5">
                  <span className={`w-6 h-6 rounded-lg flex items-center justify-center text-xs font-extrabold ${idx === 0 ? 'bg-amber-500 text-black' : 'bg-white/10 text-white'}`}>
                    {idx + 1}
                  </span>
                  <div>
                    <h5 className="font-bold text-white text-xs">{fam.name}</h5>
                    <p className="text-[10px] text-slate-400">Leader: {fam.leader}</p>
                  </div>
                </div>
                <span className="text-xs font-bold text-amber-400">{fam.score}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Online Users Preview */}
        <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-md border border-white/10 space-y-3 shadow-xl">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-purple-300 uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-emerald-400" /> Online Users (2,480 Live)
            </h3>
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
          </div>
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {topHosts.map((u, i) => (
              <div key={i} className="flex-shrink-0 flex flex-col items-center">
                <div className="relative">
                  <img src={u.avatar} alt={u.name} className="w-11 h-11 rounded-full object-cover border-2 border-emerald-500" />
                  <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 border-2 border-[#140b24]" />
                </div>
                <span className="text-[10px] text-purple-200 mt-1 truncate w-12 text-center">{u.name}</span>
              </div>
            ))}
          </div>
          <p className="text-[11px] text-slate-400 text-center pt-1 border-t border-white/10">
            Join a voice room to start voice talking now!
          </p>
        </div>
      </div>

      {/* DAILY TASKS MODAL */}
      {showTasksModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#1a0b2e]/90 backdrop-blur-2xl border border-white/20 rounded-3xl p-6 w-full max-w-md space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="font-extrabold text-white text-lg flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-purple-400" /> Daily Tasks & Rewards
              </h3>
              <button onClick={() => setShowTasksModal(false)} className="text-slate-400 font-bold hover:text-white">✕</button>
            </div>
            <div className="space-y-3">
              {[
                { title: 'Daily Check-in', reward: '50 Coins', progress: '1/1', done: true },
                { title: 'Stay in a Voice Room for 15 mins', reward: '100 Coins', progress: '15/15', done: true },
                { title: 'Send 1 Virtual Gift to any host', reward: '200 Coins + 10 Exp', progress: '0/1', done: false },
                { title: 'Share room link with 3 friends', reward: '500 Coins', progress: '1/3', done: false }
              ].map((task, i) => (
                <div key={i} className="flex items-center justify-between p-3 rounded-2xl bg-white/5 border border-white/10">
                  <div>
                    <h5 className="font-bold text-white text-sm">{task.title}</h5>
                    <p className="text-xs text-amber-400 font-semibold mt-0.5">🎁 {task.reward}</p>
                  </div>
                  <button 
                    disabled={task.done}
                    onClick={async () => {
                      try {
                        const amount = parseInt(task.reward) || 100;
                        await ApiClient.rechargeCoins(currentUser?.id || '2383452', amount);
                        await refreshUser();
                        showNotification(`Claimed reward (+${amount} Coins) for task: ${task.title}!`);
                      } catch (e) {
                        showNotification(`Claimed reward for task: ${task.title}!`);
                      }
                      setShowTasksModal(false);
                    }}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold ${task.done ? 'bg-white/10 text-slate-400 cursor-not-allowed' : 'bg-white text-purple-900 hover:bg-purple-100 shadow-md'}`}
                  >
                    {task.done ? 'Claimed ✓' : 'Claim'}
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* INVITE FRIENDS MODAL */}
      {showInviteModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#1a0b2e]/90 backdrop-blur-2xl border border-white/20 rounded-3xl p-6 w-full max-w-md space-y-4 text-center shadow-2xl">
            <div className="w-16 h-16 mx-auto rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-3xl shadow-lg animate-pulse">
              🎁
            </div>
            <h3 className="font-extrabold text-white text-xl">Invite Friends & Earn 500 Coins!</h3>
            <p className="text-xs text-slate-300">
              When your friends join using your invite link, you both receive instant bonus coins!
            </p>
            <div className="p-3 bg-black/40 rounded-2xl border border-white/10 flex items-center justify-between">
              <span className="text-xs text-purple-300 font-mono truncate">https://auravoice.io/invite/{currentUser?.uid || '2383452'}</span>
              <button 
                onClick={() => {
                  navigator.clipboard.writeText(`https://auravoice.io/invite/${currentUser?.uid || '2383452'}`);
                  showNotification('Invite link copied to clipboard!');
                  setShowInviteModal(false);
                }}
                className="px-3 py-1.5 bg-white text-purple-900 hover:bg-purple-100 text-xs font-black rounded-xl shadow"
              >
                Copy
              </button>
            </div>
            <button onClick={() => setShowInviteModal(false)} className="w-full py-2.5 bg-white/10 hover:bg-white/20 text-slate-300 rounded-2xl font-bold text-xs border border-white/10">
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
