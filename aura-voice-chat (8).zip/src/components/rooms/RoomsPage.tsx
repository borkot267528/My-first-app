/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Search, Plus, Radio, Globe, Users, Gamepad2, Music, Flame, Sparkles, ChevronRight, Layers } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { VoiceRoom as VoiceRoomType } from '../../types';
import { ApiClient } from '../../lib/api';
import { VoiceRoom } from '../room/VoiceRoom';
import { LiveRoomsListView } from './LiveRoomsListView';
import { ProfileIdBadge } from '../common/ProfileIdBadge';

export const RoomsPage: React.FC = () => {
  const { activeRoom, setActiveRoom, currentUser, showNotification, openUserSearch } = useApp();
  const [activeCategory, setActiveCategory] = useState<string>('popular');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [rooms, setRooms] = useState<VoiceRoomType[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [showCreateModal, setShowCreateModal] = useState<boolean>(false);
  const [newTitle, setNewTitle] = useState('');
  const [newTopic, setNewTopic] = useState('');
  const [newCategory, setNewCategory] = useState('popular');
  const [viewMode, setViewMode] = useState<'room' | 'browse'>('room');

  const categories = [
    { id: 'popular', label: 'Popular', icon: <Flame className="w-4 h-4 text-amber-400" /> },
    { id: 'new', label: 'New', icon: <Sparkles className="w-4 h-4 text-pink-400" /> },
    { id: 'country', label: 'Country', icon: <Globe className="w-4 h-4 text-blue-400" /> },
    { id: 'family', label: 'Family', icon: <Users className="w-4 h-4 text-purple-400" /> },
    { id: 'game', label: 'Game', icon: <Gamepad2 className="w-4 h-4 text-emerald-400" /> },
    { id: 'music', label: 'Music', icon: <Music className="w-4 h-4 text-cyan-400" /> }
  ];

  const loadRooms = async () => {
    setLoading(true);
    try {
      const data = await ApiClient.getRooms(activeCategory, searchQuery);
      const uniqueRooms = Array.isArray(data)
        ? Array.from(new Map(data.map(r => [r.id, r])).values())
        : [];
      setRooms(uniqueRooms);
      // If no room is active yet and we loaded rooms, default to the top live room
      if (!activeRoom && uniqueRooms.length > 0) {
        setActiveRoom(uniqueRooms[0]);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadRooms();
  }, [activeCategory, searchQuery]);

  const handleCreateRoom = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newTopic.trim()) {
      showNotification('Please enter both room title and topic!');
      return;
    }
    try {
      const created = await ApiClient.createRoom(newTitle, newTopic, newCategory);
      showNotification(`Room created: ${created.title}!`);
      setShowCreateModal(false);
      setActiveRoom(created);
      setViewMode('room');
    } catch (err: any) {
      showNotification(err.message || 'Failed to create room');
    }
  };

  return (
    <div className="pb-24 space-y-4 animate-fadeIn">
      {/* 1. TOP UTILITY HEADER: SEARCH & CREATE */}
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-purple-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search Voice Rooms by title or topic..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-white/5 backdrop-blur-md text-white text-xs pl-10 pr-4 py-2.5 rounded-2xl border border-white/10 focus:outline-none focus:border-white/25 placeholder:text-slate-400 shadow-inner"
          />
        </div>
        
        {/* Toggle between Primary Live Room & Directory View */}
        <div className="flex items-center p-1 bg-white/5 rounded-2xl border border-white/10 shrink-0">
          <button
            type="button"
            onClick={() => setViewMode('room')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              viewMode === 'room'
                ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
            title="Live Voice Room Primary Interface"
          >
            <Radio className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Live Room</span>
          </button>
          
          <button
            type="button"
            onClick={() => setViewMode('browse')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              viewMode === 'browse'
                ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
            title="Browse All Voice Rooms"
          >
            <Layers className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Explore</span>
          </button>
        </div>

        <button
          onClick={() => setShowCreateModal(true)}
          className="flex items-center gap-1.5 px-3.5 py-2.5 bg-gradient-to-r from-amber-400 to-yellow-500 text-black font-black text-xs rounded-2xl shadow transition-transform hover:scale-105 active:scale-95 shrink-0 cursor-pointer"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span className="hidden sm:inline">Create</span>
        </button>
      </div>

      {/* 2. PRIMARY INTERFACE: VOICE ROOM COMPONENT */}
      {viewMode === 'room' ? (
        <div className="space-y-4">
          <VoiceRoom
            room={activeRoom || rooms[0]}
            onSelectRoom={(r) => {
              setActiveRoom(r);
              showNotification(`Switched to room: ${r.title}`);
            }}
            standalone={true}
            className="w-full"
          />

          {/* Quick Rooms Carousel below the primary Voice Room */}
          <div className="pt-2 border-t border-white/10">
            <div className="flex items-center justify-between mb-2.5 px-1">
              <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <Radio className="w-3.5 h-3.5 text-pink-400" />
                <span>Other Active Live Rooms</span>
              </span>
              <button
                type="button"
                onClick={() => setViewMode('browse')}
                className="text-xs font-semibold text-purple-400 hover:text-purple-300 flex items-center gap-0.5 cursor-pointer"
              >
                <span>View Directory</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {rooms.slice(0, 4).map((r) => (
                <div
                  key={r.id}
                  onClick={() => {
                    setActiveRoom(r);
                    showNotification(`Joined room: ${r.title}`);
                  }}
                  className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-2.5 shadow-md ${
                    r.id === activeRoom?.id
                      ? 'bg-purple-900/40 border-pink-500/50 shadow-md shadow-pink-500/10'
                      : 'bg-white/5 border-white/10 hover:border-pink-500/30 hover:bg-white/10'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <img src={r.hostAvatar} alt={r.hostName} className="w-9 h-9 rounded-full object-cover shrink-0 border border-amber-400/40" />
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-bold text-white truncate">{r.title}</p>
                      <p className="text-[10px] text-slate-400 truncate flex items-center gap-1 mt-0.5">
                        <Users className="w-2.5 h-2.5 text-cyan-400" />
                        <span>{r.onlineCount || 1} live</span>
                        {r.countryFlag && <span>• {r.countryFlag}</span>}
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveRoom(r);
                      showNotification(`Joined room: ${r.title}`);
                    }}
                    className="px-2.5 py-1 rounded-lg bg-pink-500/20 hover:bg-pink-500 text-pink-300 hover:text-white border border-pink-500/30 text-[11px] font-black transition-all active:scale-95 shrink-0 cursor-pointer"
                  >
                    Join
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : (
        /* BROWSE ALL ROOMS DIRECTORY (LIVE ROOMS LIST VIEW) */
        <div className="space-y-4">
          <LiveRoomsListView
            rooms={rooms}
            isLoading={loading}
            category={activeCategory}
            searchQuery={searchQuery}
            showFilters={true}
            showViewToggle={true}
            onJoinRoom={(r) => {
              setActiveRoom(r);
              setViewMode('room');
              showNotification(`🎙️ Joined "${r.title}"!`);
            }}
            emptyMessage="There are no live rooms in this category right now. Be the first host to start one!"
          />
        </div>
      )}

      {/* CREATE ROOM MODAL */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
          <form onSubmit={handleCreateRoom} className="bg-[#1a0b2e]/95 backdrop-blur-2xl border border-white/20 rounded-3xl p-6 w-full max-w-md space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="font-extrabold text-white text-lg flex items-center gap-2">
                <Radio className="w-5 h-5 text-purple-400" /> Create New Voice Room
              </h3>
              <button type="button" onClick={() => setShowCreateModal(false)} className="text-slate-400 font-bold hover:text-white cursor-pointer">✕</button>
            </div>

            <div className="space-y-3">
              <div className="p-3 bg-gradient-to-r from-purple-950/60 to-black/60 border border-purple-500/30 rounded-2xl flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-purple-300 font-bold uppercase tracking-wider block">Assigned Voice Room ID</span>
                  <span className="text-xs text-slate-300">Synchronized with your Profile ID</span>
                </div>
                <ProfileIdBadge uid={currentUser?.uid || currentUser?.id} size="sm" canCopy={true} />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Room Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 🌙 Midnight Chill & Karaoke Party"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full bg-black/40 text-white text-xs px-3.5 py-2.5 rounded-xl border border-white/10 focus:outline-none focus:border-white/25"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Room Topic / Slogan</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Talk about gaming, music, making new friends"
                  value={newTopic}
                  onChange={(e) => setNewTopic(e.target.value)}
                  className="w-full bg-black/40 text-white text-xs px-3.5 py-2.5 rounded-xl border border-white/10 focus:outline-none focus:border-white/25"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Category</label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                  className="w-full bg-black/40 text-white text-xs px-3.5 py-2.5 rounded-xl border border-white/10 focus:outline-none focus:border-white/25"
                >
                  <option value="popular">Popular</option>
                  <option value="new">New</option>
                  <option value="country">Country</option>
                  <option value="family">Family</option>
                  <option value="game">Game</option>
                  <option value="music">Music</option>
                </select>
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="flex-1 py-2.5 rounded-xl bg-white/10 text-slate-300 font-bold text-xs hover:bg-white/20 border border-white/10 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 py-2.5 rounded-xl bg-white text-purple-900 hover:bg-purple-100 font-black text-xs shadow-lg hover:scale-105 transition-transform cursor-pointer"
              >
                Create & Enter Room
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
