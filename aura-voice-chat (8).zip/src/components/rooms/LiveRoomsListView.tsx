/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  Radio, 
  Users, 
  Mic, 
  Crown, 
  Sparkles, 
  Flame, 
  Music, 
  Gamepad2, 
  Globe, 
  Lock, 
  ChevronRight, 
  Search, 
  RefreshCw, 
  LayoutGrid, 
  List, 
  Headphones, 
  Swords, 
  HeartHandshake, 
  ArrowRight,
  ShieldCheck,
  Disc
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { VoiceRoom as VoiceRoomType } from '../../types';
import { ApiClient } from '../../lib/api';

export interface LiveRoomsListViewProps {
  /** Optional pre-loaded rooms list. If omitted, fetches active rooms from backend */
  rooms?: VoiceRoomType[];
  /** Callback when user clicks 'Join' button or card */
  onJoinRoom?: (room: VoiceRoomType) => void;
  /** Filter by category */
  category?: string;
  /** Initial search query */
  searchQuery?: string;
  /** Whether data is loading */
  isLoading?: boolean;
  /** Title header */
  title?: string;
  /** Subtitle description */
  subtitle?: string;
  /** Whether to show search & category filter toolbar */
  showFilters?: boolean;
  /** Whether to show the Grid / List layout switch buttons */
  showViewToggle?: boolean;
  /** Custom message when no rooms found */
  emptyMessage?: string;
  /** Maximum number of rooms to display */
  maxItems?: number;
  /** Extra CSS classes */
  className?: string;
  /** Default view layout ('grid' | 'list') */
  defaultLayout?: 'grid' | 'list';
}

const CATEGORIES = [
  { id: 'all', label: 'All Rooms', icon: Sparkles },
  { id: 'popular', label: 'Popular', icon: Flame },
  { id: 'music', label: 'Music', icon: Music },
  { id: 'game', label: 'Gaming', icon: Gamepad2 },
  { id: 'country', label: 'Global', icon: Globe },
  { id: 'family', label: 'Community', icon: Users }
];

export const LiveRoomsListView: React.FC<LiveRoomsListViewProps> = ({
  rooms: propRooms,
  onJoinRoom,
  category: propCategory = 'all',
  searchQuery: propSearchQuery = '',
  isLoading: propLoading,
  title,
  subtitle,
  showFilters = true,
  showViewToggle = true,
  emptyMessage = 'No active voice rooms found right now. Start your own room to go live!',
  maxItems,
  className = '',
  defaultLayout = 'grid'
}) => {
  const { setActiveRoom, activeRoom, showNotification } = useApp();

  const [internalRooms, setInternalRooms] = useState<VoiceRoomType[]>([]);
  const [internalLoading, setInternalLoading] = useState<boolean>(!propRooms);
  const [selectedCategory, setSelectedCategory] = useState<string>(propCategory);
  const [searchKeyword, setSearchKeyword] = useState<string>(propSearchQuery);
  const [layoutMode, setLayoutMode] = useState<'grid' | 'list'>(defaultLayout);

  // Fetch active rooms from backend if not passed as prop
  const fetchRooms = async () => {
    if (propRooms) return;
    setInternalLoading(true);
    try {
      const data = await ApiClient.getRooms(
        selectedCategory === 'all' ? undefined : selectedCategory,
        searchKeyword.trim() || undefined
      );
      const unique = Array.isArray(data)
        ? Array.from(new Map(data.map(r => [r.id, r])).values())
        : [];
      setInternalRooms(unique);
    } catch (err) {
      console.error('Failed to load live rooms:', err);
    } finally {
      setInternalLoading(false);
    }
  };

  useEffect(() => {
    if (!propRooms) {
      fetchRooms();
    }
  }, [propRooms, selectedCategory, searchKeyword]);

  // Sync category prop if updated from outside
  useEffect(() => {
    if (propCategory) setSelectedCategory(propCategory);
  }, [propCategory]);

  const sourceRooms = propRooms || internalRooms;
  const loading = propLoading !== undefined ? propLoading : internalLoading;

  // Filter rooms
  const activeRooms = useMemo(() => {
    let filtered = sourceRooms.filter((room) => {
      // Must be active
      if (room.status && room.status !== 'active') return false;

      // Category filter
      if (selectedCategory !== 'all' && room.category !== selectedCategory) {
        return false;
      }

      // Search keyword filter
      if (searchKeyword.trim()) {
        const query = searchKeyword.toLowerCase();
        const matchesTitle = room.title?.toLowerCase().includes(query);
        const matchesHost = room.hostName?.toLowerCase().includes(query);
        const matchesTopic = room.topic?.toLowerCase().includes(query);
        const matchesCountry = room.country?.toLowerCase().includes(query);
        if (!matchesTitle && !matchesHost && !matchesTopic && !matchesCountry) return false;
      }

      return true;
    });

    if (maxItems && maxItems > 0) {
      filtered = filtered.slice(0, maxItems);
    }

    return filtered;
  }, [sourceRooms, selectedCategory, searchKeyword, maxItems]);

  // Handle joining a room
  const handleJoin = (room: VoiceRoomType, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (onJoinRoom) {
      onJoinRoom(room);
    } else {
      setActiveRoom(room);
      showNotification(`🎙️ Joined "${room.title}"! You are now in the live voice stage.`);
    }
  };

  return (
    <div className={`space-y-4 ${className}`}>
      {/* 1. HEADER & CONTROLS */}
      {(title || subtitle || showFilters || showViewToggle) && (
        <div className="space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              {title && (
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-pink-500 via-purple-600 to-indigo-600 p-0.5 flex items-center justify-center shadow-lg shadow-purple-900/40">
                    <div className="w-full h-full bg-[#140827] rounded-[10px] flex items-center justify-center">
                      <Radio className="w-4 h-4 text-pink-400 animate-pulse" />
                    </div>
                  </div>
                  <h2 className="text-lg sm:text-xl font-black text-white tracking-tight flex items-center gap-2">
                    <span>{title}</span>
                    <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-pink-500/20 text-pink-300 border border-pink-500/30">
                      {activeRooms.length} Live
                    </span>
                  </h2>
                </div>
              )}
              {subtitle && <p className="text-xs text-slate-400 mt-1">{subtitle}</p>}
            </div>

            <div className="flex items-center gap-2 self-start sm:self-auto">
              {/* Refresh button */}
              <button
                type="button"
                onClick={fetchRooms}
                disabled={loading}
                className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 transition-colors flex items-center gap-1.5 text-xs font-bold cursor-pointer active:scale-95 disabled:opacity-50"
                title="Refresh Live Rooms"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-pink-400' : ''}`} />
                <span className="hidden sm:inline">Refresh</span>
              </button>

              {/* View Layout Toggle (Grid vs List) */}
              {showViewToggle && (
                <div className="flex items-center p-1 bg-white/5 rounded-xl border border-white/10">
                  <button
                    type="button"
                    onClick={() => setLayoutMode('grid')}
                    className={`p-1.5 rounded-lg transition-all cursor-pointer ${
                      layoutMode === 'grid'
                        ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-sm'
                        : 'text-slate-400 hover:text-white'
                    }`}
                    title="Grid Card View"
                  >
                    <LayoutGrid className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setLayoutMode('list')}
                    className={`p-1.5 rounded-lg transition-all cursor-pointer ${
                      layoutMode === 'list'
                        ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-sm'
                        : 'text-slate-400 hover:text-white'
                    }`}
                    title="Compact List View"
                  >
                    <List className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Search bar & Category filters */}
          {showFilters && (
            <div className="space-y-2.5">
              <div className="relative">
                <Search className="w-4 h-4 text-purple-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchKeyword}
                  onChange={(e) => setSearchKeyword(e.target.value)}
                  placeholder="Search live rooms by title, topic, or host..."
                  className="w-full bg-white/5 border border-white/10 rounded-2xl pl-10 pr-4 py-2 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-pink-500 transition-colors shadow-inner"
                />
              </div>

              {/* Category Pills */}
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-0.5">
                {CATEGORIES.map((cat) => {
                  const Icon = cat.icon;
                  const isSelected = selectedCategory === cat.id;
                  return (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setSelectedCategory(cat.id)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 cursor-pointer ${
                        isSelected
                          ? 'bg-gradient-to-r from-pink-500 via-purple-600 to-indigo-600 text-white shadow-md shadow-pink-500/20 scale-102'
                          : 'bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/5'
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                      <span>{cat.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* 2. LOADING SKELETON STATE */}
      {loading ? (
        <div className={layoutMode === 'grid' ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4' : 'space-y-3'}>
          {[1, 2, 3, 4, 5, 6].map((n) => (
            <div
              key={n}
              className={`rounded-3xl bg-white/[0.03] border border-white/10 animate-pulse ${
                layoutMode === 'grid' ? 'h-52' : 'h-24'
              }`}
            />
          ))}
        </div>
      ) : activeRooms.length === 0 ? (
        /* 3. EMPTY STATE */
        <div className="p-8 sm:p-12 text-center rounded-3xl bg-white/[0.02] border border-white/10 space-y-3">
          <div className="w-14 h-14 rounded-2xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center mx-auto text-purple-400">
            <Radio className="w-7 h-7 animate-pulse" />
          </div>
          <div>
            <h4 className="font-extrabold text-white text-base">No Live Voice Rooms Found</h4>
            <p className="text-xs text-slate-400 max-w-sm mx-auto mt-1">{emptyMessage}</p>
          </div>
        </div>
      ) : layoutMode === 'grid' ? (
        /* 4. GRID CARDS VIEW */
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {activeRooms.map((room) => {
            const isCurrentActive = activeRoom?.id === room.id;
            const occupiedSeats = room.seats?.filter(s => s.userId || s.userAvatar) || [];
            const occupiedMicsCount = occupiedSeats.length;

            return (
              <div
                key={room.id}
                onClick={(e) => handleJoin(room, e)}
                className={`group relative rounded-3xl overflow-hidden border transition-all duration-300 cursor-pointer flex flex-col justify-between shadow-xl hover:-translate-y-1 ${
                  isCurrentActive
                    ? 'border-pink-500 bg-gradient-to-b from-purple-950/70 via-[#180a2f] to-[#0d041c] shadow-[0_0_25px_rgba(236,72,153,0.25)]'
                    : 'border-white/10 bg-gradient-to-b from-white/[0.06] via-[#140826]/80 to-[#0c0419] hover:border-pink-500/50 hover:bg-white/[0.08]'
                }`}
              >
                {/* Background Banner Ambient Glow */}
                {room.coverImage && (
                  <div 
                    className="absolute inset-x-0 top-0 h-28 opacity-25 group-hover:opacity-35 transition-opacity bg-cover bg-center pointer-events-none"
                    style={{ backgroundImage: `url(${room.coverImage})` }}
                  />
                )}

                <div className="p-4 sm:p-5 relative z-10 space-y-3.5">
                  {/* Top Badges Row */}
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                        LIVE
                      </span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-purple-500/20 text-purple-300 border border-purple-500/30">
                        {room.category || 'VOICE'}
                      </span>
                      {room.countryFlag && (
                        <span className="text-xs" title={room.country}>{room.countryFlag}</span>
                      )}
                    </div>

                    {/* Participant Counts Badge */}
                    <div className="flex items-center gap-1 text-xs font-bold text-cyan-300 bg-black/60 px-2.5 py-1 rounded-full border border-white/15 shadow-inner">
                      <Users className="w-3.5 h-3.5 text-cyan-400" />
                      <span>{room.onlineCount || occupiedMicsCount || 1}</span>
                      <span className="text-[10px] text-slate-400 font-normal">listeners</span>
                    </div>
                  </div>

                  {/* Room Title & Topic Metadata */}
                  <div>
                    <h3 className="font-black text-white text-base sm:text-lg group-hover:text-pink-300 transition-colors line-clamp-1 flex items-center gap-1.5">
                      {room.isLocked && <Lock className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
                      <span>{room.title}</span>
                    </h3>
                    <p className="text-xs text-slate-400 line-clamp-2 mt-1 min-h-[32px] leading-relaxed">
                      {room.topic || room.announcement || 'Join this live voice stage to chat, listen to music, and interact with the host!'}
                    </p>
                  </div>

                  {/* Active Room Tool / Warfare Indicators */}
                  {(room.pkState?.active || room.musicPlaying?.isPlaying || room.toolsState?.cp?.active) && (
                    <div className="flex items-center gap-2 flex-wrap">
                      {room.pkState?.active && (
                        <span className="flex items-center gap-1 text-[10px] font-extrabold px-2 py-0.5 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse">
                          <Swords className="w-3 h-3 text-amber-400" />
                          <span>PK War Live</span>
                        </span>
                      )}
                      {room.musicPlaying?.isPlaying && (
                        <span className="flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                          <Disc className="w-3 h-3 text-cyan-400 animate-spin" />
                          <span className="truncate max-w-[120px]">{room.musicPlaying.title}</span>
                        </span>
                      )}
                      {room.toolsState?.cp?.active && (
                        <span className="flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-lg bg-pink-500/20 text-pink-300 border border-pink-500/30">
                          <HeartHandshake className="w-3 h-3 text-pink-400" />
                          <span>CP Golden Aura</span>
                        </span>
                      )}
                    </div>
                  )}

                  {/* Host Information & Mic Stage Preview */}
                  <div className="flex items-center justify-between pt-3 border-t border-white/10 gap-3">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="relative shrink-0">
                        <img
                          src={room.hostAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100'}
                          alt={room.hostName}
                          className="w-9 h-9 rounded-full object-cover border-2 border-amber-400 shadow-md"
                        />
                        <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-amber-400 text-black flex items-center justify-center text-[10px] font-bold shadow">
                          👑
                        </div>
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-slate-200 truncate flex items-center gap-1">
                          <span>{room.hostName}</span>
                        </p>
                        <p className="text-[10px] text-slate-400 flex items-center gap-1">
                          <Mic className="w-2.5 h-2.5 text-emerald-400" />
                          <span>{occupiedMicsCount}/8 Mics Active</span>
                        </p>
                      </div>
                    </div>

                    {/* Participant Avatars Preview Stack */}
                    {occupiedSeats.length > 0 && (
                      <div className="flex items-center -space-x-1.5 shrink-0">
                        {occupiedSeats.slice(0, 3).map((seat, i) => (
                          <img
                            key={i}
                            src={seat.userAvatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=80'}
                            alt=""
                            className="w-6 h-6 rounded-full object-cover border border-purple-900 shadow-sm"
                            title={seat.userName || `Seat #${seat.index + 1}`}
                          />
                        ))}
                        {occupiedSeats.length > 3 && (
                          <div className="w-6 h-6 rounded-full bg-purple-900 text-white text-[9px] font-bold flex items-center justify-center border border-purple-700">
                            +{occupiedSeats.length - 3}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                {/* Card Action Footer with 'Join' Button */}
                <div className="p-3 bg-black/40 border-t border-white/10 flex items-center justify-between gap-3">
                  <span className="text-[11px] text-purple-300/80 font-mono font-medium pl-1">
                    {room.language || 'English'} Stage
                  </span>

                  {/* PROMINENT JOIN BUTTON */}
                  <button
                    type="button"
                    onClick={(e) => handleJoin(room, e)}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-pink-500 via-purple-600 to-indigo-600 hover:from-pink-400 hover:to-indigo-500 text-white font-extrabold text-xs shadow-lg shadow-purple-900/40 hover:shadow-pink-500/30 flex items-center gap-1.5 transition-all duration-200 active:scale-95 cursor-pointer"
                  >
                    <Headphones className="w-3.5 h-3.5" />
                    <span>Join</span>
                    <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* 5. COMPACT LIST VIEW */
        <div className="space-y-2.5">
          {activeRooms.map((room) => {
            const isCurrentActive = activeRoom?.id === room.id;
            const occupiedSeats = room.seats?.filter(s => s.userId || s.userAvatar) || [];
            const occupiedMicsCount = occupiedSeats.length;

            return (
              <div
                key={room.id}
                onClick={(e) => handleJoin(room, e)}
                className={`p-3 sm:p-4 rounded-2xl border transition-all duration-200 cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-md ${
                  isCurrentActive
                    ? 'border-pink-500 bg-purple-950/60 shadow-pink-500/10'
                    : 'border-white/10 bg-white/[0.04] hover:bg-white/[0.07] hover:border-pink-500/40'
                }`}
              >
                <div className="flex items-center gap-3.5 min-w-0">
                  {/* Host Avatar with Live Ring */}
                  <div className="relative shrink-0">
                    <img
                      src={room.hostAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100'}
                      alt={room.hostName}
                      className="w-12 h-12 rounded-2xl object-cover border border-amber-400/60 shadow-md"
                    />
                    <div className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-amber-400 text-black flex items-center justify-center text-[10px] font-bold shadow">
                      👑
                    </div>
                  </div>

                  {/* Title & Metadata Details */}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" />
                      <h4 className="font-extrabold text-white text-sm sm:text-base truncate group-hover:text-pink-300">
                        {room.title}
                      </h4>
                      {room.isLocked && <Lock className="w-3 h-3 text-amber-400 shrink-0" />}
                    </div>

                    <p className="text-xs text-slate-400 truncate mt-0.5">
                      Host: <b className="text-slate-200">{room.hostName}</b> • {room.topic || 'Voice Chat & Music'}
                    </p>

                    <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-400">
                      <span className="text-cyan-300 font-bold flex items-center gap-1">
                        <Users className="w-3 h-3 text-cyan-400" />
                        {room.onlineCount || occupiedMicsCount || 1} participants
                      </span>
                      <span>•</span>
                      <span className="text-purple-300 font-medium">
                        {occupiedMicsCount}/8 on mic
                      </span>
                      {room.countryFlag && <span>• {room.countryFlag}</span>}
                    </div>
                  </div>
                </div>

                {/* Right Action: 'Join' Button */}
                <div className="flex items-center justify-between sm:justify-end gap-2.5 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-white/5">
                  <span className="sm:hidden text-xs text-slate-400 font-mono">
                    {room.category || 'Live Room'}
                  </span>

                  <button
                    type="button"
                    onClick={(e) => handleJoin(room, e)}
                    className="px-5 py-2 rounded-xl bg-gradient-to-r from-pink-500 to-purple-600 hover:brightness-110 text-white font-black text-xs sm:text-sm shadow-md shadow-pink-500/20 flex items-center gap-1.5 transition-all duration-200 active:scale-95 cursor-pointer ml-auto sm:ml-0"
                  >
                    <Headphones className="w-3.5 h-3.5" />
                    <span>Join Room</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default LiveRoomsListView;
