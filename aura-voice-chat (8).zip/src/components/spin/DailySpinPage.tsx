/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Flame, Sparkles, ChevronLeft, Gift, Award, Trophy, RotateCw } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ApiClient } from '../../lib/api';

export const DailySpinPage: React.FC = () => {
  const { setActiveModal, showNotification, currentUser, setCurrentUser, refreshUser } = useApp();
  const [spinning, setSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [lastWon, setLastWon] = useState<string | null>(null);

  const prizes = [
    { label: '500 Coins', icon: '🪙', color: 'bg-amber-500', valueCoins: 500 },
    { label: 'Royal Frame', icon: '👑', color: 'bg-purple-600', valueCoins: 2000 },
    { label: '100 Diamonds', icon: '💎', color: 'bg-cyan-500', valueCoins: 1000 },
    { label: 'Sports Car Gift', icon: '🏎️', color: 'bg-pink-600', valueCoins: 5000 },
    { label: '1,000 Coins', icon: '🪙', color: 'bg-yellow-500', valueCoins: 1000 },
    { label: 'Try Again', icon: '🍀', color: 'bg-slate-600', valueCoins: 0 }
  ];

  const handleSpin = async () => {
    if (spinning) return;
    if (currentUser && currentUser.coins < 100) {
      showNotification('You need at least 100 coins per spin!');
      return;
    }

    setSpinning(true);
    setLastWon(null);

    try {
      if (currentUser) {
        await ApiClient.rechargeCoins(currentUser.id, -100);
        await refreshUser();
      }
    } catch (e) {}

    const randomIdx = Math.floor(Math.random() * prizes.length);
    const spinDegrees = 1800 + (randomIdx * 60); // 5 full spins + offset
    setRotation(prev => prev + spinDegrees);

    setTimeout(async () => {
      setSpinning(false);
      const won = prizes[randomIdx];
      setLastWon(won.label);
      if (won.valueCoins > 0 && currentUser) {
        try {
          await ApiClient.rechargeCoins(currentUser.id, won.valueCoins);
          await refreshUser();
        } catch (e) {}
      }
      showNotification(`🎉 Congratulations! You won: ${won.label}!`);
    }, 3500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xl overflow-y-auto p-4 animate-fadeIn text-white space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-white/10 pb-3">
        <div className="flex items-center gap-3">
          <button onClick={() => setActiveModal('none')} className="p-2 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/10">
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-lg font-black flex items-center gap-2">
              <Flame className="w-5 h-5 text-pink-400 animate-bounce" /> Daily Spin & Win
            </h2>
            <p className="text-xs text-slate-300">Spin the wheel for a chance at luxury gifts & diamonds!</p>
          </div>
        </div>
        <span className="text-xs bg-amber-500 text-black font-black px-2.5 py-1 rounded-xl shadow">
          🪙 {currentUser?.coins?.toLocaleString() || 0}
        </span>
      </div>

      {/* Wheel Area */}
      <div className="flex flex-col items-center justify-center py-6 space-y-6">
        <div className="relative">
          {/* Top Pointer */}
          <div className="absolute -top-4 left-1/2 -translate-x-1/2 z-20 w-8 h-8 bg-red-600 rounded-full flex items-center justify-center shadow-lg border-2 border-white">
            ▼
          </div>

          {/* The Spinning Wheel */}
          <div 
            style={{ transform: `rotate(${rotation}deg)`, transition: 'transform 3.5s cubic-bezier(0.17, 0.67, 0.12, 0.99)' }}
            className="w-64 h-64 rounded-full border-8 border-amber-400 shadow-[0_0_40px_rgba(245,158,11,0.4)] relative overflow-hidden bg-black/60 backdrop-blur-xl flex items-center justify-center"
          >
            <div className="grid grid-cols-2 grid-rows-3 w-full h-full text-center">
              {prizes.map((p, i) => (
                <div key={i} className={`${p.color} flex flex-col items-center justify-center p-2 border border-black/20 text-xs font-black text-white`}>
                  <span className="text-2xl">{p.icon}</span>
                  <span className="text-[10px] truncate w-full">{p.label}</span>
                </div>
              ))}
            </div>
            {/* Center Circle */}
            <div className="absolute w-16 h-16 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-600 border-4 border-white flex items-center justify-center shadow-2xl">
              <Sparkles className="w-6 h-6 text-black animate-spin" />
            </div>
          </div>
        </div>

        {lastWon && (
          <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/30 to-pink-500/30 backdrop-blur-xl border border-amber-400 text-center animate-bounce shadow-xl">
            <h4 className="text-sm font-black text-amber-300">🎉 YOU WON: {lastWon}</h4>
          </div>
        )}

        <button
          onClick={handleSpin}
          disabled={spinning}
          className="px-10 py-4 bg-gradient-to-r from-pink-600 via-purple-600 to-amber-500 hover:scale-110 disabled:opacity-50 text-white font-black text-base rounded-3xl shadow-[0_0_30px_rgba(236,72,153,0.5)] transition-all flex items-center gap-2"
        >
          <RotateCw className={`w-5 h-5 ${spinning ? 'animate-spin' : ''}`} />
          {spinning ? 'SPINNING...' : 'SPIN WHEEL (100 🪙)'}
        </button>
      </div>

      {/* Rewards Table */}
      <div className="bg-white/5 backdrop-blur-xl p-5 rounded-3xl border border-white/10 space-y-3 shadow-xl">
        <h4 className="font-bold text-white text-xs">Wheel Prizes & Probabilities</h4>
        <div className="grid grid-cols-2 gap-2 text-xs">
          {prizes.map((p, i) => (
            <div key={i} className="p-2.5 rounded-xl bg-black/40 border border-white/10 flex items-center justify-between">
              <span className="font-bold text-white flex items-center gap-1.5">{p.icon} {p.label}</span>
              <span className="text-[10px] text-slate-400">16.6% chance</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
