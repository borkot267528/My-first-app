/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export { VoiceRoom } from './room/VoiceRoom';
export type { VoiceRoomProps, VoiceRoomGridProps, ParticipantAvatarItem } from './room/VoiceRoom';
export { VoiceRoom as default } from './room/VoiceRoom';
