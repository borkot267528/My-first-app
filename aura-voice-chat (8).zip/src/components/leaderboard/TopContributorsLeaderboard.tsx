/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { 
  Trophy, Crown, Sparkles, Flame, Gift, Coins, Gem, 
  ChevronRight, RefreshCw, X, Radio, ArrowUpRight, ArrowDownRight, 
  Minus, Search, Share2, Heart, Shield, Check, UserPlus
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ApiClient } from '../../lib/api';
import { 
  ContributorLeaderboardCategory, 
  ContributorLeaderboardPeriod, 
  ContributorLeaderboardItem, 
  ContributorLeaderboardResponse,
  MicSeat,
  Gift as GiftType
} from '../../types';
import { ProfileIdBadge } from '../common/ProfileIdBadge';

export interface TopContributorsLeaderboardProps {
  onClose?: () => void;
  isModal?: boolean;
  defaultCategory?: ContributorLeaderboardCategory;
  defaultPeriod?: ContributorLeaderboardPeriod;
  onSelectUserForGift?: (user: { id: string; name: string; avatar: string }) => void;
  roomId?: string;
}

export const TopContributorsLeaderboard: React.FC<TopContributorsLeaderboardProps> = ({
  onClose,
  isModal = true,
  defaultCategory = 'earners',
  defaultPeriod = 'daily',
  onSelectUserForGift,
  roomId
}) => {
  const { currentUser, setActiveModal, showNotification, setActiveRoom } = useApp();

  const [category, setCategory] = useState<ContributorLeaderboardCategory>(defaultCategory);
  const [period, setPeriod] = useState<ContributorLeaderboardPeriod>(defaultPeriod);
  const [searchQuery, setSearchQuery] = useState('');
  const [data, setData] = useState<ContributorLeaderboardResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [isLiveActive, setIsLiveActive] = useState(true);
  const [lastUpdateSecondsAgo, setLastUpdateSecondsAgo] = useState(0);

  const pollTimerRef = useRef<any>(null);
  const updateTickerRef = useRef<any>(null);

  // Fetch leaderboard data from API
  const fetchLeaderboard = useCallback(async (isSilent = false) => {
    if (!isSilent) setRefreshing(true);
    try {
      const res = await ApiClient.getTopContributors(category, period, 50);
      setData(res);
      setLastUpdateSecondsAgo(0);
    } catch (err: any) {
      if (!isSilent) {
        showNotification(err.message || 'Failed to load leaderboard data');
      }
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [category, period, showNotification]);

  // Initial fetch and on category/period change
  useEffect(() => {
    fetchLeaderboard(false);
  }, [fetchLeaderboard]);

  // Real-time Event Listeners & Auto-Polling
  useEffect(() => {
    const handleLiveGiftEvent = (e: any) => {
      // Re-fetch leaderboard with smooth background refresh on live gift
      fetchLeaderboard(true);
    };

    window.addEventListener('aura_leaderboard_updated', handleLiveGiftEvent);
    window.addEventListener('aura_gift_sent', handleLiveGiftEvent);

    // Auto-polling every 8 seconds when live is active
    if (isLiveActive) {
      pollTimerRef.current = setInterval(() => {
        fetchLeaderboard(true);
      }, 8000);
    }

    // Ticker for seconds since last refresh
    updateTickerRef.current = setInterval(() => {
      setLastUpdateSecondsAgo(prev => prev + 1);
    }, 1000);

    return () => {
      window.removeEventListener('aura_leaderboard_updated', handleLiveGiftEvent);
      window.removeEventListener('aura_gift_sent', handleLiveGiftEvent);
      if (pollTimerRef.current) clearInterval(pollTimerRef.current);
      if (updateTickerRef.current) clearInterval(updateTickerRef.current);
    };
  }, [isLiveActive, fetchLeaderboard]);

  // Format large numbers (e.g. 1,450,200 -> 1.45M)
  const formatNumber = (num: number = 0) => {
    if (num >= 1_000_000) return (num / 1_000_000).toFixed(2) + 'M';
    if (num >= 1_000) return (num / 1_000).toFixed(1) + 'k';
    return num.toLocaleString();
  };

  const allItems = data?.topItems || [];
  const filteredItems = searchQuery.trim()
    ? allItems.filter(item => 
        item.name.toLowerCase().includes(searchQuery.toLowerCase().trim()) ||
        item.uid.toLowerCase().includes(searchQuery.toLowerCase().trim())
      )
    : allItems;

  const top1 = filteredItems[0];
  const top2 = filteredItems[1];
  const top3 = filteredItems[2];
  const restItems = filteredItems.slice(3);

  const handleSendGiftTo = (item: ContributorLeaderboardItem) => {
    if (onSelectUserForGift) {
      onSelectUserForGift({
        id: item.userId,
        name: item.name,
        avatar: item.avatar
      });
      if (onClose) onClose();
    } else {
      showNotification(`Opening gift sender for ${item.name}...`);
      if (onClose) onClose();
      setActiveModal('vip_shop');
    }
  };

  const handleJoinUserRoom = async (targetRoomId: string) => {
    try {
      const roomData = await ApiClient.getRoomById(targetRoomId);
      if (roomData && roomData.room) {
        setActiveRoom(roomData.room);
        showNotification(`Entering ${roomData.room.title}!`);
        if (onClose) onClose();
      }
    } catch {
      showNotification('Joining Voice Room...');
    }
  };

  const content = (
    <div className="flex flex-col h-full bg-[#120826]/95 backdrop-blur-2xl text-white overflow-hidden rounded-t-[32px] sm:rounded-[32px] border-t sm:border border-white/15 shadow-[0_25px_80px_rgba(0,0,0,0.85)]">
      {/* MOBILE PULL HANDLE */}
      <div className="pt-3 pb-1 sm:hidden">
        <div className="w-12 h-1.5 bg-white/20 rounded-full mx-auto" />
      </div>

      {/* HEADER SECTION */}
      <div className="px-5 py-3.5 border-b border-white/10 flex items-center justify-between bg-white/[0.03]">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-400 via-pink-500 to-purple-600 p-[1.5px] flex items-center justify-center shadow-lg">
            <div className="w-full h-full bg-[#160a2c] rounded-[14px] flex items-center justify-center">
              <Trophy className="w-5 h-5 text-amber-300 animate-pulse" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-black text-white text-base tracking-wide flex items-center gap-1.5">
                Top Contributors Leaderboard
              </h3>
              {/* LIVE SYNC BADGE */}
              <div 
                onClick={() => setIsLiveActive(!isLiveActive)}
                className={`cursor-pointer px-2 py-0.5 rounded-full text-[10px] font-extrabold flex items-center gap-1.5 border transition-all ${
                  isLiveActive 
                    ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 animate-pulse' 
                    : 'bg-white/10 text-slate-400 border-white/15'
                }`}
                title={isLiveActive ? 'Real-time updates active. Tap to pause.' : 'Real-time updates paused. Tap to enable.'}
              >
                <span className={`w-1.5 h-1.5 rounded-full ${isLiveActive ? 'bg-rose-500' : 'bg-slate-400'}`} />
                <span>{isLiveActive ? 'LIVE REAL-TIME' : 'PAUSED'}</span>
              </div>
            </div>
            <p className="text-[11px] text-slate-300">
              Rankings based on virtual gift earnings, patron gifting & community engagement
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => fetchLeaderboard(false)}
            disabled={refreshing}
            className="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white flex items-center justify-center transition-all active:scale-90 cursor-pointer"
            title="Refresh Leaderboard"
          >
            <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin text-amber-300' : ''}`} />
          </button>

          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white flex items-center justify-center transition-all active:scale-90 cursor-pointer"
              title="Close"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* CATEGORY & TIMEFRAME CONTROLS */}
      <div className="p-3 bg-black/40 border-b border-white/10 space-y-2.5">
        {/* Category Filter Tabs */}
        <div className="grid grid-cols-3 gap-1.5 bg-black/50 p-1 rounded-2xl border border-white/10">
          <button
            type="button"
            onClick={() => setCategory('earners')}
            className={`py-2 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              category === 'earners'
                ? 'bg-gradient-to-r from-amber-500 to-pink-500 text-black shadow-md'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <Gem className="w-3.5 h-3.5" />
            <span>Gift Earners</span>
          </button>

          <button
            type="button"
            onClick={() => setCategory('senders')}
            className={`py-2 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              category === 'senders'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-black shadow-md'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <Coins className="w-3.5 h-3.5" />
            <span>Top Givers</span>
          </button>

          <button
            type="button"
            onClick={() => setCategory('engagement')}
            className={`py-2 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              category === 'engagement'
                ? 'bg-gradient-to-r from-purple-500 to-indigo-600 text-white shadow-md'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <Flame className="w-3.5 h-3.5" />
            <span>Engagement</span>
          </button>
        </div>

        {/* Timeframe & Search Row */}
        <div className="flex items-center justify-between gap-2">
          {/* Period selector */}
          <div className="flex items-center gap-1 bg-white/5 p-1 rounded-xl border border-white/10">
            {[
              { id: 'daily' as ContributorLeaderboardPeriod, label: 'Today' },
              { id: 'weekly' as ContributorLeaderboardPeriod, label: 'This Week' },
              { id: 'all' as ContributorLeaderboardPeriod, label: 'All-Time' },
            ].map(p => (
              <button
                key={p.id}
                type="button"
                onClick={() => setPeriod(p.id)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                  period === p.id
                    ? 'bg-purple-600 text-white shadow'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>

          {/* Quick Search Input */}
          <div className="relative flex-1 max-w-[170px] sm:max-w-[220px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search contributor..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-black/50 text-[11px] text-white pl-8 pr-3 py-1.5 rounded-xl border border-white/10 focus:outline-none focus:border-amber-400"
            />
          </div>
        </div>
      </div>

      {/* MAIN BODY (SCROLLABLE) */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4 no-scrollbar">
        {loading ? (
          <div className="py-16 text-center space-y-3">
            <RefreshCw className="w-8 h-8 text-amber-400 animate-spin mx-auto" />
            <p className="text-xs text-slate-300 font-medium">Calculating real-time gift contributions...</p>
          </div>
        ) : filteredItems.length === 0 ? (
          <div className="py-16 text-center space-y-2">
            <Trophy className="w-10 h-10 text-slate-600 mx-auto" />
            <h4 className="font-extrabold text-sm text-slate-300">No contributors found</h4>
            <p className="text-xs text-slate-400">Be the first to send a gift and claim rank #1!</p>
          </div>
        ) : (
          <>
            {/* TOP 3 PODIUM STAGE */}
            {!searchQuery && top1 && (
              <div className="pt-2 pb-4">
                <div className="grid grid-cols-3 gap-2 items-end max-w-md mx-auto">
                  {/* #2 SILVER (LEFT) */}
                  {top2 && (
                    <div className="flex flex-col items-center animate-fadeIn">
                      <div className="relative group cursor-pointer mb-2" onClick={() => handleSendGiftTo(top2)}>
                        <img 
                          src={top2.avatar} 
                          alt={top2.name} 
                          className="w-14 h-14 sm:w-16 sm:h-16 rounded-full object-cover border-2 border-slate-300 shadow-[0_0_15px_rgba(203,213,225,0.4)]"
                        />
                        <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-6 h-6 rounded-full bg-slate-300 text-black flex items-center justify-center font-black text-xs shadow-md">
                          🥈
                        </div>
                        {top2.isOnline && (
                          <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-400 border-2 border-[#120826]" />
                        )}
                      </div>
                      <span className="font-extrabold text-xs text-white truncate max-w-[90px] text-center">
                        {top2.name}
                      </span>
                      <ProfileIdBadge uid={top2.uid} size="xs" canCopy={false} />
                      <div className="mt-1 px-2 py-0.5 rounded-full bg-slate-400/20 text-slate-200 border border-slate-400/30 text-[10px] font-black">
                        {category === 'earners' && `💎 ${formatNumber(top2.diamondsEarned)}`}
                        {category === 'senders' && `🪙 ${formatNumber(top2.totalCoinsSpent)}`}
                        {category === 'engagement' && `🔥 ${formatNumber(top2.engagementScore)}`}
                      </div>

                      {/* Silver Podium Pedestal */}
                      <div className="w-full h-16 sm:h-20 mt-2 bg-gradient-to-t from-slate-800 to-slate-700/80 rounded-t-2xl border-t border-slate-400/50 flex flex-col items-center justify-center shadow-lg">
                        <span className="text-xl font-black text-slate-300">#2</span>
                        <span className="text-[9px] uppercase font-bold text-slate-400">Silver</span>
                      </div>
                    </div>
                  )}

                  {/* #1 GOLD CHAMPION (CENTER, TALLEST) */}
                  {top1 && (
                    <div className="flex flex-col items-center animate-fadeIn z-10">
                      <div className="relative group cursor-pointer mb-2" onClick={() => handleSendGiftTo(top1)}>
                        {/* Animated Golden Crown */}
                        <Crown className="w-7 h-7 text-amber-400 fill-amber-400 absolute -top-5 left-1/2 -translate-x-1/2 drop-shadow-[0_0_12px_rgba(251,191,36,0.8)] animate-bounce" />
                        <img 
                          src={top1.avatar} 
                          alt={top1.name} 
                          className="w-18 h-18 sm:w-20 sm:h-20 rounded-full object-cover border-4 border-amber-400 shadow-[0_0_25px_rgba(251,191,36,0.7)]"
                        />
                        <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-7 h-7 rounded-full bg-gradient-to-tr from-amber-400 to-yellow-300 text-black flex items-center justify-center font-black text-xs shadow-md border border-white">
                          🥇
                        </div>
                        {top1.isOnline && (
                          <span className="absolute bottom-1 right-1 w-3.5 h-3.5 rounded-full bg-emerald-400 border-2 border-[#120826]" />
                        )}
                      </div>
                      <span className="font-black text-sm text-amber-300 truncate max-w-[110px] text-center mt-1">
                        {top1.name}
                      </span>
                      <ProfileIdBadge uid={top1.uid} size="xs" canCopy={false} />
                      <div className="mt-1 px-2.5 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/40 text-[11px] font-black shadow-sm">
                        {category === 'earners' && `💎 ${formatNumber(top1.diamondsEarned)}`}
                        {category === 'senders' && `🪙 ${formatNumber(top1.totalCoinsSpent)}`}
                        {category === 'engagement' && `🔥 ${formatNumber(top1.engagementScore)}`}
                      </div>

                      {/* Gold Podium Pedestal */}
                      <div className="w-full h-22 sm:h-26 mt-2 bg-gradient-to-t from-amber-900/60 via-amber-800/80 to-amber-600 rounded-t-2xl border-t-2 border-amber-300 flex flex-col items-center justify-center shadow-[0_0_20px_rgba(251,191,36,0.25)]">
                        <span className="text-2xl font-black text-amber-200">#1</span>
                        <span className="text-[10px] uppercase font-black tracking-wider text-amber-100">Champion</span>
                      </div>
                    </div>
                  )}

                  {/* #3 BRONZE (RIGHT) */}
                  {top3 && (
                    <div className="flex flex-col items-center animate-fadeIn">
                      <div className="relative group cursor-pointer mb-2" onClick={() => handleSendGiftTo(top3)}>
                        <img 
                          src={top3.avatar} 
                          alt={top3.name} 
                          className="w-14 h-14 sm:w-16 sm:h-16 rounded-full object-cover border-2 border-amber-700 shadow-[0_0_15px_rgba(180,83,9,0.4)]"
                        />
                        <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-6 h-6 rounded-full bg-amber-700 text-amber-100 flex items-center justify-center font-black text-xs shadow-md">
                          🥉
                        </div>
                        {top3.isOnline && (
                          <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-400 border-2 border-[#120826]" />
                        )}
                      </div>
                      <span className="font-extrabold text-xs text-white truncate max-w-[90px] text-center">
                        {top3.name}
                      </span>
                      <ProfileIdBadge uid={top3.uid} size="xs" canCopy={false} />
                      <div className="mt-1 px-2 py-0.5 rounded-full bg-amber-800/30 text-amber-200 border border-amber-700/40 text-[10px] font-black">
                        {category === 'earners' && `💎 ${formatNumber(top3.diamondsEarned)}`}
                        {category === 'senders' && `🪙 ${formatNumber(top3.totalCoinsSpent)}`}
                        {category === 'engagement' && `🔥 ${formatNumber(top3.engagementScore)}`}
                      </div>

                      {/* Bronze Podium Pedestal */}
                      <div className="w-full h-14 sm:h-16 mt-2 bg-gradient-to-t from-stone-900 to-amber-950/80 rounded-t-2xl border-t border-amber-700 flex flex-col items-center justify-center shadow-lg">
                        <span className="text-xl font-black text-amber-400">#3</span>
                        <span className="text-[9px] uppercase font-bold text-amber-500/80">Bronze</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* RANKED LIST (#4 TO #50, OR SEARCH RESULTS) */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-[11px] text-slate-400 uppercase font-black tracking-wider px-2">
                <span>Rank & Contributor</span>
                <span>{category === 'earners' ? 'Diamonds Earned' : category === 'senders' ? 'Coins Contributed' : 'Engagement Score'}</span>
              </div>

              {(searchQuery ? filteredItems : restItems).map((item) => (
                <div
                  key={item.userId}
                  className="p-3 rounded-2xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 hover:border-white/20 transition-all flex items-center justify-between gap-3 group shadow-md"
                >
                  {/* Rank & User Info */}
                  <div className="flex items-center gap-3 min-w-0">
                    {/* Rank Badge + Trend */}
                    <div className="w-9 flex flex-col items-center justify-center">
                      <span className={`text-sm font-black ${item.rank <= 3 ? 'text-amber-400' : 'text-slate-300'}`}>
                        #{item.rank}
                      </span>
                      {item.trend === 'up' && (
                        <span className="text-[9px] text-emerald-400 font-bold flex items-center">
                          <ArrowUpRight className="w-2.5 h-2.5" />{item.trendPositions}
                        </span>
                      )}
                      {item.trend === 'down' && (
                        <span className="text-[9px] text-rose-400 font-bold flex items-center">
                          <ArrowDownRight className="w-2.5 h-2.5" />{item.trendPositions}
                        </span>
                      )}
                      {item.trend === 'same' && (
                        <span className="text-[9px] text-slate-500">
                          <Minus className="w-2.5 h-2.5" />
                        </span>
                      )}
                    </div>

                    {/* Avatar & Badges */}
                    <div className="relative shrink-0">
                      <img 
                        src={item.avatar} 
                        alt={item.name} 
                        className="w-11 h-11 rounded-2xl object-cover border border-white/20 group-hover:scale-105 transition-transform"
                      />
                      {item.isOnline && (
                        <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-400 border-2 border-[#120826]" />
                      )}
                    </div>

                    {/* Details */}
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <h5 className="font-extrabold text-white text-xs truncate max-w-[130px] sm:max-w-[180px]">
                          {item.name}
                        </h5>
                        {item.countryFlag && <span className="text-xs">{item.countryFlag}</span>}
                        {item.vipLevel === 'svip' && (
                          <span className="text-[9px] font-black px-1 rounded bg-amber-500 text-black shadow">
                            SVIP
                          </span>
                        )}
                        {item.vipLevel === 'vip' && (
                          <span className="text-[9px] font-black px-1 rounded bg-purple-500 text-white shadow">
                            VIP
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                        <ProfileIdBadge uid={item.uid} size="xs" canCopy={true} />
                        <span className="text-[10px] text-amber-300/80 font-bold">
                          💰 Lv.{item.sendingLevel}
                        </span>
                        <span className="text-[10px] text-pink-300/80 font-bold">
                          💎 Lv.{item.receivingLevel}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Metrics & Action Button */}
                  <div className="flex items-center gap-2.5 shrink-0">
                    <div className="text-right">
                      <h4 className="font-black text-sm text-amber-300 flex items-center justify-end gap-1">
                        {category === 'earners' && (
                          <>
                            <span>💎</span>
                            <span>{formatNumber(item.diamondsEarned)}</span>
                          </>
                        )}
                        {category === 'senders' && (
                          <>
                            <span>🪙</span>
                            <span>{formatNumber(item.totalCoinsSpent)}</span>
                          </>
                        )}
                        {category === 'engagement' && (
                          <>
                            <span>🔥</span>
                            <span>{formatNumber(item.engagementScore)}</span>
                          </>
                        )}
                      </h4>
                      <p className="text-[10px] text-slate-400">
                        {category === 'earners' ? `${item.giftsReceivedCount} gifts rec'd` : `${item.giftsSentCount} gifts sent`}
                      </p>
                    </div>

                    {/* Send Gift Action */}
                    <button
                      type="button"
                      onClick={() => handleSendGiftTo(item)}
                      className="p-2 rounded-xl bg-gradient-to-r from-amber-500 to-pink-500 hover:from-amber-400 hover:to-pink-400 text-black shadow transition-all active:scale-95 cursor-pointer"
                      title={`Send Gift to ${item.name}`}
                    >
                      <Gift className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      {/* STICKY CURRENT USER FOOTER RANK BAR */}
      {data?.currentUserRank && currentUser && (
        <div className="p-3.5 border-t border-white/10 bg-black/80 backdrop-blur-xl flex items-center justify-between z-20">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-purple-500/20 border border-purple-400/40 text-purple-300 flex items-center justify-center font-black text-xs">
              #{data.currentUserRank.rank}
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-black text-white">Your Ranking</span>
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300 font-bold border border-purple-500/30">
                  {currentUser.name}
                </span>
              </div>
              <p className="text-[10px] text-slate-300">
                {data.currentUserRank.diffToNextRank > 0 ? (
                  <>Needs <b className="text-amber-300">{formatNumber(data.currentUserRank.diffToNextRank)}</b> to rank up!</>
                ) : (
                  <span className="text-emerald-300 font-bold">Top Position! 🏆</span>
                )}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="text-right">
              <span className="text-xs font-black text-amber-300 block">
                {formatNumber(data.currentUserRank.score)}
              </span>
              <span className="text-[9px] uppercase font-bold text-slate-400">Your Score</span>
            </div>

            <button
              type="button"
              onClick={() => {
                if (onClose) onClose();
                setActiveModal('wallet');
              }}
              className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 text-black font-black text-xs shadow hover:opacity-95 transition-opacity cursor-pointer"
            >
              Recharge +
            </button>
          </div>
        </div>
      )}
    </div>
  );

  if (!isModal) {
    return content;
  }

  return (
    <div 
      className="fixed inset-0 z-[85] bg-black/80 backdrop-blur-xl flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fadeIn"
      onClick={(e) => {
        if (e.target === e.currentTarget && onClose) onClose();
      }}
    >
      <div className="w-full max-w-xl h-[92vh] sm:h-[86vh] flex flex-col animate-scaleUp">
        {content}
      </div>
    </div>
  );
};
