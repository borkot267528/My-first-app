/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  User as UserIcon, X, MessageSquare, Gift, Heart, UserMinus, 
  ShieldAlert, Sparkles, Calendar, Award, ArrowUpRight, ArrowDownRight,
  MapPin, CheckCircle2, UserPlus, Flame
} from 'lucide-react';
import { User, Connection } from '../../types';
import { useApp } from '../../context/AppContext';
import { ApiClient } from '../../lib/api';
import { ProfileIdBadge } from '../common/ProfileIdBadge';
import { StaffIdentityBadgeCard } from '../profile/StaffIdentityBadgeCard';
import { getEffectiveStaffIdentity } from '../../lib/staffIdentity';

interface FriendProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: User;
  connection?: Connection | null;
  onMessage?: (user: User) => void;
  onSendGift?: (user: User) => void;
  onConnectionUpdated?: () => void;
}

export const FriendProfileModal: React.FC<FriendProfileModalProps> = ({
  isOpen,
  onClose,
  user,
  connection,
  onMessage,
  onSendGift,
  onConnectionUpdated
}) => {
  const { showNotification, currentUser } = useApp();
  const [isProcessing, setIsProcessing] = useState(false);
  const [showConfirmRemove, setShowConfirmRemove] = useState(false);
  const [showConfirmBlock, setShowConfirmBlock] = useState(false);

  if (!isOpen || !user) return null;

  const staffIdentity = getEffectiveStaffIdentity(user);

  // Connection duration
  let connectionDays = 1;
  if (connection?.establishedAt) {
    const diffMs = Date.now() - new Date(connection.establishedAt).getTime();
    connectionDays = Math.max(1, Math.floor(diffMs / (1000 * 60 * 60 * 24)));
  }

  const handleRemove = async () => {
    if (!connection) return;
    setIsProcessing(true);
    try {
      await ApiClient.removeConnection(connection.id);
      showNotification(`Connection with ${user.name} has been removed.`);
      if (onConnectionUpdated) onConnectionUpdated();
      setShowConfirmRemove(false);
      onClose();
    } catch (err: any) {
      showNotification(err?.message || 'Failed to remove connection.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleBlock = async () => {
    setIsProcessing(true);
    try {
      await ApiClient.blockUser(user.id);
      showNotification(`${user.name} has been blocked.`);
      if (onConnectionUpdated) onConnectionUpdated();
      setShowConfirmBlock(false);
      onClose();
    } catch (err: any) {
      showNotification(err?.message || 'Failed to block user.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSendRequest = async (type: 'friend' | 'cp') => {
    setIsProcessing(true);
    try {
      await ApiClient.sendConnectionRequest(user.id, type);
      showNotification(`${type === 'cp' ? 'CP Proposal' : 'Friend request'} sent to ${user.name}!`);
      if (onConnectionUpdated) onConnectionUpdated();
    } catch (err: any) {
      showNotification(err?.message || 'Failed to send request.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[120] flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div 
        className="w-full max-w-md bg-[#13072b] border border-white/15 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Banner / Cover Header */}
        <div className="relative h-28 bg-gradient-to-r from-purple-900 via-indigo-950 to-pink-900 p-4 flex items-start justify-between">
          <div className="flex items-center gap-2">
            {connection?.type === 'cp' && (
              <span className="px-3 py-1 rounded-full bg-pink-500/80 text-white font-black text-[11px] shadow-lg flex items-center gap-1">
                <Heart className="w-3 h-3 fill-white" /> CP PARTNER • LV.{connection.level}
              </span>
            )}
            {connection?.type === 'friend' && (
              <span className="px-3 py-1 rounded-full bg-blue-500/80 text-white font-bold text-[11px] shadow-lg flex items-center gap-1">
                👥 FRIENDS • {connectionDays} DAYS
              </span>
            )}
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-xl bg-black/50 hover:bg-black/80 text-white transition-all backdrop-blur-md"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Profile Card Body */}
        <div className="px-5 pb-5 -mt-10 overflow-y-auto space-y-4">
          {/* Avatar & Main Identity */}
          <div className="flex items-end justify-between">
            <div className="relative group">
              <div className="w-20 h-20 rounded-3xl p-1 bg-gradient-to-tr from-amber-400 via-pink-500 to-purple-600 shadow-xl">
                <img 
                  src={user.avatar} 
                  alt={user.name} 
                  className="w-full h-full rounded-2xl object-cover border-2 border-black" 
                />
              </div>
              <div className="absolute -bottom-2 -left-1 -right-1 flex justify-between gap-1 pointer-events-none">
                <span className="bg-gradient-to-r from-amber-400 to-amber-600 text-black text-[9px] font-black px-1.5 py-0.5 rounded-full shadow border border-amber-300">
                  <ArrowUpRight className="w-2.5 h-2.5 inline" /> Lv.{user.sendingLevel || user.level || 1}
                </span>
                <span className="bg-gradient-to-r from-cyan-400 to-blue-600 text-white text-[9px] font-black px-1.5 py-0.5 rounded-full shadow border border-cyan-300">
                  <ArrowDownRight className="w-2.5 h-2.5 inline" /> Lv.{user.receivingLevel || 1}
                </span>
              </div>
            </div>

            {/* Quick Gifting / Messaging buttons */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  if (onMessage) onMessage(user);
                  onClose();
                }}
                className="p-2.5 rounded-2xl bg-white/10 hover:bg-purple-600 text-white border border-white/15 transition-all shadow"
                title="Message"
              >
                <MessageSquare className="w-4 h-4" />
              </button>
              <button
                onClick={() => {
                  if (onSendGift) onSendGift(user);
                  onClose();
                }}
                className="p-2.5 rounded-2xl bg-gradient-to-r from-amber-400 to-yellow-500 text-black font-black hover:scale-105 transition-all shadow"
                title="Send Gift"
              >
                <Gift className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* User Details */}
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-base font-black text-white">{user.name}</h3>
              {user.countryFlag && <span title={user.country}>{user.countryFlag}</span>}
              {user.vipLevel === 'svip' && (
                <span className="bg-gradient-to-r from-amber-400 to-yellow-600 text-black text-[10px] font-black px-1.5 py-0.2 rounded shadow">
                  SVIP
                </span>
              )}
            </div>

            <ProfileIdBadge uid={user.uid || user.id} size="sm" canCopy={true} />

            {user.bio && (
              <p className="text-xs text-slate-300 pt-1 leading-relaxed">{user.bio}</p>
            )}
          </div>

          {/* Staff Badge if Applicable */}
          {staffIdentity && staffIdentity.role !== 'user' && (
            <StaffIdentityBadgeCard identity={staffIdentity} compact={true} />
          )}

          {/* Mutual Connection Stats Box */}
          {connection && (
            <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md space-y-2.5">
              <div className="flex items-center justify-between text-xs font-bold text-slate-300">
                <span className="flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-pink-400" /> Connection Statistics
                </span>
                <span className="text-pink-300 font-mono">
                  {connection.type.toUpperCase()} STATUS
                </span>
              </div>

              <div className="grid grid-cols-3 gap-2 text-center pt-1">
                <div className="p-2 rounded-xl bg-black/40 border border-white/5">
                  <span className="text-[10px] text-slate-400 block">Days Together</span>
                  <span className="text-xs font-black text-amber-300 font-mono">
                    {connectionDays} Days
                  </span>
                </div>
                <div className="p-2 rounded-xl bg-black/40 border border-white/5">
                  <span className="text-[10px] text-slate-400 block">Intimacy</span>
                  <span className="text-xs font-black text-pink-400 font-mono">
                    {connection.intimacyPoints || 0} pts
                  </span>
                </div>
                <div className="p-2 rounded-xl bg-black/40 border border-white/5">
                  <span className="text-[10px] text-slate-400 block">Shared Gifts</span>
                  <span className="text-xs font-black text-purple-300 font-mono">
                    {connection.sharedGiftsCount || 0}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Danger Zone Actions */}
          <div className="pt-2 border-t border-white/10 space-y-2">
            {connection && (
              <>
                {showConfirmRemove ? (
                  <div className="p-3 rounded-2xl bg-red-950/40 border border-red-500/40 space-y-2">
                    <p className="text-xs text-red-200">
                      Are you sure you want to remove this connection with {user.name}? This will reset connection intimacy and history.
                    </p>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={handleRemove}
                        disabled={isProcessing}
                        className="flex-1 py-1.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-black text-xs transition-colors"
                      >
                        {isProcessing ? 'Removing...' : 'Yes, Remove'}
                      </button>
                      <button
                        onClick={() => setShowConfirmRemove(false)}
                        className="px-3 py-1.5 rounded-xl bg-white/10 text-slate-300 text-xs hover:bg-white/20"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <button
                    onClick={() => setShowConfirmRemove(true)}
                    className="w-full py-2.5 rounded-xl bg-white/5 hover:bg-red-500/20 text-red-300 border border-white/10 hover:border-red-500/30 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <UserMinus className="w-3.5 h-3.5 text-red-400" />
                    <span>{connection.type === 'cp' ? 'Remove CP Connection' : 'Remove Friend'}</span>
                  </button>
                )}
              </>
            )}

            {showConfirmBlock ? (
              <div className="p-3 rounded-2xl bg-red-950/40 border border-red-500/40 space-y-2">
                <p className="text-xs text-red-200">
                  Block {user.name}? They will no longer be able to message you, join your rooms, or view your profile.
                </p>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleBlock}
                    disabled={isProcessing}
                    className="flex-1 py-1.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-black text-xs transition-colors"
                  >
                    {isProcessing ? 'Blocking...' : 'Yes, Block User'}
                  </button>
                  <button
                    onClick={() => setShowConfirmBlock(false)}
                    className="px-3 py-1.5 rounded-xl bg-white/10 text-slate-300 text-xs hover:bg-white/20"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <button
                onClick={() => setShowConfirmBlock(true)}
                className="w-full py-2 rounded-xl text-slate-400 hover:text-red-400 text-xs flex items-center justify-center gap-1.5 transition-colors"
              >
                <ShieldAlert className="w-3.5 h-3.5" />
                <span>Block User</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
