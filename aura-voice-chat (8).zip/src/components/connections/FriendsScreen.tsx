/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { 
  Users, Search, UserPlus, UserMinus, MessageSquare, Gift, 
  X, Check, ShieldAlert, MoreVertical, Sparkles, Clock, 
  Send, UserCheck, Shield, ChevronRight
} from 'lucide-react';
import { Connection, ConnectionRequest, User } from '../../types';
import { useApp } from '../../context/AppContext';
import { ApiClient } from '../../lib/api';
import { ProfileIdBadge } from '../common/ProfileIdBadge';
import { SendGiftDirectModal } from './SendGiftDirectModal';
import { DirectMessageModal } from './DirectMessageModal';
import { FriendProfileModal } from './FriendProfileModal';

interface FriendsScreenProps {
  onClose?: () => void;
}

export const FriendsScreen: React.FC<FriendsScreenProps> = ({ onClose }) => {
  const { currentUser, showNotification } = useApp();
  const [activeTab, setActiveTab] = useState<'my_friends' | 'requests' | 'discover' | 'blocked'>('my_friends');
  const [friendsList, setFriendsList] = useState<User[]>([]);
  const [connectionsList, setConnectionsList] = useState<Connection[]>([]);
  const [incomingRequests, setIncomingRequests] = useState<ConnectionRequest[]>([]);
  const [outgoingRequests, setOutgoingRequests] = useState<ConnectionRequest[]>([]);
  const [discoverUsers, setDiscoverUsers] = useState<(User & { connectionStatus?: string })[]>([]);
  const [blockedUsers, setBlockedUsers] = useState<User[]>([]);

  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);

  // Modals & Action states
  const [activeTargetUser, setActiveTargetUser] = useState<User | null>(null);
  const [isGiftModalOpen, setIsGiftModalOpen] = useState(false);
  const [isMessageModalOpen, setIsMessageModalOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);

  // Add friend dialog
  const [addFriendTarget, setAddFriendTarget] = useState<User | null>(null);
  const [addFriendNote, setAddFriendNote] = useState('Hey! Let\'s connect and chat on Nigo Voice! 👥');
  const [isSendingRequest, setIsSendingRequest] = useState(false);

  // Quick Action menu popover
  const [activeActionMenuUserId, setActiveActionMenuUserId] = useState<string | null>(null);

  const fetchFriendsData = useCallback(async () => {
    setLoading(true);
    try {
      const [friendsRes, requestsRes, blockedRes] = await Promise.all([
        ApiClient.getFriends().catch(() => ({ connections: [], friends: [] })),
        ApiClient.getFriendRequests().catch(() => ({ incoming: [], outgoing: [] })),
        ApiClient.getBlockedUsers().catch(() => [])
      ]);
      setFriendsList(friendsRes.friends || []);
      setConnectionsList(friendsRes.connections || []);
      setIncomingRequests(requestsRes.incoming || []);
      setOutgoingRequests(requestsRes.outgoing || []);
      setBlockedUsers(blockedRes || []);
    } catch (err) {
      console.warn('Failed to fetch friends data', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchFriendsData();
  }, [fetchFriendsData]);

  // Discover search debounce
  useEffect(() => {
    if (activeTab === 'discover') {
      const timer = setTimeout(() => {
        ApiClient.discoverUsers(searchQuery)
          .then((res) => {
            const filtered = (res || []).filter(u => u.id !== currentUser?.id);
            setDiscoverUsers(filtered);
          })
          .catch(() => {});
      }, 300);
      return () => clearTimeout(timer);
    }
  }, [activeTab, searchQuery, currentUser?.id]);

  const handleAccept = async (requestId: string) => {
    try {
      await ApiClient.acceptConnectionRequest(requestId);
      showNotification('Friend request accepted! You are now connected.');
      await fetchFriendsData();
    } catch (err: any) {
      showNotification(err?.message || 'Failed to accept request');
    }
  };

  const handleDecline = async (requestId: string) => {
    try {
      await ApiClient.declineConnectionRequest(requestId);
      showNotification('Friend request declined');
      fetchFriendsData();
    } catch (err: any) {
      showNotification(err?.message || 'Failed to decline request');
    }
  };

  const handleCancelRequest = async (requestId: string) => {
    try {
      await ApiClient.cancelConnectionRequest(requestId);
      showNotification('Friend request cancelled');
      fetchFriendsData();
    } catch (err: any) {
      showNotification(err?.message || 'Failed to cancel request');
    }
  };

  const handleSendFriendRequest = async () => {
    if (!addFriendTarget) return;
    setIsSendingRequest(true);
    try {
      await ApiClient.sendConnectionRequest(addFriendTarget.id, 'friend', addFriendNote);
      showNotification(`Friend request sent to ${addFriendTarget.name}!`);
      setAddFriendTarget(null);
      fetchFriendsData();
    } catch (err: any) {
      showNotification(err?.message || 'Failed to send friend request');
    } finally {
      setIsSendingRequest(false);
    }
  };

  const handleRemoveFriend = async (friend: User) => {
    const conn = connectionsList.find(c => 
      (c.user1Id === friend.id && c.user2Id === currentUser?.id) ||
      (c.user2Id === friend.id && c.user1Id === currentUser?.id)
    );
    if (!conn) return;
    try {
      await ApiClient.removeConnection(conn.id);
      showNotification(`Removed ${friend.name} from friends.`);
      setActiveActionMenuUserId(null);
      fetchFriendsData();
    } catch (err: any) {
      showNotification(err?.message || 'Failed to remove friend');
    }
  };

  const handleBlockUser = async (user: User) => {
    try {
      await ApiClient.blockUser(user.id);
      showNotification(`${user.name} has been blocked.`);
      setActiveActionMenuUserId(null);
      fetchFriendsData();
    } catch (err: any) {
      showNotification(err?.message || 'Failed to block user');
    }
  };

  const handleUnblockUser = async (user: User) => {
    try {
      await ApiClient.unblockUser(user.id);
      showNotification(`Unblocked ${user.name}`);
      fetchFriendsData();
    } catch (err: any) {
      showNotification(err?.message || 'Failed to unblock user');
    }
  };

  // Filtered friends
  const filteredFriends = friendsList.filter(f => 
    !searchQuery || 
    f.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    (f.uid && String(f.uid).includes(searchQuery))
  );

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/85 backdrop-blur-xl p-0 sm:p-4 overflow-y-auto animate-fadeIn">
      <div 
        className="w-full max-w-lg bg-[#0d041c] border border-blue-500/20 rounded-none sm:rounded-3xl shadow-[0_0_50px_rgba(59,130,246,0.15)] flex flex-col min-h-screen sm:min-h-[85vh] max-h-screen sm:max-h-[90vh] overflow-hidden"
        onClick={e => e.stopPropagation()}
      >
        {/* HEADER */}
        <div className="p-4 bg-gradient-to-r from-blue-950/80 via-indigo-950/80 to-[#120526] border-b border-blue-500/20 flex items-center justify-between sticky top-0 z-20 backdrop-blur-md">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-500 to-indigo-500 flex items-center justify-center text-xl shadow-lg shadow-blue-500/30">
              👥
            </div>
            <div>
              <h2 className="text-base font-black text-white flex items-center gap-2 tracking-wide">
                Nigo Friends <span className="text-blue-400 text-xs">Social Network</span>
              </h2>
              <p className="text-[11px] text-blue-300/80 font-medium">
                {friendsList.length} Connected {friendsList.length === 1 ? 'Friend' : 'Friends'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* TABS */}
        <div className="flex items-center border-b border-white/10 bg-[#120626] px-2 pt-2">
          {[
            { id: 'my_friends', label: 'My Friends', icon: <Users className="w-4 h-4" />, count: friendsList.length },
            { id: 'requests', label: 'Requests', icon: <Clock className="w-4 h-4" />, count: incomingRequests.length, pulse: true },
            { id: 'discover', label: 'Discover', icon: <UserPlus className="w-4 h-4" /> },
            { id: 'blocked', label: 'Blocked', icon: <ShieldAlert className="w-4 h-4" />, count: blockedUsers.length }
          ].map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex-1 py-3 px-1 text-xs font-black flex items-center justify-center gap-1.5 border-b-2 transition-all relative ${
                  isActive 
                    ? 'border-blue-500 text-blue-300 bg-blue-500/10' 
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                {tab.icon}
                <span className="truncate">{tab.label}</span>
                {tab.count !== undefined && tab.count > 0 && (
                  <span className={`px-1.5 py-0.2 text-[10px] rounded-full font-mono font-bold ${
                    tab.id === 'requests' && tab.pulse 
                      ? 'bg-blue-500 text-white animate-pulse' 
                      : 'bg-white/15 text-slate-300'
                  }`}>
                    {tab.count}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* TAB CONTENTS */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* TAB 1: MY FRIENDS */}
          {activeTab === 'my_friends' && (
            <div className="space-y-3 animate-fadeIn">
              {/* Search Friends */}
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  placeholder="Search friends by name or ID..."
                  className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-black/40 border border-white/15 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
                />
              </div>

              {/* Friends List */}
              {filteredFriends.length === 0 ? (
                <div className="rounded-3xl p-8 bg-white/5 border border-white/10 text-center space-y-4">
                  <div className="w-16 h-16 mx-auto rounded-full bg-blue-500/10 border border-blue-400/20 flex items-center justify-center text-3xl">
                    👥
                  </div>
                  <div className="space-y-1">
                    <h4 className="text-sm font-bold text-white">No Friends Found</h4>
                    <p className="text-xs text-slate-400 max-w-xs mx-auto">
                      {searchQuery ? 'No matching friends found.' : 'You haven\'t added any friends yet. Explore discover to connect!'}
                    </p>
                  </div>
                  <button
                    onClick={() => setActiveTab('discover')}
                    className="px-5 py-2 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md transition-all"
                  >
                    Discover Friends
                  </button>
                </div>
              ) : (
                <div className="space-y-2">
                  {filteredFriends.map((friend) => {
                    const conn = connectionsList.find(c => 
                      (c.user1Id === friend.id && c.user2Id === currentUser?.id) ||
                      (c.user2Id === friend.id && c.user1Id === currentUser?.id)
                    );

                    let days = 1;
                    if (conn?.establishedAt) {
                      const diff = Date.now() - new Date(conn.establishedAt).getTime();
                      days = Math.max(1, Math.floor(diff / (1000 * 60 * 60 * 24)));
                    }

                    return (
                      <div
                        key={friend.id}
                        className="p-3.5 rounded-2xl bg-white/5 border border-white/10 hover:border-blue-500/40 flex items-center justify-between gap-3 transition-all relative"
                      >
                        {/* Friend Left Identity */}
                        <div 
                          onClick={() => {
                            setActiveTargetUser(friend);
                            setIsProfileModalOpen(true);
                          }}
                          className="flex items-center gap-3 cursor-pointer min-w-0 flex-1"
                        >
                          <div className="relative">
                            <img
                              src={friend.avatar}
                              alt={friend.name}
                              className="w-12 h-12 rounded-2xl object-cover border border-white/15"
                            />
                            <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-[#0d041c]" title="Online" />
                          </div>

                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="text-xs font-black text-white truncate">{friend.name}</span>
                              {friend.countryFlag && <span>{friend.countryFlag}</span>}
                              {friend.vipLevel === 'svip' && (
                                <span className="text-[9px] font-black px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-400/30">
                                  SVIP
                                </span>
                              )}
                            </div>
                            <ProfileIdBadge uid={friend.uid || friend.id} size="xs" />
                            <div className="flex items-center gap-2 mt-0.5 text-[10px] text-slate-400">
                              <span>Friends for {days}d</span>
                              {conn?.intimacyPoints ? (
                                <span className="text-pink-300 font-mono">❤️ {conn.intimacyPoints} pts</span>
                              ) : null}
                            </div>
                          </div>
                        </div>

                        {/* Friend Action Buttons */}
                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            onClick={() => {
                              setActiveTargetUser(friend);
                              setIsMessageModalOpen(true);
                            }}
                            className="p-2 rounded-xl bg-white/10 hover:bg-purple-600 text-white transition-colors"
                            title="Message"
                          >
                            <MessageSquare className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() => {
                              setActiveTargetUser(friend);
                              setIsGiftModalOpen(true);
                            }}
                            className="p-2 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 text-black font-bold hover:scale-105 transition-all shadow"
                            title="Send Gift"
                          >
                            <Gift className="w-4 h-4" />
                          </button>

                          {/* Options Menu Toggle */}
                          <div className="relative">
                            <button
                              onClick={() => setActiveActionMenuUserId(activeActionMenuUserId === friend.id ? null : friend.id)}
                              className="p-2 rounded-xl bg-white/5 hover:bg-white/15 text-slate-400 hover:text-white transition-colors"
                            >
                              <MoreVertical className="w-4 h-4" />
                            </button>

                            {/* Dropdown Menu */}
                            {activeActionMenuUserId === friend.id && (
                              <div className="absolute right-0 mt-1 w-36 bg-[#170930] border border-white/20 rounded-2xl p-1 shadow-2xl z-30 space-y-1">
                                <button
                                  onClick={() => {
                                    setActiveTargetUser(friend);
                                    setIsProfileModalOpen(true);
                                    setActiveActionMenuUserId(null);
                                  }}
                                  className="w-full text-left px-2.5 py-1.5 rounded-xl text-xs text-slate-200 hover:bg-white/10 flex items-center gap-2"
                                >
                                  <span>👤 Profile</span>
                                </button>
                                <button
                                  onClick={() => handleRemoveFriend(friend)}
                                  className="w-full text-left px-2.5 py-1.5 rounded-xl text-xs text-red-300 hover:bg-red-500/20 flex items-center gap-2"
                                >
                                  <span>❌ Unfriend</span>
                                </button>
                                <button
                                  onClick={() => handleBlockUser(friend)}
                                  className="w-full text-left px-2.5 py-1.5 rounded-xl text-xs text-red-400 hover:bg-red-500/20 flex items-center gap-2"
                                >
                                  <span>🚫 Block</span>
                                </button>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: REQUESTS */}
          {activeTab === 'requests' && (
            <div className="space-y-4 animate-fadeIn">
              {/* Incoming Requests */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-blue-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5 text-blue-400" /> Incoming Friend Requests ({incomingRequests.length})
                </h4>

                {incomingRequests.length === 0 ? (
                  <div className="p-6 rounded-2xl bg-white/5 border border-white/10 text-center text-xs text-slate-400">
                    No pending friend requests.
                  </div>
                ) : (
                  incomingRequests.map((req) => (
                    <div
                      key={req.id}
                      className="p-3.5 rounded-2xl bg-gradient-to-r from-blue-950/40 to-indigo-950/30 border border-blue-500/30 space-y-2.5"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-3">
                          <img
                            src={req.sender?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80'}
                            alt={req.sender?.name}
                            className="w-10 h-10 rounded-2xl object-cover border border-blue-400"
                          />
                          <div>
                            <span className="text-xs font-black text-white">{req.sender?.name || 'User'}</span>
                            <ProfileIdBadge uid={req.sender?.uid || req.senderId} size="xs" />
                          </div>
                        </div>
                        <span className="text-[10px] text-slate-400">
                          {new Date(req.createdAt).toLocaleDateString()}
                        </span>
                      </div>

                      {req.message && (
                        <p className="text-xs text-blue-200/90 bg-black/40 p-2.5 rounded-xl italic border border-blue-500/20">
                          "{req.message}"
                        </p>
                      )}

                      <div className="flex items-center gap-2 pt-1">
                        <button
                          onClick={() => handleAccept(req.id)}
                          className="flex-1 py-1.5 rounded-xl bg-gradient-to-r from-blue-500 to-indigo-600 text-white font-black text-xs shadow hover:scale-105 active:scale-95 transition-all"
                        >
                          Accept Friend
                        </button>
                        <button
                          onClick={() => handleDecline(req.id)}
                          className="px-4 py-1.5 rounded-xl bg-white/10 text-slate-300 hover:bg-white/20 text-xs font-bold transition-colors"
                        >
                          Decline
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Outgoing Requests */}
              <div className="space-y-2 pt-2 border-t border-white/10">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                  Sent Friend Requests ({outgoingRequests.length})
                </h4>

                {outgoingRequests.length === 0 ? (
                  <div className="p-4 rounded-2xl bg-white/5 border border-white/10 text-center text-xs text-slate-400">
                    No pending sent requests.
                  </div>
                ) : (
                  outgoingRequests.map((req) => (
                    <div
                      key={req.id}
                      className="p-3 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-2.5">
                        <img
                          src={req.receiver?.avatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80'}
                          alt="Recipient"
                          className="w-9 h-9 rounded-xl object-cover"
                        />
                        <div>
                          <span className="text-xs font-bold text-white">{req.receiver?.name || req.receiverId}</span>
                          <span className="text-[10px] text-amber-300 block">Pending Acceptance...</span>
                        </div>
                      </div>

                      <button
                        onClick={() => handleCancelRequest(req.id)}
                        className="px-3 py-1 rounded-xl bg-white/10 hover:bg-red-500/20 text-slate-300 hover:text-red-300 text-xs font-bold transition-colors"
                      >
                        Cancel
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* TAB 3: DISCOVER FRIENDS */}
          {activeTab === 'discover' && (
            <div className="space-y-3 animate-fadeIn">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  placeholder="Search community users to add..."
                  className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-black/40 border border-white/15 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="space-y-2">
                {discoverUsers.length === 0 ? (
                  <div className="py-12 text-center text-slate-400 text-xs">
                    No community users found.
                  </div>
                ) : (
                  discoverUsers.map((u) => {
                    const isFriend = friendsList.some(f => f.id === u.id);
                    const hasOutgoing = outgoingRequests.some(r => r.receiverId === u.id);

                    return (
                      <div
                        key={u.id}
                        className="p-3.5 rounded-2xl bg-white/5 border border-white/10 hover:border-blue-500/40 flex items-center justify-between gap-3 transition-all"
                      >
                        <div
                          onClick={() => {
                            setActiveTargetUser(u);
                            setIsProfileModalOpen(true);
                          }}
                          className="flex items-center gap-3 cursor-pointer min-w-0 flex-1"
                        >
                          <img
                            src={u.avatar}
                            alt={u.name}
                            className="w-12 h-12 rounded-2xl object-cover border border-white/15"
                          />
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="text-xs font-black text-white truncate">{u.name}</span>
                              {u.countryFlag && <span>{u.countryFlag}</span>}
                            </div>
                            <ProfileIdBadge uid={u.uid || u.id} size="xs" />
                            {u.bio && (
                              <p className="text-[10px] text-slate-400 truncate mt-0.5 max-w-[200px]">{u.bio}</p>
                            )}
                          </div>
                        </div>

                        {/* Add Friend Action */}
                        {isFriend ? (
                          <span className="px-3 py-1.5 rounded-xl bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/30">
                            ✓ Friend
                          </span>
                        ) : hasOutgoing ? (
                          <span className="px-3 py-1.5 rounded-xl bg-white/10 text-slate-300 text-xs font-bold border border-white/10">
                            Requested
                          </span>
                        ) : (
                          <button
                            onClick={() => setAddFriendTarget(u)}
                            className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-black text-xs shadow hover:scale-105 active:scale-95 transition-all flex items-center gap-1 shrink-0"
                          >
                            <UserPlus className="w-3.5 h-3.5" />
                            <span>Add</span>
                          </button>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          )}

          {/* TAB 4: BLOCKED USERS */}
          {activeTab === 'blocked' && (
            <div className="space-y-3 animate-fadeIn">
              <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 text-xs text-slate-300 flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Blocked users cannot send you messages, friend requests, or view your online room activities.</span>
              </div>

              {blockedUsers.length === 0 ? (
                <div className="p-8 rounded-2xl bg-white/5 border border-white/10 text-center text-xs text-slate-400">
                  Your blocked list is currently empty.
                </div>
              ) : (
                <div className="space-y-2">
                  {blockedUsers.map((bUser) => (
                    <div
                      key={bUser.id}
                      className="p-3.5 rounded-2xl bg-red-950/20 border border-red-500/20 flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={bUser.avatar}
                          alt={bUser.name}
                          className="w-10 h-10 rounded-2xl object-cover opacity-75 border border-white/15"
                        />
                        <div>
                          <span className="text-xs font-bold text-white">{bUser.name}</span>
                          <ProfileIdBadge uid={bUser.uid || bUser.id} size="xs" />
                        </div>
                      </div>

                      <button
                        onClick={() => handleUnblockUser(bUser)}
                        className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition-colors"
                      >
                        Unblock
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* ADD FRIEND NOTE DIALOG */}
        {addFriendTarget && (
          <div className="fixed inset-0 z-[130] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
            <div className="w-full max-w-sm bg-[#180933] border border-blue-500/40 rounded-3xl p-5 shadow-2xl space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-black text-white flex items-center gap-2">
                  <UserPlus className="w-4 h-4 text-blue-400" /> Add Friend
                </h3>
                <button
                  onClick={() => setAddFriendTarget(null)}
                  className="p-1 rounded-lg bg-white/10 text-slate-300"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="flex items-center gap-3 p-3 rounded-2xl bg-black/40 border border-white/10">
                <img
                  src={addFriendTarget.avatar}
                  alt={addFriendTarget.name}
                  className="w-12 h-12 rounded-2xl object-cover border border-blue-400"
                />
                <div>
                  <h4 className="text-xs font-black text-white">{addFriendTarget.name}</h4>
                  <ProfileIdBadge uid={addFriendTarget.uid || addFriendTarget.id} size="xs" />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-slate-300">Friend Request Note</label>
                <textarea
                  value={addFriendNote}
                  onChange={e => setAddFriendNote(e.target.value)}
                  rows={3}
                  className="w-full p-3 rounded-2xl bg-black/50 border border-white/15 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-400"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <button
                  onClick={handleSendFriendRequest}
                  disabled={isSendingRequest}
                  className="flex-1 py-2.5 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-black text-xs shadow-lg shadow-blue-500/30 hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isSendingRequest ? 'Sending...' : 'Send Request'}</span>
                </button>
                <button
                  onClick={() => setAddFriendTarget(null)}
                  className="px-4 py-2.5 rounded-2xl bg-white/10 text-slate-300 text-xs hover:bg-white/20"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {/* SEND GIFT MODAL */}
        {activeTargetUser && isGiftModalOpen && (
          <SendGiftDirectModal
            isOpen={isGiftModalOpen}
            onClose={() => setIsGiftModalOpen(false)}
            targetUser={activeTargetUser}
            isCP={false}
            onSuccess={() => fetchFriendsData()}
          />
        )}

        {/* DIRECT MESSAGE MODAL */}
        {activeTargetUser && isMessageModalOpen && (
          <DirectMessageModal
            isOpen={isMessageModalOpen}
            onClose={() => setIsMessageModalOpen(false)}
            targetUser={activeTargetUser}
            isCP={false}
          />
        )}

        {/* FRIEND PROFILE MODAL */}
        {activeTargetUser && isProfileModalOpen && (
          <FriendProfileModal
            isOpen={isProfileModalOpen}
            onClose={() => setIsProfileModalOpen(false)}
            user={activeTargetUser}
            connection={connectionsList.find(c => 
              (c.user1Id === activeTargetUser.id && c.user2Id === currentUser?.id) ||
              (c.user2Id === activeTargetUser.id && c.user1Id === currentUser?.id)
            )}
            onMessage={(u) => {
              setActiveTargetUser(u);
              setIsMessageModalOpen(true);
            }}
            onSendGift={(u) => {
              setActiveTargetUser(u);
              setIsGiftModalOpen(true);
            }}
            onConnectionUpdated={() => fetchFriendsData()}
          />
        )}
      </div>
    </div>
  );
};
