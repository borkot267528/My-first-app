/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { 
  Heart, Users, Search, Sparkles, MessageSquare, Gift, 
  Trash2, X, ArrowRight, Check, ShieldAlert, Calendar, 
  Flame, Award, Lock, ChevronRight, Clock, Star, Send
} from 'lucide-react';
import { Connection, ConnectionRequest, User } from '../../types';
import { useApp } from '../../context/AppContext';
import { ApiClient } from '../../lib/api';
import { ProfileIdBadge } from '../common/ProfileIdBadge';
import { SendGiftDirectModal } from './SendGiftDirectModal';
import { DirectMessageModal } from './DirectMessageModal';
import { FriendProfileModal } from './FriendProfileModal';

interface CPScreenProps {
  onClose?: () => void;
}

export const CPScreen: React.FC<CPScreenProps> = ({ onClose }) => {
  const { currentUser, showNotification, setActiveModal } = useApp();
  const [activeTab, setActiveTab] = useState<'my_cp' | 'discover' | 'requests' | 'profile'>('my_cp');
  const [cpConnection, setCpConnection] = useState<Connection | null>(null);
  const [incomingRequests, setIncomingRequests] = useState<ConnectionRequest[]>([]);
  const [outgoingRequests, setOutgoingRequests] = useState<ConnectionRequest[]>([]);
  const [discoverUsers, setDiscoverUsers] = useState<(User & { connectionStatus?: string })[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);

  // Modals
  const [isGiftModalOpen, setIsGiftModalOpen] = useState(false);
  const [isMessageModalOpen, setIsMessageModalOpen] = useState(false);
  const [selectedUserForProfile, setSelectedUserForProfile] = useState<User | null>(null);
  const [showRemoveConfirm, setShowRemoveConfirm] = useState(false);

  // Proposal modal
  const [proposeTargetUser, setProposeTargetUser] = useState<User | null>(null);
  const [proposalMessage, setProposalMessage] = useState('Would you like to be my CP partner on Nigo? ❤️');
  const [isSendingProposal, setIsSendingProposal] = useState(false);

  const fetchCPData = useCallback(async () => {
    setLoading(true);
    try {
      const [cpRes, reqRes] = await Promise.all([
        ApiClient.getCP().catch(() => null),
        ApiClient.getCPRequests().catch(() => ({ incoming: [], outgoing: [] }))
      ]);
      setCpConnection(cpRes);
      setIncomingRequests(reqRes.incoming || []);
      setOutgoingRequests(reqRes.outgoing || []);
    } catch (err) {
      console.warn('Failed to load CP data', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchCPData();
  }, [fetchCPData]);

  // Handle discover search
  useEffect(() => {
    if (activeTab === 'discover') {
      const timer = setTimeout(() => {
        ApiClient.discoverUsers(searchQuery)
          .then((res) => {
            // Exclude current user
            const filtered = (res || []).filter(u => u.id !== currentUser?.id);
            setDiscoverUsers(filtered);
          })
          .catch(() => {});
      }, 300);
      return () => clearTimeout(timer);
    }
  }, [activeTab, searchQuery, currentUser?.id]);

  const partner = cpConnection?.partner;

  // Calculate connection days
  let connectionDays = 1;
  if (cpConnection?.establishedAt) {
    const diff = Date.now() - new Date(cpConnection.establishedAt).getTime();
    connectionDays = Math.max(1, Math.floor(diff / (1000 * 60 * 60 * 24)));
  }

  // CP Level & Titles
  const cpLevelTitles: Record<number, { title: string; nextScore: number; perks: string }> = {
    1: { title: 'Kindred Hearts', nextScore: 500, perks: 'CP Heart Badge & In-Room Glow' },
    2: { title: 'Sweet Romance', nextScore: 2000, perks: 'Couple Entrance Animation' },
    3: { title: 'Soulmates', nextScore: 5000, perks: 'Golden Ring Avatar Frame' },
    4: { title: 'Eternal Flame', nextScore: 15000, perks: 'Exclusive CP Mic Stand' },
    5: { title: 'Mythic Dynasty', nextScore: 50000, perks: 'Custom Castle Broadcast & Full VIP Title' }
  };

  const currentLevel = cpConnection?.level || 1;
  const levelInfo = cpLevelTitles[currentLevel] || cpLevelTitles[1];
  const intimacyPoints = cpConnection?.intimacyPoints || 0;
  const progressPct = Math.min(100, Math.round((intimacyPoints / levelInfo.nextScore) * 100));

  const handleAcceptRequest = async (requestId: string) => {
    try {
      await ApiClient.acceptConnectionRequest(requestId);
      showNotification('Congratulations! CP Connection established! ❤️');
      await fetchCPData();
      setActiveTab('my_cp');
    } catch (err: any) {
      showNotification(err?.message || 'Failed to accept CP request');
    }
  };

  const handleDeclineRequest = async (requestId: string) => {
    try {
      await ApiClient.declineConnectionRequest(requestId);
      showNotification('CP Request declined');
      fetchCPData();
    } catch (err: any) {
      showNotification(err?.message || 'Failed to decline request');
    }
  };

  const handleCancelRequest = async (requestId: string) => {
    try {
      await ApiClient.cancelConnectionRequest(requestId);
      showNotification('CP proposal cancelled');
      fetchCPData();
    } catch (err: any) {
      showNotification(err?.message || 'Failed to cancel request');
    }
  };

  const handleSendProposal = async () => {
    if (!proposeTargetUser) return;
    setIsSendingProposal(true);
    try {
      await ApiClient.sendConnectionRequest(proposeTargetUser.id, 'cp', proposalMessage);
      showNotification(`CP proposal sent to ${proposeTargetUser.name}! ❤️`);
      setProposeTargetUser(null);
      fetchCPData();
    } catch (err: any) {
      showNotification(err?.message || 'Failed to send CP proposal');
    } finally {
      setIsSendingProposal(false);
    }
  };

  const handleRemoveCP = async () => {
    if (!cpConnection) return;
    try {
      await ApiClient.removeConnection(cpConnection.id);
      showNotification('CP connection has been dissolved.');
      setShowRemoveConfirm(false);
      setCpConnection(null);
      fetchCPData();
    } catch (err: any) {
      showNotification(err?.message || 'Failed to remove CP connection');
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/85 backdrop-blur-xl p-0 sm:p-4 overflow-y-auto animate-fadeIn">
      <div 
        className="w-full max-w-lg bg-[#0d041c] border border-pink-500/20 rounded-none sm:rounded-3xl shadow-[0_0_50px_rgba(244,114,182,0.15)] flex flex-col min-h-screen sm:min-h-[85vh] max-h-screen sm:max-h-[90vh] overflow-hidden"
        onClick={e => e.stopPropagation()}
      >
        {/* TOP HEADER */}
        <div className="p-4 bg-gradient-to-r from-pink-950/80 via-purple-950/80 to-[#120526] border-b border-pink-500/20 flex items-center justify-between sticky top-0 z-20 backdrop-blur-md">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-pink-500 to-rose-400 flex items-center justify-center text-xl shadow-lg shadow-pink-500/30">
              ❤️
            </div>
            <div>
              <h2 className="text-base font-black text-white flex items-center gap-1.5 tracking-wide">
                Nigo CP Space <span className="text-pink-400 text-xs">Couple Sanctuary</span>
              </h2>
              <p className="text-[11px] text-pink-300/80 font-medium">
                {partner ? `Connected with ${partner.name}` : 'Find your perfect partner'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* NAVIGATION TABS */}
        <div className="flex items-center border-b border-white/10 bg-[#120626] px-2 pt-2">
          {[
            { id: 'my_cp', label: 'My CP', icon: <Heart className="w-4 h-4" />, badge: partner ? 'Active' : undefined },
            { id: 'discover', label: 'Discover', icon: <Search className="w-4 h-4" /> },
            { 
              id: 'requests', 
              label: 'Requests', 
              icon: <Clock className="w-4 h-4" />, 
              count: incomingRequests.length 
            },
            { id: 'profile', label: 'Connection Profile', icon: <Award className="w-4 h-4" /> }
          ].map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex-1 py-3 px-1 text-xs font-black flex items-center justify-center gap-1.5 border-b-2 transition-all relative ${
                  isActive 
                    ? 'border-pink-500 text-pink-300 bg-pink-500/10' 
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                {tab.icon}
                <span className="truncate">{tab.label}</span>
                {tab.count !== undefined && tab.count > 0 && (
                  <span className="px-1.5 py-0.2 text-[10px] bg-pink-500 text-white rounded-full font-mono font-bold animate-pulse">
                    {tab.count}
                  </span>
                )}
                {tab.badge && (
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                )}
              </button>
            );
          })}
        </div>

        {/* TAB CONTENTS */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* TAB 1: MY CP */}
          {activeTab === 'my_cp' && (
            <div className="space-y-4 animate-fadeIn">
              {partner && cpConnection ? (
                <>
                  {/* DUAL CP AVATAR CARD WITH GLOWING HEART */}
                  <div className="relative overflow-hidden rounded-3xl p-6 bg-gradient-to-br from-pink-950/60 via-purple-950/40 to-black/80 border border-pink-500/40 shadow-2xl space-y-4">
                    <div className="flex items-center justify-center gap-4 sm:gap-6 py-2">
                      {/* Current User Avatar */}
                      <div className="flex flex-col items-center space-y-1.5">
                        <div className="relative">
                          <div className="w-20 h-20 rounded-3xl p-1 bg-gradient-to-tr from-purple-500 to-indigo-500 shadow-xl">
                            <img 
                              src={currentUser?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80'} 
                              alt="You" 
                              className="w-full h-full rounded-2xl object-cover border-2 border-black" 
                            />
                          </div>
                          <span className="absolute -top-1 -right-1 px-1.5 py-0.5 rounded-md bg-purple-600 text-white text-[9px] font-black">
                            YOU
                          </span>
                        </div>
                        <span className="text-xs font-black text-white truncate max-w-[90px]">{currentUser?.name || 'Me'}</span>
                        <ProfileIdBadge uid={currentUser?.uid || currentUser?.id} size="xs" />
                      </div>

                      {/* Animated Connection Heart Core */}
                      <div className="flex flex-col items-center justify-center px-2">
                        <div className="relative w-14 h-14 rounded-full bg-pink-500/20 border border-pink-400/50 flex items-center justify-center shadow-[0_0_20px_rgba(244,114,182,0.5)] animate-pulse">
                          <Heart className="w-8 h-8 text-pink-500 fill-pink-500 drop-shadow-md" />
                          <span className="absolute -bottom-1 text-[9px] font-black bg-pink-600 text-white px-1.5 py-0.2 rounded-full border border-pink-300">
                            Lv.{cpConnection.level}
                          </span>
                        </div>
                        <span className="text-[10px] font-bold text-pink-300 mt-2 font-mono">
                          {connectionDays} Days Together
                        </span>
                      </div>

                      {/* Partner Avatar */}
                      <div 
                        onClick={() => setSelectedUserForProfile(partner)}
                        className="flex flex-col items-center space-y-1.5 cursor-pointer group"
                      >
                        <div className="relative">
                          <div className="w-20 h-20 rounded-3xl p-1 bg-gradient-to-tr from-pink-500 to-rose-400 shadow-xl group-hover:scale-105 transition-transform">
                            <img 
                              src={partner.avatar} 
                              alt={partner.name} 
                              className="w-full h-full rounded-2xl object-cover border-2 border-black" 
                            />
                          </div>
                          <span className="absolute -top-1 -right-1 px-1.5 py-0.5 rounded-md bg-pink-600 text-white text-[9px] font-black">
                            PARTNER
                          </span>
                        </div>
                        <span className="text-xs font-black text-white group-hover:text-pink-300 transition-colors truncate max-w-[90px]">
                          {partner.name}
                        </span>
                        <ProfileIdBadge uid={partner.uid || partner.id} size="xs" />
                      </div>
                    </div>

                    {/* CP Title & Level Bar */}
                    <div className="p-3.5 rounded-2xl bg-black/50 border border-white/10 space-y-2 backdrop-blur-md">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-slate-300 flex items-center gap-1.5">
                          <Sparkles className="w-3.5 h-3.5 text-pink-400" />
                          Connection Level: <strong className="text-pink-300">Lv.{currentLevel} - {levelInfo.title}</strong>
                        </span>
                        <span className="font-mono text-pink-400 text-[11px] font-bold">
                          {intimacyPoints} / {levelInfo.nextScore} pts
                        </span>
                      </div>

                      <div className="w-full h-2.5 rounded-full bg-white/10 overflow-hidden p-0.5">
                        <div 
                          className="h-full rounded-full bg-gradient-to-r from-pink-500 via-rose-400 to-purple-500 transition-all duration-500 shadow-[0_0_8px_#ec4899]"
                          style={{ width: `${progressPct}%` }}
                        />
                      </div>

                      <div className="flex items-center justify-between text-[10px] text-slate-400">
                        <span>Perk: {levelInfo.perks}</span>
                        <span>{progressPct}% to Lv.{currentLevel + 1}</span>
                      </div>
                    </div>

                    {/* Quick Stats Banner */}
                    <div className="grid grid-cols-2 gap-2">
                      <div className="p-3 rounded-2xl bg-white/5 border border-white/10 flex items-center gap-3">
                        <div className="p-2 rounded-xl bg-pink-500/20 text-pink-300">
                          <Gift className="w-5 h-5" />
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-400 block">Shared Gifts</span>
                          <span className="text-sm font-black text-white font-mono">
                            {cpConnection.sharedGiftsCount || 0} gifts
                          </span>
                        </div>
                      </div>

                      <div className="p-3 rounded-2xl bg-white/5 border border-white/10 flex items-center gap-3">
                        <div className="p-2 rounded-xl bg-amber-500/20 text-amber-300">
                          <Flame className="w-5 h-5" />
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-400 block">Gift Value</span>
                          <span className="text-sm font-black text-amber-400 font-mono">
                            🪙 {(cpConnection.sharedGiftsCoins || 0).toLocaleString()}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons: Message, Send Gift, Remove Connection */}
                    <div className="pt-2 flex items-center gap-2">
                      <button
                        onClick={() => setIsMessageModalOpen(true)}
                        className="flex-1 py-2.5 rounded-2xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all border border-white/15 shadow active:scale-95"
                      >
                        <MessageSquare className="w-4 h-4 text-purple-300" />
                        <span>Message</span>
                      </button>

                      <button
                        onClick={() => setIsGiftModalOpen(true)}
                        className="flex-1 py-2.5 rounded-2xl bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-600 hover:to-rose-700 text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-pink-500/20 transition-all hover:scale-105 active:scale-95"
                      >
                        <Gift className="w-4 h-4 text-white" />
                        <span>Send Gift</span>
                      </button>

                      <button
                        onClick={() => setShowRemoveConfirm(true)}
                        className="p-2.5 rounded-2xl bg-white/5 hover:bg-red-500/20 text-slate-400 hover:text-red-300 border border-white/10 transition-colors"
                        title="Remove CP Connection"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Dissolve Confirmation Box */}
                  {showRemoveConfirm && (
                    <div className="p-4 rounded-2xl bg-red-950/60 border border-red-500/40 space-y-3">
                      <h4 className="text-xs font-black text-red-300 flex items-center gap-1.5">
                        <ShieldAlert className="w-4 h-4 text-red-400" /> Dissolve CP Connection?
                      </h4>
                      <p className="text-xs text-red-200 leading-relaxed">
                        Ending your CP connection with <strong>{partner.name}</strong> will reset your connection days and intimacy level. Both of you will return to single status.
                      </p>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={handleRemoveCP}
                          className="flex-1 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white font-black text-xs transition-colors"
                        >
                          Confirm Dissolve
                        </button>
                        <button
                          onClick={() => setShowRemoveConfirm(false)}
                          className="px-4 py-2 rounded-xl bg-white/10 text-slate-300 text-xs hover:bg-white/20"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  )}
                </>
              ) : (
                /* NO CP STATE */
                <div className="rounded-3xl p-8 bg-gradient-to-br from-pink-950/30 via-purple-950/20 to-black/60 border border-pink-500/30 text-center space-y-5 shadow-2xl">
                  <div className="w-20 h-20 mx-auto rounded-full bg-pink-500/10 border border-pink-400/30 flex items-center justify-center text-4xl shadow-[0_0_30px_rgba(244,114,182,0.2)]">
                    💍
                  </div>

                  <div className="space-y-1.5">
                    <h3 className="text-lg font-black text-white">Find Your CP Partner</h3>
                    <p className="text-xs text-slate-300 max-w-sm mx-auto leading-relaxed">
                      Pair up with your favorite person on Nigo Voice! Unlock couple avatar frames, shared intimacy rankings, and special room entrance ceremonies.
                    </p>
                  </div>

                  <div className="grid grid-cols-3 gap-2.5 pt-2 text-left">
                    <div className="p-3 rounded-2xl bg-white/5 border border-white/10 space-y-1">
                      <span className="text-base">👑</span>
                      <h5 className="text-[11px] font-bold text-white">CP Badges</h5>
                      <p className="text-[10px] text-slate-400">Exclusive heart badge on your profile</p>
                    </div>
                    <div className="p-3 rounded-2xl bg-white/5 border border-white/10 space-y-1">
                      <span className="text-base">🏰</span>
                      <h5 className="text-[11px] font-bold text-white">Joint Entry</h5>
                      <p className="text-[10px] text-slate-400">Arrive in voice rooms together</p>
                    </div>
                    <div className="p-3 rounded-2xl bg-white/5 border border-white/10 space-y-1">
                      <span className="text-base">💎</span>
                      <h5 className="text-[11px] font-bold text-white">Intimacy Ranks</h5>
                      <p className="text-[10px] text-slate-400">Level up via gifting & chatting</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 pt-3">
                    <button
                      onClick={() => setActiveTab('discover')}
                      className="flex-1 py-3 rounded-2xl bg-gradient-to-r from-pink-500 via-rose-500 to-purple-600 text-white font-black text-xs shadow-lg shadow-pink-500/25 hover:scale-105 active:scale-95 transition-all"
                    >
                      Explore Community Discover →
                    </button>
                    {incomingRequests.length > 0 && (
                      <button
                        onClick={() => setActiveTab('requests')}
                        className="py-3 px-4 rounded-2xl bg-white/10 hover:bg-white/20 text-pink-300 font-black text-xs border border-pink-400/40"
                      >
                        Requests ({incomingRequests.length})
                      </button>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: DISCOVER */}
          {activeTab === 'discover' && (
            <div className="space-y-3 animate-fadeIn">
              {/* Search Bar */}
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  placeholder="Search by username, Nigo ID, or country..."
                  className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-black/40 border border-white/15 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-pink-500"
                />
              </div>

              {/* Discover Users List */}
              <div className="space-y-2">
                {discoverUsers.length === 0 ? (
                  <div className="py-12 text-center text-slate-400 text-xs">
                    No users found matching your search.
                  </div>
                ) : (
                  discoverUsers.map((u) => {
                    const isAlreadyPartner = partner?.id === u.id;
                    const hasOutgoing = outgoingRequests.some(r => r.receiverId === u.id);

                    return (
                      <div 
                        key={u.id}
                        className="p-3.5 rounded-2xl bg-white/5 border border-white/10 hover:border-pink-500/40 flex items-center justify-between gap-3 transition-all"
                      >
                        <div 
                          onClick={() => setSelectedUserForProfile(u)}
                          className="flex items-center gap-3 cursor-pointer min-w-0 flex-1"
                        >
                          <img 
                            src={u.avatar} 
                            alt={u.name} 
                            className="w-12 h-12 rounded-2xl object-cover border border-white/15" 
                          />
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="text-xs font-black text-white truncate">{u.name}</span>
                              {u.countryFlag && <span>{u.countryFlag}</span>}
                              {u.gender === 'female' && <span className="text-pink-400 text-xs">♀</span>}
                              {u.gender === 'male' && <span className="text-blue-400 text-xs">♂</span>}
                            </div>
                            <ProfileIdBadge uid={u.uid || u.id} size="xs" />
                            {u.bio && (
                              <p className="text-[10px] text-slate-400 truncate mt-0.5 max-w-[200px]">{u.bio}</p>
                            )}
                          </div>
                        </div>

                        {/* Action Button */}
                        {isAlreadyPartner ? (
                          <span className="px-3 py-1.5 rounded-xl bg-pink-500/20 text-pink-300 text-xs font-black border border-pink-500/30">
                            Your CP ❤️
                          </span>
                        ) : hasOutgoing ? (
                          <span className="px-3 py-1.5 rounded-xl bg-white/10 text-slate-300 text-xs font-bold border border-white/10">
                            Proposal Sent
                          </span>
                        ) : (
                          <button
                            onClick={() => {
                              if (partner) {
                                showNotification('You already have an active CP. Dissolve your current CP before proposing to someone new.');
                                return;
                              }
                              setProposeTargetUser(u);
                            }}
                            className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-pink-500 to-rose-600 text-white font-black text-xs shadow hover:scale-105 active:scale-95 transition-all flex items-center gap-1 shrink-0"
                          >
                            <Heart className="w-3.5 h-3.5 fill-white" />
                            <span>Propose CP</span>
                          </button>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          )}

          {/* TAB 3: REQUESTS */}
          {activeTab === 'requests' && (
            <div className="space-y-4 animate-fadeIn">
              {/* Incoming Requests */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-pink-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Heart className="w-3.5 h-3.5 text-pink-400" /> Incoming CP Proposals ({incomingRequests.length})
                </h4>

                {incomingRequests.length === 0 ? (
                  <div className="p-6 rounded-2xl bg-white/5 border border-white/10 text-center text-xs text-slate-400">
                    No pending CP proposals received.
                  </div>
                ) : (
                  incomingRequests.map((req) => (
                    <div 
                      key={req.id}
                      className="p-3.5 rounded-2xl bg-gradient-to-r from-pink-950/40 to-purple-950/30 border border-pink-500/30 space-y-2.5"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-3">
                          <img 
                            src={req.sender?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80'} 
                            alt={req.sender?.name} 
                            className="w-10 h-10 rounded-2xl object-cover border border-pink-400" 
                          />
                          <div>
                            <span className="text-xs font-black text-white">{req.sender?.name || 'User'}</span>
                            <ProfileIdBadge uid={req.sender?.uid || req.senderId} size="xs" />
                          </div>
                        </div>
                        <span className="text-[10px] text-slate-400">
                          {new Date(req.createdAt).toLocaleDateString()}
                        </span>
                      </div>

                      {req.message && (
                        <p className="text-xs text-pink-200/90 bg-black/40 p-2.5 rounded-xl italic border border-pink-500/20">
                          "{req.message}"
                        </p>
                      )}

                      <div className="flex items-center gap-2 pt-1">
                        <button
                          onClick={() => handleAcceptRequest(req.id)}
                          className="flex-1 py-1.5 rounded-xl bg-gradient-to-r from-pink-500 to-rose-600 text-white font-black text-xs shadow hover:scale-105 active:scale-95 transition-all"
                        >
                          Accept Proposal ❤️
                        </button>
                        <button
                          onClick={() => handleDeclineRequest(req.id)}
                          className="px-4 py-1.5 rounded-xl bg-white/10 text-slate-300 hover:bg-white/20 text-xs font-bold transition-colors"
                        >
                          Decline
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Outgoing Requests */}
              <div className="space-y-2 pt-2 border-t border-white/10">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                  Sent Proposals ({outgoingRequests.length})
                </h4>

                {outgoingRequests.length === 0 ? (
                  <div className="p-4 rounded-2xl bg-white/5 border border-white/10 text-center text-xs text-slate-400">
                    No outgoing CP proposals.
                  </div>
                ) : (
                  outgoingRequests.map((req) => (
                    <div 
                      key={req.id}
                      className="p-3 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-2.5">
                        <img 
                          src={req.receiver?.avatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80'} 
                          alt="Recipient" 
                          className="w-9 h-9 rounded-xl object-cover" 
                        />
                        <div>
                          <span className="text-xs font-bold text-white">{req.receiver?.name || req.receiverId}</span>
                          <span className="text-[10px] text-amber-300 block">Pending Acceptance...</span>
                        </div>
                      </div>

                      <button
                        onClick={() => handleCancelRequest(req.id)}
                        className="px-3 py-1 rounded-xl bg-white/10 hover:bg-red-500/20 text-slate-300 hover:text-red-300 text-xs font-bold transition-colors"
                      >
                        Cancel
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* TAB 4: CONNECTION PROFILE */}
          {activeTab === 'profile' && (
            <div className="space-y-4 animate-fadeIn">
              {partner && cpConnection ? (
                <div className="space-y-4">
                  {/* Detailed Bond Summary Card */}
                  <div className="p-5 rounded-3xl bg-gradient-to-br from-pink-950/60 via-purple-950/40 to-black/80 border border-pink-500/30 space-y-4">
                    <div className="flex items-center justify-between border-b border-white/10 pb-3">
                      <div>
                        <h3 className="text-sm font-black text-white flex items-center gap-1.5">
                          ❤️ Soulmate Registry Certificate
                        </h3>
                        <p className="text-[10px] text-pink-300">
                          Official Nigo Couple Recognition
                        </p>
                      </div>
                      <span className="px-2.5 py-1 rounded-full bg-pink-500/20 text-pink-300 text-[10px] font-mono font-bold border border-pink-500/40">
                        CP ID: {cpConnection.id.slice(0, 10)}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-xs">
                      <div className="p-3 rounded-2xl bg-black/40 border border-white/10 space-y-0.5">
                        <span className="text-[10px] text-slate-400">Anniversary Date</span>
                        <span className="font-bold text-white block">
                          {new Date(cpConnection.establishedAt).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' })}
                        </span>
                      </div>
                      <div className="p-3 rounded-2xl bg-black/40 border border-white/10 space-y-0.5">
                        <span className="text-[10px] text-slate-400">Intimacy Tier</span>
                        <span className="font-bold text-pink-300 block">
                          Tier {currentLevel} • {levelInfo.title}
                        </span>
                      </div>
                    </div>

                    {/* Milestone Ladder */}
                    <div className="space-y-2 pt-2">
                      <h4 className="text-xs font-bold text-slate-300">CP Milestone Perks</h4>
                      <div className="space-y-1.5">
                        {Object.entries(cpLevelTitles).map(([lvlStr, info]) => {
                          const lvlNum = Number(lvlStr);
                          const isUnlocked = currentLevel >= lvlNum;
                          return (
                            <div 
                              key={lvlStr}
                              className={`p-2.5 rounded-xl border flex items-center justify-between text-xs ${
                                isUnlocked 
                                  ? 'bg-pink-500/10 border-pink-500/40 text-pink-200' 
                                  : 'bg-white/5 border-white/5 text-slate-500'
                              }`}
                            >
                              <div className="flex items-center gap-2">
                                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black ${
                                  isUnlocked ? 'bg-pink-500 text-white' : 'bg-white/10 text-slate-500'
                                }`}>
                                  {lvlStr}
                                </span>
                                <span className="font-bold">{info.title}</span>
                              </div>
                              <span className="text-[11px] font-medium">{info.perks}</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-8 rounded-3xl bg-white/5 border border-white/10 text-center space-y-3">
                  <span className="text-4xl">💌</span>
                  <h4 className="text-sm font-bold text-white">No Active Connection Profile</h4>
                  <p className="text-xs text-slate-400 max-w-xs mx-auto">
                    Form a CP bond in Nigo Voice to display your mutual couple credentials and unlock perks.
                  </p>
                  <button
                    onClick={() => setActiveTab('discover')}
                    className="px-4 py-2 rounded-xl bg-pink-500 text-white text-xs font-bold shadow hover:bg-pink-600"
                  >
                    Find a Partner
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* PROPOSAL POPUP MODAL */}
        {proposeTargetUser && (
          <div className="fixed inset-0 z-[130] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
            <div className="w-full max-w-sm bg-[#180933] border border-pink-500/40 rounded-3xl p-5 shadow-2xl space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-black text-white flex items-center gap-2">
                  <Heart className="w-4 h-4 text-pink-400 fill-pink-400" /> Send CP Proposal
                </h3>
                <button 
                  onClick={() => setProposeTargetUser(null)}
                  className="p-1 rounded-lg bg-white/10 text-slate-300"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="flex items-center gap-3 p-3 rounded-2xl bg-black/40 border border-white/10">
                <img 
                  src={proposeTargetUser.avatar} 
                  alt={proposeTargetUser.name} 
                  className="w-12 h-12 rounded-2xl object-cover border border-pink-400" 
                />
                <div>
                  <h4 className="text-xs font-black text-white">{proposeTargetUser.name}</h4>
                  <ProfileIdBadge uid={proposeTargetUser.uid || proposeTargetUser.id} size="xs" />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-slate-300">Proposal Love Note</label>
                <textarea
                  value={proposalMessage}
                  onChange={e => setProposalMessage(e.target.value)}
                  rows={3}
                  className="w-full p-3 rounded-2xl bg-black/50 border border-white/15 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-pink-400"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <button
                  onClick={handleSendProposal}
                  disabled={isSendingProposal}
                  className="flex-1 py-2.5 rounded-2xl bg-gradient-to-r from-pink-500 to-rose-600 text-white font-black text-xs shadow-lg shadow-pink-500/30 hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isSendingProposal ? 'Sending Proposal...' : 'Send Proposal ❤️'}</span>
                </button>
                <button
                  onClick={() => setProposeTargetUser(null)}
                  className="px-4 py-2.5 rounded-2xl bg-white/10 text-slate-300 text-xs hover:bg-white/20"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {/* MODAL 1: SEND GIFT DIRECT TO CP */}
        {partner && isGiftModalOpen && (
          <SendGiftDirectModal
            isOpen={isGiftModalOpen}
            onClose={() => setIsGiftModalOpen(false)}
            targetUser={partner}
            isCP={true}
            onSuccess={() => fetchCPData()}
          />
        )}

        {/* MODAL 2: DIRECT MESSAGE TO CP */}
        {partner && isMessageModalOpen && (
          <DirectMessageModal
            isOpen={isMessageModalOpen}
            onClose={() => setIsMessageModalOpen(false)}
            targetUser={partner}
            isCP={true}
          />
        )}

        {/* MODAL 3: USER PROFILE MODAL */}
        {selectedUserForProfile && (
          <FriendProfileModal
            isOpen={!!selectedUserForProfile}
            onClose={() => setSelectedUserForProfile(null)}
            user={selectedUserForProfile}
            connection={partner?.id === selectedUserForProfile.id ? cpConnection : null}
            onMessage={(u) => {
              setIsMessageModalOpen(true);
            }}
            onSendGift={(u) => {
              setIsGiftModalOpen(true);
            }}
            onConnectionUpdated={() => fetchCPData()}
          />
        )}
      </div>
    </div>
  );
};
