/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { MessageSquare, X, Send, Sparkles, CheckCheck } from 'lucide-react';
import { User } from '../../types';
import { useApp } from '../../context/AppContext';
import { ApiClient } from '../../lib/api';
import { ProfileIdBadge } from '../common/ProfileIdBadge';

interface DirectMessageModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetUser: User | { id: string; name: string; avatar: string; uid?: string };
  isCP?: boolean;
}

export const DirectMessageModal: React.FC<DirectMessageModalProps> = ({
  isOpen,
  onClose,
  targetUser,
  isCP = false
}) => {
  const { currentUser, showNotification, setActiveTab } = useApp();
  const [inputText, setInputText] = useState('');
  const [messages, setMessages] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isOpen && targetUser?.id) {
      setLoading(true);
      ApiClient.getPrivateMessages(targetUser.id)
        .then((res) => {
          if (res && res.length > 0) {
            setMessages(res.map((m: any) => ({
              id: m.id,
              text: m.content || m.text,
              isMe: m.senderId === (currentUser?.id || '2383452'),
              time: new Date(m.timestamp || m.createdAt || Date.now()).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            })));
          } else {
            // Sample conversation starter if empty
            setMessages([
              {
                id: 'init-1',
                text: isCP ? '❤️ Connected in CP Space! Send your first love note.' : '👋 Connected as friends! Say hello.',
                isMe: false,
                time: 'Just now'
              }
            ]);
          }
        })
        .catch(() => {})
        .finally(() => setLoading(false));
    }
  }, [isOpen, targetUser?.id, isCP, currentUser?.id]);

  if (!isOpen) return null;

  const handleSend = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim()) return;

    const newMsgText = inputText.trim();
    setInputText('');

    const optimisticMsg = {
      id: `temp-${Date.now()}`,
      text: newMsgText,
      isMe: true,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    setMessages(prev => [...prev, optimisticMsg]);

    try {
      await ApiClient.sendPrivateMessage(targetUser.id, newMsgText);
    } catch (err: any) {
      showNotification('Message sent locally.');
    }
  };

  const quickReplies = isCP ? [
    'Thinking of you! ❤️',
    'Join my voice room! 🎙️',
    'Sending you hugs! 🤗',
    'Love you CP partner! ✨'
  ] : [
    'Hey! How are you doing? 👋',
    'Join my room party! 🎙️',
    'Ready for the PK Battle? ⚔️',
    'Thanks for connecting! 🌟'
  ];

  return (
    <div className="fixed inset-0 z-[120] flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div 
        className="w-full max-w-md bg-[#13072b] border border-white/15 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col h-[75vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-purple-900/60 to-indigo-900/40 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <img 
                src={targetUser.avatar} 
                alt={targetUser.name} 
                className="w-10 h-10 rounded-2xl object-cover border border-amber-400"
              />
              {isCP && <span className="absolute -bottom-1 -right-1 text-xs">❤️</span>}
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-black text-white">{targetUser.name}</span>
                {isCP ? (
                  <span className="text-[9px] font-black px-1.5 py-0.2 rounded-full bg-pink-500/30 text-pink-300 border border-pink-400/40">
                    CP PARTNER
                  </span>
                ) : (
                  <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-full bg-blue-500/20 text-blue-300 border border-blue-400/30">
                    FRIEND
                  </span>
                )}
              </div>
              {targetUser.uid && (
                <ProfileIdBadge uid={targetUser.uid} size="xs" />
              )}
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-xl bg-white/10 text-slate-300 hover:text-white hover:bg-white/15 transition-all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Message Thread */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-[#0a0218]">
          {messages.map((m) => (
            <div 
              key={m.id}
              className={`flex flex-col ${m.isMe ? 'items-end' : 'items-start'}`}
            >
              <div 
                className={`max-w-[78%] px-3.5 py-2.5 rounded-2xl text-xs shadow-md ${
                  m.isMe 
                    ? isCP 
                      ? 'bg-gradient-to-r from-pink-600 to-purple-600 text-white rounded-br-none' 
                      : 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-br-none'
                    : 'bg-white/10 text-slate-200 border border-white/10 rounded-bl-none'
                }`}
              >
                <p className="leading-relaxed break-words">{m.text}</p>
                <div className="flex items-center justify-end gap-1 mt-1 text-[9px] opacity-70">
                  <span>{m.time}</span>
                  {m.isMe && <CheckCheck className="w-2.5 h-2.5" />}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Quick Reply Chips */}
        <div className="px-3 py-2 bg-black/40 border-t border-white/10 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          {quickReplies.map((q, idx) => (
            <button
              key={idx}
              onClick={() => setInputText(q)}
              className="text-[10px] px-2.5 py-1 rounded-full bg-white/5 hover:bg-white/15 text-slate-300 whitespace-nowrap border border-white/10 transition-colors"
            >
              {q}
            </button>
          ))}
        </div>

        {/* Message Input Box */}
        <form onSubmit={handleSend} className="p-3 bg-[#110526] border-t border-white/10 flex items-center gap-2">
          <input 
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={isCP ? "Write a sweet note to your CP..." : "Type a message..."}
            className="flex-1 bg-black/50 border border-white/15 rounded-2xl px-3.5 py-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-purple-400"
          />
          <button
            type="submit"
            disabled={!inputText.trim()}
            className={`p-2.5 rounded-2xl transition-all shadow-md ${
              inputText.trim() 
                ? isCP 
                  ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white hover:scale-105 active:scale-95' 
                  : 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white hover:scale-105 active:scale-95'
                : 'bg-white/10 text-slate-500 cursor-not-allowed'
            }`}
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
