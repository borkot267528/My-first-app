/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Gift, X, Sparkles, Send, Coins, Flame, Heart } from 'lucide-react';
import { Gift as GiftType, User } from '../../types';
import { useApp } from '../../context/AppContext';
import { ApiClient } from '../../lib/api';
import { ProfileIdBadge } from '../common/ProfileIdBadge';

interface SendGiftDirectModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetUser: User | { id: string; name: string; avatar: string; uid?: string };
  isCP?: boolean;
  onSuccess?: () => void;
}

export const SendGiftDirectModal: React.FC<SendGiftDirectModalProps> = ({
  isOpen,
  onClose,
  targetUser,
  isCP = false,
  onSuccess
}) => {
  const { currentUser, gifts, showNotification, refreshUser } = useApp();
  const [selectedGift, setSelectedGift] = useState<GiftType | null>(null);
  const [count, setCount] = useState<number>(1);
  const [isSending, setIsSending] = useState(false);

  if (!isOpen) return null;

  const fallbackGifts: GiftType[] = [
    { id: 'g-heart', name: 'Rose Romance', icon: '🌹', priceCoins: 10, category: 'popular', animationType: 'pop', svgColor: '#f43f5e' },
    { id: 'g-ring', name: 'Love Diamond Ring', icon: '💍', priceCoins: 520, category: 'luxury', animationType: 'pop', svgColor: '#ec4899' },
    { id: 'g-castle', name: 'Crystal Palace', icon: '🏰', priceCoins: 1314, category: 'luxury', animationType: 'fullscreen', svgColor: '#a855f7' },
    { id: 'g-car', name: 'Super Sports Car', icon: '🏎️', priceCoins: 2000, category: 'luxury', animationType: 'fullscreen', svgColor: '#ef4444' },
    { id: 'g-rocket', name: 'Cosmic Rocket', icon: '🚀', priceCoins: 5000, category: 'special', animationType: 'fullscreen', svgColor: '#3b82f6' },
    { id: 'g-crown', name: 'Royal Crown', icon: '👑', priceCoins: 10000, category: 'special', animationType: 'fullscreen', svgColor: '#eab308' },
    { id: 'g-teddy', name: 'Hug Teddy', icon: '🧸', priceCoins: 50, category: 'popular', animationType: 'pop', svgColor: '#f97316' },
    { id: 'g-kiss', name: 'Sweet Kiss', icon: '💋', priceCoins: 99, category: 'popular', animationType: 'pop', svgColor: '#ec4899' }
  ];

  const availableGifts = (gifts && gifts.length > 0) ? gifts : fallbackGifts;
  const activeGift = selectedGift || availableGifts[0];
  const totalPrice = (activeGift?.priceCoins || 0) * count;
  const userCoins = currentUser?.coins || 0;
  const canAfford = userCoins >= totalPrice;

  const quickCounts = isCP ? [1, 10, 52, 99, 520, 1314] : [1, 10, 66, 99, 520];

  const handleSend = async () => {
    if (!activeGift) return;
    if (!canAfford) {
      showNotification('Insufficient coins. Please recharge your wallet!');
      return;
    }

    setIsSending(true);
    try {
      await ApiClient.sendGift(targetUser.id, activeGift.id, count);
      showNotification(`Sent ${count}x ${activeGift.name} ${activeGift.icon} to ${targetUser.name}!`);
      await refreshUser();
      if (onSuccess) onSuccess();
      onClose();
    } catch (err: any) {
      showNotification(err?.message || 'Failed to send gift. Please try again.');
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[120] flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div 
        className="w-full max-w-md bg-[#13072b] border border-white/15 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-purple-900/60 to-pink-900/40 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <img 
                src={targetUser.avatar} 
                alt={targetUser.name} 
                className="w-10 h-10 rounded-2xl object-cover border border-amber-400"
              />
              {isCP && (
                <span className="absolute -bottom-1 -right-1 text-xs">❤️</span>
              )}
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-black text-white">{targetUser.name}</span>
                {isCP && (
                  <span className="text-[9px] font-black px-1.5 py-0.2 rounded-full bg-pink-500/30 text-pink-300 border border-pink-400/40">
                    CP PARTNER
                  </span>
                )}
              </div>
              {targetUser.uid && (
                <ProfileIdBadge uid={targetUser.uid} size="xs" />
              )}
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-xl bg-white/10 text-slate-300 hover:text-white hover:bg-white/15 transition-all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* User Balance Bar */}
        <div className="px-4 py-2 bg-black/40 border-b border-white/10 flex items-center justify-between text-xs">
          <span className="text-slate-400 flex items-center gap-1">
            <Coins className="w-3.5 h-3.5 text-amber-400" />
            My Coins: <span className="font-bold font-mono text-amber-300">{userCoins.toLocaleString()}</span>
          </span>
          {isCP && (
            <span className="text-pink-300 text-[11px] font-bold flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-pink-400" /> +1 Intimacy pt per coin
            </span>
          )}
        </div>

        {/* Gift Grid */}
        <div className="p-3 overflow-y-auto flex-1 grid grid-cols-4 gap-2">
          {availableGifts.map((g) => {
            const isSelected = activeGift?.id === g.id;
            return (
              <button
                key={g.id}
                onClick={() => setSelectedGift(g)}
                className={`p-2 rounded-2xl border transition-all flex flex-col items-center justify-between text-center relative ${
                  isSelected 
                    ? 'bg-gradient-to-b from-purple-600/40 to-pink-600/30 border-pink-400 shadow-[0_0_15px_rgba(244,114,182,0.3)] scale-[1.03]' 
                    : 'bg-white/5 border-white/10 hover:bg-white/10 hover:border-white/20'
                }`}
              >
                <div className="text-3xl my-1">{g.icon}</div>
                <div className="w-full">
                  <div className="text-[11px] font-bold text-white truncate">{g.name}</div>
                  <div className="text-[10px] font-black text-amber-400 font-mono mt-0.5 flex items-center justify-center gap-0.5">
                    🪙 {g.priceCoins.toLocaleString()}
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Quantity Select & Actions */}
        <div className="p-4 bg-black/60 border-t border-white/10 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-bold text-slate-300">Quantity:</span>
            <div className="flex items-center gap-1 flex-wrap justify-end">
              {quickCounts.map((qc) => (
                <button
                  key={qc}
                  onClick={() => setCount(qc)}
                  className={`px-2.5 py-1 rounded-xl text-xs font-bold font-mono transition-all ${
                    count === qc 
                      ? 'bg-pink-500 text-white shadow-md' 
                      : 'bg-white/10 text-slate-300 hover:bg-white/20'
                  }`}
                >
                  x{qc}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between pt-1">
            <div>
              <span className="text-[11px] text-slate-400 block">Total Cost</span>
              <span className="text-base font-black font-mono text-amber-400 flex items-center gap-1">
                🪙 {totalPrice.toLocaleString()}
              </span>
            </div>

            <button
              onClick={handleSend}
              disabled={isSending || !canAfford}
              className={`px-6 py-2.5 rounded-2xl font-black text-xs flex items-center gap-2 shadow-lg transition-all ${
                !canAfford 
                  ? 'bg-red-500/30 text-red-300 border border-red-500/40 cursor-not-allowed'
                  : isSending 
                    ? 'bg-pink-600/50 text-white animate-pulse'
                    : 'bg-gradient-to-r from-pink-500 to-purple-600 text-white hover:scale-105 active:scale-95 shadow-pink-500/25'
              }`}
            >
              <Send className="w-4 h-4" />
              <span>{isSending ? 'Sending...' : !canAfford ? 'Need Coins' : 'Send Gift'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
