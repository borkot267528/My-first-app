/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export * from './family/FamiliesModule';
export { FamiliesModule as default } from './family/FamiliesModule';
