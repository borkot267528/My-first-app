/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  Search, X, User as UserIcon, Radio, MessageSquare, Gift, 
  Sparkles, ExternalLink, Shield, CheckCircle2, Flame, Award, 
  ArrowUpRight, ArrowDownRight, Clock, Users, Hash, ChevronRight,
  Filter, Zap
} from 'lucide-react';
import { User, VoiceRoom } from '../../types';
import { useApp } from '../../context/AppContext';
import { ApiClient } from '../../lib/api';
import { searchUsersInFirestore } from '../../lib/firestoreUsers';
import { ProfileIdBadge } from '../common/ProfileIdBadge';
import { FriendProfileModal } from '../connections/FriendProfileModal';
import { DirectMessageModal } from '../connections/DirectMessageModal';
import { SendGiftDirectModal } from '../connections/SendGiftDirectModal';

interface UserSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialQuery?: string;
}

type FilterCategory = 'all' | 'online' | 'host' | 'vip' | 'staff';

export const UserSearchModal: React.FC<UserSearchModalProps> = ({
  isOpen,
  onClose,
  initialQuery = ''
}) => {
  const { currentUser, setActiveRoom, showNotification } = useApp();

  const [query, setQuery] = useState(initialQuery);
  const [filter, setFilter] = useState<FilterCategory>('all');
  const [results, setResults] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('aura_recent_searches');
      return stored ? JSON.parse(stored) : ['2383452', 'Elena', 'Alex'];
    } catch {
      return ['2383452', 'Elena', 'Alex'];
    }
  });

  // Action Modals State
  const [selectedUserForProfile, setSelectedUserForProfile] = useState<User | null>(null);
  const [selectedUserForDM, setSelectedUserForDM] = useState<User | null>(null);
  const [selectedUserForGift, setSelectedUserForGift] = useState<User | null>(null);

  const inputRef = useRef<HTMLInputElement>(null);
  const debounceTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Auto-focus input when opened
  useEffect(() => {
    if (isOpen) {
      if (initialQuery) {
        setQuery(initialQuery);
      }
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
    }
  }, [isOpen, initialQuery]);

  // Execute search function
  const performSearch = async (searchTerm: string, activeFilter: FilterCategory) => {
    setIsLoading(true);
    try {
      // 1. Try server API search
      const apiResults = await ApiClient.searchUsers(searchTerm, { 
        filter: activeFilter, 
        limit: 30 
      }).catch(() => null);

      if (apiResults && Array.isArray(apiResults)) {
        setResults(apiResults);
      } else {
        // Fallback to Firestore user search
        const fsResults = await searchUsersInFirestore(searchTerm);
        let filtered = fsResults;
        if (activeFilter === 'online') filtered = filtered.filter(u => u.isOnline);
        if (activeFilter === 'vip') filtered = filtered.filter(u => u.vipLevel && u.vipLevel !== 'none');
        if (activeFilter === 'staff') filtered = filtered.filter(u => u.role !== 'user');
        setResults(filtered);
      }
    } catch (err) {
      console.warn('User search error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Debounced query execution
  useEffect(() => {
    if (!isOpen) return;

    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }

    debounceTimerRef.current = setTimeout(() => {
      performSearch(query, filter);
    }, 220);

    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
    };
  }, [query, filter, isOpen]);

  // Save query to recent searches
  const saveRecentSearch = (term: string) => {
    const trimmed = term.trim();
    if (!trimmed) return;
    setRecentSearches(prev => {
      const updated = [trimmed, ...prev.filter(t => t.toLowerCase() !== trimmed.toLowerCase())].slice(0, 8);
      try {
        localStorage.setItem('aura_recent_searches', JSON.stringify(updated));
      } catch {}
      return updated;
    });
  };

  const removeRecentSearch = (termToRemove: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setRecentSearches(prev => {
      const updated = prev.filter(t => t !== termToRemove);
      try {
        localStorage.setItem('aura_recent_searches', JSON.stringify(updated));
      } catch {}
      return updated;
    });
  };

  const clearAllRecent = () => {
    setRecentSearches([]);
    try {
      localStorage.removeItem('aura_recent_searches');
    } catch {}
  };

  const handleSelectRecent = (term: string) => {
    setQuery(term);
    saveRecentSearch(term);
  };

  const handleJoinVoiceRoom = async (user: User & { activeRoomId?: string }) => {
    const roomId = user.activeRoomId || user.uid || user.id;
    try {
      showNotification(`Joining voice room of ${user.name}... 🎙️`);
      const { room } = await ApiClient.getRoomById(roomId);
      if (room) {
        setActiveRoom(room);
        onClose();
        return;
      }
    } catch (err) {
      // Create or join fallback
      const fallbackRoom: VoiceRoom = {
        id: roomId,
        title: `${user.name}'s Lounge`,
        topic: 'Live Voice Chat & PK',
        category: 'popular',
        coverImage: user.avatar || 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=400&q=80',
        hostId: user.id,
        hostName: user.name,
        hostAvatar: user.avatar,
        hostUid: user.uid,
        hostFrame: user.frame,
        country: user.country || 'United States',
        countryFlag: user.countryFlag || '🇺🇸',
        language: 'English',
        onlineCount: 1,
        maxSeats: 8,
        isLocked: false,
        announcement: `Welcome to ${user.name}'s official voice room!`,
        tags: ['Voice', 'PK', 'Music'],
        seats: [
          { index: 0, isLocked: false, isMuted: false, isSpeaking: false, contributionCoin: 0, userId: user.id, userName: user.name, userAvatar: user.avatar, userFrame: user.frame }
        ],
        pkState: undefined,
        createdAt: new Date().toISOString()
      };
      setActiveRoom(fallbackRoom);
      onClose();
    }
  };

  // Keyboard shortcut: Escape to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-start sm:items-center justify-center p-2 sm:p-4 overflow-y-auto animate-fadeIn">
        <div 
          className="relative w-full max-w-2xl bg-gradient-to-b from-[#130924] via-[#0e051d] to-[#090214] border border-white/15 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] mt-2 sm:mt-0"
          onClick={(e) => e.stopPropagation()}
        >
          
          {/* TOP SEARCH BAR HEADER */}
          <div className="p-4 sm:p-5 border-b border-white/10 bg-white/5 backdrop-blur-md space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-400 to-yellow-500 flex items-center justify-center text-black font-black shadow-md">
                  <Search className="w-4 h-4 stroke-[2.5]" />
                </div>
                <div>
                  <h2 className="text-sm font-black text-white tracking-wide flex items-center gap-2">
                    Search Users
                    <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-amber-400/15 text-amber-300 border border-amber-400/30">
                      UID & Name
                    </span>
                  </h2>
                  <p className="text-[11px] text-slate-400">
                    Find users by unique User ID (UID / Nigo ID) or display name
                  </p>
                </div>
              </div>

              <button
                onClick={onClose}
                className="p-2 rounded-xl bg-white/5 hover:bg-white/15 text-slate-300 hover:text-white transition-colors cursor-pointer"
                title="Close (Esc)"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* INPUT FIELD */}
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-amber-400">
                <Search className="w-4 h-4" />
              </div>
              <input
                ref={inputRef}
                type="text"
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  if (e.target.value.trim()) {
                    saveRecentSearch(e.target.value);
                  }
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    saveRecentSearch(query);
                    performSearch(query, filter);
                  }
                }}
                placeholder="Search by User ID (e.g. 2383452, borkot_777) or name..."
                className="w-full pl-10 pr-10 py-3 bg-black/60 border border-white/20 focus:border-amber-400 rounded-2xl text-white text-sm outline-none transition-all placeholder:text-slate-500 shadow-inner"
              />
              {query && (
                <button
                  type="button"
                  onClick={() => {
                    setQuery('');
                    inputRef.current?.focus();
                  }}
                  className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-white cursor-pointer"
                  title="Clear input"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* FILTER PILLS */}
            <div className="flex items-center gap-1.5 overflow-x-auto py-0.5 no-scrollbar text-xs">
              {[
                { id: 'all', label: 'All Users' },
                { id: 'online', label: '🟢 Online Now' },
                { id: 'host', label: '🎙️ Room Hosts' },
                { id: 'vip', label: '👑 VIP Members' },
                { id: 'staff', label: '🛡️ Official Staff' }
              ].map(f => (
                <button
                  key={f.id}
                  onClick={() => setFilter(f.id as FilterCategory)}
                  className={`px-3 py-1 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
                    filter === f.id
                      ? 'bg-amber-400 text-black font-black shadow-md'
                      : 'bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          {/* RECENT SEARCHES CHIPS (When query is empty) */}
          {!query && recentSearches.length > 0 && (
            <div className="px-5 py-3 border-b border-white/5 bg-white/[0.02]">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-bold text-slate-400 flex items-center gap-1">
                  <Clock className="w-3 h-3 text-amber-400" />
                  Recent Searches
                </span>
                <button
                  onClick={clearAllRecent}
                  className="text-[10px] text-slate-500 hover:text-slate-300 cursor-pointer"
                >
                  Clear all
                </button>
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                {recentSearches.map(term => (
                  <button
                    key={term}
                    onClick={() => handleSelectRecent(term)}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white/5 hover:bg-amber-400/20 text-slate-300 hover:text-amber-300 border border-white/10 hover:border-amber-400/30 text-xs font-mono transition-all cursor-pointer group"
                  >
                    <span>{term}</span>
                    <span
                      onClick={(e) => removeRecentSearch(term, e)}
                      className="opacity-50 hover:opacity-100 hover:text-red-400 ml-0.5"
                    >
                      &times;
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* SEARCH RESULTS BODY */}
          <div className="p-4 sm:p-5 space-y-3 overflow-y-auto flex-1 min-h-[300px]">
            {isLoading ? (
              <div className="py-16 flex flex-col items-center justify-center gap-3 text-slate-400">
                <div className="w-8 h-8 rounded-full border-2 border-amber-400 border-t-transparent animate-spin" />
                <span className="text-xs font-semibold">Searching users by ID and Name...</span>
              </div>
            ) : results.length === 0 ? (
              <div className="py-16 text-center space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 mx-auto flex items-center justify-center text-slate-400">
                  <Users className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">No users found</h4>
                  <p className="text-xs text-slate-400 max-w-xs mx-auto mt-1">
                    {query 
                      ? `We couldn't find anyone matching "${query}". Try searching by exact User ID or display name.`
                      : 'Type a User ID or name above to start discovering users.'}
                  </p>
                </div>
                {query && (
                  <button
                    onClick={() => setQuery('')}
                    className="px-3.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-bold text-white transition-colors cursor-pointer"
                  >
                    Clear Search
                  </button>
                )}
              </div>
            ) : (
              <div className="space-y-2.5">
                <div className="flex items-center justify-between text-[11px] text-slate-400 px-1 font-semibold">
                  <span>
                    {query ? `Search results for "${query}"` : 'Recommended & Active Users'}
                  </span>
                  <span>{results.length} found</span>
                </div>

                {results.map((user) => {
                  const isSelf = currentUser?.id === user.id;
                  const hasActiveRoom = (user as any).activeRoomId || user.role === 'host';

                  return (
                    <div
                      key={user.id}
                      className="p-3.5 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-amber-400/40 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 group"
                    >
                      {/* USER PROFILE INFO */}
                      <div className="flex items-center gap-3 min-w-0">
                        {/* Avatar */}
                        <div 
                          className="relative cursor-pointer shrink-0"
                          onClick={() => setSelectedUserForProfile(user)}
                        >
                          <div className={`w-12 h-12 rounded-2xl p-0.5 shadow-md ${
                            user.role === 'ceo' 
                              ? 'bg-gradient-to-tr from-amber-400 to-yellow-500' 
                              : user.vipLevel === 'svip' 
                              ? 'bg-gradient-to-tr from-pink-500 to-purple-600'
                              : 'bg-white/10'
                          }`}>
                            <img
                              src={user.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80'}
                              alt={user.name}
                              className="w-full h-full object-cover rounded-xl"
                            />
                          </div>

                          {/* Online indicator */}
                          <span className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-black ${
                            user.isOnline ? 'bg-emerald-400' : 'bg-slate-500'
                          }`} />
                        </div>

                        {/* Details */}
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span 
                              className="font-black text-white text-sm truncate hover:text-amber-300 cursor-pointer"
                              onClick={() => setSelectedUserForProfile(user)}
                            >
                              {user.name}
                            </span>

                            {isSelf && (
                              <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-amber-400/20 text-amber-300 border border-amber-400/30">
                                You
                              </span>
                            )}

                            {user.vipLevel === 'svip' && (
                              <span className="text-[9px] font-black px-1.5 py-0.2 rounded bg-gradient-to-r from-amber-400 to-yellow-500 text-black shadow">
                                SVIP
                              </span>
                            )}
                            {user.vipLevel === 'vip' && (
                              <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-purple-600 text-white">
                                VIP
                              </span>
                            )}

                            {user.role && user.role !== 'user' && (
                              <span className="text-[9px] font-bold px-1.5 py-0.2 rounded uppercase bg-blue-500/20 text-blue-300 border border-blue-500/30">
                                {user.role.replace('_', ' ')}
                              </span>
                            )}
                          </div>

                          {/* User ID Badge & Level Badges */}
                          <div className="flex items-center gap-2 mt-1 flex-wrap">
                            <ProfileIdBadge
                              uid={user.uid || (user as any).nigoId || user.id}
                              size="xs"
                              showLabel={true}
                              canCopy={true}
                              onCopy={() => showNotification('UID copied to clipboard!')}
                            />

                            <span className="text-[10px] text-slate-300 flex items-center gap-1">
                              <span>{user.countryFlag || '🌐'}</span>
                              <span className="hidden xs:inline">{user.country || 'Global'}</span>
                            </span>

                            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-amber-400/10 text-amber-300 border border-amber-400/20 flex items-center gap-0.5">
                              <ArrowUpRight className="w-2.5 h-2.5" /> Lv.{user.sendingLevel || user.level || 1}
                            </span>
                          </div>

                          {/* Bio preview if available */}
                          {user.bio && (
                            <p className="text-[11px] text-slate-400 truncate max-w-sm mt-0.5">
                              {user.bio}
                            </p>
                          )}
                        </div>
                      </div>

                      {/* ACTION BUTTONS */}
                      <div className="flex items-center gap-1.5 sm:self-center shrink-0 flex-wrap justify-end">
                        {/* If user is hosting a live voice room */}
                        {hasActiveRoom && (
                          <button
                            onClick={() => handleJoinVoiceRoom(user)}
                            className="px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-rose-500 to-pink-600 hover:from-rose-400 hover:to-pink-500 text-white font-bold text-xs flex items-center gap-1 shadow-md shadow-pink-500/20 cursor-pointer animate-pulse"
                            title="Join Voice Room"
                          >
                            <Radio className="w-3.5 h-3.5" />
                            <span>Live Room</span>
                          </button>
                        )}

                        {/* View Profile */}
                        <button
                          onClick={() => setSelectedUserForProfile(user)}
                          className="px-2.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-200 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                          title="View Profile Details"
                        >
                          <UserIcon className="w-3.5 h-3.5 text-amber-400" />
                          <span className="hidden xs:inline">Profile</span>
                        </button>

                        {/* Send Direct Message (DM) */}
                        {!isSelf && (
                          <button
                            onClick={() => setSelectedUserForDM(user)}
                            className="p-1.5 sm:px-2.5 sm:py-1.5 rounded-xl bg-white/10 hover:bg-purple-600/30 text-purple-300 border border-purple-500/20 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                            title="Direct Message"
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                            <span className="hidden sm:inline">Message</span>
                          </button>
                        )}

                        {/* Send Gift */}
                        {!isSelf && (
                          <button
                            onClick={() => setSelectedUserForGift(user)}
                            className="p-1.5 sm:px-2.5 sm:py-1.5 rounded-xl bg-gradient-to-r from-amber-400/20 to-yellow-500/20 hover:from-amber-400/30 hover:to-yellow-500/30 text-amber-300 border border-amber-400/30 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                            title="Send Gift"
                          >
                            <Gift className="w-3.5 h-3.5 text-amber-400" />
                            <span className="hidden sm:inline">Gift</span>
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* FOOTER INFO BAR */}
          <div className="p-3 bg-[#07010f] border-t border-white/10 flex items-center justify-between text-[11px] text-slate-400">
            <span className="flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              Live search connects across PostgreSQL and Firebase Firestore
            </span>
            <span className="text-slate-500 hidden sm:inline">
              Press <kbd className="px-1.5 py-0.5 rounded bg-white/10 font-mono text-[10px] text-slate-300">Esc</kbd> to exit
            </span>
          </div>

        </div>
      </div>

      {/* CONNECTED MODALS */}
      {selectedUserForProfile && (
        <FriendProfileModal
          isOpen={Boolean(selectedUserForProfile)}
          onClose={() => setSelectedUserForProfile(null)}
          user={selectedUserForProfile}
          onMessage={(u) => {
            setSelectedUserForProfile(null);
            setSelectedUserForDM(u);
          }}
          onSendGift={(u) => {
            setSelectedUserForProfile(null);
            setSelectedUserForGift(u);
          }}
        />
      )}

      {selectedUserForDM && (
        <DirectMessageModal
          isOpen={Boolean(selectedUserForDM)}
          onClose={() => setSelectedUserForDM(null)}
          targetUser={selectedUserForDM}
        />
      )}

      {selectedUserForGift && (
        <SendGiftDirectModal
          isOpen={Boolean(selectedUserForGift)}
          onClose={() => setSelectedUserForGift(null)}
          targetUser={selectedUserForGift}
        />
      )}
    </>
  );
};
