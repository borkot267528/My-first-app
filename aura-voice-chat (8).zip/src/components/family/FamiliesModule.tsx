/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  Users, 
  Trophy, 
  Shield, 
  Sparkles, 
  Search, 
  Plus, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Crown, 
  Flame, 
  ChevronRight, 
  Globe, 
  Lock, 
  ArrowRight, 
  Send, 
  Check, 
  X, 
  RefreshCw, 
  Award,
  Layers,
  FileText,
  UserCheck,
  LogOut,
  Star
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ApiClient } from '../../lib/api';
import { Family, FamilyMember, FamilyApplication } from '../../types';

export interface FamiliesModuleProps {
  /** Initial active tab */
  initialTab?: 'leaderboard' | 'browse' | 'top_rated' | 'my_family' | 'applications';
  /** Optional callback when a family is selected */
  onSelectFamily?: (family: Family) => void;
  /** Custom class names */
  className?: string;
}

const CATEGORIES = [
  { id: 'all', label: 'All Families' },
  { id: 'Gaming & Social', label: 'Gaming & PK' },
  { id: 'Music & Acoustic', label: 'Music & Singing' },
  { id: 'Social', label: 'Social & Chill' },
];

export const FamiliesModule: React.FC<FamiliesModuleProps> = ({
  initialTab = 'leaderboard',
  onSelectFamily,
  className = '',
}) => {
  const { families: contextFamilies, currentUser, refreshUser, showNotification } = useApp();

  const [activeTab, setActiveTab] = useState<'leaderboard' | 'browse' | 'top_rated' | 'my_family' | 'applications'>(initialTab);
  const [families, setFamilies] = useState<Family[]>(contextFamilies || []);
  const [loading, setLoading] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Application modal state
  const [applyingFamily, setApplyingFamily] = useState<Family | null>(null);
  const [applicationPitch, setApplicationPitch] = useState<string>('');
  const [isSubmittingApp, setIsSubmittingApp] = useState<boolean>(false);

  // User's applications list
  const [myApplications, setMyApplications] = useState<FamilyApplication[]>([]);
  const [incomingApplications, setIncomingApplications] = useState<FamilyApplication[]>([]);
  const [loadingApps, setLoadingApps] = useState<boolean>(false);

  // Create Family modal state
  const [showCreateModal, setShowCreateModal] = useState<boolean>(false);
  const [isCreatingFamily, setIsCreatingFamily] = useState<boolean>(false);
  const [createForm, setCreateForm] = useState({
    name: '',
    badge: '👑',
    slogan: 'Together we conquer and thrive in voice!',
    description: '',
    announcement: 'Welcome all new clan members!',
    category: 'Gaming & Social',
    privacy: 'public',
    joinMethod: 'approval' as 'anyone' | 'approval'
  });

  // Load families from API
  const loadFamilies = async () => {
    setLoading(true);
    try {
      const data = await ApiClient.getFamilies();
      if (Array.isArray(data) && data.length > 0) {
        setFamilies(data);
      }
    } catch (err) {
      console.error('Failed to load families:', err);
    } finally {
      setLoading(false);
    }
  };

  // Load applications
  const loadApplications = async () => {
    if (!currentUser) return;
    setLoadingApps(true);
    try {
      const apps = await ApiClient.getMyFamilyApplications();
      setMyApplications(apps);

      // If user is family leader, also load incoming applications
      if (currentUser.familyId) {
        const incoming = await ApiClient.getFamilyApplications(currentUser.familyId);
        setIncomingApplications(incoming);
      }
    } catch (err) {
      // Non-blocking
    } finally {
      setLoadingApps(false);
    }
  };

  useEffect(() => {
    loadFamilies();
    loadApplications();
  }, [currentUser?.id, currentUser?.familyId]);

  // Sync with context
  useEffect(() => {
    if (contextFamilies && contextFamilies.length > 0) {
      setFamilies(contextFamilies);
    }
  }, [contextFamilies]);

  // Sorted leaderboards (sorted by totalContribution or ranking)
  const sortedLeaderboard = useMemo(() => {
    return [...families].sort((a, b) => (b.totalContribution || 0) - (a.totalContribution || 0));
  }, [families]);

  // Top 3 Podium
  const top1 = sortedLeaderboard[0] || null;
  const top2 = sortedLeaderboard[1] || null;
  const top3 = sortedLeaderboard[2] || null;

  // Filtered families for search / category
  const filteredFamilies = useMemo(() => {
    return sortedLeaderboard.filter((f) => {
      // Category filter
      if (selectedCategory !== 'all' && f.category !== selectedCategory) {
        return false;
      }
      // Top rated filter
      if (activeTab === 'top_rated') {
        const isTopTier = (f.level && f.level >= 5) || f.joinMethod === 'approval' || (f.ranking && f.ranking <= 3);
        if (!isTopTier) return false;
      }
      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = f.name?.toLowerCase().includes(q);
        const matchesId = f.familyId?.toLowerCase().includes(q);
        const matchesLeader = f.leaderName?.toLowerCase().includes(q);
        if (!matchesName && !matchesId && !matchesLeader) return false;
      }
      return true;
    });
  }, [sortedLeaderboard, selectedCategory, activeTab, searchQuery]);

  // Current user's family object
  const userFamily = useMemo(() => {
    if (!currentUser?.familyId) return null;
    return families.find(f => f.id === currentUser.familyId || f.familyId === currentUser.familyId) || null;
  }, [families, currentUser?.familyId]);

  // Check if user has pending application for a given family
  const hasPendingAppForFamily = (familyId: string) => {
    return myApplications.some(app => app.familyId === familyId && app.status === 'pending');
  };

  // Join family directly (Open group)
  const handleJoinDirect = async (family: Family) => {
    if (!currentUser) {
      showNotification('⚠️ Please log in to join a family');
      return;
    }
    if (currentUser.familyId === family.id) {
      showNotification(`You are already a member of ${family.name}!`);
      return;
    }

    try {
      await ApiClient.joinFamily(family.id);
      showNotification(`🎉 Congratulations! You have joined "${family.name}"!`);
      await refreshUser();
      loadFamilies();
      loadApplications();
    } catch (err: any) {
      showNotification(`❌ ${err.message || 'Failed to join family'}`);
    }
  };

  // Submit Application for Membership (Top-Rated / Approval required)
  const handleSubmitApplication = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!applyingFamily) return;

    setIsSubmittingApp(true);
    try {
      await ApiClient.applyToFamily(applyingFamily.id, applicationPitch);
      showNotification(`📝 Application sent to "${applyingFamily.name}" leaders!`);
      setApplyingFamily(null);
      setApplicationPitch('');
      loadApplications();
    } catch (err: any) {
      showNotification(`❌ ${err.message || 'Failed to submit application'}`);
    } finally {
      setIsSubmittingApp(false);
    }
  };

  // Decide on incoming application (Leader approve/reject)
  const handleApplicationDecision = async (appId: string, decision: 'approve' | 'reject') => {
    try {
      await ApiClient.decideFamilyApplication(appId, decision);
      showNotification(`Application ${decision === 'approve' ? 'approved' : 'rejected'} successfully.`);
      loadApplications();
      loadFamilies();
    } catch (err: any) {
      showNotification(`❌ ${err.message || 'Failed to process application'}`);
    }
  };

  // Leave current family
  const handleLeaveFamily = async () => {
    if (!userFamily) return;
    if (window.confirm(`Are you sure you want to leave ${userFamily.name}? You will lose clan perks.`)) {
      try {
        await ApiClient.leaveFamily(userFamily.id);
        showNotification(`You have left ${userFamily.name}.`);
        await refreshUser();
        loadFamilies();
        loadApplications();
      } catch (err: any) {
        showNotification(`❌ ${err.message || 'Failed to leave family'}`);
      }
    }
  };

  // Create new family
  const handleCreateFamilySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!createForm.name.trim()) {
      showNotification('⚠️ Family Name is required.');
      return;
    }
    const fee = 500;
    if ((currentUser?.coins || 0) < fee) {
      showNotification(`⚠️ Insufficient coins. Required: ${fee} coins.`);
      return;
    }

    setIsCreatingFamily(true);
    try {
      const res = await ApiClient.createFamily(createForm);
      showNotification(`🎉 Family "${res.name}" founded successfully!`);
      setShowCreateModal(false);
      await refreshUser();
      loadFamilies();
      setActiveTab('my_family');
    } catch (err: any) {
      showNotification(`❌ ${err.message || 'Failed to create family'}`);
    } finally {
      setIsCreatingFamily(false);
    }
  };

  return (
    <div className={`space-y-5 select-none ${className}`}>
      
      {/* ========================================================= */}
      {/* 1. HEADER HERO: Title, My Family Tag & Create Action     */}
      {/* ========================================================= */}
      <div className="relative overflow-hidden rounded-3xl p-5 sm:p-6 bg-gradient-to-r from-purple-950/80 via-[#180829] to-pink-950/80 backdrop-blur-xl border border-white/15 shadow-2xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-gradient-to-tr from-amber-400 via-rose-500 to-purple-600 p-0.5 shadow-xl shadow-purple-950/50 flex items-center justify-center shrink-0">
              <div className="w-full h-full bg-[#160626] rounded-[14px] flex items-center justify-center text-3xl">
                {userFamily?.badge || '🛡️'}
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2">
                  <span>Families & Guilds</span>
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  Global Clans
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1 line-clamp-1">
                {userFamily 
                  ? `Your Clan: ${userFamily.name} • LV.${userFamily.level || 1} • Rank #${userFamily.ranking || 1}`
                  : 'Join an existing group, compete in PK wars, or apply to top-rated families!'}
              </p>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2 self-start sm:self-auto shrink-0">
            {userFamily ? (
              <button
                type="button"
                onClick={() => setActiveTab('my_family')}
                className="px-3.5 py-2 rounded-xl bg-purple-500/20 hover:bg-purple-500/30 text-purple-200 border border-purple-500/40 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow"
              >
                <Shield className="w-3.5 h-3.5 text-purple-400" />
                <span>My Clan</span>
              </button>
            ) : null}

            <button
              type="button"
              onClick={() => setShowCreateModal(true)}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 hover:brightness-110 active:scale-95 text-black text-xs font-black transition shadow-lg shadow-amber-900/40 flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Create Family</span>
            </button>
          </div>
        </div>

        {/* Quick Announcement ticker */}
        <div className="p-2.5 rounded-2xl bg-black/40 border border-white/10 flex items-center gap-2 text-xs text-slate-200">
          <span className="bg-gradient-to-r from-pink-500 to-purple-600 text-white font-black text-[9px] px-2 py-0.5 rounded-md uppercase shrink-0">
            NOTICE
          </span>
          <p className="truncate text-slate-300">
            {userFamily?.announcement || 'Top 3 Families on Sunday 00:00 UTC receive 250,000 bonus prize pool coins & VIP Badges!'}
          </p>
        </div>
      </div>

      {/* ========================================================= */}
      {/* 2. NAVIGATION TABS                                        */}
      {/* ========================================================= */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
        {[
          { id: 'leaderboard', label: 'Leaderboard 🏆', icon: Trophy },
          { id: 'browse', label: 'Browse & Join ⚡', icon: Users },
          { id: 'top_rated', label: 'Top-Rated (Apply) ⭐', icon: Star },
          { id: 'applications', label: `Applications (${myApplications.length + incomingApplications.length})`, icon: FileText },
          { id: 'my_family', label: 'My Family Clan 🏰', icon: Shield },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3.5 py-2 rounded-2xl text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 cursor-pointer ${
                isActive
                  ? 'bg-gradient-to-r from-pink-500 via-purple-600 to-indigo-600 text-white shadow-lg shadow-pink-500/20 scale-102 font-black'
                  : 'bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ========================================================= */}
      {/* 3. TAB 1: LEADERBOARD & PODIUM (TOP 3 CLASH)              */}
      {/* ========================================================= */}
      {activeTab === 'leaderboard' && (
        <div className="space-y-6 animate-fadeIn">
          
          {/* Top 3 Visual Podium */}
          <div className="grid grid-cols-3 gap-2 sm:gap-4 items-end pt-8 pb-2">
            
            {/* #2 SILVER PODIUM (Left) */}
            {top2 && (
              <div 
                onClick={() => onSelectFamily ? onSelectFamily(top2) : undefined}
                className="p-3 sm:p-4 rounded-3xl bg-gradient-to-b from-slate-400/20 via-[#130b20] to-[#0a0414] border border-slate-300/30 text-center space-y-2 relative shadow-xl hover:-translate-y-1 transition-all cursor-pointer"
              >
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-slate-300 text-black font-black text-xs flex items-center justify-center shadow-lg border border-white">
                  🥈 2
                </div>
                <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl mx-auto bg-slate-400/20 p-1 flex items-center justify-center text-2xl border border-slate-300/40">
                  {top2.badge || '🐺'}
                </div>
                <div>
                  <h4 className="font-extrabold text-white text-xs sm:text-sm truncate">{top2.name}</h4>
                  <p className="text-[10px] text-slate-400 truncate">Leader: {top2.leaderName}</p>
                </div>
                <div className="text-[11px] font-mono font-black text-amber-300">
                  💎 {((top2.totalContribution || 0) / 1000).toFixed(0)}K
                </div>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    if (top2.joinMethod === 'approval') setApplyingFamily(top2);
                    else handleJoinDirect(top2);
                  }}
                  className="w-full py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-[10px] transition cursor-pointer"
                >
                  {top2.joinMethod === 'approval' ? 'Apply' : 'Join'}
                </button>
              </div>
            )}

            {/* #1 GOLD PODIUM (Center, Elevated) */}
            {top1 && (
              <div 
                onClick={() => onSelectFamily ? onSelectFamily(top1) : undefined}
                className="p-4 sm:p-5 rounded-3xl bg-gradient-to-b from-amber-500/30 via-yellow-600/10 to-[#120520] border-2 border-amber-400/60 text-center space-y-2.5 relative shadow-2xl hover:-translate-y-1.5 transition-all cursor-pointer scale-105 z-10"
              >
                <div className="absolute -top-6 left-1/2 -translate-x-1/2 flex flex-col items-center">
                  <span className="text-xl animate-bounce">👑</span>
                  <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-400 to-yellow-300 text-black font-black text-sm flex items-center justify-center shadow-2xl border-2 border-white">
                    🥇 1
                  </div>
                </div>
                <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl mx-auto bg-amber-500/20 p-1 flex items-center justify-center text-3xl border border-amber-400/50 shadow-inner mt-2">
                  {top1.badge || '👑'}
                </div>
                <div>
                  <h4 className="font-black text-white text-sm sm:text-base truncate flex items-center justify-center gap-1">
                    <span>{top1.name}</span>
                  </h4>
                  <p className="text-[10px] text-amber-200 truncate">Leader: {top1.leaderName} • LV.{top1.level}</p>
                </div>
                <div className="text-xs sm:text-sm font-mono font-black text-amber-400">
                  💎 {((top1.totalContribution || 0) / 1000).toLocaleString()}K XP
                </div>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    if (top1.joinMethod === 'approval') setApplyingFamily(top1);
                    else handleJoinDirect(top1);
                  }}
                  className="w-full py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:brightness-110 active:scale-95 text-black font-black text-xs shadow-lg shadow-amber-900/40 transition cursor-pointer"
                >
                  {top1.joinMethod === 'approval' ? 'Apply for Clan ⭐' : 'Join Now ⚡'}
                </button>
              </div>
            )}

            {/* #3 BRONZE PODIUM (Right) */}
            {top3 && (
              <div 
                onClick={() => onSelectFamily ? onSelectFamily(top3) : undefined}
                className="p-3 sm:p-4 rounded-3xl bg-gradient-to-b from-amber-800/20 via-[#130b20] to-[#0a0414] border border-amber-700/30 text-center space-y-2 relative shadow-xl hover:-translate-y-1 transition-all cursor-pointer"
              >
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-amber-700 text-white font-black text-xs flex items-center justify-center shadow-lg border border-white">
                  🥉 3
                </div>
                <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl mx-auto bg-amber-700/20 p-1 flex items-center justify-center text-2xl border border-amber-700/40">
                  {top3.badge || '✨'}
                </div>
                <div>
                  <h4 className="font-extrabold text-white text-xs sm:text-sm truncate">{top3.name}</h4>
                  <p className="text-[10px] text-slate-400 truncate">Leader: {top3.leaderName}</p>
                </div>
                <div className="text-[11px] font-mono font-black text-amber-300">
                  💎 {((top3.totalContribution || 0) / 1000).toFixed(0)}K
                </div>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    if (top3.joinMethod === 'approval') setApplyingFamily(top3);
                    else handleJoinDirect(top3);
                  }}
                  className="w-full py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-[10px] transition cursor-pointer"
                >
                  {top3.joinMethod === 'approval' ? 'Apply' : 'Join'}
                </button>
              </div>
            )}
          </div>

          {/* Search & Category Filter Toolbar */}
          <div className="flex flex-col sm:flex-row gap-2.5 justify-between sm:items-center">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-purple-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search families by name, ID, or leader..."
                className="w-full bg-white/5 border border-white/10 rounded-2xl pl-10 pr-4 py-2 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-pink-500 shadow-inner"
              />
            </div>

            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
              {CATEGORIES.map(cat => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
                    selectedCategory === cat.id
                      ? 'bg-white text-purple-900 shadow font-black'
                      : 'bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Complete Rankings List */}
          <div className="space-y-2.5">
            {filteredFamilies.map((fam, idx) => {
              const rank = fam.ranking || idx + 1;
              const isCurrentMember = currentUser?.familyId === fam.id;
              const isPending = hasPendingAppForFamily(fam.id);
              const isTopTier = fam.joinMethod === 'approval' || fam.level >= 5;

              return (
                <div
                  key={fam.id}
                  className={`p-3.5 sm:p-4 rounded-2xl border transition-all duration-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-md ${
                    isCurrentMember
                      ? 'border-purple-500 bg-purple-950/40 shadow-purple-900/20'
                      : 'border-white/10 bg-white/[0.03] hover:bg-white/[0.06] hover:border-pink-500/40'
                  }`}
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    {/* Rank Badge */}
                    <span className={`w-8 h-8 rounded-xl font-black text-xs flex items-center justify-center shrink-0 ${
                      rank === 1 ? 'bg-amber-400 text-black' :
                      rank === 2 ? 'bg-slate-300 text-black' :
                      rank === 3 ? 'bg-amber-700 text-white' :
                      'bg-white/10 text-slate-300'
                    }`}>
                      #{rank}
                    </span>

                    {/* Clan Emblem */}
                    <div className="w-11 h-11 rounded-2xl bg-white/5 border border-white/15 flex items-center justify-center text-2xl shrink-0">
                      {fam.badge || '🛡️'}
                    </div>

                    {/* Metadata */}
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <h4 className="font-extrabold text-white text-sm sm:text-base truncate">
                          {fam.name}
                        </h4>
                        <span className="text-[10px] px-1.5 py-0.2 bg-amber-500/20 text-amber-300 font-bold rounded">
                          LV.{fam.level}
                        </span>
                        {fam.country && (
                          <span className="text-xs">{fam.country}</span>
                        )}
                      </div>

                      <p className="text-xs text-slate-400 truncate mt-0.5">
                        Leader: <b className="text-slate-200">{fam.leaderName}</b> • {fam.slogan}
                      </p>

                      <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-400">
                        <span className="text-amber-400 font-mono font-bold">
                          💎 {((fam.totalContribution || 0) / 1000).toFixed(0)}K XP
                        </span>
                        <span>•</span>
                        <span>{fam.memberCount}/{fam.maxMembers} Members</span>
                        <span>•</span>
                        <span className={isTopTier ? 'text-pink-300 font-semibold' : 'text-emerald-300 font-semibold'}>
                          {isTopTier ? 'Approval Required' : 'Open Entry'}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center justify-between sm:justify-end gap-2 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-white/5">
                    {isCurrentMember ? (
                      <span className="px-3.5 py-1.5 rounded-xl bg-purple-500/20 text-purple-300 border border-purple-500/40 text-xs font-black flex items-center gap-1">
                        <Check className="w-3.5 h-3.5" />
                        <span>Member ✓</span>
                      </span>
                    ) : isPending ? (
                      <span className="px-3.5 py-1.5 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5" />
                        <span>Applied ⏳</span>
                      </span>
                    ) : isTopTier ? (
                      <button
                        type="button"
                        onClick={() => setApplyingFamily(fam)}
                        className="px-4 py-2 rounded-xl bg-gradient-to-r from-pink-500 to-purple-600 hover:brightness-110 active:scale-95 text-white font-black text-xs shadow-md shadow-pink-500/20 flex items-center gap-1.5 transition cursor-pointer"
                      >
                        <Star className="w-3.5 h-3.5 text-amber-300" />
                        <span>Apply ⭐</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => handleJoinDirect(fam)}
                        className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:brightness-110 active:scale-95 text-white font-black text-xs shadow-md shadow-emerald-900/30 flex items-center gap-1.5 transition cursor-pointer"
                      >
                        <Users className="w-3.5 h-3.5" />
                        <span>Join Group</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* 4. TAB 2: BROWSE & JOIN OPEN GROUPS                       */}
      {/* ========================================================= */}
      {activeTab === 'browse' && (
        <div className="space-y-4 animate-fadeIn">
          <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/10 space-y-1">
            <h4 className="font-extrabold text-white text-sm flex items-center gap-1.5">
              <Users className="w-4 h-4 text-emerald-400" />
              <span>Instant-Join Family Groups</span>
            </h4>
            <p className="text-xs text-slate-300">
              Clans with instant entry enabled! No approvals required—tap join to receive immediate clan buffs.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {families
              .filter(f => f.joinMethod !== 'approval')
              .map(fam => {
                const isCurrentMember = currentUser?.familyId === fam.id;
                return (
                  <div
                    key={fam.id}
                    className="p-4 rounded-3xl bg-gradient-to-b from-white/[0.05] to-[#120622] border border-white/10 hover:border-emerald-500/40 transition-all space-y-3 shadow-lg flex flex-col justify-between"
                  >
                    <div className="space-y-2.5">
                      <div className="flex items-center justify-between">
                        <span className="w-12 h-12 rounded-2xl bg-white/5 border border-white/15 flex items-center justify-center text-3xl">
                          {fam.badge || '🛡️'}
                        </span>
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                          Instant Entry
                        </span>
                      </div>

                      <div>
                        <h4 className="font-black text-white text-base">{fam.name}</h4>
                        <p className="text-xs text-slate-400 line-clamp-2 mt-0.5">{fam.slogan}</p>
                      </div>

                      <div className="flex items-center justify-between text-xs pt-2 border-t border-white/5">
                        <span className="text-slate-300">👑 {fam.leaderName}</span>
                        <span className="font-mono text-amber-400 font-bold">{fam.memberCount}/{fam.maxMembers} Members</span>
                      </div>
                    </div>

                    <button
                      type="button"
                      disabled={isCurrentMember}
                      onClick={() => handleJoinDirect(fam)}
                      className={`w-full py-2.5 rounded-2xl font-black text-xs transition-all flex items-center justify-center gap-1.5 shadow ${
                        isCurrentMember
                          ? 'bg-white/10 text-slate-400 cursor-not-allowed'
                          : 'bg-gradient-to-r from-emerald-500 to-teal-600 hover:brightness-110 active:scale-95 text-white shadow-emerald-900/40 cursor-pointer'
                      }`}
                    >
                      {isCurrentMember ? 'Already In Family ✓' : 'Join Group Instantly ⚡'}
                    </button>
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* 5. TAB 3: TOP-RATED (APPLY FOR MEMBERSHIP)                */}
      {/* ========================================================= */}
      {activeTab === 'top_rated' && (
        <div className="space-y-4 animate-fadeIn">
          <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/20 to-pink-500/20 border border-amber-500/40 space-y-1">
            <h4 className="font-extrabold text-white text-sm flex items-center gap-1.5">
              <Star className="w-4 h-4 text-amber-400" />
              <span>Top-Rated & Elite Family Guilds</span>
            </h4>
            <p className="text-xs text-slate-200">
              Prestigious clans with Level 5+ status and competitive PK records. Membership requires an application approved by clan elders.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {families
              .filter(f => f.joinMethod === 'approval' || (f.level && f.level >= 5))
              .map(fam => {
                const isCurrentMember = currentUser?.familyId === fam.id;
                const isPending = hasPendingAppForFamily(fam.id);

                return (
                  <div
                    key={fam.id}
                    className="p-5 rounded-3xl bg-gradient-to-b from-[#1f0b29] to-[#0e0416] border border-amber-500/30 hover:border-pink-500/50 transition-all space-y-3.5 shadow-xl flex flex-col justify-between"
                  >
                    <div className="space-y-2.5">
                      <div className="flex items-center justify-between">
                        <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-3xl shadow">
                          {fam.badge || '👑'}
                        </div>
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase bg-pink-500/20 text-pink-300 border border-pink-500/30">
                          Elite Guild LV.{fam.level}
                        </span>
                      </div>

                      <div>
                        <h4 className="font-black text-white text-base flex items-center gap-1.5">
                          <span>{fam.name}</span>
                          <span className="text-amber-400 text-xs">★</span>
                        </h4>
                        <p className="text-xs text-slate-300 line-clamp-2 mt-0.5">{fam.slogan}</p>
                      </div>

                      <div className="p-2.5 rounded-xl bg-black/40 border border-white/5 space-y-1 text-xs">
                        <div className="flex justify-between text-slate-300">
                          <span>Leader:</span>
                          <b className="text-white">{fam.leaderName}</b>
                        </div>
                        <div className="flex justify-between text-slate-300">
                          <span>Contribution:</span>
                          <b className="font-mono text-amber-300">{((fam.totalContribution || 0) / 1000).toFixed(0)}K XP</b>
                        </div>
                        <div className="flex justify-between text-slate-300">
                          <span>Capacity:</span>
                          <b className="text-white">{fam.memberCount}/{fam.maxMembers} members</b>
                        </div>
                      </div>
                    </div>

                    {isCurrentMember ? (
                      <span className="w-full py-2.5 rounded-2xl bg-purple-500/20 text-purple-300 border border-purple-500/40 text-xs font-bold text-center block">
                        You are a Member ✓
                      </span>
                    ) : isPending ? (
                      <span className="w-full py-2.5 rounded-2xl bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-bold text-center block flex items-center justify-center gap-1">
                        <Clock className="w-3.5 h-3.5" />
                        <span>Application Pending Approval</span>
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setApplyingFamily(fam)}
                        className="w-full py-2.5 rounded-2xl bg-gradient-to-r from-pink-500 via-purple-600 to-indigo-600 hover:brightness-110 active:scale-95 text-white font-black text-xs shadow-lg shadow-purple-900/40 transition cursor-pointer flex items-center justify-center gap-1.5"
                      >
                        <Star className="w-3.5 h-3.5 text-amber-300" />
                        <span>Apply for Membership</span>
                      </button>
                    )}
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* 6. TAB 4: MY APPLICATIONS & INCOMING APPROVALS           */}
      {/* ========================================================= */}
      {activeTab === 'applications' && (
        <div className="space-y-6 animate-fadeIn">
          {/* User's Submitted Applications */}
          <div className="space-y-3">
            <h4 className="font-extrabold text-white text-sm flex items-center justify-between">
              <span className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-purple-400" />
                <span>My Submitted Applications</span>
              </span>
              <span className="text-xs text-slate-400 font-normal">{myApplications.length} applied</span>
            </h4>

            {myApplications.length === 0 ? (
              <div className="p-6 text-center rounded-2xl bg-white/[0.02] border border-white/5 space-y-2">
                <FileText className="w-8 h-8 text-slate-500 mx-auto" />
                <p className="text-xs text-slate-400">You have no active applications. Browse top-rated families to apply!</p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {myApplications.map(app => (
                  <div
                    key={app.id}
                    className="p-3.5 rounded-2xl bg-white/[0.04] border border-white/10 flex items-center justify-between gap-3 shadow"
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-base">{app.familyBadge || '🛡️'}</span>
                        <h5 className="font-extrabold text-white text-xs sm:text-sm truncate">
                          {app.familyName}
                        </h5>
                        <span className={`text-[10px] font-black px-2 py-0.2 rounded uppercase ${
                          app.status === 'approved' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' :
                          app.status === 'rejected' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' :
                          'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                        }`}>
                          {app.status}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 truncate mt-0.5 italic">
                        &quot;{app.message}&quot;
                      </p>
                      <p className="text-[10px] text-slate-400 mt-0.5">
                        Submitted: {new Date(app.createdAt).toLocaleDateString()}
                      </p>
                    </div>

                    {app.status === 'approved' && (
                      <span className="text-xs font-bold text-emerald-400 flex items-center gap-1 shrink-0">
                        <CheckCircle2 className="w-4 h-4" /> Joined
                      </span>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Incoming Applications for Clan Leaders */}
          {userFamily && (userFamily.leaderId === currentUser?.id || userFamily.ownerId === currentUser?.id) && (
            <div className="space-y-3 pt-3 border-t border-white/10">
              <h4 className="font-extrabold text-white text-sm flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <UserCheck className="w-4 h-4 text-emerald-400" />
                  <span>Incoming Applications for {userFamily.name}</span>
                </span>
                <span className="text-xs text-amber-400 font-bold">{incomingApplications.filter(a => a.status === 'pending').length} Pending</span>
              </h4>

              {incomingApplications.filter(a => a.status === 'pending').length === 0 ? (
                <p className="text-xs text-slate-400 p-4 rounded-xl bg-white/[0.02] border border-white/5 text-center">
                  No pending membership applications at the moment.
                </p>
              ) : (
                <div className="space-y-2.5">
                  {incomingApplications
                    .filter(a => a.status === 'pending')
                    .map(app => (
                      <div
                        key={app.id}
                        className="p-3.5 rounded-2xl bg-black/40 border border-amber-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-lg"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <img
                            src={app.userAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=80'}
                            alt={app.userName}
                            className="w-10 h-10 rounded-full object-cover border border-amber-400/40 shrink-0"
                          />
                          <div className="min-w-0">
                            <h5 className="font-black text-white text-xs sm:text-sm">{app.userName}</h5>
                            <p className="text-xs text-slate-300 italic line-clamp-1 mt-0.5">&quot;{app.message}&quot;</p>
                            <p className="text-[10px] text-slate-400 font-mono mt-0.5">UID: {app.userUid || app.userId}</p>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            type="button"
                            onClick={() => handleApplicationDecision(app.id, 'approve')}
                            className="px-3 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-black text-xs shadow transition cursor-pointer"
                          >
                            Approve ✓
                          </button>
                          <button
                            type="button"
                            onClick={() => handleApplicationDecision(app.id, 'reject')}
                            className="px-3 py-1.5 rounded-xl bg-rose-600/30 hover:bg-rose-600/50 text-rose-300 border border-rose-500/40 font-bold text-xs transition cursor-pointer"
                          >
                            Decline ✕
                          </button>
                        </div>
                      </div>
                    ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* ========================================================= */}
      {/* 7. TAB 5: MY FAMILY CLAN DASHBOARD                        */}
      {/* ========================================================= */}
      {activeTab === 'my_family' && (
        <div className="space-y-5 animate-fadeIn">
          {userFamily ? (
            <div className="space-y-4">
              {/* Clan Header Card */}
              <div className="p-5 rounded-3xl bg-gradient-to-r from-purple-900/40 via-indigo-950/40 to-pink-900/40 border border-purple-500/40 shadow-xl space-y-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3.5">
                    <div className="w-16 h-16 rounded-2xl bg-amber-500/20 border-2 border-amber-400/50 flex items-center justify-center text-4xl shadow-inner">
                      {userFamily.badge || '👑'}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-black text-white text-lg">{userFamily.name}</h3>
                        <span className="bg-amber-400 text-black font-black text-[10px] px-1.5 py-0.5 rounded">
                          LV.{userFamily.level}
                        </span>
                      </div>
                      <p className="text-xs text-slate-300 mt-0.5">{userFamily.slogan}</p>
                      <p className="text-[10px] text-amber-300 font-mono mt-1">ID: {userFamily.familyId || userFamily.id}</p>
                    </div>
                  </div>

                  <span className="bg-white/10 text-white font-black text-xs px-3 py-1 rounded-xl border border-white/10">
                    Rank #{userFamily.ranking || 1}
                  </span>
                </div>

                {/* Clan Stats Grid */}
                <div className="grid grid-cols-3 gap-2.5 pt-2 border-t border-white/10 text-center">
                  <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
                    <p className="text-[10px] text-slate-400 font-bold uppercase">Contribution</p>
                    <p className="text-sm font-black text-amber-400 font-mono mt-0.5">
                      💎 {((userFamily.totalContribution || 0) / 1000).toFixed(0)}K
                    </p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
                    <p className="text-[10px] text-slate-400 font-bold uppercase">Members</p>
                    <p className="text-sm font-black text-white font-mono mt-0.5">
                      {userFamily.memberCount}/{userFamily.maxMembers}
                    </p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
                    <p className="text-[10px] text-slate-400 font-bold uppercase">Leader</p>
                    <p className="text-xs font-black text-purple-300 truncate mt-0.5">
                      {userFamily.leaderName}
                    </p>
                  </div>
                </div>
              </div>

              {/* Clan Announcement */}
              <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/10 space-y-1.5">
                <span className="text-[10px] font-black text-purple-400 uppercase tracking-wider">Clan Announcement</span>
                <p className="text-xs text-slate-200">{userFamily.announcement || 'No announcement posted yet.'}</p>
              </div>

              {/* Leave Clan Action */}
              <div className="pt-2 text-right">
                <button
                  type="button"
                  onClick={handleLeaveFamily}
                  className="px-4 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ml-auto"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Leave Family</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="p-8 text-center rounded-3xl bg-white/[0.03] border border-white/10 space-y-4">
              <Shield className="w-12 h-12 text-slate-500 mx-auto" />
              <div>
                <h4 className="font-black text-white text-base">You are not in a Family yet</h4>
                <p className="text-xs text-slate-400 max-w-sm mx-auto mt-1">
                  Join an open group or apply to top-rated families to unlock exclusive nameplates, gift EXP bonuses, and clan chat!
                </p>
              </div>
              <div className="flex items-center justify-center gap-3">
                <button
                  type="button"
                  onClick={() => setActiveTab('leaderboard')}
                  className="px-5 py-2.5 rounded-2xl bg-white text-purple-900 font-black text-xs shadow-lg hover:scale-102 transition cursor-pointer"
                >
                  View Leaderboard 🏆
                </button>
                <button
                  type="button"
                  onClick={() => setShowCreateModal(true)}
                  className="px-5 py-2.5 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 text-black font-black text-xs shadow-lg hover:scale-102 transition cursor-pointer"
                >
                  Create My Family +
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================= */}
      {/* 8. APPLY FOR MEMBERSHIP MODAL                             */}
      {/* ========================================================= */}
      {applyingFamily && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
          <form onSubmit={handleSubmitApplication} className="bg-[#180a29] border-2 border-amber-500/40 rounded-3xl p-5 sm:p-6 w-full max-w-md space-y-4 shadow-2xl text-white">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <Star className="w-5 h-5 text-amber-400" />
                <h3 className="font-black text-base sm:text-lg">Apply for Membership</h3>
              </div>
              <button
                type="button"
                onClick={() => setApplyingFamily(null)}
                className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-slate-300"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Target Family Banner */}
            <div className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-500/20 to-purple-600/20 border border-amber-500/30 flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-amber-400/20 flex items-center justify-center text-3xl border border-amber-400/40 shrink-0">
                {applyingFamily.badge || '👑'}
              </div>
              <div className="min-w-0">
                <h4 className="font-extrabold text-white text-sm truncate">{applyingFamily.name}</h4>
                <p className="text-[11px] text-amber-200">
                  Leader: {applyingFamily.leaderName} • Rank #{applyingFamily.ranking || 1}
                </p>
                <p className="text-[10px] text-slate-400">
                  {applyingFamily.memberCount}/{applyingFamily.maxMembers} Members currently
                </p>
              </div>
            </div>

            {/* Application Pitch Textarea */}
            <div className="space-y-1.5 text-left">
              <label className="text-xs font-bold text-slate-300">
                Introduction / Why would you like to join?
              </label>
              <textarea
                rows={3}
                required
                value={applicationPitch}
                onChange={(e) => setApplicationPitch(e.target.value)}
                placeholder="Hi, I am an active voice chatter and contributor looking forward to participating in weekly PK wars..."
                className="w-full bg-black/50 text-xs text-white p-3 rounded-2xl border border-white/15 focus:outline-none focus:border-amber-400 placeholder-slate-500 shadow-inner"
              />
            </div>

            {/* Checklist */}
            <div className="p-3 rounded-xl bg-white/5 border border-white/5 space-y-1.5 text-xs text-slate-300">
              <div className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Respect all guild members & clan leaders</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Participate in voice rooms and clan activities</span>
              </div>
            </div>

            {/* Submit */}
            <div className="flex gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setApplyingFamily(null)}
                className="flex-1 py-3 rounded-2xl bg-white/10 hover:bg-white/20 text-slate-300 font-bold text-xs"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmittingApp}
                className="flex-1 py-3 rounded-2xl bg-gradient-to-r from-pink-500 via-purple-600 to-indigo-600 hover:brightness-110 active:scale-95 text-white font-black text-xs shadow-lg shadow-purple-900/40 transition disabled:opacity-50 cursor-pointer flex items-center justify-center gap-1.5"
              >
                {isSubmittingApp ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Submitting...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>Send Application</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ========================================================= */}
      {/* 9. CREATE FAMILY MODAL                                    */}
      {/* ========================================================= */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
          <form onSubmit={handleCreateFamilySubmit} className="bg-[#180a29] border border-white/20 rounded-3xl p-5 sm:p-6 w-full max-w-md space-y-4 shadow-2xl text-white">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <Plus className="w-5 h-5 text-amber-400" />
                <h3 className="font-black text-base sm:text-lg">Found a New Family Clan</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-slate-300"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-left">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">Family Clan Name:</label>
                <input
                  type="text"
                  required
                  value={createForm.name}
                  onChange={(e) => setCreateForm({ ...createForm, name: e.target.value })}
                  placeholder="e.g. Phoenix Vanguard 👑"
                  className="w-full bg-black/50 text-xs text-white px-3 py-2.5 rounded-xl border border-white/15 focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">Crest Badge Emoji:</label>
                <div className="flex gap-2">
                  {['👑', '🛡️', '⚡', '🔥', '💎', '🐺'].map(emoji => (
                    <button
                      key={emoji}
                      type="button"
                      onClick={() => setCreateForm({ ...createForm, badge: emoji })}
                      className={`w-9 h-9 rounded-xl text-lg flex items-center justify-center border transition ${
                        createForm.badge === emoji ? 'bg-amber-400/30 border-amber-400 scale-105' : 'bg-white/5 border-white/10'
                      }`}
                    >
                      {emoji}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">Clan Motto / Slogan:</label>
                <input
                  type="text"
                  value={createForm.slogan}
                  onChange={(e) => setCreateForm({ ...createForm, slogan: e.target.value })}
                  placeholder="e.g. Victory through loyalty and unity!"
                  className="w-full bg-black/50 text-xs text-white px-3 py-2.5 rounded-xl border border-white/15 focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">Entry Method:</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setCreateForm({ ...createForm, joinMethod: 'anyone' })}
                    className={`py-2 px-3 rounded-xl text-xs font-bold border transition ${
                      createForm.joinMethod === 'anyone' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' : 'bg-white/5 text-slate-300 border-white/10'
                    }`}
                  >
                    Open (Instant Join)
                  </button>
                  <button
                    type="button"
                    onClick={() => setCreateForm({ ...createForm, joinMethod: 'approval' })}
                    className={`py-2 px-3 rounded-xl text-xs font-bold border transition ${
                      createForm.joinMethod === 'approval' ? 'bg-pink-500/20 text-pink-300 border-pink-500/40' : 'bg-white/5 text-slate-300 border-white/10'
                    }`}
                  >
                    Approval Required
                  </button>
                </div>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between text-xs">
              <span className="text-amber-200">Creation Fee:</span>
              <span className="font-mono font-black text-amber-300">500 Coins 🪙</span>
            </div>

            <div className="flex gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="flex-1 py-3 rounded-2xl bg-white/10 text-slate-300 font-bold text-xs"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isCreatingFamily}
                className="flex-1 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 text-black font-black text-xs shadow-lg transition active:scale-95 disabled:opacity-50 cursor-pointer"
              >
                {isCreatingFamily ? 'Founding Clan...' : 'Found Clan (500 🪙)'}
              </button>
            </div>
          </form>
        </div>
      )}

    </div>
  );
};

export default FamiliesModule;
