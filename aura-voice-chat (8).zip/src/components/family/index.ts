/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export { FamiliesModule, default as FamiliesModuleDefault } from './FamiliesModule';
export type { FamiliesModuleProps } from './FamiliesModule';
export { FamilyPage } from './FamilyPage';
