/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Users, Trophy, Shield, MessageSquare, Award, Plus, CheckCircle2, 
  Crown, Sparkles, ChevronRight, Search, Globe, Lock, AlertCircle, 
  Coins, Check, X, RefreshCw, UserPlus, Image as ImageIcon
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ApiClient } from '../../lib/api';
import { FamiliesModule } from './FamiliesModule';

const LOGO_PRESETS = [
  '👑', '🛡️', '⚔️', '🐉', '🦅', '🦁', '⚡', '🔥', '💎', '🌌', '🐺', '🏆'
];

const BACKGROUND_PRESETS = [
  'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=500&q=80',
  'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=500&q=80',
  'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=500&q=80',
  'https://images.unsplash.com/photo-1511447333015-45b65e60f6d5?auto=format&fit=crop&w=500&q=80'
];

export const FamilyPage: React.FC = () => {
  const { families, showNotification, currentUser, refreshUser } = useApp();
  const [activeTab, setActiveTab] = useState<'home' | 'ranking' | 'members' | 'chat' | 'tasks' | 'contribution'>('home');

  // Create Family Modal state
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showConfirmStep, setShowConfirmStep] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [formData, setFormData] = useState({
    name: '',
    familyId: `FAM-${Math.floor(100000 + Math.random() * 900000)}`,
    badge: '👑',
    logo: BACKGROUND_PRESETS[0],
    slogan: 'United in brotherhood & voice!',
    description: '',
    announcement: 'Welcome all new clan members!',
    country: currentUser?.country || 'United States 🇺🇸',
    category: 'Gaming & Social',
    privacy: 'public',
    joinMethod: 'anyone'
  });

  // Search Family in Rankings
  const [searchQuery, setSearchQuery] = useState('');

  // Check if current user is owner/member of a family
  const myFamily = families.find(f => f.id === currentUser?.familyId || f.leaderId === currentUser?.id || f.ownerId === currentUser?.id) || families[0] || {
    id: 'fam-001',
    familyId: 'FAM-100001',
    name: 'Royal Dynasty 👑',
    slogan: 'Where kings and queens unite in harmony!',
    badge: '👑',
    coverImage: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=500&q=80',
    leaderName: 'Elena Vance',
    level: 8,
    totalContribution: 4500000,
    memberCount: 45,
    maxMembers: 50,
    announcement: 'Weekly clan meeting this Sunday at 8 PM UTC! Complete your daily contributions.',
    ranking: 1
  };

  const membersList = [
    { name: myFamily.leaderName || 'Elena Vance', role: 'Leader 👑', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80', contrib: '1.2M', online: true },
    { name: 'Marcus Aurelius', role: 'Co-Leader 🛡️', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80', contrib: '850K', online: true },
    { name: 'Alex Chen', role: 'Elder ⚔️', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80', contrib: '620K', online: true },
    { name: 'Kenji Sato', role: 'Member', avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=300&q=80', contrib: '340K', online: true },
    { name: 'Liam Vance', role: 'Member', avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=300&q=80', contrib: '190K', online: false }
  ];

  const creationFee = 500;
  const userCoins = currentUser?.coins || 0;
  const hasEnoughCoins = userCoins >= creationFee;

  const handleCreateFamilySubmit = async () => {
    if (!formData.name.trim()) {
      showNotification('⚠️ Family Name is required.');
      return;
    }

    if (!hasEnoughCoins) {
      showNotification(`⚠️ Insufficient coins. Required: ${creationFee} coins, You have: ${userCoins} coins.`);
      return;
    }

    setIsSubmitting(true);
    try {
      const result = await ApiClient.createFamily(formData);
      showNotification(`🎉 Family "${result?.name || formData.name}" created successfully!`);
      setShowCreateModal(false);
      setShowConfirmStep(false);
      await refreshUser();
      setActiveTab('home');
    } catch (err: any) {
      showNotification(`❌ Error: ${err.message || 'Failed to create family'}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleJoinFamily = async (famId: string, famName: string) => {
    try {
      await ApiClient.joinFamily(famId);
      showNotification(`🎉 Successfully joined Family "${famName}"!`);
      await refreshUser();
    } catch (err: any) {
      showNotification(`❌ ${err.message || 'Failed to join family'}`);
    }
  };

  const filteredFamilies = families.filter(f => 
    f.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (f.familyId && f.familyId.toLowerCase().includes(searchQuery.toLowerCase())) ||
    f.leaderName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="pb-24 space-y-4 animate-fadeIn">
      {/* HEADER BANNER WITH + CREATE FAMILY BUTTON */}
      <div className="relative overflow-hidden rounded-3xl p-5 bg-gradient-to-r from-purple-900/40 via-indigo-900/30 to-pink-900/30 backdrop-blur-xl border border-white/10 shadow-2xl flex flex-col space-y-4">
        <div className="flex items-start justify-between flex-wrap gap-3">
          <div className="flex items-center gap-3.5">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-400 to-yellow-600 flex items-center justify-center text-3xl shadow-lg border border-white/20">
              {myFamily.badge || '👑'}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black text-white">{myFamily.name}</h2>
                <span className="bg-amber-500 text-black text-[10px] font-black px-1.5 py-0.5 rounded-md">
                  LV.{myFamily.level}
                </span>
                {myFamily.familyId && (
                  <span className="bg-purple-500/30 text-purple-200 text-[10px] font-mono font-bold px-2 py-0.5 rounded-md border border-purple-500/30">
                    ID: {myFamily.familyId}
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-300 mt-0.5 line-clamp-1">{myFamily.slogan}</p>
              <p className="text-[10px] text-amber-400 font-semibold mt-1 flex items-center gap-2">
                <span>👑 Leader: {myFamily.leaderName}</span>
                <span>•</span>
                <span>👥 {myFamily.memberCount}/{myFamily.maxMembers} Members</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="bg-white/10 text-slate-200 text-xs font-black px-2.5 py-1 rounded-xl border border-white/10">
              #{myFamily.ranking} Clan
            </span>
            <button
              onClick={() => {
                setFormData({
                  name: '',
                  familyId: `FAM-${Math.floor(100000 + Math.random() * 900000)}`,
                  badge: '👑',
                  logo: BACKGROUND_PRESETS[0],
                  slogan: 'United in brotherhood & voice!',
                  description: '',
                  announcement: 'Welcome all new clan members!',
                  country: currentUser?.country || 'United States 🇺🇸',
                  category: 'Gaming & Social',
                  privacy: 'public',
                  joinMethod: 'anyone'
                });
                setShowConfirmStep(false);
                setShowCreateModal(true);
              }}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-black text-xs font-black transition shadow-lg flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" /> CREATE FAMILY
            </button>
          </div>
        </div>

        {/* Announcement Box */}
        <div className="bg-black/40 backdrop-blur-md p-3 rounded-2xl border border-white/10 text-xs text-slate-200 flex items-center gap-2">
          <span className="bg-purple-600 text-white font-bold px-1.5 py-0.5 rounded text-[9px] flex-shrink-0">NOTICE</span>
          <p className="truncate flex-1">{myFamily.announcement}</p>
        </div>
      </div>

      {/* SUB-NAVIGATION TABS */}
      <div className="grid grid-cols-6 gap-1 p-1.5 bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 text-center shadow-lg">
        {[
          { id: 'home', label: 'Home', icon: <Users className="w-3.5 h-3.5 mx-auto" /> },
          { id: 'ranking', label: 'Rankings', icon: <Trophy className="w-3.5 h-3.5 mx-auto" /> },
          { id: 'members', label: 'Members', icon: <Shield className="w-3.5 h-3.5 mx-auto" /> },
          { id: 'chat', label: 'Chat', icon: <MessageSquare className="w-3.5 h-3.5 mx-auto" /> },
          { id: 'tasks', label: 'Tasks', icon: <CheckCircle2 className="w-3.5 h-3.5 mx-auto" /> },
          { id: 'contribution', label: 'Contrib', icon: <Award className="w-3.5 h-3.5 mx-auto" /> }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`py-2 px-1 rounded-xl text-[10px] font-bold transition-all ${
              activeTab === tab.id
                ? 'bg-white text-purple-900 font-black shadow'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            {tab.icon}
            <span className="block mt-0.5 truncate">{tab.label}</span>
          </button>
        ))}
      </div>

      {/* TAB CONTENTS */}
      {activeTab === 'home' && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 space-y-1 shadow-xl">
              <span className="text-xs text-slate-300">Total Contribution</span>
              <h4 className="text-lg font-black text-amber-400">💎 {myFamily.totalContribution.toLocaleString()}</h4>
              <p className="text-[10px] text-emerald-400 font-semibold">+125,000 this week</p>
            </div>
            <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 space-y-1 shadow-xl">
              <span className="text-xs text-slate-300">Family Prestige</span>
              <h4 className="text-lg font-black text-pink-400">🔥 Royal Tier 1</h4>
              <p className="text-[10px] text-slate-400">Next LV at 5M contrib</p>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 space-y-3 shadow-xl">
            <h4 className="font-bold text-white text-sm flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-purple-400" /> Family Privileges & Perks
            </h4>
            <div className="grid grid-cols-2 gap-2.5 text-xs">
              <div className="p-3 bg-black/40 rounded-xl border border-white/10 font-semibold text-slate-200">
                👑 Exclusive Royal Nameplate
              </div>
              <div className="p-3 bg-black/40 rounded-xl border border-white/10 font-semibold text-slate-200">
                🚀 +15% Gift Experience Bonus
              </div>
              <div className="p-3 bg-black/40 rounded-xl border border-white/10 font-semibold text-slate-200">
                🎙️ Dedicated Family Voice Lounge
              </div>
              <div className="p-3 bg-black/40 rounded-xl border border-white/10 font-semibold text-slate-200">
                🏆 Weekly PK Tournament Seed
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'ranking' && (
        <div className="space-y-4">
          <FamiliesModule initialTab="leaderboard" />
        </div>
      )}

      {activeTab === 'members' && (
        <div className="space-y-2.5">
          <div className="flex items-center justify-between px-1">
            <h4 className="font-bold text-white text-xs">Clan Members ({membersList.length})</h4>
            <button onClick={() => showNotification('Invite link sent to friends!')} className="text-xs font-bold text-purple-300 hover:text-white flex items-center gap-1">
              <Plus className="w-3.5 h-3.5" /> Invite Member
            </button>
          </div>
          {membersList.map((m, idx) => (
            <div key={idx} className="p-3 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 flex items-center justify-between shadow-xl">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <img src={m.avatar} alt={m.name} className="w-11 h-11 rounded-full object-cover border border-white/20" />
                  {m.online && <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 rounded-full border-2 border-black/80" />}
                </div>
                <div>
                  <h5 className="font-bold text-white text-xs">{m.name}</h5>
                  <span className="text-[10px] bg-white/10 text-slate-200 px-1.5 py-0.2 rounded border border-white/10">{m.role}</span>
                </div>
              </div>
              <span className="text-xs font-bold text-amber-400">💎 {m.contrib}</span>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'chat' && (
        <div className="bg-white/5 backdrop-blur-xl p-4 rounded-3xl border border-white/10 space-y-3 shadow-xl">
          <h4 className="font-bold text-white text-sm">Family Live Chat Room</h4>
          <div className="space-y-2 h-60 overflow-y-auto">
            <div className="p-2.5 rounded-xl bg-black/40 border border-white/5 text-xs"><span className="font-bold text-amber-400">{myFamily.leaderName}:</span> Welcome all family members! Let us win tonight's PK! 👑</div>
            <div className="p-2.5 rounded-xl bg-black/40 border border-white/5 text-xs"><span className="font-bold text-purple-300">Marcus Aurelius:</span> Ready with 50K coins gift support 🔥</div>
            <div className="p-2.5 rounded-xl bg-black/40 border border-white/5 text-xs"><span className="font-bold text-pink-400">Alex Chen:</span> Let us go squad! 🚀</div>
          </div>
          <input type="text" placeholder="Send message to clan..." className="w-full bg-black/40 text-xs text-white px-3.5 py-2.5 rounded-xl border border-white/10 focus:outline-none focus:border-white/25" />
        </div>
      )}

      {activeTab === 'tasks' && (
        <div className="space-y-2.5">
          {[
            { title: 'Daily Clan Check-In', reward: '+100 Family Contrib', done: true },
            { title: 'Send 500 Coins in gifts while inside Family Room', reward: '+500 Family Contrib', done: false },
            { title: 'Participate in Family PK Match', reward: '+1,000 Family Contrib', done: false }
          ].map((t, i) => (
            <div key={i} className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 flex items-center justify-between shadow-xl">
              <div>
                <h5 className="font-bold text-white text-xs">{t.title}</h5>
                <p className="text-[10px] text-amber-400 font-semibold mt-0.5">🎁 {t.reward}</p>
              </div>
              <button 
                onClick={async () => {
                  try {
                    await ApiClient.rechargeCoins(currentUser?.id || '2383452', 100);
                    await refreshUser();
                    showNotification('Task completed! +100 Coins & Contribution added.');
                  } catch (e) {
                    showNotification('Task completed! Contribution added.');
                  }
                }} 
                disabled={t.done} 
                className={`px-3 py-1.5 rounded-xl text-xs font-bold ${t.done ? 'bg-white/10 text-slate-400 cursor-not-allowed' : 'bg-white text-purple-900 hover:bg-purple-100 font-black shadow'}`}
              >
                {t.done ? 'Done ✓' : 'Go'}
              </button>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'contribution' && (
        <div className="space-y-2.5">
          <h4 className="font-bold text-white text-xs px-1">Top Contributors This Week</h4>
          {membersList.map((m, idx) => (
            <div key={idx} className="p-3 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 flex items-center justify-between shadow-xl">
              <div className="flex items-center gap-3">
                <span className="font-black text-amber-400 text-xs">#{idx + 1}</span>
                <img src={m.avatar} alt={m.name} className="w-9 h-9 rounded-full object-cover border border-white/20" />
                <span className="font-bold text-white text-xs">{m.name}</span>
              </div>
              <span className="font-black text-amber-400 text-xs">💎 {m.contrib}</span>
            </div>
          ))}
        </div>
      )}

      {/* CREATE FAMILY MODAL */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-purple-500/30 rounded-3xl p-6 max-w-lg w-full space-y-4 shadow-2xl animate-scaleUp max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-400 to-yellow-600 flex items-center justify-center text-lg font-black text-black">
                  👑
                </div>
                <div>
                  <h3 className="text-base font-black text-white">Create New Family Clan</h3>
                  <p className="text-xs text-slate-400">Establish your official voice family on the platform</p>
                </div>
              </div>
              <button 
                onClick={() => setShowCreateModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {!showConfirmStep ? (
              /* FORM STEP */
              <div className="space-y-3 text-xs">
                {/* Name & ID */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="font-bold text-slate-300">Family Name *</label>
                    <input
                      type="text"
                      placeholder="e.g. Royal Crown Clan 👑"
                      value={formData.name}
                      onChange={e => setFormData({ ...formData, name: e.target.value })}
                      className="w-full bg-black/50 text-white p-2.5 rounded-xl border border-white/10 focus:outline-none focus:border-purple-400"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="font-bold text-slate-300">Family Unique ID / Code</label>
                    <input
                      type="text"
                      value={formData.familyId}
                      onChange={e => setFormData({ ...formData, familyId: e.target.value })}
                      className="w-full bg-black/50 text-amber-300 font-mono font-bold p-2.5 rounded-xl border border-white/10 focus:outline-none"
                    />
                  </div>
                </div>

                {/* Badge Preset Selection */}
                <div className="space-y-1.5">
                  <label className="font-bold text-slate-300">Choose Family Emblem Badge:</label>
                  <div className="flex gap-2 overflow-x-auto pb-1">
                    {LOGO_PRESETS.map(badge => (
                      <button
                        key={badge}
                        type="button"
                        onClick={() => setFormData({ ...formData, badge })}
                        className={`w-10 h-10 rounded-xl text-lg flex items-center justify-center border transition ${
                          formData.badge === badge
                            ? 'bg-amber-500 text-black border-amber-300 shadow-lg scale-105'
                            : 'bg-black/30 border-white/10 text-white hover:bg-white/10'
                        }`}
                      >
                        {badge}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Cover Image Preset */}
                <div className="space-y-1.5">
                  <label className="font-bold text-slate-300">Family Cover Banner:</label>
                  <div className="grid grid-cols-4 gap-2">
                    {BACKGROUND_PRESETS.map((bg, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setFormData({ ...formData, logo: bg })}
                        className={`h-12 rounded-xl overflow-hidden border transition relative ${
                          formData.logo === bg ? 'border-amber-400 ring-2 ring-amber-400/50' : 'border-white/10 opacity-70'
                        }`}
                      >
                        <img src={bg} alt="preset" className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>
                </div>

                {/* Slogan & Announcement */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-300">Family Slogan / Motto</label>
                  <input
                    type="text"
                    placeholder="e.g. United in voice & brotherhood!"
                    value={formData.slogan}
                    onChange={e => setFormData({ ...formData, slogan: e.target.value })}
                    className="w-full bg-black/50 text-white p-2.5 rounded-xl border border-white/10 focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-300">Family Announcement</label>
                  <textarea
                    rows={2}
                    placeholder="Notice for new clan members..."
                    value={formData.announcement}
                    onChange={e => setFormData({ ...formData, announcement: e.target.value })}
                    className="w-full bg-black/50 text-white p-2.5 rounded-xl border border-white/10 focus:outline-none"
                  />
                </div>

                {/* Category, Privacy & Join Method */}
                <div className="grid grid-cols-3 gap-2">
                  <div className="space-y-1">
                    <label className="font-bold text-slate-300">Category</label>
                    <select
                      value={formData.category}
                      onChange={e => setFormData({ ...formData, category: e.target.value })}
                      className="w-full bg-black/50 text-white p-2 rounded-xl border border-white/10"
                    >
                      <option value="Social">Social</option>
                      <option value="Gaming">Gaming</option>
                      <option value="Music">Music</option>
                      <option value="Royal">Royal Clan</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="font-bold text-slate-300">Privacy</label>
                    <select
                      value={formData.privacy}
                      onChange={e => setFormData({ ...formData, privacy: e.target.value })}
                      className="w-full bg-black/50 text-white p-2 rounded-xl border border-white/10"
                    >
                      <option value="public">Public</option>
                      <option value="private">Private</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="font-bold text-slate-300">Join Method</label>
                    <select
                      value={formData.joinMethod}
                      onChange={e => setFormData({ ...formData, joinMethod: e.target.value })}
                      className="w-full bg-black/50 text-white p-2 rounded-xl border border-white/10"
                    >
                      <option value="anyone">Anyone</option>
                      <option value="approval">Approval</option>
                      <option value="invite">Invite Only</option>
                    </select>
                  </div>
                </div>

                {/* CREATION FEE SUMMARY */}
                <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Coins className="w-5 h-5 text-amber-400" />
                    <div>
                      <p className="font-bold text-white text-xs">Family Creation Fee</p>
                      <p className="text-[10px] text-slate-300">One-time clan license fee</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-black text-amber-400">{creationFee} Coins</p>
                    <p className={`text-[10px] font-bold ${hasEnoughCoins ? 'text-emerald-400' : 'text-red-400'}`}>
                      Balance: {userCoins} Coins
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    if (!formData.name.trim()) {
                      showNotification('⚠️ Family Name is required.');
                      return;
                    }
                    if (!hasEnoughCoins) {
                      showNotification(`⚠️ Insufficient coins. Required: ${creationFee} coins.`);
                      return;
                    }
                    setShowConfirmStep(true);
                  }}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 text-black font-black text-xs transition shadow-lg"
                >
                  Proceed to Confirmation →
                </button>
              </div>
            ) : (
              /* CONFIRMATION STEP */
              <div className="space-y-4 text-xs">
                <div className="p-4 rounded-2xl bg-black/40 border border-amber-500/30 space-y-2">
                  <h4 className="font-bold text-amber-400 text-sm flex items-center gap-1.5">
                    {formData.badge} {formData.name}
                  </h4>
                  <p className="text-slate-300"><span className="text-slate-400">Unique Family ID:</span> <strong className="font-mono text-amber-300">{formData.familyId}</strong></p>
                  <p className="text-slate-300"><span className="text-slate-400">Motto:</span> {formData.slogan}</p>
                  <p className="text-slate-300"><span className="text-slate-400">Leader / Owner:</span> <strong className="text-white">{currentUser?.name}</strong></p>
                  <p className="text-slate-300"><span className="text-slate-400">Creation Fee:</span> <strong className="text-amber-400">{creationFee} Coins</strong></p>
                  <p className="text-slate-300"><span className="text-slate-400">Coin Balance After:</span> <strong className="text-emerald-400">{userCoins - creationFee} Coins</strong></p>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => setShowConfirmStep(false)}
                    className="flex-1 py-3 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 text-xs font-bold transition"
                  >
                    ← Back to Edit
                  </button>
                  <button
                    type="button"
                    onClick={handleCreateFamilySubmit}
                    disabled={isSubmitting}
                    className="flex-1 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-black text-xs font-black transition shadow-lg flex items-center justify-center gap-1.5"
                  >
                    {isSubmitting ? <RefreshCw className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
                    Confirm & Create Family
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
