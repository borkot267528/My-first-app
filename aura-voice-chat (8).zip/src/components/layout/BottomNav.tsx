/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Home, Radio, MessageSquare, Users, User, ShieldAlert } from 'lucide-react';
import { useApp, NavTab } from '../../context/AppContext';

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab, currentUser, activeModal, setActiveModal, activeRoom } = useApp();

  // Hide the bottom navigation bar completely when inside an active voice room so it never overlays or blocks room controls
  if (activeRoom) {
    return null;
  }

  const navItems: { id: NavTab; label: string; icon: React.ReactNode; badge?: number }[] = [
    { id: 'home', label: 'Home', icon: <Home className="w-6 h-6" /> },
    { id: 'rooms', label: 'Rooms', icon: <Radio className="w-6 h-6" /> },
    { id: 'messages', label: 'Messages', icon: <MessageSquare className="w-6 h-6" />, badge: 3 },
    { id: 'family', label: 'Family', icon: <Users className="w-6 h-6" /> },
    { id: 'profile', label: 'Profile', icon: <User className="w-6 h-6" /> }
  ];

  const handleNavClick = (id: NavTab) => {
    setActiveTab(id);
    if (activeModal === 'admin') {
      setActiveModal('none');
    }
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-[60] max-w-md mx-auto bg-[#0c031a]/90 backdrop-blur-xl border-t border-white/10 px-3 py-2 pb-[calc(0.5rem+env(safe-area-inset-bottom))] flex items-center justify-around shadow-[0_-8px_25px_rgba(0,0,0,0.8)]">
      {navItems.map((item) => {
        const isActive = activeTab === item.id && activeModal !== 'admin';
        return (
          <button
            key={item.id}
            id={`nav-btn-${item.id}`}
            onClick={() => handleNavClick(item.id)}
            className={`relative flex flex-col items-center justify-center py-1.5 px-3 rounded-2xl transition-all duration-300 ${
              isActive 
                ? 'text-white font-medium scale-105 bg-white/10 shadow-[0_0_15px_rgba(255,255,255,0.1)] border border-white/15' 
                : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
            }`}
          >
            <div className="relative">
              {item.icon}
              {item.badge && (
                <span className="absolute -top-1.5 -right-2 bg-gradient-to-r from-pink-500 to-purple-600 text-white text-[10px] font-bold px-1.5 py-0.2 rounded-full border border-black/50 shadow-sm animate-pulse">
                  {item.badge}
                </span>
              )}
            </div>
            <span className="text-[11px] mt-1 tracking-tight">{item.label}</span>
            {isActive && (
              <span className="absolute bottom-0 w-1/2 h-0.5 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full shadow-[0_0_8px_#c084fc]" />
            )}
          </button>
        );
      })}

      {/* Quick Admin Access pill for staff */}
      {currentUser && ['ceo', 'gm', 'manager', 'super_admin', 'admin', 'bd', 'agency'].includes(currentUser.role) && (
        <button
          onClick={() => setActiveModal(activeModal === 'admin' ? 'none' : 'admin')}
          title="Open Admin & Permission Portal"
          className={`flex flex-col items-center justify-center py-1.5 px-2.5 rounded-2xl transition-all border ${
            activeModal === 'admin'
              ? 'text-amber-200 bg-amber-500/20 border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.3)] scale-105'
              : 'text-amber-300 hover:text-amber-200 hover:bg-white/10 border-amber-500/30 shadow-[0_0_10px_rgba(245,158,11,0.15)] animate-pulse'
          }`}
        >
          <ShieldAlert className="w-5 h-5" />
          <span className="text-[10px] mt-1 font-bold">Admin</span>
        </button>
      )}
    </nav>
  );
};
