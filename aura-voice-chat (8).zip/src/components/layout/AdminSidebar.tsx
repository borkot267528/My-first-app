/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Activity, Users, Radio, DollarSign, Building, Mic, Percent, Crown, 
  Sparkles, Gift, Megaphone, MessageSquare, Shield, BarChart3, Settings, 
  FileText, Terminal, Wallet, CreditCard, Building2, PlusCircle, Swords, 
  UserCheck, History, Key, ChevronDown, ChevronRight, X, ShieldAlert,
  HelpCircle, ExternalLink, RefreshCw, LogOut, LayoutGrid, CheckCircle2, Ban, ShieldOff, Globe,
  Palette, Heart
} from 'lucide-react';
import { User, UserRole } from '../../types';

export interface AdminNavGroup {
  id: string;
  title: string;
  badge?: string;
  items: AdminNavItem[];
}

export interface AdminNavItem {
  id: string;
  label: string;
  icon: React.ReactNode;
  subTab?: string;
  path?: string;
  badge?: string | number;
  badgeColor?: string;
}

interface AdminSidebarProps {
  activeTab: string;
  onSelectTab: (tabId: string, subTab?: string) => void;
  currentUser?: User | null;
  isOpenMobile?: boolean;
  onCloseMobile?: () => void;
  isCollapsed?: boolean;
  onToggleCollapse?: () => void;
  onExitAdmin?: () => void;
}

export const AdminSidebar: React.FC<AdminSidebarProps> = ({
  activeTab,
  onSelectTab,
  currentUser,
  isOpenMobile = false,
  onCloseMobile,
  isCollapsed = false,
  onExitAdmin
}) => {
  const [expandedGroups, setExpandedGroups] = useState<Record<string, boolean>>({
    main: true,
    live_room_ops: true,
    staff_governance: true
  });

  const toggleGroup = (groupId: string) => {
    setExpandedGroups(prev => ({
      ...prev,
      [groupId]: !prev[groupId]
    }));
  };

  const navGroups: AdminNavGroup[] = [
    {
      id: 'main',
      title: 'Main',
      badge: 'Core',
      items: [
        { id: 'dashboard', label: 'Executive Dashboard', icon: <Activity className="w-4 h-4 text-amber-400" /> },
        { id: 'financials', label: 'Financial Operations', icon: <DollarSign className="w-4 h-4 text-emerald-400" /> },
        { id: 'wallet', label: 'Platform Wallet & Vault', icon: <Wallet className="w-4 h-4 text-amber-300" />, path: '/admin/wallet' },
        { id: 'withdraw_methods', label: 'Withdraw Payment Methods', icon: <CreditCard className="w-4 h-4 text-emerald-400" />, path: '/admin/wallet/withdraw-methods' },
        { id: 'merchants', label: 'Payment Merchants', icon: <CreditCard className="w-4 h-4 text-indigo-400" />, path: '/admin/merchants' },
        { id: 'recharge_agents', label: 'Recharge Agents', icon: <Building2 className="w-4 h-4 text-teal-400" />, path: '/admin/recharge-agents' },
        { id: 'countries', label: 'Country Management', icon: <Globe className="w-4 h-4 text-emerald-400" />, path: '/admin/countries', badge: 'Geo' },
        { id: 'banners', label: 'Promotional Banners', icon: <Megaphone className="w-4 h-4 text-pink-400" /> },
        { id: 'audit', label: 'System Audit Logs', icon: <FileText className="w-4 h-4 text-blue-400" /> },
        { id: 'settings', label: 'System Settings', icon: <Settings className="w-4 h-4 text-slate-300" /> },
        { id: 'appearance', label: 'Appearance', icon: <Palette className="w-4 h-4 text-purple-400" />, path: '/admin/appearance' },
        { id: 'api_docs', label: 'OpenAPI Explorer', icon: <Terminal className="w-4 h-4 text-cyan-400" /> }
      ]
    },
    {
      id: 'live_room_ops',
      title: 'Live Room Operations',
      badge: 'Live',
      items: [
        { id: 'rooms', label: 'Voice Rooms Directory', icon: <Radio className="w-4 h-4 text-rose-400" /> },
        { id: 'host', label: 'Host Management', icon: <Mic className="w-4 h-4 text-amber-400" /> },
        { id: 'agency', label: 'Agency Guild Operations', icon: <Building className="w-4 h-4 text-purple-400" /> },
        { id: 'host_agency_create', label: 'Create Host Agency', icon: <PlusCircle className="w-4 h-4 text-emerald-400" />, path: '/admin/host-agencies/create' },
        { id: 'commission', label: 'Commission & Settlements', icon: <Percent className="w-4 h-4 text-yellow-400" /> },
        { id: 'gifts', label: 'Gift Inventory & FX', icon: <Gift className="w-4 h-4 text-pink-400" /> },
        { id: 'pk', label: 'PK Battles & Tournaments', icon: <Swords className="w-4 h-4 text-red-400" /> },
        { id: 'family', label: 'Family Guilds', icon: <Shield className="w-4 h-4 text-indigo-400" /> }
      ]
    },
    {
      id: 'staff_governance',
      title: 'Staff & Governance',
      badge: 'Security',
      items: [
        { id: 'users', label: 'Users & Staff Directory', icon: <Users className="w-4 h-4 text-blue-400" /> },
        { id: 'user_bans', label: 'User Ban & Unban', icon: <Ban className="w-4 h-4 text-rose-400" /> },
        { id: 'connections', label: 'CP & Friendship Management', icon: <Heart className="w-4 h-4 text-pink-400" />, path: '/admin/connections', badge: 'Social' },
        { id: 'staff_identity', label: 'Staff Identity & Badges', subTab: 'staff_identity', icon: <Sparkles className="w-4 h-4 text-amber-400" /> },
        { id: 'vip', label: 'VIP Privileges', icon: <Crown className="w-4 h-4 text-amber-400" /> },
        { id: 'vip_management', label: 'VIP / SVIP / Frame Grants', icon: <Sparkles className="w-4 h-4 text-cyan-400" /> },
        { id: 'messaging', label: 'Messaging & Broadcasts', icon: <MessageSquare className="w-4 h-4 text-emerald-400" /> },
        { id: 'reports', label: 'Moderation & Reports', icon: <BarChart3 className="w-4 h-4 text-rose-400" /> }
      ]
    }
  ];

  const handleItemClick = (item: AdminNavItem) => {
    onSelectTab(item.id, item.subTab);
    if (item.path && typeof window !== 'undefined' && window.history) {
      window.history.pushState({}, '', item.path);
    }
    if (onCloseMobile) {
      onCloseMobile();
    }
  };

  const sidebarContent = (
    <div className="h-full flex flex-col justify-between bg-slate-900/95 border-r border-white/10 text-white select-none backdrop-blur-xl">
      {/* SIDEBAR HEADER / BRAND */}
      <div className="p-4 border-b border-white/10 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-black font-black shadow-lg shadow-amber-500/20">
            <Shield className="w-5 h-5 text-black" />
          </div>
          {!isCollapsed && (
            <div>
              <h2 className="text-sm font-black tracking-wide text-white leading-tight">
                Aura Staff Portal
              </h2>
              <span className="text-[10px] text-amber-300 font-mono tracking-wider">
                EXECUTIVE SUITE
              </span>
            </div>
          )}
        </div>

        {isOpenMobile && onCloseMobile && (
          <button
            onClick={onCloseMobile}
            className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* USER BADGE & ROLE */}
      {!isCollapsed && (
        <div className="p-3 mx-3 my-2 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2.5 overflow-hidden">
            <img
              src={currentUser?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80'}
              alt="Admin Avatar"
              className="w-8 h-8 rounded-full border border-amber-400/50 object-cover shrink-0"
            />
            <div className="overflow-hidden">
              <p className="text-xs font-black text-white truncate">
                {currentUser?.name || 'Administrator'}
              </p>
              <span className="text-[10px] px-1.5 py-0.5 rounded font-mono uppercase bg-amber-500/20 text-amber-300 border border-amber-500/30">
                {currentUser?.role?.toUpperCase() || 'CEO'}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* NAVIGATION GROUPS CONTAINER */}
      <div className="flex-1 overflow-y-auto px-3 py-2 space-y-4 custom-scrollbar">
        {navGroups.map((group) => {
          const isExpanded = expandedGroups[group.id] ?? true;

          return (
            <div key={group.id} className="space-y-1">
              {/* GROUP HEADER */}
              <button
                type="button"
                onClick={() => toggleGroup(group.id)}
                className="w-full px-3 py-1.5 flex items-center justify-between text-[11px] font-black tracking-wider uppercase text-slate-400 hover:text-white transition-colors"
              >
                <div className="flex items-center gap-2">
                  <span className="text-amber-400">{group.title}</span>
                  {group.badge && (
                    <span className="text-[9px] px-1.5 py-0.2 rounded-full font-mono bg-white/10 text-slate-300">
                      {group.badge}
                    </span>
                  )}
                </div>
                {isExpanded ? (
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                ) : (
                  <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                )}
              </button>

              {/* GROUP ITEMS */}
              {isExpanded && (
                <div className="space-y-0.5 pl-1">
                  {group.items.map((item) => {
                    const isActive = activeTab === item.id;

                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => handleItemClick(item)}
                        className={`w-full px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-3 transition-all ${
                          isActive
                            ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-black font-black shadow-lg shadow-amber-500/20 scale-[1.01]'
                            : 'text-slate-300 hover:text-white hover:bg-white/10'
                        }`}
                      >
                        <div className={`shrink-0 ${isActive ? 'text-black' : ''}`}>
                          {item.icon}
                        </div>
                        {!isCollapsed && (
                          <span className="flex-1 text-left truncate">{item.label}</span>
                        )}
                        {item.badge && (
                          <span
                            className={`text-[10px] px-1.5 py-0.5 rounded-full font-mono font-bold ${
                              item.badgeColor || 'bg-amber-500/20 text-amber-300'
                            }`}
                          >
                            {item.badge}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* FOOTER ACTIONS */}
      <div className="p-3 border-t border-white/10 space-y-2">
        {onExitAdmin && (
          <button
            onClick={onExitAdmin}
            className="w-full py-2 px-3 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white text-xs font-bold flex items-center justify-center gap-2 transition-all border border-white/5"
          >
            <LogOut className="w-3.5 h-3.5 text-rose-400" />
            {!isCollapsed && <span>Exit to Mobile App View</span>}
          </button>
        )}
      </div>
    </div>
  );

  return (
    <>
      {/* DESKTOP PERSISTENT DOCKED SIDEBAR */}
      <aside
        className={`hidden lg:block h-screen sticky top-0 shrink-0 z-30 transition-all duration-300 ${
          isCollapsed ? 'w-20' : 'w-72'
        }`}
      >
        {sidebarContent}
      </aside>

      {/* MOBILE RESPONSIVE DRAWER BACKDROP & SHEET */}
      {isOpenMobile && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
            onClick={onCloseMobile}
          />
          {/* Drawer Sheet */}
          <div className="relative w-72 max-w-[85vw] h-full z-10 shadow-2xl animate-slideRight">
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  );
};
