/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { BottomNav } from './BottomNav';
import { HomePage } from '../home/HomePage';
import { RoomsPage } from '../rooms/RoomsPage';
import { MessagesPage } from '../messages/MessagesPage';
import { FamilyPage } from '../family/FamilyPage';
import { ProfilePage } from '../profile/ProfilePage';
import { VoiceRoomView } from '../room/VoiceRoomView';

// Modals
import { VipShopPage } from '../shop/VipShopPage';
import { WalletPage } from '../wallet/WalletPage';
import { LuckyBagPage } from '../luckybag/LuckyBagPage';
import { DailySpinPage } from '../spin/DailySpinPage';
import { PkBattlePage } from '../pk/PkBattlePage';
import { AdminPanelPage } from '../admin/AdminPanelPage';
import { AdminSidebar } from './AdminSidebar';
import { AuthModal } from '../auth/AuthModal';
import { CPScreen } from '../connections/CPScreen';
import { FriendsScreen } from '../connections/FriendsScreen';
import { UserSearchModal } from '../search/UserSearchModal';
import { TopContributorsLeaderboard } from '../leaderboard/TopContributorsLeaderboard';

import { 
  Shield, Menu, Smartphone, Monitor, ChevronRight, Sparkles, 
  UserCheck, Radio, Wallet as WalletIcon, X, ExternalLink, LogIn, Flame, Search, Trophy
} from 'lucide-react';
import { ProfileIdBadge } from '../common/ProfileIdBadge';

export const AppShell: React.FC = () => {
  const { 
    activeTab, 
    activeRoom, 
    activeModal, 
    setActiveModal, 
    notification, 
    currentUser,
    switchDemoUser,
    isMobileFrame,
    setIsMobileFrame,
    isAuthModalOpen,
    setIsAuthModalOpen,
    isSearchOpen,
    setIsSearchOpen,
    searchInitialQuery,
    openUserSearch,
    firebaseUser
  } = useApp();

  const [isAdminSidebarOpenMobile, setIsAdminSidebarOpenMobile] = useState(false);
  const [isAdminCollapsed, setIsAdminCollapsed] = useState(false);
  const [adminActiveTab, setAdminActiveTab] = useState<string>('dashboard');

  // Global Keyboard Shortcut: Ctrl+K / Cmd+K to toggle Search
  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [setIsSearchOpen]);

  const isAdminView = activeModal === 'admin';

  const handleAdminSelectTab = (tabId: string, subTab?: string) => {
    setAdminActiveTab(tabId);
    if (!isAdminView) {
      setActiveModal('admin');
    }
  };

  return (
    <div className="min-h-screen bg-[#090214] text-slate-100 font-sans flex flex-col antialiased selection:bg-amber-500 selection:text-black">
      {/* GLOBAL BACKGROUND AMBIENT GLOW */}
      <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] bg-purple-900/20 rounded-full blur-[140px]" />
        <div className="absolute top-[40%] right-[-10%] w-[450px] h-[450px] bg-indigo-900/20 rounded-full blur-[140px]" />
        <div className="absolute bottom-[-10%] left-[20%] w-[500px] h-[500px] bg-pink-900/15 rounded-full blur-[140px]" />
      </div>

      {/* GLOBAL TOAST NOTIFICATION */}
      {notification && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[100] max-w-sm w-[90%] bg-black/80 backdrop-blur-2xl border border-amber-400/30 text-slate-100 px-4 py-3 rounded-2xl shadow-[0_0_30px_rgba(245,158,11,0.25)] flex items-center gap-3 animate-bounce">
          <span className="text-xl">✨</span>
          <p className="text-xs font-black tracking-wide flex-1">{notification}</p>
        </div>
      )}

      {/* TOP RESPONSIVE DESKTOP UTILITY BAR */}
      <header className="hidden lg:flex items-center justify-between px-6 py-2.5 bg-slate-900/80 border-b border-white/10 backdrop-blur-xl z-30 sticky top-0">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 to-yellow-400 flex items-center justify-center font-black text-black text-sm shadow-md shadow-amber-500/20">
              🎙️
            </div>
            <div>
              <h1 className="text-xs font-black tracking-wider text-white uppercase flex items-center gap-1.5">
                Aura Voice <span className="text-[10px] text-amber-400 font-mono px-1.5 py-0.5 rounded bg-amber-400/10 border border-amber-400/20">ENTERPRISE</span>
              </h1>
            </div>
          </div>

          <div className="h-4 w-px bg-white/10" />

          {/* QUICK DEMO ROLE SWITCHER */}
          <div className="flex items-center gap-1.5 text-xs">
            <span className="text-[11px] text-slate-400 font-semibold">Active Role:</span>
            <span className="px-2 py-0.5 rounded-lg bg-amber-500/20 text-amber-300 font-mono font-bold text-[11px] border border-amber-500/30">
              {currentUser?.role?.toUpperCase() || 'CEO'}
            </span>
            {currentUser && (
              <ProfileIdBadge uid={currentUser.uid} size="xs" showGroupTag={false} canCopy={true} />
            )}
            <div className="flex items-center gap-1 ml-1">
              {[
                { id: '1', label: 'CEO', role: 'ceo' },
                { id: '2', label: 'SuperAdmin', role: 'super_admin' },
                { id: '3', label: 'Agency', role: 'agency' },
                { id: '4', label: 'Host', role: 'host' },
                { id: '5', label: 'VIP User', role: 'user' }
              ].map(r => (
                <button
                  key={r.id}
                  onClick={() => switchDemoUser(r.id)}
                  className={`px-2 py-0.5 rounded text-[10px] font-bold transition-all ${
                    currentUser?.id === r.id 
                      ? 'bg-amber-400 text-black font-black' 
                      : 'bg-white/5 text-slate-300 hover:bg-white/15'
                  }`}
                >
                  {r.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* SEARCH USERS QUICK TRIGGER */}
          <button
            onClick={() => openUserSearch()}
            className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 text-xs font-semibold flex items-center gap-2 transition-all shadow-sm active:scale-95 group cursor-pointer"
            title="Search users by UID or display name (Ctrl+K)"
          >
            <Search className="w-3.5 h-3.5 text-amber-400 group-hover:scale-110 transition-transform" />
            <span className="hidden xl:inline text-slate-400">Search users by UID or name...</span>
            <span className="xl:hidden">Search</span>
            <kbd className="hidden xl:inline-block px-1.5 py-0.5 rounded bg-white/10 text-[10px] font-mono text-slate-400">
              ⌘K
            </kbd>
          </button>

          {/* TOP CONTRIBUTORS LEADERBOARD BUTTON */}
          <button
            onClick={() => setActiveModal('contributors')}
            className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500/20 via-pink-500/15 to-purple-500/20 hover:from-amber-500/30 hover:to-purple-500/30 text-amber-300 border border-amber-400/30 text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm active:scale-95 cursor-pointer"
            title="Top Contributors Leaderboard (Gift Earnings & Engagement)"
          >
            <Trophy className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
            <span className="hidden sm:inline">Leaderboard</span>
          </button>

          {/* FIREBASE AUTH / USER BUTTON */}
          <button
            onClick={() => setIsAuthModalOpen(true)}
            className="px-3 py-1.5 rounded-xl bg-purple-500/20 hover:bg-purple-500/30 text-purple-200 border border-purple-500/30 text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm active:scale-95"
            title="Firebase Authentication & Profile Sync"
          >
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            <span>{firebaseUser ? (firebaseUser.displayName || firebaseUser.email?.split('@')[0]) : 'Sign In / Auth'}</span>
          </button>

          {/* VIEW MODE TOGGLE (ADMIN vs APP) */}
          <button
            onClick={() => setActiveModal(isAdminView ? 'none' : 'admin')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-md ${
              isAdminView
                ? 'bg-amber-500 text-black font-black shadow-amber-500/20'
                : 'bg-white/10 hover:bg-white/20 text-slate-200'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            {isAdminView ? 'Admin Console Active' : 'Open Admin Console'}
          </button>

          {!isAdminView && (
            <button
              onClick={() => setIsMobileFrame(!isMobileFrame)}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 transition-colors"
              title={isMobileFrame ? 'Expand to Full View' : 'Constrain to Mobile Frame'}
            >
              {isMobileFrame ? <Monitor className="w-4 h-4" /> : <Smartphone className="w-4 h-4" />}
            </button>
          )}
        </div>
      </header>

      {/* MOBILE TOP BAR (For quick access to Admin on small screens) */}
      <div className="lg:hidden flex items-center justify-between px-4 py-3 bg-slate-900/90 border-b border-white/10 backdrop-blur-xl z-30 sticky top-0">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-amber-500 to-yellow-400 flex items-center justify-center font-black text-black text-xs">
            🎙️
          </div>
          <span className="text-xs font-black tracking-wide text-white">Aura Voice</span>
        </div>

        <div className="flex items-center gap-2">
          {/* MOBILE TOP CONTRIBUTORS LEADERBOARD BUTTON */}
          <button
            onClick={() => setActiveModal('contributors')}
            className="p-2 rounded-xl bg-gradient-to-r from-amber-500/20 to-yellow-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-400/30 text-xs font-bold flex items-center justify-center transition-all active:scale-95 cursor-pointer"
            title="Top Contributors Leaderboard"
          >
            <Trophy className="w-4 h-4 text-amber-400" />
          </button>

          {/* MOBILE USER SEARCH BUTTON */}
          <button
            onClick={() => openUserSearch()}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/15 text-amber-300 border border-white/15 text-xs font-bold flex items-center justify-center transition-all active:scale-95 cursor-pointer"
            title="Search Users by UID or Name"
          >
            <Search className="w-4 h-4" />
          </button>

          <button
            onClick={() => setIsAuthModalOpen(true)}
            className="px-2.5 py-1.5 rounded-xl bg-purple-500/20 text-purple-200 border border-purple-500/30 text-xs font-bold flex items-center gap-1"
          >
            <LogIn className="w-3 h-3 text-amber-400" />
            <span>Auth</span>
          </button>

          <button
            onClick={() => {
              if (!isAdminView) {
                setActiveModal('admin');
              }
              setIsAdminSidebarOpenMobile(true);
            }}
            className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 text-black font-black text-xs flex items-center gap-1.5 shadow-md shadow-amber-500/20"
          >
            <Menu className="w-3.5 h-3.5" />
            <span>Admin</span>
          </button>
        </div>
      </div>

      {/* BODY WORKSPACE */}
      <div className="flex-1 flex w-full relative">
        {/* PERSISTENT ADMIN SIDEBAR (Responsive on Mobile & Desktop) */}
        {(isAdminView || typeof window !== 'undefined') && (
          <AdminSidebar
            activeTab={adminActiveTab}
            onSelectTab={handleAdminSelectTab}
            currentUser={currentUser}
            isOpenMobile={isAdminSidebarOpenMobile}
            onCloseMobile={() => setIsAdminSidebarOpenMobile(false)}
            isCollapsed={isAdminCollapsed}
            onToggleCollapse={() => setIsAdminCollapsed(!isAdminCollapsed)}
            onExitAdmin={() => setActiveModal('none')}
          />
        )}

        {/* MAIN DISPLAY VIEW */}
        <div className="flex-1 min-w-0 relative flex flex-col">
          {isAdminView ? (
            /* ADMIN PORTAL WORKSPACE */
            <div className="flex-1 w-full p-3 sm:p-6 max-w-[1700px] mx-auto">
              <AdminPanelPage />
            </div>
          ) : (
            /* USER MOBILE APP WORKSPACE */
            <div className="flex-1 flex items-center justify-center p-0 sm:p-4">
              <div
                className={`w-full min-h-screen bg-[#0c031a] text-slate-100 relative overflow-x-hidden shadow-2xl transition-all ${
                  isMobileFrame 
                    ? 'max-w-md mx-auto rounded-none sm:rounded-3xl border-x border-y sm:border border-white/10' 
                    : 'w-full max-w-5xl mx-auto rounded-3xl border border-white/10'
                }`}
              >
                {/* MAIN TAB PAGES */}
                <main className="p-4 relative z-10 pb-28 sm:pb-32">
                  {activeTab === 'home' && <HomePage />}
                  {activeTab === 'rooms' && <RoomsPage />}
                  {activeTab === 'messages' && <MessagesPage />}
                  {activeTab === 'family' && <FamilyPage />}
                  {activeTab === 'profile' && <ProfilePage />}
                </main>

                {/* BOTTOM NAVIGATION BAR (Hidden during active room session) */}
                {!activeRoom && <BottomNav />}

                {/* ACTIVE VOICE ROOM OVERLAY VIEW */}
                {activeRoom && <VoiceRoomView />}

                {/* FULLSCREEN POPUP MODALS */}
                {activeModal === 'vip_shop' && <VipShopPage />}
                {activeModal === 'wallet' && <WalletPage />}
                {activeModal === 'lucky_bag' && <LuckyBagPage />}
                {activeModal === 'spin' && <DailySpinPage />}
                {activeModal === 'pk' && <PkBattlePage />}
                {activeModal === 'cp' && <CPScreen onClose={() => setActiveModal('none')} />}
                {activeModal === 'friends' && <FriendsScreen onClose={() => setActiveModal('none')} />}
                {(activeModal === 'contributors' || activeModal === 'leaderboard') && (
                  <TopContributorsLeaderboard onClose={() => setActiveModal('none')} />
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* FIREBASE AUTHENTICATION MODAL */}
      <AuthModal isOpen={isAuthModalOpen} onClose={() => setIsAuthModalOpen(false)} />

      {/* USER SEARCH MODAL (SEARCH BY UID / NAME) */}
      <UserSearchModal
        isOpen={isSearchOpen || activeModal === 'search'}
        onClose={() => {
          setIsSearchOpen(false);
          if (activeModal === 'search') setActiveModal('none');
        }}
        initialQuery={searchInitialQuery}
      />
    </div>
  );
};
