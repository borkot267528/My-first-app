/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { MessageSquare, Users, Bell, Shield, Send, Mic, Image as ImageIcon, Gift, ArrowLeft, CheckCheck } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ApiClient } from '../../lib/api';

export const MessagesPage: React.FC = () => {
  const { showNotification, currentUser, setActiveModal } = useApp();
  const [activeTab, setActiveTab] = useState<'private' | 'family' | 'system' | 'notifications'>('private');
  const [activeChatUser, setActiveChatUser] = useState<any | null>(null);
  const [msgInput, setMsgInput] = useState('');
  const [chatHistory, setChatHistory] = useState([
    { id: 'm1', senderId: '8829106', text: 'Hey! Are you hosting the PK battle tonight?', time: '10:15 AM', isMe: false },
    { id: 'm2', senderId: 'me', text: 'Yes! We start at 10 PM UTC. Make sure to invite your family members 🔥', time: '10:16 AM', isMe: true },
    { id: 'm3', senderId: '8829106', text: 'Awesome! I have readied 50,000 coins for gift support 💎', time: '10:18 AM', isMe: false }
  ]);

  const [privateConversations, setPrivateConversations] = useState<any[]>([
    { id: 'c1', name: 'Marcus Aurelius', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80', role: 'GM', lastMsg: 'Awesome! I have readied 50,000 coins...', time: '10:18 AM', unread: 2, online: true },
    { id: 'c2', name: 'Alex Chen', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80', role: 'Super Admin', lastMsg: 'Sent you the esports tournament flyer 🕹️', time: 'Yesterday', unread: 0, online: true },
    { id: 'c3', name: 'Sophia Taylor', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80', role: 'Agency', lastMsg: 'Can we do a dual acoustic live room next week?', time: '2 days ago', unread: 0, online: false },
    { id: 'c4', name: 'Kenji Sato', avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=300&q=80', role: 'Host', lastMsg: 'Thanks for the Royal Crown gift! 🙏✨', time: '3 days ago', unread: 0, online: true }
  ]);

  const [notificationsList, setNotificationsList] = useState<any[]>([
    { id: 'n1', title: 'New Follower', text: 'Alex Chen started following your voice room!', time: '10 mins ago', icon: '👤' },
    { id: 'n2', title: 'Lucky Bag Claimed', text: 'You won 180 coins from Elena Vance\'s room lucky bag!', time: '1 hour ago', icon: '🪙' },
    { id: 'n3', title: 'PK Battle Victory', text: 'Your room defeated Cyber Wolves in Live PK! +500 Exp gained.', time: '4 hours ago', icon: '🏆' },
    { id: 'n4', title: 'Gift Received', text: 'Marcus Aurelius sent you a Neon Heart 💖 in Room #101.', time: '6 hours ago', icon: '🎁' }
  ]);

  useEffect(() => {
    ApiClient.getConversations().then(res => {
      if (res && res.length > 0) {
        setPrivateConversations(res.map(c => ({
          id: c.peerId || c.id,
          name: c.peerName || 'User',
          avatar: c.peerAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
          role: 'VIP',
          lastMsg: c.lastMessage || 'Sent a message',
          time: 'Recent',
          unread: c.unreadCount || 0,
          online: true
        })));
      }
    }).catch(() => {});

    ApiClient.getNotifications().then(res => {
      if (res && res.length > 0) {
        setNotificationsList(res.map(n => ({
          id: n.id,
          title: n.title,
          text: n.message,
          time: new Date(n.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          icon: n.type === 'gift' ? '🎁' : n.type === 'system' ? '🛡️' : '🔔'
        })));
      }
    }).catch(() => {});
  }, []);

  useEffect(() => {
    if (activeChatUser) {
      ApiClient.getPrivateMessages(activeChatUser.id).then(res => {
        if (res && res.length > 0) {
          setChatHistory(res.map(m => ({
            id: m.id,
            senderId: m.senderId,
            text: m.content,
            time: new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            isMe: m.senderId === (currentUser?.id || '2383452')
          })));
        }
      }).catch(() => {});
    }
  }, [activeChatUser, currentUser]);

  const familyMessages = [
    { id: 'fm1', name: 'Elena Vance (Leader)', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80', text: '👑 Royal Dynasty Clan! Remember to complete daily contributions.', time: '09:00 AM' },
    { id: 'fm2', name: 'Marcus Aurelius', text: 'Contributed 500 diamonds today! Let us reach Level 9 🚀', time: '09:30 AM' },
    { id: 'fm3', name: 'Kenji Sato', text: 'Who is online for squad gaming right now?', time: '11:10 AM' }
  ];

  const systemMessages = [
    { id: 's1', title: '🎉 Recharge Bonus Event', text: 'Recharge any diamond package this weekend to get +20% bonus coins automatically added to your wallet!', time: '2 hours ago' },
    { id: 's2', title: '🛡️ Security & Anti-Fraud Notice', text: 'Aura Voice Chat will never ask for your password or bank details. Please report any suspicious users immediately.', time: '1 day ago' },
    { id: 's3', title: '🚀 Version 1.0.0 Live', text: 'Welcome to the new Android-style mobile interface! Enjoy smoother audio and brand new luxury 3D gifts.', time: '3 days ago' }
  ];

  const handleSendPrivate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!msgInput.trim() || !activeChatUser) return;
    const text = msgInput.trim();
    setMsgInput('');
    const tempId = `my-${Date.now()}`;
    setChatHistory(prev => [
      ...prev,
      { id: tempId, senderId: currentUser?.id || '2383452', text, time: 'Just now', isMe: true }
    ]);
    try {
      await ApiClient.sendPrivateMessage(activeChatUser.id, text, 'text');
    } catch (err) {
      console.error('Failed to send private message', err);
    }
  };

  if (activeChatUser) {
    return (
      <div className="pb-24 space-y-3 animate-fadeIn">
        {/* Chat Header */}
        <div className="flex items-center justify-between bg-white/5 backdrop-blur-xl p-3 rounded-2xl border border-white/10 shadow-xl">
          <div className="flex items-center gap-3">
            <button onClick={() => setActiveChatUser(null)} className="p-1 text-slate-300 hover:text-white">
              <ArrowLeft className="w-5 h-5" />
            </button>
            <img src={activeChatUser.avatar} alt={activeChatUser.name} className="w-10 h-10 rounded-full object-cover border border-white/20" />
            <div>
              <h4 className="font-bold text-white text-sm flex items-center gap-1.5">
                {activeChatUser.name}
                <span className="bg-white/10 text-slate-300 text-[9px] px-1.5 py-0.2 rounded border border-white/10">
                  {activeChatUser.role}
                </span>
              </h4>
              <span className="text-[10px] text-emerald-400 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" /> Online Now
              </span>
            </div>
          </div>
          <button onClick={() => setActiveModal('vip_shop')} title="Send Gift" className="p-2 bg-gradient-to-r from-amber-500 to-pink-500 rounded-xl text-white shadow">
            <Gift className="w-4 h-4" />
          </button>
        </div>

        {/* Chat Thread */}
        <div className="bg-black/40 backdrop-blur-md p-4 rounded-3xl border border-white/10 h-96 overflow-y-auto space-y-3 flex flex-col shadow-inner">
          <div className="text-center my-2">
            <span className="text-[10px] text-slate-400 bg-white/5 px-3 py-1 rounded-full border border-white/5">Today</span>
          </div>
          {chatHistory.map((m) => (
            <div key={m.id} className={`flex flex-col ${m.isMe ? 'items-end' : 'items-start'} max-w-[80%]`}>
              <div className={`p-3 rounded-2xl text-xs leading-relaxed ${m.isMe ? 'bg-white text-purple-950 font-bold rounded-tr-none shadow-md' : 'bg-white/10 backdrop-blur-md text-slate-100 rounded-tl-none border border-white/10'}`}>
                {m.text}
              </div>
              <span className="text-[9px] text-slate-400 mt-1 flex items-center gap-1">
                {m.time} {m.isMe && <CheckCheck className="w-3 h-3 text-cyan-400" />}
              </span>
            </div>
          ))}
        </div>

        {/* Chat Input Bar */}
        <form onSubmit={handleSendPrivate} className="flex items-center gap-2">
          <button type="button" onClick={() => showNotification('Voice note recording simulated (3s audio sent!)')} className="p-3 bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl text-slate-300 hover:text-white">
            <Mic className="w-4 h-4" />
          </button>
          <button type="button" onClick={() => showNotification('Photo attachment uploaded!')} className="p-3 bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl text-slate-300 hover:text-white">
            <ImageIcon className="w-4 h-4" />
          </button>
          <input
            type="text"
            placeholder="Type private message..."
            value={msgInput}
            onChange={(e) => setMsgInput(e.target.value)}
            className="flex-1 bg-white/5 backdrop-blur-md text-white text-xs px-4 py-3 rounded-2xl border border-white/10 focus:outline-none focus:border-white/25 placeholder:text-slate-400 shadow-inner"
          />
          <button type="submit" className="p-3 bg-white text-purple-900 hover:bg-purple-100 font-black rounded-2xl shadow hover:scale-105">
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    );
  }

  return (
    <div className="pb-24 space-y-4 animate-fadeIn">
      {/* Tabs */}
      <div className="grid grid-cols-4 gap-1.5 p-1.5 bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 shadow-lg">
        {[
          { id: 'private', label: 'Private', icon: <MessageSquare className="w-3.5 h-3.5" />, count: 2 },
          { id: 'family', label: 'Family', icon: <Users className="w-3.5 h-3.5" />, count: 1 },
          { id: 'system', label: 'System', icon: <Shield className="w-3.5 h-3.5" /> },
          { id: 'notifications', label: 'Alerts', icon: <Bell className="w-3.5 h-3.5" /> }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex items-center justify-center gap-1 py-2 px-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === tab.id
                ? 'bg-white text-purple-900 font-black shadow'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            {tab.icon} <span className="truncate">{tab.label}</span>
            {tab.count && <span className="bg-pink-500 text-white text-[9px] px-1 rounded-full">{tab.count}</span>}
          </button>
        ))}
      </div>

      {/* Tab 1: Private Chat */}
      {activeTab === 'private' && (
        <div className="space-y-2.5">
          {privateConversations.map((conv) => (
            <div
              key={conv.id}
              onClick={() => setActiveChatUser(conv)}
              className="cursor-pointer p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 hover:border-white/20 hover:bg-white/10 transition-all flex items-center justify-between shadow-xl"
            >
              <div className="flex items-center gap-3">
                <div className="relative">
                  <img src={conv.avatar} alt={conv.name} className="w-12 h-12 rounded-full object-cover border border-white/20" />
                  {conv.online && <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 rounded-full border-2 border-black/80" />}
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <h5 className="font-bold text-white text-sm">{conv.name}</h5>
                    <span className="text-[10px] bg-white/10 text-slate-200 px-1.5 py-0.2 rounded font-semibold border border-white/10">{conv.role}</span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5 line-clamp-1">{conv.lastMsg}</p>
                </div>
              </div>
              <div className="flex flex-col items-end gap-1">
                <span className="text-[10px] text-slate-500">{conv.time}</span>
                {conv.unread > 0 && (
                  <span className="w-5 h-5 rounded-full bg-pink-500 text-white text-[10px] font-black flex items-center justify-center shadow">
                    {conv.unread}
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 2: Family Chat */}
      {activeTab === 'family' && (
        <div className="space-y-3">
          <div className="p-3.5 rounded-2xl bg-gradient-to-r from-purple-900/30 to-pink-900/30 backdrop-blur-xl border border-white/10 flex items-center justify-between shadow-xl">
            <div className="flex items-center gap-2.5">
              <span className="text-2xl">👑</span>
              <div>
                <h4 className="font-extrabold text-white text-sm">Royal Dynasty Clan Chat</h4>
                <p className="text-xs text-slate-300">45 Members Online • Level 8 Family</p>
              </div>
            </div>
            <button onClick={() => showNotification('Joined Family Voice Room')} className="px-3 py-1.5 bg-white text-purple-900 hover:bg-purple-100 font-black text-xs rounded-xl shadow">
              Voice Lounge
            </button>
          </div>

          <div className="space-y-2">
            {familyMessages.map((fm) => (
              <div key={fm.id} className="p-3 rounded-2xl bg-white/5 backdrop-blur-md border border-white/10 space-y-1 shadow">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-amber-300 text-xs">{fm.name}</span>
                  <span className="text-[10px] text-slate-500">{fm.time}</span>
                </div>
                <p className="text-xs text-white leading-relaxed">{fm.text}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: System Messages */}
      {activeTab === 'system' && (
        <div className="space-y-2.5">
          {systemMessages.map((sys) => (
            <div key={sys.id} className="p-4 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 space-y-1.5 shadow-xl">
              <div className="flex items-center justify-between">
                <h5 className="font-extrabold text-amber-400 text-sm flex items-center gap-1.5">
                  <Shield className="w-4 h-4 text-purple-400" /> {sys.title}
                </h5>
                <span className="text-[10px] text-slate-500">{sys.time}</span>
              </div>
              <p className="text-xs text-slate-200 leading-relaxed">{sys.text}</p>
            </div>
          ))}
        </div>
      )}

      {/* Tab 4: Notifications */}
      {activeTab === 'notifications' && (
        <div className="space-y-2">
          {notificationsList.map((notif) => (
            <div key={notif.id} className="p-3.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 flex items-center gap-3 shadow-xl">
              <span className="w-10 h-10 rounded-2xl bg-white/10 border border-white/10 flex items-center justify-center text-xl flex-shrink-0">
                {notif.icon}
              </span>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h5 className="font-bold text-white text-xs">{notif.title}</h5>
                  <span className="text-[10px] text-slate-500">{notif.time}</span>
                </div>
                <p className="text-xs text-slate-300 mt-0.5">{notif.text}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
