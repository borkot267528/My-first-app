/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export * from './pk/PKBattle';
export { PKBattle as default } from './pk/PKBattle';
