/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type UserRole = 
  | 'user' 
  | 'host' 
  | 'agency' 
  | 'bd' 
  | 'admin' 
  | 'super_admin' 
  | 'manager' 
  | 'gm' 
  | 'ceo'
  | 'recharge_agent'
  | 'coin_merchant'
  | 'seller'
  | 'official_staff';

export interface StaffIdentity {
  role: UserRole;
  roles?: string[];
  positions?: string[];
  badge: string;
  badges?: string[];
  title: string;
  titles?: string[];
  frame?: string;
  background?: string;
  staffId: string;
  staffLevel: number;
  isVerified: boolean;
  department: string;
  joinedDate: string;
  activeStatus: 'Active' | 'On Shift' | 'Offline' | 'Suspended';
  assignedBy?: string;
  assignedAt?: string;
  notes?: string;
}

export interface IdentityHistoryEntry {
  id: string;
  role: UserRole;
  roles?: string[];
  title: string;
  titles?: string[];
  action: 'assigned' | 'removed' | 'updated';
  assignedBy: string;
  assignedAt: string;
  previousIdentities?: string[];
  newIdentities?: string[];
  notes?: string;
}

export interface BanRecord {
  id: string;
  userId: string;
  userUid: string;
  userName: string;
  userAvatar?: string;
  banType: 'temporary' | 'permanent';
  durationHours?: number;
  reason: string;
  adminNote?: string;
  bannedBy: string;
  bannedByName: string;
  bannedByRole: string;
  bannedAt: string;
  expiresAt?: string;
  status: 'active' | 'expired' | 'unbanned';
  unbannedBy?: string;
  unbannedByName?: string;
  unbannedAt?: string;
  unbanReason?: string;
}

export interface User {
  id: string;
  uid: string;
  firebaseUid?: string;
  nigoId?: string;
  name: string;
  email: string;
  password?: string;
  avatar: string;
  frame?: string;
  background?: string;
  gender: 'male' | 'female' | 'other';
  phone?: string;
  country: string;
  countryId?: string;
  countryCode?: string;
  dialCode?: string;
  currencyCode?: string;
  countryFlag: string;
  bio: string;
  role: UserRole;
  status?: 'active' | 'banned' | 'suspended';
  banType?: 'temporary' | 'permanent';
  banReason?: string;
  banNote?: string;
  banStartedAt?: string;
  banExpiresAt?: string;
  bannedBy?: string;
  bannedByName?: string;
  bannedByRole?: string;
  unbannedAt?: string;
  unbannedBy?: string;
  unbannedByName?: string;
  staffIdentity?: StaffIdentity;
  canAssignIdentity?: boolean;
  identityHistory?: IdentityHistoryEntry[];
  vipLevel: 'none' | 'vip' | 'svip';
  vipExpiry?: string;
  coins: number;
  diamonds: number;
  level: number;
  sendingLevel?: number;   // Sending Level (Wealth / Giver Level ID based on coins sent)
  receivingLevel?: number; // Receiving Level (Charm / Receiver Level ID based on gifts received)
  familyId?: string;
  familyName?: string;
  isOnline: boolean;
  createdAt: string;
  badges: Badge[];
  medals: Medal[];
}

export interface Badge {
  id: string;
  name: string;
  icon: string;
  description: string;
  acquiredAt: string;
}

export interface Medal {
  id: string;
  name: string;
  icon: string;
  level: number;
  color: string;
}

export interface VoiceRoom {
  id: string;
  hostUid?: string;
  title: string;
  topic: string;
  category: 'popular' | 'new' | 'country' | 'family' | 'game' | 'music';
  coverImage: string;
  hostId: string;
  hostName: string;
  hostAvatar: string;
  hostFrame?: string;
  country: string;
  countryFlag: string;
  language: string;
  onlineCount: number;
  maxSeats: number;
  isLocked: boolean;
  password?: string;
  announcement: string;
  tags: string[];
  musicPlaying?: {
    title: string;
    artist: string;
    isPlaying: boolean;
  };
  toolsState?: RoomToolsState;
  pkState?: {
    active: boolean;
    opponentRoomId?: string;
    opponentName?: string;
    opponentAvatar?: string;
    myScore: number;
    opponentScore: number;
    timeLeft: number;
  };
  status?: 'active' | 'inactive' | 'suspended';
  theme?: string;
  backgroundUrl?: string;
  privacy?: 'public' | 'private';
  allowMic?: boolean;
  allowChat?: boolean;
  allowGifts?: boolean;
  allowNewUsers?: boolean;
  hostOnlyControls?: boolean;
  soundEffectsEnabled?: boolean;
  blockedWords?: string[];
  bannedUserIds?: string[];
  kickedUsers?: { userId: string; userName: string; kickedUntil: string; reason?: string }[];
  announcementsList?: { id: string; title: string; content: string; enabled: boolean; createdAt: string }[];
  seats: MicSeat[];
  createdAt: string;
}

export interface MicSeat {
  index: number; // 0 is host, 1-8 are mic seats
  userId?: string;
  userName?: string;
  userAvatar?: string;
  userFrame?: string;
  isMuted: boolean;
  isLocked: boolean;
  isSpeaking: boolean;
  contributionCoin: number;
}

export interface RoomMusicState {
  title: string;
  artist: string;
  url?: string;
  isPlaying: boolean;
  currentTime?: number;
  duration?: number;
  volume?: number;
  queue?: Array<{ id: string; title: string; artist: string; url?: string; duration?: number; addedBy?: string }>;
}

export interface RoomYouTubeState {
  videoId: string;
  videoTitle: string;
  videoUrl: string;
  isPlaying: boolean;
  currentTime?: number;
  addedBy?: string;
  queue?: Array<{ id: string; videoId: string; videoTitle: string; videoUrl: string; addedBy?: string }>;
}

export interface RoomCPInteractionState {
  active: boolean;
  partner1Id: string;
  partner1Name: string;
  partner1Avatar: string;
  partner2Id: string;
  partner2Name: string;
  partner2Avatar: string;
  coupleId?: string;
  level: number;
  connectionDays: number;
  interactionType?: 'hug' | 'love' | 'kiss' | 'anniversary' | 'gift';
  startedAt?: string;
}

export interface RoomGameState {
  activeGameId?: 'spin' | 'lucky77' | 'lucky_bag' | 'fruit_blast' | 'trivia' | 'dice';
  gameName?: string;
  status?: 'idle' | 'waiting' | 'in_progress' | 'ended';
  hostId?: string;
  hostName?: string;
  players?: Array<{ userId: string; userName: string; userAvatar: string; score?: number }>;
  lastResult?: any;
}

export interface RoomToolsState {
  activeTool?: 'none' | 'game' | 'music' | 'youtube' | 'cp' | 'pk';
  music?: RoomMusicState;
  youtube?: RoomYouTubeState;
  cp?: RoomCPInteractionState;
  pk?: {
    active: boolean;
    battleId?: string;
    opponentRoomId?: string;
    opponentName?: string;
    opponentAvatar?: string;
    myScore: number;
    opponentScore: number;
    timeLeft: number;
    startedAt?: string;
    status?: 'matching' | 'active' | 'finished';
    winner?: 'roomA' | 'roomB' | 'draw';
    history?: Array<{ opponentName: string; myScore: number; opponentScore: number; result: 'win' | 'lose' | 'draw'; date: string }>;
  };
  game?: RoomGameState;
}

export interface RoomMessage {
  id: string;
  roomId: string;
  userId: string;
  userName: string;
  userAvatar: string;
  vipLevel?: 'none' | 'vip' | 'svip';
  type: 'text' | 'gift' | 'system' | 'join' | 'emoji' | 'lucky_bag';
  content: string;
  giftId?: string;
  giftName?: string;
  giftIcon?: string;
  giftCount?: number;
  timestamp: string;
}

export interface Gift {
  id: string;
  name: string;
  icon: string;
  priceCoins: number;
  category: 'popular' | 'luxury' | 'pk' | 'family' | 'special';
  animationType: 'pop' | 'fullscreen' | 'banner';
  svgColor: string;
  description?: string;
  stockQuantity?: number; // -1 or undefined for infinite stock
  isAvailable?: boolean;
  diamondYieldRate?: number; // Default 0.5 (50% host diamond commission)
  rarity?: 'common' | 'rare' | 'epic' | 'legendary' | 'mythic';
  soundEffect?: string;
  comboMultiplier?: number;
  tags?: string[];
  createdAt?: string;
}

export interface UserGiftInventoryItem {
  id: string;
  userId: string;
  giftId: string;
  quantity: number;
  gift?: Gift;
  acquiredAt: string;
  source?: 'purchase' | 'spin' | 'lucky_bag' | 'event' | 'reward';
}

export interface SendGiftParams {
  senderId: string;
  receiverId: string;
  giftId: string;
  count?: number;
  roomId?: string;
  deductFromInventory?: boolean;
  comboStreak?: number;
  customMessage?: string;
}

export interface SendGiftResult {
  success: boolean;
  transactionId: string;
  senderId: string;
  receiverId: string;
  gift: Gift;
  count: number;
  totalCostCoins: number;
  diamondsAwarded: number;
  senderNewCoinBalance: number;
  receiverNewDiamondBalance: number;
  deductedFromInventory: boolean;
  remainingInventoryCount?: number;
  senderSendingLevel?: number;
  receiverReceivingLevel?: number;
  roomMessageId?: string;
  pkScoreBoosted?: boolean;
  pkNewScore?: number;
  notificationsSent: {
    receiverNotificationId?: string;
    roomBroadcast: boolean;
    luxuryGlobalAlert: boolean;
    hostNotificationId?: string;
    familyNoticeSent?: boolean;
  };
  comboStreak?: number;
  timestamp: string;
}

export interface GiftInventoryStats {
  totalGifts: number;
  totalCategories: number;
  categoryCounts: Record<string, number>;
  rarityCounts: Record<string, number>;
  totalInStock: number;
  mostPopularGifts: Gift[];
}

export interface LuckyBag {
  id: string;
  roomId: string;
  senderId: string;
  senderName: string;
  totalCoins: number;
  remainingCoins: number;
  totalWinners: number;
  claimedCount: number;
  createdAt: string;
  expiresAt: string;
  status: 'active' | 'expired' | 'depleted';
  claims: {
    userId: string;
    userName: string;
    userAvatar: string;
    amount: number;
    claimedAt: string;
  }[];
}

export interface Family {
  id: string;
  familyId?: string;
  name: string;
  slogan: string;
  badge: string;
  logo?: string;
  coverImage: string;
  description?: string;
  announcement: string;
  country?: string;
  category?: string;
  status?: 'active' | 'inactive' | 'suspended';
  suspendReason?: string;
  privacy?: 'public' | 'private';
  joinMethod?: 'anyone' | 'approval' | 'invite';
  ownerId?: string;
  leaderId: string;
  leaderName: string;
  leaderAvatar?: string;
  coLeaderIds?: string[];
  coLeaderNames?: string[];
  level: number;
  xp?: number;
  totalContribution: number;
  memberCount: number;
  maxMembers: number;
  ranking: number;
  createdAt?: string;
  updatedAt?: string;
}

export interface BenefitAssignmentRecord {
  id: string;
  targetUserId: string;
  targetUserUid: string;
  targetUserName: string;
  targetUserAvatar: string;
  benefitType: 'vip' | 'svip' | 'frame';
  levelOrFrameId: string;
  durationDays: number | 'permanent';
  assignedByUserId: string;
  assignedByUserName: string;
  assignedByRole: UserRole;
  assignmentMode: 'free_grant' | 'coin_deduction';
  status: 'active' | 'expired' | 'revoked';
  createdAt: string;
  expiresAt: string | 'permanent';
  reason?: string;
}

export interface FamilyMember {
  id: string;
  familyId: string;
  userId: string;
  userUid?: string;
  name: string;
  avatar: string;
  role: 'leader' | 'co_leader' | 'elder' | 'member';
  userRole?: UserRole;
  contributionDaily: number;
  contributionTotal: number;
  isOnline?: boolean;
  joinedAt: string;
}

export interface FamilyApplication {
  id: string;
  familyId: string;
  familyName: string;
  familyBadge?: string;
  familyLogo?: string;
  userId: string;
  userUid?: string;
  userName: string;
  userAvatar?: string;
  message?: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
  decidedAt?: string;
}

export interface PrivateMessage {
  id: string;
  senderId: string;
  receiverId: string;
  type: 'text' | 'image' | 'voice' | 'gift';
  content: string;
  timestamp: string;
  read: boolean;
}

export interface WalletTransaction {
  id: string;
  userId: string;
  type: 'recharge' | 'withdraw' | 'gift_sent' | 'gift_received' | 'lucky_bag' | 'spin_reward' | 'admin_adjustment';
  currency: 'coin' | 'diamond';
  amount: number;
  balanceAfter: number;
  description: string;
  status: 'completed' | 'pending' | 'rejected';
  timestamp: string;
  createdAt?: string;
}

export interface AuditLog {
  id: string;
  action: string;
  module: 'auth' | 'room' | 'wallet' | 'staff' | 'family' | 'system' | 'gift' | 'permission' | 'banner' | 'security' | 'moderation' | 'connections';
  performedByUserId: string;
  performedByUserName: string;
  performedByRole: UserRole;
  targetId?: string;
  targetName?: string;
  details: string;
  ipAddress: string;
  timestamp: string;
  oldUid?: string;
  newUid?: string;
  reason?: string;
  previousColor?: string;
  newColor?: string;
}

export type BannerType = 'event' | 'pk' | 'recharge' | 'vip' | 'gift' | 'custom';
export type BannerTargetAction = 'none' | 'open_room' | 'open_vip' | 'open_recharge' | 'open_event' | 'open_custom';
export type BannerStatus = 'active' | 'inactive' | 'scheduled' | 'expired';

export interface Banner {
  id: string;
  imageUrl: string;
  title: string;
  subtitle: string;
  description?: string;
  type: BannerType;
  targetAction: BannerTargetAction;
  targetRoomId?: string;
  targetUrl?: string;
  startDate: string;
  endDate: string;
  isActive: boolean;
  sortOrder: number;
  createdBy: string;
  createdAt: string;
  updatedAt?: string;
  status?: BannerStatus; // Calculated status for admin display
}

export interface StaffMember {
  id: string;
  userId: string;
  name: string;
  email: string;
  role: UserRole;
  staffIdentity?: StaffIdentity;
  canAssignIdentity?: boolean;
  permissions: string[];
  assignedBy: string;
  assignedAt: string;
  status: 'active' | 'suspended';
}

export interface DailySpinReward {
  id: string;
  name: string;
  type: 'coin' | 'diamond' | 'frame' | 'vip_day' | 'nothing';
  value: number;
  icon: string;
  probability: number;
  color: string;
}

export interface PkBattle {
  id: string;
  roomAId: string;
  roomAName: string;
  roomAHost: string;
  roomAAvatar: string;
  roomAScore: number;
  roomBId: string;
  roomBName: string;
  roomBHost: string;
  roomBAvatar: string;
  roomBScore: number;
  durationSeconds: number;
  remainingSeconds: number;
  status: 'matching' | 'active' | 'finished';
  winnerRoomId?: string;
  createdAt: string;
}

export interface StaffActivityLog {
  id: string;
  staffId: string;
  staffName: string;
  staffRole: UserRole;
  actionType: 'LOGIN' | 'ROLE_CHANGE' | 'ROOM_MODERATION' | 'WITHDRAWAL_APPROVAL' | 'USER_BAN' | 'SYSTEM_CONFIG';
  targetResource: string;
  details: string;
  ipAddress: string;
  timestamp: string;
}

export interface NotificationItem {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'system' | 'gift' | 'wallet' | 'pk' | 'family';
  read: boolean;
  createdAt: string;
  link?: string;
}

export interface ReportItem {
  id: string;
  reporterId: string;
  reporterName: string;
  reporterUid?: string;
  reporterAvatar?: string;
  targetType: 'user' | 'room' | 'message';
  targetId: string;
  targetTitle?: string;
  targetUserName?: string;
  reason: string;
  details?: string;
  status: 'pending' | 'investigating' | 'resolved' | 'dismissed';
  createdAt: string;
  resolvedBy?: string;
  resolvedAt?: string;
  adminNotes?: string;
}

export interface RechargePackage {
  id: string;
  name?: string;
  currencyType: 'coin' | 'diamond';
  coins?: number;
  bonus?: number;
  bonusCoins?: number;
  diamonds?: number;
  priceUsd: number;
  badge?: string;
  popular?: boolean;
  bestValue?: boolean;
  isActive: boolean;
  sortOrder?: number;
  createdAt?: string;
  updatedAt?: string;
}

export type WithdrawPaymentMethodType = 'mobile_wallet' | 'bank' | 'crypto' | 'paypal' | 'other';

export interface WithdrawPaymentMethod {
  id: string;
  name: string;
  type: WithdrawPaymentMethodType;
  currency: string;
  accountFieldLabel: string;
  placeholder?: string;
  minWithdraw?: number;
  maxWithdraw?: number;
  processingFee?: number;
  isActive: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
  createdBy?: string;
  updatedBy?: string;
}

export interface AnalyticsOverview {
  totalUsers: number;
  onlineUsers: number;
  activeRooms: number;
  totalCoinsCirculation: number;
  totalDiamondsCirculation: number;
  dailyActiveUsers: { date: string; count: number }[];
  revenueByDay: { date: string; amountUsd: number }[];
  topHosts: { hostId: string; name: string; avatar: string; diamondsEarned: number }[];
  roomRetentionRate: number;
}

export type ContributorLeaderboardCategory = 'earners' | 'senders' | 'engagement';
export type ContributorLeaderboardPeriod = 'daily' | 'weekly' | 'all';

export interface ContributorLeaderboardItem {
  rank: number;
  userId: string;
  name: string;
  avatar: string;
  uid: string;
  role: string;
  gender?: 'male' | 'female' | 'other';
  country?: string;
  countryFlag?: string;
  vipLevel?: 'none' | 'vip' | 'svip';
  frame?: string;
  sendingLevel: number;
  receivingLevel: number;
  totalCoinsSpent: number;
  diamondsEarned: number;
  engagementScore: number;
  giftsSentCount: number;
  giftsReceivedCount: number;
  isOnline: boolean;
  activeRoomId?: string;
  familyName?: string;
  badge?: string;
  trend?: 'up' | 'down' | 'same';
  trendPositions?: number;
}

export interface ContributorLeaderboardResponse {
  category: ContributorLeaderboardCategory;
  period: ContributorLeaderboardPeriod;
  updatedAt: string;
  totalContributors: number;
  topItems: ContributorLeaderboardItem[];
  currentUserRank?: {
    rank: number;
    score: number;
    diamondsEarned: number;
    coinsSpent: number;
    diffToNextRank: number;
  };
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
  timestamp: string;
}

export interface Agency {
  id: string;
  name: string;
  code: string;
  ownerUid: string;
  ownerName: string;
  ownerAvatar?: string;
  logoUrl: string;
  description?: string;
  country: string;
  contactInfo?: string;
  membersCount: number;
  totalRevenueUsd: number;
  commissionRate: number;
  pendingPayoutUsd: number;
  status: 'active' | 'pending' | 'inactive' | 'suspended';
  parentBdId?: string;
  notes?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface RechargeAgent {
  id: string;
  userId: string;
  uid: string;
  name: string;
  avatar: string;
  creditBalance: number;
  rechargeVolume: number;
  commissionRate: number;
  totalCommissionEarned: number;
  status: 'active' | 'inactive' | 'suspended';
  notes?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface Merchant {
  id: string;
  name: string;
  code: string;
  ownerUid: string;
  ownerName: string;
  apiKey: string;
  secretKey: string;
  feePercentage: number;
  totalProcessedUsd: number;
  availableBalanceUsd: number;
  pendingSettlementUsd: number;
  currency: string;
  webhookUrl?: string;
  status: 'active' | 'pending' | 'suspended' | 'inactive';
  notes?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface Country {
  id: string; // e.g. "bd", "us", "in" or uuid
  name: string; // e.g. "Bangladesh"
  countryCode: string; // ISO 2-letter uppercase, e.g. "BD"
  iso2: string; // ISO 2-letter uppercase, e.g. "BD"
  iso3: string; // ISO 3-letter uppercase, e.g. "BGD"
  dialCode: string; // Dial code with +, e.g. "+880"
  flag: string; // Flag emoji or URL, e.g. "🇧🇩"
  currencyName: string; // e.g. "Bangladeshi Taka"
  currencyCode: string; // e.g. "BDT"
  currencySymbol: string; // e.g. "৳"
  defaultLanguage: string; // e.g. "Bengali"
  timezone: string; // e.g. "Asia/Dhaka"
  status: 'enabled' | 'disabled'; // Status: Enabled / Disabled
  registrationAllowed: boolean; // Registration Allowed: Yes / No
  loginAllowed: boolean; // Login Allowed: Yes / No
  rechargeAllowed: boolean; // Recharge Allowed: Yes / No
  withdrawalAllowed: boolean; // Withdrawal Allowed: Yes / No
  voiceRoomAllowed: boolean; // Voice Room Allowed: Yes / No
  paymentMethods: string[]; // Supported payment/recharge methods, e.g. ["bKash", "Nagad", "Rocket"]
  withdrawalMethods?: string[]; // Supported withdrawal methods, e.g. ["bKash", "Nagad", "Rocket", "Binance USDT"]
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
  createdBy?: string;
  updatedBy?: string;
}

export interface CountryFormData {
  name: string;
  countryCode?: string;
  iso2: string;
  iso3: string;
  dialCode: string;
  flag: string;
  currencyName: string;
  currencyCode: string;
  currencySymbol: string;
  defaultLanguage: string;
  timezone: string;
  status: 'enabled' | 'disabled';
  registrationAllowed: boolean;
  loginAllowed: boolean;
  rechargeAllowed: boolean;
  withdrawalAllowed: boolean;
  voiceRoomAllowed: boolean;
  paymentMethods: string[];
  withdrawalMethods?: string[];
  sortOrder?: number;
}

export interface AdminAppearanceSettings {
  backgroundColor: string;
  updatedAt: string;
  updatedBy: string;
  updatedByName?: string;
  updatedByRole?: string;
}

// ==========================================
// DYNAMIC RBAC PERMISSION MANAGEMENT SYSTEM
// ==========================================

export type PermissionAccessLevel = 'NONE' | 'VIEW' | 'OPERATE' | 'MANAGE' | 'FULL';
export type PermissionLevel = PermissionAccessLevel;

export interface PermissionModule {
  id: string;
  key: string;
  name: string;
  description: string;
  icon?: string;
  isCustom?: boolean;
}

export interface SystemPermission {
  id: string;
  key: string;
  name: string;
  module: string;
  description: string;
  defaultLevel: PermissionAccessLevel;
  isCustom?: boolean;
  isCeoProtected?: boolean; // E.g., users:edit_uid can only be granted by CEO
  createdAt?: string;
  createdBy?: string;
}

export interface RolePermissionConfig {
  id: string;
  roleId: UserRole;
  roleName: string;
  rank: number;
  description?: string;
  permissions: Record<string, PermissionAccessLevel>;
  canGrantRoles: UserRole[] | ['*'];
  updatedAt: string;
  updatedBy: string;
}

export interface StaffPermissionOverride {
  id: string;
  userId: string;
  userName: string;
  userUid: string;
  role: UserRole;
  overrides: Record<string, PermissionAccessLevel>;
  notes?: string;
  updatedAt: string;
  updatedBy: string;
}

export interface EffectivePermissionResult {
  userId?: string;
  role: UserRole;
  isCeo: boolean;
  rolePermissions: Record<string, PermissionAccessLevel>;
  overrides: Record<string, PermissionAccessLevel>;
  effectivePermissions: Record<string, PermissionAccessLevel>;
  canGrantRoles: UserRole[] | ['*'];
}

export type ConnectionType = 'friend' | 'cp';
export type ConnectionRequestStatus = 'pending' | 'accepted' | 'declined' | 'cancelled';
export type ConnectionStatus = 'active' | 'terminated';

export interface Connection {
  id: string;
  type: ConnectionType;
  user1Id: string;
  user2Id: string;
  user1?: User;
  user2?: User;
  level: number;
  intimacyPoints: number;
  sharedGiftsCount: number;
  sharedGiftsCoins: number;
  status: ConnectionStatus;
  establishedAt: string;
  updatedAt: string;
}

export interface ConnectionRequest {
  id: string;
  type: ConnectionType;
  senderId: string;
  sender?: User;
  receiverId: string;
  receiver?: User;
  status: ConnectionRequestStatus;
  message?: string;
  createdAt: string;
  updatedAt: string;
}

export interface BlockedUserRecord {
  id: string;
  userId: string;
  blockedUserId: string;
  createdAt: string;
  user?: User;
  blockedUser?: User;
}

export interface AdminConnectionOverview {
  totalActiveCp: number;
  totalTerminatedCp: number;
  totalActiveFriends: number;
  totalTerminatedFriends: number;
  totalPendingRequests: number;
  totalAcceptedRequests: number;
  totalDeclinedRequests: number;
  totalCancelledRequests: number;
  totalIntimacyPoints: number;
  totalSharedCoins: number;
  averageIntimacy: number;
  levelDistribution: Record<number, number>;
  topCpCouples: Connection[];
}

export interface ConnectionSystemConfig {
  minUserLevelForCp: number;
  initialIntimacyPoints: number;
  giftIntimacyPercent: number;
  giftIntimacyBasePerGift: number;
  maxFriendsLimit: number;
  autoApproveVipCp: boolean;
  allowSameGenderCp: boolean;
  updatedAt?: string;
  updatedBy?: string;
}


